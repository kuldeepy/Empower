Predict Environment
===================
Prerequisites
-------------
**For local set-ups, add a hosts file entry for localhost.dev**
```bash
sudo vi /etc/hosts

127.0.0.1		localhost
127.0.0.1		localhost.dev
127.0.1.1		my_dev_machine
~~~

**Install Pip (for Ansible Install)**
```bash
wget https://bootstrap.pypa.io/get-pip.py
sudo python get-pip.py
rm get-pip.py
```

**Install Git, openssh-server and sshpass**
```bash
sudo apt-get update && sudo apt-get install git && sudo apt-get install -y openssh-server && sudo apt-get install -y sshpass
```


Setup
-----

**Install Ansible**

Get [Ansible](http://docs.ansible.com/intro_installation.html) __v1.9 or greater__.
Note, ansible only works on unix machines. Also, if you install
via the debian package, you will get a version that is too old.
The easiest way to install Ansible on both Mac and Ubuntu is
with [pip](https://pip.pypa.io/en/latest/installing.html).

```bash
sudo pip install ansible
```

**Clone this repository on the control machine.**

```bash
git clone git@github.com:medseek-engineering/predict_environment.git
```

**Default Inventory (for local setups)**

If you want to avoid having to type "-i dev" with every ansible command,
you can do the below:

```bash
sudo mkdir /etc/ansible
sudo mkdir /etc/ansible/hosts
sudo cp dev /etc/ansible/hosts
sudo chmod -x /etc/ansible/hosts/dev
```

__Note:__ *If your git repository is cloned to a shared directory between
your VM and local machine, VirtualBox will cause conflicts
when calling the ansible inventory files in a playbook. You can work
around this by performing the above copy routine.*

**Test your authentication**

```bash
cd predict_environment
ansible all -a 'ls' -i <inventory file>
```

This command instructs ansible to execute the `ls` command on all the machines
in the inventory. If you have never worked with the specified inventory before, you probably
will encounter authentication errors. Follow the steps below to fix those.

Assuming your authentication worked, you should see some text showing the output of a `ls`
command executed in your home directory on each machine.


Authentication
--------------

Ansible strongly prefers that it be able to ssh to the machines it is managing via
public key authentication. Therefore, setup public key authentication with the machines
that you will be managing from the control machine.

__On the control machine__

__Generate RSA key:__

```bash
ssh-keygen -t rsa -C "yourusername@controlmachine"
```

__Ensure SSH Agent is enabled:__

```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_rsa
```

__Create user on remote hosts if needed:__
```bash
sudo adduser username
sudo adduser username sudo
sudo adduser username docker
```

__Use ansible to setup authorized_key file on remote hosts:__

```bash
ansible all -m authorized_key -a "user=<username> key=\"{{ lookup('file', '~/.ssh/id_rsa.pub') }}\""  -i <inventoryName> --ask-pass
```
Username is required.
```bash
--user "<username>" --become --ask-become-pass --ask-pass
```
Sometimes the above is needed in addition to the ansible command, depending on the configuration of the environment

You can now manage your inventory without having to use --ask-pass again with ansible or ansible-playbook.


Inventories
-----------

Ansible inventories are lists of machines in ini format that describe a deployment.
This project contains the following inventories:

* [staging](staging)
* [production](production)
* [qa-dev](qa-dev)


Running the Playbook
--------------------

```bash
ansible-playbook -i <inventory file> predict.yaml --ask-sudo-pass
```
