var db = db.getSiblingDB('admin');

db.createUser( 
  { 
    user: "superuser", 
    pwd: "M3ds33K!", 
    roles: [ { role: "userAdminAnyDatabase", db: "admin" } ]
  }
);
  
db.createUser( 
  {
    user: "siteRootAdmin",
    pwd: "M3ds33K!",
    roles: [ { role: "root", db: "admin" } ]
  }
);
	
var db = db.getSiblingDB('predict');

db.createUser( 
  { 
    user: "PredMongoUser", 
    pwd: "M3ds33k!Pred", 
    roles: [ { role: "readWrite", db: "predict" }, { role: "dbAdmin", db: "predict" }]
  }
);
