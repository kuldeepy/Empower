select environment in "production" "staging"; do
   case $environment in
    "production") environ="production"; break;;
    "staging") environ="staging"; break;;
    *) exit 1;;
  esac
done
echo "selected $environment";

ansible redis -i $environ -a "redis-cli -p 6378 eval \"return redis.call('del', unpack(redis.call('keys', 's?:*')))\" 0" 
ansible redis -i $environ -a "redis-cli -p 6378 eval \"return redis.call('del', unpack(redis.call('keys', 'hhl:*')))\" 0" 
ansible redis -i $environ -a "redis-cli -p 6378 eval \"return redis.call('del', unpack(redis.call('keys', 'fl:*')))\" 0" 

ansible redis -i $environ -a "redis-cli -p 6379 eval \"return redis.call('del', unpack(redis.call('keys', 's?:*')))\" 0" 
ansible redis -i $environ -a "redis-cli -p 6379 eval \"return redis.call('del', unpack(redis.call('keys', 'hhl:*')))\" 0" 
ansible redis -i $environ -a "redis-cli -p 6379 eval \"return redis.call('del', unpack(redis.call('keys', 'fl:*')))\" 0" 

ansible redis -i $environ -a "redis-cli -p 6380 eval \"return redis.call('del', unpack(redis.call('keys', 's?:*')))\" 0" 
ansible redis -i $environ -a "redis-cli -p 6380 eval \"return redis.call('del', unpack(redis.call('keys', 'hhl:*')))\" 0" 
ansible redis -i $environ -a "redis-cli -p 6380 eval \"return redis.call('del', unpack(redis.call('keys', 'fl:*')))\" 0" 

ansible redis -i $environ -a "redis-cli -p 6381 eval \"return redis.call('del', unpack(redis.call('keys', 's?:*')))\" 0" 
ansible redis -i $environ -a "redis-cli -p 6381 eval \"return redis.call('del', unpack(redis.call('keys', 'hhl:*')))\" 0" 
ansible redis -i $environ -a "redis-cli -p 6381 eval \"return redis.call('del', unpack(redis.call('keys', 'fl:*')))\" 0" 
