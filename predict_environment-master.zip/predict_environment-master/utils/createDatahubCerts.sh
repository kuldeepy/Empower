keytool -genkey -keyalg RSA -alias datahub -keystore datahub.keystore -noprompt -keypass d@t@hub1! -storepass d@t@hub1! -dname "CN=datahub, OU=Engineering, O=Influence Health"
keytool -export -alias datahub -file datahub.cer -keystore datahub.keystore -storepass d@t@hub1!
keytool -import -v -trustcacerts -alias datahub -file datahub.cer -keystore datahub.truststore -storepass d@t@hub1! -keypass d@t@hub1! -noprompt
keytool -importkeystore -srckeystore datahub.keystore -srcalias datahub -destkeystore datahub.p12.keystore -deststoretype PKCS12 -srcstorepass d@t@hub1! -deststorepass d@t@hub1! -srckeypass d@t@hub1! -destkeypass d@t@hub1!
openssl pkcs12 -in datahub.p12.keystore -out datahub.pem -nodes -password pass:d@t@hub1!
openssl pkcs12 -in datahub.p12.keystore -nocerts -out datahub-key.pem -nodes -password pass:d@t@hub1!