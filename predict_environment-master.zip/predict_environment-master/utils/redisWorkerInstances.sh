ansible redis_master -i production -a "redis-cli -p 6378 RPOP workerInstances"
ansible redis_master -i production -a "redis-cli -p 6378 RPOP workerInstances"
ansible redis_master -i production -a "redis-cli -p 6378 RPOP workerInstances"

ansible redis_master -i production -a "redis-cli -p 6379 RPOP workerInstances"
ansible redis_master -i production -a "redis-cli -p 6379 RPOP workerInstances"
ansible redis_master -i production -a "redis-cli -p 6379 RPOP workerInstances"

ansible redis_master -i production -a "redis-cli -p 6380 RPOP workerInstances"
ansible redis_master -i production -a "redis-cli -p 6380 RPOP workerInstances"
ansible redis_master -i production -a "redis-cli -p 6380 RPOP workerInstances"

ansible redis_master -i production -a "redis-cli -p 6381 RPOP workerInstances"
ansible redis_master -i production -a "redis-cli -p 6381 RPOP workerInstances"
ansible redis_master -i production -a "redis-cli -p 6381 RPOP workerInstances"

ansible redis_master -i production -a "redis-cli -p 6378 LRANGE workerInstances 0 99"
ansible redis_master -i production -a "redis-cli -p 6379 LRANGE workerInstances 0 99"
ansible redis_master -i production -a "redis-cli -p 6380 LRANGE workerInstances 0 99"
ansible redis_master -i production -a "redis-cli -p 6381 LRANGE workerInstances 0 99"

read -rsp $'Press any key to continue...\n' -n1 key

ansible redis_master -i production -a "redis-cli -p 6378 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-01.ecosmart.local'\"','\"'port'\"':6378}"
ansible redis_master -i production -a "redis-cli -p 6378 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-02.ecosmart.local'\"','\"'port'\"':6378}"
ansible redis_master -i production -a "redis-cli -p 6378 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-03.ecosmart.local'\"','\"'port'\"':6378}"

ansible redis_master -i production -a "redis-cli -p 6379 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-01.ecosmart.local'\"','\"'port'\"':6379}"
ansible redis_master -i production -a "redis-cli -p 6379 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-02.ecosmart.local'\"','\"'port'\"':6379}"
ansible redis_master -i production -a "redis-cli -p 6379 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-03.ecosmart.local'\"','\"'port'\"':6379}"

ansible redis_master -i production -a "redis-cli -p 6380 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-01.ecosmart.local'\"','\"'port'\"':6380}"
ansible redis_master -i production -a "redis-cli -p 6380 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-02.ecosmart.local'\"','\"'port'\"':6380}"
ansible redis_master -i production -a "redis-cli -p 6380 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-03.ecosmart.local'\"','\"'port'\"':6380}"

ansible redis_master -i production -a "redis-cli -p 6381 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-01.ecosmart.local'\"','\"'port'\"':6381}"
ansible redis_master -i production -a "redis-cli -p 6381 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-02.ecosmart.local'\"','\"'port'\"':6381}"
ansible redis_master -i production -a "redis-cli -p 6381 LPUSH workerInstances {'\"'host'\"':'\"'az-pred-red-03.ecosmart.local'\"','\"'port'\"':6381}"

ansible redis_master -i production -a "redis-cli -p 6378 LRANGE workerInstances 0 99"
ansible redis_master -i production -a "redis-cli -p 6379 LRANGE workerInstances 0 99"
ansible redis_master -i production -a "redis-cli -p 6380 LRANGE workerInstances 0 99"
ansible redis_master -i production -a "redis-cli -p 6381 LRANGE workerInstances 0 99"
