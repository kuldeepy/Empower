#######################################
# This script installs the New Relic Monitor.
# It also creates the labels, and attempts to enable
# docker monitoring.
#######################################.

#!/bin/bash
# Init
read -p "This script must be ran as root, not sudo!" nothing
# Make sure only root can run our script
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi
# Vars
labelType=""
labelValue=""
#Add the new relic apt repository
echo deb http://apt.newrelic.com/debian/ newrelic non-free >> /etc/apt/sources.list.d/newrelic.list
#trust the new relic GPG key
wget -O- https://download.newrelic.com/548C16BF.gpg | apt-key add -
#update apt-get
apt-get update
#install the server Monitor
apt-get install newrelic-sysmond -y
#configure  the monitor daemon
nrsysmond-config --set license_key=ecbc6fbb96520196144b830ec6ef8b3199874db5
#set the labels in new relic.
echo "Now we need to set the Lable Type and the Label Value. These are used to group servers in New Relic"
echo "Lable Type is normally 'Environment', while Label Value is normally the environment the server is in"
read -e -p "Lable Type: " -i "Environment" labelType
read -e -p "Lable Value: " -i "Staging" labelValue
echo "labels="$labelType":"$labelValue >> /etc/newrelic/nrsysmond.cfg
#ask if this should attempt to configure new relic to monitor docker.
echo "Would you like to have this script attempt to setup docker monitoring?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) usermod -a -G docker newrelic; break;;
        No ) break;;
    esac
done
#ask to start the service
echo "Would you like to have this script start the New Relic Monitor?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) /etc/init.d/newrelic-sysmond start; break;;
        No ) exit;;
    esac
done
