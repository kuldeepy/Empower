select environment in "production" "staging"; do
   case $environment in
    "production") environ="az-pred-mon-01"; break;;
    "staging") environ="az-preds-ela-01"; break;;
    *) exit 1;;
  esac
done
echo "selected $environment";

read -e -p "ES username: " -i "azureuser" esuser
if [ $ES_PASS ]
  then
    espass=$ES_PASS
  else
    read -e -p "ES password: " espass
fi

read -e -p "Num of Days: " -i 30 numofdays
read -e -p "Prefix: " -i ".marvel-2" prefix


curator --host $environ.ecosmart.local --http_auth $esuser:$espass delete indices --timestring '%Y.%m.%d' --prefix "$prefix" --older-than $numofdays --time-unit 'days'
