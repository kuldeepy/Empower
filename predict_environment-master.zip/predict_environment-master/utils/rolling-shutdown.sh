#######################################
# This script selects either a production or staging
# server 1-9 and shuts it down
#
#######################################

user="azureuser"
pass=""
read -e -p "username: " -i "azureuser" user
read -es -p "password: " pass
echo "select staging or production ela server... (Press Enter)";
select environment in "production" "staging"; do
   case $environment in
    "production") server="az-pred-ela-0"; haserver="az-pred-mgo-01"; break;;
    "staging") server="az-preds-ela-0"; haserver="az-preds-mgo-01"; break;;
    *) exit 1;;
  esac
done
echo "selected $environment";


echo "Which ELA server do you want to shut down?"
select servernum in "1" "2" "3" "4" "5" "6" "7" "8" "9" "Enable Allocation" "Disable Allocation" "Exit"; do
    case $servernum in
        [1-9]) echo "setting allocation:none and sending shutdown to ${server}${servernum}.ecosmart.local";
		curl -XPUT $user:$pass@${server}${servernum}.ecosmart.local:9200/_cluster/settings -d '{"transient":{"cluster.routing.allocation.disable_allocation": true}}';
		curl -XPOST $user:$pass@${server}${servernum}.ecosmart.local:9200/_cluster/nodes/_local/_shutdown
	;;
	"Enable Allocation") echo "setting allocation:all";
	    curl -XPUT $user:$pass@${haserver}.ecosmart.local:9200/_cluster/settings -d '{ "transient" : { "cluster.routing.allocation.disable_allocation": false  } }';
	;;
        "Disable Allocation") echo "setting allocation:none";
            curl -XPUT $user:$pass@${haserver}.ecosmart.local:9200/_cluster/settings -d '{ "transient" : { "cluster.routing.allocation.disable_allocation": true  } }';
        ;;
       	*) exit;;
    esac
done
