(function (app) {
  'use strict';
  app.filter('mhrDateFilter', ['$filter', function (filter) {
    return function (date, format) {
      var formatedDate;
      if (date) {
        if (format) {
          switch (format.toLowerCase()) {
            case 'yyyy':
              formatedDate = moment(date).format(format);
              break;
            case 'mm/yyyy':
              formatedDate = moment(date).format(format);
              break;
            case 'mm-yyyy':
              formatedDate = moment(date).format(format);
              break;

            case 'mm/dd/yyyy':
              formatedDate = moment(date).format(format);
              break;
            case 'mm-dd-yyyy':
              formatedDate = moment(date).format(format);
              break;

            case 'mm/dd/yyyy hh:mm':
              formatedDate = moment(date).format('MM/DD/YYYY hh:mm A');
              break;

            case 'mm-dd-yyyy hh:mm':
              formatedDate = moment(date).format('MM/DD/YYYY hh:mm A');
              break;
            default: formatedDate = date;
          }
          return formatedDate;
        } else {
          return date;
        }
      } else { return ''; }
    };
  }]);
}(window.app));
