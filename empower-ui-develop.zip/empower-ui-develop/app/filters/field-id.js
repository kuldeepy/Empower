(function (app) {
  'use strict';
  app.filter('field_id', function () {
    return function (field) {
      if (field) {
        return (field.id) ? field.id : field.name + '_' + field.layout.row + '_' + field.layout.column;
      }
    };
  });
}(window.app));
