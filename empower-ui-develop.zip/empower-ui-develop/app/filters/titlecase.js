(function (app) {
  'use strict';
  app.filter('titlecase', function () {
    return function (s) {
      s = (s === undefined || s === null) ? '' : s;
      return s.toString().replace(/\w\S*/g, function (txt) {
        return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
      });
    };
  });
}(window.app));
