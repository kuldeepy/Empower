(function (app) {
  'use strict';

  app.filter('ssn', ['_', function (_) {
    return function (input) {
      var first = input.substr(0, 3);
      var second = input.substr(3, 2);
      var third = input.substr(5);
      return _.compact([first, second, third]).join('-');
    };
  }]);

}(window.app));
