(function (app) {
  'use strict';

  app.filter('age', function () {
    return function (input) {
      if (!(input instanceof Date) && typeof moment(input)._i !== 'string') {
        return '';
      }
      return moment().diff(input, 'years');
    };
  });

}(window.app));
