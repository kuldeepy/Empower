(function (app) {
  'use strict';

  app.filter('duration', function () {
    return function (input) {
      return moment(input).fromNow(true);
    };
  });

}(window.app));
