(function (app) {
  'use strict';

  app.filter('dob', function () {
    return function (input, format) {
      return moment(input).utc().format(format || 'MM/D/YYYY');
    };
  });

}(window.app));
