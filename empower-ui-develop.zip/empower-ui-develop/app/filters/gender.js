(function (app) {
  'use strict';
  app.filter('gender', [function () {
    return function (input) {
      var parsedInput = parseInt(input);
      if (parsedInput === 2) {
        return 'Male';
      } else if (parsedInput === 3) {
        return 'Female';
      } else {
        return 'Unknown';
      }
    };
  }]);

  app.filter('unique', [function () {
    return function (arr, field) {
      var o = {}, i, r = [];
      if (arr && arr.length > 0) {
        for (i = 0; i < arr.length; i += 1) {
          o[arr[i][field]] = arr[i];
        }
        for (i in o) {
          r.push(o[i]);
        }
        return r;
      }
    };


  }]);

}(window.app));
