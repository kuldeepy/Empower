(function (app) {
  'use strict';

  app.filter('isEmpty', function () {
    return function (obj) {
      for (var item in obj) {
        if (obj.hasOwnProperty(item)) {
          return false;
        }
      }
      return true;
    };
  });
})(window.app);
