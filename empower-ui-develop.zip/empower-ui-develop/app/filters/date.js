(function (app) {
  'use strict';

  app.filter('dateFilter', function () {
    return function (input, format) {
      return moment(input).format(format || 'M/D/YYYY');
    };
  });

}(window.app));
