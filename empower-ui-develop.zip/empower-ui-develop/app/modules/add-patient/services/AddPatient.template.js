(function (app) {
  'use strict';

  app.factory('ConnectPinSvc',
    ['$http', '$q', 'session', 'medseekApi',
      function (http, q, session, medseekApi) {
        return {
          getDeletePharmacy: function () {
            // return "<div ng-include=\"'/modules/Add-patient/templates/deleteRecordsTemplate.html'\"></div>";
            return '<div ng-include="\'/modules/profile/templates/deletePharmacy.html\'"></div>';
          },

          getDeleteLocation: function () {
            // return "<div ng-include=\"'/modules/Add-patient/templates/deleteRecordsTemplate.html'\"></div>";
            return '<div ng-include="\'/modules/profile/templates/deleteLocation.html\'"></div>';
          /* jshint ignore:end */
          },

          getDeletePhysician: function () {
            // return "<div ng-include=\"'/modules/Add-patient/templates/deleteRecordsTemplate.html'\"></div>";
            return '<div ng-include="\'/modules/profile/templates/deletePhysician.html\'"></div>';
          /* jshint ignore:end */
          }

        };

      }]);

}(window.app));
