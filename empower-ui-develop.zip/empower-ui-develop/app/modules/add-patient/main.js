(function (app) {
  'use strict';

  /* module root controller */
  app.controller('addPatientCtrl', ['$scope', function (scope) {
   

    /* init function */
    scope.initialize = function () {
      scope.model = {
        routeParams: {}
      };
    };
    scope.initialize();
  }]);

})(window.app);