(function (app) {
  'use strict';

  /* module root controller */
  app.controller('addPatientWithOutPinMainCtrl', ['$scope', '$timeout', '$location', '$dialogFactory', 'session','$translate', function (scope, timeout, location, dialog, session,translate) {
    scope.model = {
      routeParams: {},
      isShowDialog: false
    };

    scope.stepIndex = 0;
    scope.currentIndex = 0;

    /* init function */
    scope.initialize = function () {};

    this.onControlsAdded = function (sender, control) {
      var setIdx = function () {
        control.setIndex(scope.currentIndex, scope.stepIndex);
      };
      timeout(setIdx, 0);
    };

    this.onCancel = function () {
      if (scope.masterForm.$dirty) {
          var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          scope.masterForm.$setPristine();
          location.path('/');
        });
      } else {
        location.path('/');
      }
    };

    // confirm navigation when form is dirty
    var unregConfirm = scope.$on('$locationChangeStart', function (event) {
      if (sessionName) {
        session.clear(sessionName);
      }
      session.clear('pin');
    });

    scope.$on('msStepFlowControlsAdded', this.onControlsAdded);
    scope.$on('stepFlowOnCancel', this.onCancel);

  }]);

})(window.app);
