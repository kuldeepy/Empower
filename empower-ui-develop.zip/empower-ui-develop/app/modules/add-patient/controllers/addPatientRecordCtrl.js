(function (app) {
  'use strict';

  app.controller('addPatientRecordCtrl', ['$scope', 'medseekApi', 'session', '$q', '$location', '$timeout', 'alertService', 'dynamicText', '$dialogFactory', 'dialogService', 'userPermissionsSvc', '$translate', 'localStorageSvc', 'generic', 'myHealthInformation', function (scope, msApi, session, q, loc, timeout, alertService, dynamicText, dialogFactory, dialogService, userPermissionsSvc, translate, localStorageSvc, generic, myHealthInformation) {
    /* variable declarations */
    scope.error = 'danger';
    scope.route = { path: '/modules/add-patient/views/addPatientRecords.html', name: 'addPatientRecord' };
    scope.steps = this.steps = [];
    scope.patient = JSON.parse(session.get('patient'));
    var userId = session.get('userId');
    scope.clinicalSteps = [translate.instant('HEIGHT_LBL'), translate.instant('WEIGHT_LBL'), translate.instant('SMOKING_PREFERENCE_ADD_PATIENT')];
    scope.searchTypePharmacy = true;
    scope.searchTypeZipcode = false;
    scope.locations = [];
    scope.clinicalInformation = {};
    scope.count = null;
    scope.smoking = 'Yes';
    scope.deleteSelected = {};
    scope.showDeleteButton = false;
    scope.isLinkedPatientWithSame = false;
    scope.isLinkedForPrimaryRecord = false;
    var sessionFactory = session;

    var displayColumn = {
      'allergies': ['name', 'source'],
      'medications': ['name', 'source'],
      'problems': ['name', 'source'],
    };
    var culture = localStorageSvc.get('cultureName') ? (localStorageSvc.get('cultureName') === 'es-MX' ? 'es' : 'en-US') : 'en-US';
    scope.getAllAdminSettingsDynamicTexts = function (culture) {
      var deferred = q.defer();
      msApi.getAllAdminSettingsDynamicTexts.get({ culture: culture }, null).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };
    /* onFocus wizard function */
    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      scope.addPatientRecord = scope;
      if (scope.steps.length === 0) {
        scope.init();
      }

    };

    /* onNext wizard function */
    scope.onNext = function (flowControl) {
      alertService.clear();
      flowControl.next(scope.fc);
    };

    /* onPrevious wizard function */
    scope.onPrevious = function (flowControl) {
      alertService.clear();
      flowControl.previous();
    };

    scope.$on('reload', function () {
      scope.reset();
    });

    scope.reset = function () {
      scope.currentIndex = 0;
      if (scope.stepIndex > 0) {
        scope.stepIndex = 0;
      }
      scope.onPrevious(scope.fc);
    };

    scope.filterDynamicText = function (msgKey, data) {
      var dynamicTextWelcomeMsg = _.where(data.results, function (value, key) { return key === msgKey; });
      if (dynamicTextWelcomeMsg) {
        return dynamicTextWelcomeMsg[0];
      }
      return 'n/a';
    };

    /* init */
    scope.init = function () {
      scope.addPatientRecord.clinicalInformation = {};
      scope.patient = JSON.parse(session.get('patient'));
      if (scope.patient) {
        scope.patientName = scope.patient.patientName;
      }
      scope.getPatientChallengeQuestion();
      scope.getmodulesSettings();
      scope.getMhrModuleSettings();
      scope.getAllAdminSettingsDynamicTexts(culture).then(function (data) {
        scope.challengeQuestionsInstructions = scope.filterDynamicText('Profile_ChallengeQuestionsInstructions', data);
        scope.verifyDemographicsInstructions = scope.filterDynamicText('Enrollment_VerifyDemographics', data);
      });
    };

    scope.getMhrModuleSettings = function () {
      msApi.modules.settings.get({ moduleName: 'Mhr' }).$promise.then(function (response) {
        generic.healthInformationDateFormat = response.results.Retval.HealthInformationDateFormat;
      });
    };

    scope.getMhrAccessLevelPermissions = function (key, patientId, canView) {
      var permissionKey = '';
      if (patientId) {
        if (canView === true || canView) {
          permissionKey = patientId + '.health-information.' + key + '.view';
        } else {
          permissionKey = patientId + '.health-information.' + key + '.manage';
        }
      }
      return permissionKey;
    };

    scope.getDynamicSteps = function () {
      scope.permission = {};
      scope.count = 0;
      var steps = [], isClinicalExist = 0, isMhr = false;
      scope.dynamicSteps = {};
      scope.pinObject = JSON.parse(session.get('pin'));

      if (!scope.pinObject) {
        return;
      }

      _.remove(scope.steps, function (item) { return true; });

      scope.clincicalArray = [{ menu: translate.instant('CHALLENGE_QUESTIONS') }, { menu: translate.instant('VERIFY_DEMOGRAPHICS_INFORMATION_MENU') }];

      if (scope.pinObject.relationShipType && scope.pinObject.relationShipType.toLowerCase() == 'self') {
        scope.clincicalArray = [{ menu: translate.instant('CHALLENGE_QUESTIONS') }, { menu: translate.instant('VERIFY_DEMOGRAPHICS_INFORMATION_MENU') }, { menu: translate.instant('INPUT_CLINICAL_INFORMATION') }, { menu: translate.instant('COMM_MEDICATIONS') }, { menu: translate.instant('ALLERGIES_LBL') }, { menu: translate.instant('CONDITION_LBL') }];
      }

      var isClinicalinfo = false, hasMhrPermissions = false, isClinicalinfo = false, key = '';

      _.forEach(scope.moduleSettings.ClinicalInfoWizardStepsPermissions, function (res) {
        if (scope.pinObject.patientData) {
          hasMhrPermissions = false;
          if (res.StepName.toLowerCase() === 'height' || res.StepName.toLowerCase() === 'weight' || res.StepName === 'Smoking Preference (Social History)') {
            key = 'height-weight-bmi';
            scope.steps;
          } else {
            key = res.StepName;
            if (userPermissionsSvc.userHasPermission(scope.getMhrAccessLevelPermissions(key.toLowerCase(), scope.pinObject.patientData.Id, true))) {
              hasMhrPermissions = true;
            }
            _.remove(scope.clincicalArray, function (item) { return (item.menu == res.StepName && hasMhrPermissions === false); });
          }

          if (res.CanAddRecord) {
            res.CanAddRecord = (userPermissionsSvc.userHasPermission(scope.getMhrAccessLevelPermissions(key.toLowerCase(), scope.pinObject.patientData.Id, false)) || false);
          }
        } else {
          _.remove(scope.clincicalArray, function (item) { return (item.menu == res.StepName && res.CanViewStep === false); });

          if ((res.StepName === 'Height' || res.StepName === 'Weight' || res.StepName === translate.instant('SMOKING_PREFERENCE_ADD_PATIENT')) && res.CanViewStep === true) {
            isClinicalinfo = true;
          }
          _.remove(scope.clincicalArray, function (item) { return (item.menu == translate.instant('INPUT_CLINICAL_INFORMATION') && isClinicalinfo === false); });
        }

        if (res.CanViewStep) {
          scope.permission[res.StepName] = res;
          isMhr = true;
        }
      });

      _.forEach(scope.clincicalArray, function (res) {
        scope.dynamicSteps[res.menu] = scope.count;
        scope.count++;
      });

      if (isMhr) {
        scope.getMhrData();
      }

      if (scope.steps.length === 0) {
        _.forEach(scope.clincicalArray, function (res) {
          scope.steps.push({ menu: res.menu });
        });
      }

    };

    /* get patient challenge questions */
    scope.getmodulesSettings = function () {
      msApi.modules.settings.get({ moduleName: 'enrollment' }).$promise.then(function (response) {
        scope.moduleSettings = response.results.Retval;
        scope.getDynamicSteps();
      });
    };

    scope.getMenu = function (key) {
      return translate.instant(key);
    };

    scope.getDynamicMenuVisibility = function (stepIndex, key, collection) {
      if (collection)
        return stepIndex === collection[translate.instant(key)] ? true : false;
    };
    /* method for get clinical data description */
    scope.getClinicalDataDescription = function (data) {
      var uObject = JSON.parse(sessionFactory.get('userObject')) || {};
      var pObject = JSON.parse(sessionFactory.get('patient')) || {};
      data = data.split('$$UserName$$').join(sessionFactory.get('username'));
      data = data.split('$$PatientName$$').join(JSON.parse(sessionFactory.get('patient')).patientName);
      data = data.split('$$UserFullName$$').join(sessionFactory.get('user'));
      data = data.split('$$UserFirstName$$').join(uObject.firstName);
      data = data.split('$$PatientName$$').join(pObject.patientName);
      data = data.split('$$PatientFirstName$$').join(pObject.patientFirstName);
      return (data);
    };

    scope.getAddDescription = function (key) {
      if (item == undefined) return;
      var item = scope.connectingPatientRecord.clinicalData[key];
      var headerMessage = '';
      var vowelList = ['a', 'e', 'i', 'o', 'u'];
      var res = item.ItemName.toLowerCase().substring(0, 1);
      var artical = (vowelList.indexOf(res) > -1) ? 'an' : 'a';
      headerMessage = translate.instant('HEALTH_INFO_ADD_DESCRIPTION', { artical: artical, ItemName: item.ItemName ? item.ItemName.toLowerCase() : '' });

      return headerMessage;
    };

    scope.getMhrData = function () {
      if (scope.patient && scope.patient.patientId) {
        msApi.patient.clinicalInformation.get({ patientId: scope.patient.patientId, mrn: scope.patient.mrn }).$promise.then(function (response) {
          scope.clinicalData = {};
          var data = response.results.Retval;
          // set the scope data
          data.forEach(function (section) {
            if (section.GridEntity && displayColumn[section.Key.toLowerCase()]) {
              section.GridEntity.Columns.forEach(function (col) {
                col.isShow = (displayColumn[section.Key.toLowerCase()].indexOf(col.DataName) > -1) ? true : false;
              });
            }
            if (section.Description) {
              section.Description = scope.getClinicalDataDescription(section.Description);
            }

            _.forEach(section.Records, function (record) {
              if (record.documents) {
                var documents = JSON.parse(record.documents);
                var clinicalSource = _.max(documents, function (cl) {
                  return cl.id !== '' && parseInt(cl.id);
                });
                record.isclinicaldocument = clinicalSource.isclinicaldocument;
                record.source = (clinicalSource.documentType === 'StructuredClinicalSummary') ? clinicalSource.physician : clinicalSource.location;
              }
            });

            scope.clinicalData[section.Key.toLowerCase()] = section;
          });

          if (scope.clinicalData['weights'].Records && scope.clinicalData['weights'].Records.length > 0) {
            var weight = scope.clinicalData['weights'].Records[(scope.clinicalData['weights'].Records.length - 1)];
            var feet = Math.floor((weight.heightvalue / 12));
            var inches = Math.round(((weight.heightvalue / 12) - feet) * 12);
            scope.clinicalInformation.heightFt = feet;
            scope.clinicalInformation.heightIn = inches;
            scope.clinicalInformation.BMI = weight.bmi;
            scope.clinicalInformation.weight = weight.weightvalue ? weight.weightvalue.replace('lb', '').replace('lbs', '') : '';
          }
        });

        scope.bindDynamicText('Enrollment', 'MedicationsStep');
        scope.bindDynamicText('Enrollment', 'ConditionsStep');
        scope.bindDynamicText('Enrollment', 'AllergiesStep');
      }
    };

    scope.selecetedData = { formData: {} };
    /* load container */
    scope.openMhrAddTemplate = function (key) {
      scope.formEntity = generic.buildFormData(scope.clinicalData[key].FormEntity, key);
      if (scope.formEntity) {
        scope.formEntity.name = '';
      }
      scope.formData = null;
      scope.selectedItem = key;
      dialogService.show('addmhr');
    };

    scope.bindDynamicText = function (moduleName, key) {

      scope.getAllAdminSettingsDynamicTexts(culture).then(function (data) {
        switch (key) {
          case 'MedicationsStep':
            scope.medicationsStepInstructions = scope.filterDynamicText(moduleName + '_' + key, data);
            break;
          case 'ConditionsStep':
            scope.conditionsStepInstructions = scope.filterDynamicText(moduleName + '_' + key, data);
            break;
          case 'AllergiesStep':
            scope.allergiesStepInstructions = scope.filterDynamicText(moduleName + '_' + key, data);
            break;
        }
      });

    };

    scope.deleteMhr = function (key, method, data) {
      scope.addPatientRecord.selectedItem = key;
      scope.addPatientRecord.formData = (data !== undefined) ? data : scope.formData;
      dialogService.show('deletemhr');
    };

    scope.DisputeMhr = function (key, data) {
      var item = scope.addPatientRecord.clinicalData[key];
      scope.addPatientRecord.selectedItem = key;
      scope.addPatientRecord.formData = (data !== undefined) ? data : scope.formData;
      myHealthInformation.currentView = scope.addPatientRecord.formData;
      myHealthInformation.editRecord('.isDispute', scope.addPatientRecord.formData);
      myHealthInformation.controllerData.detailedView = item.DetailFormEntity.Fields;
      myHealthInformation.currentView = myHealthInformation.viewRecord();
      myHealthInformation.data.Key = key;
      dialogService.show('my-heath-information-view');
    };

    /* method for construct JSON data for add, save and delete */
    scope.constructJsonObject = function (selectedData, selectedItem) {
      var jsonData = {};
      var clinicalData = {};

      for (var key in selectedData) {
        var value = selectedData[key];
        if (Object.prototype.toString.call(value) === '[object Date]') {
          var d = new Date(value);
          clinicalData[key] = moment.utc(d).format('YYYY-MM-DDTHH:mm:ss');
        } else {
          clinicalData[key] = value;
        }
      }

      clinicalData.source = 'Patient Entered (' + session.get('user') + ')';
      delete clinicalData.Button;
      jsonData.data = {};
      jsonData.data[selectedItem] = clinicalData;
      return jsonData;
    };

    /* load container */
    scope.saveOrDeleteMhr = function (key, method, data) {
      var item = scope.addPatientRecord.clinicalData[key];
      var message = 'Added';
      scope.formData = (data !== undefined) ? data : scope.formData;
      var jsonData = scope.constructJsonObject(scope.formData, item.DataTypeName);

      if (item.Key == 'problems') {
        item.Key = 'conditions';
      }

      if (method == 'delete') {
        jsonData.isDelete = true;
        message = 'Deleted';
        msApi.healthInformation.deleteSelfEnteredData.update({ patientId: scope.patient.patientId, viewkey: item.Key, mrn: scope.patient.mrn, id: scope.formData.id }, jsonData).$promise.then(function (response) {
          var success = translate.instant('HL_SUCCESSFULLY_DELETED_HEALTH_RECORD', { sectionName: item.ItemName, patientName: scope.patient.patientName });
          alertService.add('success', success, 10000);
          scope.getMhrData();
          scope.cancelMhr();
        }, function () {
          var error = translate.instant('HEALTH_INFO_UNABLE_TO_SAVE_ERROR');
          alertService.add('danger', error, 0, '', 'alert_wizard-step');
        });
      } else {
        var autocompleteField = _.find(scope.formEntity.fields, { name: 'name' });
        if (!autocompleteField.itemSelected) {
          var res = item.ItemName.toLowerCase().substring(0, 1);
          var vowelList = ['a', 'e', 'i', 'o', 'u'];
          var article = (vowelList.indexOf(res) > -1) ? 'an' : 'a';
          var componentName = item.ItemName;
          if (componentName.toLowerCase() === 'problem') {
            componentName = 'Condition';
          }
          alertService.add('danger', translate.instant('HL_SELECT_FROM_SUGGESTED_VALUES', { article: article, sectionName: componentName }), 0, '', 'alert_wizard-step');
          return;
        }

        msApi.healthInformation.postSelfEnteredData.save({ patientId: scope.patient.patientId, viewkey: item.Key, mrn: scope.patient.mrn, specificAction: 'Add' }, jsonData).$promise.then(function (response) {
          var success = translate.instant('HL_SUCCESSFULLY_SAVED_HEALTH_RECORD', { sectionName: item.ItemName, patientName: scope.patient.patientName });
          alertService.add('success', success, 10000);
          scope.getMhrData();
          scope.cancelMhr();
        }, function () {
          var error = translate.instant('HEALTH_INFO_UNABLE_TO_SAVE_ERROR')
          alertService.add('danger', error, 0, '', 'alert_wizard-step');
        });
      }

    };

    /* load container */
    scope.cancelMhrData = function (key) {
      if (scope.masterForm.$dirty) {
        var dialogCallback = dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          scope.masterForm.$setPristine();
          dialogService.hide('addmhr');
        });
      } else {
        scope.masterForm.$setPristine();
        dialogService.hide('addmhr');
      }
    };

    scope.healthInformationNextClick = function (flowControl, stepName) {
      var wizardIndex = _.findIndex(scope.steps, { 'menu': translate.instant(stepName) });
      if (wizardIndex === (scope.steps.length - 1)) {
        flowControl.tabComplete();
      } else {
        flowControl.next();
      }
    };

    /* load container */
    scope.cancelMhr = function (key) {
      scope.formEntity = null;
      scope.formData = null;
      dialogService.hide('addmhr');
      dialogService.hide('deletemhr');
    };

    /* method for clinical information next click */
    scope.clinicalInformationNextClick = function () {
      scope.pinObject = JSON.parse(session.get('pin'));
      scope.pinObject.isClinicalSkip = false;
      session.set('pin', JSON.stringify(scope.pinObject));
      if (!scope.addPatientRecord.permission.Height.CanAddRecord || !scope.addPatientRecord.permission.Weight.CanAddRecord) {
        scope.fc.next();
        return;
      }

      if (!scope.addPatientRecord.clinicalInformation.heightFt && !scope.addPatientRecord.clinicalInformation.heightIn && !scope.addPatientRecord.clinicalInformation.weight) {
        scope.fc.next();
        return;
      }

      scope.saveHeightAndWeight();
    };

    /* method for validate data */
    scope.validateData = function (checkingFromApplyBmiFunc) {
      var error = '';
      var validationFlag = true;

      if (!scope.addPatientRecord.clinicalInformation.heightFt && !scope.addPatientRecord.clinicalInformation.heightIn && !scope.addPatientRecord.clinicalInformation.weight) {
        if (checkingFromApplyBmiFunc === false) {
          error += translate.instant('HEALTH_INFO_ENTER_HEIGHT_WEIGHT_ERROR');
        }
        validationFlag = false;
      } else {
        if (!scope.addPatientRecord.clinicalInformation.heightFt && !scope.addPatientRecord.clinicalInformation.heightIn) {
          if (checkingFromApplyBmiFunc === false) {
            error += translate.instant('HEALTH_INFO_ENTER_HEIGHT_ERROR');
          }
          validationFlag = false;
        }
        else if (!scope.addPatientRecord.clinicalInformation.weight) {
          if (checkingFromApplyBmiFunc === false) {
            error += translate.instant('HEALTH_INFO_ENTER_WEIGHT_ERROR');
          }
          validationFlag = false;
        }
        else if (!scope.addPatientRecord.clinicalInformation.heightFt) {
          if (checkingFromApplyBmiFunc === false) {
            error += translate.instant('HEALTH_INFO_ENTER_FEET_ERROR');
          }
          validationFlag = false;
        }
      }
      alertService.add('danger', error, 0, '', 'alert_wizard-step');
      return validationFlag;
    };

    /* method for make date for post */
    scope.makeDateForPost = function () {
      var data = {};
      data.weight = {
        'height': +(parseInt(scope.addPatientRecord.clinicalInformation.heightFt) * 12) + ((parseInt(scope.addPatientRecord.clinicalInformation.heightIn) || 0) > 0 ? parseInt(scope.addPatientRecord.clinicalInformation.heightIn) : 0),
        'date': moment.utc(new Date()).format('YYYY-MM-DDTHH:mm:ss'),
        'bmi': scope.addPatientRecord.clinicalInformation.BMI,
        'weight': scope.addPatientRecord.clinicalInformation.weight,
        'comments': '',
        'source': translate.instant('PATIENT_ENTERED') + ' (' + session.get('user') + ')'
      };
      return data;
    };

    /* method for apply bmi */
    scope.applyBmi = function () {
      if (scope.addPatientRecord.clinicalInformation.heightFt === 0) {
        scope.addPatientRecord.clinicalInformation.heightFt = undefined;
      }

      if (scope.addPatientRecord.clinicalInformation.weight === 0) {
        scope.addPatientRecord.clinicalInformation.weight = undefined;
      }

      if (scope.validateData(true)) {
        var height = (parseInt(scope.addPatientRecord.clinicalInformation.heightFt) * 12) + ((parseInt(scope.addPatientRecord.clinicalInformation.heightIn) || 0) > 0 ? parseInt(scope.addPatientRecord.clinicalInformation.heightIn) : 0);
        scope.addPatientRecord.clinicalInformation.BMI = Math.round(parseInt(scope.addPatientRecord.clinicalInformation.weight) / (height * height) * 703);
      }
    };

    /* method for save height and weight */
    scope.saveHeightAndWeight = function () {
      var patient = JSON.parse(session.get('patient'));
      var dataForPost = { data: scope.makeDateForPost() };

      msApi.healthInformation.postSelfEnteredData.save({ patientId: scope.patient.patientId, viewkey: 'height-weight-bmi', mrn: scope.patient.mrn, specificAction: 'Add' }, dataForPost).$promise.then(function (response) {
        scope.fc.next();
      }, function (response) {
        scope.controller.error = translate.instant('HEALTH_INFO_UNABLE_TO_SAVE_WEIGHT_ERROR');
        alertService.add('danger', scope.controller.error, 0, '', 'alert_wizard-step');
      });
    };

    scope.clinicalInformationSkipClick = function () {
      scope.pinObject = JSON.parse(session.get('pin'));
      scope.pinObject.isClinicalSkip = true;
      session.set('pin', JSON.stringify(scope.pinObject));
      scope.fc.tabComplete();
      /*scope.addPatientRecord.stepIndex = scope.stepIndex =  _.findIndex(scope.clincicalArray, function(step) { return step.type==='externalInfo' });
      scope.fc.setIndex(scope.currentIndex,scope.stepIndex);*/
    };

    /* get patient challenge questions */
    scope.getPatientChallengeQuestion = function () {
      msApi.modules.settings.get({ moduleName: 'profile' }).$promise.then(function (response) {
        scope.moduleSettings = response.results.Retval;
        scope.profileModuleSettings = response.results.Retval;
        msApi.settings.profileForm.get({ formId: scope.moduleSettings.ConnectWithNewPatientWithPinChallengeQuestionsFormId }).$promise.then(function (response) {
          scope.userChallengeQuestions = response.results.Retval;
          scope.userChallengeQuestions.name = null;
        });

        msApi.settings.profileForm.get({ formId: scope.moduleSettings.ConnectWithNewPatientVerifyDemographicsFormId }).$promise.then(function (response) {
          scope.verifyDemographics = response.results.Retval;
          scope.verifyDemographics.name = null;
        });
      });


      msApi.modules.settings.get({ moduleName: 'enrollment' }).$promise.then(function (response) {
        scope.enrollModuleSettings = response.results.Retval;
      });

    };

    /* method for challenge question last next click */
    scope.challengeQuestionsLastNextClick = function () {
      scope.patient = JSON.parse(session.get('patient'));
      if (scope.patient && scope.patient.patientId) {
        scope.setPatientPermissions('', scope.patient.patientId, undefined, '');
      }
      if (scope.challengeQuestions.$invalid) {
        scope.error = translate.instant('SIGNUP_REQUIRED_INFO_MISSING_ERROR');
        alertService.add('danger', scope.error, 0, '', 'alert_wizard-step');
        return;
      }

      if ($('.ng-invalid-pattern').length > 0) {
        scope.error = translate.instant('CHALLENGE_QUESTIONS_INVALID_ERROR');
        alertService.add('danger', scope.error, 0, '', 'alert_wizard-step');
        return;
      }

      var requestObj = scope.getChallengeBody(scope.dataModel);
      // moment.utc(d).format();
      var challengeQuestionData = { pin: scope.pinObject.pin, responses: requestObj };
      delete challengeQuestionData.responses.data;
      var userId = session.get('userId');
      msApi.validatePinWithChallengeAnswers.save({ userid: userId }, challengeQuestionData).$promise.then(function (response) {
        var status = '';
        var attempts = 0;
        if (response.results.indexOf(',') > 0) {
          var obj = JSON.parse(response.results);

          status = obj.status;
          attempts = obj.attempt;
        } else {
          status = response.results;
        }

        if (status === 'LockedPin' || status === 'ExpiredPin' || status === 'PinAlreadyUsed') {
          dynamicText.getDynamicText('Enrollment', status).then(function (response) {
            alertService.add('danger', response, 0, '', 'alert_wizard-step');
            return;
          });
          return;
        }

        if (status !== 'Success') {
          var error = translate.instant('CONNECT_WITH_PATIENT_ANSWER_DOES_NOT_MATCH_WITH_RECORDS', { x: attempts })
          alertService.add('danger', error, 0, '', 'alert_wizard-step');
          return;
        }

        msApi.user.patients.get({ userid: session.get('userId') }).$promise.then(function (data) {
          scope.getLinkedPatients(data);
          var patients = data.results.Retval;
          scope.patientData = _.filter(patients, function (patient) {
            return (patient.MedicalRecordNumber === scope.pinObject.patient.MedicalRecordNumber);
          })[0];
          scope.pinObject.patientData = scope.patientData;
          scope.pinObject.patientRelationship = scope.patientData.relationship;
          session.set('pin', JSON.stringify(scope.pinObject));
          scope.setSwitchPatient(scope.patientData, '', true);
          scope.refreshLeftMenus();

          timeout(function () {
            userPermissionsSvc.updatePermissions(true).then(function () {
              scope.getDynamicSteps();
              scope.onNext(scope.fc);
            });
          }, 500);

        });
      });

    };

    /* method for display contact staff */
    scope.doesNotKnowChallengeClick = function () {
      var callBack = dialogFactory.create('doesNotKnowChallengeDialog', translate.instant('CHALLENGE_QUESTIONS_DIALOG_NAME'));
      callBack.result.then(function () {
        session.clear('ADDPatient');
        session.clear('pin');
        loc.url('/');
      });
    };

    /* method for incorrect demographic information */
    scope.incorrectDemographicInformation = function () {
      if (scope.enrollModuleSettings.ReportIncorrectDemographics) {
        msApi.settings.profileForm.get({ formId: scope.profileModuleSettings.ConnectWithNewPatientVerifyDemographicsFormId }).$promise.then(function (response) {
          scope.editPatientDemographicsForm = response.results.Retval;
          scope.editPatientDemographicsForm.name = null;
          timeout(function () {
            scope.masterForm.editDemographics.$setPristine();
          }, 500);
          timeout(function () {
            scope.demographicsData = angular.copy(scope.patientData);
          }, 100);
          delete scope.demographicsData.userPermissions;
          var relationField = _.find(scope.editPatientDemographicsForm.fields, { name: 'RelationshipToPatient' });
          angular.forEach(relationField.listItems, function (value, key) {
            if (value == scope.pinObject.patientRelationship) {
              timeout(function () {
                scope.demographicsData.RelationshipToPatient = key;
              }, 10);
            }
          });
        });

        dialogService.show('editDemographics');
      } else {
        var callBack = dialogFactory.create('informationNotCorrectDialog', translate.instant('INFO_NOT_CORRECT'));
      }

    };

    /* method for incorrect demographic information */
    scope.cancelEditDemographics = function (flowControl) {
      if (scope.masterForm.editDemographics.$dirty) {
        var dialogCallback = dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          scope.editPatientDemographicsForm = null;
          scope.demographicsData = null;
          scope.masterForm.editDemographics.$setPristine();
          dialogService.hide('editDemographics');
        });
      } else {
        scope.editPatientDemographicsForm = null;
        scope.demographicsData = null;
        dialogService.hide('editDemographics');
      }
    };

    scope.buildRacesForRequest = function (races) {
      var racesObj = [];
      angular.forEach(races, function (data) {
        racesObj.push({
          'ConceptCode': data.key,
          'Name': null,
          'DisplayName': data.value
        });
      });

      return racesObj;
    };

    scope.buildPatientXMLData = function (requestObject) {
      var xmlData = '<root><data>';
      for (var key in requestObject.patient) {
        if (requestObject.patient[key]) {
          xmlData += '<value key="' + key + '" label="' + key + '">' + requestObject.patient[key] + '</value>';
        } else {
          xmlData += '<value key="' + key + '" label="' + key + '"/>';
        }
      }
      xmlData += '</data></root>';
      return xmlData;
    };

    scope.BuildEditPatientDemographicsRequestObject = function (patient) {
      var requestObject = {};
      requestObject.patient = patient;

      if (patient.Title && patient.Title.id) {
        requestObject.patient.Title = patient.Title.id;
      }
      if (patient.Suffix && patient.Suffix.id) {
        requestObject.patient.Suffix = patient.Suffix.id;
      }
      if (patient.Gender && patient.Gender.id) {
        requestObject.patient.Gender = patient.Gender.id;
      }

      if (patient.Country && patient.Country.id) {
        requestObject.patient.Country = patient.Country.id;
      }

      if (patient.State && patient.State.id) {
        requestObject.patient.State = patient.State.id;
      }
      if (patient.MaritalStatus && patient.MaritalStatus.id) {
        requestObject.patient.MaritalStatus = patient.MaritalStatus.id;
      }

      if (patient.LanguagesKey && patient.LanguagesKey.id) {
        requestObject.patient.PreferredLanguage = patient.LanguagesKey.id;
      }

      if (patient.Ethnicity && patient.Ethnicity.id) {
        requestObject.patient.Ethnicity = patient.Ethnicity.id;
      }

      if (patient.RaceKey) {
        patient.Races = scope.buildRacesForRequest(requestObject.patient.RaceKey);
      }

      if (requestObject.patient.DateOfBirth) {
        requestObject.patient.DateOfBirth = (angular.isDate(requestObject.patient.DateOfBirth)) ?
          requestObject.patient.DateOfBirth.toLocaleDateString() : requestObject.patient.DateOfBirth;
      }

      if (patient.RelationshipToPatient && patient.RelationshipToPatient.id) {
        requestObject.patient.PortalUserRelationships = [];
        requestObject.patient.PortalUserRelationships = [{ RelationshipClassification: patient.RelationshipToPatient.id }];
      }
      requestObject.patient.PatientsXmlData = '';
      requestObject.patient.PatientsXmlData = scope.buildPatientXMLData(requestObject);
      return requestObject;
    };

    /* method for incorrect demographic information */
    scope.updateDemographics = function (flowControl) {
      msApi.profileLookups.get().$promise.then(function (response) {
        scope.lookUps = response.results;
        if (scope.demographicsData.PortalUserRelationships) {
          var relationship = _.find(scope.lookUps, { Name: scope.demographicsData.PortalUserRelationships.RelationshipClassification });
          if (relationship) {
            scope.demographicsData.RelationshipToPatient = { id: relationship.UniqueId };
          }
        }

        var requestObj = scope.BuildEditPatientDemographicsRequestObject(scope.demographicsData);
        msApi.patient_management.patientDemographics.update({ patientId: requestObj.patient.Id }, requestObj).$promise.then(function (response) {
          if (scope.moduleSettings.RequireApprovalForDemographicsUpdate) {
            dynamicText.getDynamicText('profile', 'IncorrectDemographicsReported').then(function (response) {
              alertService.add('success', response);
              dialogService.hide('editDemographics');
            });
          } else {
            timeout(function () {
              msApi.patient.patientById.get({ patientId: scope.patientData.Id }).$promise.then(function (response) {
                response.results.Retval.PortalUserRelationships = response.results.Relationship[0];
                scope.patientData = response.results.Retval;
                scope.pinObject.patientData = scope.patientData;
                session.set('pin', JSON.stringify(scope.pinObject));
                scope.setSwitchPatient(scope.patientData, undefined, true);
              });
              alertService.add('success', translate.instant('PATIENT_MANAGEMENT_UPDATED_PROFILE_DEMOGRAPHICS_SUCCESS_MSG'));
              dialogService.hide('editDemographics');
            }, 500);
          }

        }, function (error) {
          alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SAVE_PROFILE_COMPONENT_ERROR'), 0, '', 'alert_wizard-step');
        });

      });
    };

    scope.$on('CountryChanged', function (event, item) {
      var stateField = _.find(scope.editPatientDemographicsForm.fields, { name: 'State' });
      stateField.filters.href = 'empower/countries/' + item.id + '/states';
      scope.dataModel.ZipCode = '.';
      setTimeout(function () {
        scope.dataModel.ZipCode = '';
      });
    });

    scope.verifyDemographic = function (flowControl) {
      scope.patient = JSON.parse(session.get('patient'));
      if (scope.patient && scope.patient.patientId) {
        scope.setPatientPermissions('', scope.patient.patientId, undefined, '');
      }
      // userPermissionsSvc.updatePermissions(true);
      // timeout(function () {
      var wizardIndex = _.findIndex(scope.steps, { 'menu': translate.instant('VERIFY_DEMOGRAPHICS_INFORMATION_MENU') });
      if (wizardIndex === (scope.steps.length - 1)) {
        flowControl.tabComplete();
      } else {
        scope.getMhrData();
        flowControl.next();
      }
      // }, 10000);
    };

    scope.getChallengeBody = function (model) {
      var res = {};
      if (model.RelationshipType && model.RelationshipType.id) {
        res.RelationshipType = model.RelationshipType.name;
      }
      if (model.FirstName) {
        res.FirstName = model.FirstName;
      }
      if (model.LastName) {
        res.LastName = model.LastName;
      }

      if (model.MiddleName) {
        res.MiddleInitial = model.MiddleName;
      }

      if (model.StateId && model.StateId.id) {
        res.State = model.StateId.id;
      }
      if (model.CountryId && model.CountryId.id) {
        res.Country = model.CountryId.id;
      }
      if (model.City) {
        res.City = model.City;
      }

      if (model.ZipCode) {
        res.Zip = model.ZipCode;
      }

      if (model.DateOfBirth) {
        res.DateOfBirth = moment(model.DateOfBirth).format('YYYY-MM-DD');
      }

      if (model.GenderId && model.GenderId.id) {
        res.Gender = model.GenderId.id;
      }
      if (model.EmailAddress) {
        res.Email = model.EmailAddress;
      }

      if (model.SocialSecurityNumber) {
        res.SocialSecurityNumber = model.SocialSecurityNumber;
      }

      if (model.DaytimePhone) {
        res.PhoneNumber = model.DaytimePhone;
      }

      if (model.HealthcareNumber) {
        res.HealthcareNumber = model.HealthcareNumber;
      }
      if (model.MedicalRecordNumber) {
        res.MedicalRecordNumber = model.MedicalRecordNumber;
      }
      return res;
    };

    scope.close = function (form) {
      if (form.$dirty) {
        var confirmDialog = dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        confirmDialog.result.then(function () {
          myHealthInformation.controllerData.dataModel = {};
          $('.my-heath-information-view').modal(generic.closePopupModalClassName);
          myHealthInformation.clearErrorMessage();
          form.$setPristine();
        });
        return;
      }

      $('.my-heath-information-view').modal(generic.closePopupModalClassName);
      myHealthInformation.clearErrorMessage();
    };

  }]);

}(window.app));
