(function (app) {
  'use strict';

  app.controller('addPatientWithOutPinCtrl', ['$scope', 'medseekApi', 'session', '$q', '$location', '$timeout', 'alertService', 'dynamicText','$translate', function (scope, api, session, q, loc, timeout, alertService, dynamicText,translate) {
    /* variable declarations */
    scope.error = 'danger';
    scope.route = { path: '/modules/add-patient/views/addPatientWithOutPin.html', name: 'addPatientWithOutPin' };
    scope.steps = this.steps = [{ menu: translate.instant('ENTER_PATIENT_INFORMATION_MENU') }];
    scope.addPatient = {};
    scope.formEntity = { patientAddForm: [] };
    scope.countryCodeForCanada = 103;

    /* onFocus wizard function */
    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      scope.init();
    };

    /* onNext wizard function */
    scope.onNext = function (flowControl) {
      alertService.clear();
      scope.fc = flowControl;
      switch (scope.stepIndex) {
        case 0:
          flowControl.next();
          flowControl.showNext(false);
          flowControl.showPrevious(false);
          flowControl.showCancel(false);
          break;
        case 1:
          flowControl.tabComplete();
          break;
      }
    };

    /* onPrevious wizard function */
    scope.onPrevious = function (flowControl) {
      switch (scope.stepIndex) {
        case 1:
          flowControl.showPrevious(false);
          flowControl.showNext(true);
          flowControl.enableNext(true);
          flowControl.showCancel(true);
          flowControl.previous();
          break;
      }
    };

    scope.$on('reload', function () {
      scope.reset();
    });

    scope.reset = function () {
      scope.currentIndex = 0;
      scope.isSearch = false;
      scope.selectedPharmacy = undefined;
      if (scope.stepIndex > 0) {
        scope.stepIndex = 0;
      }
      scope.onPrevious(scope.fc);
    };

    scope.constructObject = function (patient) {
      var relationShip = '';
      // addPatientWithOutPin.dataModel
      angular.forEach(scope.formEntity.patientAddForm.fields, function (field) {
        if (field.model && field.model.indexOf('RelationshipClassification') > -1) {
          relationShip = field.listItems[patient.RelationshipClassification];
        }
      });

      var obj = { patientEntity: angular.copy(patient) };
      obj.patientEntity.PortalUserRelationships = [
        {
          'IsCurrentContext': false,
          'PortalUserId': session.get('userId'),
          'PatientFirstName': patient.FirstName,
          'PatientLastName': patient.LastName,
          'PatientMiddleName': patient.MiddleName,
          'ProfilePatientId': 0,
          'RelationshipClassification': patient.RelationshipToPatient.name ? patient.RelationshipToPatient.name : relationShip,
          'CustodianLevel': {}
        }
      ];
      if (obj.patientEntity.Country && obj.patientEntity.Country.id) {
        obj.patientEntity.Country = obj.patientEntity.Country.id;
      }

      if (obj.patientEntity.State && obj.patientEntity.State.id) {
        obj.patientEntity.State = obj.patientEntity.State.id;
      }

      if (obj.patientEntity.Gender && obj.patientEntity.Gender.id) {
        obj.patientEntity.Gender = obj.patientEntity.Gender.id;
      }

      if (obj.patientEntity.RelationshipToPatient && obj.patientEntity.RelationshipToPatient.id) {
        obj.patientEntity.RelationshipToPatient = obj.patientEntity.RelationshipToPatient.id;
      }

      if (patient.Races && patient.Races.length > 0) {
        obj.patientEntity.Races = [];
        angular.forEach(patient.Races, function (race) {
          obj.patientEntity.Races.push({
            ConceptCode: race.key,
            DisplayName: race.value
          });
        });
      }
      return obj;
    };

    scope.createPatient = function (flowControl, form) {
      if (!form.$valid) {
        alertService.add('error', translate.instant('PLEASE_PROVIDE_VALID_DATA'));
        return;
      }
      var req = scope.constructObject(scope.dataModel);
      if (scope.connectWithNewPatientWithoutPinInstructions) {
        var instructions = angular.copy(scope.connectWithNewPatientWithoutPinInstructions);
        scope.connectWithNewPatientWithoutPinInstructions = scope.replaceTokens(instructions, req.patientEntity);
      }

      api.patient.save(null, req).$promise.then(function (response) {
        flowControl.next();
      }, function (response) {});
    };

    scope.getConnectWithNewPatientWithoutPinInstructionsDynamicText = function () {
      api.getDynamicTexts.get({ moduleName: 'profile', key: 'ConnectWithNewPatientWithoutPinApprovalMessage' }).$promise.then(function (instructions) {
        scope.connectWithNewPatientWithoutPinInstructions = instructions.results.Retval;

      });
    }

    scope.replaceTokens = function (instructions, patient) {
      if (instructions) {
        scope.user = JSON.parse(session.get('userObject')) || {};
        var patientMiddleName = patient.MiddleName ? patient.MiddleName : '';
        instructions = instructions.split('$$StaffFirstName$$').join('');
        instructions = instructions.split('$$UserFirstName$$').join(scope.user.firstName);
        instructions = instructions.split('$$PatientFirstName$$').join(patient.FirstName);
        instructions = instructions.split('$$UserName$$').join((scope.user.firstName || scope.user.lastName) ? (scope.user.firstName + ' ' + scope.user.lastName) : '');
        instructions = instructions.split('$$PatientName$$').join(patient.FirstName + ' ' + patientMiddleName + ' ' + patient.LastName);
      }
      return instructions;
    }


    /* init */
    scope.init = function () {
      api.modules.settings.get({ moduleName: 'profile' }).$promise.then(function (response) {
        scope.moduleSettings = response.results.Retval;

        scope.getConnectWithNewPatientWithoutPinInstructionsDynamicText();

        api.settings.profileForm.get({ formId: scope.moduleSettings.ConnectWithNewPatientWithoutPinFormId }).$promise.then(function (response) {
          var formEntity = response.results.Retval;
          formEntity.name = null;

          api.user.patients.get({ userid: session.get('userId') }).$promise.then(function (data) {
            var patientData = _.filter(data.results.Retval, function (patient) { return (patient.PortalUserRelationships && patient.PortalUserRelationships.RelationshipClassification == 'Self'); });
            if (patientData.length > 0) {
              var relationField = _.find(formEntity.fields, { name: 'RelationshipToPatient' });
              angular.forEach(relationField.listItems, function (value, key) {
                if (value == 'Self') {
                  delete relationField.listItems[key];
                }

              });
            }
            scope.formEntity.patientAddForm = formEntity;

          });
        });
      });

    };

    /*map phone numbers*/
    scope.getPhoneNumber = function (phoneNumbers) {
      angular.forEach(phoneNumbers , function (phone) {
        if (phone.PhoneType && phone.PhoneNumber) {
          if (phone.PhoneType.toString() === '4001') {
            scope.dataModel.EveningPhone = phone.PhoneNumber;
            scope.dataModel.EveningPhoneExt = phone.Extension;
          }
          else if (phone.PhoneType.toString() === '4002') {
            scope.dataModel.DaytimePhone = phone.PhoneNumber;
            scope.dataModel.DaytimePhoneExt = phone.Extension;
          }
          else if (phone.PhoneType.toString() === '4003') {
            scope.dataModel.MobilePhone = phone.PhoneNumber;
          }
        }
      });
    };

    var RelationshipToPatient = {};
    /*Copy Account holder info*/
    var populateUserDemographics = function () {
      api.users.profile.get({ userId: session.get('userId') }).$promise.then(function (response) {
        scope.userDetails = response.results;
        scope.dataModel = {};
        scope.dataModel = scope.userDetails;
        scope.dataModel.DateOfBirth = scope.userDetails.DateOfBirth ? new Date(scope.userDetails.DateOfBirth) : null;
        scope.dataModel.RelationshipToPatient = RelationshipToPatient;
        if (scope.userDetails.Addresses.length > 0) {
          scope.dataModel.Address1 = scope.userDetails.Addresses[0].AddressLine1;
          scope.dataModel.Address2 = scope.userDetails.Addresses[0].AddressLine2;
          scope.dataModel.City = scope.userDetails.Addresses[0].City;
          scope.dataModel.State = scope.userDetails.Addresses[0].State;
          scope.dataModel.Country = scope.userDetails.Addresses[0].Country;
          scope.dataModel.ZipCode = scope.userDetails.Addresses[0].ZipCode;
          if (scope.dataModel.Country && (scope.dataModel.Country.toString() === scope.countryCodeForCanada.toString())) {
            var stateField = _.find(scope.formEntity.patientAddForm.fields, { name: 'State' });
            stateField.filters.href = 'empower/countries/' + scope.dataModel.Country + '/states';
            timeout(function () {
              scope.dataModel.State = scope.userDetails.Addresses[0].State;
            }, 1000);
          }
          var zipField = _.find(scope.formEntity.patientAddForm.fields, { name: 'ZipCode' });
          zipField.filters.href = scope.dataModel.Country;

        }
        if (scope.userDetails.PhoneNumbers.length > 0) {
          scope.getPhoneNumber(scope.userDetails.PhoneNumbers);
        }

      });
    };

    scope.$on('RelationshipToPatientChanged', function (event, item) {
      if (item.name === 'Self') {
        RelationshipToPatient = item;
        populateUserDemographics();
      }
    });

    scope.$on('CountryChanged', function (event, item) {
      var stateField = _.find(scope.formEntity.patientAddForm.fields, { name: 'State' });
      stateField.filters.href = 'empower/countries/' + item.id + '/states';
      scope.dataModel.ZipCode = '.';
      setTimeout(function () {
        scope.dataModel.ZipCode = '';
      });
    });

  }]);

}(window.app));
