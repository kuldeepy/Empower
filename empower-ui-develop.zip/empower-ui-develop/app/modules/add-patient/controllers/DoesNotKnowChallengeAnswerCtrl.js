(function (app) {
  'use strict';

  app.controller('DoesNotKnowChallengeAnswerCtrl',
    ['$scope', '$modalInstance', 'header', 'medseekApi', '$q', 'alertService', 'dynamicText', '$timeout', 'session', '$location', '$translate',
      function (scope, modal, header, api, q, alertService, dynamicText, timeout, session, location, translate) {
        scope.header = header;
        scope.nonConfigurableMessage = {
          enrollmentMessage: ''
        };

        /*method to display dynamic text*/
        scope.displayDynamicText = function (keyName) {
          dynamicText.getDynamicText('Enrollment', keyName).then(function (response) {
            scope.nonConfigurableMessage.enrollmentMessage = response;
          });
        };

        scope.tryAgainClick = function () {
          modal.dismiss();
        };

        scope.contactStaffClick = function () {
          if (location.path().indexOf('add-patient') > -1) {
            modal.close();
            location.path('/');
          } else {
            var message = translate.instant('ACCOUNT_CREATED_AND_NOT_LINKED_TO_PATIENT', { patient: JSON.parse(session.get('pin')).patient.FirstName.toString() });
            alertService.add('success', message, 10000);
            timeout(function () {
              modal.close();
            }, 10000);
          }
        };

        alertService.clear();
        scope.displayDynamicText('DoesNotknowAnswerToChallengeQuestion');

      }]);

}(window.app));
