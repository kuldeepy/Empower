(function (app) {
  'use strict';
  // session module controllers are required
  app.require('modules/profile');
  app.controller('completePatientProfileCtrl', ['$scope', 'medseekApi', 'api', 'session', '$q', '$location', '$timeout', 'alertService', 'dynamicText', 'dialogService', 'profileService', 'ConnectPinSvc', 'patientProfileService', '$dialogFactory', 'GetDialogTemplate', 'userPermissionsSvc', '$modal', '$translate', function (scope, msApi, api, session, q, loc, timeout, alertService, dynamicText, diag, profileSvc, cSvc, pSvc, dialogFactory, GetDialogTemplate, userPermissionsSvc, modal, translate) {
    /* variable declarations */
    scope.error = 'danger';
    scope.route = { path: '/modules/add-patient/views/completePatientProfile.html', name: 'copmleteProfile' };
    scope.steps = this.steps = [];
    scope.patient = JSON.parse(session.get('patient'));
    var userId = session.get('userId');
    scope.searchTypePharmacy = true;
    scope.searchTypeZipcode = false;
    scope.locations = [];
    scope.count = null;

    scope.deleteSelected = {};
    scope.showDeleteButton = false;
    scope.isLinkedPatientWithSame = false;
    scope.isLinkedForPrimaryRecord = false;

    scope.setDynamicStepVisibility = function (stepIndex, key, collection) {
      if (collection)
        return stepIndex === collection[translate.instant(key)] ? true : false;
    };
    /* onFocus wizard function */
    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      scope.copmleteProfile = scope;
      scope.getAllstepData();
    };

    /* onNext wizard function */
    scope.onNext = function (flowControl) {
      flowControl.next();
    };

    /* onPrevious wizard function */
    scope.onPrevious = function (flowControl) {
      flowControl.previous();
    };

    /* onPrevious wizard function */
    scope.rediretToHomePage = function (url) {
      scope.patient = JSON.parse(session.get('patient'));
      if (scope.patient && url === '/view-edit-profile') {
        if (!userPermissionsSvc.userHasPermission(scope.patient.patientId + '.patient-management')) {
          url = '/';
        }
      }
      scope.setSwitchPatientConnect('', scope.patient.patientId, undefined, url);
      session.clear('ADDPatient');
      session.clear('pin');
    };

    scope.$on('reload', function () {
      scope.reset();
    });

    scope.reset = function () {
      scope.currentIndex = 0;
      scope.isSearch = false;
      scope.selectedPharmacy = undefined;
      if (scope.stepIndex > 0) {
        scope.stepIndex = 0;
      }
      scope.onPrevious(scope.fc);
    };

    scope.selecetedData = { formData: {} };

    /* get patient challenge questions */
    scope.getmodulesSettings = function () {
      msApi.modules.settings.get({ moduleName: 'enrollment' }).$promise.then(function (response) {
        scope.moduleSettings = response.results.Retval;
        scope.permission = {};
        scope.count = 0;
        var steps = [];
        scope.dynamicSteps = {};
        scope.pinObject = JSON.parse(session.get('pin'));
        var hasMhrPermissions = false;

        scope.clincicalArray = [{ menu: translate.instant('PHYSICIANS_LBL') }, { menu: translate.instant('LOCATIONS_LBL') }, { menu: translate.instant('PHARMACIES_LBL') }];

        _.forEach(scope.moduleSettings.ExternalSourcesWizardStepsPermissions, function (res) {
          hasMhrPermissions = false;
          if (userPermissionsSvc.userHasPermission(scope.getPatientManagementAccessLevelPermissions(res.StepName.toLowerCase(), scope.patient.patientId, true))) {
            hasMhrPermissions = true;
          }
          _.remove(scope.clincicalArray, function (item) { return (hasMhrPermissions === false && item.menu == res.StepName || res.CanViewStep === false); });

          if (res.CanAddRecord) {
            res.CanAddRecord = (userPermissionsSvc.userHasPermission(scope.getPatientManagementAccessLevelPermissions(res.StepName.toLowerCase(), scope.patient.patientId, false)) || false);
          }
          scope.permission[res.StepName] = res;
        });
        _.forEach(scope.moduleSettings.ClinicalInfoWizardStepsPermissions, function (res) {
          if (res.CanAddRecord) {
            res.CanAddRecord = (userPermissionsSvc.userHasPermission(scope.getPatientManagementAccessLevelPermissions(res.StepName.toLowerCase(), scope.patient.patientId, false)) || false);
          }
          scope.permission[res.StepName] = res;
        });
        _.forEach(scope.clincicalArray, function (res) {
          scope.dynamicSteps[res.menu] = scope.count;
          scope.count++;
        });

        if (scope.steps.length === 0) {
          _.forEach(scope.clincicalArray, function (res) {
            scope.steps.push({ menu: res.menu });
          });
        }
      });
    };

    scope.externalPreviousClick = function (stepName) {
      scope.pinObject = JSON.parse(session.get('pin'));
      if (scope.pinObject.isClinicalSkip) {
        var index = _.findIndex(scope.clincicalArray, function (step) { return step.menu === stepName; });
        if (index === 0) {
          scope.fc.setIndex(1, 2);
          return;
        }
      }
      scope.fc.previous();
    };

    /* init */
    scope.getAllstepData = function () {
      scope.getmodulesSettings();
      scope.copmleteProfile.clinicalInformation = {};
      scope.patient = JSON.parse(session.get('patient'));

      dynamicText.getDynamicText('profile', 'LocationsTabInstructions').then(function (response) {
        scope.InstructionalTextLocationsTab = response;
      });
      dynamicText.getDynamicText('profile', 'PharmaciesTabInstructions').then(function (response) {
        scope.InstructionalTextPharmaciesTab = response;
      });
      dynamicText.getDynamicText('profile', 'PhysiciansTabInstructions').then(function (response) {
        scope.InstructionalTextPhysiciansTab = response;
      });

      if (scope.patient) {
        scope.patientName = scope.patient.patientName;
        userPermissionsSvc.updatePermissions(true).then(function () {
          timeout(function () {
            if (userPermissionsSvc.userHasPermission(scope.getPatientManagementAccessLevelPermissions('pharmacies', scope.patient.patientId))) {
              scope.getPatientPharmacy();
            }
            if (userPermissionsSvc.userHasPermission(scope.getPatientManagementAccessLevelPermissions('locations', scope.patient.patientId))) {
              scope.getPatientLocations();
            }
            if (userPermissionsSvc.userHasPermission(scope.getPatientManagementAccessLevelPermissions('physicians', scope.patient.patientId))) {
              scope.getPatientPhysicians();
            }
          }, 500);
        });

      }
    };

    /* get patient pharmacy */
    scope.getPatientPharmacy = function () {
      scope.patient = JSON.parse(session.get('patient'));
      profileSvc.pharmacy.getPharmacy({ patientId: scope.patient.patientId }).then(function (response) {
        scope.copmleteProfile.pharmacies = response;
        var primaryPharmacies = _.find(scope.copmleteProfile.pharmacies, { IsDefault: true });
        if (primaryPharmacies === undefined || primaryPharmacies === null) {
          scope.updateIsPrimaryRecord('pharmacies', _.first(scope.copmleteProfile.pharmacies));
        }
        alertService.clear();
      }, function (error) {
        alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_GET_PHARMACIES'), 0, '', 'alert_wizard-step');
      });
    };

    /* get patient locations */
    scope.getPatientLocations = function () {
      scope.patient = JSON.parse(session.get('patient'));
      profileSvc.getPatientLocations(scope.patient.patientId).then(function (result) {
        scope.copmleteProfile.locations = result.Retval;
        var primaryLocations = _.find(scope.copmleteProfile.locations, { IsDefault: true });
        if (primaryLocations === undefined || primaryLocations === null) {
          scope.updateIsPrimaryRecord('locations', _.first(scope.copmleteProfile.locations));
        }
        alertService.clear();
      }, function (error) {
        alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_GET_PATIENT_LOCATIONS'), 0, '', 'alert_wizard-step');
      });
    };

    /* get profile physician records */
    scope.getPatientPhysicians = function (currentAddedPhysician, currentProfilePhyID, successMessage) {
      alertService.clear();
      scope.patient = JSON.parse(session.get('patient'));
      if (successMessage) {
        successMessage = translate.instant('PATIENT_MANAGEMENT_PHYSICIAN_SAVED_TO_PROFILE', { patientName: scope.patient.patientName });
        alertService.add('success', successMessage);
      }
      
      profileSvc.getPatientPhysicians(scope.patient.patientId).then(function (result) {
        scope.copmleteProfile.physicians = result.Retval;
        var primaryPhisicians = _.find(scope.copmleteProfile.physicians, { IsPrimary: true });
        if (primaryPhisicians === undefined || primaryPhisicians === null) {
          scope.updateIsPrimaryRecord('physicians', _.first(scope.copmleteProfile.physicians));
        }
        alertService.clear();
      }, function (error) {
        alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_GET_PATIENT_PHYSICIANS'), 0, '', 'alert_wizard-step');
      });
    };

    /*
    *Updates an entity to primary
    */
    scope.updateIsPrimaryRecord = function (type, entity) {
      if (!entity) {
        return;
      }
      var patient = scope.patient = scope.currentPatient = JSON.parse(session.get('patient'));
      switch (type) {
        case 'physicians':
          msApi.patients.primaryPhysician.update({ patientId: patient.patientId, physicianId: entity.Id }, null).$promise.then(function (primaryResponse) {
            scope.getPatientPhysicians(undefined, undefined, undefined);
          });
          break;
        case 'locations':
          msApi.patient_management.locations.save({ patientId: patient.patientId }, { isDefault: true, locationId: entity.LocationId, isCopy: false }).$promise.then(function (response) {
            scope.getPatientLocations();
          }, function (error) { });
          break;
        case 'pharmacies':
          msApi.patient_management.pharmacies.save({ patientId: patient.patientId }, { isCopy: false, isDefault: true, pharmacyId: entity.Id }).$promise.then(function (response) {
            scope.getPatientPharmacy();
          }, function (error) { });
          break;
        default:
          break;
      }

    };
    /*
    *Set selected physicain to primary
    */
    scope.physicianchoosePrimary = function (physician) {
      _.forEach(scope.copmleteProfile.physicians, function (item) {
        if (item.Id !== physician.Id) {
          item.IsPrimary = false; // reset everything else to false
        }
      });
      scope.updateIsPrimaryRecord('physicians', physician);
    };
    /*
    *Set selected location to primary
    */
    scope.locationchoosePrimary = function (location) {
      if (!location.IsDefault) { // update only if primary is to be set
        _.forEach(scope.copmleteProfile.locations, function (item) {
          if (item.LocationId !== location.LocationId) {
            item.IsDefault = false; // reset everything else to false
          }
        });
        scope.updateIsPrimaryRecord('locations', location);
      }
    };

    /*
    *Set selected pharmacy to primary
    */
    scope.pharmacieschoosePrimary = function (pharmacy) {
      if (!pharmacy.IsDefault) { // update only if primary is to be set
        _.forEach(scope.copmleteProfile.pharmacies, function (item) {
          if (item.Id !== pharmacy.Id) {
            item.IsDefault = false; // reset everything else to false
          }
        });
        scope.updateIsPrimaryRecord('pharmacies', pharmacy);
      }
    };

    scope.acceptPin = function (flowControl) {
      flowControl.tabComplete();
    };

    /* open dialog */
    scope.open = function (data, container, headerText, type, mode) {
      headerText = translate.instant(headerText);
      scope.loadContainer(data, container, headerText, type, mode);
    };

    /* load container */
    scope.loadContainer = function (data, container, headerText, type, mode) {
      var template = '';

      if (container == 'addLocations') {
        template = app.root + 'modules/signup/templates/addLocations.html';
      }
      else if (container == 'addPhysician') {
        template = app.root + 'modules/signup/templates/addPhysician.html';
      }
      else if (container == 'addPharmacy1') {
        template = app.root + 'modules/signup/templates/addPharmacy.html';
      }
      if (template != '') {
        scope.lookupModal = modal.open({
          templateUrl: template,
          scope: scope,
          backdrop: 'static',
          keyboard: false
        });
      }
    };

    var getTemplateContent = new GetDialogTemplate(diag);

    scope.closePopups = function (form) {
      if (form && form.$dirty) {
        var dialogCallback = dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          form.$setPristine();
          scope.lookupModal.close();
        });
      } else {
        scope.lookupModal.close();
      }
    };

    /* close dialog */
    scope.closeDialog = function (container) {
      scope.isLinkedForPrimaryRecord = false;
      getTemplateContent.closeDialog(container);
      scope.closePopups();
    };

    /* get content based on the type */
    scope.getContent = function (data, type, mode) {
      var content = '';

      switch (type) {
        case 'Pharmacy':
          content = cSvc.getDeletePharmacy();
          break;

        case 'Physician':
          content = cSvc.getDeletePhysician();
          break;

        case 'Location':
          content = cSvc.getDeleteLocation();
          break;
      }

      return content;
    };

    /* is linked patient for primary records */
    scope.isLinkedPatientForIsPrimary = function () {
      scope.isLinkedForPrimaryRecord = true;
    };

    /* update as primary */
    scope.updateIsPrimary = function (data, type) {
      angular.forEach(scope.deleteCollection, function (item) {
        item.IsDefault = false;
        if (data.Id === item.Id) {
          item.IsDefault = true;
        }
      });
    };

    /* show delete container */
    scope.isDelete = function (data, container, headerText, type, mode, collection) {
      headerText = translate.instant(headerText);
      scope.patient = JSON.parse(session.get('patient'));
      scope.patient.demographics = { FirstName: scope.patient.patientFirstName };
      scope.deleteCollection = [];
      scope.deleteSelected = data;
      angular.copy(collection, scope.deleteCollection);
      scope.patient.deleteCollection = [];

      angular.forEach(scope.deleteCollection, function (item) {
        if (typeof data.IsDefault === 'undefined') {
          if (!(data.IsPrimary === item.IsPrimary && item.IsPrimary === true && item.Id === data.Id)) {
            scope.patient.deleteCollection.push(item);
          }
        } else {
          if (!(data.IsDefault === item.IsDefault && item.IsDefault === true && item.Id === data.Id)) {
            scope.patient.deleteCollection.push(item);
          }
        }
      });

      scope.isLinkedRecord(type);
      if (scope.patient.deleteCollection.length > 0) {
        scope.patient.deleteCollection[0].IsDefault = true;
      }

      scope.content = getTemplateContent.getTemplateWithoutClose(container, headerText, scope.getContent(data, type, mode), '');
      timeout(function () {
        getTemplateContent.showDialog(container);
      }, 500);

    };

    /* check whether the patient's data is linked to other patient's data */
    scope.isLinkedRecord = function (type) {
      /* jshint ignore:start */
      var currentPatient = scope.deleteSelected;
      scope.isLinkedPatientWithSame = false;
      scope.linkedPhysiciansMatched = {};

      api.patients.get({ userid: userId }).then(function (response) {
        var linkedPatients = response.results.Retval;

        for (var index = 0; index < linkedPatients.length; index++) {
          var linkedPatient = linkedPatients[index];
          if (linkedPatient.Id !== scope.patient.patientId) {
            var dataObject = {};
            dataObject = { patientId: linkedPatient.Id };

            pSvc.getEntity(dataObject, type).then(function (responseItem) {
              var isExists = _.filter(responseItem, function (item) {
                if (type === 'Physician') {
                  var retval = (item.FirstName === scope.deleteSelected.FirstName && item.MiddleName === scope.deleteSelected.MiddleName && item.LastName === scope.deleteSelected.LastName) ?
                    scope.linkedPhysiciansMatched[item.PatientId] = item : null;
                  return retval !== null;
                }
                return (item.Id === scope.deleteSelected.Id);
              });

              if (isExists.length > 0) {
                scope.isLinkedPatientWithSame = true;
              }
            });
          } else {
            if (type === 'Physician') {
              scope.linkedPhysiciansMatched[linkedPatient.Id] = scope.deleteSelected;
            }
          }
        }
      });
      /* jshint ignore:end */
    };
    scope.getDataForBind = function (type) {
      if (type === 'Pharmacy') {
        scope.getPatientPharmacy();
      }
      if (type === 'Physician') {
        scope.getPatientPhysicians();
      }
      if (type === 'Location') {
        scope.getPatientLocations();
      }
    };

    /* delete */
    scope.delete = function (type, container) {
      var deleteObject = {};
      var saveObject = {};
      if (type === 'Pharmacy') {
        deleteObject = { patientId: scope.patient.patientId, pharmacyId: scope.deleteSelected.Id };
      }
      if (type === 'Physician') {
        deleteObject = { patientId: scope.patient.patientId, physicianId: scope.deleteSelected.Id };
      }
      if (type === 'Location') {
        deleteObject = { patientId: scope.patient.patientId, locationId: scope.deleteSelected.Id };
      }

      if (scope.isLinkedPatientWithSame === false) {
        pSvc.deleteEntity(deleteObject, type).then(function (response) {
          alertService.add('success', 'You have successfully deleted ' + scope.patient.demographics.FirstName + "'s " + type + '');
          scope.getDataForBind(type);
          scope.deleteSelected = {};
          getTemplateContent.closeDialog(container);
          scope.showDeleteButton = false;
        }, function (error) {
          alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_DELETE_PROFILE_COMPONENT_ERROR', { ProfileType: type }));
        });
      } else {
        /* jshint ignore:start */

        if (scope.patient.deleteCollection.length === 0) {
          api.patients.get({ userid: userId }).then(function (response) {
            scope.deleteLinkedPatients(response.results.Retval, type, container);
          });
        } else {
          angular.forEach(scope.patient.deleteCollection, function (item) {
            if (item.IsDefault === true || item.PrimaryGuarantor === true) {
              if (type === 'Pharmacy') {
                saveObject = { patientId: scope.patient.patientId, pharmacyId: item.Id, isDefault: true };
              }

              if (type === 'Physician') {
                saveObject = { patientId: scope.patient.patientId, physicianId: item.Id };
                if (scope.deleteSelected.IsPrimary === true) {
                  pSvc.saveEntity(saveObject, type).then(function (response) {
                    api.patients.get({ userid: userId }).then(function (response) {
                      scope.deleteLinkedPatients(response.results.Retval, type, container);
                    });
                  }, function (error) {
                    // temp
                    api.patients.get({ userid: userId }).then(function (response) {
                      scope.deleteLinkedPatients(response.results.Retval, type, container);
                    });
                    alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_DELETE_PROFILE_COMPONENT_ERROR', { ProfileType: type }));
                  });
                } else {
                  api.patients.get({ userid: userId }).then(function (response) {
                    scope.deleteLinkedPatients(response.results.Retval, type, container);
                  });
                }
              }

              if (type !== 'Physician') {
                pSvc.saveEntity(saveObject, type).then(function (response) {
                  api.patients.get({ userid: userId }).then(function (response) {
                    scope.deleteLinkedPatients(response.results.Retval, type, container);
                  });
                }, function (error) {
                  alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_DELETE_PROFILE_COMPONENT_ERROR', { ProfileType: type }));
                });
              }
            }
          });
        }
        /* jshint ignore:end */
      }
    };

    /* delete linked patients */
    scope.deleteLinkedPatients = function (linkedPatients, type, container) {
      var promises = [];
      _.filter(linkedPatients, function (linkedPatient) {
        var deleteObject = {};

        if (type === 'Pharmacy') {
          deleteObject = { patientId: linkedPatient.Id, pharmacyId: scope.deleteSelected.Id };
        }
        if (type === 'Physician') {
          deleteObject = { patientId: linkedPatient.Id, physicianId: scope.linkedPhysiciansMatched[linkedPatient.Id].Id };
        }
        if (type === 'Location') {
          deleteObject = { patientId: scope.patient.patientId, locationId: scope.deleteSelected.Id };
        }

        var promise = pSvc.deleteEntity(deleteObject, type);
        promises.push(promise);

        q.all(promises).then(function () {
          alertService.add('success', translate.instant('SUCCESSFULLY_DELETED_COMPONENT_FROM_LINKED_PATIENTS', { type: type }));
          timeout(function () {
            scope.getDataForBind(type);
            scope.deleteSelected = {};
            getTemplateContent.closeDialog(container);
            scope.showDeleteButton = false;
            scope.isLinkedForPrimaryRecord = false;
          }, 5000);
        });
      });
    };

    /* delete current */
    scope.deleteCurrent = function (type, container, headerText) {
      headerText = translate.instant(headerText);
      if (scope.patient.deleteCollection.length === 0) {
        scope.deleteRecord(container, type);
      } else {
        angular.forEach(scope.patient.deleteCollection, function (item) {
          if (item.IsDefault === true || item.PrimaryGuarantor === true) {
            var saveObject = {};
            if (type === 'Pharmacy') {
              saveObject = { patientId: scope.patient.patientId, pharmacyId: item.Id, isDefault: true };
            }
            if (type === 'Physician') {
              saveObject = { patientId: scope.patient.patientId, physicianId: item.Id };
              if (scope.deleteSelected.IsPrimary === true) {
                pSvc.saveEntity(saveObject, type).then(function (response) {
                  scope.deleteRecord(container, type);
                }, function (error) {
                  alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SET_PRIMARY_ERR_MSG', { type: type }));
                });
              }

            }
            if (type === 'Location') {
              saveObject = { patientId: scope.patient.patientId, locationId: item.Id };
            }

            if (type !== 'Physician') {
              pSvc.saveEntity(saveObject, type).then(function (response) {
                scope.deleteRecord(container, type);
              }, function (error) {
                alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SET_PRIMARY_ERR_MSG', { type: type }));
              });
            }
          }
        });
      }
    };

    /* delete record */
    scope.deleteRecord = function (container, type) {
      var deleteObject = {};
      if (type === 'Pharmacy') {
        deleteObject = { patientId: scope.patient.patientId, pharmacyId: scope.deleteSelected.Id };
      }
      if (type === 'Physician') {
        deleteObject = { patientId: scope.patient.patientId, physicianId: scope.deleteSelected.Id };
      }
      if (type === 'Location') {
        deleteObject = { patientId: scope.patient.patientId, locationId: scope.deleteSelected.Id };
      }

      pSvc.deleteEntity(deleteObject, type).then(function (response) {
        alertService.add('success', translate.instant('PATIENT_MANAGEMENT_DELETED_PROFILE_COMPONENT_SUCCESS_MSG',{PatientName:scope.patient.demographics.FirstName,type:type}));
        scope.getDataForBind(type);
        scope.deleteSelected = {};
        getTemplateContent.closeDialog(container);
        scope.showDeleteButton = false;
        scope.isLinkedForPrimaryRecord = false;
      }, function (error) {
        alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_DELETE_PROFILE_COMPONENT_ERROR',{ProfileType:type}));
      });
    };

    scope.getPatientManagementAccessLevelPermissions = function (key, patientId, canView) {
      var permissionKey = '';
      if (patientId) {
        if (canView === true || canView) {
          permissionKey = patientId + '.patient-management.' + key + '.view';
        } else {
          permissionKey = patientId + '.patient-management.' + key + '.manage';
        }
      }
      return permissionKey;
    };

  }]);

}(window.app));
