(function (app) {
  'use strict';

  app.controller('addPatientWithPinCtrl', ['$scope', 'medseekApi', 'session', '$q', '$location', '$timeout', 'alertService', 'dynamicText', '$translate', 'localStorageSvc', function (scope, api, session, q, loc, timeout, alertService, dynamicText, translate, localStorageSvc) {
    /* variable declarations */
    scope.error = 'danger';
    scope.route = { path: '/modules/add-patient/views/addPatientWithPin.html', name: 'addPatientWithPin' };
    scope.steps = this.steps = [{ menu: translate.instant('SIGNUP_ENTER_PIN_TITLE') }];

    scope.getAllAdminSettingsDynamicTexts = function () {
      var culture = localStorageSvc.get('cultureName') || 'en-US';
      return api.getAllAdminSettingsDynamicTexts.get({ culture: culture }, null).$promise;
    };
    scope.filterDynamicText = function (msgKey, data) {
      var dynamicTextWelcomeMsg = _.where(data.results, function (value, key) { return key === msgKey; });
      if (dynamicTextWelcomeMsg) {
        return dynamicTextWelcomeMsg[0];
      }
      return 'n/a';
    };
    /* method for display dynamic text message */
    scope.displayDynamicTextForPin = function (keyName) {

      scope.getAllAdminSettingsDynamicTexts().then(function (data) {
        scope.error = scope.filterDynamicText('Enrollment' + '_' + keyName, data);
        alertService.add('danger', scope.error, 0, '', 'alert_wizard-step');
      }, function (error) {
        scope.error = error;
        alertService.add('danger', scope.error, 0, '', 'alert_wizard-step');
      });
    };

    /* onFocus wizard function */
    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      scope.init();

    };

    /* onNext wizard function */
    scope.onNext = function (flowControl) {
      flowControl.next();
    };

    /* onPrevious wizard function */
    scope.onPrevious = function (flowControl) {
      flowControl.previous();
    };

    scope.$on('reload', function () {
      scope.reset();
    });

    scope.reset = function () {
      if (scope.stepIndex > 0) {
        scope.stepIndex = 0;
      }
    };

    /* init */
    scope.init = function () {
      api.modules.settings.get({ moduleName: 'profile' }).$promise.then(function (response) {
        scope.moduleSettings = response.results.Retval;
      });
    };

    scope.acceptPin = function (flowControl) {
      flowControl.tabComplete();
    };

    scope.pinObject = JSON.parse(session.get('pin'));
    if (scope.pinObject) {
      scope.userName = scope.pinObject.patientName;
      var validUserPinInformation = translate.instant('SIGNUP_SELF_PIN_INSTRUCTIONS');
      scope.validUserPinInformation = validUserPinInformation.replace('@@userName@@', scope.pinObject.patientName);
      scope.steps.push({ menu: scope.pinObject.patientName });
    }


    scope.validatePin = function () {
      alertService.clear();
      if (angular.isUndefinedOrNull(scope.pin) || scope.pin.trim().length === 0) {
        scope.error = translate.instant('SIGNUP_REQUIRED_INFO_MISSING_ERROR'); // 'Please fill out all of the required information and try again.';
        alertService.add('danger', scope.error, 0, '', 'alert_wizard-step');
        return;
      }
      scope.pinValidationError = false;
      api.pinVerification.get({ pin: scope.pin, isExcludeDetails: true }).$promise.then(function (response) {
        var res = response.results.Retval;
        if (res.ValidationResponseKey !== 'Success') {
          /* jshint ignore:start */
          (res.ValidationResponseKey === 'InvalidPin') ? scope.displayDynamicTextForPin(res.ValidationResponseKey) :
            (res.ValidationResponseKey === 'PinAlreadyUsed') ? scope.displayDynamicTextForPin('AlreadyUsedPin') :
              (res.ValidationResponseKey === 'ExpiredPin') ? scope.displayDynamicTextForPin('ExpiredPin') :
                (res.ValidationResponseKey === 'LockedPin') ? scope.displayDynamicTextForPin('LockedPin') : (res.ValidationResponseKey === 'ExpiredInvitation') ? scope.displayDynamicTextForPin('ExpiredInvitation') :
                  (res.ValidationResponseKey === 'PatientAlreadyHasRelationshipWithCustodian') ? scope.displayDynamicTextForPin('AlreadyUsedPin') : alertService.add('danger', res.ValidationResponseKey, 0, '', 'alert_wizard-step');
          return;
          /* jshint ignore:end */
        }
        /*var patientData = res.ExternalPatients;
        scope.userName = 'Are you ' + patientData[0].FirstName + ' ' + patientData[0].LastName;
        session.set('pin', JSON.stringify({pin:scope.pin,patientName:scope.userName,patient : patientData[0]}));
*/

        var profilePatientRelationShip = res.ExternalPatients[0].ProfilePatientRelationShip;
        scope.userName = profilePatientRelationShip.UserFirstName + ' ' + profilePatientRelationShip.UserLastName;
        session.set('pin', JSON.stringify({ pin: scope.pin, patientName: scope.userName, patient: res.ExternalPatients[0], relationShipType: profilePatientRelationShip.RelationShip }));
        var validUserPinInformation = '';
        if (profilePatientRelationShip.RelationShip === 'Self') {
          validUserPinInformation = translate.instant('SIGNUP_SELF_PIN_INSTRUCTIONS'); // message.openEnrollment.selfPinMessages;
        } else {
          alertService.clear();
          validUserPinInformation = translate.instant('SIGNUP_DETAILS_FOR_VALID_PIN_INSTRUCTIONS');
        }
        scope.validUserPinInformation = validUserPinInformation.replace('@@userName@@', scope.userName).replace('@@patientName@@', res.ExternalPatients[0].FirstName + ' ' + res.ExternalPatients[0].MiddleName + ' ' + res.ExternalPatients[0].LastName);

        if (scope.steps.length < 2) {
          scope.steps.push({ menu: translate.instant('ARE_YOU_USER_MENU', { userName: scope.userName }) });
        } else {
          scope.steps[1].menu = scope.userName;
        }

        scope.fc.next();

      }, function (response) {
        alertService.add('danger', response.developerMessage, 0, '', 'alert_wizard-step');
      });
    };

  }]);

}(window.app));
