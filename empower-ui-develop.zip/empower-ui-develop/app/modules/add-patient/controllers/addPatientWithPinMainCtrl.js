(function (app) {
  'use strict';

  /* module root controller */
  app.controller('addPatientWithPinMainCtrl', ['$scope', '$timeout', '$location', '$dialogFactory', 'session','$translate', function (scope, timeout, location, dialog, session,translate) {
    scope.model = {
      routeParams: {},
      isShowDialog: false
    };

    scope.stepIndex = 0;
    scope.currentIndex = 0;
    var sessionName = 'ADDPatient';

    scope.setSession = function (addPatient) {
      session.set(sessionName, JSON.stringify(addPatient));
    };

    scope.$watch('stepIndex', function (newVal) {
      if (typeof newVal === 'number' && typeof scope.currentIndex === 'number') {
        scope.setSession({
          stepIndex: newVal,
          mainIndex: scope.currentIndex
        });
      }
    });

    scope.$watch('currentIndex', function (newVal) {
      if (typeof newVal === 'number') {
        scope.setSession({
          stepIndex: scope.stepIndex || 0,
          mainIndex: newVal || 0
        });
      }
    });

    var addPatientSession = JSON.parse(session.get(sessionName));
    if (addPatientSession) {
      scope.stepIndex = addPatientSession.stepIndex;
      scope.currentIndex = addPatientSession.mainIndex;
    }

    /* init function */
    scope.init = function () {};

    this.onControlsAdded = function (sender, control) {
      var setIdx = function () {
        control.setIndex(scope.currentIndex, scope.stepIndex);
      };
      timeout(setIdx, 0);
    };

    this.onCancel = function () {
      if (scope.masterForm.$dirty) {
          var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          scope.masterForm.$setPristine();
          session.clear(sessionName);
          session.clear('pin');
          location.path('/');
        });
      } else {
        session.clear(sessionName);
        session.clear('pin');
        location.path('/');
      }
    };

    // confirm navigation when form is dirty
    var unregConfirm = scope.$on('$locationChangeStart', function (event) {
      session.clear(sessionName);
      session.clear('pin');
    });

    scope.$on('msStepFlowControlsAdded', this.onControlsAdded);
    scope.$on('stepFlowOnCancel', this.onCancel);

  }]);

})(window.app);
