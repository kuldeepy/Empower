(function (app) {
  'use strict';

  /* directive for task center new discussion */
  app.directive('msAddPharmacy', [function () {
    return {
      restrict: 'E',
      scope: true,
      templateUrl: app.root + 'modules/Add-patient/templates/addPharmacy.html',

      controller: ['$scope', 'medseekApi', 'session', '$q', '$location', 'patientProfileService', '$timeout', 'alertService', 'profileService', 'dialogService', '$dialogFactory','$translate', function (scope, api, session, q, loc, pSvc, timeout, alertService, profileService, diag, dialogFactory,translate) {
        /* variable declarations */
        scope.error = 'danger';
        scope.linkedPharmacies = [];
        scope.selectedPharmacyErrorMessage = translate.instant('SIGNUP_REQUIRED_INFO_MISSING_ERROR');
        scope.fillPharmacyDetailErrorMessage = translate.instant('PATIENT_MANAGEMENT_FILL_MANDATORY_PHARMACY_DETAILS');
        scope.searchTypePharmacy = true;
        scope.searchTypeZipcode = false;
        scope.sortOptions = { fields: ['Name'], directions: ['desc'] };
        scope.pagingOption = { pageSize: 5, totalItems: 100, currentPage: 1, pageOption: [] };
        scope.pharmacyName = scope.searchByZip = '';
        scope.searchType = scope.searchTypePharmacy;
        scope.isSelected = false;
        scope.orderByField = '';
        scope.selectedPharamacy = {};
        scope.selectedPharamacy.isPrimary = false;

        scope.getPharmacy = function (pharmacy) {
          scope.patient = JSON.parse(session.get('patient'));
          if (!scope.patient) {
            return;
          }
          profileService.pharmacy.getPharmacy({ patientId: scope.patient.patientId }).then(function (response) {
            scope.patintPharmacies = response;
            scope.selectedPharamacy.isPrimary = (scope.patintPharmacies.length == 0);
          });
        };

        scope.getPharmacy();
        /* checked pharmacy */
        scope.checkedPharmacy = function (pharmacy) {
          scope.selectedPharamacy = pharmacy;
          scope.isSelected = true;
          scope.selectedPharamacy.isPrimary = (scope.patintPharmacies && scope.patintPharmacies.length == 0);

        };

        /* check if the record is primary */
        scope.checkIsPrimaryPharmacy = function () {
          var isExists = _.filter(scope.pharmacies, function (pharmacy) {
            return pharmacy.IsDefault === true;
          });

          return (isExists.length > 0);
        };

        /* save pharmacy */
        scope.savePharmacyToProfile = function (flowControl) {
          if (!scope.selectedPharamacy || !scope.selectedPharamacy._id) {
            alertService.add(scope.error, 'Please select Pharamacy.');
            return;
          }
          scope.patient = JSON.parse(session.get('patient'));
          if (!scope.patient) {
            return;
          }

          var isDefault = scope.selectedPharamacy.isPrimary;
          // if (scope.linkedPharmacies.length === 0) {
          //  isDefault = true;
          // }
          pSvc.saveEntity({ patientId: scope.patient.patientId, pharmacyId: scope.selectedPharamacy._id, isDefault: isDefault}, 'Pharmacy').then(function (response) {
            alertService.add('success', translate.instant('PATIENT_MANAGEMENT_PHARMACY_SAVED_TO_PROFILE',{patientFirstName:scope.patient.patientName}), 5000);
            timeout(function () {
              scope.$parent.getPatientPharmacy();
              scope.getPharmacy();
            }, 200);

            scope.pharmacyName = scope.searchByZip = '';
            scope.pharmacies = [];
            scope.searchByName = '';
            scope.isSearch = false;
            scope.isSelected = false;
            diag.hide('addPharmacy1');
            scope.$parent.closeDialog();
          }, function (error) {
            alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SAVE_PHARMACY'));
          });
        };

        /* sort pharmacies search results */
        scope.sortSearchPharmacies = function (type) {
          var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
          if (scope.pagingOption.currentPage > total) {
            return;
          }
          scope.sortOrder = scope.sortOptions.directions[0] === 'desc' ? 'asc' : 'desc';
          scope.reverseSort = scope.sortOrder === 'asc' ? true : false;
          scope.sortOptions.directions[0] = scope.sortOrder;
          scope.pagingOption.currentPage = 1;
          scope.getPharmacies();
          scope.orderByField = type;
        };

        /* get sort field */
        scope.getSortField = function (field) {
          var mapField = '';
          switch (field.toLowerCase()) {
            case 'name':
              mapField = 'PharmacyName';
              break;
            case 'phone':
              mapField = 'Phone';
              break;
            case 'type':
              mapField = 'PharmacyType';
              break;
            default:
              mapField = 'PharmacyName';
              break;

          }
          return mapField;
        };

        /* get sort direction */
        scope.getSortDirection = function (direction) {
          switch (direction.toLowerCase()) {
            case 'asc':
              return 'Ascending';
            case 'desc':
              return 'Descending';
            default:
              return 'Ascending';
          }
        };

        /* construct search pharmacies request object */
        scope.constructBody = function (reqObject) {
          if (scope.isSearch) {
            return {
              'parameters': {
                'pharmacyName': (scope.pharmacyName) ? scope.pharmacyName : '',
                'isEnabled': true,
                'zip': (scope.searchByZip) ? (scope.searchByZip) : '',
                'Radius': (scope.searchByZip !== '') ? scope.pharmacyDistance : null
              },
              'sortField': scope.getSortField(scope.orderByField),
              'sortDirection': scope.getSortDirection(scope.sortOptions.directions[0]),
              'pageSize': scope.pagingOption.pageSize,
              'pageIndex': scope.pagingOption.currentPage,
              'patientId': scope.patient.patientId

            };
          } else {
            return {
              'parameters': {
                'pharmacyName': '',
                'isEnabled': true,
                'zip': '',
              },
              'sortField': 'PharmacyName',
              'sortDirection': 'Ascending',
              'pageSize': '',
              'pageIndex': '',
              'patientId': scope.patient.patientId
            };
          }
        };

        /* get pharmacy */
        scope.getPharmacies = function () {
          scope.patient = JSON.parse(session.get('patient'));
          if (!scope.patient) {
            return;
          }

          scope.pharmacies = [];
          var pharmacy = {};
          pSvc.getEntities(scope.constructBody(), 'Pharmacy').then(function (response) {
            if (response.Retval.length > 0) {
              angular.forEach(response.Retval, function (pharmacy) {
                scope.pharmacies.push(pharmacy);
              });
            }
            scope.pagingOption.totalItems = response.totalItemCount;
            scope.isSelected = false;
          }, function (error) {
            alertService.add(scope.error, translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_GET_PHARMACIES_ERROR'));
          });
        };

        /* search click function */
        scope.searchClick = function () {
          scope.pharmacies = [];
          scope.isSearch = true;
          var body = {};
          if (scope.searchType === scope.searchTypePharmacy && scope.searchByName !== undefined && scope.searchByName.trim().length > 0) {
            scope.pharmacyName = scope.searchByName;
          }
          else if (scope.searchType === scope.searchTypeZipcode && scope.searchByZip !== undefined && scope.searchByZip.trim().length > 0) {
            scope.searchByZip = scope.searchByZip;
          } else {
            scope.pharmacyName = '';
          }
          scope.pagingOption.currentPage = 1;
          scope.getPharmacies();
          scope.getPharmacy();
        };

        /* watch function for pagination - current page */
        scope.$watch('pagingOption.currentPage', function (newVal, oldVal) {
          alertService.clear();
          var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
          if (oldVal !== newVal && newVal !== '' && parseInt(newVal) > 0 && total >= newVal) {
            scope.getPharmacies();
          }
          else if (isNaN(newVal) || parseInt(newVal) >= total || parseInt(newVal) <= 0 || isNaN(parseInt(newVal))) {
            alertService.add('danger', translate.instant('PLEASE_ENTER_VALID_PAGE_NUMBER'));
          }
        });

        /* watch function for pagination - page size */
        scope.$watch('pagingOption.pageSize', function (oldVal, newVal) {
          if (oldVal !== newVal) {
            scope.pagingOption.currentPage = 1;
            scope.getPharmacies();
          }
        });

        scope.onZipCodeChange = function () {
          scope.searchByName = scope.pharmacyName = '';
          scope.pharmacies = [];
          scope.isSearch = false;
        };

        scope.onPharmacyNameChange = function () {
          scope.searchByZip = scope.searchByZip = '';
          scope.pharmacies = [];
          scope.isSearch = false;
        };

        scope.closePopups = function () {
          if (scope.form && scope.form.$dirty) {
              var dialogCallback = dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
            dialogCallback.result.then(function () {
              scope.pharmacyName = scope.searchByZip = '';
              scope.pharmacies = [];
              scope.searchByName = '';
              scope.isSearch = false;
              scope.isSelected = false;
              diag.hide('addPharmacy1');
              scope.$parent.closeDialog();
            });
          } else {
            scope.pharmacyName = scope.searchByZip = '';
            scope.pharmacies = [];
            scope.searchByName = '';
            scope.isSearch = false;
            scope.isSelected = false;
            diag.hide('addPharmacy1');
            scope.$parent.closeDialog();
          }

        };

        scope.validateZip = function () {
          scope.pharmacyDistance = 10;
          scope.searchByZip = scope.searchByZip.replace(/[^a-z0-9]/gi, '');
          scope.searchByZip = (scope.searchByZip) ? scope.searchByZip : '';
          if (scope.searchByZip.length === 0) {
            scope.pharmacyDistance = 10;
          }
        };

      }]
    };
  }]);

}(window.app));
