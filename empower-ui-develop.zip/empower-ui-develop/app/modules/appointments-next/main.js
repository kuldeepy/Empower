(function (app) {
  'use strict';

  var initialized = false;

  /* module root controller */
  app.controller('AppointmentsModuleCtrl', ['$scope', 'session', 'stateManager', function (scope, session, stateManager) {
    /* module level data */
    scope.module = {
    };
    scope.isStaffUser = session.get('portal').toUpperCase() === 'STAFF' ? true : false;

    if (!initialized) {
      /* configure routing */
      stateManager.configure(scope, 'appointments')
        .state('appointmentlist', {
          url: '',
          templateUrl: 'views/appointment-list.html',
          controller: 'AppointmentsAppointmentListCtrl'
        }).state('appointmentlistfoo', {
        url: '/foo',
        templateUrl: 'views/appointment-list.html',
        controller: function ($scope) { $scope.foo = 'foo'; }
      });

      stateManager.apply();
      initialized = true;
    }
  }]);

})(window.app);
