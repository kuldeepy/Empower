(function (app) {
  'use strict';

  app.directive('appointmentsAppointmentList', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/appointments-next/directives/appointment-list/appointment-list.html',
      scope: {
        appointments: '=',
        sortOrder: '@',
        isStaffUser: '='
      },
      link: function (scope, element, attrs) {
        // create appointment groups
        scope.$watch('appointments', function (val) {
          var chain = _.chain(val)
            .sortBy(function (item) { return (item.date || new Date()); })
            .groupBy(function (item) { return (item.date || new Date()).getFullYear(); })
            .pairs().map(function (item) { return _.object(_.zip(['year', 'items'], item)); });

          if (scope.sortOrder === 'desc') {
            chain.reverse();
          }

          scope.yearGrouping = chain.value();
        });
      }
    };
  }]);
}(window.app));
