(function (app) {
  'use strict';

  app.controller('AppointmentsAppointmentListCtrl', ['$scope', function (scope) {
    // view information
    scope.module.view = {
      title: 'Appointments'
    };

    scope.appointments = [
      { date: new Date('January 1, 2012 11:00:00'), patient: {}, physician: {}, location: {}, type: 'Follow Up', status: 'Completed' },
      { date: new Date('January 2, 2013 11:30:00'), patient: {}, physician: {}, location: {}, type: 'Follow Up', status: 'Completed' },
      { date: new Date('January 3, 2015 11:00:00'), patient: {}, physician: {}, location: {}, type: 'Follow Up', status: 'Confirmed' },
      { date: new Date('January 4, 2016 11:30:00'), patient: {}, physician: {}, location: {}, type: 'Follow Up', status: 'Confirmed' },
      { date: new Date('December 1, 2014 11:00:00'), patient: {}, physician: {}, location: {}, type: 'Follow Up', status: 'Confirmed' },
      { date: new Date('November 1, 2014 11:00:00'), patient: {}, physician: {}, location: {}, type: 'Follow Up', status: 'Confirmed' },
      { date: new Date('January 1, 2011 11:00:00'), patient: {}, physician: {}, location: {}, type: 'Follow Up', status: 'Confirmed' },
    ];

    // create appointment groups
    scope.$watch('appointments', function (val) {
      var today = new Date();
      today.setHours(0, 0, 0, 0);

      scope.upcomingAppointments = _.filter(val, function (item) {
        return (!item.date) || (item.date >= today);
      });

      scope.pastAppointments = _.filter(val, function (item) {
        return (item.date && item.date < today);
      });
    });
  }]);

}(window.app));
