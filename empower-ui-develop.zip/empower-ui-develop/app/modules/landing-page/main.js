(function (app) {
  'use strict';

  /* module root controller */
  app.controller('landingPageMainCtrl', ['$scope', 'userService', 'medseekApi', '$q', 'session', 'PatientMhrDataSvc', '$http', '$sce', '$filter', 'AppointmentDataSvc', 'UserDataSvc', 'RequestDataSvc', 'LandingPageModuleData', 'Mhr', function (scope, userService, medseekApi, q, session, PatientMhrDataSvc, http, sce, $filter, AppointmentDataSvc, UserDataSvc, RequestDataSvc, LandingPageModuleData, Mhr) {
    scope.model = {
      routeParams: {}
    };
    var getHealthInfo = PatientMhrDataSvc;
    scope.myTile = [];
    scope.myHealthInformation = [];
    scope.patientClinicalDocuments = [];
    scope.appointmentData = [];
    scope.appointmentAllPatientData = [];
    scope.requestData = [];
    scope.userData = [];
    var userData = UserDataSvc;
    var appointmentData = AppointmentDataSvc;
    var patient = {};

    /* init function */
    scope.init = function () {
      userService.isModulePermission();
      if (session.get('portal') === 'staff') {
        scope.getMyTaskTileDetails();
      } else {
        patient = JSON.parse(session.get('patient'));
        if (patient) {
          scope.getAllPatientAppointments();
          scope.getPatientAppointments(patient);
        } else {
          scope.getPatients();
        }

        scope.getUserActivityRequest(patient);

      }
    };

    scope.getAllPatientAppointments = function () {
      userData.getUsersPatient(session.get('userId')).then(function (patients) {
        if (patients.Retval && patients.Retval.length > 0) {
          angular.forEach(patients.Retval, function (patient) {
            appointmentData.getPatientAppointment(patient.Id, patient.MedicalRecordNumber).then(function (response) {
              if (response.results.retval && response.results.retval.length > 0) {
                angular.forEach(response.results.retval, function (app) {
                  scope.appointmentAllPatientData.push(app);
                });
              }
            });
          });
        }
      });

    };

    scope.getUserActivityRequest = function () {
      var body = scope.buildUserActitityLogBody();

      // get the offset value based on the user timezone and load the activity log
      medseekApi.user.timeZone.get({ userId: session.get('userId') })
      .$promise.then(function (response) {
        var offSet = response.results.ActualUtcOffset || response.results.BaseUtcOffset;
        var offSetData = offSet.split(':');
        if (offSet.indexOf('-') > -1) {
          scope.offSet = (parseInt(offSetData[0] * 60) - parseInt(offSetData[1]));
        } else {
          scope.offSet = (parseInt(offSetData[0] * 60) + parseInt(offSetData[1]));
        }
        body.offSet = scope.offSet;

        userData.getUserActivityRequest(session.get('userId'), body).then(function (response) {
          scope.userData = response.results.Retval;
          scope.userData = _.remove(scope.userData, function (n) {
            return n.DataAccessAction !== 'User account accessed';
          });

        }, function (err) {
          scope.userData = [];
        });
      });

    };

    scope.buildUserActitityLogBody = function () {
      scope.dataAccessAction = [];
      scope.dataAccessAction[0] = "'Patient Demographics Viewed'";
      scope.dataAccessAction[1] = "'Patient Emergency Contacts Viewed'";
      scope.dataAccessAction[2] = "'Patient Guarantors Viewed'";
      scope.dataAccessAction[3] = "'Patient Insurances Viewed'";
      scope.dataAccessAction[4] = "'Patient Locations Viewed'";
      scope.dataAccessAction[5] = "'Patient Pharmacies Viewed'";
      scope.dataAccessAction[6] = "'Patient Physicians Viewed'";
      scope.dataAccessAction[7] = "'Patient Access Granted'";
      scope.dataAccessAction[8] = "'Patient Access Denied'";

      scope.dataAccessAction[9] = "'Health Records Viewed'";
      scope.dataAccessAction[10] = "'Weight, Height, Cholesterol, Blood Glucose, Blood Pressure, BMI Viewed'";
      scope.dataAccessAction[11] = "'Immunizations, Procedures, Social History, Family History Viewed'";
      scope.dataAccessAction[12] = "'Test Results Viewed'";
      scope.dataAccessAction[13] = "'Allergies Viewed'";
      scope.dataAccessAction[14] = "'Medications Viewed'";
      scope.dataAccessAction[15] = "'Problems Viewed'";
      scope.dataAccessAction[16] = "'Conditions Viewed'";
      scope.dataAccessAction[17] = "'Immunizations Viewed'";
      scope.dataAccessAction[18] = "'Procedures Viewed'";
      scope.dataAccessAction[19] = "'Family History Viewed'";
      scope.dataAccessAction[20] = "'Cholesterol Viewed'";
      scope.dataAccessAction[21] = "'Blood Pressure Viewed'";
      scope.dataAccessAction[22] = "'Blood Glucose Viewed'";
      scope.dataAccessAction[23] = "'Height Weight BMI Viewed'";
      scope.dataAccessAction[24] = "'Clinical Documents Viewed in Browser'";

      scope.dataAccessAction[25] = "'Test Results Printed'";
      scope.dataAccessAction[26] = "'Allergies Printed'";
      scope.dataAccessAction[27] = "'Medications Printed'";
      scope.dataAccessAction[28] = "'Problems Printed'";
      scope.dataAccessAction[29] = "'Conditions Printed'";
      scope.dataAccessAction[30] = "'Immunizations Printed'";
      scope.dataAccessAction[31] = "'Procedures Printed'";
      scope.dataAccessAction[32] = "'Family History Printed'";
      scope.dataAccessAction[33] = "'Cholesterol Printed'";
      scope.dataAccessAction[34] = "'Blood Pressure Printed'";
      scope.dataAccessAction[35] = "'Blood Glucose Printed'";
      scope.dataAccessAction[36] = "'Height Weight BMI Printed'";
      scope.dataAccessAction[37] = "'Enable Emergency Access'";
      scope.dataAccessAction[38] = "'Comment Deleted'";
      scope.dataAccessAction[39] = "'Comment Edited'";
      scope.dataAccessAction[40] = "'Comment Added'";

      return {
        'patientId': '',
        'userId': session.get('userId'),
        'pageSize': 50,
        'pageIndex': 1,
        'sortField': 'ActionDateTime',
        'sortDirection': 'Descending',
        /*'StartDateTime': scope.fromDate,
        'EndDateTime': scope.toDate,
        'offSet': scope.offSet,*/
        'dataAccessAction': scope.dataAccessAction
      };
    };

    scope.getPatientAppointments = function () {
      appointmentData.getPatientAppointment(patient.patientId, patient.mrn).then(function (response) {
        scope.appointmentData = response.results.retval;
      }, function (err) {
        scope.appointmentData = [];
      });
    };

    scope.getMyTaskTileDetails = function () {
      var getTiles = LandingPageModuleData;
      getTiles.getUserTasks(JSON.parse(session.get('userObject')).RoleIds, 'Pending').then(function (response) {
        scope.myTile.push({ name: 'Pending Tasks', count: (response.results.Count) ? response.results.Count : 0 });
        /*scope.myTile.push({ name: 'Unread Discussion Comments', count: (response.results.Count)? response.results.Count : 0 })*/
        scope.getUnreadCommentsCount(response.results);
        scope.myTile.push({ name: 'Unread Discussion Comments', count: 0 });
      });
    };

    scope.getUnreadCommentsCount = function (tasks) {
      var userId = session.get('userId');
      var getTiles = LandingPageModuleData;
      getTiles.getUserTasksDiscussion(userId).then(function (response) {
        scope.myTile[1].count = response.results ? response.results.count : 0;
        scope.$broadcast('Tasks');
      });
    // var UnreadCommentsCount = 0;
    // angular.forEach(tasks.Retval, function (task) {
    //  getTiles.getUserTasksDiscussion(userId, task.Id).then(function (response) {
    //    angular.forEach(response.results.Retval, function (discussion) {
    //      if (discussion.UnreadComments) {
    //        UnreadCommentsCount++;
    //      }
    //    });
    //    scope.myTile[1].count = UnreadCommentsCount;
    //  });
    // });
    };

    scope.getPatientHealthInformationDetails = function (patient) {
      Mhr.getAllPatientHealthInfoDetails({ 'patientId': patient.patientId, 'mrn': patient.mrn }).then(function (response) {
        scope.myHealthInformation = response;
      }, function(err) {
        scope.myHealthInformation = [];
      });
    };

    scope.getPatientClinicalDocuments = function (patient) {
      return Mhr.getImportedDocuments({ patientId: patient.patientId, medseekId: patient.mrn }).then(function (response) {
        scope.patientClinicalDocuments = response;
        _.forEach(scope.patientClinicalDocuments, function (item) { item.source = item.location });
        return scope.patientClinicalDocuments;
      }, function (response) {
      });
    };

    scope.getMhrModuleSettings = function () {
      Mhr.getModuleSettings().then(function (response) {
        scope.mhrModuleSettings = response;
      }, function (err) {
        scope.mhrModuleSettings = [];
      });
    };

    /* get patients */
    scope.getPatients = function () {
      var userId = session.get('userId');
      getHealthInfo.getPatients(userId).then(function (response) {
        var patientData = scope.getPatientData(response);
        if (patientData && Object.keys(patientData).length !== 0) {
          scope.getPatientHealthInformationDetails(patientData);
          scope.getPatientClinicalDocuments(patientData);
        }
      });
    };

    scope.getPatientData = function (response) {
      var patientData = null, patient = {}, patientobj = {};
      if (response.results.Retval.length > 0) {
        angular.forEach(response.results.Retval, function (data) {
          if (data.RelationshipLevel === 1) {
            patientData = data;
          }
        });
        patient = (patientData === null) ? response.results.Retval[0] : patientData;
        patientobj = {
          patientId: patient.Id,
          mrn: patient.MedicalRecordNumber,
        };
      }
      return patientobj;
    };

    scope.closeSummaryDialog = function (className) {
      angular.element('.' + className).hide();
    };

    scope.showDocument = function (record, patient) {
      var downloadClinicalDocumentDataUrl = app.api.root + 'patients/' + patient.Id + '/' + 'documents' + '/' + record.fileId + '?medseekId=' + patient.MedicalRecordNumber + '&documentId=' + record.id + '&fileName=' + record.name + '&actionType=view&format=pdf';
      http({
        method: 'GET',
        url: downloadClinicalDocumentDataUrl,
        headers: {
          'Authorization': 'bearer ' + session.get('sessionId'),
          'Content-Type': 'application/json;charset=utf-8'
        },
        responseType: 'arraybuffer'
      }).success(function (response, status, header) {
        var mime = header('Content-Type');
        var file = new Blob([response], { type: mime });
        scope.getView(file, record);
      }).error(function () {});
    };

    /* function to set the  clinical document view*/
    scope.getView = function (file, record) {
      record.read = true;
      scope.ClinicalDocumentDetailedContent = '';
      scope.fileURL = URL.createObjectURL(file);
      angular.element('.documentViewer').show();
    };

  }]);

})(window.app);
