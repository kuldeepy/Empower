(function (app) {
  'use strict';
  // session module controllers are required
  app.controller('LandingPageCtrl', ['$scope', 'session', 'messagingService', 'alertService', 'medseekApi', '$q', '$dialogFactory', '$timeout', 'dialogService', 'GetDialogServiceTemplates', 'GetDialogTemplate', '$filter', 'userPermissionsSvc', '$location', '$translate','PatientMhrDataSvc', 'UserDataSvc', 'RequestDataSvc', 'AppointmentDataSvc', 'GetLandingPageData', 'LandingPageModuleData','localStorageSvc', 'Mhr', 'mhrModuleSettings',
    function (scope, session, messageSvc, alertService, medseekApi, q, dialog, timeout, dialogService, GetDialogServiceTemplates, GetDialogTemplate, $filter, userPermissionsSvc, loc, translate, PatientMhrDataSvc, UserDataSvc, RequestDataSvc, AppointmentDataSvc, GetLandingPageData, LandingPageModuleData, localStorageSvc, Mhr, mhrModuleSettings) {
    scope.iconBasePath = '/themes/default/images/tile-icons/';

    scope.tileContentsForStaff = '';
    scope.tiles = [];
    scope.availableTiles = [];
    var getHealthInfo = PatientMhrDataSvc;
    scope.requestData = [];

    scope.portalId = '';
    scope.predicate = 'order';
    scope.isUserOnly = false;
    scope.userTiles = {
      portalId: '',
      tiles: []
    };
    var userSettings;

    var iWantToLinks;

    var patientHealthInfo = [];

    var patientClinicalDocuments = [];

    scope.patient = JSON.parse(session.get('patient')) || {};

    scope.renewMedication = function (data) {
      var medication = _.find(patientHealthInfo, function (data) {
        return data.Key == 'medications';
      });
      var row = _.find(medication.Records, function (row) {
        return row.id == data;
      });
      session.set('renewPrescription', JSON.stringify(row));
      loc.path('my-health-information/treatment').search({ type: 'medications', isRenew: 'true' });
    };

    scope.adminSettings = [];
    // scope.avilableTiles = [];
    scope.dialogName = 'confirmDialog';
    var getTemplateContent = new GetDialogTemplate(dialogService);
    var getDialogTemplates = new GetDialogServiceTemplates();

    /* init function */
    scope.init = function () {
      scope.currentLanguage = (localStorageSvc.get('cultureName') || '').toLowerCase();
      scope.dialogContent = getTemplateContent.getTemplate(scope.dialogName, translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'), getDialogTemplates.getConfirmFooter());
      scope.getLandingPageTiles(session.get('portal'));
      scope.setRequestCenterPatientPermissions();
    };

    scope.$on('Landingpage', function () {
      scope.tiles = [];
      scope.availableTiles = [];
      scope.init();
    });

    scope.$on('Tasks', function () {
      scope.tiles = [];
      scope.BindLandingPageData(scope.adminSettings, scope.userSettings);
    });

    scope.getLandingPageTiles = function (portalName) {
      alertService.clear();
      if (!portalName) {
        alertService.add('danger', 'Unable to get the tile information', 0, '', 'alert_page-top');
      } else {
        var getTiles = LandingPageModuleData;
        q.all([
          getTiles.getDefaultLandingPageTiles(portalName, session.get('userId')),
          getTiles.getUserTiles()
        ])
        .then(function (resultSet) {
          scope.portalId = resultSet[0].results.PortalId;
          scope.adminSettings = resultSet[0].results.Tiles;
          var userSettings = resultSet[1];
          scope.userSettings = userSettings;
          var patient = JSON.parse(session.get('patient'));
          if (patient) {

            var requestBody = {
              'criteria': {
                'PageSize': 5,
                'PageNumber': 1,
                'SortField': 'LastUpdatedDate',
                'SortDirection': 'Descending',
                'RequestStatus': 'Pending'
              }
            };

            var requestData = RequestDataSvc;
            q.all([
              Mhr.getImportedDocuments({ 'patientId': patient.patientId, 'medseekId': patient.mrn }),
              Mhr.getAllPatientHealthInfoDetails({ 'patientId': patient.patientId, 'mrn': patient.mrn }),
              Mhr.getModuleSettings(),
              requestData.getPatientRequest(session.get('userId'), requestBody)
            ])
            .then(function(mhrResultSet) {
              // MHR
              patientClinicalDocuments = mhrResultSet[0];
              patientHealthInfo = mhrResultSet[1];
              mhrModuleSettings = mhrResultSet[2];
              scope.HealthInformationActions = mhrModuleSettings.HealthInformationActions;
              scope.healthInformationDateFormat = mhrModuleSettings.HealthInformationDateFormat;

              // Request Center
              scope.requestData = (mhrResultSet[3].results.Retval && mhrResultSet[3].results.Retval.Results) ? mhrResultSet[3].results.Retval.Results : [];
            })
            .finally(function() {
              scope.BindLandingPageData(scope.adminSettings, userSettings);
              scope.getAvailableTiles();
            });
          } else {
            scope.isUserOnly = (session.get('portal') === 'patient');
            scope.BindLandingPageData(scope.adminSettings, userSettings);
            scope.getAvailableTiles();
          }

        }, function (error) {
          alertService.add('danger', error, 0, '', 'alert_page-top');
        });
      }
    };


    scope.BindLandingPageData = function (adminSettings, userSettings) {
      scope.patient = JSON.parse(session.get('patient'));
      if (adminSettings && adminSettings.length > 0 && userSettings && userSettings.results) {
        var userSavedSettings = JSON.parse(userSettings.results.Retval);
        if (userSavedSettings && userSavedSettings.tiles && userSavedSettings.tiles.length > 0) {
          angular.forEach(userSavedSettings.tiles, function (tile) {
            angular.forEach(adminSettings, function (adminSetting) {
              tile.permission = [];
              if (tile.tileName === adminSetting.TileName) {
                if (scope.patient) {
                  if (tile.tileName === 'Requests') {
                    tile.permission.push(['request-center']);
                  }
                  if (tile.tileName === 'MyNewMessages') {
                    tile.permission.push(['message-center']);
                  }
                }
                scope.mapTile(adminSetting, tile);
              }

            });
          });
        } else if(!userSavedSettings){//for new user userSavedSettings  will be null so bind default admin tiles
          angular.forEach(adminSettings, function (tiles) {
            scope.mapTile(tiles, {});
          });
        }
      } else {
        angular.forEach(adminSettings, function (tiles) {
          scope.mapTile(tiles, {});
        });
      }
    };

    scope.getMhrPermissionsForTile = function (tileName) {
      var permission = getHealthInfo.getMhrPermissionByKey(scope.HealthInformationActions, scope.mapTileName(tileName, null, scope.patient ? scope.patient.patientId : null));
      return ((permission) && (!permission.IsVisible)) ? false : true;
    };

    scope.getMhrPermissions = function (tileName) {
      var permission = getHealthInfo.getMhrPermissionByKey(scope.HealthInformationActions, scope.mapTileName(tileName, null, scope.patient ? scope.patient.patientId : null));
      return (permission);
    };

    scope.getCanViewHealthRecordsPermissions = function (tileName) {
      var permission = getHealthInfo.getMhrPermissionByKey(scope.HealthInformationActions, scope.mapTileName(tileName, null , scope.patient ? scope.patient.patientId : null));
      if (permission) {
        return permission.IsVisible;
      }
    };

    scope.getIsDisplay = function (adminSetting, usersetting, tile, tileName) {
      var mhrPermissions;

      if (adminSetting && usersetting) {
        mhrPermissions = (scope.getCanViewHealthRecordsPermissions(usersetting.tileName) === false) ? false : true;
        var adminSettingPermission = (adminSetting.IsAllowUserToAdd || adminSetting.IsDisplayByDefault);
        var isDisplay = (mhrPermissions && adminSettingPermission);
        return isDisplay;
      }
      else if (tileName) {
        if (scope.getCanViewHealthRecordsPermissions(tileName) === false) {
          mhrPermissions = false;
        } else {
          mhrPermissions = true;
        }
        return mhrPermissions;
      } else {
        if (scope.getCanViewHealthRecordsPermissions(tileName) === false) {
          mhrPermissions = false;
        } else {
          mhrPermissions = true;
        }
        return mhrPermissions;
      }
    };

    scope.mapTileName = function (key, CheckPremission, patientId) {
      var mapedKey = '';
      var permission = '';
      var addPermission = '';
      switch (key) {
        case 'Allergies':
        case 'AddAllerg':
        case 'AddAllergy':
          mapedKey = 'allergies';
          permission = [patientId + '.health-information.allergies.view'];
          addPermission = [patientId + '.health-information.allergies.manage'];
          break;
        case 'AddMedication':
        case 'Medications':
          mapedKey = 'medications';
          permission = [patientId + '.health-information.medications.view'];
          addPermission = [patientId + '.health-information.medications.manage'];
          break;
        case 'AddCondition':
        case 'Conditions':
          mapedKey = 'problems';
          permission = [patientId + '.health-information.conditions.view'];
          addPermission = [patientId + '.health-information.conditions.manage'];
          break;
        case 'IWantToAddFamilyHistory':
        case 'FamilyHistory':
          mapedKey = 'familyHistories';
          permission = [patientId + '.health-information.family-history.view'];
          addPermission = [patientId + '.health-information.family-history.manage'];
          break;
        case 'IWantToAddSocialHistory':
        case 'SocialHistory':
          mapedKey = 'socialHistories';
          permission = [patientId + '.health-information.social-histories.view'];
          addPermission = [patientId + '.health-information.social-histories.manage'];
          break;
        case 'IWantToAddProcedure':
        case 'Procedures':
          mapedKey = 'procedures';
          permission = [patientId + '.health-information.procedures.view'];
          addPermission = [patientId + '.health-information.procedures.manage'];
          break;
        case 'IWantToAddImmunization':
        case 'Immunizations':
          mapedKey = 'immunizations';
          permission = [patientId + '.health-information.immunizations.view'];
          addPermission = [patientId + '.health-information.immunizations.manage'];
          break;
        case 'IWantToAddNewWeight':
        case 'WeightAndHeight':
          mapedKey = 'weights';
          permission = [patientId + '.health-information.height-weight-bmi.view'];
          addPermission = [patientId + '.health-information.height-weight-bmi.manage'];
          break;
        case 'IWantToAddNewBloodGlucose':
        case 'BloodGlucose':
          mapedKey = 'bloodGlucoses';
          permission = [patientId + '.health-information.blood-glucoses.view'];
          addPermission = [patientId + '.health-information.blood-glucoses.manage'];
          break;
        case 'IWantToAddNewBloodPressure':
        case 'BloodPressure':
          mapedKey = 'bloodPressures';
          permission = [patientId + '.health-information.blood-pressures.view'];
          addPermission = [patientId + '.health-information.blood-pressures.manage'];
          break;
        case 'IWantToAddNewCholesterol':
        case 'Cholesterol':
          mapedKey = 'cholesterols';
          permission = [patientId + '.health-information.cholesterols.view'];
          addPermission = [patientId + '.health-information.cholesterols.manage'];
          break;
        case 'IWantToViewTestResults':
        case 'TestResults':
          mapedKey = 'testResults';
          permission = [patientId + '.health-information.test-results.view'];
          addPermission = [patientId + '.health-information.test-results.manage'];
          break;
        case 'IWantToViewClinicalDocuments':
        case 'ClinicalDocuments':
          mapedKey = 'ImportedRecords';
          permission = [patientId + '.health-information.clinical-documents.view'];
          addPermission = [patientId + '.health-information.clinical-documents.manage'];
          break;
        case 'Requests':
          permission = ['request-center.requests.pending.view'];
          addPermission = scope.requestCenterPermissions;
          break;
        case 'SubmitNewRequet':
          permission = scope.requestCenterPermissions;
          break;
        case 'MyNewMessages':
          permission = ['message-center'];
          break;
        case 'Tasks': // 'MyTask': -> Earlier it was MyTask, Now it is Tasks. Changing for EMPO-6215
          permission = ['task-center'];
          break;
        case 'MyActivityLog':
        case 'ActivityLog':
          permission = ['user-settings'];
          break;
        case 'AddPhysician':
          permission = [patientId + '.patient-management.physicians.manage'];
          break;
        case 'SendMessage':
          permission = ['message-center.messages.create'];
          break;
        case 'UpdateEmail':
          permission = ['user-settings.user-info.edit'];
          // permission = [patientId + ".patient-management.demographics.manage"];
          // Changed update Email permission to that of User Settings Edit and not patient management.
          break;
        case 'UpdatePhone':
          permission = [patientId + '.patient-management.demographics.manage'];
          break;
        case 'UpdatePreferences':
          permission = ['user-settings.notification-types.manage' , 'user-settings.time-zone.edit'];
          break;
        case 'AddLocation':
          permission = [patientId + '.patient-management.locations.manage'];
          break;
        case 'ShareAcces':
          permission = [patientId + '.patient-management.share-access'];
          break;
        case 'UpdateAddress':
          permission = [patientId + '.patient-management.demographics.manage'];
          break;
        case 'Appointments':
        case 'AllAppointments':
          permission = [patientId + '.appointments.future.view'];
          addPermission = [patientId + '.appointments.future.schedule'];
          break;
        default:
          mapedKey = key;
      }
      if (!CheckPremission) {
        return mapedKey;
      } else {
        if (CheckPremission === 'isTile') {
          return permission;
        } else {
          return addPermission;
        }
      }
    };
    scope.setRequestCenterPatientPermissions = function () {
      scope.requestCenterPermissions = [];
      var userId = session.get('userId');
      var deferred = q.defer();
      medseekApi.user.patients.get({ userid: userId }).$promise.then(function (response) {
        angular.forEach(response.results.Retval, function (patient) {
          scope.requestCenterPermissions.push(patient.Id + '.request-center.requests.create');
          deferred.resolve(scope.requestCenterPermissions);
        });
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    scope.checkPremission = function (titleName, condition) {
      var permission;
      var permissionKey;
      if (session.get('portal') === 'staff') {
        if (titleName === 'IWantTo' || titleName.toUpperCase() === 'QuickLinks'.toUpperCase() || titleName === 'TourThisPage') {
          permission = true;
        } else {
          permissionKey = scope.mapTileName(titleName, condition);
          permission = userPermissionsSvc.userHasPermission(permissionKey);
        }
      } else {
        var patientId = (session.get('patient')) ? JSON.parse(session.get('patient')).patientId : '';
        permissionKey = scope.mapTileName(titleName, condition, patientId);
        if (titleName === 'IWantTo' || titleName.toUpperCase() === 'QuickLinks'.toUpperCase() || titleName === 'TourThisPage') {
          permission = true;
        } else {
          permission = userPermissionsSvc.userHasPermission(permissionKey);
        }
      }
      return (permission) ? true : false;
    };

    scope.mapTile = function (adminSetting, usersetting) {
      var isDisplay = true;
      var titleName = adminSetting.TileName || usersetting.tileName;
      if (session.get('portal') != 'staff' && !scope.getMhrPermissionsForTile(titleName)) {
        return;
      }
      if (!scope.checkPremission(titleName, 'isTile')) {
        return;
      }
      var mappedTile = {
        tileName: titleName,
        title: scope.translateTiles((adminSetting.DisplayName) ? scope.bindTokens(adminSetting.DisplayName) : usersetting.title),
        isDisplayByDefault: (usersetting && usersetting.tileName) ? adminSetting.IsAllowUserToAdd : adminSetting.IsDisplayByDefault,
        isAllowUserToAdd: adminSetting.IsAllowUserToAdd,
        isAllowUserToRemove: adminSetting.IsAllowUserToRemove,
        isAllowUserToMove: adminSetting.IsAllowUserToMove,
        template: scope.bindTilesItems(adminSetting.TileName, adminSetting.Links, null, isDisplay),
        icon: scope.iconBasePath + scope.bindTilesItems(adminSetting.TileName, null, 'icon', isDisplay),
        className: scope.bindTilesItems(adminSetting.TileName, null, 'class', isDisplay),
        isAdd: scope.bindTilesItems(adminSetting.TileName, null, 'isAdd', isDisplay),
        isMore: scope.bindTilesItems(adminSetting.TileName, null, 'isMore', isDisplay),
        addText: scope.bindTilesItems(adminSetting.TileName, null, 'addText', isDisplay),
        moreNavigation: scope.bindTilesItems(adminSetting.TileName, null, 'moreNav', isDisplay),
        addNewNavigation: scope.bindTilesItems(adminSetting.TileName, null, 'addNewNav', isDisplay),
        addIcon: scope.bindTilesItems(adminSetting.TileName, null, 'addIcon', isDisplay),
        col: usersetting.col,
        row: usersetting.row,
        specific: adminSetting.Specific

      };
      if (scope.isUserOnly) {
        if (mappedTile.specific === 'User' && mappedTile.isDisplayByDefault) {
          scope.tiles.push(mappedTile);
        }
      } else {
        if (mappedTile.isDisplayByDefault) {
          scope.tiles.push(mappedTile);
        }
      }
    };

    scope.bindTokens = function (name) {
      // EMPO-5357 - removing Patients name from tiles
      return name.replace("$$PatientFirstName$$'s", '').replace('My ', '');

    };

    scope.getTokenValue = function () {
      var patient = (session.get('patient')) ? JSON.parse(session.get('patient')) : undefined;
      return (patient) ? patient.patientName.split(' ')[0] : undefined;
    };

    scope.getCanAddHealthRecordsPermissions = function (tileName) {
      var permission = getHealthInfo.getMhrPermissionByKey(scope.HealthInformationActions, tileName);
      if (permission) {
        return permission.IsAddEnabled;
      }
    };

    scope.bindTilesProperties = function (property, className, icon, isAdd, isMore, addText, addNavKey, moreNavKey, addIcon, tileName) {
      var template;
      var navLink = new GetLandingPageData();
      if (property === 'class') {
        template = className;
      }
      else if (property === 'icon') {
        template = icon;
      }
      else if (property === 'isAdd') {
        template = isAdd;
        if (tileName) {
          if (!scope.checkPremission(tileName, 'isAdd')) {
            template = '';
          }
        }
      }
      else if (property === 'isMore') {
        template = isMore;
      }
      else if (property === 'addText') {
        template = addText;

      }
      else if (property === 'moreNav') {
        var moreNav = navLink.getNavigationRoute(moreNavKey);
        template = moreNav;
      }
      else if (property === 'addNewNav') {
        var addNav = navLink.getNavigationRoute(addNavKey);
        template = addNav;
      }
      else if (property === 'addIcon') {
        template = addIcon;
      }

      return template;
    };

    scope.bindTilesItems = function (tileName, links, property, isDisplay) {
      var appointmentData = AppointmentDataSvc;
      var requestData = RequestDataSvc;
      var userData = UserDataSvc;
      var template;
      var jsonval;
      var addLink = '';
      var moreLink = '';
      var mhrViewKey = '';
      switch (tileName) {
        case 'QuickLinks':
        case 'IWantTo':
          if (!property && isDisplay) {
            template = scope.getIWantToTemplate(links);
          } else {
            template = scope.bindTilesProperties(property, 'i-want-to', 'icon_i_want_to.png', false, false, '', '', '', 'icon-add-6fa8dc-30x30');
          }
          break;
        case 'AllAppointments':
          if (!property && isDisplay) {
            template = appointmentData.getAppointmentDataTemplate(scope.$parent.appointmentAllPatientData, $filter, true);
          } else {
            template = scope.bindTilesProperties(property, 'all-appointments', 'icon_my_appointment.png', true, true, translate.instant('NEW_APPOINTMENT'), 'addNewAppointments', 'viewAppointments', 'icon-add-6fa8dc-30x30');
          }
          break;
        case 'Appointments':
          if (!property && isDisplay) {
            template = appointmentData.getAppointmentDataTemplate(scope.$parent.appointmentData, $filter, false);
          } else {
            template = scope.bindTilesProperties(property, 'my-appointments', 'icon_my_appointment.png', true, true, translate.instant('NEW_APPOINTMENT'), 'addNewAppointments', 'viewAppointments', 'icon-add-6fa8dc-30x30');
          }
          break;
        case 'MyActivityLog':
        case 'ActivityLog':
          if (!property && isDisplay) {
            template = userData.getUserActivityDataTemplate(scope.$parent.userData, $filter);
          } else {
            template = scope.bindTilesProperties(property, 'recent-activity', 'icon_recent_activity.png', false, true, '', '', 'viewMyActivityLog', 'icon-add-6fa8dc-30x30');
          }
          break;
        case 'Announcements':
          if (!property && isDisplay) {
            template = scope.getAnnouncementsTemplate();
          } else {
            template = scope.bindTilesProperties(property, 'announcements', 'icon_announcement.png', false, true, '', '', 'viewAnnouncements', 'icon-add-6fa8dc-30x30');
          }
          break;
        case 'Requests':
          if (!property && isDisplay) {
            template = requestData.getRequestDataTemplate(scope.requestData, $filter, requestData);
          } else {
            template = scope.bindTilesProperties(property, 'my-requests', 'icon_my_request.png', true, true, translate.instant('NEW_REQUEST'), 'addNewRequests', 'viewRequests', 'icon-add-6fa8dc-30x30', 'Requests');
          }
          break;
        case 'MyNewMessages':
        case 'MyNewMessage':
        case 'MyMessage':
          if (!property && isDisplay) {
            template = scope.getMyMessagesTemplate();
          } else {
            template = scope.bindTilesProperties(property, 'my-messages', 'icon_message.png', true, true, translate.instant('NEW_MESSAGE'), 'addNewMessages', 'viewMessages', 'icon-add-6aa84f-30x30');
          }
          break;
        case 'Medications':
          mhrViewKey = 'medications';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('Medications', mhrViewKey, patientHealthInfo, null, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-medications', 'icon_medication.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_MEDICATION'), 'addNewMedications', 'viewMedications', 'icon-add-8e7cc3-30x30', 'Medications');
          }
          break;
        case 'Allergies':
          mhrViewKey = 'allergies';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('allergies', mhrViewKey, patientHealthInfo, null, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-allergies', 'icon_allergies.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_ALLERGY'), 'addNewAllergies', 'viewAllergies', 'icon-add-8e7cc3-30x30', 'Allergies');
          }
          break;
        case 'Conditions':
          mhrViewKey = 'problems';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('Conditions', mhrViewKey, patientHealthInfo, null, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-conditions', 'icon_conditions.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_CONDITION'), 'addNewConditions', 'viewConditions', 'icon-add-526e83-30x30', 'Conditions');
          }
          break;
        case 'FamilyHistory':
          mhrViewKey = 'familyHistories';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('FamilyHistory', mhrViewKey, patientHealthInfo, null, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-family-history', 'icon_family_history.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_FAMILY_HISTORY'), 'addNewFamilyHistory', 'viewFamilyHistory', 'icon-add-333333-30x30', 'FamilyHistory');
          }
          break;
        case 'SocialHistory':
          mhrViewKey = 'socialHistories';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('SocialHistory', mhrViewKey, patientHealthInfo, null, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-social-history', 'icon_social_history2.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_SOCIAL_HISTORY'), 'addNewSocialHistory', 'viewSocialHistory', 'icon-add-6fa8dc-30x30', 'SocialHistory');
          }
          break;
        case 'Procedures':

          mhrViewKey = 'procedures';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('Procedures', mhrViewKey, patientHealthInfo, null, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-procedures', 'icon_procedures.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_PROCEDURE'), 'addNewProcedures', 'viewProcedures', 'icon-add-6aa84f-30x30', 'Procedures');
          }
          break;
        case 'Immunizations':
          mhrViewKey = 'immunizations';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('Immunizations', mhrViewKey, patientHealthInfo, null, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-immunizations', 'immunization-icon-short-45x45.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_IMMUNIZATION'), 'addNewImmunizations', 'viewImmunizations', 'icon-add-8e7cc3-30x30', 'Immunizations');
          }
          break;
        case 'WeightAndHeight':
          mhrViewKey = 'weights';
          if (!property && isDisplay) {
            template = getHealthInfo.getHealthTrackersDataTemplate('WeightAndHeight', mhrViewKey, patientHealthInfo, mhrModuleSettings);
          } else {
            template = scope.bindTilesProperties(property, 'my-weight-and-height', 'icon_weight.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_WEIGHT_HEIGHT'), 'addNewWeightAndHeight', 'viewWeightAndHeight', 'icon-add-526e83-30x30', 'WeightAndHeight');
          }
          break;

        case 'BloodGlucose':
          mhrViewKey = 'bloodGlucoses';
          if (!property && isDisplay) {
            template = getHealthInfo.getHealthTrackersDataTemplate('BloodGlucose', mhrViewKey, patientHealthInfo, mhrModuleSettings);
          } else {
            template = scope.bindTilesProperties(property, 'my-blood-glucose', 'icon_blood_glucose.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_BLOOD_GLUCOSE'), 'addNewBloodGlucose', 'viewBloodGlucose', 'icon-add-333333-30x30', 'BloodGlucose');
          }
          break;
        case 'BloodPressure':
          mhrViewKey = 'bloodPressures';
          if (!property && isDisplay) {
            template = getHealthInfo.getHealthTrackersDataTemplate('BloodPressure', mhrViewKey, patientHealthInfo, mhrModuleSettings);
          } else {
            template = scope.bindTilesProperties(property, 'my-blood-pressure', 'icon_blood_pressure.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_BLOOD_PRESSURE'), 'addNewBloodPressure', 'viewBloodPressure', 'icon-add-6fa8dc-30x30', 'BloodPressure');
          }
          break;
        case 'Cholesterol':
          mhrViewKey = 'cholesterols';
          if (!property && isDisplay) {
            template = getHealthInfo.getHealthTrackersDataTemplate('Cholesterol', mhrViewKey, patientHealthInfo, mhrModuleSettings);
          } else {
            template = scope.bindTilesProperties(property, 'my-cholesterol', 'cholestrol-icon-short-45x45.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, translate.instant('ADD_NEW_CHOLESTROL'), 'addNewCholesterol', 'viewCholesterol', 'icon-add-6aa84f-30x30', 'Cholesterol');
          }
          break;
        case 'TestResults':
          mhrViewKey = 'testResults';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('TestResults', mhrViewKey, patientHealthInfo, null, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-test-results', 'icon_test_results.png', scope.getCanAddHealthRecordsPermissions(mhrViewKey), true, '', '', 'viewTestResults', 'icon-add-6fa8dc-30x30', 'TestResults');
          }
          break;
        case 'ClinicalDocuments':
          mhrViewKey = 'ImportedRecords';
          if (!property && isDisplay) {
            template = getHealthInfo.getMhrDataTemplate('ClinicalDocuments', mhrViewKey, patientHealthInfo, patientClinicalDocuments, scope.healthInformationDateFormat);
          } else {
            template = scope.bindTilesProperties(property, 'my-clinical-documents', 'icon_clinical_document_76a5af.png', scope.getCanAddHealthRecordsPermissions('ImportedRecords'), true, '', '', 'viewClinicalDocuments', 'icon-add-6fa8dc-30x30', 'ClinicalDocuments');
          }
          break;
        case 'Tasks': // MyTask': -> Earlier it was MyTask, Now it is Tasks. Changing for EMPO-6215
          if (!property && isDisplay) {
            template = scope.getMyTasksTemplate();
          } else {
            template = scope.bindTilesProperties(property, 'my-task', 'icon-my-task.png', false, true, '', '', 'viewMyTask', 'icon-add-6fa8dc-30x30');
          }
          break;
      }
      return template;
    };

    scope.generateTileContents = function (data) {
      var template = '<table class="table table-striped"><tbody>';

      angular.forEach(data.rows, function (row) {
        var count = 0;
        template += '<tr>';
        for (count = 0; count < row.length; count = count + 1) {
          template += '<td>' + row[count] + '</td>';
        }
        template += '</tr>';
      });

      template += '</tbody></table>';
      return template;
    };

    scope.getIWantToTemplate = function (links) {
      var getlinks = new GetLandingPageData();
      var template = '<div>';
      if (session.get('portal').trim().toUpperCase() === 'PATIENT') {
        iWantToLinks = getlinks.getIWantToLinks(links, scope.getTokenValue());
        template += '<ul class="generic-tile-item with-' + iWantToLinks.length + '-links">';
        angular.forEach(iWantToLinks, function (link) {
          var mhrPermission = false;
          var mhrTileHasPermission = false;
          var condition = 'isTile';

          if (session.get('portal') != 'staff') {
            mhrPermission = scope.getMhrPermissions(link.title);
            mhrTileHasPermission = true;
          }

          if (mhrPermission) {
            if (!mhrPermission.IsVisible) {
              mhrTileHasPermission = false;
            }

            if (link.title.indexOf('IWantToViewTestResults') == -1 && link.title.indexOf('IWantToViewClinicalDocuments') == -1) {
              mhrTileHasPermission = mhrPermission.IsAddEnabled;
              condition = 'link';
            }
          }
          if (mhrTileHasPermission && scope.checkPremission(link.title, condition)) {
            if (link.title != 'TourThisPage') {
              template += '<li><a class="icon-with-label i-want-to-nav-item" href="' + link.navigateTo + '"><span class="icon-holder"><span class="' + link.iconClass+ '"></span></span><span class="icon-label">' + scope.translateTiles(link.label) + '</span></a></li>';
            }
          }
          if (link.title === 'TourThisPage') {
            template += '<li class="hidden-xs"><a class="icon-with-label i-want-to-nav-item take-the-tour-menu-item" ng-click="openTour()" href=""><span class="icon-holder"><span class="quick-links_tour"></span></span><span class="icon-label">Tour this Page</span></a></li>';
          }
        });

        template += '</ul>';

      }
      if (session.get('portal').trim().toUpperCase() === 'STAFF') {
        iWantToLinks = getlinks.getIWantToLinks(links, '', userPermissionsSvc);
        var linkIndex, link;
        template += '<ul class="generic-tile-item">';
        for (linkIndex in iWantToLinks) {
          var optionsLinks = '';
          if (userPermissionsSvc.userHasPermissions(['user-management.users.search.view', 'user-management.patients.search.view'])) {
            optionsLinks = '<option>Patients and Users</option> <option>Patients only</option><option>Users only</option>';
          }
          else if (userPermissionsSvc.userHasPermissions(['user-management.patients.search.view'])) {
            optionsLinks = '<option>Patients only</option>';

          }
          else if (userPermissionsSvc.userHasPermissions(['user-management.users.search.view'])) {
            optionsLinks = '<option>Users only</option>';
          }
          link = iWantToLinks[linkIndex];
          if (/search/gi.test(link.label)) {
            template += '<li class="i-want-to-patient-search"><form ng-submit="iWantToSearch(searchIwantToValue,searchType)" class="">';
            template += '<label class="control-label sr-only" for="userPatientSearch_search">Quick Search</label>';
            template += '<p>' + link.label + '</p>';
            template += '<div class="form-group"><input id="userPatientSearch_search" type="search" ng-model="searchIwantToValue" class="form-control" placeholder="Quick Search">';
            template += '<button role="button" type="submit" class="btn-search"><span class="icon-holder"><i class="round-icon_search"></i></span><span class="icon-label sr-only">Search</span></button></div>';
            template += '</form></li>';
          } else {
            template += '<li><a href="' + link.navigateTo + '" class="icon-with-label i-want-to-nav-item">';
            template += '<span class="icon-holder"><i class="' + link.iconClass + '"></i></span>';
            template += '<span class="icon-label">' + link.label + '</span>';
            template += '</a></li>';
          }
        }
        template += '</ul>';
      }
      template += '</div>';
      return template;
    };

    scope.getMyTasksTemplate = function () {
      var template = '<ul class="generic-tile-item">';
      angular.forEach(scope.$parent.myTile, function (myTask) {
        template += '<li><div class="generic-tile-item_row">';
        template += '<p class="tile_entry entry_with_icon"><a href=task-center>' + myTask.name + '</a></p>' + '<span class="badge badge-alert tile_icon">' + myTask.count + '</span>';
        template += '</div></li>';
      });
      template += '</ul>';
      return template;
    };

    scope.iWantToSearch = function (searchIwantToValue, searchType) {
      if (!searchIwantToValue) {
        alertService.add('danger', 'Please provide a valid search criteria', 2000);
        return;
      }
      var url = '/user-management/search?quickSearchText=' + searchIwantToValue.toString() + '&profileSearch=true&searchType=';
      url += searchType == 'Patients only' ? 'Patient' : searchType == 'Users only' ? 'AccountHolder' : 'Both';
      url += '&orderBy=firstName';
      url += '&isQuickSearch=true';
      loc.url(url);
    };

    scope.getActivityLogTemplate = function () {
      var getActivityLog = new GetLandingPageData();
      var template = '<ul class="generic-tile-item">';
      angular.forEach(getActivityLog.activityLogs, function (activity) {
        template += '<li><div class="generic-tile-item_row">';
        template += '<p class="tile_entry entry_with_timeFrom">' + activity.name + '</p>';
        template += '<p class="tile_timeFrom">' + activity.changedOn + '</p>';
        template += '</div></li>';
      });

      template += '</ul>';

      return template;
    };

    scope.getAnnouncementsTemplate = function () {
      var getAnnouncements = new GetLandingPageData();
      var template = '<ul class="generic-tile-item">';

      angular.forEach(getAnnouncements.announcements, function (announcement) {
        template += '<li><div class="generic-tile-item_row">';
        template += '<p class="tile_entry"><a href="">' + announcement.name + '</a> <br />' + announcement.date + '</p>';
        template += '</div></li>';
      });

      template += '</ul>';

      return template;
    };

    /* method of get my messages template for get record and bind the template */
    scope.getMyMessagesTemplate = function () {
      var getMyMessages = new GetLandingPageData(messageSvc, q);
      getMyMessages.myMessages().then(function (response) {
        scope.myNewMessagesData = response;
      });

      var template = '<ul class="generic-tile-item" ng-show="myNewMessagesData.Messages.length">';
      template += '<li class="message-landing__item" ng-repeat="myMessage in myNewMessagesData.Messages">';
      template += '<p class="message-landing__subject">Subject: <span class="" ng-bind="myMessage.Subject"></span></p>';
      template += '<p class="message-landing__from">From: <span class="" ng-bind="myMessage.From[0].Name"></span></p>';
      template += '<p  class="message-landing__received"><span class="sr-only">Received on: </span><span class="" ng-bind="myMessage.Date | date:\'MM/dd/yyyy hh:mm a\'"></span></p>';
      template += '</li>';
      template += '</ul>';
      template += '<p class="no-data" ng-show="!myNewMessagesData.Messages.length">There are no new messages at this time.</p>';
      return template;
    };

    scope.getMyRequestsTemplate = function () {
      var getMyRequests = new GetLandingPageData();
      var template = '<ul class="generic-tile-item">';

      angular.forEach(getMyRequests.myRequests, function (myRequest) {
        template += '<li><div class="generic-tile-item_row"><p class="myrequests-item__name tile_entry entry_with_status entry_with_date">';
        template += myRequest.name;
        template += '</p><p class="tile_date">';
        template += myRequest.changedOn;
        template += '</p><p class="tile_status ' + myRequest.statusType + '">' + myRequest.status + '</p>';
        template += '</div></li>';
      });
      template += '</ul>';
      return template;
    };

    scope.gridsterOpts = {
      // pushing: false,
      columns: 2,
      minColumns: 2,
      minRows: 0,
      maxRows: 400,
      mobileBreakPoint: 767,
      defaultSizeX: 1,
      defaultSizeY: 15,
      rowHeight: 20,
      // margins: [0, 0],
      outerMargin: false,
      resizable: {
        enabled: false
      },
      draggable: {
        enabled: true,
        handle: '.icon-drag',
        start: function (event, widget) {},
        stop: function (event, widget) {
          scope.saveUserSettings();
        }
      }
    };
    scope.gridsterFixedOpts = {
      // pushing: false,
      columns: 2,
      minColumns: 2,
      minRows: 0,
      maxRows: 400,
      mobileBreakPoint: 767,
      defaultSizeX: 1,
      defaultSizeY: 15,
      rowHeight: 20,
      // margins: [0, 0],
      outerMargin: false,
      resizable: {
        enabled: false
      },
      draggable: {
        enabled: false,
        handle: '.icon-no'
      }
    };



    scope.bindAvailabeTiles = function (admintile) {
      return {
        tileName: admintile.TileName,
        title: scope.translateTiles(scope.bindTokens(admintile.DisplayName)),
        isDisplayByDefault: true,
        isAllowUserToAdd: admintile.IsAllowUserToAdd,
        isAllowUserToRemove: admintile.IsAllowUserToRemove,
        isAllowUserToMove: admintile.IsAllowUserToMove,
        template: scope.bindTilesItems(admintile.TileName, admintile.Links, null, true),
        icon: scope.iconBasePath + scope.bindTilesItems(admintile.TileName, null, 'icon'),
        className: scope.bindTilesItems(admintile.TileName, null, 'class'),
        isAdd: scope.bindTilesItems(admintile.TileName, null, 'isAdd'),
        isMore: scope.bindTilesItems(admintile.TileName, null, 'isMore'),
        addText: scope.bindTilesItems(admintile.TileName, null, 'addText'),
        moreNavigation: scope.bindTilesItems(admintile.TileName, null, 'moreNav'),
        addNewNavigation: scope.bindTilesItems(admintile.TileName, null, 'addNewNav'),
        addIcon: scope.bindTilesItems(admintile.TileName, null, 'addIcon'),
        permission: admintile.permission[0],
      };
    };

    scope.addNewTiles = function () {
      // scope.availableTiles = [];
      scope.tileSelected = false;
      scope.getAvailableTiles();
      alertService.clear();
      scope.displayPopup();
    };

    scope.bindNewTiles = function (admintile) {
      if (scope.tiles.length < 1 && admintile.IsAllowUserToAdd) {
        scope.availableTiles.push(scope.bindAvailabeTiles(admintile));
      } else {
        var isNeedAdd = true;
        angular.forEach(scope.tiles, function (usertile) {
          if (admintile.TileName === usertile.tileName) {
            isNeedAdd = false;
          }
        });
        if (admintile.IsAllowUserToAdd && isNeedAdd) {
          scope.availableTiles.push(scope.bindAvailabeTiles(admintile));
        }
      }
    };

    scope.getAvailableTiles = function () {
      scope.availableTiles = [];
      scope.search = '';
      var patient = JSON.parse(session.get('patient'));
      angular.forEach(scope.adminSettings, function (admintile) {
        admintile.permission = [];
        var portal = session.get('portal');
        if (patient && portal != 'staff') {
          if (admintile.TileName === 'Requests') {
            admintile.permission.push(['request-center']);
          }
          else if (admintile.TileName === 'MyNewMessages') {
            admintile.permission.push(['message-center']);
          }

          if (scope.getMhrPermissionsForTile(admintile.TileName) && admintile.IsAllowUserToAdd && scope.checkPremission(admintile.TileName, 'isTile')) {
            scope.bindNewTiles(admintile);
          }
        }

        else if (portal == 'staff') {
          if (admintile.TileName === 'Tasks' || admintile.TileName === 'MyTask') { // MyTask': -> Earlier it was MyTask, Now it is Tasks. Changing for EMPO-6215
            admintile.permission.push(['task-center']);
          }
          if (admintile.IsAllowUserToAdd && scope.checkPremission(admintile.TileName, 'isTile')) {
            scope.bindNewTiles(admintile);
          }
        }
      // refactored EMPO-6534, previous revision head '133e463'
      });
    };

    /* display popup */
    scope.displayPopup = function () {
      $('.add-tile-popup').modal('show');
    };

    /* close popup */
    scope.closePopup = function (tileSelected) {
      $('.add-tile-popup').modal('hide');
    };

    scope.translateTiles = function(item){
      switch (item) {
        case "Quick Links":
          return translate.instant('QUICK_LINKS');
        case "Appointments":
          return translate.instant('APPOINTMENTS_HEADER');
        case "All Appointments":
          return translate.instant('ALL_APPOINTMENTS');
        case "Activity Log":
          return translate.instant('ACTIVITY_LOG');
        case "Requests":
          return translate.instant('REQUESTS');
        case "Medications":
          return translate.instant('MEDICATIONS_MENU');
        case "Allergies":
          return translate.instant('ALLERGIES_LBL');
        case "Conditions":
          return translate.instant('CONDITION_LBL');
        case "Family History":
          return translate.instant('FAMILY_HISTORY');
        case "Social History":
          return translate.instant('SOCIAL_HISTORY');
        case "Procedures":
          return translate.instant('PROCEDURES');
        case "Immunizations":
          return translate.instant('IMMUNIZATIONS');
        case "Weight and Height":
          return translate.instant('WEIGHT_AND_HEIGHT');
        case "Blood Glucose":
          return translate.instant('BLOOD_GLUCOSE');
        case "Blood Pressure":
          return translate.instant('BLOOD_PRESSURE');
        case "Cholesterol":
          return translate.instant('CHOLESTROL');
        case "Test Results":
          return translate.instant('TEST_RESULTS');
        case "Clinical Documents":
          return translate.instant('CLINICAL_DOCS');
        case "Send a Message":
          return translate.instant('SEND_MESSAGE');
        case "Share Access to Patient Record":
          return translate.instant('SHARE_ACCESS_TO_PATU_RECORD');
        case "Add a Physician":
          return translate.instant('ADD_PHYSICIAN');
        case "Add New Allergy":
          return translate.instant('ADD_NEW_ALLERGY');
        case "Add a Location":
          return translate.instant('ADD_LOCATION');
        case "Submit New Request":
          return translate.instant('SUBMIT_NEW_REQUEST');
        case "Update Patient's Address":
          return translate.instant('UPDATE_PATIENTS_ADDRESS');
        case "Update Patient's Phone":
          return translate.instant('UPDATE_USER_PHONE');
        case "Update User's Email":
          return translate.instant('UPDATE_USER_EMAIL');
        case "Update User's Preferences":
          return translate.instant('UPDATE_USER_PREF');
        case "Add New Medication":
          return translate.instant('ADD_NEW_MEDICATION');
        case "Add New Condition":
          return translate.instant('ADD_NEW_CONDITION');
        case "Add New Family History":
          return translate.instant('ADD_NEW_FAMILY_HISTORY');
        case "Add New Social History":
          return translate.instant('ADD_NEW_SOCIAL_HISTORY');
        case "Add New Procedure":
          return translate.instant('ADD_NEW_PROCEDURE');
        case "Add New Immunization":
          return translate.instant('ADD_NEW_IMMUNIZATION');
        case "Add New Weight":
          return translate.instant('ADD_NEW_WEIGHT');
        case "Add New Blood Glucose":
          return translate.instant('ADD_NEW_BLOOD_GLUCOSE');
        case "Add New Blood Pressure":
          return translate.instant('ADD_NEW_BLOOD_PRESSURE');
        case "Add New Cholesterol":
          return translate.instant('ADD_NEW_CHOLESTROL');
        case "View Test Results":
          return translate.instant('VIEW_TEST_RESULTS');
        case "View Clinical Documents":
          return translate.instant('VIEW_CLINICAL_DOCS');

        default:
          return item;
      }
    };

    scope.saveClickPopup = function () {
      // var value = scope.availableTiles;

      angular.forEach(scope.availableTiles, function (tile) {
        if (tile.isCheck) {
          tile.title = scope.translateTiles(tile.title) ? scope.translateTiles(tile.title) : tile.title;
          scope.tiles.push(tile);
        }
      });
      scope.saveUserSettings();
      scope.getAvailableTiles();
      $('.add-tile-popup').modal('hide');
    };

    scope.selectedTile = function () {
      var count = 0;
      angular.forEach(scope.availableTiles, function (availableTile) {
        if (availableTile.isCheck) {
          count++;
        }
      });
      scope.tileSelected = (count > 0);
    };
    //
    scope.searchTileName = '';

    scope.removeTile = function (tile) {
        var tileIndex = scope.tiles.indexOf(tile);
        scope.tilesWarning = translate.instant('LANDING_PAGE_REMOVE_TILES_WARNING');
        scope.removeTileHeader = translate.instant('REMOVE_TILE');
        var dlg = dialog.confirm('confirmDialog', scope.removeTileHeader, scope.tilesWarning);
      dlg.result.then(function () {
        scope.tiles.splice(tileIndex, 1);
        scope.saveUserSettings();
        scope.getAvailableTiles();
      }, function () {});
    };

    scope.bindUserSettingForLandingPage = function () {
      scope.userTiles.portalId = scope.portalId;
      scope.userTiles.tiles = [];
      angular.forEach(scope.tiles, function (tile) {
        if (tile.isDisplayByDefault) {
          scope.userTiles.tiles.push({
            tileName: tile.tileName,
            title: tile.title,
            isDisplayByDefault: tile.isDisplayByDefault,
            isAllowUserToAdd: tile.isAllowUserToAdd,
            isAllowUserToRemove: tile.isAllowUserToRemove,
            isAllowUserToMove: tile.isAllowUserToMove,
            col: tile.col,
            row: tile.row
          });
        }
      });
      return JSON.stringify(scope.userTiles);
    };

    scope.saveUserSettings = function () {
      alertService.clear();
      var data = scope.bindUserSettingForLandingPage();
      var getTiles = LandingPageModuleData;
      getTiles.saveUserTiles(data).then(function () {}, function (response) {
        // alertService.add('danger', response, 2000);
      });
    };

    scope.yesConfirmClick = function () {
      scope.close();
      scope.getAvailableTiles();
      $('.add-tile-popup').modal('hide');
    };

  }]);

}(window.app));
