(function(app) {
'use strict';
  
  /*global generic:false*/
  /* module level function(s) */
  var LandingPageModuleData = function (scope, api, q, generic) {
    this.getDefaultLandingPageTiles = function (portalType, userId) {
      var deferred = q.defer();
      api.getDefaultLandingPageTiles.get({ portalType: portalType, userid: userId, key: 'MedSeek.Portal.Module.LandingPage.Settings' }).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    this.saveUserTiles = function (data) {
      var deferred = q.defer();
      api.userTiles.save(data).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    this.getUserTiles = function (userId) {
      var deferred = q.defer();
      api.userTiles.get().$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    this.getUserTasks = function (roleId, taskType) {
      var myTasks = [];
      var reqBody = {
        'view': 'self',
        'pageSize': 1,
        'pageNumber': 1,
        'taskType': taskType,
        'columnFilters': {},
        'searchText': '',
        'sortField': '',
        'sortDirection': 'Ascending',
        'roleId': roleId ? roleId[0].Id : ''
      };
      var deferred = q.defer();
      if (roleId) {
        api.task_center.getTasks.get({ taskScope: reqBody.view, pageSize: reqBody.pageSize, pageNumber: reqBody.pageNumber, sortDirection: reqBody.sortDirection, taskState: reqBody.columnFilters.TaskState || '', taskType: reqBody.taskType, roleId: reqBody.roleId }, null).$promise.then(function (response) {
          deferred.resolve(response);
        }, function (response) {
          deferred.reject(response.data.developerMessage);
        });
      }
      return deferred.promise;
    };

    this.getUserTasksDiscussion = function (userId) {
      var deferred = q.defer();
      api.task_center.getAllDiscussion.get({ userId: userId }, null).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      // api.task_center.getDiscussions.get({ taskId: taskId, userId: userId }, null).$promise.then(function (response) {
      //  deferred.resolve(response);
      // }, function (response) {
      //  deferred.reject(response.data.developerMessage);
      // });
      return deferred.promise;
    };
  };
  
  var GetLandingPageData = function (messageSvc, q) {
    this.appointments = [];

    this.announcements = [
      { name: 'New Clinic Opens in Riverside', date: '01/20/2014' },
      { name: '$79 Mammagrams in February', date: '01/15/2014' },
      { name: 'Flu Vaccinations are now available!', date: '11/09/2013' },
    ];

    this.activityLogs = [
      { name: 'Your Home Phone Number was changed', changedOn: '2 hours ago' },
      { name: 'Your Weight was updated to 124 lbs', changedOn: 'Yesterday' },
      { name: 'You sent a Secure Message to Dr. Burpeau', changedOn: '1/23/2014' },
      { name: 'You renewed a Prescription for Flonase', changedOn: '1/15/2014' },
    ];

    this.myRequests = [];

    this.iWantToStaffLinks = [
      { img: '', label: 'Create a Portal Invitation' },
      { img: '', label: 'Send a Message to a Patient' }
    ];

    this.getIWantToLinks = function (links, patientName, userPermissionsSvc) {
      var userIWantToLinks = [];
      angular.forEach(links, function (value, key) {
        if (value) {
          if (bindlinks(value, key, patientName, userPermissionsSvc) !== '')
            userIWantToLinks.push(bindlinks(value, key, patientName, userPermissionsSvc));
        }
      });
      return userIWantToLinks;
    };

    this.myMessages = function () {
      var deferred = q.defer();
      var data = { Sort: 'DateSent|desc', Search: undefined, Limit: 3, Position: 1 };
      messageSvc.getMessages('INBOX', data).then(function (response) {
        deferred.resolve(response);
      });
      return deferred.promise;
    };

    this.getNavigationRoute = function (key) {
      var navigations = [];
      navigations.addNewAppointments = 'appointments/schedule-appointment';
      navigations.viewAppointments = 'appointments';
      navigations.viewMyActivityLog = 'notification-center/activities';
      navigations.viewAnnouncements = '';
      navigations.addNewRequests = 'request-center/new-request?type=0';
      navigations.viewRequests = 'request-center';
      navigations.addNewMessages = 'message-center/message/_new';
      navigations.viewMessages = 'message-center/mailbox/inbox';
      navigations.addNewMedications = 'my-health-information/treatment?type=medications&isPopup=true';
      navigations.viewMedications = 'my-health-information/treatment?type=medications';
      navigations.addNewAllergies = 'my-health-information/treatment?type=allergies&isPopup=true';
      navigations.viewAllergies = 'my-health-information/treatment?type=allergies';
      navigations.addNewConditions = 'my-health-information/treatment?type=problems&isPopup=true';
      navigations.viewConditions = 'my-health-information/treatment?type=problems';
      navigations.addNewFamilyHistory = 'my-health-information/medical-history?add=family';
      navigations.viewFamilyHistory = 'my-health-information/medical-history';
      navigations.addNewSocialHistory = 'my-health-information/medical-history?add=social';
      navigations.viewSocialHistory = 'my-health-information/medical-history';
      navigations.addNewProcedures = 'my-health-information/medical-history?add=procedure';
      navigations.viewProcedures = 'my-health-information/medical-history';
      navigations.addNewImmunizations = 'my-health-information/medical-history?add=immunization';
      navigations.viewImmunizations = 'my-health-information/medical-history';
      navigations.viewWeightAndHeight = 'my-health-information/health-tracker/weight-bmi';
      navigations.addNewWeightAndHeight = 'my-health-information/health-tracker/weight-bmi?isPopup=true&type=0';
      navigations.viewBloodGlucose = 'my-health-information/health-tracker/blood-glucose';
      navigations.addNewBloodGlucose = 'my-health-information/health-tracker/blood-glucose?isPopup=true&type=2';
      navigations.viewBloodPressure = 'my-health-information/health-tracker/blood-pressure';
      navigations.addNewBloodPressure = 'my-health-information/health-tracker/blood-pressure?isPopup=true&type=1';
      navigations.viewCholesterol = 'my-health-information/health-tracker/cholesterol';
      navigations.addNewCholesterol = 'my-health-information/health-tracker/cholesterol?isPopup=true&type=3';
      navigations.viewTestResults = 'my-health-information/test-results?type=Test%20Results';
      navigations.viewClinicalDocuments = 'my-health-information/clinical-documents?type=Imported%20Records';
      navigations.viewMyTask = 'task-center';
      navigations.ShareAcces = 'view-edit-profile/share-access';
      navigations.AddPhysician = 'view-edit-profile/patient/addphysician';
      navigations.AddLocation = 'view-edit-profile/patient/addlocation';
      navigations.UpdateUser = 'view-edit-profile?edit=demographics';
      navigations.UpdateUserEmail = 'user-settings';
      navigations.UpdatePhone = 'view-edit-profile?edit=demographics';
      navigations.UpdatePreferences = 'user-settings/preferences';
      navigations.QuickSearch = 'task-center';
      navigations.CreatePortalInvitaion = 'user-management/create-invitation';

      return navigations[key];
    };

    function bindlinks (value, key, patientName, userPermissionsSvc) {
      var link = {};
      var navLink = new GetLandingPageData();
      var name = '';
      switch (key) {
        case 'SendMessage':
          link = { iconClass: 'quick-links_messages', label: 'Send a Message', navigateTo: navLink.getNavigationRoute('addNewMessages') };
          break;
        case 'ShareAcces':
          link = { iconClass: 'quick-links_share-patient-access', label: 'Share Access to Patient Record', navigateTo: navLink.getNavigationRoute('ShareAcces') };
          break;
        case 'AddPhysician':
          link = { iconClass: 'quick-links_physicians', label: 'Add a Physician', navigateTo: navLink.getNavigationRoute('AddPhysician') };
          break;
        case 'AddAllerg':
          link = { iconClass: 'quick-links_allergy', label: 'Add New Allergy', navigateTo: navLink.getNavigationRoute('addNewAllergies') };
          break;
        case 'AddLocation':
          link = { iconClass: 'quick-links_locator', label: 'Add a Location', navigateTo: navLink.getNavigationRoute('AddLocation') };
          break;
        case 'SubmitNewRequet':
          link = { iconClass: 'quick-links_my-requests', label: 'Submit New Request', navigateTo: navLink.getNavigationRoute('addNewRequests') };
          break;
        case 'UpdateAddress':
          link = { iconClass: 'quick-links_update-address', label: "Update Patient's Address", navigateTo: navLink.getNavigationRoute('UpdateUser') };
          break;
        case 'UpdatePhone':
          link = { iconClass: 'quick-links_phone', label: "Update Patient's Phone", navigateTo: navLink.getNavigationRoute('UpdatePhone') };
          break;
        case 'UpdateEmail':
          link = { iconClass: 'quick-links_email', label: "Update User's Email", navigateTo: navLink.getNavigationRoute('UpdateUserEmail') };
          break;
        case 'UpdatePreferences':
          link = { iconClass: 'quick-links_settings', label: "Update User's Preferences", navigateTo: navLink.getNavigationRoute('UpdatePreferences') };
          break;
        case 'AddAllergy':
          link = { iconClass: 'quick-links_allergy', label: 'Add New Allergy', navigateTo: navLink.getNavigationRoute('addNewAllergies') };
          break;
        case 'AddMedication':
          link = { iconClass: 'quick-links_pills', label: 'Add New Medication', navigateTo: navLink.getNavigationRoute('addNewMedications') };
          break;
        case 'AddCondition':
          link = { iconClass: 'quick-links_conditions', label: 'Add New Condition', navigateTo: navLink.getNavigationRoute('addNewConditions') };
          break;
        case 'IWantToAddFamilyHistory':
          link = { iconClass: 'quick-links_family', label: 'Add New Family History', navigateTo: navLink.getNavigationRoute('addNewFamilyHistory') };
          break;
        case 'IWantToAddSocialHistory':
          link = { iconClass: 'quick-links_social-history', label: 'Add New Social History', navigateTo: navLink.getNavigationRoute('addNewSocialHistory') };
          break;
        case 'IWantToAddProcedure':
          link = { iconClass: 'quick-links_procedures', label: 'Add New Procedure', navigateTo: navLink.getNavigationRoute('addNewProcedures') };
          break;
        case 'IWantToAddImmunization':
          link = { iconClass: 'quick-links_immunizations', label: 'Add New Immunization', navigateTo: navLink.getNavigationRoute('addNewImmunizations') };
          break;
        case 'IWantToAddNewWeight':
          link = { iconClass: 'quick-links_weight', label: 'Add New Weight', navigateTo: navLink.getNavigationRoute('addNewWeightAndHeight') };
          break;
        case 'IWantToAddNewBloodGlucose':
          link = { iconClass: 'quick-links_blood-glucose', label: 'Add New Blood Glucose', navigateTo: navLink.getNavigationRoute('addNewBloodGlucose') };
          break;
        case 'IWantToAddNewBloodPressure':
          link = { iconClass: 'quick-links_blood-pressure', label: 'Add New Blood Pressure', navigateTo: navLink.getNavigationRoute('addNewBloodPressure') };
          break;
        case 'IWantToAddNewCholesterol':
          link = { iconClass: 'quick-links_cholesterol', label: 'Add New Cholesterol', navigateTo: navLink.getNavigationRoute('addNewCholesterol') };
          break;
        case 'IWantToViewTestResults':
          link = { iconClass: 'quick-links_test-results', label: 'View Test Results', navigateTo: navLink.getNavigationRoute('viewTestResults') };
          break;
        case 'IWantToViewClinicalDocuments':
          link = { iconClass: 'quick-links_clinical-document', label: 'View Clinical Documents', navigateTo: navLink.getNavigationRoute('viewClinicalDocuments') };
          break;
        case 'QuickSearch':
          if (userPermissionsSvc.userHasPermission(['user-management.users.search.view', 'user-management.patients.search.view'])) {
            link = { iconClass: 'icon_search.png', label: 'Enter a login username, first name, last name, email, patient identifier or SSN to search for a patient or a user.', navigateTo: navLink.getNavigationRoute('QuickSearch') };
            link.toShow = false;
          } else {
            link = '';
          }
          break;
        case 'CreatePortalInvitaion':
          if (userPermissionsSvc.userHasPermissions(['user-management.invitations.create'])) {
            link = { iconClass: 'quick-links_invitation', label: 'Create a Portal Invitation', navigateTo: navLink.getNavigationRoute('CreatePortalInvitaion') };
          } else {
            link = '';
          }
          break;
        case 'SendAMessageToPatient':
          if (userPermissionsSvc.userHasPermissions(['message-center.messages.recipients.users.add'])) {
            link = { iconClass: 'quick-links_messages', label: 'Send a Message', navigateTo: navLink.getNavigationRoute('addNewMessages') };
          } else {
            link = '';
          }
          break;
      }
      if (link === '') {
        return link;
      }
      link.title = key;
      return link;
    }
  };

  var AppointmentData = function (scope, api, q, translate) {
    this.getPatientAppointment = function (patientId, medseekId) {
      var deferred = q.defer();
      api.appointments.getAppointments.get({ patientId: patientId, medseekId: medseekId, isFutureAppointment: 'future' }, null).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    this.getAppointmentDataTemplate = function (data, $filter, isAllAppointments) {
      var template = '<ul class="generic-tile-item">';
      var getTimeZoneTranslation = function(timeZone){
        switch(timeZone.toLowerCase()){
          case "central time":
            return translate.instant('CENTRAL_TIME');
          case "eastern time":
            return translate.instant('EASTERN_TIME');
          case "mountain time":
            return translate.instant('MOUNTAIN_TIME');
          case "pacific time":
            return translate.instant('PACIFIC_TIME');
          default:
            return timeZone;
        }
      };
      if (data && data.length > 0) {
        angular.forEach(data, function (appointment, count) {
          appointment.Status = (appointment.Status && appointment.Status.toLowerCase() === 'active') ? 'Confirmed' : appointment.Status;
          appointment.PatientName = ((appointment.PatientRelationship) && (appointment.PatientRelationship.toLowerCase() == 'self')) ? translate.instant('YOU') : appointment.PatientName;
          if (count < 2) {
            template += '<li class="my-appointments__appointment appointment_' + appointment.style + '"><div class="my-appointments__wrapper">';
            if (appointment.Status.toLowerCase() === 'pending approval') {
              template += '<p class="my-appointments__date">?</p>';
              template += '<div class="my-appointments__text1">';
              if (isAllAppointments) {
                template += '<p class="my-appointments__patientName">' + appointment.PatientName + '</p>';
              }
              template += '<p class="my-appointments__status">' + translate.instant('PENDING_APPROVAL') + '</p>';
              template += '</div>';
            } else {
              template += '<p class="my-appointments__date"><span class="my-appointments__month">' + $filter('date')(appointment.AppointmentDateTimeUTC, 'MMM') + '</span> ';
              template += '<span class="my-appointments__day">' + $filter('date')(appointment.AppointmentDateTimeUTC, 'dd') + '</span></p>';
              template += '<div class="my-appointments__text1">';
              if (isAllAppointments) {
                template += '<p class="my-appointments__patientName">' + appointment.PatientName + '</p>';
              } else {
                template += '<p>' + $filter('date')(appointment.AppointmentDateTimeUTC, 'MM/dd/yyyy') + '</p>';
              }
              template += '<p>' + $filter('date')(appointment.AppointmentDateTimeUTC, 'hh:mm a') + ' ' + getTimeZoneTranslation(appointment.TimeZoneDisplayName) + '</p>';
              template += '</div>';
            }
            template += '<div class="my-appointments__text2">';
            template += '<p>';
            template += (appointment.PhysicianName) ? appointment.PhysicianName : 'Physician Name Not Provided';
            template += '</p>';
            template += '<p>';
            template += (appointment.LocationName) ? appointment.LocationName : 'Location Not Provided';
            template += '</p>';
            template += '<p>';
            template += (appointment.AppointmentTypeName) ? appointment.AppointmentTypeName : 'Appointment Type Not Provided';
            template += '</p>';
            template += '</div>';
            template += '</div></li>';
          }
        });
      } else {
        template += '<p class="no-data">'+translate.instant('NO_APPOINTMENTS')+'</p>';
      }

      template += '</ul>';

      return template;

    };
  };

  var RequestData = function (scope, api, q, translate) {
    this.translateStatus = function(item){
      switch(item.toLowerCase()){
        case 'pending':
          return translate.instant('PENDING');
          break;
        case 'approved':
          return translate.instant('APPROVED');
          break;
        case 'denied':
          return translate.instant('DENIED');
          break;
        case 'complete':
          return translate.instant('COMPLETE');
          break;
        default:
          return item;
          break;
      }
    }

    this.getPatientRequest = function (userId, body) {
      var deferred = q.defer();
      api.requestCenter.getAllPendingRequests.get({ userId: userId, offset: body.criteria.PageNumber, limit: body.criteria.PageSize, sortField: body.criteria.SortField, sortDirection: body.criteria.SortDirection }, body).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    this.getRequestDataTemplate = function (data, $filter,RequestData) {
      var template = '<ul class="generic-tile-item">';
      if (data && data.length > 0) {
        angular.forEach(data, function (myRequest, count) {
          if (count < 5) {
            template += '<li><div class="generic-tile-item_row"><p class="myrequests-item__name tile_entry entry_with_status entry_with_date">';
            template += myRequest.TaskName;
            template += '</p><p class="tile_date">';
            template += $filter('date')(myRequest.DateSent, 'MM/dd/yyyy') + '</p>';
            template += '</p><p class="tile_status ' + myRequest.Status + '">' + RequestData.translateStatus(myRequest.Status) + '</p>';
            template += '</div></li>';
          }

        });
      } else {
        template += '<p class="no-data">'+translate.instant('NO_REQUESTS')+'</p>';
      }
      template += '</ul>';
      return template;
    };
  };

  var UserData = function (scope, api, q, $filter, translate) {
    this.getUserActivityRequest = function (userId, body) {
      var deferred = q.defer();
      api.notificationAuditLog.getActivityDataWithOffSet.save(null, body).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    this.getUserActivityDataTemplate = function (data) {
      var template = '<ul class="generic-tile-item">';
      if (data && data.length > 0) {
        angular.forEach(data, function (activity, count) {
          if (count < 5) {
            template += '<li><div class="generic-tile-item_row">';
            template += '<p class="tile_entry entry_with_timeFrom">' + activity.DataAccessAction + '</p>';
            template += '<p class="tile_timeFrom">' + $filter('date')(activity.ActionDateTime, 'MM/dd/yyyy') + '</p>';
            template += '</div></li>';
          }
        });
      } else {
        template += '<p class="no-data">'+translate.instant('NO_ACTIVITY_LOGS')+'</p>';
      }
      template += '</ul>';
      return template;
    };

    this.getUsersPatient = function (userId) {
      var deferred = q.defer();
      api.user.patients.get({ userid: userId }).$promise.then(function (response) {
        deferred.resolve(response.results);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };
  };

  var PatientMhrData = function (scope, api, q, $filter, translate, generic, myHealthInformation) {
    /* load mhr data for patient */
    this.getPatients = function (userId) {
      var deferred = q.defer();

      api.getpatientsPath.get({ userid: userId }).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    /* load mhr data for patient */
    this.getPatientHealthInformation = function (patientId, patientMrnNo) {
      var deferred = q.defer();

      api.getPatientHealthInformationPath.get({ patientId: patientId, mrn: patientMrnNo }).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    /* load mhr data for patient */
    this.getPatientClinicalDocuments = function (patientId, patientMrnNo) {
      var deferred = q.defer();
      api.getPatientClinicalDocumentsPath.get({ patientId: patientId, medseekId: patientMrnNo }).$promise.then(function (response) {
        deferred.resolve(response);
      }, function (response) {
        deferred.reject(response.data.developerMessage);
      });
      return deferred.promise;
    };

    this.getMhrPermissionByKey = function (permissions, type) {
      var permission;
      if (permissions !== undefined && permissions !== null) {
        angular.forEach(permissions, function (data) {
          if (data.Key.toUpperCase() === type.toUpperCase()) {
            permission = data;
          }
        });
      }
      return permission;
    };

    /* function used to build grid data for clinical information */
    this.buildMhrDataByViewKey = function (dataSet, viewKey) {
      var mappedData = [];
      angular.forEach(dataSet, function (data) {
        if (data.Key.toUpperCase() === viewKey.toUpperCase()) {
          angular.forEach(data.Records, function (record) {
            mappedData.push(record);
          });
        }
      });
      return mappedData;
    };

    this.getTemplateByTileName = function (tileName, data, mhrSetting, translate, $filter) {
      var template = '', dataFormat = '';
      if (mhrSetting) {
        dataFormat = mhrSetting || {};
      }
      switch (tileName.toLowerCase()) {
        case 'Medications'.toLowerCase():
          if (data) {
            if ((data.active.toString() === 'true') || ((data.status || '').toLocaleLowerCase() === 'active')) {
              data.dosage = (data.dosage) || '';
              template = '<p class="tile_entry entry_with_action entry_with_amount"><span class="medication-item__name">' + data.name + '</span></p><p class="tile_amount">' + data.dosage + '</p><p class="tile_action"><a href="" ng-click="renewMedication(' + data.id + ')" >'+(translate.instant('RENEW') || 'Renew')+'</a></p>';
            }
          } else {
            template = '<p class="no-data">'+translate.instant('NO_MEDICATIONS')+'</p>';
          }
          break;
        case 'Allergies'.toLowerCase():
          if (data) {
            template = '<p class="' + tileName.toLowerCase() + '-item__name">' + data.name + '</p>';
          } else {
            template = '<p class="no-data">'+translate.instant('NO_ALLERGIES')+'</p>';
          }
          break;
        case 'Conditions'.toLowerCase():
          if (data) {
            template = '<p class="' + tileName.toLowerCase() + '-item__name">' + data.name + '</p>';
          } else {
            template = '<p class="no-data">'+translate.instant('NO_CONDITIONS')+'</p>';
          }
          break;
        case 'FamilyHistory'.toLowerCase():
          if (data) {
            template = '<p class="' + tileName.toLowerCase() + '-item__name tile_entry entry_with_type">' + data.condition + '</p><p class="tile_type">Relationship: ' + data.relationship + '</p>';
          } else {
            template = '<p class="no-data">'+translate.instant('NO_FAMILY_HISTORY')+'</p>';
          }
          break;
        case 'SocialHistory'.toLowerCase():
          if (data) {
            template = '<p class="' + tileName.toLowerCase() + '-item__name">' + data.type + '</p>';
          } else {
            template = '<p class="no-data">'+translate.instant('NO_SOCIAL_HISTORY')+'</p>';
          }
          break;
        case 'Procedures'.toLowerCase():

          if (data) {
            var settings = _.find(mhrSetting, function (data) { return data.Key == 'Procedures'.toLowerCase(); });
            var dateFormate = (settings) ? settings.DateFormat : '';

            template = '<p class="' + tileName.toLowerCase() + '-item__name tile_entry entry_with_date">' + data.name + '</p> <p class="' + tileName.toLowerCase() + '-item__recieved tile_date"><span class="sr-only">Updated on: </span><span> ' + $filter('mhrDateFilter')(data.date, dateFormate) + '</span></p>';
          } else {
            template = '<p class="no-data">'+translate.instant('NO_PROCEDURES')+'</p>';
          }
          break;
        case 'Immunizations'.toLowerCase():
          if (data) {
            var settings = _.find(mhrSetting, function (data) { return data.Key.toLowerCase() == 'Immunizations'.toLowerCase(); });
            var dateFormate = (settings) ? settings.DateFormat : '';

            template = '<p class="' + tileName.toLowerCase() + '-item__name tile_entry entry_with_date">' + data.name + '</p> <p class="' + tileName.toLowerCase() + '-item__recieved tile_date"><span class="sr-only">Updated on: </span>' + $filter('mhrDateFilter')(data.date, dateFormate) + '</p>';
          } else {
            template = '<p class="no-data">'+translate.instant('NO_IMMUNIZATIONS')+'</p>';
          }
          break;
        case 'TestResults'.toLowerCase():
          if (data) {
            var settings = _.find(mhrSetting, function (data) { return data.Key.toLowerCase() == 'TestResults'.toLowerCase(); });
            var dateFormate = (settings) ? settings.DateFormat : '';

            template = '<p class="' + tileName.toLowerCase() + '-item__name tile_entry entry_with_date">' + data.name + '</p><p class="' + tileName.toLowerCase() + '-item__recieved tile_date"><span class="sr-only">Tested on: </span>' + $filter('mhrDateFilter')(data.date, dateFormate) + '</p>';
          } else {
            template = '<p class="no-data">'+translate.instant('NO_TEST_RECORDS')+'</p>';
          }
          break;
        case 'ClinicalDocuments'.toLowerCase():
          if (data) {
            var settings = _.find(mhrSetting, function (data) { return data.Key.toLowerCase() == 'ImportedRecords'.toLowerCase(); });
            var dateFormate = (settings) ? settings.DateFormat : '';

            template = '<p class="' + tileName.toLowerCase() + '-item__name tile_entry entry_with_type">' + data.displayName + '</p> <p class="' + tileName.toLowerCase() + '-item__recieved tile_type">' + $filter('mhrDateFilter')(data.date, dateFormate) + '</p><p class="tile_entry entry_with_type"> Source: ' + data.source + '</p>';
          } else {
            template = '<p class="no-data">' + translate.instant('NO_CLINICAL_DOCS') + '</p>';
          }
          break;
      }
      return template;
    };

    this.getMhrDataTemplate = function (key, mhrViewKey, patientMhrDetails, patientClinicalDocuments, mhrsettings) {
      var records = [];
      var getHealthInfo = new PatientMhrData({}, api, q, $filter, translate, generic);

      if (patientMhrDetails && key !== 'ClinicalDocuments') {
        records = generic.sortArray(this.buildMhrDataByViewKey(patientMhrDetails, mhrViewKey), 'date', 'desc', true);
      } else {
        records = generic.sortArray(patientClinicalDocuments, 'date', 'desc', true);
      }
      var limit = 5;

      switch (key) {
        case 'ClinicalDocuments':
          limit = 3;
          break;
        case 'Medications':
          var medicationRecord = [];
          for (var medicationRecordIndex = 0; medicationRecordIndex < records.length && medicationRecord.length < 5; medicationRecordIndex++) {
            var data = records[medicationRecordIndex];
            if (data.status === 'Active' || (data.source.indexOf('Patient Entered') === -1 && data.active)) {
              medicationRecord.push(records[medicationRecordIndex]);
            }
          }
          records = medicationRecord;
          break;
      }

      if (key !== 'Medications') {
        records = $filter('limitTo')(records, limit);
      }

      var template = '';

      if (records && records.length > 0) {
        template += '<ul class="generic-tile-item">';
        for (var index in records) {
          var data = getHealthInfo.getTemplateByTileName(key, records[index], mhrsettings, translate ? translate : null, $filter);
          template += '<li>';
          template += '<div class="generic-tile-item_row">';
          template += (data) ? data : '';
          template += '</div>';
          template += '</li>';
          if (index === 1) {
            break;
          }
        }
        template += '</ul>';
      } else {
        // when there are no records
        template += getHealthInfo.getTemplateByTileName(key, null, null, translate ? translate : null);
      }

      return template;
    };

    /* calculate height to show on detailed pane */
    this.getHeightOfPerson = function (returnJustNumber, heightRecord) {
      var heightFeet = this.getHeightInFeet(parseInt(heightRecord.height));
      var heightInches = this.getHeightInInches(parseInt(heightRecord.height));
      var date = heightRecord ? heightRecord.date : new Date();
      if (returnJustNumber === true) {
        return { feet: heightFeet, inches: heightInches, date: date };
      } else {
        return heightFeet + "'" + heightInches + "''";
      }
    };

    /* calculate height to show on detailed pane */
    this.getHeightInFeet = function (heightvalue) {
      return heightvalue ? Math.floor(Math.abs((heightvalue || 0) / 12)) : 0;
    };

    /* calculate height to show on detailed pane */
    this.getHeightInInches = function (heightvalue) {
      return heightvalue ? ((Math.abs(heightvalue) || 0) % 12) : 0;
    };

    /* calculate height to show on detailed pane */
    this.getHeightDiffInInches = function (heightvalue) {
      var heightFeet = this.getHeightInFeet(heightvalue);
      var heightInches = this.getHeightInInches(heightvalue);
      var changesInHeight = (heightvalue < 0) ? '-' : '';
      return changesInHeight + heightFeet + "'" + heightInches + "''";
    };

    /* return valid values rounded to floor */
    this.roundToFloor = function (value, unit) {
      return (value !== undefined && value !== null) ? (unit ? this.prepareReturnString(value, unit) : Math.floor(+value)) : 'N/A';
    };

    /* if some unit is there in round-to-floor method than returns make string with floored value */
    this.prepareReturnString = function (value, unit) {
      if ((Math.floor(+value)) !== 0) {
        return Math.floor(+value) + ' ' + unit;
      } else {
        return 'N/A';
      }
    };

    this.bindMinMaxValue = function (values, type) {
      if (values.length <= 0) {
        return;
      }
      var data = _.filter(values, function (value) {
        return value.Type === type;
      });
      return data;
    };

    var getHealthTrackersVisualTemplate = function (normalcyRanges, currentLevel, latestReading, latestDate, differenceReading, differenceDate, units, translate) {
      var template = '<div class="healthTracker_entry">';
      if (normalcyRanges && currentLevel) {
        template += '<div class="generic-tile-item_row">';
        template += '<p class="tile_entry healthTracker_level"><a href="" tooltip-placement="top normalcy" tooltip-append-to-body="true" tooltip-html-unsafe="' +normalcyRanges+ '">' + translate.instant(currentLevel) + '</a></p>';
        template += '</div>';
      }
      template += '<div class="healthTracker_current"><div class="generic-tile-item_row">';
      template += '<p class=" tile_entry entry_with_date"><span class="healthTracker_reading">' + latestReading + '</span> <span class="healthTracker_measurement">' + units + '</span></p><p class="tile_date"><span class="sr-only">on </span>' + latestDate + '</p></div></div>';
      template += '<div class="healthTracker_current healthTracker_diff"><div class="generic-tile-item_row">';
      template += '<p class="tile_entry entry_with_date"><span class="healthTracker_reading">' + differenceReading + '</span> <span class="healthTracker_measurement">' + units + '</span></p>' + '<p class="tile_date">'+translate.instant('SINCE') + ' ' +differenceDate + '</p>';
      template += '</div></div>';
      template += '</div>';
      return template;
    };

    this.getBloodPressureLevel = function (mhrModuleSettings, latestRecord) {
      if (mhrModuleSettings && mhrModuleSettings.HealthTrackerNormalcyRanges && mhrModuleSettings.HealthTrackerNormalcyRanges.BloodPressureRanges && latestRecord) {
        return this.filterBloodPressurelevel(mhrModuleSettings.HealthTrackerNormalcyRanges.BloodPressureRanges, latestRecord);
      }
    };

    this.filterBloodPressurelevel = function (bloodPressureRanges, latestRecord) {
      if (latestRecord && latestRecord.diastolic && latestRecord.systolic && bloodPressureRanges && bloodPressureRanges.length > 0) {
        var getHealthInfo = new PatientMhrData({}, api, q, $filter, translate, generic);
        var higherValue = (parseInt(latestRecord.systolic) < parseInt(latestRecord.diastolic)) ? 'diastolic' : 'systolic';

        var data = [];
        var systolic = null;
        var diastolic = null;
        for (var i = 0; i < bloodPressureRanges.length && !data.length; i++) {
          if (systolic == null)
            systolic = (Number(latestRecord.systolic) <= Number(bloodPressureRanges[i].SystolicMax) && Number(latestRecord.systolic) >= Number(bloodPressureRanges[i].SystolicMin)) ? i : null;
          if (diastolic == null)
            diastolic = (Number(latestRecord.diastolic) <= Number(bloodPressureRanges[i].DiastolicMax) && Number(latestRecord.diastolic) >= Number(bloodPressureRanges[i].DiastolicMin)) ? i : null;
          if (systolic != null && diastolic != null)
            data.push(systolic > diastolic ? bloodPressureRanges[systolic] : bloodPressureRanges[diastolic]);
        }
        return data;
      }
    };

    this.getMyWeightAndBmiTemplate = function (records, mhrModuleSettings) {
      var template = '<ul>';
      if (records.firstRecord && records.latestRecord) {
        var weightDifference = parseInt(records.latestRecord.weight) - parseInt(records.firstRecord.weight);
        var latestHeightInInches = this.getHeightOfPerson(false, records.latestRecord);
        var heightDiffInInches = this.getHeightDiffInInches(records.firstRecord.heightvalue ? (records.latestRecord.heightvalue - records.firstRecord.heightvalue) : records.latestRecord.heightvalue);

        var mhrSetting = mhrModuleSettings.HealthInformationDateFormat;
        var settings = _.find(mhrSetting, function (data) { return data.Key.toLowerCase() == 'growthcharts'; });
        var dateFormate = (settings) ? settings.DateFormat : '';
        records.latestRecord.date = $filter('mhrDateFilter')(records.latestRecord.date, dateFormate);
        records.firstRecord.date = $filter('mhrDateFilter')(records.firstRecord.date, dateFormate);

        // getHealthTrackersVisualTemplate(normalcyRanges, currentLevel, latestReading, latestDate, differenceReading, differenceDate, units)
        template += '<li class="healthTracker_weight">' + getHealthTrackersVisualTemplate('', '', records.latestRecord.weight, records.latestRecord.date, weightDifference, records.firstRecord.date, translate.instant('WEIGHT_LBS_LBL'), translate) + '</li>';

        template += '<li class="healthTracker_height">' + getHealthTrackersVisualTemplate('', '', latestHeightInInches, records.latestRecord.date, heightDiffInInches, records.firstRecord.date, translate.instant('HEIGHT_LBL'), translate) + '</li>';
      } else {
        template = '<li><div class="healthTracker_entry"><span class="no-data">'+ "{{'NO_WEIGHT_BMI_ERR_MSG'|translate}}" +'</span></div></li>';
      }
      template += '</ul>';
      return template;
    };

    this.getBloodPressureDataTemplate = function (records, mhrModuleSettings) {
      var template = '';
      if (records && records.firstRecord && records.latestRecord && records.latestRecord.systolic && records.latestRecord.diastolic && records.firstRecord.systolic && records.firstRecord.diastolic && mhrModuleSettings) {
        var bloodPressure = this.roundToFloor(records.latestRecord.systolic) + '/' + this.roundToFloor(records.latestRecord.diastolic);
        var fstDiastolic = this.roundToFloor(records.latestRecord.systolic) - this.roundToFloor(records.firstRecord.systolic);
        var lstDiastolic = this.roundToFloor(records.latestRecord.diastolic) - this.roundToFloor(records.firstRecord.diastolic);
        var bloodPressureDiff = fstDiastolic + '/' + lstDiastolic;

        var bloodPressureLevel = this.getBloodPressureLevel(mhrModuleSettings, records.latestRecord);
        bloodPressureLevel = (bloodPressureLevel && bloodPressureLevel[0] && bloodPressureLevel[0].Type) ? getCurrentLevel(bloodPressureLevel[0].Type) : '';
        var normalcyRanges = this.getBloodPressureNormalcyRanges(mhrModuleSettings);

        var mhrSetting = mhrModuleSettings.HealthInformationDateFormat;
        var settings = _.find(mhrSetting, function (data) { return data.Key.toLowerCase() == 'bloodpressures'; });
        var dateFormate = (settings) ? settings.DateFormat : '';
        records.latestRecord.date = $filter('mhrDateFilter')(records.latestRecord.date, dateFormate);
        records.firstRecord.date = $filter('mhrDateFilter')(records.firstRecord.date, dateFormate);

        // getHealthTrackersVisualTemplate(normalcyRanges, currentLevel, latestReading, latestDate, differenceReading, differenceDate, units)
        template = getHealthTrackersVisualTemplate(normalcyRanges, bloodPressureLevel, bloodPressure, records.latestRecord.date, bloodPressureDiff, records.firstRecord.date, 'mmHg', translate);
      }
      return template;
    };

    this.getBloodPressureNormalcyRanges = function (mhrModuleSettings) {
      if (mhrModuleSettings && mhrModuleSettings.HealthTrackerNormalcyRanges && mhrModuleSettings.HealthTrackerNormalcyRanges.BloodPressureRanges) {
        var bloodPressureRanges = mhrModuleSettings.HealthTrackerNormalcyRanges.BloodPressureRanges;
        var template = "<div class='tooltip-table'><table>";
        template += '<thead><tr><th>'+"{{'BLOODPRESSURE_TYPE'|translate}}"+'</th><th>'+"{{'SYSTOLIC_WITHOUT_UNIT'|translate}}"+'</th><th>' + "{{'MHR_HYPERTENSIVE_CRISIS'|translate}}" + '</th></tr></thead>';
        template += '<tbody>';
        angular.forEach(bloodPressureRanges, function (range) {
          template += '<tr>';
          if (getCurrentLevel(range.Type)) {
            template += '<td>' + translate.instant(getCurrentLevel(range.Type)) + '</td>';
          }
          else {
            template += '<td>' + range.Type.replace('BloodPressure', '') + '</td>';
          }
          template += '<td>' + range.SystolicMin + '-' + range.SystolicMax + '</td>';
          template += '<td>' + range.DiastolicMin + '-' + range.DiastolicMax + '</td>';
          template += '</tr>';
        });
        template += '</tbody></table></div>';
        return template;
      }
    };

    this.getCholesterolMaxValue = function (mhrModuleSettings, latestRecord) {
      if (mhrModuleSettings && mhrModuleSettings.HealthTrackerNormalcyRanges && mhrModuleSettings.HealthTrackerNormalcyRanges.CholesterolRanges && latestRecord && latestRecord.level) {
        var getHealthInfo = new PatientMhrData({}, api, q, $filter, translate, generic);
        var data = _.filter(mhrModuleSettings.HealthTrackerNormalcyRanges.CholesterolRanges, function (value) {
          return (getHealthInfo.roundToFloor(latestRecord.level) >= getHealthInfo.roundToFloor(value.Min) && getHealthInfo.roundToFloor(latestRecord.level) <= getHealthInfo.roundToFloor(value.Max));
        });
        return data;
      }
    };

    this.getCholesterolDataTemplate = function (records, mhrModuleSettings) {
      var template = '';
      if (mhrModuleSettings && records.firstRecord && records.latestRecord) {
        var cholesterolMaxValue = this.getCholesterolMaxValue(mhrModuleSettings, records.latestRecord);
        var currentLevel = (cholesterolMaxValue && cholesterolMaxValue[0] && cholesterolMaxValue[0].Type) ? getCurrentLevel(cholesterolMaxValue[0].Type) : '';
        var cholestrolDiff = this.roundToFloor(records.latestRecord.level) - this.roundToFloor(records.firstRecord.level);
        var normalcyRanges = this.getCholesterolNormalcyRanges(mhrModuleSettings);

        var mhrSetting = mhrModuleSettings.HealthInformationDateFormat;
        var settings = _.find(mhrSetting, function (data) { return data.Key.toLowerCase() == 'cholesterols'; });
        var dateFormate = (settings) ? settings.DateFormat : '';
        records.latestRecord.date = $filter('mhrDateFilter')(records.latestRecord.date, dateFormate);
        records.firstRecord.date = $filter('mhrDateFilter')(records.firstRecord.date, dateFormate);

        template = getHealthTrackersVisualTemplate(normalcyRanges, currentLevel, records.latestRecord.level, records.latestRecord.date, cholestrolDiff, records.firstRecord.date, 'mg/dl', translate);
      }
      return template;
    };

    this.getCholesterolNormalcyRanges = function (mhrModuleSettings) {
      if (mhrModuleSettings && mhrModuleSettings.HealthTrackerNormalcyRanges && mhrModuleSettings.HealthTrackerNormalcyRanges.CholesterolRanges) {
        var cholesterolRanges = mhrModuleSettings.HealthTrackerNormalcyRanges.CholesterolRanges;
        var template = "<div class='tooltip-table'><table>";
        template += '<thead><tr><th>'+ "{{'CHOLESTEROL_TYPE'|translate}}" +'</th><th>'+"{{'MIN'|translate}}"+'</th><th>'+"{{'MAX'|translate}}"+'</th></tr></thead>';
        template += '<tbody>';
        angular.forEach(cholesterolRanges, function (range) {
          template += '<tr>';
          if (getCurrentLevel(range.Type)) {
            template += '<td>' + translate.instant(getCurrentLevel(range.Type)) + '</td>';
          }
          else {
           template += '<td>' + range.Type.replace('BloodPressure', '') + '</td>';
          }
          template += '<td>' + range.Min + '</td>';
          template += '<td>' + range.Max + '</td>';
          template += '</tr>';
        });
        template += '</tbody></table></div>';
        return template;
      }
    };

     var getCurrentLevel = function (currentLevel) {
       switch (currentLevel) {
        case 'CholesterolNormal':
        case 'BloodGlucoseNormal':
         return 'MHR_NORMAL' ;
        case 'CholesterolBorderline':
          return 'MHR_BORDERLINE_HIGH';
        case 'CholesterolHigh':
          return 'MHR_HIGH';
         case 'BloodPressureHighStage1':
           return 'MHR_HIGH_BP_STAGE1';
         case 'BloodPressureHighStage2':
           return 'MHR_HIGH_BP_STAGE2';
         case 'BloodPressureHypertensiveCrisis':
           return 'MHR_HYPERTENSIVE_CRISIS';
         case 'BloodPressureLow':
           return 'MHR_LOW';
         case 'BloodPressureNormal':
           return 'MHR_NORMAL';
         case 'BloodPressurePrehypertension':
           return 'MHR_PRE_HYPERTENSION';
         case 'BloodGlucoseAbnormal':
           return 'MHR_ABNORMAL';
      }
    }
    this.getBloodGlucoseLevel = function (mhrModuleSettings, latestRecord) {
      if (latestRecord && latestRecord.glucose && mhrModuleSettings && mhrModuleSettings.HealthTrackerNormalcyRanges && mhrModuleSettings.HealthTrackerNormalcyRanges.BloodGlucoseRanges) {
        var getHealthInfo = new PatientMhrData({}, api, q, $filter, translate, generic);
        var data = _.filter(mhrModuleSettings.HealthTrackerNormalcyRanges.BloodGlucoseRanges, function (value) {
          return (getHealthInfo.roundToFloor(latestRecord.glucose) >= getHealthInfo.roundToFloor(value.Min) && getHealthInfo.roundToFloor(latestRecord.glucose) <= getHealthInfo.roundToFloor(value.Max));
        });
        return data;
      }
    };

    this.getBloodGlucoseTemplate = function (records, mhrModuleSettings) {
      var template = '';
      if (records && records.firstRecord && records.latestRecord && mhrModuleSettings && records.firstRecord.glucose && records.latestRecord.glucose) {
        //records.firstRecord.glucose = records.firstRecord.glucose.replace('mgdl', '');
        //records.latestRecord.glucose = records.latestRecord.glucose.replace('mgdl', '');
        var glucoseLevel = this.getBloodGlucoseLevel(mhrModuleSettings, records.latestRecord);

        var currentLevel = (glucoseLevel && glucoseLevel[0] && glucoseLevel[0].Type)
          ? ((glucoseLevel[0].Type.indexOf('BloodGlucoseAbnormal') > -1) ? getCurrentLevel('BloodGlucoseAbnormal') : getCurrentLevel('BloodGlucoseNormal'))
          : '';

        var glucoseDiff = this.roundToFloor(records.latestRecord.glucose) - this.roundToFloor(records.firstRecord.glucose);
        var normalcyRanges = this.getBloodGlucoseNormalcyRanges(mhrModuleSettings);
        // getHealthTrackersVisualTemplate(normalcyRanges, currentLevel, latestReading, latestDate, differenceReading, differenceDate, units)

        var mhrSetting = mhrModuleSettings.HealthInformationDateFormat;
        var settings = _.find(mhrSetting, function (data) { return data.Key.toLowerCase() == 'bloodglucoses'; });
        var dateFormate = (settings) ? settings.DateFormat : '';
        records.latestRecord.date = $filter('mhrDateFilter')(records.latestRecord.date, dateFormate);
        records.firstRecord.date = $filter('mhrDateFilter')(records.firstRecord.date, dateFormate);

        template = getHealthTrackersVisualTemplate(normalcyRanges, currentLevel, records.latestRecord.glucose, records.latestRecord.date, glucoseDiff, records.firstRecord.date, 'mg/dl', translate);
      }
      return template;
    };

    this.getBloodGlucoseNormalcyRanges = function (mhrModuleSettings) {
      if (mhrModuleSettings && mhrModuleSettings.HealthTrackerNormalcyRanges && mhrModuleSettings.HealthTrackerNormalcyRanges.BloodGlucoseRanges) {
        var bloodGlucoseRanges = mhrModuleSettings.HealthTrackerNormalcyRanges.BloodGlucoseRanges;
        var template = "<div class='tooltip-table'><table>";
        template += '<thead><tr><th>' + "{{'BLOODGLUCOSE_TYPE'|translate}}" + '</th><th>' + "{{'MIN'|translate}}" + '</th><th>' + "{{'MAX'|translate}}" + '</th></tr></thead>';
        template += '<tbody>';
        angular.forEach(bloodGlucoseRanges, function (range) {
          template += '<tr>';

          if (range.Type.indexOf('BloodGlucoseAbnormal') > -1) {
            template += '<td>' + translate.instant(getCurrentLevel('BloodGlucoseAbnormal')) + '</td>';
          } else {
            if (range.Type=='BloodGlucoseNormal') {
              template += '<td>' + translate.instant(getCurrentLevel('BloodGlucoseNormal')) + '</td>';
            }
            else {
              template += '<td>' + range.Type.replace('BloodGlucose', '') + '</td>';
            }
          }
          template += '<td>' + range.Min + '</td>';
          template += '<td>' + range.Max + '</td>';
          template += '</tr>';
        });
        template += '</tbody></table></div>';
        return template;
      }
    };

    this.getHealthTrackerData = function (key, mhrViewKey, patientMhrDetails) {
      var records = [];
      var healthTracker = { };
      records = generic.sortArray(this.buildMhrDataByViewKey(patientMhrDetails, mhrViewKey), 'date', 'desc', true);

      var lastIndex = 0;
      if (records && records.length > 0) {
        healthTracker.latestRecord = angular.copy(records[lastIndex]);
        if (records && records.length >= 2) {
          lastIndex = 1;
        }
        healthTracker.firstRecord = angular.copy(records[lastIndex]);

      }

      return healthTracker;
    };

    this.getHealthTrackersDataTemplate = function (key, mhrViewKey, patientMhrDetails, mhrModuleSettings) {
      var template = '';
      var records = this.getHealthTrackerData(key, mhrViewKey, patientMhrDetails);
      if (mhrViewKey === 'weights') {
        var heightData = [];
        var growthChartRecords = this.getHealthTrackerData(key, 'growthCharts', patientMhrDetails);

        var recordsOfWeights = [];
        var recordsOfGrowthChart = [];
        recordsOfWeights = generic.sortArray(this.buildMhrDataByViewKey(patientMhrDetails, 'weights'), 'date', 'desc', true);
        recordsOfGrowthChart = generic.sortArray(this.buildMhrDataByViewKey(patientMhrDetails, 'growthCharts'), 'date', 'desc', true);

        _.each(recordsOfGrowthChart, function (record) {
          record.date = moment(record.date).format('YYYY-MM-DDTHH:mm:ss');
          recordsOfWeights.push(record);
        });
        recordsOfWeights = recordsOfWeights.sort(function (a, b) {
          return new Date(b.date) - new Date(a.date);
        });
        //records.latestRecord.date will be not if records set is zero of empty object so validating !records.length
        heightData = !(growthChartRecords.latestRecord) ? records :
          ((!records.length || records.length === 0) ? growthChartRecords :
            (myHealthInformation.convertToPreferredTimeZoneDateTime(growthChartRecords.latestRecord.date).getTime() > myHealthInformation.convertToPreferredTimeZoneDateTime(records.latestRecord.date).getTime()) ? growthChartRecords : records);

        var heightDataToDisplay = (name === undefined && heightData.latestRecord) ? heightData.latestRecord : heightData;
        records.latestRecord = records.latestRecord ? records.latestRecord : {};
        records.latestRecord.height = ((heightDataToDisplay.latestRecord) || angular.noop).height;
        records.latestRecord.heightunit = ((heightDataToDisplay.latestRecord) || angular.noop).heightunit;
        records.latestRecord.heightvalue = ((heightDataToDisplay.latestRecord) || angular.noop).heightvalue;
        records.latestRecord.date = ((heightDataToDisplay.latestRecord) || angular.noop).date;

        if (records.firstRecord){
          records.firstRecord.height = ((recordsOfWeights[1]) || angular.noop).height;
          records.firstRecord.heightunit = ((recordsOfWeights[1]) || angular.noop).heightunit;
          records.firstRecord.heightvalue = ((recordsOfWeights[1]) || angular.noop).heightvalue;
          records.firstRecord.date = ((recordsOfWeights[1]) || angular.noop).date;
        }
      }
      if (records.firstRecord && records.latestRecord) {
        template = this.getHealthTrackersTemplateByTileName(key, records, mhrModuleSettings);

      } else {
        template = this.getHealthTrackersTemplateByTileName(key, records);

      }
      return template;
    };

    this.getHealthTrackersTemplateByTileName = function (tileName, records, mhrModuleSettings) {
      var template = '';

      switch (tileName.toLowerCase()) {
        case 'BloodGlucose'.toLowerCase():
          if (mhrModuleSettings && records && records.firstRecord && records.latestRecord) {
            template = this.getBloodGlucoseTemplate(records, mhrModuleSettings);
          } else {
            template = '<p class="no-data healthTracker_entry">'+translate.instant('NO_BLOOD_GLUCOSE')+'</p>';
          }
          break;
        case 'BloodPressure'.toLowerCase():
          if (mhrModuleSettings && records && records.firstRecord && records.latestRecord) {
            template = this.getBloodPressureDataTemplate(records, mhrModuleSettings);
          } else {
            template = '<p class="no-data healthTracker_entry">'+translate.instant('NO_BLOOD_PRESSURE')+'</p>';
          }
          break;
        case 'Cholesterol'.toLowerCase():
          if (mhrModuleSettings && records && records.firstRecord && records.latestRecord) {
            template = this.getCholesterolDataTemplate(records, mhrModuleSettings);
          } else {
            template = '<p class="no-data healthTracker_entry">'+translate.instant('NO_CHOLESTROL_RECORDS')+'</p>';
          }
          break;
        case 'WeightAndHeight'.toLowerCase():
          if (mhrModuleSettings && records && records.firstRecord && records.latestRecord) {
            template = this.getMyWeightAndBmiTemplate(records, mhrModuleSettings);
          } else {
            template = '<p class="no-data healthTracker_entry">' + translate.instant('NO_HEIGHT_WEIGHT_RECORDS') + '</p>';
          }
          break;

      }
      return template;
    };

  };

  var GetDialogServiceTemplates = function () {
    /* method for dialog service footer of confirm */
    this.getConfirmFooter = function () {
      return ' <form name="form">' +
      '<div class="pull-right">' +
      '<button type="button" class="btn btn-default" ng-click="close()">No</button>' +
      '<button type="button" class="btn btn-primary" ng-click="yesConfirmClick()">Yes</button>' +
      '</div>' +
      '</form>';
    };

    /* method for dialog service content of confirm */
    this.getConfirmContent = function () {
      return '<p class="text-align-justify padding" ng-bind-html="this is test"></p>';
    };

  };
  
  app.factory('GetDialogServiceTemplates', function () {
    return GetDialogServiceTemplates;
  });

  app.factory('GetLandingPageData', function () {
    return GetLandingPageData;
  });

  
  app.factory('LandingPageModuleData', ['medseekApi', '$q', '$filter', '$translate', 'generic', function (api, q, $filter, translate, generic) {
    return new LandingPageModuleData({}, api, q, generic);
  }]);
  
  app.factory('PatientMhrDataSvc',['medseekApi','$q','$filter','$translate', 'generic', 'myHealthInformation', function (api, q, $filter, translate, generic, myHealthInformation) {
    return new PatientMhrData({}, api, q, $filter, translate, generic, myHealthInformation);
  }]);

  app.factory('UserDataSvc',['medseekApi','$q','$filter','$translate',function (api, q, $filter, translate) {
    return new UserData({}, api, q, $filter, translate);
  }]);

  app.factory('RequestDataSvc',['medseekApi','$q','$filter','$translate',function (api, q, $filter, translate) {
    return new RequestData({}, api, q, translate);
  }]);

  app.factory('AppointmentDataSvc',['medseekApi','$q','$filter','$translate',function (api, q, $filter, translate) {
    return new AppointmentData({}, api, q, translate);
  }]);

})(window.app);