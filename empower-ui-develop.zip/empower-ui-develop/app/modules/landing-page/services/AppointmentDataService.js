(function (app, angular) {
  app.factory('AppointmentDataService', ['$q', 'medseekApi', function (q, api) {
    return {
      getPatientAppointment: function (patientId, medseekId) {
        if (!medseekId) {
          return q.reject('no medseekId');
        }
        var deferred = q.defer();
        api.appointments.getAppointments.get({
          patientId: patientId,
          medseekId: medseekId,
          isFutureAppointment: 'future'
        }, null).$promise.then(function (response) {
          deferred.resolve(response);
        }, function (response) {
          deferred.reject(response.data.developerMessage);
        });
        return deferred.promise;
      },
      getAppointmentDataTemplate: function (data, $filter, isAllAppointments) {
        var template = '<ul class="generic-tile-item">';
        if (data && data.length > 0) {
          angular.forEach(data, function (appointment, count) {
            appointment.Status = (appointment.Status && appointment.Status.toLowerCase() === 'active') ? 'Confirmed' : appointment.Status;
            appointment.PatientName = ((appointment.PatientRelationship) && (appointment.PatientRelationship.toLowerCase() === 'self')) ? 'You' : appointment.PatientName;
            if (count < 2) {
              template += '<li class="my-appointments__appointment appointment_' + appointment.style + '"><div class="my-appointments__wrapper">';
              if (appointment.Status.toLowerCase() === 'pending approval') {
                template += '<p class="my-appointments__date">?</p>';
                template += '<div class="my-appointments__text1">';
                if (isAllAppointments) {
                  template += '<p class="my-appointments__patientName">' + appointment.PatientName + '</p>';
                }
                template += '<p class="my-appointments__status">' + appointment.Status + '</p>';
                template += '</div>';
              } else {
                template += '<p class="my-appointments__date"><span class="my-appointments__month">' + $filter('date')(appointment.AppointmentDateTimeUTC, 'MMM') + '</span> ';
                template += '<span class="my-appointments__day">' + $filter('date')(appointment.AppointmentDateTime, 'dd') + '</span></p>';
                template += '<div class="my-appointments__text1">';
                if (isAllAppointments) {
                  template += '<p class="my-appointments__patientName">' + appointment.PatientName + '</p>';
                } else {
                  template += '<p>' + $filter('date')(appointment.AppointmentDateTime, 'MM/dd/yyyy') + '</p>';
                }
                template += '<p>' + $filter('date')(appointment.AppointmentDateTime, 'hh:mm a') + ' ' + (appointment.TimeZoneDisplayName) + '</p>';
                template += '</div>';
              }
              template += '<div class="my-appointments__text2">';
              template += '<p>';
              template += (appointment.PhysicianName) ? appointment.PhysicianName : 'Physician Name Not Provided';
              template += '</p>';
              template += '<p>';
              template += (appointment.LocationName) ? appointment.LocationName : 'Location Not Provided';
              template += '</p>';
              template += '<p>';
              template += (appointment.AppointmentTypeName) ? appointment.AppointmentTypeName : 'Appointment Type Not Provided';
              template += '</p>';
              template += '</div>';
              template += '</div></li>';
            }
          });
        } else {
          template += '<p class="no-data">There are no upcoming appointments at this time.</p>';
        }
        template += '</ul>';
        return template;
      }
    };
  }]);
})(window.app, window.angular);
