(function (app) {
  'use strict';
  app.controller('iframeMainCtrl', ['$scope', function (scope) {
    scope.model = {
      routeParams: {}
    };
  }]);
})(window.app);
