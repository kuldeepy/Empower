(function (app) {
  'use strict';
  app.controller('iframeCtrl', ['$scope', '$sce', 'medseekApi', '$http', '$log', 'session', '$keepalive', '$idle', 'MenuService', function (scope, scEscaping, api, http, log, session, keepAlive, idle, MenuService) {
    MenuService.getModuleTitle({ ModuleInstanceId: app.routing.routeParams.moduleInstanceId }).then(function (moduleTitle) {
      app.routing.data.title = moduleTitle;
    });

    if (app.routing.routeParams.moduleInstanceId) {
      var queryObject = {
        moduleInstanceId: app.routing.routeParams.moduleInstanceId
      };
      var patient = session.getObject('patient');
      if (patient) {
        queryObject.contextPatientId = patient.patientId;
      }
      api.iframes.get(queryObject).$promise.then(function (response) {
        if (response.results && response.results.length > 0) {
          var iframe = response.results[0];
          log.debug('iframe', iframe);
          if (iframe.Source) {
            scope.introductionText = iframe.IntroductionText;
            scope.width = iframe.Width;
            scope.height = iframe.Height;
            scope.scrolling = iframe.Scrolling;
            if (iframe.RequestMethod.toUpperCase() === 'GET') {
              scope.source = scEscaping.trustAsResourceUrl(iframe.ParameterizedSourceUrl);
            } else if (iframe.RequestMethod.toUpperCase() === 'POST') {
              scope.source = '';
              var parameters = extractParameters(iframe.ParameterizedSourceUrl);
              postAndDisplayResults(iframe.Source, parameters);
            } else {
              log.warn('unsupported request method', iframe.RequestMethod);
            }
            if (iframe.KeepSessionAlive) {
              keepSessionAlive();
            }
          }
        }
      });
    }

    function extractParameters (parameterizedUrl) {
      if (parameterizedUrl.indexOf('?') === -1) {
        return {};
      }
      return _.object(_.compact(_.map(parameterizedUrl.split('?')[1].split('&'), function (pair) {
        if (pair) {
          return _.map(pair.split('='), function (part) {
            return decodeURIComponent(part);
          });
        }
      })));
    }

    function postAndDisplayResults (url, parameters) {
      log.debug('posting', url, parameters);
      http({
        method: 'POST',
        url: url,
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: $.param(parameters)
      }).success(function (data) {
        log.debug('got post response');
        $('#content-iframe').contents().find('html').html(data);
      }).error(function (data) {
        log.error('error making post request for iframe', data);
      });
    }

    function keepSessionAlive () {
      var PING_INTERVAL = 60;

      log.debug('stopping idle watch');
      idle.unwatch();

      keepAlive._options().http = {
        method: 'PUT',
        url: app.api.root + 'empower/sessions/' + session.get('userId'),
        data: {
          'fullSessionId': session.get('sessionId')
        }
      };
      keepAlive._options().interval = PING_INTERVAL;
      log.info('iframe: starting session keep alive ping', PING_INTERVAL);
      keepAlive.start();

      // stop keepalive when navigating away
      var onlocationChange = scope.$on('$locationChangeStart', function () {
        log.info('iframe: stopping session keep alive ping');
        keepAlive._options().http = null;
        keepAlive.stop();
        log.debug('resuming idle watch');
        idle.watch();
        // deregister event handler
        onlocationChange();
      });
    }

  }]);
})(window.app);
