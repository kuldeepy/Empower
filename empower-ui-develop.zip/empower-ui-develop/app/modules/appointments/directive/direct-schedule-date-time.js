(function (app) {
  'use strict';

  app.directive('directScheduleDateTime', function () {
    return {
      restrict: 'E',
      scope: {
        instruction: '=',
        input: '=',
        output: '='
      },
      templateUrl: app.root + 'modules/appointments/templates/direct-reschedule-date-time.html',
      // controller: 'directRescheduleDateTimeCtrl'
      controller: ['$scope', function (scope) {
        scope.availableDateTime = scope.input;
        scope.morning = [];
        scope.evening = [];

        scope.defaultDate = function () {
          scope.date = new Date(Object.keys(scope.availableDateTime)[0] ? Object.keys(scope.availableDateTime)[0] : null);
        };
        // scope.defaultDate();

        // Disable date selection
        scope.disabled = function (date, mode) {
          var flag = true;
          var format = [];
          switch (mode) {
            case 'day': format = ['MM/DD/YYYY', 'day'];
              break;
            case 'month': format = ['MM/YYYY', 'month'];
              break;
            case 'year': format = ['YYYY', 'year'];
              break;
          }
          _.forEach(scope.availableDateTime, function (dnt) {
            if (moment(date).format(format[0]) === moment(dnt.AppointmentDateTime).format(format[0])
              && (moment(date).isAfter(new Date(), format[1]) || moment(date).isSame(new Date(), format[1]))) {
              flag = false;
            }
          });
          return flag;
        };

        scope.minDate = function () {
          scope.minDate = new Date();
        };
        scope.minDate();

        scope.dateOptions = {
          'year-format': "'yyyy'",
          'starting-day': 1
        };

        scope.segregateTime = function () {
          scope.morning = [];
          scope.evening = [];
          angular.forEach(scope.availableTime, function (time) {
            var utcTime = moment(time);
            if ((utcTime.get('hours') * 60) < 720) {
              scope.morning.push(time);
            } else {
              scope.evening.push(time);
            }
          });
        };

        scope.selectTime = function (time) {
          scope.output = time;
        };

        scope.getAvailableTime = function () {
          scope.availableTime = [];
          scope.output = null;
          _.forEach(scope.availableDateTime, function (dnt) {
            if (moment(dnt.AppointmentDateTime).format('MM-DD-YYYY') === moment(scope.date).format('MM-DD-YYYY')) {
              scope.availableTime.push(dnt.AppointmentDateTime);
            }
          });
        };

      }]
    };
  });

}(window.app));
