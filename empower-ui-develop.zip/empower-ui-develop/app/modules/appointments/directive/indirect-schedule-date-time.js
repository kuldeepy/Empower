(function (app) {
  'use strict';

  app.directive('indirectScheduleDateTime', function () {
    return {
      restrict: 'E',
      scope: {
        input: '=',
        output: '='
      },
      templateUrl: app.root + 'modules/appointments/templates/indirect-schedule-date-time.html',
      controller: 'indirectScheduleDateTimeCtrl'
    };
  });

  app.directive('myMap', function ($timeout) {
    // directive link function

    var link = function (scope, element, attrs) {
      var map, infoWindow;
      var markers = [];
      var directionsService = new google.maps.DirectionsService();
      var directionsDisplay = new google.maps.DirectionsRenderer();

      // init the map
      function initMap () {
        if (map === void 0) {
          $timeout(function () {
            scope.location = scope.appointment.patient.Address1 + ',' + scope.appointment.patient.City + ',' + scope.appointment.patient.ZipCode;
            scope.locationto = scope.appointment.location[0]._address1 + ',' + scope.appointment.location[0]._city + ',' + scope.appointment.location[0]._state + ',' + scope.appointment.location[0]._country;
            $.get('http://maps.googleapis.com/maps/api/geocode/json?address=' + scope.location + '&sensor=false',
              function (data) {
                var fromLatitudeValue = { 'k': data.results[0].geometry.location.lat, 'D': data.results[0].geometry.location.lng };
                var toLatitudeValue = { 'k': scope.appointment.location[0].Latitude, 'D': scope.appointment.location[0].Longitude };
                calcRoute(fromLatitudeValue, toLatitudeValue);
                scope.fromAddressValue = fromLatitudeValue;
                scope.toAddressValue = toLatitudeValue;
              });
          }, 200);
        }
      }

      initMap();
      scope.searchByLocation = function () {
        searchLocation();
      };

      function searchLocation () {
        var locationFrom = (scope.fromAddresDetails) ? scope.fromAddresDetails.geometry.location : scope.fromAddressValue;
        var locationto = (scope.toAddresDetails) ? scope.toAddresDetails.geometry.location : scope.toAddressValue;
        calcRoute(locationFrom, locationto);
      }

      function calcRoute (fromLatitudeValue, toLatitudeValue) {
        var fromLocation = new google.maps.LatLng(fromLatitudeValue.k, (fromLatitudeValue.B || fromLatitudeValue.D));
        var toLocation = new google.maps.LatLng(toLatitudeValue.k, (toLatitudeValue.B || fromLatitudeValue.D));
        var mapOptions = {
          zoom: 4,
          center: fromLocation
        };

        var map = new google.maps.Map(element[0], mapOptions);
        var request = {
          origin: fromLocation,
          destination: toLocation,
          provideRouteAlternatives: true,
          unitSystem: google.maps.UnitSystem.METRIC,
          travelMode: 'DRIVING',
          optimizeWaypoints: true
        };
        directionsDisplay.setMap(map);
        directionsDisplay.setPanel(document.getElementById('directions'));
        directionsService.route(request, function (response, status) {
          if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
          }
        });
      }
    };

    return {
      restrict: 'A',
      template: '<div id="map" class="map"></div>',
      replace: true,
      link: link
    };
  });
}(window.app));
