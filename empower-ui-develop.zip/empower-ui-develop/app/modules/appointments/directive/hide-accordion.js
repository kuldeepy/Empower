(function (app) {
  'use strict';

  app.directive('hideAccordion', ['$timeout', function (timeout) {
    return {
      restrict: 'E',
      scope: {
        checkForClass: '@',
        hidingClass: '@'
      },
      link: function (scope) {
        scope.$watch(function () { return angular.element('.' + scope.checkForClass).length; }, function (newr, old) {
          if (angular.element('.' + scope.checkForClass).length === 0) {
            angular.element('.' + scope.hidingClass).css('display', 'none');
          } else {
            angular.element('.' + scope.hidingClass).css('display', '');
          }
        });
      }
    };
  }]);

}(window.app));
