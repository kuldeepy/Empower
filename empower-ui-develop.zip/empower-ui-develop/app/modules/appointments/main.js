(function (app) {
  'use strict';

  /* module root controller */
  app.controller('appointmentsMainCtrl', ['$scope', 'appointmentService', '$translate', function (scope, appointmentSvc,translate) {
    scope.model = {
      routeParams: {}
    };
    if (scope.portalType === 'patient') {
      scope.appointmentsBreadcrumb = [];
      scope.appointmentDetailBreadcrumb = [
        { name: translate.instant(app.routing.data.title), url: '/appointments/' }
      ];
    } else {
      scope.appointmentsBreadcrumb = [
        { name: app.routing.data.title, url: 'profile'}
      ];
      scope.appointmentDetailBreadcrumb = [
        { name: app.routing.data.title, url: '../profile'}, { name: "Patient's Appointments", url: '../appointments'}
      ];
    }
    scope.appointmentDynamicText = {};
    appointmentSvc.getAllDynamicText().then(function (dynamicTexts) {
      _.forEach(dynamicTexts, function (dynamicText) { scope.appointmentDynamicText[dynamicText.key] = appointmentSvc.dynamicText.replaceToken(dynamicText.textvalue); });
    });

    scope.appntMsPromise = appointmentSvc.moduleSettingsFactory.getModuleSettings('AppointmentRequest').then(function (res) {
      scope.appntMs = res;
      scope.appntMsPromiseResolved = true;
    });

  }]);

})(window.app);
