(function (app) {
  'use strict';
  app.controller('rescheduleAppointmentCtrl', ['$scope', 'appointmentService', 'generalServices', 'scheduleAppointmentSvc', function (scope, appSvc, gs, saSvc) {
    /* variable declarations */
    scope.route = { path: '/modules/appointments/templates/rescheduleAppointment.html', name: 'rescheduleAppointment' };
    scope.steps = this.steps = [{ menu: 'APPOINTMENTS_APPOINTMENT_DATE_AND_TIME' }, { menu: 'APPOINTMENTS_REASON_FOR_RESCHEDULING' }];
    /* Init */
    scope.init = function () {
      appSvc.getDynamicText('RescheduleAppointmentInstructions').then(function (result) {
        scope.rescheduleAppointmentInstructions = result;
      });
      scope.getAppointment();
      scope.bindDynamicForm();
    };
    scope.isIndirect = true;
    scope.isRescheduleAppointment = false;

    /* onFocus wizard function */
    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      flowControl.showNext(false);
      if (scope.stepIndex === 0) {
        scope.currentIndex = 0;
      }

    };

    /* get available appointments for direct scheduling */
    scope.getAvailableAppointments = function (appointment) {
      var location = appointment.LocationId || angular.noop;
      saSvc.getAvailableAppointments(appointment.patient.MedicalRecordNumber,
        (appointment.LocationId), (appointment.physician || angular.noop).FindADoctorId || null, appointment.appointmentType.Id).then(function (availDateAndTime) {
        scope.availableDateTimeInp = availDateAndTime;
      });
    };

    scope.getAppointment = function () {
      appSvc.getAppointment().then(function (appointment) {
        scope.appointment = appointment;
        scope.appointment.AppointmentDate = new Date(appointment.AppointmentDateTime);
        var getAppointmentTypeBody = {
          'parameters': {
            Id: scope.appointment.AppointmentTypeId
          }
        };

        if (scope.appointment.appointmentType.IsDirectScheduleEnabled === true) {
          scope.getAvailableAppointments(appointment);
        }
        scope.isRescheduleAppointment = true;
      });
    };

    /* bind the dynamic form for reschedule */
    scope.bindDynamicForm = function () {
      appSvc.dynamicForm.getDynamicForm('appointmentrequest', 'HospitalRescheduleForm').then(function (form) {
        scope.rescheduleAppointment.formDataModel = {};
        scope.rescheduleAppointment.formDefinition = form;
        _.find(scope.rescheduleAppointment.formDefinition.fields,{name: 'RescheduleReason'}).filters.BlankItem = true;
        scope.rescheduleAppointment.formDefinition.name = '';
        gs.timeout(function () {
          if (scope.rescheduleAppointment) {
            _.forEach(scope.rescheduleAppointment.formDefinition.fields, function (field) {
              if (field.name || field.type) {
                if (field.name.toLowerCase() === 'reschedulereason' && field.type.toLowerCase() === 'dropdown') {
                  field.listItems = _.sortBy(field.listItems, function (item) {
                    return item.name.toLowerCase();
                  });
                }
              }
            });

            scope.rescheduleAppointment.masterForm.$setPristine();
          } else {
            scope.masterForm.$setPristine();
          }
        }, 1000);
      });
    };

    /* event for next click */
    scope.onNext = function (flowControl) {
      scope.fc = flowControl;
      if (scope.stepIndex === 1) {
        var body = {
          appointment: scope.appointment,
          dataModel: scope.rescheduleAppointment.formDataModel,
          isIndirect: scope.isIndirect,
          ScheduleBody: scope.rescheduleAppointment.selectedDateTimeOutput.data,
          directDateTime: scope.rescheduleAppointment.selectedDateTimeOutput
        };
        gs.session.set('rescheduleApp', JSON.stringify(body));
        flowControl.tabComplete();
        return;
      }
      flowControl.next();
    };

    scope.onPrevious = function (flowControl) {
      scope.fc = flowControl;
      flowControl.previous();
    };

  }]);

}(window.app));
