(function (app) {
  'use strict';
  app.controller('cancelAppointmentCtrl', ['$scope', 'dynamicForm', 'generalServices', 'appointmentService', '$translate', function (scope, dynamicForm, gs, apSvc, translate) {
    /* variable declarations */
    scope.route = { path: '/modules/appointments/templates/cancelAppointment.html', name: 'cancelAppointment' };
    scope.steps = this.steps = [{ menu: 'CONFIRM_CANCEL_DIALOG_NAME', displayName : translate.instant('CONFIRM_CANCEL_DIALOG_NAME')}];

    /* Init */
    scope.init = function () {
      apSvc.getDynamicText('CancelAppointmentInstructions').then(function (result) {
        scope.cancelAppointmentInstructions = result;
      });
      apSvc.getAppointment().then(function (appointment) {
        scope.appointment = appointment;
        apSvc.getAppointmentType({ 'parameters': { Id: appointment.AppointmentTypeId } }).then(function (type) {
          if (type && type.length > 0) {
            if (type.length > 0 && type[0].IsDirectScheduleEnabled) {
              scope.directCancel = true;
            } else {
              scope.directCancel = false;
            }
          }
        });
      });
      scope.bindDynamicForm();
    };

    /* bind the dynamic form for cancel */
    scope.bindDynamicForm = function () {
      apSvc.dynamicForm.getDynamicForm('appointmentrequest', 'HospitalCancelForm').then(function (form) {
        scope.cancelAppointment.formDataModel = {};
        scope.cancelAppointment.formDefinition = form;
        if (scope.rescheduleAppointment && scope.rescheduleAppointment.formDefinition) {
          _.forEach(scope.rescheduleAppointment.formDefinition.fields, function (field) {
            if (field.name || field.type) {
              if (field.name.toLowerCase() === 'cancelreason' && field.type.toLowerCase() === 'dropdown') {
                field.listItems = _.sortBy(field.listItems, function (item) {
                  return item.name.toLowerCase();
                });
              }
            }
          });
          scope.cancelAppointment.formDefinition.name = '';
        }
      });
    };

    /* onFocus wizard function */
    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      if (scope.stepIndex === 0) {
        scope.currentIndex = 0;
        scope.stepIndex = 0;
      }
    };

    /* onSubmit wizard function */
    scope.onSubmit = function (flowControl) {
      apSvc.getDynamicText(scope.directCancel === true ? 'DirectCancelSuccessMessage' : 'CancelRequestSuccessMessage').then(function (result) {
        scope.successText = result;
      });

      if (scope.appointment.appointmentType.IsDirectScheduleEnabled === false) {
        if (scope.cancelAppointment.formDataModel.CancelReason.id) {
          scope.appointment.CancelReason = scope.cancelAppointment.formDataModel.CancelReason;
          var cancelBody = {
            'appointmentId': scope.appointment.Id,
            'reasonId': scope.cancelAppointment.formDataModel.CancelReason.id,
            'comments': scope.cancelAppointment.formDataModel.EarliestAvailable,
            'responseType': '',
            'daytimePhone': scope.appointment.DaytimePhone,
            'daytimePhoneExt': scope.appointment.DaytimePhoneExt,
            'generalInformationData': angular.toJson(apSvc.getDynamicFormData(scope.cancelAppointment.formDataModel, scope.cancelAppointment.formDefinition)),
            'generalInformationFormStringData': scope.appointment.GeneralInformationFormStringData,
            'AppointmentTypeFormStringData': angular.toJson(apSvc.getDynamicFormData(scope.cancelAppointment.formDataModel, scope.cancelAppointment.formDefinition))
          };

          apSvc.cancelIndirectAppointment(cancelBody).then(function (result) {
            scope.fc = flowControl;
            flowControl.next();
            scope.stepIndex = 1;
            flowControl.showNext(false);
            flowControl.showPrevious(false);
            flowControl.showCancel(false);
          }, function (error) {
            gs.alertService.clear();
            gs.alertService.add('danger', translate.instant('APPT_UNABLE_TO_CANCEL_MSG'), 0, '', 'alert_page-top');
            scope.$parent.cancel();
          });
        }
      } else {
        var directCancelBody = {
          appointment: scope.appointment,
          medseekId: scope.appointment.patient.MedicalRecordNumber,
          directCancel: true,
          createTaskOnFail: false
        };
        apSvc.cancelExternalAppointment(directCancelBody).then(function (result) {
          scope.fc = flowControl;
          flowControl.next();
          scope.stepIndex = 1;
          flowControl.showNext(false);
          flowControl.showPrevious(false);
          flowControl.showCancel(false);
        }, function (error) {
          gs.alertService.clear();
          gs.alertService.add('danger', translate.instant('APPT_UNABLE_TO_CANCEL_MSG'), 0, '', 'alert_page-top');
          scope.$parent.cancel();
        });

      }
    };

  }]);

}(window.app));
