(function (app) {
  'use strict';

  /* module root controller */
  app.controller('detailsCtrl', ['$scope', 'appointmentService', 'alertService', '$timeout', 'dialogService', 'GetDialogTemplate', 'session', '$location', 'scheduleAppointmentSvc', 'calendarServices', '$translate', function (scope, appointmentSvc, alertSvc, timeout, diag, GetDialogTemplate, session, loc, saSvc, calendarServices, translate) {
    /* page variables */
    var errorIcon = 'danger',
      popupTemplate = new AppointmentPopupTemplates(),
      getTemplateContent = new GetDialogTemplate(diag),
      unableToGetAppointmentDetails = "Unfortunately, we are not able to display the patient's appointment details at this time. Please try again later or contact your healthcare provider if this continues.";

    /* get appointment & set the appointment actions */
    appointmentSvc.getAppointment().then(function (res) {
      if (res.location && res.location.length > 0) {
        if (res.location[0].Latitude && res.location[0].Longitude) {
          var Location = new google.maps.LatLng(res.location[0].Latitude, res.location[0].Longitude),
            mapOptions = { center: Location, zoom: 14, draggable: true, panControl: false, scrollwheel: true, mapTypeId: google.maps.MapTypeId.ROADMAP },
            map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions),
            marker = new google.maps.Marker({
              position: Location,
              map: map,
              title: 'A',
              animation: google.maps.Animation,
            });
        }
      }
      scope.appointment = res;
      scope.appointment.ScheduleBody = JSON.parse(scope.appointment.ScheduleBody);
      scope.addtocalender =  translate.instant('APPOINTMENTS_ADD_TO_CALENDAR');
      scope.removefromcalender =  translate.instant('APPOINTMENTS_REMOVE_FROM_CALENDER');
      scope.daysAway = scope.getDaysAway(); // returning the number of days away.
      scope.numberOfWeeksInMonth = calendarServices.weeksInMonth(new Date(scope.appointment.AppointmentDateTime));
      scope.calendarAppointmentDateTime = moment(scope.appointment.AppointmentDateTime);
      scope.getModuleSettings(scope.appointment);
      scope.setAppointmentStatusStyle(scope.appointment);

    }, function (error) {
      alertSvc.clear();
      if (error !== null) {
        alertSvc.add(errorIcon, unableToGetAppointmentDetails, 0, '', 'alert_page-top');
      }
    });

    scope.portal = session.get('portal');

    /*get module settings*/
    scope.getModuleSettings = function (appointment) {
      appointmentSvc.moduleSettingsFactory.getModuleSettings('AppointmentRequest').then(function (res) {
        scope.appntMs = res;
        scope.getAppointmentActions(appointment, scope.appntMs.GeneralSettings);
      });
    };

    scope.setAppointmentStatusStyle = function (record) {
      record.Status = (loc.search().status.toLowerCase()) ? loc.search().status.toLowerCase() : recored.Status;
      if (record.Status === 'Active') {
        record.Status = translate.instant('APPOINTMENTS_CONFIRM');
      }
      switch (record.Status.toLowerCase()) {
        case 'active':
          record.style = 'confirmed';
          record.Status = translate.instant('CONFIRMED');
          break;
        case 'pending reschedule':
          record.style = 'pending';
          record.Status = translate.instant('PENDING_RESCHEDULE');
          break;
        case 'cancelled':
          record.style = 'cancelled';
          record.Status = translate.instant('CANCELLED');
          break;
        case 'pending cancellation':
          record.style = 'cancelled';
          record.Status = translate.instant('PENDING_CANCELLATION');
          break;

        case 'pending approval':
          record.style = 'pending';
          record.Status = translate.instant('PENDING_APPROVAL');
          break;
        case 'pre-registered':
          record.style = 'confirmed';
          record.Status = translate.instant('PRE_REGISTERED');
          break;

        case 'completed':
          record.style = 'confirmed';
          record.Status = translate.instant('COMPLETED');
          break;
        default:
          break;
      }
    };

    /* close direction dialog and reset map*/
    scope.closeDirectionDialog = function () {
      getTemplateContent.removeDialog('location-map');
      scope.content = undefined;
    };

    /* get appointment actions based on appointment status */
    scope.getAppointmentActions = function (appointment, settings) {
      appointmentSvc.getAppointmentActions(appointment, settings);
    };

    scope.backClick = function () {
      if (session.get('portal') === 'staff') {
        history.back();
      } else {
        window.location.href = '/appointments';
      }
    };

    // Find out the number of days the appointment is away
    scope.getDaysAway = function () {
      var currentDate = new Date();
      var appointmentDate = new Date(scope.appointment.AppointmentDateTime);
      var millisecondsPerDay = 1000 * 60 * 60 * 24;

      var diffDays = Math.round((appointmentDate.getTime() - currentDate.getTime()) / (millisecondsPerDay));

      var daysAwayMessage;

      if (diffDays == 1) {
        daysAwayMessage = translate.instant('TOMORROW');
      } else if (diffDays == 0) {
        daysAwayMessage = translate.instant('CALENDAR_TODAY');
      } else if (diffDays == -1) {
        daysAwayMessage = translate.instant('YESTERDAY');
      } else if (diffDays <= -2) {
        daysAwayMessage = Math.abs(diffDays) + ' ' + translate.instant('DAYSAGO');
      } else {
        // diffDays >= 2
        daysAwayMessage = diffDays + ' ' + translate.instant('DAYSAWAY');
      }

      return daysAwayMessage;
    };

    scope.checkRebookAbility = function (redirectionUrl, appointmentId, appntExternalId, PatientId, LocationId, PhysicianId, $event) {
      if (redirectionUrl === saSvc.rebookUrlName) {
        $event.preventDefault();
        var promises = [];

        /* connection severed check */
        promises.push(saSvc.medseekApi.users.userPatientRelationship.get({ userId: saSvc.getFromSession('userId') }).$promise.then(function (response) {
          response.results.Retval.forEach(function (data) {
            if ((parseInt(saSvc.getFromSession('patient').patientId) === +data.ProfilePatientId) && (data.Status.Name !== 'Enabled')) {
              scope.redirectToScheduleAppointment();
            }
          });
        }));

        /* patient have permission for sechedule appointment check */
        if (appointmentSvc.checkPatientPermission(saSvc.getFromSession('patient'), 'appointments.future.schedule') === 0) {
          scope.redirectToScheduleAppointment();
        }

        /* physician disabled check */
        if (LocationId) {
          promises.push(saSvc.getPatientData('locations', saSvc.getFromSession('patient').patientId).then(function (res) {
            if (!saSvc.getValueById(res[1], LocationId, 'LocationId')) {
              scope.redirectToScheduleAppointment();
            }
          }));
        }

        /* location disabled check */
        if (PhysicianId) {
          promises.push(saSvc.getPatientData('physicians', saSvc.getFromSession('patient').patientId).then(function (res) {
            if (!saSvc.getValueById(res[1], PhysicianId, 'FindADoctorId')) {
              scope.redirectToScheduleAppointment();
            }
          }));
        }

        /* appointment type avialable for selected physician location check */
        promises.push(saSvc.getAppointmentTypes(LocationId, PhysicianId).then(function (response) {
          return response.Retval;
        }));

        saSvc.q.all(promises).then(function (res) {
          /* appointment type check  */
          if (!_.contains(_.pluck(res[3], 'Id'), scope.appointment.AppointmentTypeId.toString())) {
            scope.redirectToScheduleAppointment();
          } else {
            scope.redirectToRebookAppointment(redirectionUrl, appointmentId, appntExternalId, PatientId, LocationId, PhysicianId);
          }
        });
      }
    };

    scope.redirectToScheduleAppointment = function () {
      loc.$$search = {};
      loc.url('appointments/schedule-appointment');
    };
    scope.redirectToRebookAppointment = function (redirectionUrl, appointmentId, appntExternalId, PatientId, LocationId, PhysicianId) {
      saSvc.location = loc;
      loc.url('appointments/' + redirectionUrl + '?id=' + appointmentId + '&externalId=' + appntExternalId +
        '&patientId=' + PatientId + '&locationId=' + LocationId + '&physicianId=' + PhysicianId + '&appointmenttype=' + scope.appointment.AppointmentTypeId);
    };

  }]);

})(window.app);
