(function (app) {
  'use strict';

  /* controller for indirect scheduling of appointment prefered date and time */
  app.controller('indirectScheduleDateTimeCtrl', ['$scope', 'scheduleAppointmentSvc', function (scope, saSvc) {
    scope.output = {};

    saSvc.dynamicText.getDynamicText('appointmentrequest', 'SchedulePreferencesInstructions').then(function (text) {
      scope.preferredDateTimeInstructions = text;
    });

    scope.selelctedSchedule = {};
    scope.selelctedSchedule = angular.copy(scope.input);
    scope.output = { data: scope.selelctedSchedule, nothingChecked: true };

    scope.resetPreferredDayTime = function () {
      _.forEach(scope.output.data.SchedulePreferencesList, function (schedule) {
        schedule.SchedulePreferenceMonday = false;
        schedule.SchedulePreferenceTuesday = false;
        schedule.SchedulePreferenceWednesday = false;
        schedule.SchedulePreferenceThursday = false;
        schedule.SchedulePreferenceFriday = false;
        schedule.SchedulePreferenceSaturday = false;
        schedule.SchedulePreferenceSunday = false;
      });
      scope.output.nothingChecked = true;
    };

    scope.resetPreferredDayTime();

    scope.checkForCheckedCount = function (currentModel) {
      if (currentModel) {
        scope.output.nothingChecked = false;
      } else {
        if (_.find(scope.selelctedSchedule.SchedulePreferencesList, { SchedulePreferenceMonday: true })) {
          scope.output.nothingChecked = false;
        }
        else if (_.find(scope.selelctedSchedule.SchedulePreferencesList, { SchedulePreferenceTuesday: true })) {
          scope.output.nothingChecked = false;
        }
        else if (_.find(scope.selelctedSchedule.SchedulePreferencesList, { SchedulePreferenceWednesday: true })) {
          scope.output.nothingChecked = false;
        }
        else if (_.find(scope.selelctedSchedule.SchedulePreferencesList, { SchedulePreferenceThursday: true })) {
          scope.output.nothingChecked = false;
        }
        else if (_.find(scope.selelctedSchedule.SchedulePreferencesList, { SchedulePreferenceFriday: true })) {
          scope.output.nothingChecked = false;
        }
        else if (_.find(scope.selelctedSchedule.SchedulePreferencesList, { SchedulePreferenceSaturday: true })) {
          scope.output.nothingChecked = false;
        }
        else if (_.find(scope.selelctedSchedule.SchedulePreferencesList, { SchedulePreferenceSunday: true })) {
          scope.output.nothingChecked = false;
        } else {
          scope.output.nothingChecked = true;
        }
      }
    };

  }]);

})(window.app);
