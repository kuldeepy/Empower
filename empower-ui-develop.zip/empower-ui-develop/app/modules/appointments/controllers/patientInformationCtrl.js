(function (app) {
  'use strict';

  /* schedule appointment patient Information controller */
  app.controller('patientInformationCtrl', ['$scope', 'scheduleAppointmentSvc', 'alertService', 'medseekApi', '$translate', function (scope, aSvc, alertSvc, api, translate) {
    scope.steps = this.steps = [{ menu: 'DEMOGRPAHICS_STEP' }, { menu: 'INSURANCE' }];
    scope.route = {
      path: '/modules/appointments/templates/patient-information.html',
      name: 'patientInformation'
    };
    scope.settings = {};
    scope.patientDemographicsStatus = 'Not Provided';
    scope.patientInsuranceStatus = 'Not Provided';
    scope.insuranceInfo = {};

    scope.createPiSteps = function (flowControl) {
      if (scope.saPatDemoPermission.IsEnabled === false) {
        scope.steps = this.steps = [{ menu: translate.instant('INSURANCE') }];
        scope.settings.ptInsIndex = 0;
      }
      else if (scope.saInsTnfoPermission.IsEnabled === false) {
        scope.steps = this.steps = [{ menu: translate.instant('DEMOGRPAHICS_STEP') }];
        scope.settings.ptDemoIndex = 0;
      } else {
        scope.steps = this.steps = [{ menu: translate.instant('DEMOGRPAHICS_STEP') }, { menu: translate.instant('INSURANCE') }];
        scope.settings.ptDemoIndex = 0;
        scope.settings.ptInsIndex = 1;
      }
      flowControl.changeSteps(2, scope.steps);
      flowControl.changeFlowControl();
    };

    scope.createPiStepsOnce = _.once(scope.createPiSteps);

    scope.onFocus = function (flowControl) {
      scope.createPiStepsOnce(flowControl);
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      scope.fc = flowControl;
      if (scope.stepIndex === 0) {
        scope.currentIndex = 0;
        scope.stepIndex = 0;
      }
      scope.patientData = aSvc.getFromSession('selectedPatient');
      scope.getInsurance();
    };

    // scope.patientData = aSvc.getFromSession('selectedPatient');
    // scope.getInsurance();

    /* get call when wizard opens  */
    scope.init = function () {
      scope.getEnrollModuleSettings();
      scope.getProfileModuleSettings();
      // scope.getInsurance();
      scope.portalType = aSvc.getFromSession('portal');
    };

    scope.getPatientDemographicsForm = function (id) {
      aSvc.getProfilePatientDemographicsForm(id).then(function (response) {
        scope.verifyDemographicsForm = response.verifyDemographicsForm;

      });
    };

    scope.getEnrollModuleSettings = function () {
      aSvc.getEnrollModuleSettings().then(function (response) {
        scope.enrollModuleSettings = response.enrollModuleSettings;
      });
    };

    scope.getProfileModuleSettings = function () {
      aSvc.getProfileModuleSettings().then(function (response) {
        scope.profileModuleSettings = response.profileModuleSettings;
        scope.getPatientDemographicsForm(scope.profileModuleSettings.ConnectWithNewPatientVerifyDemographicsFormId);
      });
    };

    scope.incorrectDemographicInformation = function () {
      if (scope.enrollModuleSettings.ReportIncorrectDemographics) {
        scope.editPatientDemographicsForm = angular.copy(scope.verifyDemographicsForm);

        if (scope.patientInformation.patientData.Country.toString() === '103') {
          var stateField = _.find(scope.editPatientDemographicsForm.fields, { name: 'State' });
          stateField.filters.href = 'empower/countries/103/states';
          var zipField = _.find(scope.editPatientDemographicsForm.fields, { name: 'ZipCode' });
          zipField.filters.href = '103';
          setTimeout(function () {
            scope.demographicsData = angular.copy(scope.patientInformation.patientData);
            aSvc.dialogService.show('editDemographics');
          }, 1000);

        } else {
          scope.demographicsData = angular.copy(scope.patientInformation.patientData);
          aSvc.dialogService.show('editDemographics');
        }

        setTimeout(function () {
          scope.editDemographics.$setPristine();
        }, 500);
      } else {
        var callBack = aSvc.dialogFactory.create('patientInformationNotCorrectDialog', translate.instant('INFO_NOT_CORRECT'));
      }
    };

    /* method for incorrect demographic information */
    scope.updateDemographics = function (flowControl) {
      aSvc.getProfilelookUp().then(function (response) {
        scope.lookUps = response;
        if (scope.demographicsData.PortalUserRelationships) {
          scope.demographicsData.RelationshipToPatient = _.find(scope.lookUps, { Name: scope.demographicsData.PortalUserRelationships.RelationshipClassification });
        }
        aSvc.updateDemographics(scope.demographicsData, scope.profileModuleSettings.RequireApprovalForDemographicsUpdate).then(function (response) {
          scope.patientInformation.patientDemographicsStatus = 'Updated';
          if (response.requireApproval !== true) {
            scope.patientInformation.patientData = null;
            aSvc.timeout(function () {
              scope.patientInformation.patientData = response;
            }, 10);
          }
        });
      });
    };

    // scope.piContent = aSvc.dialog.getTemplate('addInsurance', 'Edit Insurance', aSvc.addInsurance, '');

    /* openAddInsurance */
    scope.openAddInsurance = function () {
      scope.insuranceLable = translate.instant('ADD_INSURANCE');
      aSvc.dialog.showDialog('addInsurance');
      scope.$broadcast('isEditedInsurance', { isEdited: false });
    };

    /* openAddInsurance */
    scope.openEditInsurance = function (selectedInsurance) {
      scope.insuranceLable = translate.instant('SR_EDIT_INSURANCE');
      scope.selectedParentInsurence = selectedInsurance;
      scope.$broadcast('isEditedInsurance', { isEdited: true, selectedInsurance: selectedInsurance });
      aSvc.dialog.showDialog('addInsurance');
    };

    /* openDeleteInsurance */
    scope.deleteInsurance = function (selectedInsurance) {

      aSvc.dialogFactory.confirm('confirmDialog', translate.instant('DELETE_INSURANCE'), translate.instant('PATIENT_MANAGEMENT_PROMPT_DELETE_INSURANCE', { FirstName: scope.patientInformation.patientData.FirstName })).result.then(function () {
        api.patient_management.insuranceById.delete({ patientId: selectedInsurance.PatientId, insuranceId: selectedInsurance.PayerId, id: selectedInsurance.Id, isLinked: false }).$promise.then(function (response) {
          alertSvc.add('success', translate.instant('PATIENT_MANAGEMENT_DELETED_PROFILE_COMPONENT_SUCCESS_MSG', { PatientName: scope.patientInformation.patientData.FirstName, type: 'Insurance' }), 20000);
          scope.getInsurance(); // reload grid
        }, function (error) {
          alertSvc.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_DELETE_INSURANCE'), 20000);
        });
      });
    };

    /* method to getInsurance  */
    scope.getInsurance = function () {
      if (scope.patientData || scope.patientInformation.patientData) {
        aSvc.getInsurance((scope.patientData || scope.patientInformation.patientData).Id).then(function (response) {
          scope.patient = { insurance: response };
          if ((scope.saInsTnfoPermission || scope.patientInformation.saInsTnfoPermission).IsRequired) {
            if (scope.patient.insurance.length > 0) {
              if (scope.patientInformation) {
                scope.patientInformation.insuranceInfo.isAddInsuranceNextBtnEnabled = false;
              } else {
                scope.insuranceInfo.isAddInsuranceNextBtnEnabled = false;
              }
            } else {
              if (scope.patientInformation) {
                scope.patientInformation.insuranceInfo.isAddInsuranceNextBtnEnabled = true;
              } else {
                scope.insuranceInfo.isAddInsuranceNextBtnEnabled = true;
              }
            }
          } else {
            if (scope.patientInformation) {
              scope.patientInformation.insuranceInfo.isAddInsuranceNextBtnEnabled = false;
            } else {
              scope.insuranceInfo.isAddInsuranceNextBtnEnabled = false;
            }
          }
        });
      }
    };

    scope.$on('CountryChanged', function (event, item) {
      var stateField = _.find(scope.editPatientDemographicsForm.fields, { name: 'State' });
      stateField.filters.href = 'empower/countries/' + item.id + '/states';
      scope.demographicsData.ZipCode = '.';
      setTimeout(function () {
        scope.demographicsData.ZipCode = '';
      });
    });

    /* method for incorrect demographic information */
    scope.cancelEditDemographics = function (flowControl) {
      if (scope.editDemographics.$dirty) {
        aSvc.dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG')).result.then(function () {
          scope.closeEditDemographics();
        });
      } else {
        scope.closeEditDemographics();
      }
    };

    scope.closeEditDemographics = function () {
      scope.editPatientDemographicsForm = null;
      scope.demographicsData = null;
      aSvc.dialogService.hide('editDemographics');
    };

    /* onPrevious wizard function */
    scope.onPrevious = function (flowControl) {
      switch (scope.stepIndex) {
        case 0:
          flowControl.previous();
          break;
      }
    };

    scope.setPatDemoStatus = function (status) {
      scope.patientDemographicsStatus = (aSvc.getFromSession(aSvc.dsn.patientDemographicsStatus) || scope.patientDemographicsStatus);
      scope.patientDemographicsStatus = scope.patientDemographicsStatus === 'Not Provided' ? status : scope.patientDemographicsStatus;
      aSvc.setToSession(aSvc.dsn.patientDemographicsStatus, scope.patientDemographicsStatus);
    };

    scope.setInsuranceStatus = function (status) {
      scope.patientInsuranceStatus = (aSvc.getFromSession(aSvc.dsn.patientInsuranceStatus) || scope.patientInsuranceStatus);
      scope.patientInsuranceStatus = scope.patientInsuranceStatus === 'Not Provided' ? status : scope.patientInsuranceStatus;
      aSvc.setToSession(aSvc.dsn.patientInsuranceStatus, scope.patientInsuranceStatus);
    };

    /* onPrevious wizard function */
    scope.onNext = function (flowControl) {
      switch (scope.stepIndex) {
        case 0: flowControl.tabComplete();
          break;
      }
    };

    /*to get date*/
    scope.getDate = function (parameter) {
      if (parameter) {
        return (new Date(parameter));
      }
    };
  }]);

})(window.app);
