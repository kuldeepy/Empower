'use strict';

var AppointmentPopupTemplates = function () {
  this.getLocationMap = function () {
    /* jshint ignore:start */
    return '<div ng-include="\'/modules/appointments/templates/location-map.html\'"></div>';
  /* jshint ignore:end */
  };

};
