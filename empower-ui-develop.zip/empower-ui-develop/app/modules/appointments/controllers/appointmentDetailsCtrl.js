(function (app) {
  'use strict';

  /* schedule appointment appointment details controller */
  app.controller('appointmentDetailsCtrl', ['$scope', 'scheduleAppointmentSvc', '$translate', function (scope, saSvc, translate) {
    scope.steps = this.steps = [{ menu: 'PHYSICIAN', key: 'Physician' }, { menu: 'LOCATION', key: 'Location' }, { menu: 'APPOINTMENTS_APPOINTMENT_TYPE', key: 'Appointment Type' }, { menu: 'PREF_DATE_OR_TIME', key: 'Preferred Date/Time' }];
    scope.route = {
      path: '/modules/appointments/templates/appointment-details.html',
      name: 'appointmentDetails'
    };
    scope.phyCheckPromiseResolved = false;
    scope.locCheckPromiseResolved = false;
    scope.createStepOnce = function (flowControl) {
      if (scope.saPhyPermission.Order === 0) {
        var data = scope.steps = this.steps = [{ menu: translate.instant('PHYSICIAN'), key: 'Physician' }, { menu: translate.instant('LOCATION'), key: 'Location' }, { menu: translate.instant('APPOINTMENTS_APPOINTMENT_TYPE'), key: 'Appointment Type' }, { menu: translate.instant('PREF_DATE_OR_TIME'), key: 'Preferred Date/Time' }];
        flowControl.changeSteps(1, data);
      }
      else if (scope.saLocPermission.Order === 0) {
        var data = scope.steps = this.steps = [{ menu: translate.instant('LOCATION'), key: 'Location' }, { menu: translate.instant('PHYSICIAN'), key: 'Physician' }, { menu: translate.instant('APPOINTMENTS_APPOINTMENT_TYPE'), key: 'Appointment Type' }, { menu: translate.instant('PREF_DATE_OR_TIME'), key: 'Preferred Date/Time' }];
        flowControl.changeSteps(1, data);
      }

      if (scope.saPhyPermission.IsEnabled === false) {
        var data = scope.steps = this.steps = [{ menu: translate.instant('LOCATION'), key: 'Location' }, { menu: translate.instant('APPOINTMENTS_APPOINTMENT_TYPE'), key: 'Appointment Type' }, { menu: translate.instant('PREF_DATE_OR_TIME'), key: 'Preferred Date/Time' }];
        flowControl.changeSteps(1, data);
      }

      else if (scope.saLocPermission.IsEnabled === false) {
        var data = scope.steps = this.steps = [{ menu: translate.instant('PHYSICIAN'), key: 'Physician' }, { menu: translate.instant('APPOINTMENTS_APPOINTMENT_TYPE'), key: 'Appointment Type' }, { menu: translate.instant('PREF_DATE_OR_TIME'), key: 'Preferred Date/Time' }];
        flowControl.changeSteps(1, data);
      }
      flowControl.changeFlowControl();

    };

    scope.createStep = _.once(scope.createStepOnce);

    scope.apiKeys = { physician: 'physicians', location: 'locations' };

    scope.debouncedFocus = _.debounce(function (flowControl) {
      scope.createStep(flowControl);
      scope.stepIndexing();
      scope.saPatient = saSvc.getFromSession(saSvc.dsn.selectedPatient);

      scope.getStepData(scope.saPatient, 0);
    }, 1);

    scope.setLocationPhysicianForRebook = function () {
      if (!scope.selectedPhysicianId && (scope.physicians || scope.appointmentDetails)) {
        scope.selectedPhysicianId = (saSvc.getValueById((scope.physicians || scope.appointmentDetails.physicians), saSvc.location.$$search.physicianId, 'FindADoctorId') || angular.noop).FindADoctorId;
      }
      if (!scope.selectedLocationId && (scope.locations || scope.appointmentDetails)) {
        if (scope.indexVar.Location === 0) {
          var propName = 'LocationId';
        } else {
          var propName = 'BaseId';
          if (scope.selectedPhysicianId === '0') {
            var propName = 'LocationId';
          }
        }
        scope.selectedLocationId = scope.indexVar.Location === 0 ? (saSvc.getValueById((scope.locations || scope.appointmentDetails.locations), saSvc.location.$$search.locationId, propName) || angular.noop).LocationId : +saSvc.location.$$search.locationId;
      }
    };

    scope.setRebookAppointmentType = function (appointmentTypeId) {
      scope.getAppointmentTypesPromise.then(function () {
        scope.appointmentDetails.selectedAppointmentType = _.find(scope.appointmentTypes, function (appnt) { return +appnt.Id === +appointmentTypeId; });
        scope.appointmentDetails.changeAppointmentType(scope.appointmentDetails.selectedAppointmentType);
      });
    };

    scope.stepIndexing = function () {
      scope.physicianIndex = _.findIndex(scope.steps, { key: 'Physician' });
      scope.locationIndex = scope.physicianIndex === 0 ? 1 : 0;
      scope.indexVar = {};
      _.forEach((scope.steps || scope.appointmentDetails.steps), function (val, key) {
        scope.indexVar[val.key] = key;
      });(scope.setDymaicStepIndexes || scope.appointmentDetails.setDymaicStepIndexes)(scope.indexVar);
    };

    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      if (scope.stepIndex === 0) {
        scope.currentIndex = 0;
        scope.stepIndex = 0;
      }
      scope.debouncedFocus(flowControl);
    };

    /* reset model of location on next step if physician changes and vice-versa */
    scope.resetAlternateModel = function (model, sessionKeyName) {
      scope[model] = undefined;
      scope.appointmentDetails.phyCheckPromiseResolved = false;
      scope.appointmentDetails.locCheckPromiseResolved = false;
      scope.appointmentDetails.locationIsNotLinked = false;
      scope.appointmentDetails.physicianIsNotLinked = false;
      /* clearing it from session as well */
      saSvc.session.clear(sessionKeyName);
    };

    scope.getStepData = function (selectedPatient, index) {
      return saSvc.getPatientData(scope.apiKeys[(scope.appointmentDetails || scope).steps[index].key.toLowerCase()], selectedPatient.Id).then(function (response) {
        scope[response[0]] = saSvc.getLogicalData(response[1]);
        if (index === 0) { scope.setData(); }
        /* rebook condition */
        if ((saSvc.location.$$search.locationId || saSvc.location.$$search.physicianId) && app.routeParams[0] === saSvc.rebookUrlName) {
          scope.setLocationPhysicianForRebook();
        }
      }, saSvc.callFailure);
    };

    // scope.checkPrimaryPhysician = function (phy) {
    //  scope.selectedPhysicianId = phy.IsPrimary === true && phy.IsApproved === true && !scope.selectedPhysicianId ? phy.FindADoctorId : scope.selectedPhysicianId;
    // };

    scope.checkPrimaryPhysicianLocation = function (loc) {
      if (!scope.selectedLocationId) {
        scope.selectedLocationId = loc.IsPrimary === true && (!scope.selectedLocationId || !scope.appointmentDetails.selectedLocationId) ? loc.Id : (scope.selectedLocationId || scope.appointmentDetails.selectedLocationId);

      }
    };

    // scope.checkPrimaryLocation = function (loc) {
    //  scope.selectedLocationId = loc.IsDefault === true && !scope.selectedLocationId ? loc.LocationId : scope.selectedLocationId;
    // };

    /* get call when wizard opens  */
    scope.setData = function () {
      scope.stepIndexing();
      scope.selectedPhysicianId = (saSvc.getFromSession(saSvc.dsn.selectedPhysician) || angular.noop).FindADoctorId;
      scope.selectedLocationId = (saSvc.getFromSession(saSvc.dsn.selectedLocation) || angular.noop).Id;
      if (scope.selectedPhysicianId || scope.selectedLocationId) {
        saSvc.getNextStepData(scope).then(function (response) {
          scope[response[0]] = response[1];
          /* get appointment types by location and/or physician on refresh */
          if ((scope.stepIndex == 2) && ((scope.currentIndex || scope.appointmentDetails.currentIndex) == 1)) {
            scope.getApppointmentTypes(scope.selectedLocationId, scope.selectedPhysicianId);
          }
        }, saSvc.callFailure);
      }
    };

    scope.getModelValue = function (val) {
      scope.selectedPhysicianId = (scope.selectedPhysicianId) ? scope.selectedPhysicianId : scope.appointmentDetails.selectedPhysicianId;
    };

    /* get Apppointment Types according to physciain and/or Location */
    scope.getApppointmentTypes = function (locationId, physicianId) {
      scope.getAppointmentTypesPromise = saSvc.getAppointmentTypes(locationId, physicianId).then(function (response) {
        scope.appointmentTypes = response.Retval;
      });
    };

    /* event for change appointment type */
    scope.changeAppointmentType = function (appointment) {
      scope.directPreferredDateAndTIme = null;
      var getAppointmentTypeBody = {
        'parameters': {
          Id: appointment.Id
        }
      };
      saSvc.getAppointmentType(getAppointmentTypeBody).then(function (type) {
        if (type && type.length > 0) {
          scope.selectedAppointmentTypeDescription = type[0];
          scope.bindAppointmentForm(type[0].FormId);
          if (scope.selectedAppointmentTypeDescription.IsDirectScheduleEnabled === true) {
            scope.getAvailableAppointments();
          }
        }
      });
    };

    /* get available appointments for direct scheduling */
    scope.getAvailableAppointments = function () {
      var selectedPhysicianId = (saSvc.getFromSession(saSvc.dsn.selectedPhysician) || angular.noop).FindADoctorId;
      var selectedLocationId = (saSvc.getFromSession(saSvc.dsn.selectedLocation) || angular.noop).LocationId || (saSvc.getFromSession(saSvc.dsn.selectedLocation) || angular.noop).BaseId;
      scope.availableDateTimeInp = null;
      saSvc.getAvailableAppointments(scope.saPatient.MedseekId, selectedLocationId, selectedPhysicianId, scope.selectedAppointmentTypeDescription.Id).then(function (availDateAndTime) {
        saSvc.timeout(function () { scope.availableDateTimeInp = availDateAndTime; });
      });
    };

    /* bind the dynamic form for new appointment */
    scope.bindAppointmentForm = function (id) {
      scope.addAppointmentDataModel = {};
      saSvc.getDynamicFormById(id, true).then(function (form) {
        scope.addAppointmentForm = form;
        scope.addAppointmentForm.name = '';
      });
    };

    /* onPrevious wizard function */
    scope.onPrevious = function (flowControl) {
      switch (scope.stepIndex) {
        case 1:
          flowControl.previous();
          break;
        case 2:
          flowControl.previous();
          break;
        case 3:
          if (!scope.appointmentDetails.selectedAppointmentType) { scope.getApppointmentTypes(scope.selectedLocationId, scope.selectedPhysicianId); }
          flowControl.previous();
          break;
      }
    };

    /* onPrevious wizard function */
    scope.onNext = function (flowControl, callFor) {
      switch (callFor) {
        case 0: scope.setSessioData(scope.stepIndex);
          saSvc.getNextStepData(scope).then(function (response) {
            scope[response[0]] = response[1];
            /* rebook conditions */
            if ((saSvc.location.$$search.locationId || saSvc.location.$$search.physicianId) && app.routeParams[0] === saSvc.rebookUrlName) {
              scope.setLocationPhysicianForRebook();
            }
            flowControl.next();
          }, saSvc.callFailure);
          break;
        case 1:
          scope.setSessioData(scope.stepIndex);
          if (scope.appointmentDetails.dataForAdding) {
            scope.addUnlinkedData().then(function () {
              scope.appointmentDetails.dataForAdding = null;
              scope.appointmentDetails.phyCheckPromiseResolved = false;
              scope.appointmentDetails.locCheckPromiseResolved = false;
              scope.appointmentDetails.locationIsNotLinked = false;
              scope.appointmentDetails.physicianIsNotLinked = false;
              flowControl.next();
            }, function () {});
          } else {
            flowControl.next();
            /* rebook condition */
            if (saSvc.location.$$search.appointmenttype && app.routeParams[0] === saSvc.rebookUrlName) {
              scope.setRebookAppointmentType(saSvc.location.$$search.appointmenttype);
            }
          }
          break;
        case 'Appointment Type':
          var contactInfo = _.find(scope.appointmentDetails.addAppointmentForm.fields, function (field) { return field.name === 'ContactInformation'; }).listItems;
          var additionalInfo = _.find(scope.appointmentDetails.addAppointmentForm.fields, function (field) { return field.name === 'AdditionalInformationData'; });
          var isNewPatient = _.find(scope.appointmentDetails.addAppointmentForm.fields, function (field) { return field.name === 'IsNewPatient'; });
          var haveReferral = _.find(scope.appointmentDetails.addAppointmentForm.fields, function (field) { return field.name === 'HaveReferral'; });
          scope.sessionData = {
            selectedAppointmentType: scope.appointmentDetails.selectedAppointmentTypeDescription, selectedAppointmentData: scope.appointmentDetails.addAppointmentDataModel,
            selectedAppointmentXml: [
              {
                key: 'Pref. method of contact',
                value: scope.appointmentDetails.addAppointmentDataModel.ContactInformation ?
                  contactInfo[scope.appointmentDetails.addAppointmentDataModel.ContactInformation] : 'Not available'
              },
              {
                key: 'Additional Information',
                value: scope.appointmentDetails.addAppointmentDataModel[additionalInfo.name] ? scope.appointmentDetails.addAppointmentDataModel[additionalInfo.name] : 'Not available'
              },
              {
                key: 'Referral',
                value: (scope.appointmentDetails.addAppointmentDataModel[haveReferral.name]) ? (parseInt(scope.appointmentDetails.addAppointmentDataModel[haveReferral.name]) === 1 ? 'Yes' : 'No') : 'Not available'
              },
              {
                key: 'New Patient',
                value: (scope.appointmentDetails.addAppointmentDataModel[isNewPatient.name]) ? (parseInt(scope.appointmentDetails.addAppointmentDataModel[isNewPatient.name]) === 1 ? 'Yes' : 'No') : 'Not available'
              },
              {
                key: 'User Information updated',
                value: saSvc.getFromSession(saSvc.dsn.patientDemographicsStatus) ? saSvc.getFromSession(saSvc.dsn.patientDemographicsStatus).updated ? 'Yes' : 'No' : 'No'
              },
              {
                key: 'Insurance added',
                value: saSvc.getFromSession(saSvc.dsn.patientInsuranceStatus) ? (saSvc.getFromSession(saSvc.dsn.patientInsuranceStatus) === 'Added' ? 'Yes' : 'No') : 'No'
              },
              {
                key: 'Insurance updated',
                value: saSvc.getFromSession(saSvc.dsn.patientInsuranceStatus) ? (saSvc.getFromSession(saSvc.dsn.patientInsuranceStatus) === 'Updated' ? 'Yes' : 'No') : 'No'
              }
            ]
          };
          saSvc.setToSession(saSvc.dsn.selectedAppointment, scope.sessionData);
          
          flowControl.next();
          break;
        case 'Preferred Date/Time':
          if (scope.appointmentDetails.selectedAppointmentTypeDescription.IsDirectScheduleEnabled === false) {
            saSvc.setToSession(saSvc.dsn.selectedDateTime, scope.appointmentDetails.preferredDateTimeFormModel);
          }
          if (scope.appointmentDetails.selectedAppointmentTypeDescription.IsDirectScheduleEnabled === true) {
            saSvc.setToSession(saSvc.dsn.selectedDateTime, { data: scope.appointmentDetails.directPreferredDateAndTIme });
          }
          flowControl.tabComplete();
          break;
      }

    };

    scope.addUnlinkedData = function () {
      if (scope.appointmentDetails.dataForAdding[0] === 'location') {
        return saSvc.addLocation({ patientId: scope.appointmentDetails.saPatient.Id, locationId: scope.appointmentDetails.dataForAdding[1].Id });
      }
      if (scope.appointmentDetails.dataForAdding[0] === 'physician') {
        return saSvc.addPhysician({ patientId: scope.appointmentDetails.saPatient.Id, physicianId: scope.appointmentDetails.dataForAdding[1].Id }).then(function (res) {
          if (res.isApprovalRequired) {
            scope.appointmentDetails.adContent = saSvc.dialog.getTemplateDialogWithoutClose('approvalRequiredPopup', 'Approval Required', saSvc.staffApprovalRequired, '');
            saSvc.dialog.showDialog('approvalRequiredPopup');
          }
        });
      }
    };

    scope.setSessioData = function (stepIndex) {
      if (stepIndex === scope.appointmentDetails.physicianIndex) {
        var propName = stepIndex === 0 ? 'FindADoctorId' : 'FindADoctorId';

        if (scope.selectedPhysicianId !== (saSvc.getFromSession(saSvc.dsn.selectedPhysician) || angular.noop)[propName] && scope.appointmentDetails.indexVar.Physician + 1 === scope.appointmentDetails.indexVar['Appointment Type']) {
          scope.appointmentDetails.addAppointmentForm = {};
          scope.appointmentDetails.selectedAppointmentType = null;
          scope.getApppointmentTypes(scope.selectedLocationId, scope.selectedPhysicianId);
        }
        if (scope.selectedPhysicianId === '0') {
          var sessionPhy = {};
          sessionPhy[propName] = scope.selectedPhysicianId;
          saSvc.setToSession(saSvc.dsn.selectedPhysician, sessionPhy);
        } else {
          saSvc.setToSession(saSvc.dsn.selectedPhysician, saSvc.getValueById((scope.physicians || scope.appointmentDetails.physicians), scope.selectedPhysicianId, 'FindADoctorId'));
        }
      }
      if (stepIndex === scope.appointmentDetails.locationIndex) {
        if (stepIndex === 0) {
          var propName = 'LocationId';
        } else {
          var propName = 'BaseId';
          if (scope.selectedPhysicianId === '0') {
            var propName = 'LocationId';
          }
        }
        // propName = scope.selectedPhysicianId === '0' ? 'BaseId' : propName;
        if (scope.selectedLocationId !== (saSvc.getFromSession(saSvc.dsn.selectedLocation) || angular.noop)[propName] && scope.appointmentDetails.indexVar.Location + 1 === scope.appointmentDetails.indexVar['Appointment Type']) {
          scope.appointmentDetails.addAppointmentForm = {};
          scope.appointmentDetails.selectedAppointmentType = null;
          scope.getApppointmentTypes(scope.selectedLocationId, scope.selectedPhysicianId);
        }
        if (scope.selectedLocationId === '0') {
          var sessionLoc = {};
          sessionLoc[propName] = scope.selectedLocationId;
          saSvc.setToSession(saSvc.dsn.selectedLocation, sessionLoc);

        } else {
          saSvc.setToSession(saSvc.dsn.selectedLocation, saSvc.getValueById((scope.locations || scope.appointmentDetails.locations), scope.selectedLocationId, propName));

        }
      }
    };

    scope.showPhysicianLookup = function () {
      scope.adContent = saSvc.dialog.getTemplateDialog('plookup', translate.instant('PATIENT_MANAGEMENT_SELECT_PHYSICIAN'), saSvc.physicianLookUp, '');
      saSvc.dialog.showDialog('plookup');
    };

    scope.showLocationLookup = function () {
      scope.adContent = saSvc.dialog.getTemplateDialog('lLookup', translate.instant('PATIENT_MANAGEMENT_SELECT_LOCATION'), saSvc.locationLookUp, '');
      saSvc.dialog.showDialog('lLookup');
    };

    scope.getPatientPhysicians = function (physician) {
      if (physician.isApprovalRequired === true) {
        scope.appointmentDetails.adContent = saSvc.dialog.getTemplateDialog('approvalRequiredPopup', 'Approval Required', saSvc.staffApprovalRequired, '');
        saSvc.dialog.showDialog('approvalRequiredPopup');
      } else {
        scope.getStepData(scope.appointmentDetails.saPatient, scope.appointmentDetails.saPhyPermission.Order).then(function () {
          scope.selectedPhysicianId = +physician.FindADoctorId;
        });
      }
      saSvc.dialog.closeDialog('plookup');
    };

    scope.getPatientLocations = function (location) {
      scope.getStepData(scope.appointmentDetails.saPatient, scope.appointmentDetails.saLocPermission.Order).then(function () {
        scope.selectedLocationId = +location.Id;
      });
      scope.closePopups();
    };

    scope.closeDialog = function () {
      scope.$broadcast('closeDialog', '');
    };

    scope.closePopups = function () {
      saSvc.dialog.closeDialog('plookup');
      saSvc.dialog.closeDialog('lLookup');
    };

    scope.checkForProfileLink = function (data, type) {
      scope.dataForAdding = null;
      if (type === 'location') {
        saSvc.getPatientLocation((scope.saPatient || scope.appointmentDetails.saPatient).Id).then(function (response) {
          scope.allData = response[1];
          if (_.filter(scope.allData, function (loc) { return +(data.BaseId || data.LocationId) === +loc.LocationId; }).length === 0) {
            scope.locationIsNotLinked = true;
            scope.dataForAdding = ['location', data];
          } else {
            scope.locationIsNotLinked = false;
          }
          scope.locCheckPromiseResolved = true;
        });
      }
      if (type === 'physician') {
        saSvc.getPatientData(scope.apiKeys.physician, (scope.saPatient || scope.appointmentDetails.saPatient).Id).then(function (response) {
          scope.allData = response[1];
          if (_.filter(scope.allData, function (phy) { return +(data.FindADoctorId) === +phy.FindADoctorId; }).length === 0) {
            scope.physicianIsNotLinked = true;
            scope.dataForAdding = ['physician', data];
          } else {
            scope.physicianIsNotLinked = false;
          }
          scope.phyCheckPromiseResolved = true;
        });
      }
    };

  }]);

})(window.app);
