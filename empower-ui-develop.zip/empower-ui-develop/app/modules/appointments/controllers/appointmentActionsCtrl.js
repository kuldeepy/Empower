(function (app) {
  'use strict';

  /* schedule appointment appointment details controller */
  app.controller('appointmentActionsCtrl', ['$scope', 'scheduleAppointmentSvc', 'generalServices','$translate', function (scope, saSvc, gs,translate) {
    scope.stepIndex = 0;
    scope.currentIndex = 0;

    scope.setSession = function (val) {
      gs.session.set(saSvc.sessionStorageName, JSON.stringify(val));
    };

    scope.$watch('stepIndex', function (newVal) {
      if (typeof newVal === 'number' && typeof scope.currentIndex === 'number') {
        scope.setSession({
          stepIndex: newVal,
          mainIndex: scope.currentIndex
        });
      }
    });

    scope.$watch('currentIndex', function (newVal) {
      if (typeof newVal === 'number') {
        scope.setSession({
          stepIndex: scope.stepIndex || 0,
          mainIndex: newVal || 0
        });
      }
    });

    var saStorageValue = JSON.parse(gs.session.get(saSvc.sessionStorageName));
    if (saStorageValue) {
      scope.stepIndex = saStorageValue.stepIndex;
      scope.currentIndex = saStorageValue.mainIndex;
    }

    /* cancel dialog */
    scope.cancel = function (isConfirm , dirty) {
      if ((dirty !== undefined ? dirty : scope.masterForm.$dirty) && !isConfirm) {
          var dialogCallback = gs.dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          scope.masterForm.$setPristine();
          gs.location.url('/appointments');
        });
      } else {
        gs.location.url('/appointments');
      }
    // localStorage.removeItem('currentAppointment');
    };

    /* method  for controls added */
    scope.onControlsAdded = function (sender, control) {
      var setIdx = function () {
        control.setIndex(scope.currentIndex, scope.stepIndex);
      };
      gs.timeout(setIdx, 0);
    };

    /* page control events - init */
    scope.$on('msStepFlowControlsAdded', scope.onControlsAdded);
    scope.$on('stepFlowOnCancel', scope.onCancel);

    scope.$on('$locationChangeStart', function () {
      gs.session.clear(saSvc.sessionStorageName);
      gs.session.clear('rescheduleApp');
      _.forEach(saSvc.dsn, function (storeKey) {
        gs.session.clear(storeKey);
      });
    });

  }]);

})(window.app);
