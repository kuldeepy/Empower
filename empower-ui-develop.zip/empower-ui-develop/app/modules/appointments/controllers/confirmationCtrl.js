(function (app) {
  'use strict';

  /* schedule appointment confirmation controller */
  app.controller('confirmationCtrl', ['$scope', 'scheduleAppointmentSvc', function (scope, saSvc) {
    scope.steps = this.steps = [{ menu: 'Confirmation' }];
    scope.route = {
      path: '/modules/appointments/templates/confirmation.html',
      name: 'confirmation'
    };

    scope.onFocus = function (flowControl) {
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      scope.fc = flowControl;
      if (scope.stepIndex === 0) {
        scope.currentIndex = 0;
        scope.stepIndex = 0;
      }
      scope.confPatient = saSvc.getFromSession(saSvc.dsn.selectedPatient);
      scope.confPhysician = saSvc.getFromSession(saSvc.dsn.selectedPhysician);
      scope.confLocation = saSvc.getFromSession(saSvc.dsn.selectedLocation);
      scope.confAppointmentType = saSvc.getFromSession(saSvc.dsn.selectedAppointment);
      scope.confDateTime = angular.toJson(saSvc.getFromSession(saSvc.dsn.selectedDateTime).data);
      if (scope.confAppointmentType.selectedAppointmentType.IsDirectScheduleEnabled === false) {
        scope.dataTimeSelected = { earliestAvailable: saSvc.getFromSession(saSvc.dsn.selectedDateTime).data.ScheduleEarliestAvailable, dateTime: saSvc.getSelectedDayTime(saSvc.getFromSession(saSvc.dsn.selectedDateTime).data) };
      }
      if (scope.confAppointmentType.selectedAppointmentType.IsDirectScheduleEnabled === true) {
        scope.confDateTime = saSvc.getFromSession(saSvc.dsn.selectedDateTime).data;
        scope.dataTimeSelected = moment(saSvc.getFromSession(saSvc.dsn.selectedDateTime).data).format('dddd MMMM Do, YYYY hh:mm A');
      }
      scope.newAppointmentDataModel = { patient: scope.confPatient, physician: scope.confPhysician, location: scope.confLocation, appointmentType: scope.confAppointmentType, scheduleDaysAndTime: scope.confDateTime };
      scope.contactInformationList = saSvc.getFromSession(saSvc.dsn.ContactInformation);
    };

    /* get call when wizard opens  */
    scope.init = function () {};

    /* onPrevious wizard function */
    scope.onPrevious = function (flowControl) {
      switch (scope.stepIndex) {
        case 0:
          flowControl.previousTab();
          break;
      }
    };

    /* onPrevious wizard function */
    scope.onNext = function (flowControl) {
        switch (scope.stepIndex) {
            case 0:
                saSvc.createAppointment(scope.newAppointmentDataModel || scope.confirmation.newAppointmentDataModel).then(function (res) {
                    flowControl.tabComplete();
                    angular.element('.wizard-block').addClass('ng-hide');
                    if (scope.setShowConfirm) {
                        scope.setShowConfirm(scope.confirmation.confAppointmentType.selectedAppointmentType.IsDirectScheduleEnabled);
                    } else if (scope.confirmation.setShowConfirm) {
                        scope.confirmation.setShowConfirm(scope.confirmation.confAppointmentType.selectedAppointmentType.IsDirectScheduleEnabled);
                    }
                }, saSvc.callFailure);
                break;
        }
    };

    scope.goToStep = function (index) {
      scope.fc.setIndex(1, index);
    };
  }]);

})(window.app);
