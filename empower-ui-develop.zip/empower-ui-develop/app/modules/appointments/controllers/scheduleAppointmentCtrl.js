(function (app) {
  'use strict';

  /* schedule appointment appointment details controller */
  app.controller('scheduleAppointmentCtrl', ['$scope', 'scheduleAppointmentSvc', 'generalServices', '$translate', function (scope, saSvc, gs, translate) {
    scope.stepIndex = 0;
    scope.currentIndex = 0;
    scope.showConformation = false;
    /* on refresh clears the session */
    gs.session.clear(saSvc.sessionStorageName);
    _.forEach(saSvc.dsn, function (storeKey) {
      gs.session.clear(storeKey);
    });

    scope.model.moduleUrl = app.routeParams[0];

    scope.appntMsPromise.then(function () {
      _.forEach(scope.appntMs.HospitalSettings, function (setting) {
        if (setting.FieldName === 'Physician') { scope.saPhyPermission = setting; }
        if (setting.FieldName === 'Location') { scope.saLocPermission = setting; }
        if (setting.FieldName === 'Patient Demographics') { scope.saPatDemoPermission = setting; }
        if (setting.FieldName === 'Insurance Information') { scope.saInsTnfoPermission = setting; }
      });
      scope.isPermissionResolved = true;
    });

    scope.setSession = function (val) {
      gs.session.set(saSvc.sessionStorageName, JSON.stringify(val));
    };

    scope.$watch('stepIndex', function (newVal) {
      if (typeof newVal === 'number' && typeof scope.currentIndex === 'number') {
        scope.setSession({
          stepIndex: newVal,
          mainIndex: scope.currentIndex
        });
      }
    });

    scope.$watch('currentIndex', function (newVal) {
      if (typeof newVal === 'number') {
        scope.setSession({
          stepIndex: scope.stepIndex || 0,
          mainIndex: newVal || 0
        });
      }
    });

    var saStorageValue = JSON.parse(gs.session.get(saSvc.sessionStorageName));
    if (saStorageValue) {
      scope.stepIndex = saStorageValue.stepIndex;
      scope.currentIndex = saStorageValue.mainIndex;
    }
    /* cancel dialog */
    scope.onCancel = function () {
      if (scope.masterForm.$dirty) {
        var dialogCallback = gs.dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          scope.masterForm.$setPristine();
          gs.location.url('/appointments');
        });
      } else {
        gs.location.url('/appointments');
      }
    };

    /* method  for controls added */
    scope.onControlsAdded = function (sender, control) {
      var setIdx = function () {
        control.setIndex(scope.currentIndex, scope.stepIndex);
      };
      gs.timeout(setIdx, 0);
    };

    // confirm navigation when form is dirty
    var unregConfirm = scope.$on('$locationChangeStart', function (event) {
      gs.session.clear(saSvc.sessionStorageName);
      _.forEach(saSvc.dsn, function (storeKey) {
        gs.session.clear(storeKey);
      });
    });

    scope.setShowConfirm = function (directFlag) {
      if (directFlag === true) {
        scope.showConformationDirect = true;
      } else {
        scope.showConformation = true;
      }
    };

    scope.setDymaicStepIndexes = function (stepTwoindexes) {
      scope.allStepIndex = {
        Physician: stepTwoindexes['Physician'],
        Location: stepTwoindexes['Location'],
        AppointmentType: stepTwoindexes['Appointment Type'],
        PreferredDateTime: stepTwoindexes['Preferred Date/Time']
      };
    };

    /* page control events - init */
    scope.$on('msStepFlowControlsAdded', scope.onControlsAdded);
    scope.$on('stepFlowOnCancel', scope.onCancel);
  }]);

})(window.app);
