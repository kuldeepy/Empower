(function (app) {
  'use strict';

  app.controller('InformationNotCorrectCtrl',
    ['$scope', '$modalInstance', '$dialogFactory', 'alertService', 'dynamicText', 'medseekApi', 'session','$translate',
      function (scope, modal, dialog, alertService, dynamicText, api, session,translate) {
        scope.controller = {
          characterLimit: 500,
          comment: '',
          error: ''
        };

        /* cancel click event */
        scope.cancelClick = function (form) {
          if (form.$dirty) {
              var callBack = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), message.dialogMessages.cancelUnsavedConfirmMessage);
            callBack.result.then(function () {
              scope.close();
            });
            return;
          }
          scope.close();
        };

        /* method for close dialog */
        scope.close = function () {
          alertService.clear();
          modal.close();
        };

        /* ok click button */
        scope.okClick = function () {
          scope.controller.error = '';
          var patient = JSON.parse(session.get('patient'));
          var userId = session.get('userId');
          api.reportIncorrectDemographics.update({ userId: userId, patientId: patient.patientId }, null).$promise.then(function (response) {
            session.set('patientDemographicsStatus', 'Reported Incorrect');
            dynamicText.getDynamicText('profile', 'DemographicUpdateApprovalRequiredMessage').then(function (response) {
              alertService.add('success', response ? response : ('Thank you. Your request to update demographics ' +
              'has been submitted. Please allow 24 to 48 hours to process this request.') , 10000);
              modal.close();
            });
          });

          // dynamicText.getDynamicText('profile', 'DemographicUpdateApprovalRequiredMessage').then(function (response) {
          //   alertService.add('success',response);
          //    modal.close();
          // });

        };

      }]);

}(window.app));
