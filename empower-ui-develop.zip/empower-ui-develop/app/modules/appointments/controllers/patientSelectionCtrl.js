(function (app) {
  'use strict';

  /* schedule appointment patient Selection controller */
  app.controller('patientSelectionCtrl', ['$scope', 'scheduleAppointmentSvc', 'appointmentService', '$translate', function (scope, saSvc, appsvc, translate) {
    scope.steps = this.steps = [{ menu: 'Patient', 'displayName':translate.instant('PATIENT') }];
    var currentPermissionSet = saSvc.getFromSession('currentPermissionSet');
    scope.route = {
      path: '/modules/appointments/templates/patient-selection.html',
      name: 'patientSelection'
    };
    scope.selectedPatientId = {};
    scope.onFocus = function (flowControl) {
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      scope.fc = flowControl;
      if (scope.stepIndex === 0) {
        scope.currentIndex = 0;
        scope.stepIndex = 0;
      }
    };

    /* get call when wizard opens  */
    scope.init = function (flowControl) {
      saSvc.timeout(function () {
        scope.patientSelection.selectedPatientId = scope.getPatientIdHavingPermission(saSvc.getFromSession('patient'), 'appointments.future.schedule');

        /* checks if re-book process then set patient according to that */
        if (saSvc.location.$$search.patientId && app.routeParams[0] === saSvc.rebookUrlName) {
          scope.patientSelection.selectedPatientId = saSvc.location.$$search.patientId;
          scope.onNext(flowControl);
        }

        scope.patientSelection.getLinkedPatientPromise.then(function () {
          if (scope.patientSelection.linkedPatientWithSelf.length === 1) {
            scope.onNext(flowControl);
          }
        });
      });
    };

    /* checks for permission for auto selection of patient */
    scope.getPatientIdHavingPermission = function (patient, permission) {
      if (appsvc.checkPatientPermission(patient, permission) === 0) {
        appsvc.sortArray(scope.patientSelection.linkedPatientWithSelf, 'FirstName', 'asc', 's');
        scope.patientSelection.askForSwitchPatint((scope.patientSelection.linkedPatientWithSelf[0] || angular.noop).Id);
        return (scope.patientSelection.linkedPatientWithSelf[0] || angular.noop).Id;
      } else {
        return (saSvc.getValueById(scope.patientSelection.linkedPatientWithSelf, saSvc.getFromSession('patient').patientId) || angular.noop).Id;
      }
    };

    /* onPrevious wizard function */
    scope.onNext = function (flowControl) {
      scope.patientSelection.masterForm.$setDirty();
      switch (scope.stepIndex) {
        case 0:
          /* storing selected patient in session */
          if (!scope.patientSelection.switchingToPatient) {
            saSvc.setToSession(saSvc.dsn.selectedPatient, saSvc.getValueById(scope.patientSelection.linkedPatientWithSelf, scope.patientSelection.selectedPatientId));
            flowControl.tabComplete();
          }
          else if (scope.patientSelection.switchingToPatient.Id === scope.patientSelection.switchingFromPatient.Id) {
            saSvc.setToSession(saSvc.dsn.selectedPatient, saSvc.getValueById(scope.patientSelection.linkedPatientWithSelf, scope.patientSelection.selectedPatientId));
            flowControl.tabComplete();
          }
          /* ask to switch patient */
          else {
            saSvc.dialog.showDialog('saSwitchPatient');
          }
          break;
      }
    };

    /* ask for switching patient */
    scope.askForSwitchPatint = function (switchingWithId) {
      scope.switchingToPatient = saSvc.getValueById(scope.linkedPatientWithSelf, switchingWithId);
      scope.switchingFromPatient = saSvc.getValueById(scope.linkedPatientWithSelf, saSvc.getFromSession('patient').patientId);
      var patientName = scope.switchingToPatient.FirstName + ' ' + scope.switchingToPatient.LastName;
      scope.switchPatientMessage = translate.instant('APPT_SWITCH_PATIENT_PROMPT_MSG').replace('@@patientName@@', patientName);
      scope.psContent = saSvc.dialog.getTemplateDialogWithoutClose('saSwitchPatient', translate.instant('SWITCH_PATIENT'), saSvc.switchPatientDialog, '');
    };

    scope.switch = function (flowControl) {
      scope.switchPatient(scope.switchingToPatient, true, true);
      saSvc.dialog.closeDialog('saSwitchPatient');
      saSvc.setToSession(saSvc.dsn.selectedPatient, saSvc.getValueById(scope.linkedPatientWithSelf, scope.selectedPatientId));
      flowControl.tabComplete();
    };

    scope.cancelSwitch = function () {
      scope.selectedPatientId = scope.switchingFromPatient.Id;
      scope.switchingToPatient = scope.switchingFromPatient;
      saSvc.dialog.closeDialog('saSwitchPatient');
    };

    scope.schedulePermissionFilter = function (patient) {
      return appsvc.checkPatientPermission(patient, 'appointments.future.schedule');
    };

  }]);

})(window.app);
