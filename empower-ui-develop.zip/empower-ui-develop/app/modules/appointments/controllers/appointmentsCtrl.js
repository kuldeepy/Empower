(function (app) {
  'use strict';
  /* module root controller */

  app.require('modules/request-center');
  app.controller('appointmentsCtrl', ['$scope', '$window', 'session', 'requestService', 'appointmentService', 'alertService', '$filter', '$q', '$location', '$translate', function (scope, window, session, requestService, appointmentSvc, alertSvc, $filter, q, location, translate) {
    /* page variables */
    var past = 'past',
      upcomingQ = q.defer(),
      pastQ = q.defer(),
      errorIcon = 'danger',
      patient = 'patient',
      upcoming = 'upcoming',
      panelName = 'appointmentPanels',
      Appointments = [],
      appointmentLandingDynamicText = 'AppointmentsLandingPage';
    if (session.get(patient) === null) {
      scope.patientData = [];
      scope.patientData.medseekId = app.routing.routeParams.mrn;
    } else {
      scope.patientData = JSON.parse(session.get(patient));
      scope.patientName = JSON.parse(session.get('patient')).patientName;
      scope.patientData.medseekId = (scope.patientData.medseekId) ? scope.patientData.medseekId : scope.patientData.mrn;
    }
    scope.isHighlightRequest = false;
    scope.count = 0;
    /*Check if the current patient has permission*/
    var currentPermissionSet = JSON.parse(session.get('currentPermissionSet'));
    angular.forEach(currentPermissionSet, function (permission) {
      var comparePermission = scope.patientData.patientId + '.appointments';
      if (permission === comparePermission || permission == 'appointments') {
        scope.count++;
      }
    });
    if (location.search().appointmentId !== undefined && parseInt(location.search().appointmentId) > 0) {
      scope.isHighlightRequest = true;
      scope.highlightRequestId = location.search().appointmentId;
    }
    scope.portalType = session.get('portal');
    scope.canSchedule = true;
    scope.helptext = '';
    scope.pastAppointments = [];
    scope.upcomingAppointments = [];
    scope.allAppointments = [];
    scope.allAppointments.past = [];
    scope.allAppointments.upcoming = [];
    /* scope variables */
    scope.appointmentPanels = {
      upcoming: {
        isOpen: function () {
          setTimeout(function () {
            return true;
          });
        },
        loadPanel: function () {
          if (scope.allAppointments.upcoming)
            scope.appointments = scope.allAppointments.upcoming;
        }
      },
      past: {
        isOpen: false,
        loadPanel: function () {
          if (scope.allAppointments.past)
            scope.appointments = scope.allAppointments.past;
        }
      }
    };
    scope.setFutureAppointments = function (upcomingRes) {
      Appointments.upcoming = [];
      angular.forEach(upcomingRes, function (data) {
        Appointments.upcoming.push(data);
        Appointments.push(data);
      });

      scope.canViewUpcoming = upcomingRes.canViewUpcoming;
      if (scope.canViewUpcoming === false)
        scope.showUpcoming = false;
      else
        scope.showUpcoming = (upcomingRes[0] || scope.portalType === 'staff') ? true : false;
      upcomingQ.resolve();
    };

    scope.setPastAppointments = function (pastRes) {
      Appointments.past = [];
      angular.forEach(pastRes, function (data) {
        Appointments.past.push(data);
        Appointments.push(data);
      });
      scope.canViewPast = pastRes.canViewPast;
      if (scope.canViewPast === false)
        scope.showPast = false;
      else
        scope.showPast = (pastRes[0] || scope.portalType === 'staff') ? true : false;
      pastQ.resolve();
    };
    scope.init = function () {
      upcomingQ = q.defer();
      pastQ = q.defer();
      var timeZoneQ = q.defer(),
        dynamicTextQ = q.defer(),
        timeZone = q.defer();
      Appointments.upcoming = [];
      Appointments.past = [];

      if (scope.portalType === 'patient') {
        scope.headerText = 'Appointments';
      }

      scope.futurePermission = 'appointments.future.view';
      scope.pastPermission = 'appointments.past.view';

      scope.getAppointmentsErrorForPermission = function (requiredPermission) {
        var deferred = q.defer();
        q.all([appointmentSvc.getPatientHavingPermission(scope.futurePermission, true), appointmentSvc.getPatientHavingPermission(scope.pastPermission, true)]).then(function (res) {
          if (res[0].length === 0 && res[1].length === 0) {
            alertSvc.add(errorIcon, translate.instant('APPT_DISABLED_FROM_ADMIN_MSG'), 0, '', 'alert_page-top');
            deferred.reject();
          } else {
            deferred.resolve();
          }

        });
        return deferred.promise;
      };

      scope.getAppointmentsErrorForPermission(scope.futurePermission).then(function () {
        appointmentSvc.getAppointments({ medseekId: scope.patientData.medseekId }, upcoming).then(scope.setFutureAppointments, function (error) {});
      }, function () {
        // no permission
      });

      scope.getAppointmentsErrorForPermission(scope.pastPermission).then(function () {
        appointmentSvc.getAppointments({ medseekId: scope.patientData.medseekId }, past).then(scope.setPastAppointments, function () {
          // no permission
        }, function (error) {
          scope.getAppointmentsError();
        });
      });

      appointmentSvc.getDynamicText(appointmentLandingDynamicText).then(function (res) {
        scope.appointmentDescription = res;
        dynamicTextQ.resolve();
      });

      q.all([upcomingQ.promise, pastQ.promise, dynamicTextQ.promise]).then(function () {
        scope.allAppointments.past.push(Appointments.past);
        scope.allAppointments.upcoming.push(Appointments.upcoming);
        scope.allAppointments = Appointments;
        if (scope.isHighlightRequest) {
          angular.forEach(scope.allAppointments.upcoming, function (appointment) {
            angular.forEach(appointment.appointments, function (app, key) {
              if (parseInt(app.Id) === parseInt(scope.highlightRequestId)) {
                scope.isHighlightRequest = false;
                window.location.href = '/appointments/details?id=' + app.Id + '&status=' + app.Status + '&externalId=' + app.ExternalId + '';
              }
            });
          });

          angular.forEach(scope.allAppointments.past, function (appointment) {
            angular.forEach(appointment.appointments, function (app, key) {
              if (parseInt(app.Id) === parseInt(scope.highlightRequestId)) {
                scope.isHighlightRequest = false;
                window.location.href = '/appointments/details?id=' + app.Id + '&status=' + app.Status + '&externalId=' + app.ExternalId + '';
              }
            });
          });
        }
        var pData = scope.allAppointments;
        var patientName = session.get('portal') === 'staff' ? (function () {
          var p = session.getObject('CurrentPatient');
          return _.template('::FirstName:: ::LastName::', p);
        })() : app.routing.routeParams.patientname;
        if (scope.allAppointments.upcoming) {
          try {
            angular.forEach(scope.allAppointments.upcoming, function (value, key) {
              angular.forEach(value.appointments, function (app, key) {
                app.sequence = app.Status === 'Pending Approval' ? 0 : 1;
                app.AppointmentDateTime = app.Status === 'Pending Approval' ? null : app.AppointmentDateTime;
              });
            });
            angular.forEach(scope.allAppointments.upcoming, function (value, key) {
              value.appointments = _.sortBy(value.appointments, 'sequence');
              value.appointments = _.sortBy(value.appointments, 'AppointmentDateTime'); // sort by asc Appointment date
            });

          } catch (e) {
            console.log(e);
          }
        }
        if (scope.allAppointments.past) {
          try {
            scope.allAppointments.past = _.sortBy(scope.allAppointments.past, 'year').reverse();
            angular.forEach(scope.allAppointments.past, function (value, key) {
              value.appointments = _.sortBy(value.appointments, 'AppointmentDateTime').reverse(); // sort by Descending Appointment date
            });
          } catch (e) {
            console.log(e);
          }
        }
        if (scope.allAppointments.upcoming) {
          scope.allAppointments.upcoming = _.sortBy(scope.allAppointments.upcoming, 'year');
        }
        scope.allAppointments = Appointments;
        if (scope.canViewUpcoming === false && scope.canViewPast === false) { // no access to view both, them, then hide both accordians
          scope.helptext = translate.instant('APPT_DISABLED_FROM_ADMIN_MSG');
          scope.showUpcoming = false;
          scope.showPast = false;
        } else if (scope.showPast === false && scope.showUpcoming === false) {
          scope.helptext = scope.portalType === 'patient' ? translate.instant('APPT_NO_APPOINTMENTS_SCHEDULED_YET_MSG') : patientName + ' has not scheduled any appointments.';
        } else {
          scope.helptext = scope.portalType === 'patient' ? scope.appointmentDescription : 'You can click on an appointment to view more details.';
        }

        if (scope.portalType === 'staff') {
          scope.headerText = (patientName) + "'s Appointments";
        }

        if (session.get(patient) === null && scope.portalType === 'patient') {
          scope.helptext = "You don't have any linked patient records. You must Connect with a Patient before managing their profile.";
          scope.canSchedule = false;
          scope.showUpcoming = false;
          scope.showPast = false;
        }
        if (scope.canViewUpcoming === false) scope.showUpcoming = false;
        if (scope.canViewPast === false) scope.showPast = false;
        scope.panelActions(); // initiate panel open close 
      }, function (error) {
        scope.getAppointmentsError(error);
      });
    };

    scope.checkPermission = function (checkFor) {
      checkFor = checkFor.toString();
      if (checkFor && checkFor.length) {
        return session.get('currentPermissionSet').indexOf(checkFor) != -1 ? true : false;
      }
    };

    scope.getAppointmentsError = function () {
      alertSvc.add(errorIcon, translate.instant('APPT_UNABLE_TO_RETRIEVE_MSG'), 0, '', 'alert_page-top');
    };

    scope.panelActions = function () {
      _.each(scope.appointmentPanels, function (panel) {
        if (panel.isOpen) {
          scope.appointments = [];
          panel.loadPanel();
        }
      });
    };

    /* check the panel & load specific data for that panel */
    scope.$watch(panelName, function () {
      scope.panelActions(); // initiate panel open close 
    }, true);

    scope.checkNullorUndefined = function (val) {
      return angular.isUndefined(val) === true ? '' : val === null ? '' : val;
    };

    /* print upcoming data */
    scope.printData = function () {
      var pdf = new jsPDF('1', 'pt', 'B3'), margins = { top: 40, bottom: 40, left: 20, width: 1000 };
      pdf.setFont('times');
      pdf.fromHTML(scope.prepareHtmlforPrint(), margins.left, margins.top, { 'width': margins.width }, function (dispose) { pdf.output('dataurlnewwindow'); }, margins);
    };

    scope.prepareHtmlforPrint = function () {
      var printData = '';
      if (!scope.showUpcoming && !scope.showPast) {
        printData = '<h2>No Records</h2>';
      }
      if (scope.showUpcoming && scope.allAppointments.upcoming) {
        printData += '<h1>' + translate.instant('APPOINTMENTS_UPCOMING_APPOINTMENTS') + '</h1>';
        printData += '<table cellpadding="20">';
        printData += '<thead><tr>' + '<th style="width:150px">' + translate.instant('PATIENT_NAME') + '</th>' + '<th>' + translate.instant('DATE') + '</th>' + '<th>' + translate.instant('TIME') + '</th>' + '<th>' + translate.instant('PHYSICIAN') + '</th>' + '<th>' + translate.instant('LOCATION') + '</th>' + '<th>' + translate.instant('APPOINTMENTS_VISIT_TYPE') + '</th>' + '<th>' + translate.instant('STATUS') + '</th>' + '</tr></thead>' + '<tbody>';
        bubbleSort(scope.allAppointments.upcoming, 'year');
        angular.forEach(scope.allAppointments.upcoming, function (appointment) { // upcoming
          angular.forEach(appointment.appointments, function (app, key) {
            var source = app;
            source.PatientRelationship = source.PatientRelationship === null ? '' : source.PatientRelationship;
            source.PhysicianName = (source.PhysicianName) ? source.PhysicianName : translate.instant('NOT_PROVIDED');
            if (source.AppointmentDateTime === null) {
              printData += '<tr>' + '<td>' + scope.checkNullorUndefined((source.PatientRelationship.toLowerCase()) === 'self' ? translate.instant('YOU') : source.PatientName) + '</td><td>' + translate.instant('PENDING') + '</td><td><span>' + translate.instant('PENDING') + '</span><span> </span></td><td>' + scope.checkNullorUndefined(source.PhysicianName) + '</td><td>' + scope.checkNullorUndefined(source.LocationName) + '</td><td>' + scope.checkNullorUndefined(source.AppointmentTypeName) + '</td><td>' + scope.checkNullorUndefined(scope.getStatus(source)) + '</td>' + '</tr>';
            } else {
              printData += '<tr>' + '<td>' + scope.checkNullorUndefined(source.PatientRelationship.toLowerCase() === 'self' ? translate.instant('YOU') : source.PatientName) + '</td><td>' + $filter('date')(source.AppointmentDateTime, 'MM/dd/yyyy') + '</td><td><span>' + $filter('date')(source.AppointmentDateTime, 'hh:mm a') + '</span><span> ' + source.TimeZoneDisplayName + '</span></td><td>' + scope.checkNullorUndefined(source.PhysicianName) + '</td><td>' + scope.checkNullorUndefined(source.LocationName) + '</td><td>' + scope.checkNullorUndefined(source.AppointmentTypeName) + '</td><td>' + scope.checkNullorUndefined(scope.getStatus(source)) + '</td>' + '</tr>';
            }
          });
        });
        printData += '</tbody>' + '</table>';
      }

      return printData;
    };
    function bubbleSort (a, par) {
      var swapped;
      do {
        swapped = false;
        for (var i = 0; i < a.length - 1; i++) {
          if (a[i][par] > a[i + 1][par]) {
            var temp = a[i];
            a[i] = a[i + 1];
            a[i + 1] = temp;
            swapped = true;
          }
        }
      } while (swapped);
    }

    scope.getStatus = function (record) {
      var status = '';
      switch (record.Status.toLowerCase()) {
        case 'active':
          status = translate.instant('CONFIRMED');
          break;
        case 'pending reschedule':
          status = translate.instant('PENDING_RESCHEDULE');
          break;
        case 'pending cancellation':
          status = translate.instant('PENDING_CANCELLATION');
          break;
        case 'pending approval':
          status = translate.instant('PENDING_APPROVAL');
          break;
        case 'pre-registered':
          status = translate.instant('PRE_REGISTERED');
          break;
        case 'completed':
          status = translate.instant('COMPLETED');
          break;
        case 'cancelled':
          status = translate.instant('CANCELLED');
          break;
        default:
          status = record.Status;
          break;
      }

      return status;
    };

    /* get dynamic text for appointment description */
    if (scope.count > 0) {
      scope.init();
    }
  }]);
})(window.app);
