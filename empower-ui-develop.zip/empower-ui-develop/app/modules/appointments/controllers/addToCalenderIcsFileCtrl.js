(function (app) {
  'use strict';

  app.controller('addToCalenderIcsFileCtrl', ['$scope', 'dynamicText', 'alertService', '$filter', '$translate', function (scope, dynamicText, alertService, filter, translate) {
    scope.test = {};
    scope.check = function (name) {
      var appointment = scope.$parent.appointment;
      dynamicText.getDynamicText('appointmentrequest', 'TitleAppointmentCalendar').then(function (res) {
        scope.appointmentTitle = res;
        try {
          var startTime = new Date(appointment.AppointmentDateTimeUTC);
          var endTime = new Date(appointment.AppointmentDateTimeUTC);
          var duration = appointment.appointmentType.Duration;
          endTime.setMinutes(endTime.getMinutes() + duration);
          var lineBreak = '\\n';

          var emailBody = ' Patient Last Name: ' + appointment.patient.LastName + lineBreak +
            ' Patient First Name: ' + appointment.patient.FirstName + lineBreak +
            ' Appointment Unique ID: ' + appointment.Id + lineBreak +
            ' Appointment Date/Time: ' + startTime + lineBreak +
            ' Appointment Duration: ' + duration + ' minutes ' + lineBreak +
            ' Physician Last Name: ' + appointment.physician.LastName + lineBreak +
            ' Physician First Name: ' + appointment.physician.FirstName + lineBreak +
            ' Appointment Location Name: ' + appointment.location[0]._locationName + lineBreak +
            ' Appointment Location Address: ' + appointment.location[0]._address1 + ' ' + appointment.location[0]._address2 + ' '
            + appointment.location[0]._city + ' ' + appointment.location[0]._state + ' '
            + appointment.location[0]._zip + lineBreak +
            ' Appointment Location Phone Number: ' + filter('phone')(appointment.location[0]._phone);
          var cal = ics();
          if (name === translate.instant('APPOINTMENTS_ADD_TO_CALENDAR') ) {
            cal.addEvent(appointment.Id, scope.appointmentTitle, emailBody, appointment.location[0]._locationName, startTime, endTime);
          }
          else if (name === translate.instant('APPOINTMENTS_REMOVE_FROM_CALENDER') ) {
            cal.removeEvent(appointment.Id, scope.appointmentTitle, emailBody, appointment.location[0]._locationName, startTime, endTime);
          }
          if (cal)
            cal.download();
        } catch (err) {
          console.log(err);
          var error = (name === translate.instant('APPOINTMENTS_ADD_TO_CALENDAR') ? translate.instant('APPT_UNABLE_TO_EXPORTCALENDER_MSG') : translate.instant('APPT_UNABLE_TO_REMOVE_FROM_CALENDER_MSG'));
          alertService.add('danger', error, 0, '', 'alert_page-top');
        }
      });

    };

  }]);

})(window.app);
