(function (app) {
  'use strict';

  app.directive('appointments', ['appointmentService', function (appsvc) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/appointments/templates/appointments.html',
      scope: {
        isolatedAttributeSource: '@attributeSource',
        isolatedBindingSource: '=bindingSource',
        appointmentTense: '@'
      },
      controller: ['$scope', '$location', function ($scope, location) {
        $scope.navigateToDetails = function (appointment) {
          // window.location.href = '/appointments/details?id=' + appointment.Id + '&status=' + appointment.Status + '&externalId=' + appointment.ExternalId + '';
          location.path(location.$$path + '/details').search({id: appointment.Id,status: appointment.Status,externalId: appointment.ExternalId, patientId: appointment.PatientId });
        };

        $scope.filterByPatientAccess = function (appointment) {
          var permission = $scope.appointmentTense === 'future' ? 'appointments.future.view' : 'appointments.past.view';
          return appsvc.checkPatientPermission({ Id: appointment.PatientId }, permission);
        };
      }]
    };
  }]);

  app.directive('appointment', function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/appointments/templates/appointment.html',
      scope: {
        source: '=bindingSource'
      }
    };
  });

  app.directive('appointmentStatus', ['$translate', function (translate) {
    return {
      restrict: 'A',
      scope: {
        source: '=appointmentstatus'
      },
      link: function (scope, iElm, iAttrs) {
        scope.getStatus = function () {
          var status = '';
          var record = {};
          record.Status = scope.source.Status;
          switch (record.Status.toLowerCase()) {
            case 'active':
              status = translate.instant('CONFIRMED');
              break;
            case 'pending reschedule':
              status = translate.instant('PENDING_RESCHEDULE');
              break;
            case 'pending cancellation':
              status = translate.instant('PENDING_CANCELLATION');
              break;
            case 'pending approval':
              status = translate.instant('PENDING_APPROVAL');
              break;
            case 'pre-registered':
              status = translate.instant('PRE_REGISTERED');
              break;
            case 'completed':
              status = translate.instant('COMPLETED');
              break;
            case 'cancelled':
              status = translate.instant('CANCELLED');
              break;
            default:
              status = record.Status;
              break;
          }

          return status;
        };
        scope.source.showStatus=scope.getStatus();

      }
    };
  }]);

}(window.app));
