(function (app) {
  'use strict';

  /* schedule appointment patient Information controller */
  app.controller('preRegisterCtrl', ['$scope', 'appointmentService', 'generalServices', '$translate', function (scope, appSvc, gs, translate) {
    scope.steps = this.steps = [{ menu: 'INSTRUCTIONS' }, { menu: 'APPOINTMENTS_PRE_REGISTER_INFORMATION' }];
    scope.route = {
      path: '/modules/appointments/templates/pre-register.html',
      name: 'preRegister'
    };

    scope.createStep = function (flowControl) {
      if (scope.appntMs.GeneralSettings.DisplayPreRegistrationInstructions) {
        scope.preRegInfoStepIndex = 1;
        scope.InstStepIndex = 0;
      } else {
        var data = scope.steps = this.steps = [{ menu: translate.instant('APPOINTMENTS_PRE_REGISTER_INFORMATION') }];
        scope.preRegInfoStepIndex = 0;
        flowControl.changeSteps(0, data);
        flowControl.changeFlowControl();
      }
    };

    scope.createStepOnce = _.once(scope.createStep);

    /* on focus event for wizard */
    scope.onFocus = function (flowControl) {
      scope.createStepOnce(flowControl);
      scope.fc = flowControl;
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
    };

    /* get call when wizard opens  */
    scope.init = function () {
      scope.bindDynamicText('PreregistrationInstructions');
      scope.bindDynamicText('PreregistrationFormInstructions');
      scope.getAppointmentDetail();
      scope.isPreviousClick = false;
      scope.isSuccess = false;
    };

    /* event for submit the pre registration information */
    scope.preRegistrationInformationSubmit = function (flowControl) {
      var data = appSvc.getPreRegistrationInformationSubmitBody(scope.appointment, scope.preRegisterDataModel, scope.preRegisterForm);
      scope.bindDynamicText('PreregistrationSuccessMessage');
      appSvc.savePreRegistrationInformation(data).then(function (result) {
        scope.isSuccess = true;
        flowControl.next();
      }, function (error) {
        appSvc.alertService.add('danger', translate.instant('APPT_UNABLE_TO_PREREGISTER_MSG'), 2000);
      });
    };

    /* bind all the dynamic text */
    scope.bindDynamicText = function (key) {
      appSvc.dynamicText.getDynamicText('AppointmentRequest', key).then(function (res) {
        if (key === 'PreregistrationInstructions') {
          scope.preRegister.preregistrationInstructions = res;
        }
        else if (key === 'PreregistrationFormInstructions') {
          scope.preRegister.preregistrationFormInstructions = res;
        }
        else if (key === 'PreregistrationSuccessMessage') {
          scope.preregistrationSuccessMessage = res;
        }

      });
    };

    /* onPrevious wizard function */
    scope.onPrevious = function (flowControl) {
      scope.isPreviousClick = true;
      flowControl.previous();
    };

    /* get the appointment details */
    scope.getAppointmentDetail = function () {
      appSvc.getAppointment().then(function (appointment) {
        scope.appointment = appointment;
        scope.appointment.AppointmentDate = new Date(appointment.AppointmentDateTime);
        var getAppointmentTypeBody = {
          'parameters': {
            Id: scope.appointment.AppointmentTypeId
          }
        };
        appSvc.getAppointmentType(getAppointmentTypeBody).then(function (type) {
          if (type && type.length > 0) {
            scope.bindPreRegistrationForm(type[0].PreRegistrationFormId);
          }
        });
      });
    };

    /* bind the dynamic form for appintment pre-Registration */
    scope.bindPreRegistrationForm = function (id) {
      scope.preRegisterDataModel = {};
      appSvc.getDynamicFormById(id).then(function (form) {
        scope.preRegisterForm = form;
        scope.preRegisterForm.name = '';
        scope.preRegister.masterForm.$setPristine();
      });
    };

    /* onPrevious wizard function */
    scope.onNext = function (flowControl) {
      switch (scope.stepIndex) {
        case 0:
          if (!scope.isPreviousClick) {
            scope.masterForm.$setPristine();
          }
          flowControl.next();
          break;

      }
    };

    // confirm navigation when form is dirty
    /*    scope.$on('$locationChangeStart', function (event,url) {
          event.preventDefault();
          if ((scope.preRegister || scope).masterForm.$dirty) {
            var dialogCallback = gs.dialogFactory.confirm('confirmDialog', 'Confirm Cancel', 'All changes will be lost. Do you want to continue?');
            dialogCallback.result.then(function () {
              (scope.preRegister || scope).masterForm.$setPristine();
              gs.location.url('/appointments');
            }, function(){
              event.preventDefault();
            });
          }
        });*/

  }]);

})(window.app);
