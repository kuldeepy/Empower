(function (app) {
  'use strict';
  app.controller('rescheduleConfirmationCtrl', ['$scope', 'appointmentService', 'generalServices', 'scheduleAppointmentSvc', '$translate', function (scope, appSvc, gs, saSvc, translate) {
    /* variable declarations */
    scope.route = { path: '/modules/appointments/templates/rescheduleConfirmation.html', name: 'rescheduleConfirmation' };
    scope.steps = this.steps = [{ menu: translate.instant('CONFIRMATION') }];

    /* Init */
    scope.init = function () {
      appSvc.getDynamicText('RescheduleConfirmationInstructions').then(function (result) {
        scope.rescheduleConfirmationInstructions = result;
      });
    };

    /* onFocus wizard function */
    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.showNext(false);
      flowControl.showPrevious(false);
      flowControl.showCancel(false);
      if (scope.stepIndex === 0) {
        scope.currentIndex = 0;
        scope.stepIndex = 0;
      }
      scope.rescheduleDetails = JSON.parse(gs.session.get('rescheduleApp'));
      scope.originalDate = moment(scope.rescheduleDetails.appointment.AppointmentDateTime).format('dddd MMMM Do, YYYY hh:mm A');
      if (scope.rescheduleDetails.appointment.appointmentType.IsDirectScheduleEnabled === true) {
        scope.directDateTimeSelected = moment(scope.rescheduleDetails.directDateTime).format('dddd MMMM Do, YYYY hh:mm A');
      } else {
        scope.dataTimeSelected = { earliestAvailable: scope.rescheduleDetails.ScheduleBody.ScheduleEarliestAvailable, dateTime: saSvc.getSelectedDayTime(scope.rescheduleDetails.ScheduleBody) };
      }
    };

    /* edit the preferred days and time */
    scope.editPreferredDays = function (flowControl) {
      flowControl.setIndex(0, 0);
    };

    scope.onSubmit = function (flowControl) {
      if (!scope.rescheduleDetails) {
        scope.rescheduleDetails = JSON.parse(gs.session.get('rescheduleApp'));
      }
      scope.isDirectReschedule = scope.rescheduleDetails.appointment.appointmentType.IsDirectScheduleEnabled;
      var data = scope.getRescheduleAppointmentBody(scope.rescheduleDetails.appointment, scope.rescheduleDetails.dataModel, scope.rescheduleDetails.ScheduleBody, scope.rescheduleDetails.directDateTime);
      appSvc.getDynamicText(scope.isDirectReschedule === true ? 'DirectRescheduleSuccessMessage' : 'RescheduleRequestSuccessMessags').then(function (result) {
        scope.successText = result;
      });
      if (data.newAppointment) {
        appSvc.rescheduleIndirectAppointment(data).then(function (result) {
          if (result.Retval) {
            scope.fc = flowControl;
            flowControl.next();
            scope.stepIndex = 1;
            flowControl.showNext(false);
            flowControl.showPrevious(false);
            flowControl.showCancel(false);
          } else {
            scope.showError(translate.instant('APPT_UNABLE_TO_RESCHEDULE_MSG'));
          }
        }, function () {
          scope.showError(translate.instant('APPT_UNABLE_TO_RESCHEDULE_MSG'));
        });
      } else {
        appSvc.rescheduleDirectAppointment(data).then(function (result) {
          if (result.Retval) {
            scope.fc = flowControl;
            flowControl.next();
            scope.stepIndex = 1;
            flowControl.showNext(false);
            flowControl.showPrevious(false);
            flowControl.showCancel(false);
          } else {
            scope.showError(translate.instant('APPT_UNABLE_TO_RESCHEDULE_MSG'));
          }
        }, function () {
          scope.showError(translate.instant('APPT_UNABLE_TO_RESCHEDULE_MSG'));
        });
      }

    };

    scope.showError = function (error) {
      appSvc.alertService.add('danger', error, 2000);
    };
    scope.getDynamicFormData = function () {
      scope.dynamicValues = { selectedAppointmentXml: [] };
      _.forEach(scope.rescheduleAppointment.formDefinition.fields, function (item) {
        scope.dynamicValues.selectedAppointmentXml.push({
          key: item.name === 'RescheduleReason' ? 'Reason for rescheduling' : 'Additional Information',
          value: item.type === 'DropDown' ? ( scope.rescheduleAppointment.formDataModel[item.name] ? scope.rescheduleAppointment.formDataModel[item.name].name : 'Not available')
            : (scope.rescheduleAppointment.formDataModel[item.name] ? scope.rescheduleAppointment.formDataModel[item.name] : 'Not available')
        });

      });
      return scope.dynamicValues;
    };
    /* build the body for reschedule body */
    scope.getRescheduleAppointmentBody = function (appointment, dataModel, newDateTime, directDateTime) {
      if (dataModel && dataModel.RescheduleReason && dataModel.RescheduleReason.id) {
        appointment.ReasonId = dataModel.RescheduleReason.id;
        appointment.ReasonName = dataModel.RescheduleReason.name;

      }
      /*var body = {
        appointmentToCancel : appointment,
        newAppointment : appointment,
        comments : dataModel.EarliestAvailable
      };
      body.newAppointment.Action = 'ManualReschedule';
      body.newAppointment.Status = 'ReschedulePending',
      body.newAppointment.ScheduleBody = angular.toJson(newDateTime);
      body.newAppointment.Id = '0'*/
      var body = {};
      if (appointment.appointmentType.IsDirectScheduleEnabled === false) {
        body = {
          appointmentIdToCancel: appointment.Id,
          reasonId: appointment.ReasonId,
          ReasonName: appointment.ReasonName,
          comments: dataModel.EarliestAvailable,
          newAppointment: appointment,
          status: 'ReschedulePending',

        };
        body.newAppointment.Action = 'ManualReschedule';
        body.newAppointment.AppointmentTypeFormStringData = angular.toJson(scope.getDynamicFormData()),
        body.newAppointment.Status = 'ReschedulePending';
        body.newAppointment.ScheduleBody = angular.toJson(newDateTime);
      } else {
        appointment.AppointmentDateTime = directDateTime;
        body = {
          appointment: appointment,
          medseekId: appointment.patient.MedseekId,
          directSchedule: true,
          sendNotification: true
        };
      }

      return body;
    };
    scope.onPrevious = function (flowControl) {
      scope.fc = flowControl;
      flowControl.previousTab();
    };

  }]);

}(window.app));
