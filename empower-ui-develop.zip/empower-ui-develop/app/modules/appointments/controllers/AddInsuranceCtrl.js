(function (app) {
  'use strict';

  app.controller('AddInsuranceCtrl', ['$scope', 'medseekApi', 'session', '$q', '$location', '$timeout', 'alertService', '$dialogFactory', 'scheduleAppointmentSvc', '$translate', function (scope, api, session, q, loc, timeout, alertService, dialog, aSvc, translate) {
    /* variable declarations */
    scope.error = 'danger';
    scope.searchTypeInsurance = 'Select Insurance';
    scope.selectedInsuranceErrorMessage = 'Select a Insurance.';
    scope.fillInsuranceDetailErrorMessage = 'Please fill the mandatory insurance details';
    scope.addInsuranceForm = {
      formData: {},
      formDefinition: null
    };
    scope.insurance = {};

    var patient = {};
    if (session.get('patient')) {
      patient = JSON.parse(session.get('patient'));
    }

    /* init */
    scope.initMethod = function () {
      scope.isEdit = false;
      aSvc.insuranceProvider({}).then(function (responseItem) {
        scope.insurances = responseItem;
      });
    };
    scope.initMethod();

    /* selected insurance */
    scope.insuranceSelected = function (insurance) {
      if (scope.insurance) {
        scope.insurance.selectedInsurance = angular.copy(insurance);
      } else {
        scope.insurance.selectedInsurance = insurance;
      }
      scope.insuranceData = insurance;
      scope.getDynamicForm(scope.insurance.selectedInsurance.Id);
    };

    scope.$on('isEditedInsurance', function (event, data) {
      if (data.isEdited) {
        scope.isEdit = true;
        scope.insurance.selectedInsurance = scope.selectedParentInsurence;
        scope.getDynamicForm(scope.selectedParentInsurence.PayerId);
      } else {
        scope.initMethod();
      }
    });

    /* onPrevious wizard function */
    scope.getDynamicForm = function (id) {
      scope.addInsuranceForm = {
        formData: {},
        formDefinition: null
      };
      aSvc.getInsurancesDynamicForm({ payerId: id }).then(function (res) {
        _.forEach(res.fields, function (field) {
          if (field.textLabel !== null) {
            field.label = field.textLabel;
          }
        });

        scope.addInsuranceForm.formDefinition = angular.copy(res);
        if (scope.insurance.selectedInsurance && scope.addInsuranceForm.formDefinition.fields.length > 0) {
          aSvc.timeout(function () {
            _.forEach(scope.addInsuranceForm.formDefinition.fields, function (field) {
              if (field.name === 'InsuranceName') {
                field.filters.ReadOnly = true;
              }
            });

            if (scope.isEdit) {
              scope.selectedInsuranceId = scope.insurance.selectedInsurance.Id;
              scope.addInsuranceForm.formData = scope.insurance.selectedInsurance;
              scope.addInsuranceForm.formData = scope.constructInsurance(scope.insurance.selectedInsurance);
              scope.addInsuranceForm.formData.InsuranceName = scope.insurance.selectedInsurance.ProviderName;
            }

            if (!scope.isEdit) {
              _.forEach(scope.addInsuranceForm.formDefinition.fields, function (field) {
                if (field.name === 'InsuranceName') {
                  field.filters.ReadOnly = true;
                  scope.addInsuranceForm.formData.InsuranceName = scope.insurance.selectedInsurance.PayerName;
                  scope.bindInsurance(scope.insurance.selectedInsurance);
                }
              });
            }
          }, 100);
        }
      });
    };

    scope.bindInsurance = function (insurance) {
      if (insurance.Rank) {
        scope.addInsuranceForm.formData.Rank = insurance.Rank.id;
      }
      if (insurance.PolicyHolderRelationshipToPatient) {
        scope.addInsuranceForm.formData.PolicyHolderRelationshipToPatient = insurance.PolicyHolderRelationshipToPatient.id;
      }
      scope.addInsuranceForm.formData.PolicyCountry = (insurance.PolicyCountry) ? insurance.PolicyCountry.id : insurance.CountryId;
      scope.addInsuranceForm.formData.StateProvince = (insurance.StateProvince) ? insurance.StateProvince.id : insurance.StateId;

      if (insurance.PolicyHolderCountry) {
        scope.addInsuranceForm.formData.PolicyHolderCountry = insurance.PolicyHolderCountry.id;
      } else {
        scope.addInsuranceForm.formData.PolicyHolderCountry = (scope.insurance) ? scope.insurance.DefaultCountryId : scope.DefaultCountryId;
      }
      if (insurance.PolicyHolderStateProvince) {
        scope.addInsuranceForm.formData.PolicyHolderStateProvince = insurance.PolicyHolderStateProvince.id;
      }

      if (scope.addInsuranceForm.formData.PolicyCountry && scope.addInsuranceForm.formData.PolicyCountry.toString() === '103') {
        scope.setPolicyDemography();
      }
      if (scope.addInsuranceForm.formData.PolicyHolderCountry && scope.addInsuranceForm.formData.PolicyHolderCountry.toString() === '103') {
        scope.setPolicyHolderDemography();
      }
      scope.addInsuranceForm.formData.ZipPostalCode = (insurance.ZipPostalCode) ? insurance.ZipPostalCode : insurance.Zip;

    };

    scope.constructInsurance = function (insurance) {
      var insuranceProvider = angular.copy(insurance);
      insuranceProvider.Rank = scope.bindEditInsuranceRank(insurance.RankType);
      insuranceProvider.PolicyIDNumber = insurance.PolicyNumber;
      insuranceProvider.EffectiveDate = (insurance.EffectiveDate) ? new Date(insurance.EffectiveDate) : '';
      insuranceProvider.ExpirationDate = (insurance.ExpirationDate) ? new Date(insurance.ExpirationDate) : '';
      insuranceProvider.PolicyHolderDateofBirth = new Date(insurance.PolicyHolderDob);
      insuranceProvider.PolicyHolderSocialSecurityNumber = insurance.PolicyHolderSsn;
      insuranceProvider.PolicyHolderAddress1 = insurance.Address1;
      insuranceProvider.PolicyHolderAddress2 = insurance.Address2;
      insuranceProvider.PolicyHolderCity = insurance.City;
      insuranceProvider.PolicyHolderStateProvince = insurance.State;
      insuranceProvider.PolicyHolderCountry = insurance.Country;
      insuranceProvider.PolicyHolderZipPostalCode = insurance.ZipCode;
      insuranceProvider.PolicyHolderEmployerName = insurance.EmployerName;
      insuranceProvider.PolicyHolderRelationshipToPatient = insurance.RelationshipToPatient;
      insuranceProvider.Address1 = insurance.PayerAddress1;
      insuranceProvider.Address2 = insurance.PayerAddress2;
      insuranceProvider.City = insurance.PayerCity;
      insuranceProvider.StateProvince = insurance.PayerState;
      insuranceProvider.PolicyCountry = insurance.PayerCountry;
      insuranceProvider.ZipPostalCode = insurance.PayerZipCode;
      insuranceProvider.Fax = insurance.PayerFax;
      insuranceProvider.Phone = insurance.PayerPhone;
      return insuranceProvider;
    };

    scope.cancelInsurance = function (cancelOnSuccess) {
      if (scope.formState.$dirty && cancelOnSuccess === undefined) {
        var dialogCallback = aSvc.dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          scope.resetInsurence();
        });
      } else {
        scope.resetInsurence();
      }
    };

    scope.resetInsurence = function () {
      scope.addInsuranceForm = {
        formData: {},
        formDefinition: null
      };
      scope.isEdit = false;
      scope.piContent = undefined;
      scope.selectedInsurance = {};
      aSvc.dialog.closeDialog('addInsurance');
      scope.formState.$setPristine();
    };

    scope.saveInsuranceToProfile = function () {
      var patient = {};
      if (session.get('patient')) {
        patient = JSON.parse(session.get('patient'));
      }
      scope.expirationDate = scope.addInsuranceForm.formData.ExpirationDate;
      scope.effectiveDate = scope.addInsuranceForm.formData.EffectiveDate;
      scope.dateOfBirth = scope.addInsuranceForm.formData.PolicyHolderDateofBirth;
      alertService.clear();
      var validationFails = false;
      var expirationDate = (scope.expirationDate) ? (scope.expirationDate.getMonth() + 1) + '/' + scope.expirationDate.getDate() + '/' + (scope.expirationDate.getYear() + 1900) : '';
      var effectiveDate = (scope.effectiveDate) ? (scope.effectiveDate.getMonth() + 1) + '/' + scope.effectiveDate.getDate() + '/' + (scope.effectiveDate.getYear() + 1900) : '';
      var dateOfBirth = (scope.dateOfBirth) ? (scope.dateOfBirth.getMonth() + 1) + '/' + scope.dateOfBirth.getDate() + '/' + (scope.dateOfBirth.getYear() + 1900) : '';
      if (effectiveDate === expirationDate && expirationDate !== '' || scope.effectiveDate > scope.expirationDate && expirationDate !== '') {
        alertService.add('danger', ' Expiration Date of Policy has to be a date later than the Effective Date', 0, '', 'alert_appointments-popup');
        return;
      }
      if (scope.effectiveDate != '' && scope.effectiveDate < scope.dateOfBirth) {
        alertService.add('danger', "Effective Date of Policy has to be a date later than Policy Holder's Date of Birth", 0, '', 'alert_appointments-popup');
        return;
      }
      if (scope.dateOfBirth > new Date()) {
        alertService.add('danger', "Policy Holder's Date of Birth cannot be a future date", 0, '', 'alert_appointments-popup');
        return;
      } else {
        scope.body = scope.constructSaveOrUpdatePatientInsuranceRequest(scope.addInsuranceForm.formData);
        scope.body.insurance.InsuranceXmlData = scope.buildInsurnaceXMLData(scope.body);
        scope.addInsuranceForm.formData.patientId = JSON.parse(session.get('patient')).patientId;
        scope.body.insurance.PatientId = JSON.parse(session.get('patient')).patientId;
        scope.body.insurance.Id = (scope.isEdit) ? scope.selectedInsuranceId : 0;

        api.patient_management.insurances.save({ patientId: scope.body.insurance.PatientId, insuranceId: scope.body.insurance.Id }, scope.body).$promise.then(function (response) {
          aSvc.setToSession(aSvc.dsn.patientInsuranceStatus, scope.isEdit ? 'Updated' : 'Added');
          if (response.results && response.results.Retval === 0) {
            if (scope.body.insurance.PolicyHolderName) {
              scope.contactName = 'Payer: ' + scope.body.insurance.ProviderName +
                ' Policy Numer: ' + scope.body.insurance.PolicyNumber +
                ' RelationShip: ' + scope.body.insurance.RelationshipToPatient;
            }
            scope.alreadyExitMessage = 'An Insurance with this information ' + scope.contactName + ' is already added to ' + scope.body.insurance.PolicyHolderName + "'s profile. Please provide a different name and try again.";
            alertService.clear();
            alertService.add('danger', scope.alreadyExitMessage, 0, 'alert_appointments-popup');
            return;
          }
          scope.insuranceToCopy = scope.setInsuranceToCopy(scope.addInsuranceForm.formData, response.results);
          scope.getSuccessMessages();
        });
      }

    };

    scope.bindRank = function (rank) {
      var id = 0;
      switch (rank) {
        case 'Primary':
          id = 1;
          break;
        case 'Secondary':
          id = 2;
          break;
        case 'Other':
          id = 0;
          break;
      }
      return id;
    };

    scope.constructSaveOrUpdatePatientInsuranceRequest = function (data) {
      if (data.Rank) {
        data.Rank.id = scope.bindRank(data.Rank.name);
      }
      return {
        insurance: {
          'CreatedOn': new Date(),
          'EffectiveDate': (data.EffectiveDate) ? data.EffectiveDate : '',
          'ExternalId': null,
          'GroupNumber': (data.GroupNumber) ? data.GroupNumber : '',
          'InsuranceProvider': null,
          'InsuranceXmlData': null,
          'IsActive': true,
          'LastUpdatedOn': new Date(),
          'PatientId': '',
          'PayerId': (scope.isEdit) ? scope.insurance.selectedInsurance.PayerId : scope.insurance.selectedInsurance.Id,
          'PolicyHolderDob': (data.PolicyHolderDateofBirth) ? data.PolicyHolderDateofBirth : '',
          'PolicyHolderName': (data.PolicyHolderName) ? data.PolicyHolderName : '',
          'PolicyHolderSsn': (data.PolicyHolderSocialSecurityNumber) ? data.PolicyHolderSocialSecurityNumber : '',
          'PolicyNumber': (data.PolicyIDNumber) ? data.PolicyIDNumber : '',
          'ProviderName': (data.InsuranceName) ? data.InsuranceName : '',
          'RankType': (data.Rank) ? data.Rank.id : '',
          'ExpirationDate': data.ExpirationDate,
          'RelationshipToPatient': data.PolicyHolderRelationshipToPatient.id,
          'Address1': (data.PolicyHolderAddress1) ? (data.PolicyHolderAddress1) : '',
          'Address2': (data.PolicyHolderAddress2) ? data.PolicyHolderAddress2 : '',
          'City': (data.PolicyHolderCity) ? data.PolicyHolderCity : '',
          'State': (data.PolicyHolderStateProvince) ? data.PolicyHolderStateProvince.id : 0,
          'Country': (data.PolicyHolderCountry) ? data.PolicyHolderCountry.id : 0,
          'ZipCode': (data.PolicyHolderZipPostalCode) ? data.PolicyHolderZipPostalCode : '',
          'EmployerName': (data.PolicyHolderEmployerName) ? (data.PolicyHolderEmployerName) : '',
          'PayerAddress1': (data.Address1) ? (data.Address1) : '',
          'PayerAddress2': (data.Address2) ? data.Address2 : '',
          'PayerCity': (data.City) ? data.City : '',
          'PayerState': (data.StateProvince) ? data.StateProvince.id : 0,
          'PayerCountry': (data.PolicyCountry) ? data.PolicyCountry.id : 0,
          'PayerZipCode': (data.ZipPostalCode) ? data.ZipPostalCode : '',
          'PayerPhone': (data.Phone) ? data.Phone : '',
          'PayerFax': (data.Fax) ? data.Fax : '',
        }
      };
    };

    scope.setInsuranceToCopy = function (data, result) {
      return {
        'Id': result.Retval,
        'PolicyNumber': (data.PolicyIDNumber) ? data.PolicyIDNumber : '',
        'RankType': (data.Rank) ? data.Rank.name : '',
        'RelationshipToPatient': (data.PolicyHolderRelationshipToPatient) ? data.PolicyHolderRelationshipToPatient.name : '',
      };
    };

    scope.buildInsurnaceXMLData = function (requestObject) {
      var xmlData = '<root><data>';
      for (var key in requestObject.insurance) {
        if (requestObject.insurance[key]) {
          xmlData += '<value key="' + key + '" label="' + key + '">' + requestObject.insurance[key] + '</value>';
        } else {
          xmlData += '<value key="' + key + '" label="' + key + '"/>';
        }
      }
      xmlData += '</data></root>';
      return xmlData;
    };

    /* on save click  */
    scope.getSuccessMessages = function () {
      alertService.clear();
      scope.insuranceSuccessMessage = translate.instant('PATIENT_MANAGEMENT_INSURANCE_SAVED_TO_PROFILE', { patientFirstName: patient.patientFirstName });
      alertService.add('success', scope.insuranceSuccessMessage, 2000);
      scope.getInsurance();
      scope.cancelInsurance(true);

    };

    /* to set policy holder demography*/
    scope.setPolicyHolderDemography = function () {
      var stateField = _.find(scope.addInsuranceForm.formDefinition.fields, { name: 'PolicyHolderStateProvince' });
      stateField.filters.href = 'empower/countries/103/states';
      var zipField = _.find(scope.addInsuranceForm.formDefinition.fields, { name: 'PolicyHolderZipPostalCode' });
      zipField.filters.href = '103';
    };

    /* to set policy demography*/
    scope.setPolicyDemography = function () {
      var stateField = _.find(scope.addInsuranceForm.formDefinition.fields, { name: 'StateProvince' });
      stateField.filters.href = 'empower/countries/103/states';
      var zipField = _.find(scope.addInsuranceForm.formDefinition.fields, { name: 'ZipPostalCode' });
      zipField.filters.href = '103';
    };

    scope.$on('PolicyCountryChanged', function (event, item) {
      var stateField = _.find(scope.addInsuranceForm.formDefinition.fields, { name: 'StateProvince' });
      stateField.filters.href = 'empower/countries/' + item.id + '/states';
      scope.addInsuranceForm.formData.ZipPostalCode = '';
    });

    scope.$on('PolicyHolderCountryChanged', function (event, item) {
      var stateField = _.find(scope.addInsuranceForm.formDefinition.fields, { name: 'PolicyHolderStateProvince' });
      stateField.filters.href = 'empower/countries/' + item.id + '/states';
      scope.addInsuranceForm.formData.PolicyHolderZipPostalCode = '';
    });

    scope.getZipCode = function () {
      if (scope.addInsuranceForm.formDefinition.ZipCode && scope.addInsuranceForm.formDefinition.Country && scope.addInsuranceForm.formDefinition.Country.toString() === '102') {
        if (scope.addInsuranceForm.formDefinition.ZipCode.indexOf('-') > 0) {
          var zip = scope.addInsuranceForm.formDefinition.ZipCode.split('-');
          scope.body.insurance.ZipCode = zip[0] + zip[1];
        }
      }
    };

    scope.bindEditInsuranceRank = function (rank) {
      var id;
      switch (rank) {
        case 'Primary':
          id = 1;
          break;
        case 'Secondary':
          id = 2;
          break;
        case 'Other':
          id = 3;
          break;
      }
      return id;
    };

  }]);

}(window.app));
