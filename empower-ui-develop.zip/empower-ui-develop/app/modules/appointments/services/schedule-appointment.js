(function (app) {
  'use strict';

  /* factory for appointment scheduling */
  app.factory('scheduleAppointmentSvc', ['generalServices', 'session', 'getAppointmentDialogContant', '$translate', 'localStorageSvc', 'patientProfileService', function (gs, session, gadc, translate, localStorageSvc, patientProfileService) {
    var svc = {};
    var patientInfo = JSON.parse(session.get('patient'));
    /* injecting general services in local service */
    svc = angular.copy(gs);

    /* making instance of getting dialog template method */
    svc.dialog = svc.GetDialogTemplate(gs.dialogService);

    /* delayed showdialog because of binding issue */
    svc.dialog.showDialog = function (dialogName) {
      gs.timeout(function () { gs.GetDialogTemplate(gs.dialogService).showDialog(dialogName); });
    };

    /* injecting to get Appointment Dialog Contant(template-injector-svc) local service */
    angular.extend(svc, gadc);

    svc.sessionStorageName = 'stepStore';

    svc.rebookUrlName = 're-book-appointment';

    /* Data Store Names/Keys in session storage */
    svc.dsn = {
      selectedPatient: 'selectedPatient', selectedPhysician: 'selectedPhysician',
      selectedLocation: 'selectedLocation', selectedAppointment: 'selectedAppointment',
      selectedDateTime: 'selectedDateTime', ContactInformation: 'ContactInformation',
      patientInsuranceCount: 'patientInsuranceCount', patientDemographicsStatus: 'patientDemographicsStatus',
      patientInsuranceStatus: 'patientInsuranceStatus'
    };

    function buildEditPatientDemographicsRequestObject (patient) {
      var requestObject = {};
      requestObject.patient = patient;

      if (patient.Title && patient.Title.id) {
        requestObject.patient.Title = patient.Title.id;
      }
      if (patient.Suffix && patient.Suffix.id) {
        requestObject.patient.Suffix = patient.Suffix.id;
      }
      if (patient.Gender && patient.Gender.id) {
        requestObject.patient.Gender = patient.Gender.id;
      }

      if (patient.Country && patient.Country.id) {
        requestObject.patient.Country = patient.Country.id;
      }

      if (patient.State && patient.State.id) {
        requestObject.patient.State = patient.State.id;
      }
      if (patient.MaritalStatus && patient.MaritalStatus.id) {
        requestObject.patient.MaritalStatus = patient.MaritalStatus.id;
      }

      if (patient.LanguagesKey && patient.LanguagesKey.id) {
        requestObject.patient.PreferredLanguage = patient.LanguagesKey.id;
      }

      if (patient.Ethnicity && patient.Ethnicity.id) {
        requestObject.patient.Ethnicity = patient.Ethnicity.id;
      }

      if (patient.RaceKey) {
        patient.Races = scope.buildRacesForRequest(requestObject.patient.RaceKey);
      }

      if (patient.RelationshipToPatient && patient.RelationshipToPatient.UniqueId) {
        requestObject.patient.PortalUserRelationships = [];
        requestObject.patient.PortalUserRelationships = [{ RelationshipClassification: patient.RelationshipToPatient.UniqueId }];
      }

      requestObject.patient.PatientsXmlData = '';
      requestObject.patient.PatientsXmlData = buildPatientXMLData(requestObject);
      return requestObject;
    }

    function buildPatientXMLData (requestObject) {
      var xmlData = '<root><data>';
      for (var key in requestObject.patient) {
        if (requestObject.patient[key]) {
          xmlData += '<value key="' + key + '" label="' + key + '">' + requestObject.patient[key] + '</value>';
        } else {
          xmlData += '<value key="' + key + '" label="' + key + '"/>';
        }
      }
      xmlData += '</data></root>';
      return xmlData;
    }

    svc.getFromSession = function (key) {
      try {
        return angular.fromJson(gs.session.get(key));
      } catch (err) {
        return gs.session.get(key);
      }
    };

    svc.setToSession = function (key, val) {
      if (angular.isObject(val)) {
        gs.session.set(key, angular.toJson(val));
      } else {
        gs.session.set(key, val);
      }
    };

    /* return patient with mathed ID */
    svc.getValueById = function (collection, Id, compareProperty) {
      return _.filter(collection, function (obj) {
        return obj[compareProperty || 'Id'] == Id;
      })[0];
    };

    /* brings patient data like physician or location by patient-Id*/
    svc.getPatientData = function (dataType, Id) {
      var deferred = gs.q.defer();
      gs.medseekApi.patient_management[dataType].get({ patientId: Id }, null).$promise.then(function (response) {
        deferred.resolve([dataType, response.results.Retval]);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    /* brings location of physician */
    svc.getPhysicianByLoaction = function (Id) {
      var deferred = gs.q.defer();
      gs.medseekApi.getPhysicians.get({ locationId: Id }).$promise.then(function (response) {
        var approvedOrNotAddedPhysicins = [];
        svc.getPatientPhysician(svc.getFromSession('patient').patientId).then(function (phy) {
          var profilePhysician = phy[1];
          _.forEach(response.results.Retval, function (phyByLoc) {
            var temp;
            _.forEach(profilePhysician, function (proPhy) {
              if (+proPhy.FindADoctorId === +phyByLoc.FindADoctorId) {
                temp = proPhy;
              }
            });
            if (temp) {
              if (temp.IsApproved === true) {
                approvedOrNotAddedPhysicins.push(phyByLoc);
              }

            } else {
              if (phyByLoc.IsEnabled === true) {
                approvedOrNotAddedPhysicins.push(phyByLoc);
              }
            }
          });
          deferred.resolve(['physicians', approvedOrNotAddedPhysicins]);

        });
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    /* brings location of physician */
    svc.getLocationByPhysician = function (Id) {
      var deferred = gs.q.defer();
      gs.medseekApi.getPhysicians.locations.get({ physicianId: Id }).$promise.then(function (response) {
        var temp = [];
        if (response.results.Retval.length > 0) {
          _.forEach(response.results.Retval, function (locByPhy) {
            if (locByPhy.IsEnabled === true) {
              temp.push(locByPhy);
            }
          });
          response.results.Retval = temp;
        }
        deferred.resolve(['locations', response.results.Retval]);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    svc.getPatientLocation = function (Id) {
      var deferred = gs.q.defer();
      gs.medseekApi.patient_management.locations.get({ patientId: Id }, null).$promise.then(function (response) {
        deferred.resolve(['locations', response.results.Retval]);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    svc.getPatientPhysician = function (Id) {
      var deferred = gs.q.defer();
      gs.medseekApi.patient_management.physicians.get({ patientId: Id }, null).$promise.then(function (response) {
        deferred.resolve(['physicians', response.results.Retval]);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    svc.getLogicalData = function (response) {
      return response;
    };

    svc.callFailure = function (error) {
      gs.alertService.add('danger', 'Error');
      return gs.q.reject();
    };

    svc.getNextStepData = function (scope) {
      var promise;
      if (scope.appointmentDetails.indexVar['Physician'] === 0) {
        if (scope.selectedPhysicianId === '0') {
          promise = svc.getPatientLocation((scope.saPatient || scope.appointmentDetails.saPatient).Id);
        } else {
          promise = svc.getLocationByPhysician(scope.selectedPhysicianId);
        }
      }
      else if (scope.appointmentDetails.indexVar['Location'] === 0) {
        if (scope.selectedLocationId === '0') {
          promise = svc.getPatientPhysician((scope.saPatient || scope.appointmentDetails.saPatient).Id);
        } else {
          promise = svc.getPhysicianByLoaction(scope.selectedLocationId);

        }
      }
      return promise;
    };

    svc.getRelationBody = function (entityTypeId, entityId) {
      return {
        'CriteriaType': 'RelatedTo',
        'EntityTypeId': entityTypeId,
        'EntityId': entityId
      };
    };

    svc.getAppointmentTypes = function (locationId, physicianId) {
      locationId = locationId === '0' ? null : locationId;
      physicianId = physicianId === '0' ? null : physicianId;
      var deferred = gs.q.defer();
      var body = {
        'moduleInstanceId': '',
        'criteriaList': [],
        'useParticipantFiltering': false
      };
      if (locationId && physicianId) {
        body.criteriaList.push(svc.getRelationBody('Physician', physicianId));
        body.criteriaList.push(svc.getRelationBody('Location', locationId));
        body.useParticipantFiltering = false;
      }
      else if (locationId) {
        body.criteriaList.push(svc.getRelationBody('Location', locationId));
        body.useParticipantFiltering = false;
      }
      else if (physicianId) {
        body.criteriaList.push(svc.getRelationBody('Physician', physicianId));
        body.useParticipantFiltering = false;
      }
      gs.medseekApi.requestCenter.getDataRelation.save({ entityType: 'AppointmentType' }, body).$promise.then(function (response) {
        deferred.resolve(response.results);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    svc.getDirectAppointmentObj = function (dataModel) {
      var obj = {
        'appointment': {
          'PatientId': dataModel.patient.Id.toString(),
          'AppointmentDateTime': dataModel.appointmentType.selectedAppointmentType.IsDirectScheduleEnabled === true ? dataModel.scheduleDaysAndTime : new Date(),
          'LocationId': (+(dataModel.location || angular.noop).LocationId || +(dataModel.location || angular.noop).BaseId) || '',

          'PhysicianId': (dataModel.physician && dataModel.physician.FindADoctorId) ? dataModel.physician.FindADoctorId.toString() : '',
          'PhysicianName': (dataModel.physician || angular.noop).DoctorFullName,

          'IsFirstAppointment': true,
          'IsReminderEnabled': false,
          'IsWillingToSeeOtherPhysician': true,
          'MedseekPatientId': dataModel.patient.MedicalRecordNumber,

          'ResponseType': 1,
          'ReminderSentDateTime': null,
          'LinkedAppointmentId': null,
          'Action': 'Schedule',
          'Status': 'Pending',

          'CanCancel': false,

          'LocationName': (dataModel.location || angular.noop).LocationName,

          'IsPreRegistered': dataModel.appointmentType.selectedAppointmentType.IsIntegrateWithPreRegistration,
          'GeneralInformationXmlData': null,
          'GeneralInformationData': null,
          'GeneralInformationFormStringData': null,
          'IsExternal': false,
          'ExternalId': null,
          'IsEnabled': true,
          'AppointmentTypeId': dataModel.appointmentType.selectedAppointmentType.Id.toString(),
          'AppointmentTypeExternalId': dataModel.appointmentType.selectedAppointmentType.ExternalId.toString(),
          'AppointmentTypeFormStringData': null,
          'AppointmentTypeName': dataModel.appointmentType.selectedAppointmentType.AppointmentTypeName,
          'AppointmentTypeDescription': dataModel.appointmentType.selectedAppointmentType.Description,
          'AppointmentTypeCancellationBuffer': dataModel.appointmentType.selectedAppointmentType.CancellationBuffer.toString(),
          'AppointmentTypeRescheduleBuffer': dataModel.appointmentType.selectedAppointmentType.RescheduleAppointmentRequestBuffer.toString()
        },
        'medseekId': dataModel.patient.MedicalRecordNumber,
        'createTaskOnFail': false,
        'directSchedule': dataModel.appointmentType.selectedAppointmentType.IsDirectScheduleEnabled
      };
      if (obj.appointment.LocationId.toString() === '0') {
        obj.appointment.LocationId = null;
      }
      return obj;
    };

    svc.createAppointment = function (dataModel) {
      var deferred = gs.q.defer();
      var body = {};
      if (dataModel.appointmentType.selectedAppointmentType.IsDirectScheduleEnabled === true) {
        body = svc.getDirectAppointmentObj(dataModel);
        gs.medseekApi.appointments.scheduleExternalAppointment.save({ patientId: dataModel.patient.Id }, body).$promise.then(function (response) {
          deferred.resolve(response.results);
        }, function (error) {
          deferred.reject(error);
        });
      } else {
        body = svc.buildNewAppointmentBody(dataModel);
        gs.medseekApi.appointments.saveNewAppointment.save({ patientId: dataModel.patient.Id }, body).$promise.then(function (response) {
          deferred.resolve(response.results);
        }, function (error) {
          deferred.reject(error);
        });
      }

      return deferred.promise;
    };

    svc.getPatientDemographicsForm = function () {
      var deferred = gs.q.defer();
      gs.medseekApi.dynamicForms.get({ module: 'Enrollment', key: 'VerifyDemographics', cultureName: localStorageSvc.get('cultureName') }).$promise.then(function (response) {
        var verifyDemographics = response.results.Retval;
        verifyDemographics.name = null;
        deferred.resolve({ verifyDemographicsForm: verifyDemographics });
      });
      return deferred.promise;
    };

    svc.getProfilePatientDemographicsForm = function (id) {
      var deferred = gs.q.defer();
      gs.medseekApi.settings.profileForm.get({ formId: id }).$promise.then(function (response) {
        var verifyDemographics = response.results.Retval;
        verifyDemographics.name = null;
        deferred.resolve({ verifyDemographicsForm: verifyDemographics });
      });
      return deferred.promise;
    };

    svc.getEnrollModuleSettings = function () {
      var deferred = gs.q.defer();
      gs.medseekApi.modules.settings.get({ moduleName: 'enrollment' }).$promise.then(function (response) {
        var enrollModuleSettings = response.results.Retval;
        deferred.resolve({ enrollModuleSettings: enrollModuleSettings });
      });
      return deferred.promise;
    };

    svc.getProfileModuleSettings = function () {
      var deferred = gs.q.defer();
      gs.medseekApi.modules.settings.get({ moduleName: 'profile' }).$promise.then(function (response) {
        var moduleSettings = response.results.Retval;
        deferred.resolve({ profileModuleSettings: moduleSettings });
      });
      return deferred.promise;
    };

    svc.getProfilelookUp = function () {
      var deferred = gs.q.defer();
      gs.medseekApi.profileLookups.get().$promise.then(function (response) {
        var lookUp = response.results;
        deferred.resolve(response.results);
      });
      return deferred.promise;
    };

    svc.updateDemographics = function (patient, isRequireApproval) {
      var deferred = gs.q.defer();
      var requestObj = buildEditPatientDemographicsRequestObject(patient);

      gs.medseekApi.patient_management.patientDemographics.update({ patientId: requestObj.patient.Id }, requestObj).$promise.then(function (response) {
        if (isRequireApproval) {
          gs.dynamicText.getDynamicText('profile', 'DemographicUpdateApprovalRequiredMessage').then(function (response) {
            gs.alertService.add('success', response);
            gs.dialogService.hide('editDemographics');
            deferred.resolve({ requireApproval: isRequireApproval });
          });
        } else {
          gs.timeout(function () {
            gs.medseekApi.patient.patientById.get({ patientId: patient.Id }).$promise.then(function (response) {
              response.results.Retval.PortalUserRelationships = response.results.Relationship[0];
              svc.setToSession('selectedPatient', response.results.Retval);
              deferred.resolve(response.results.Retval);
            });
          });
          var pat = angular.fromJson(gs.session.get('patient'));
          gs.alertService.add('success', 'You have successfully updated ' + pat.patientFirstName + ' ' + pat.patientMiddleName + ' ' + pat.patientLastName + "'s demographics");
          gs.dialogService.hide('editDemographics');
        }

      }, function (error) {
        gs.alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SAVE_PROFILE_COMPONENT_ERROR'), 0, '', 'alert_demographics-popup');
        deferred.reject(error);
      });

      return deferred.promise;
    };

    svc.getInsurance = function (patientId) {
      var deferred = gs.q.defer();
      gs.medseekApi.patient_management.insuranceById.get({ patientId: patientId }, null).$promise.then(function (response) {
        deferred.resolve(response.results.Retval);
        svc.setToSession(svc.dsn.patientInsuranceCount, response.results.Retval.length);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    svc.insuranceProvider = function (body) {
      var deferred = gs.q.defer();
      gs.medseekApi.insurances.get(body, null).$promise.then(function (response) {
        deferred.resolve(response.results.Retval);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    svc.getInsurancesDynamicForm = function (body) {
      var deferred = gs.q.defer();
      gs.medseekApi.insurances.getDynamicFormForPayer.get(body).$promise.then(function (response) {
        deferred.resolve(response.results);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    /* add location to patient */
    svc.addLocation = function (body) {
      var deferred = gs.q.defer();

      gs.medseekApi.patient_management.locations.save({ patientId: body.patientId }, { isDefault: false, locationId: body.locationId, isCopy: false }).$promise.then(function (response) {
        patientProfileService.updateProfileInfo('locations');
        deferred.resolve(response);
      }, function (error) {
        deferred.reject(error);
      });
      return deferred.promise;
    };

    svc.addPhysician = function (body) {
      var deferred = gs.q.defer();
      gs.moduleSettingsFactory.getModuleSettings('profile').then(function (settings) {
        gs.medseekApi.patients.savePhysician.save({ patientId: body.patientId, physicianId: body.physicianId }, { isDefault: { isDefault: !settings.RequireApprovalForPhysicians } }).$promise.then(function (response) {
          deferred.resolve({ isApprovalRequired: settings.RequireApprovalForPhysicians });
          patientProfileService.updateProfileInfo('physicians');
        }, function (error) {
          deferred.reject(error);
        });
      });
      return deferred.promise;
    };

    svc.buildXmlData = function () {
      return '<root><data><value key="AppointmentComments" label="Comments" /></data></root>';
    };
    svc.buildNewAppointmentBody = function (dataModel) {
      var appointmentData = svc.getFromSession(svc.dsn.selectedAppointment);
      if (appointmentData) {
        _.forEach(appointmentData.selectedAppointmentXml, function (item) {
          if (item.key === 'User Information updated') {
            item.value = svc.getFromSession(svc.dsn.patientDemographicsStatus);
          }
          if (item.key === 'Insurance added') {
            item.value = svc.getFromSession(svc.dsn.patientInsuranceStatus) ? (svc.getFromSession(svc.dsn.patientInsuranceStatus) === 'Added' ? 'Yes' : 'No') : 'No';
          }
          if (item.key === 'Insurance updated') {
            item.value = svc.getFromSession(svc.dsn.patientInsuranceStatus) ? (svc.getFromSession(svc.dsn.patientInsuranceStatus) === 'Updated' ? 'Yes' : 'No') : 'No';
          }
        });
        svc.setToSession(svc.dsn.selectedAppointment, appointmentData);
      }
      if (!dataModel) { return {}; }
      var body = {
        'appointment': {
          'ListViewLine1': 'None specified',
          'ListViewLine1Label': 'Provider:',
          'ListViewLine2': 'None specified',
          'ListViewLine2Label': 'Location:',
          'ListViewLine3': 'None specified',
          'ListViewLine3Label': 'Department:',
          'ListViewLine4': 'None specified',
          'ListViewLine4Label': 'Procedure:',
          'ListViewLine5': 'None specified',
          'ListViewLine5Label': 'Reason:',
          'ProcedureDescription': '',
          'SecondaryLocationId': '',
          'SecondaryLocationName': '',
          'PatientId': dataModel.patient.Id,
          'AppointmentDateTime': dataModel.appointmentType.selectedAppointmentType.IsDirectScheduleEnabled === true ? dataModel.scheduleDaysAndTime : new Date(),
          'LocationId': (dataModel.location || angular.noop).LocationId || (dataModel.location || angular.noop).BaseId,
          'DepartmentId': null,
          'DepartmentName': '',
          'PhysicianId': (dataModel.physician || angular.noop).FindADoctorId,
          'PhysicianName': (dataModel.physician || angular.noop).DoctorFullName,
          'ProcedureId': '',
          'ProcedureName': '',
          'ReasonId': null,
          'ReasonName': '',
          'OriginalAppointmentReason': null,
          'IsFirstAppointment': true,
          'IsReminderEnabled': false,
          'IsWillingToSeeOtherPhysician': true,
          'MedseekPatientId': dataModel.patient.MedicalRecordNumber,
          'DaytimePhone': '',
          'DaytimePhoneExt': '',
          'ResponseType': 1,
          'ReminderSentDateTime': null,
          'LinkedAppointmentId': null,
          'Action': 'Schedule',
          'Status': 'Pending',
          'SequenceNumber': null,
          'WorkflowInstanceId': null,
          'CanCancel': false,
          'Schedule': null,
          'LocationName': (dataModel.location || angular.noop).LocationName,
          'AppointmentComments': '',
          'CancelComments': '',
          'RescheduleComments': '',
          'AppointmentCommentsStaff': '',
          'CancelCommentsStaff': '',
          'RescheduleCommentsStaff': '',
          'IsPreRegistered': dataModel.appointmentType.selectedAppointmentType.IsIntegrateWithPreRegistration,
          'GeneralInformationXmlData': svc.buildXmlData(),
          'GeneralInformationData': null,
          'GeneralInformationFormStringData': angular.toJson({ insurance: svc.getFromSession(svc.dsn.patientInsuranceStatus), patientDemographic: svc.getFromSession(svc.dsn.patientDemographicsStatus) }),
          'IsExternal': false,
          'ExternalId': null,
          'IsEnabled': true,
          'AppointmentTypeId': dataModel.appointmentType.selectedAppointmentType.Id,
          'AppointmentTypeExternalId': dataModel.appointmentType.selectedAppointmentType.ExternalId,
          'AppointmentTypeFormStringData': angular.toJson(svc.getFromSession(svc.dsn.selectedAppointment)),
          'AppointmentTypeName': dataModel.appointmentType.selectedAppointmentType.AppointmentTypeName,
          'AppointmentTypeDescription': dataModel.appointmentType.selectedAppointmentType.Description,
          'AppointmentTypeCancellationBuffer': dataModel.appointmentType.selectedAppointmentType.CancellationBuffer,
          'AppointmentTypeRescheduleBuffer': dataModel.appointmentType.selectedAppointmentType.RescheduleAppointmentRequestBuffer,
          'PhysicianOrderAvailable': '',
          'PhysicianOrderDeliveryType': '',
          'OrderingPhysicianFirstName': '',
          'OrderingPhysicianLastName': '',
          'OrderingPhysicianPhone': '',
          'OrderingPhysicianFax': '',
          'ScheduleFormXml': svc.buildXmlData(),
          'HasResolveErrors': false,
          'ScheduleBody': dataModel.appointmentType.selectedAppointmentType.IsDirectScheduleEnabled === false ?
            angular.toJson(angular.extend(angular.fromJson(dataModel.scheduleDaysAndTime), { 'AppointmentTypeFormStringData': dataModel.appointmentType.selectedAppointmentData }))
            : {}
        },
        'comments': dataModel.appointmentType.selectedAppointmentData.AdditionalInformationData,
        'directScheduleStatus': 'Pending'
      };
      if (body.appointment && body.appointment.LocationId && body.appointment.LocationId.toString() === '0') {
        body.appointment.LocationId = null;
      }
      return body;
    };

    svc.getSelectedDayTime = function (dayTime) {
      var monArray = _.filter(dayTime.SchedulePreferencesList, { SchedulePreferenceMonday: true });
      var tuesArray = _.filter(dayTime.SchedulePreferencesList, { SchedulePreferenceTuesday: true });
      var wedArray = _.filter(dayTime.SchedulePreferencesList, { SchedulePreferenceWednesday: true });
      var thursArray = _.filter(dayTime.SchedulePreferencesList, { SchedulePreferenceThursday: true });
      var friArray = _.filter(dayTime.SchedulePreferencesList, { SchedulePreferenceFriday: true });
      var satArray = _.filter(dayTime.SchedulePreferencesList, { SchedulePreferenceSaturday: true });
      var sunArray = _.filter(dayTime.SchedulePreferencesList, { SchedulePreferenceSunday: true });
      var selectedDayTime = [{ day: 'Monday', time: monArray },
        { day: 'Tuesday', time: tuesArray },
        { day: 'Wednesday', time: wedArray },
        { day: 'Thursday', time: thursArray },
        { day: 'Friday', time: friArray },
        { day: 'Saturday', time: satArray },
        { day: 'Sunday', time: sunArray }
      ];
      return selectedDayTime;
    };
    svc.getAvailableAppointments = function (patientExtId, locationId, physicianId, appointmentId) {
      var deferred = gs.q.defer();
      var response = {
        'Retval': [
          {
            'ExternalId': null,
            'AppointmentDateTime': '02/18/2015 8:00:00 AM',
            'AppointmentTypeId': 2,
            'AppointmentTypeExternalId': '101',
            'AppointmentTypeName': 'appointment3',
            'LocationId': '5870',
            'LocationName': '1036 Valley Medical Center',
            'DepartmentId': null,
            'DepartmentName': null,
            'ProcedureId': null,
            'ProcedureName': '',
            'PhysicianId': null,
            'PhysicianName': null
          },
          {
            'ExternalId': null,
            'AppointmentDateTime': '02/19/2000 9:00:00 AM',
            'AppointmentTypeId': 2,
            'AppointmentTypeExternalId': '101',
            'AppointmentTypeName': 'appointment3',
            'LocationId': '5870',
            'LocationName': '',
            'DepartmentId': null,
            'DepartmentName': null,
            'ProcedureId': null,
            'ProcedureName': '',
            'PhysicianId': null,
            'PhysicianName': null
          },
          {
            'ExternalId': null,
            'AppointmentDateTime': '02/19/2015 6:00:00 PM',
            'AppointmentTypeId': 2,
            'AppointmentTypeExternalId': '101',
            'AppointmentTypeName': 'appointment3',
            'LocationId': '5870',
            'LocationName': '',
            'DepartmentId': null,
            'DepartmentName': null,
            'ProcedureId': null,
            'ProcedureName': '',
            'PhysicianId': null,
            'PhysicianName': null
          },
          {
            'ExternalId': null,
            'AppointmentDateTime': '03/20/2015 10:00:00 PM',
            'AppointmentTypeId': 2,
            'AppointmentTypeExternalId': '101',
            'AppointmentTypeName': 'appointment3',
            'LocationId': '5870',
            'LocationName': '',
            'DepartmentId': null,
            'DepartmentName': null,
            'ProcedureId': null,
            'ProcedureName': '',
            'PhysicianId': null,
            'PhysicianName': null
          }
        ]
      };
      var obj = {
        'appointmentTypeId': appointmentId,
        'departmentId': '0',
        'locationId': +locationId || '',
        'providerId': physicianId,
        'patientId': patientExtId,
        'daysOfWeek': ''
      };
      gs.medseekApi.appointments.directAvailableAppointment.save({ patientId: patientInfo.patientId }, obj).$promise.then(function (response) {
        deferred.resolve(response.results.Retval);
      });

      // deferred.reject(error);
      return deferred.promise;
    };

    return svc;
  }]);

}(window.app));
