(function (app, angular, $) {
  'use strict';

  /* factory for appointment */
  app.factory('appointmentService', ['$q', '$location', 'medseekApi', 'session', 'generalServices', '_', '$rootScope', '$translate', function (q, loc, api, session, gs, _, rootScope, translate) {
    var svc = gs;
    var appsvc = {};
    var patientId;

    var patientInfo = JSON.parse(session.get('patient'));
    if (patientInfo === null) {
      if (app.routing) {
        api.patient.patientByMrn.get({ mrn: app.routing.routeParams.mrn }).$promise.then(function (response) {
          var patientdetails = response.results.Retval;
          rootScope.patientIdForCurrentMrn = patientdetails.Id;
        });
      }
    } else {
      patientId = patientInfo.patientId;
    }

    /* get patient id which have certain permission */
    appsvc.getPatientHavingPermission = function (requiredPersmission, onlyPatientIds) {
      var perms = session.getObject('currentPermissionSet');
      var deferred = q.defer();
      var permittedPatients = [];

      if (session.get('portal') === 'staff') {
        if (perms.indexOf(requiredPersmission) > -1) {
          deferred.resolve([true]);
        } else {
          deferred.resolve([]);
        }

      }
      else if (onlyPatientIds) {
        _.forEach(perms, function (p) {
          if (p.slice(p.indexOf('.')) === '.' + requiredPersmission) {
            permittedPatients.push(p.split('.')[0]);
          }
        });
        deferred.resolve(permittedPatients);
      } else {
        api.user.patients.get({ userid: session.get('userId') }).$promise.then(function (response) {
          _.forEach(response.results.Retval, function (user) {
            if (_.contains(perms, user.Id + '.' + requiredPersmission)) {
              permittedPatients.push(user);
            }
          });
          deferred.resolve(permittedPatients);
        }, function (error) {
          deferred.reject(error);
        });
      }
      return deferred.promise;
    };

    appsvc.getPatientId = function (requiredPersmission) {
      if (session.get('portal') === 'staff') {
        return api.staff.userManagement.patients.get({ uniqueId: app.routing.routeParams.mrn }).$promise.then(function (response) {
          session.set('CurrentPatient', JSON.stringify(response));
          return [response];
        });
      }

      return appsvc.getPatientHavingPermission(requiredPersmission);
    };

    // get the offset value based on the user timezone
    appsvc.getUserTimeZone = function () {
      return api.user.timeZone.get({ userId: session.get('userId') }).$promise.then(function (response) {
        return response.results;
      });
    };

    /* get appointment actions based on appointment status */
    appsvc.getAppointmentActions = function (appointment, appSettings) {
      var appointmentStatus = (loc.search().status) ? loc.search().status.toLowerCase() : '';
      var patientId = loc.search().patientId.toString();
      if (appointment) {
        appointment.permissions = [];
      }
      switch (appointmentStatus.toLowerCase()) {
        case 'active':
          appointment.permissions.push({ name: translate.instant('APPOINTMENTS_PRE_REGISTER'), accesslevel: patientId + '.appointments.future.preregister', icon: 'appointment_icon_preregister', redirectionUrl: 'pre-register', canView: appSettings.ManageAvailableActions[0].PreRegister,appointmentStatus:'Pre-register' });
          appointment.permissions.push({ name: translate.instant('APPOINTMENTS_ADD_TO_CALENDAR'), accesslevel: patientId + '.appointments.future.export', icon: 'appointment_icon_add', redirectionUrl: 'add-to-calendar', canView: appSettings.ManageAvailableActions[0].ExportToCalendar, appointmentStatus: 'addtocalender' });
          appointment.permissions.push({ name: translate.instant('APPOINTMENTS_RESCHEDULE'), accesslevel: patientId + '.appointments.future.reschedule', icon: 'appointment_icon_reschedule', redirectionUrl: 'reschedule-appointment', canView: appSettings.ManageAvailableActions[0].Reschedule, appointmentStatus: 'Reschedule' });
          appointment.permissions.push({ name: translate.instant('CANCEL'), accesslevel: patientId + '.appointments.future.cancel', icon: 'appointment_icon_cancel', redirectionUrl: 'cancel-appointment', canView: appSettings.ManageAvailableActions[0].Cancel, appointmentStatus: 'Cancel' });
          break;
        case 'cancelled':
          appointment.permissions.push({ name: translate.instant('APPOINTMENTS_REBOOK_APPOINTMENT'), accesslevel: patientId + '.appointments.past.rebook', icon: 'appointment_icon_rebook', redirectionUrl: 're-book-appointment', canView: appSettings.ManageAvailableActions[1].ReBook, appointmentStatus: 'appointmentStatus' });
          appointment.permissions.push({ name: translate.instant('APPOINTMENTS_REMOVE_FROM_CALENDER'), accesslevel: patientId + '.appointments.past.export', icon: 'appointment_icon_remove', redirectionUrl: 'remove-from-calendar', canView: appSettings.ManageAvailableActions[1].ExportToCalendar, appointmentStatus: 'removefromcalender' });
          break;
        case 'completed':
          appointment.permissions.push({ name: translate.instant('APPOINTMENTS_REBOOK_APPOINTMENT'), accesslevel: patientId + '.appointments.past.rebook', icon: 'appointment_icon_rebook', redirectionUrl: 're-book-appointment', canView: appSettings.ManageAvailableActions[1].ReBook,appointmentStatus:appointmentStatus });
          break;
        case 'pre-registered':
          appointment.permissions.push({ name: translate.instant('APPOINTMENTS_ADD_TO_CALENDAR'), accesslevel: patientId + '.appointments.future.export', icon: 'appointment_icon_add', redirectionUrl: 'add-to-calendar', canView: appSettings.ManageAvailableActions[0].ExportToCalendar, appointmentStatus: 'addtocalender' });
          break;
      }
      return appointment;
    };

    /* get appointment based on the appointment id and status */
    appsvc.getAppointment = function () {
      var appointmentId = '';

      if (loc.search().id !== undefined || loc.search().id !== null) {
        appointmentId = loc.search().id.toString();
      }
      if (patientId === undefined) {
        var PatId = session.getObject('CurrentPatient') || {};
        patientId = PatId.Id;
      }
      patientId = (loc.search().patientId) ? loc.search().patientId.toString() : patientId;
      // checking for direct schedule

      if (appointmentId === '0') { // get direct schedule
        return api.appointments.getAppointmentByExternalId.get({ patientId: patientId, appointmentExternalId: loc.search().externalId }, null).$promise.then(function (response) {
          response.results.Retval.patient = (session.getObject('CurrentPatient')) ? session.getObject('CurrentPatient') : JSON.parse(session.get('patient'));
          if (response.results.Retval && response.results.Retval.patient && !response.results.Retval.patient.MedicalRecordNumber || !response.results.Retval.patient.MedseekId) {
            response.results.Retval.patient.MedicalRecordNumber = response.results.Retval.patient.MedseekId = response.results.Retval.patient.mrn;
          }
          return response.results.Retval;

        });
      } else {
        // get Indirect schedule
        return api.appointments.getAppointmentById.get({ patientId: patientId, appointmentId: appointmentId }, null).$promise.then(function (response) {
          return response.results.Retval;
        });
      }
    };

    /* get appointment type on the appointment type id */
    appsvc.getAppointmentType = function (body) {
      return api.appointments.getAppointmentType.save({ patientId: patientId }, body).$promise.then(function (response) {
        return response.results.Retval;
      });
    };

    /* get appointment type on the appointment type id */
    appsvc.getDynamicFormById = function (formId, isAppointmentTypeDynamicForm) {
      var deferred = q.defer();
      api.dynamicFormsById.get({ formId: formId }, null).$promise.then(function (response) {
        if (isAppointmentTypeDynamicForm) {
          api.appointments.appntResponeType.get({ patientId: patientId }).$promise.then(function (res) {
            if (response && response.results && response.results.Retval) {
              response.results.Retval.fields.forEach(function (field) {
                if (field.name === 'ContactInformation') {
                  field.listItems = res.results;
                  session.set('ContactInformation', angular.toJson(res.results));
                }
              });
            }
            deferred.resolve(response.results.Retval);
          });
        } else {
          deferred.resolve(response.results.Retval);
        }

      }, function (error) {
        deferred.reject(error);
      });

      return deferred.promise;
    };

    /* save the pre-Registration information */
    appsvc.savePreRegistrationInformation = function (body) {
      return api.appointments.savePreRegistrationInformation.save({ patientId: patientId, id: body.entity.AppointmentId }, body).$promise.then(function (response) {
        return response.results.Retval;
      });
    };
    appsvc.getDynamicFormData = function (model, dynamicform, app) {
      var dynamicValues = {selectedAppointmentXml: []};
      _.forEach(dynamicform.fields, function (item) {
        dynamicValues.selectedAppointmentXml.push({
          key: item.name === 'CancelReason'?'Reason for cancellation':'Additional Information',
          value: item.type === 'DropDown' ? (model[item.name] ? model[item.name].name : 'Not available')
            : (model[item.name] ? model[item.name] : 'Not available')
        });

      });
      if (app) {
        dynamicValues.selectedAppointmentXml.push({ key: 'Reason for Visit', value: app.AppointmentTypeName });
      }
      return dynamicValues;
    };
    /* build the submit body for pre-Registration */
    appsvc.getPreRegistrationInformationSubmitBody = function (app, model, dynamicform) {
      var body = {
        'entity': {
          'Id': '0',
          'VisitDate': app.AppointmentDateTime,
          'PatientId': app.PatientId,
          'PhysicianId': app.PhysicianId,
          'PhysicianName': app.PhysicianName,
          'LocationId': app.LocationId,
          'LocationName': app.LocationName,
          'PreRegistrationTypeId': 1,
          // 'ReligionId': model.Religion,
          // 'LanguageId': model.PreferredLanguage,
          'HasAdvanceDirective': false,
          'AdvanceDirectiveName': 'advance',
          'AdvanceDirectivePhone': '1111111111',
          'HasPowerOfAttorney': (model.DurablePowerOfAttorney && model.DurablePowerOfAttorney === '1') ? true : false,
          'PowerOfAttorneyName': 'Example String',
          'PowerOfAttorneyPhone': 'Example String',
          'IsOrganDonor': (model.RegisteredOrganDonor && model.RegisteredOrganDonor === '1') ? true : false,
          'Comments': model.AdditionalInformationData,
          'AppointmentId': app.Id,
          'XmlData': '<root><data><value key="AppointmentComments" label="Comments" /></data></root>',
          'ExternalAppointmentId': app.ExternalId,
          'AppointmentTypeFormStringData': angular.toJson(appsvc.getDynamicFormData(model, dynamicform, app))
        }
      };
      return body;
    };

    /* get appointments based on the type(type will be upcoming or past) */
    appsvc.getAppointments = function (body, type) {
      return appsvc.getPatientId((type.toLowerCase() === 'upcoming') ? 'appointments.future.view' : 'appointments.past.view').then(function (patients) {
        var promises = [];
        _.forEach(patients, function (patient) {
          if (!patient.Id || !patient.MedicalRecordNumber) {
            return;
          }
          promises.push(api.appointments.getAppointments.get({ patientId: patient.Id, medseekId: patient.MedicalRecordNumber, isFutureAppointment: (type.toLowerCase() === 'upcoming') ? 'future' : 'past' }, null).$promise.then(function (response) {
            return response.results;
          }));
        });

        return q.all(promises).then(function (allPatientsAppointments) {
          var allAppointments = {
            retval: []
          };
          _.forEach(allPatientsAppointments, function (appointment) {
            allAppointments.retval = allAppointments.retval.concat(appointment.retval);
            allAppointments.canViewUpcoming = appointment.canViewUpcoming;
            allAppointments.showUpcoming = appointment.showUpcoming;
            allAppointments.canViewPast = appointment.canViewPast;
            allAppointments.showPast = appointment.showPast;
          });
          var appointments = [];
          var data = allAppointments.retval;
          var years = _(data).map(function (appt) {
            return new Date(appt.AppointmentDateTime).getFullYear();
          })
            .uniq()
            .value();

          _.forEach(years, function (year) {
            var currentYearData = { appointments: [] };
            var records = [];

            _.forEach(data, function (record) {
              var currentRecordYear = new Date(record.AppointmentDateTime).getFullYear();
              if (currentRecordYear === year) {
                switch (record.Status.toLowerCase()) {
                  case 'active':
                    record.style = 'confirm';
                    break;
                  case 'pending':
                  case 'pending approval':
                    record.style = 'pending';
                    break;
                  case 'inactive':
                  case 'pending reschedule':
                    record.style = 'pending'; // reschedule
                    break;
                  case 'cancelled':
                  case 'pending cancellation':
                    record.style = 'reschedule';
                    break;
                  case 'pre-registered':
                  case 'completed':
                    record.style = 'confirm';
                    break;
                  default:
                    break;
                }
                record.timeZoneId = body.timeZoneId;
                records.push(record);
              }
            });

            currentYearData.year = year;
            currentYearData.appointments = records;
            appointments.push(currentYearData);
          });
          appointments.canViewUpcoming = allAppointments.canViewUpcoming;
          appointments.showUpcoming = allAppointments.showUpcoming;
          appointments.canViewPast = allAppointments.canViewPast;
          appointments.showPast = allAppointments.showPast;
          return appointments;
        });

      });
    };

    /* get dynamic text */
    appsvc.getDynamicText = function (key) {
      var patient = session.getObject('patient');
      var user = session.getObject('userFullName');
      return gs.dynamicText.getDynamicText('AppointmentRequest', key, user, patient).then(function (dynamicText) {
        return dynamicText;
      });
    };

    /* get dynamic text */
    appsvc.getAllDynamicText = function () {
      return api.appointments.getAllDynamicText.get({ patientId: patientId || 0 }).$promise.then(function (res) {
        return res.results;
      });
    };

    /* Reschedule indirect appointment */
    appsvc.rescheduleIndirectAppointment = function (body) {
      return api.appointments.rescheduleIndirectAppointment.save({ patientId: patientId }, body).$promise.then(function (res) {
        return res.results;
      });
    };

    /* Reschedule direct appointment */
    appsvc.rescheduleDirectAppointment = function (body) {
      return api.appointments.rescheduleDirectAppointment.save({ patientId: patientId }, body).$promise.then(function (res) {
        return res.results;
      });
    };

    /* cancel indirect appointment */
    appsvc.cancelIndirectAppointment = function (body) {
      return api.appointments.cancelIndirectAppointment.save({ patientId: patientId }, body).$promise.then(function (res) {
        return res.results;
      });
    };

    /* cancel direct appointment */
    appsvc.cancelExternalAppointment = function (body) {
      return api.appointments.cancelExternalAppointment.save({ patientId: patientId }, body).$promise.then(function (res) {
        return res.results;
      });
    };

    /* checks permission for patient */
    appsvc.checkPatientPermission = function (patient, permissionName) {
      return _.filter(session.getObject('currentPermissionSet'), function (permission) {
        var prefix = session.get('portal') === 'staff' ? '' : ((patient.patientId || patient.Id) + '.');
        return (permission === (prefix + permissionName));
      }).length;
    };

    appsvc.sortArray = function (collection, field, direction, fieldType) {
      field = field.split('.').length > 1 ? field.split('.') : field;
      if (!collection) { return; }
      collection.sort(function (a, b) {
        if (direction === 'asc') {
          // for numbers
          if (fieldType === 'n') { return a[field] > b[field] ? 1 : -1; }
          // for date
          if (fieldType === 'd') { return (a[field] ? Date.parse(a[field]) : new Date()) > (b[field] ? Date.parse(b[field]) : new Date()) ? 1 : -1; }
          // for string
          if (fieldType === 's') {
            if (angular.isArray(field) && field.length === 2) { return a[field[0]][field[1]].toUpperCase() > b[field[0]][field[1]].toUpperCase() ? 1 : -1; }
            return a[field].toUpperCase() > b[field].toUpperCase() ? 1 : -1;
          }
        } else {
          if (fieldType === 'n') { return a[field] > b[field] ? -1 : 1; }
          if (fieldType === 'd') { return (a[field] ? Date.parse(a[field]) : new Date()) > (b[field] ? Date.parse(b[field]) : new Date()) ? -1 : 1; }
          if (fieldType === 's') {
            if (angular.isArray(field) && field.length === 2) { return a[field[0]][field[1]].toUpperCase() > b[field[0]][field[1]].toUpperCase() ? -1 : 1; }
            return a[field].toUpperCase() > b[field].toUpperCase() ? -1 : 1;
          }
        }
      });
      return collection;
    };

    return angular.extend(svc, appsvc);
  }]);

}(window.app, window.angular, window.jQuery));
