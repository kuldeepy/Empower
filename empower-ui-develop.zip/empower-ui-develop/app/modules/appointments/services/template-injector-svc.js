(function (app) {
  'use strict';

  var basePath = "'/modules/appointments/templates/";
  var templates = {
    switchPatientDialog: '<div ng-include="' + basePath + 'switch-patient-dialog.html\'"></div>',
    physicianLookUp: '<ms-add-physician />',
    locationLookUp: '<ms-add-location />',
    staffApprovalRequired: '<div ng-include="' + basePath + 'staff-approval-required.html\'"></div>',
    addInsurance: '<div ng-include="' + basePath + 'add-insurance.html\'"></div>'
  // successConfimation: "<div ng-include=\"" + basePath + "confirm-success.html'\"></div>"
  };

  app.value('getAppointmentDialogContant', templates);
}(window.app));
