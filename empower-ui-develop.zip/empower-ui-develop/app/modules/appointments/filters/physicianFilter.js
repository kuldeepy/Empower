(function (app) {
  'use strict';
  app.filter('physicianFilter', [function () {
    return function (data) {
      if (data) {
        var approvedPhysicians = [];
        _.forEach(data, function (physician) {
          if (physician.IsApproved === true || physician.IsApproved === undefined) {
            approvedPhysicians.push(physician);
          }
        });
        return approvedPhysicians;
      } else {
        return null;
      }
    };
  }]);
})(window.app);
