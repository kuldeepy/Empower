(function (app) {
  'use strict';
  app.filter('appntDate', ['$filter', function (filter) {
    return function (date, format) {
      if (date) {
        date = moment(date);
        if ((date.get('hours') * 60) < 720) {
          return date.format('hh:mm') + ' AM';
        } else {
          return date.format('hh:mm') + ' PM';
        }
      } else { return ''; }
    };
  }]);
})(window.app);
