(function (app) {
  'use strict';
  app.filter('messageDate', ['$filter', function (filter) {
    return function (date, format) {
      if (date) {
        if (format) {
          return filter('date')(date, format);
        } else {
          return moment().isSame(date, 'day') ?
            filter('date')(date, 'shortTime') :
            filter('date')(date, 'MM/dd/yyyy');
        }
      } else { return ''; }
    };
  }]);
})(window.app);
