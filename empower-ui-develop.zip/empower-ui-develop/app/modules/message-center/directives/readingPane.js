(function (app) {
  'use strict';

  app.directive('msgctrReadingPane', ['messagingService', '$location', 'dialogService', 'alertService', '$sce', function (messageSvc, location, dialogService, alertService, sce) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/message-center/templates/reading-pane.html',
      scope: {
        model: '=',
        message: '=',
        columns: '=',
        isStaffUser: '=',
        moduleSettings: '=',
        searchFlag: '=',
        currentState: '=', // change state view on mobile
        replyDisableText: '='
      },
      link: function (scope, element, attrs, ngModel) {
        // determine image URL
        scope.imageUrl = function (message) {
          // TODO: resolve a real URL?
          // determine if sender if male of female?
          return app.root + 'themes/default/images/male.png';
        };

        scope.oneAtATime = false;
        // call service to set property of any message like: IsRead,IsUnread
        scope.deleteDraftMessage = function (messageId) {
          dialogService.show('discardDraft');
        };

        // call service to set property of any message like: IsRead,IsUnread
        scope.recallMessage = function (messageId) {
          dialogService.show('recallMessage');
        };

        scope.downloadAttachment = function (attachment) {
          messageSvc.downloadAttachment(attachment.Id).then(function (res) {
            var data = _base64ToArrayBuffer(res.results.FileBase64);
            var type = res.results.Details.Type;
            var blob = new Blob([data], { type: type });
            // Tell the browser to save as report.txt.
            saveAs(blob, res.results.Details.Name);
          // alertService.add('success', 'Attacment download successfully', 5000);
          });
        };

        scope.isWithinMaxDaysForReplying = function (date) {
          if (scope.moduleSettings && +scope.moduleSettings.DaysPatientReplyAllowed === 0) {
            return true;
          }
          if (date !== undefined && !scope.isStaffUser && scope.moduleSettings) {
            return moment().diff(new Date(date), 'days') < scope.moduleSettings.DaysPatientReplyAllowed;
          } else {
            return true;
          }
        };

        scope.toTrusted = function (htmlCode) {
          return sce.trustAsHtml(htmlCode);
        };

        /* function to get education article link content */
        scope.getEducationArticleLink = function (contentLink) {
          // messageSvc.getContentDocument(contentId, contentTypeId).then(function (response) {
          //   var linkData = response.results.ContentItems[0];
          //   if (linkData) {
          //     var openLink = window.open();
          //     openLink.document.write('<html><head><title>' + linkData.Title + '</title></head>');
          //     openLink.document.write(linkData.Content);
          //     openLink.document.write('</html>');
          //     openLink.document.close();
          //     openLink.focus();
          //   }
          // });
          window.open(contentLink, '_blank');
        };
      }
    };
  }]);
  function _base64ToArrayBuffer (base64) {
    var binaryString = window.atob(base64);
    var len = binaryString.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
    }
    return bytes.buffer;
  }

}(window.app));
