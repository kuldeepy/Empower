(function (app) {
  'use strict';

  app.directive('msgctrMailboxList', ['dialogService', 'messagingService', '$timeout', '$location', function (dialogService, messageSvc, $timeout, location) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/message-center/templates/mailbox-list.html',
      scope: {
        mailboxes: '=', // bind available folders
        defaultMailboxes: '=',
        mailboxParam: '&', // selected mailbox key
        mailboxRoute: '@', // base route for mailboxes
        selectedMailbox: '=', // bind selected folder
        mailboxChange: '=', // event for mailbox selection
        newFolderName: '=',
        parentId: '=',
        parent: '=',
        folderObj: '=',
        getMessagesCount: '=',
        searchMessages: '=',
        baseMessages: '=',
        makeSubFolder: '=',
        searchFlag: '=',
        searchText: '=',
        folderList: '=',
        flattenFolder: '=',
        currentState: '=', // States for mobile view
        errorMessage: '='
      },
      link: function (scope, element, attrs) {
        //
        scope.icons = { INBOX: 'fa fa-inbox', DRAFT: 'fa fa-file-text-o', SENT: 'fa fa-envelope-o', ARCHIVE: 'fa fa-file-archive-o', DELETED: 'fa fa-trash-o', MYFOLDER: 'fa fa-folder-o' };
        scope.folderDropdown = {};
        // binds $watch for mailbox-params after getting mailboxes
        scope.unbindThisWatch = scope.$watch('mailboxes', function () {
          if (scope.mailboxes) {
            scope.bindParam$Watch();
            // unbinds it-self after binding mailbox-params $watch
            scope.unbindThisWatch();
            scope.getMessagesCount();
          }
        });

        scope.bindParam$Watch = function () {
          // sync selected mailbox with route param
          scope.$watch('mailboxParam()', function (val) {
            // capture old and new values
            var old = scope.selectedMailbox;
            if (val) {
              scope.selectedMailbox = val.toUpperCase();
            }

            // notify controller of mailbox changes
            (scope.mailboxChange || angular.noop)(scope.selectedMailbox, old);
          });
        };

        /* show dialog for new folder */
        scope.showDialogForNewFolder = function (oldFolder) {
          scope.parent = '';
          scope.errorMessage = null;
          scope.makeSubFolder = false;
          scope.folderObj = null;
          scope.newFolderName = undefined;
          dialogService.show('newFolder');
        };
        // trim the current editing folder from folder list
        scope.trimFolderList = function (oldFolder, flattenFolder) {
          scope.folderList = _.filter(flattenFolder, function (folder) {
            return (+folder.Id !== +oldFolder.Id);
          });
          scope.findChildren(scope.folderList, oldFolder);
        };

        scope.findChildren = function (folderList, parent) {
          var children = _.filter(folderList, function (folder) {
            return +folder.ParentId === +parent.Id;
          });
          angular.forEach(children, function (child) {
            scope.trimFolderList(child, scope.folderList);
          });
        };

        /* show dialog for new folder */
        scope.showDialogForEditFolder = function (oldFolder) {
          scope.errorMessage = null;
          scope.makeSubFolder = true;
          var parent = _.filter(scope.flattenFolder, function (folder) { return +folder.Id === +oldFolder.ParentId; }) || '';
          scope.parent = parent.length > 0 ? parent[0] : null;
          if (scope.parent === null) {
            scope.makeSubFolder = false;
          }
          // prefilling of folder name in text box
          scope.newFolderName = oldFolder ? oldFolder.Name : undefined;
          scope.trimFolderList(oldFolder, scope.flattenFolder);
          // saving old name for comparision
          scope.folderObj = oldFolder;
          dialogService.show('editFolder');
        };

        /* show dialog for new folder */
        scope.showDialogForNewSubFolder = function (parentFolder) {
          scope.parent = parentFolder;
          scope.folderObj = parentFolder;
          scope.makeSubFolder = true;
          scope.newFolderName = undefined;
          scope.parentId = parentFolder.Id;
          dialogService.show('newFolder');
        };

        /* show dialog for delete folder */
        scope.showDialogForDelete = function (folder) {
          scope.folderObj = folder;
          dialogService.show('deleteFolder');
        };

        /*Get new message count*/
        scope.getMessagesCount = function () {
          messageSvc.getMessagesCount().then(function (res) {
            scope.baseMessages.count = res > 0 ? res : undefined;
          });
        };

        scope.searchTextChange = function () {
          scope.searchMessages(scope.searchText, null, 1);
        };

        scope.toogleDropdownIcon = function (Id) {
          scope.folderDropdown = {};
          Id ? scope.folderDropdown[Id] = true : scope.folderDropdown[Id] = false; // jshint ignore:line
        };

        scope.resetSearch = function (path) {
          scope.searchText = undefined;
          location.path() === path ? scope.searchMessages(scope.searchText, null, 1) : null; // jshint ignore:line
        };
        // Switches between view states in mobile

        scope.switchCurrentState = function (state, mailboxName) {
          messageSvc.setCurrentState(state);
          messageSvc.setCurrentFolder(mailboxName);
        };
      }
    };

  }]);

}(window.app));
