(function (app) {
  'use strict';

  app.directive('broadcastRecipients', ['messagingService', 'dialogService', 'Msgctr.Broadcast', 'generic', function (messageSvc, dialogService, broadcastSvc, generic) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/message-center/templates/broadcast-recipients.html',
      scope: {
        init: '=',
        compose: '='
      },
      link: function (scope, element, attrs, ngModel) {
        scope.importListsLeft = [];
        scope.importListsRight = [];
        scope.targetGroupListsLeft = [];
        scope.targetGroupListsRight = [];

        // react when popup opens,to get list of items
        scope.init = function () {
          broadcastSvc.getImportList().then(function (res) {
            scope.importListsLeft = generic.sortArray(res, 'Name', 'asc', false);
            if (scope.compose.To.length > 0) {
              scope.importListsRight = [];
              scope.tempImportListsRight = [];
              angular.forEach(scope.compose.To, function (data) {
                if (data.isImportList === true) {
                  scope.tempImportListsRight.push(_.find(scope.importListsLeft, function (list) {
                    return (list.Id === data.Id && data.isImportList === true);
                  }));
                  scope.importListsLeft = _.reject(scope.importListsLeft, function (item) {
                    return (item.Id === data.Id && data.isImportList === true);
                  });
                }
              });
              scope.importListsRight = scope.tempImportListsRight;
            } else {
              scope.importListsRight = [];
            }
            broadcastSvc.getModules().then(function (response) {
              var module = _.find(response, {'ModuleId': 'MessageCenter'});
              broadcastSvc.getTargetGroups({ moduleInstanceId: module.Id }).then(function (res) {
                scope.targetGroupListsLeft = generic.sortArray(res, 'Name', 'asc', false);
                if (scope.compose.To.length > 0) {
                  scope.targetGroupListsRight = [];
                  scope.tempTargetGroupListsRight = [];
                  angular.forEach(scope.compose.To, function (data) {
                    if (data.isTargetGroupList === true) {
                      scope.tempTargetGroupListsRight.push(_.find(scope.targetGroupListsLeft, function (list) {
                        return (list.Id === data.Id && data.isTargetGroupList === true);
                      }));
                      scope.targetGroupListsLeft = _.reject(scope.targetGroupListsLeft, function (item) {
                        return (item.Id === data.Id && data.isTargetGroupList === true);
                      });
                    }
                  });
                  scope.targetGroupListsRight = scope.tempTargetGroupListsRight;
                } else {
                  scope.targetGroupListsRight = [];
                }
                $('.broadcastRecipientsPopup').modal({ 'backdrop': 'static', keyboard: false });
              });
            });
          });
        };
        // reacts on shift button click
        scope.shift = function (dataModel, srcModel, destModel) {
          angular.forEach(scope[dataModel], function (d, k) {
            scope[srcModel] = _.reject(scope[srcModel], function (val) { return _.isEqual(val, d); });
            scope[destModel].push(d);
          });
          scope[srcModel] = generic.sortArray(scope[srcModel], 'Name', 'asc', false);
          scope[destModel] = generic.sortArray(scope[destModel], 'Name', 'asc', false);
          scope[dataModel] = [];
        };
        // sets importlist and target group for compose 'TO'
        scope.setData = function (importList, targetGroupList) {
          angular.forEach(importList, function (impList) {
            impList['isImportList'] = true;
          });
          angular.forEach(targetGroupList, function (tgList) {
            tgList['isTargetGroupList'] = true;
          });

          scope.compose.To = importList.concat(targetGroupList);
          $('.broadcastRecipientsPopup').modal('hide');
        };
        // close dialog
        scope.closeDialog = function () {
          $('.broadcastRecipientsPopup').modal('hide');
        };
      }
    };
  }]);

}(window.app));
