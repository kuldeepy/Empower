(function (app) {
  'use strict';

  app.directive('msgctrMessageList', ['messagingService', 'messageCenterMailBoxService', '$timeout', 'session', function (messageSvc, mailboxSvc, $timeout, session) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/message-center/templates/message-list.html',
      scope: {
        model: '=',
        messages: '=',
        selectedMessage: '=',
        checkedMessages: '=',
        setSelectedMessage: '=',
        setMessageProperty: '=',
        columns: '=',
        getMessagesCount: '=',
        searchFlag: '=',
        pagingOption: '=',
        messageList: '=',
        selectAllMessage: '=',
        currentColumn: '=',
        isSortedType: '=',
        searchBox: '=',
        searchText: '=',
        currentState: '=' // change state view on mobile
      },
      link: function (scope, element, attrs, ngModel) {
        scope.messageList = {
          checkAll: false
        };
        // set selected Message for reading-pane
        scope.setSelectedMessage = function (message) {
          if (message.HtmlBody) {
            message.HtmlBody = message.HtmlBody.replace('$$UserName$$', session.get('user'));
          } else {
            message.Body = message.Body.replace('$$UserName$$', session.get('user'));
          }
          scope.selectedMessage = message;
          if (message && message.IsUnread) {
            var messageIdObj = {};
            messageIdObj[message.Id] = true;
            scope.setMessageProperty('IsUnread', false, messageIdObj);
          }
        };
        // call service to set property of any message like: IsRead,IsUnread
        scope.setMessageProperty = function (property, value, messageIds) {
          messageSvc.setMessageProperty(property, value, messageIds).then(function (res) {
            scope.getMessagesCount();
            scope.bindProperty(res);
          });
        };
        // reflect changing properties of message back to view
        scope.bindProperty = function (bindingEntity) {
          angular.forEach(scope.messages, function (message, key) {
            bindingEntity.Changed.indexOf(message.Id) > -1 ?
              message[bindingEntity.Property] = bindingEntity.Value : null; // jshint ignore:line
          });
        };
        // select messages : property param will be used if wants to select reads and unreads
        scope.selectAllMessage = function (property, value) {
          // select none
          scope.checkedMessages = {};
          // checks for what to select
          if (value) {
            angular.forEach(scope.messages, function (message, index) {
              scope.checkedMessages[message.Id] = true;
            });
          }
        };
        // sets Other folder names to specific folder name
        scope.putMailBoxNames = function (messages) {
          _.forEach(messages, function (message) {
            if (message.Folder === 'Other') {
              var boxObject = _.filter(scope.mailboxes, function (box) {
                return message.MailboxId === box.Id;
              });

              message.Folder = (boxObject && boxObject.length) ? boxObject[0].Name : message.Folder;
            }
          });
          return messages;
        };

        scope.selectMessage = function () {
          var isAllChecked = true;
          angular.forEach(scope.messages, function (message, index) {
            if (scope.checkedMessages[message.Id] === undefined || scope.checkedMessages[message.Id] === false) {
              isAllChecked = false;
            }
          });
          scope.messageList.checkAll = (isAllChecked) ? true : false;
        };

        scope.getMailBox = function () {
          mailboxSvc.getDefaultMailboxes().then(function (defaultMailboxes) {
            scope.defaultMailBoxs = defaultMailboxes;
          });
        };

        scope.sortColumn = function (columnName, mailbox) {
          var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
          if (scope.pagingOption.currentPage > total) {
            alertService.add('danger', 'Please enter the valid page number.');
            return;
          }
          scope.getMailBox();
          scope.isSortedType = (scope.isSortedType === 'asc') ? 'desc' : 'asc';
          scope.currentColumn = columnName;

          if (!scope.searchText) {
            scope.searchText = '';
          }

          var obj = { 'Sort': scope.currentColumn + '|' + scope.isSortedType + '', 'Limit': scope.pagingOption.pageSize, 'Position': 1 };
          if (scope.searchText !== '' && scope.searchText.length >= 3) {
            obj = { 'Sort': scope.currentColumn + '|' + scope.isSortedType + '', 'Search': scope.searchText, 'Limit': scope.pagingOption.pageSize, 'Position': 1 };
          }
          if (scope.pagingOption.currentPage === 1) {
            var box = scope.searchFlag ? (scope.searchBox === 'ARCHIVE') ? 'ARCHIVE' : null : mailbox;
            messageSvc.getMessages(box, obj).then(function (messages) {
              scope.messages = messages.Messages;
              scope.messages.forEach(function (data) {
                messageSvc.getMessageThread(data.Id, 10, 1).then(function (res) {
                  data.messageThread = res.results.Messages.filter(function (item) {
                    return item.Id <= data.InResponseTo;
                  });
                });
                var userid = (mailbox.toUpperCase() === 'SENT' || mailbox.toUpperCase() === 'DRAFT') && !scope.searchFlag ? data.To[0].Id : data.From[0].Id;
                messageSvc.getUserImage(userid).then(function (res) {
                  data.image = (res.results.image === null) ? null : 'data:image/jpeg;base64,' + res.results.image;
                });
                if (data.Folder === 'Other') {
                  var boxObject = _.filter(scope.defaultMailBoxs, function (box) {
                    return data.MailboxId === box.Id;
                  });

                  data.Folder = (boxObject && boxObject.length) ? boxObject[0].Name : data.Folder;
                }
              });
              scope.messages ? scope.setSelectedMessage(scope.messages[0]) : null; // jshint ignore:line
            });
          } else {
            $timeout(function () {
              scope.pagingOption.currentPage = 1;
            }, 100);
          }
        };
        // Switches between view states in mobile

        scope.switchCurrentState = function (state) {
          messageSvc.setCurrentState(state);
        };
      }
    };
  }]);

}(window.app));
