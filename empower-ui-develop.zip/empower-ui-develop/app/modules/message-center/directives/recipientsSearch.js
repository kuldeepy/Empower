(function (app) {
  'use strict';

  app.directive('recipientsSearch', ['messagingService', 'dialogService', '$timeout', 'alertService', 'Msgctr.Utility', 'session', 'userPermissionsSvc', function (messageSvc, dialogService, timeout, alertService, utilitySvc, session, userPermissionsSvc) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/message-center/templates/recipients-search.html',
      scope: {
        compose: '=',
        showReceipent: '=',
        showRePatient: '=',
        initSearch: '=',
        composeForm: '='
      },
      link: function (scope, element, attrs, ngModel) {
        scope.searchFieldsData = {};
        scope.shakeTextboxes = false;
        scope.compose.toIsAStaffUser = false;
        var month = '' + (1 + new Date().getMonth()).toString().length > 1 ? (1 + new Date().getMonth()) : '0' + (1 + new Date().getMonth());
        scope.todayDate = new Date().getFullYear() + '-' + month + '-' + new Date().getDate();

        scope.pagingOption = {
          pageSize: 10,
          totalItems: 1000,
          currentPage: 1,
          pageOption: [10, 50, 100, 500]
        };
        scope.setNumberOfPages = scope.pagingOption.pageOption[0];

        scope.$watch('pagingOption.currentPage', function (newVal, oldVal) {
          // call api for next page  
          alertService.clear();
          var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
          if (oldVal !== newVal && newVal !== '' && parseInt(newVal) > 0 && total >= newVal) {
            scope.getPaginatedData();
          }
          else if (isNaN(newVal) || parseInt(newVal) >= total || parseInt(newVal) <= 0 || isNaN(parseInt(newVal))) {
            alertService.add('danger', 'Please enter the valid page no');
          }
        });

        scope.$watch('pagingOption.pageSize', function (oldVal, newVal) {
          // call api for content in one page            
          if (oldVal !== newVal) {
            scope.pagingOption.currentPage = 1;
            scope.searchResult = scope.totalsearchResult.slice(0, newVal);
          }
        });

        scope.getPaginatedData = function () {
          var searchFieldsData = scope.searchFieldsData;
          var recipientType = scope.recipientType;

          searchFieldsData.pageSize = scope.pagingOption.pageSize;
          searchFieldsData.pageNumber = scope.pagingOption.currentPage;
          messageSvc.searchRecipient(searchFieldsData, recipientType.type).then(function (res) {
            scope.searchHeader = recipientType.resultDetails;
            scope.totalsearchResult = recipientType.type === 'STAFF' ? _.filter(res, function (r) {
              return +r.Id !== +session.get('userId');
            }) : res;

            if (recipientType.type === 'RECORDS') {
              scope.searchResult = res.patientRecipient;
              scope.pagingOption.totalItems = res.total;
            } else {
              scope.searchResult = scope.totalsearchResult.slice((scope.pagingOption.currentPage - 1) * scope.pagingOption.pageSize, scope.pagingOption.currentPage * scope.pagingOption.pageSize);
              scope.pagingOption.totalItems = scope.totalsearchResult.length;
            }

          });
        };

        scope.allToRecipientTypes = [
          {
            name: 'Patient Users',
            type: 'PATIENT',
            displayName: 'Recipient Search',
            searchFields: [
              { model: 'LastName', type: 'text', displayName: 'Last Name' },
              { model: 'FirstName', type: 'text', displayName: 'First Name' },
              { model: 'UserName', type: 'text', displayName: 'Username' },
              { model: 'Email', type: 'email', displayName: 'Email Address' }
            ],
            resultDetails: [
              { displayName: 'Full Name', dataKey: 'Name' },
              { displayName: 'Username', dataKey: 'UserName' },
              { displayName: 'Date of Birth', dataKey: 'DateofBirth' },
              { displayName: 'Email Address', dataKey: 'Email' },
              { displayName: 'Linked Patient(s)', dataKey: 'LinkedPatients' }
            ],
            permission: ['message-center.messages.recipients.users.add']
          },
          {
            name: 'Staff Users',
            type: 'STAFF',
            displayName: 'Recipient Search',
            searchFields: [
              { model: 'LastName', type: 'text', displayName: 'Last Name' },
              { model: 'FirstName', type: 'text', displayName: 'First Name' },
              { model: 'UserName', type: 'text', displayName: 'Username' },
              { model: 'Email', type: 'Email', displayName: 'Email Address' }
            ],
            resultDetails: [
              { displayName: 'Full Name', dataKey: 'Name' },
              { displayName: 'Username', dataKey: 'UserName' },
              { displayName: 'Email Address', dataKey: 'Email' }
            ],
            permission: ['message-center.messages.recipients.staff.add']
          }
        ];
        scope.rePatientRecipientType = [
          {
            name: 'Patient Records',
            type: 'RECORDS',
            displayName: 'Patient Search',
            searchFields: [
              { model: 'LastName', type: 'text', displayName: 'Last Name' },
              { model: 'FirstName', type: 'text', displayName: 'First Name' },
              { model: 'ExternalSourceId', type: 'text', displayName: 'Patient ID' },
              { model: 'DateofBirth', type: 'date', displayName: 'Date of Birth' }
            ],
            resultDetails: [
              { displayName: 'Full Name', dataKey: 'Name' },
              { displayName: 'Patient IDs', dataKey: 'ExternalIdentifiers' },
              { displayName: 'Date of Birth', dataKey: 'DateofBirth' },
              { displayName: 'Linked User(s)', dataKey: 'LinkedUsers' }
            ]

          }
        ];

        // only display recipient types the user has permissions for
        scope.toRecipientTypes = [];
        if (scope.allToRecipientTypes) {
          for (var i = 0; i < scope.allToRecipientTypes.length; i++) {
            if (userPermissionsSvc.userHasPermission(scope.allToRecipientTypes[i].permission)) {
              scope.toRecipientTypes.push(scope.allToRecipientTypes[i]);
            }
          }
        }

        // react on recipient type change, for changing search fields
        scope.showSearchFields = function (recipientType) {
          scope.searchFields = recipientType.searchFields;
        // searches on drop down change
        // scope.search({}, scope.recipientType);
        };
        // search button click
        scope.search = function (searchFieldsData, recipientType) {
          scope.sortingColumn = undefined;
          scope.setNumberOfPages = scope.pagingOption.pageOption[0];
          scope.pagingOption.currentPage = 1;
          scope.callSearchApi(searchFieldsData, recipientType);
        };
        // api call for search
        scope.callSearchApi = function (searchFieldsData, recipientType) {
          scope.searchFieldsData = searchFieldsData;
          scope.recipientType = recipientType;
          scope.getPaginatedData();
        };
        // closes popup of recipient search
        scope.closeDialog = function () {
          scope.recipientType = scope.searchHeader = scope.searchResult = scope.totalsearchResult = scope.searchFields = scope.sortingColumn = undefined;
          angular.element('.recipientSearch').hide();
        };
        // takes user input from searched result
        scope.selectRecipient = function (recipient) {
          if (scope.recipientOptions.length === 2) {
            scope.compose.recipient = recipient;
            scope.composeForm.$dirty = true;
            scope.compose.toIsAStaffUser = scope.recipientType === scope.recipientOptions[1];
            if (!scope.compose.toIsAStaffUser) {
              scope.compose.rePatient = undefined;
              scope.showRePatient = true;
            }
            scope.showReceipent = false;
          } else {
            scope.compose.rePatient = recipient;
            scope.showRePatient = false;
          }
          scope.closeDialog();
        };
        // search staff-users by default
        scope.initSearch = function (recipientType, calledFrom) {
          scope.searchFieldsData = {};
          scope.searchFields = {};
          scope.pagingOption.currentPage = 1;
          if (calledFrom) { scope.recipientOptions = scope[calledFrom]; }
          if (recipientType) {
            scope.recipientType = recipientType;
          } else {
            scope.recipientType = scope.recipientOptions[0];
          }
          if (scope.recipientType) { scope.showSearchFields(scope.recipientType); }
        // initial search by default
        // scope.recipientType ? scope.search({}, scope.recipientType) : null;
        };
        // sort columns
        scope.sort = function (header, index) {
          if (header.dataKey === 'LinkedPatients' || header.dataKey === 'ExternalIdentifiers' || header.dataKey === 'LinkedUsers') { return; }
          header.sortType = header.sortType === 'asc' ? 'desc' : 'asc';
          scope.sortingColumn = header;
          scope.setNumberOfPages = scope.pagingOption.pageOption[0];
          scope.pagingOption.currentPage = 1;
          var dateFlag = header.dataKey === 'DateofBirth' ? 'd' : 's';
          scope.totalsearchResult = utilitySvc.sortArray(scope.totalsearchResult, header.dataKey, header.sortType, dateFlag);
          scope.getPaginatedData();
        };
        // remove all filters
        scope.cancelSearchFilter = function () {
          scope.initSearch(scope.recipientType);
        };
        // open datepicker
        scope.open = function ($event) {
          $event.preventDefault();
          $event.stopPropagation();
          scope.dateOptions.opened = true;
        };
        // date option for date picker
        scope.dateOptions = {
          formatYear: 'yy',
          startingDay: 1,
          opened: false
        };
      }
    };
  }]);

}(window.app));
