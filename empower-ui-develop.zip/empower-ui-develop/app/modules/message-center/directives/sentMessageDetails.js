(function (app) {
  'use strict';

  app.directive('sentMessageDetails', ['messagingService', 'dialogService', '$timeout', 'Msgctr.Broadcast', '$q', function (messageSvc, dialogService, timeout, broadcastSvc, q) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/message-center/templates/broadcast-sent-message-details-popup.html',
      link: function (scope, element, attrs, ngModel) {
        scope.isReadRecepients = false;

        scope.initSentMessages = function (messageId) {
          var promises = [], length0Importlist = [];
          var obj = {
            'id': messageId,
            'includeRecipients': true,
            'includeAttachments': true
          };
          broadcastSvc.getSentMessageById(obj).then(function (sentResponse) {
            sentResponse.importListDetails = [];
            sentResponse.targetListDetails = [];
            sentResponse.recipients = [];
            _.forEach(sentResponse.ImportIds, function (Id) {
              var promise = broadcastSvc.getImportProcessed(Id, 1).then(function (res) {
                if (res.length > 0) {
                  sentResponse.importListDetails.push({ listName: res[0].Name, listlength: res.length });
                } else {
                  length0Importlist.push(Id);
                }
              });
              promises.push(promise);
            });
            _.forEach(sentResponse.TargetIds, function (Id) {
              var promise = broadcastSvc.getTargetGroupProcessed(Id).then(function (targetGroup) {
                if (targetGroup) {
                  sentResponse.targetListDetails.push({ listName: targetGroup.groupName, listlength: targetGroup.count });
                } else {
                  length0Importlist.push(Id);
                }
              });
              promises.push(promise);
            });
            q.all(promises).then(function (res) {
              broadcastSvc.getImportList({ sortField: '', sortAscending: false, pageSize: null, pageNumber: null }).then(function (res) {
                _.forEach(res, function (obj) {
                  if (_.contains(length0Importlist, obj.Id)) {
                    sentResponse.importListDetails.push({ listName: obj.Name, listlength: 0 });
                  }
                });
              });

            });
            broadcastSvc.getMessageRecipients(messageId).then(function (recipients) {
              sentResponse.recipients = recipients;
              sentResponse.readRecipients = _.filter(sentResponse.recipients, function (recipient) {
                return recipient.IsExcluded === false ? recipient.ReadDate !== null : false;
              });
              angular.element('.sentMessageDetails').modal({ backdrop: 'static', keyboard: false });
            });
            scope.sentMessageDetails = { message: sentResponse };
          });
        };

        scope.readRecepientsClick = function () {
          scope.recipientList = [];
          scope.sentMessageDetails.message.recipients ? scope.sentMessageDetails.message.recipients.length > 0 ? scope.isReadRecepients = true : null : null; // jshint ignore:line

        };

        // function called when back button is clicked
        scope.readRecepientsBack = function () {
          scope.isReadRecepients = false;
        };

        // function to download attachment
        scope.downloadAttachment = function (attachment) {
          var data = scope._base64ToArrayBuffer(attachment.BinaryContent);
          var type = attachment.ContentType;
          var blob = new Blob([data], { type: type });
          // Tell the browser to save as report.txt.
          saveAs(blob, attachment.FileName);
          alertService.add('success', 'Attacment download successfully', 5000);
        };

        scope._base64ToArrayBuffer = function (base64) {
          var binaryString = window.atob(base64);
          var len = binaryString.length;
          var bytes = new Uint8Array(len);
          for (var i = 0; i < len; i++) {
            var ascii = binaryString.charCodeAt(i);
            bytes[i] = ascii;
          }
          return bytes.buffer;
        };
        // close popup
        scope.closePopup = function (popupName) {
          scope.isReadRecepients = false;
          angular.element(popupName).modal('hide');
        };
      }
    };
  }]);

}(window.app));
