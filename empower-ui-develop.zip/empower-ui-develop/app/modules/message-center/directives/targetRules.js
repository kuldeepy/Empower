(function (app) {
  'use strict';

  app.directive('msgctrTargetRules', ['messagingService', 'Msgctr.Broadcast', '$location', 'dialogService', 'alertService', '$sce', '$timeout', 'medseekApi', '$q', 'session', 'GetDialogTemplate','$translate', function (messageSvc, broadcastSvc, location, dialogService, alertService, sce, timeout, api, q, session, GetDialogTemplate,translate) {
    return {
      restrict: 'E',
      link: function (scope, element, attrs, ngModel) {
        scope.controllerData = {
          targetRulesDialogName: 'targetRulesDialog',
          targetRulesEditDialogName: 'targetRulesEditDialog',
          targetDialogName: ''
        };

        var getTemplateContent = new GetDialogTemplate(dialogService);
        var getTargetDialogTemplates = new GetTargetContentDialogTemplates(dialogService);
        var apiMethodCall = new MedseekApiCall(scope, api, q);

        var initObject = { enableGroup: true, rules: [{}] };

        scope.ruleController = {
          confirmMessage: 'There are unsaved changes, are you sure you want to Cancel? Any unsaved changes will be lost.',
          targetGroupsData: [],
          locationsData: [],
          physiciansData: [],
          ruleParameterData: [],
          opened: false,
          dateOptions: { formatYear: 'yy', startingDay: 1, showWeeks: false },
          format: 'MM/dd/yyyy',
          datePickerCurrentIndex: -1,
          parentCurrentIndex: -1,
          statesData: [],
          gendersData: []
        };

        scope.ruleGroups = [angular.copy(initObject)];
        scope.clinical = {};
        scope.commanOperator = [
          { id: 1, name: 'equals' },
          { id: 2, name: 'is not equal to' },
          { id: 3, name: 'is greater than' },
          { id: 4, name: 'is less than' },
          { id: 5, name: 'is greater than/equal to' },
          { id: 6, name: 'is less than/equal to' }
        ];

        scope.comparisonOperator = [
          { id: 1, name: 'equals' },
          { id: 2, name: 'is not equal to' },
          { id: 3, name: 'contains' }
        ];

        scope.groupOperator = [
          { id: 1, name: 'belongs to' },
          { id: 2, name: 'not belongs to' }
        ];

        scope.valueData = [{ Name: 'Birmingham, AL' }, { id: 2, Name: 'Birmingham, MI' }, { id: 3, Name: 'Birmingham, MS' }];
        scope.operatorData = [{ name: 'AND' }, { id: 2, name: 'OR' }];
        scope.postalCodeData = [{ Name: '8989-123' }, { id: 2, Name: '8999-328' }, { id: 3, Name: '5683-328' }];

        scope.parameterData = [
          { name: 'Patient Age', type: 'Number', target: 'user.patients.age', operatorType: 'commanOperator', field: 'PatientAge' },
          { name: 'Patient City', type: 'String', target: 'user.patients.city', operatorType: 'comparisonOperator', field: 'PatientCity' },
          { name: 'Patient DOB', type: 'String', target: 'user.patients.dateOfBirth', operatorType: 'commanOperator', field: 'PatientDob' },
          { name: 'Patient Gender', type: 'String', target: 'user.patients.gender', operatorType: 'comparisonOperator', field: 'PatientGender' },
          { name: 'Patient Height', type: 'Number', target: 'user.patients.clinical.weights.height', operatorType: 'commanOperator', field: 'PatientHeight' },
          { name: 'Patient Locations', type: 'Number', target: 'user.patients.locations.id', operatorType: 'comparisonOperator', field: 'PatientLocations' },
          { name: 'Patient Physicians', type: 'Number', target: 'user.patients.physicians.id', operatorType: 'comparisonOperator', field: 'PatientPhysicians' },
          { name: 'Patient State', type: 'String', target: 'user.patients.state', operatorType: 'comparisonOperator', field: 'PatientStateProvince' },
          { name: 'Patient Postal Code', type: 'String', target: 'user.patients.postalCode', operatorType: 'commanOperator', field: 'PatientZipPostalCode' },
          { name: 'Patient Weight', type: 'Number', target: 'user.patients.clinical.weights.weight', operatorType: 'commanOperator', field: 'PatientWeight' },
          { name: 'Target Group', type: 'RuleGroup', target: 'rule.id', operatorType: 'groupOperator', field: 'TargetGroup' },
          { name: 'User Access Level', type: 'String', target: 'user.patients.relationshipClassification', operatorType: 'comparisonOperator', field: 'UserAccessLevel' },
          { name: 'User Age', type: 'Number', target: 'user.age', operatorType: 'commanOperator', field: 'UserAge' },
          { name: 'User City', type: 'String', target: 'user.addresses.city', operatorType: 'comparisonOperator', field: 'UserCity' },
          { name: 'User DOB', type: 'String', target: 'user.dateOfBirth', operatorType: 'commanOperator', field: 'UserDob' },
          { name: 'User Gender', type: 'String', target: 'user.gender', operatorType: 'comparisonOperator', field: 'UserGender' },
          { name: 'User State', type: 'String', target: 'user.addresses.state', operatorType: 'comparisonOperator', field: 'UserStateProvince' },
          { name: 'User Postal Code', type: 'String', target: 'user.addresses.postalCode', operatorType: 'commanOperator', field: 'UserZipPostalCode' },
          { name: 'User Role', type: 'Number', target: 'user.roles.id', operatorType: 'comparisonOperator', field: 'UserRole' }
        ];

        /* method for open target rules popup window */
        scope.targetRulesOpenPopupWindow = function () {
          scope.loadMethodForControl();
        };

        /* finally bind all data after all the api calls */
        scope.bindAllData = function () {
          scope.controllerData.targetDialogName = (scope.isNewTargetGroupFlag) ? scope.controllerData.targetRulesDialogName : scope.controllerData.targetRulesEditDialogName;

          if (scope.isNewTargetGroupFlag) {
            scope.targetRulesDialogContent = getTemplateContent.getTemplateDialog(scope.controllerData.targetRulesDialogName, 'Target Group Rules Definition', getTargetDialogTemplates.getTargetRulesContent(), '');
          } else {
            scope.targetRulesEditDialogContent = getTemplateContent.getTemplateDialog(scope.controllerData.targetRulesEditDialogName, 'Edit Target Group Rules Definition', getTargetDialogTemplates.getTargetRulesContent(), '');
          }

          timeout(function () {
            getTemplateContent.showDialog(scope.controllerData.targetDialogName);
            scope.bindTargetRulesData();
          }, 500);
        };

        /* method for load the api call and assign data */
        scope.loadMethodForControl = function () {
          messageSvc.getModuleSettings().then(function (response) {
            scope.ruleController.ruleParameterData = [];
            for (var field in response.SearchFieldsSettings) {
              if (response.SearchFieldsSettings[field]) {
                /* jshint ignore:start */
                _.each(scope.parameterData, function (parameter) {
                  if (parameter.field === field) {
                    scope.ruleController.ruleParameterData.push(parameter);
                  }
                });
              /* jshint ignore:end */
              }
            }

            var moduleInstanceId = session.get('moduleInstanceId');
            apiMethodCall.targetGroups(moduleInstanceId).then(function (response) {
              scope.ruleController.targetGroupsData = response;

              apiMethodCall.targetGroupsParameter().then(function (response) {
                angular.forEach(response, function (record) {
                  scope.ruleController[record.name + 'Data'] = record.data;
                });

                scope.bindAllData();
              });
            });
          });
        };

        /* method for bind the target rules data */
        scope.bindTargetRulesData = function () {
          timeout(function () {
            scope.ruleGroups = [angular.copy(initObject)];
            if (scope.newTargetGroup.TargetRules !== undefined) {
              scope.editConfigureRule(JSON.parse(scope.newTargetGroup.TargetRules));
            }
          }, 500);
        };

        /* method for bind the data for parameter and operator */
        scope.bindGroupData = function (ruleData, name) {
          var result = {};
          angular.forEach(ruleData, function (rule) {
            if (name === rule.target || name === rule.name) {
              result = rule;
              result.name = (result.name === undefined) ? rule.type : result.name;
            }
          });
          return result;
        };

        /* method for bind the data for value */
        scope.getValueData = function (valueData, value, collectionName) {
          var result = {};
          angular.forEach(valueData, function (data) {
            if (value === data[collectionName]) {
              result = data;
            }
          });
          return result;
        };

        /*  method for bind the data for physician value  */
        scope.getValuePhysiciansData = function (valueData, value, firstName, lastName) {
          var result = {};
          angular.forEach(valueData, function (data) {
            if (value === (data[lastName] + ' ' + data[firstName])) {
              result = data;
            }
          });
          return result;
        };

        /* method for get target collection */
        scope.getTargetCollection = function (groupRule) {
          var value;
          switch (groupRule.target) {
            case 'user.patients.city':
              value = scope.getValueData(scope.ruleController.cityData, groupRule.value, 'Name');
              break;
            case 'user.patients.locations.id':
              value = scope.getValueData(scope.ruleController.locationsData, groupRule.value, '_id');
              break;
            case 'user.patients.physicians.id':
              value = scope.getValuePhysiciansData(scope.ruleController.physiciansData, groupRule.value, 'FirstName', 'LastName');
              break;
            case 'user.patients.state':
              value = scope.getValueData(scope.ruleController.statesData, groupRule.value, 'Name');
              break;
            case 'user.addresses.city':
              value = scope.getValueData(scope.ruleController.cityData, groupRule.value, 'Name');
              break;
            case 'user.addresses.state':
              value = scope.getValueData(scope.ruleController.statesData, groupRule.value, 'Name');
              break;
            case 'rule.id':
              value = scope.getValueData(scope.ruleController.targetGroupsData, groupRule.value, 'RulesId');
              break;
            case 'user.patients.gender':
              value = scope.getValueData(scope.ruleController.gendersData, groupRule.value, 'Name');
              break;
            case 'user.gender':
              value = scope.getValueData(scope.ruleController.gendersData, groupRule.value, 'Name');
              break;
            case 'user.roles.id':
              value = scope.getValueData(scope.ruleController.rolesData, groupRule.value, 'Id');
              break;
            case 'user.patients.dateOfBirth':
            case 'user.dateOfBirth':
              value = scope.getFormat(groupRule.value);
              break;
            default:
              value = groupRule.value;
          }
          return value;
        };

        /* function to convert date to utc format */
        scope.getFormat = function (date) {
          return moment.utc(date).format();
        };

        /* method for get controller data */
        scope.getControllerData = function (groupData, groupRuleData) {
          groupData.parameter = scope.bindGroupData(scope.ruleController.ruleParameterData, groupRuleData.target);
          scope.comparisonData = scope.getComparisonOperator(groupData.parameter.operatorType);
          groupData.comparison = scope.bindGroupData(scope.comparisonData, groupRuleData.operator);
          if (groupRuleData.target === 'user.addresses.city' || groupRuleData.target === 'user.patients.city') {
            groupData.value = groupRuleData.value;
          } else {
            groupData.value = (groupRuleData.operator === 'contains') ? groupRuleData.value : scope.getTargetCollection(groupRuleData);
          }
          return groupData;
        };

        /* method for edit target group data */
        scope.editConfigureRule = function (data) {
          data = data.rules;
          scope.ruleGroups = [];
          var groupData = {};
          angular.forEach(data, function (groupRule) {
            var campian = { rules: [], enableGroup: groupRule.enabled };
            if (groupRule.operatorType === undefined) {
              angular.forEach(groupRule.rules, function (groupRuleData) {
                if (groupRuleData.operatorType === undefined) {
                  campian.rules.push(scope.getControllerData(groupData, groupRuleData));
                  groupData = {};
                } else {
                  groupData.operator = scope.bindGroupData(scope.operatorData, groupRuleData.operatorType.toUpperCase());
                }
              });
              scope.ruleGroups.push(campian);
            }
          });
        };

        /* method for get comparison operator */
        scope.getComparisonOperator = function (operatorType) {
          var result = [];
          switch (operatorType) {
            case 'commanOperator':
              result = scope.commanOperator;
              break;
            case 'comparisonOperator':
              result = scope.comparisonOperator;
              break;
            default:
              result = scope.groupOperator;
          }
          return result;
        };

        /* method for add campaign rules row */
        scope.addCampaignRulesRow = function (index, campaign, groupIndex, form) {
          if ((index + 1) < scope.ruleGroups[groupIndex].rules.length || scope.validateGroupFields(campaign)) {
            return;
          }

          form.$dirty = true;
          campaign.push({ operator: scope.operatorData[0]});

        };

        /* method for validate group fields */
        scope.validateGroupFields = function (campaign) {
          var validateRule = false, count = 0;
          angular.forEach(campaign, function (data) {
            if (((!data.operator && count !== 0) || !data.parameter || !data.comparison || !data.value) && data.rules === undefined) {
              validateRule = true;
            }

            count++;
          });
          return validateRule;
        };

        /* method for remove campaign rules row */
        scope.removeCampaignRulesRow = function (index, campaign, form) {
          campaign.splice(index, 1);

          if (campaign.length !== 0) {
            delete campaign[0].operator;
          }

          if (campaign.length === 0) {
            campaign.push({});
          }

          form.$dirty = true;
        };

        /* method for add campaign rules group row */
        scope.addRuleGroups = function (index, form) {
          if (scope.validateGroupFields(scope.ruleGroups[index].rules)) {
            return;
          }

          scope.ruleGroups.push(angular.copy(initObject));
          form.$dirty = true;
        };

        /* method for cancel popup click */
        scope.close = function () {
          scope.ruleGroups = [];
          scope.ruleGroups.push(angular.copy(initObject));
          dialogService.close();
          return false;
        };

        /* method for validate rule groups */
        scope.validateRuleGroups = function () {
          var result = false;
          for (var ruleIndex = 0; ruleIndex < scope.ruleGroups.length; ruleIndex++) {
            if (scope.validateGroupFields(scope.ruleGroups[ruleIndex].rules)) {
              result = true;
            }
          }
          return result;
        };

        /* method for cancel configure rules */
        scope.cancelConfigRules = function (form) {
          if (form.$dirty) {
            scope.openConfirmDialog('Cancel Changes?');
            return;
          }
          scope.closeDialog(scope.controllerData.targetDialogName);
        };

        /* method for yes confirm click */
        scope.yesConfirmClick = function (dialog) {
          dialogService.hide(dialog);
          scope.resetConfigureRules();
        };

        /* method for reset configure rules */
        scope.resetConfigureRules = function () {
          scope.ruleGroups = [];
          scope.ruleGroups.push(angular.copy(initObject));
          dialogService.hide(scope.controllerData.targetDialogName);
          scope.configureRuleBaseForm.$setPristine();
        };

        /* method for bind the parameter value */
        scope.bindParameterValue = function (rule) {
          var value;
          switch (rule.parameter.name) {
            case 'Patient City':
            case 'User City':
              value = (angular.isObject(rule.value)) ? rule.value.Name : rule.value;
              break;
            case 'Patient Locations':
              value = (angular.isObject(rule.value)) ? rule.value._id : rule.value;
              break;
            case 'User Role':
              value = (angular.isObject(rule.value)) ? rule.value.Id : rule.value;
              break;
            case 'Patient DOB':
            case 'User DOB':
              value = scope.convertDateToUtcFormat(rule.value);
              break;
            case 'Patient Physicians':
              value = (angular.isObject(rule.value)) ? (rule.value.FirstName + ' ' + rule.value.LastName) : rule.value;
              break;
            case 'Target Group':
              value = (angular.isObject(rule.value)) ? rule.value.RulesId : rule.value;
              break;
            default:
              value = (angular.isObject(rule.value)) ? rule.value.Name : rule.value;
              break;
          }
          return value;
        };

        /* method for construct json data for save*/
        scope.constructGroupJson = function () {
          scope.groupRuleData = [];
          angular.forEach(scope.ruleGroups, function (ruleGroup) {
            var ruleData = [];
            angular.forEach(ruleGroup.rules, function (rule) {
              var value = scope.bindParameterValue(rule);
              var data = { operator: rule.comparison.name, value: value, type: rule.parameter.type, target: rule.parameter.target };
              if (rule.operator !== undefined) {
                ruleData.push({ operatorType: rule.operator.name });
              }

              ruleData.push(data);
            });
            var groupRuleJson = { enabled: ((ruleGroup.enableGroup) ? ruleGroup.enableGroup : false), rules: ruleData };
            if (scope.groupRuleData.length !== 0) {
              scope.groupRuleData.push({ operatorType: 'OR' });
            }
            scope.groupRuleData.push(groupRuleJson);
          });
          return scope.groupRuleData;
        };

        /* method for save configure rule */
        scope.saveConfigRules = function () {
          for (var ruleIndex = 0; ruleIndex < scope.ruleGroups.length; ruleIndex++) {
            if (scope.validateGroupFields(scope.ruleGroups[ruleIndex].rules)) {
              return;
            }
          }

          var groupJson = scope.constructGroupJson();
          var rulesObject = { name: 'name', description: 'description', enabled: true, rules: groupJson };
          scope.newTargetGroup.TargetRules = JSON.stringify(rulesObject);
          scope.resetConfigureRules();
          scope.targetForm.$dirty = true;
        };

        /* method for reset filter group data */
        scope.resetFilterGroupData = function (rule) {
          if (rule.comparison !== undefined) {
            rule.comparison = undefined;
          }

          if (rule.value !== undefined) {
            rule.value = undefined;
          }
        };

        /* method for open confirm dialog */
        scope.openConfirmDialog = function (headerMessage) {
          scope.confirmDialogContent = getTemplateContent.getTemplateDialog('confirmDialog', headerMessage, getTargetDialogTemplates.getTargetRulesConfirmDialogContent(), getTargetDialogTemplates.getTargetRulesConfirmDialogFooter('confirmDialog'));
          timeout(function () {
            getTemplateContent.showDialog('confirmDialog');
          }, 100);

        };

        /* method for cancel confirm click */
        scope.cancelConfirmClick = function (className) {
          dialogService.hide(className);
        };

        /* method for close dialog */
        scope.closeDialog = function (className) {
          if (scope.configureRuleBaseForm.$dirty && className !== 'confirmDialog') {
              scope.openConfirmDialog(translate.instant('CONFIRM_CANCEL_DIALOG_NAME'));
            return;
          }
          dialogService.hide(className);
        };

        /* method for validate numaric data */
        scope.validateNumeric = function (rule) {
          rule.value = (rule.parameter.type === 'Number') ? rule.value.replace(/[^\d\s]+/gi, '') : rule.value;
        };

        /* method for convert date to utc format */
        scope.convertDateToUtcFormat = function (dateValue) {
          var date = new Date(dateValue);
          return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
        };

        /* method for changed value filed */
        scope.selectedDateValue = function () {
          scope.ruleController.datePickerCurrentIndex = -1;
          scope.ruleController.opened = false;
          scope.ruleController.parentCurrentIndex = -1;
        };

        /* method for open date picker control */
        scope.open = function (event, index, parent) {
          event.preventDefault();
          event.stopPropagation();
          scope.ruleController.datePickerCurrentIndex = index;
          scope.ruleController.opened = true;
          scope.ruleController.parentCurrentIndex = parent.$parent.$parent.$parent.$parent.$index;
        };

        /* method for remove rule group */
        scope.removeRuleGroup = function (index) {
          scope.ruleGroups.splice(index, 1);
          scope.configureRuleBaseForm.$dirty = true;
        };

      }
    };
  }]);

}(window.app));
