(function (app) {
  'use strict';

  app.controller('MessageCenterDefaultCtrl', ['$scope', '$location', function (scope, location) {
    // redirect to inbox
    location.replace().path(app.currentRoute + '/mailbox/inbox');
  }]);

}(window.app));
