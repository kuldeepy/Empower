(function (app) {
  'use strict';

  app.controller('broadcastLandingCtrl', ['$scope', '$location', 'session', 'Msgctr.Broadcast', 'alertService', '$http', 'dialogService', '$timeout', 'messagingService', '$upload', 'Msgctr.Utility', '$sce', '$q', 'GetDialogTemplate', '$cacheFactory', '$modal', '$dialogFactory','$translate',
    function (scope, location, session, broadcastSvc, alertService, http, dialogService, timeout, messageSvc, $upload, utilitySvc, sce, q, GetDialogTemplate, cacheFactory, $modal, $dialogFactory,translate) {
      scope.editorOptions = {
        height: 200
      };
      scope.newTemplate = {};
      scope.newImportList = {};
      scope.newTargetGroup = {};
      scope.templateControl = {};
      scope.draftControl = {};
      scope.importListControl = {};
      scope.importSummary = {};
      scope.targetGroupSummary = {};
      scope.tabs = [];
      scope.importDetailSortType = {};
      scope.targetGroupSortType = {};
      scope.targetGroupDetailSortType = {};
      scope.broadcastRecipientsdetail = {};
      scope.readMethod = 'readAsDataURL';
      scope.checkedListItems = {};
      scope.checkedTemplateItems = {};
      scope.checkedDraftItems = {};
      scope.templateId = '';
      scope.template = {};
      scope.template.Attachments = [];
      scope.checkedTargetGroupItems = {};

      var $httpDefaultCache = cacheFactory.get('$http');
      scope.gridOptions = {
        data: 'recipientList',
        multiSelect: false,
        showFooter: true,
        enableSorting: true,
        totalServerItems: 'totalServerItems',
        columnDefs: 'columnsSelected'
      };
      // react on tab change
      scope.tabChangeEvent = function (activeTab) {
        scope.url = activeTab.url ? app.root + activeTab.url : undefined;
        scope.popupUrl = activeTab.popupUrl ? app.root + activeTab.popupUrl : undefined;
      };

      scope.pagingOption = {
        pageSize: 10,
        totalItems: 10000,
        currentPage: 1,
        pageOption: [10]
      };

      scope.sentMessagesPagingOption = angular.copy(scope.pagingOption);
      scope.draftMessagesPagingOption = angular.copy(scope.pagingOption);
      scope.templateMessagesPagingOption = angular.copy(scope.pagingOption);
      scope.importedListsPagingOption = angular.copy(scope.pagingOption);
      scope.targetGroupResultsPagingOption = angular.copy(scope.pagingOption);
      scope.matchingRecipientsPagingOption = angular.copy(scope.pagingOption);
      scope.recipientsNotFoundPagingOption = angular.copy(scope.pagingOption);
      scope.invalidRecodsPagingOption = angular.copy(scope.pagingOption);
      scope.targetGroupsPagingOption = angular.copy(scope.pagingOption);

      scope.setNumberOfPages = scope.pagingOption.pageOption[0];

      /* method for load initialize */
      scope.initialize = function () {
        broadcastSvc.getModules().then(function (response) {
          angular.forEach(response, function (data) {
            if (data.ModuleId === 'MessageCenter') {
              session.set('moduleInstanceId', data.Id);
            }
          });
        });
      };

      /* validation for pagination */
      scope.pagingValidation = function (data, newVal, oldVal) {
        alertService.clear();
        var totalItems = data.totalItems;
        var pageSize = data.pageSize;
        var total = (Math.floor(totalItems / pageSize) >= totalItems / pageSize) ? Math.floor(totalItems / pageSize) : Math.floor(totalItems / pageSize) + 1;
        if (oldVal !== newVal && newVal !== '' && parseInt(newVal) > 0 && total >= newVal) {
          return true;
        } else if (isNaN(newVal) || parseInt(newVal) >= total || parseInt(newVal) <= 0 || isNaN(parseInt(newVal))) {
          scope.errorMessage = 'Please enter the valid page number';
          alertService.clear();
          alertService.add('danger', scope.errorMessage, 0, '', 'alert_page-top');
          return false;
        }
        return false;
      };

      // paging functions
      scope.$watch('importedListsPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.pagingValidation(scope.importedListsPagingOption, newVal, oldVal)) {
          scope.importListControl.checkAll = false;
          scope.selectAllMessage(scope.importList, scope.checkedListItems, false, 'Id');
          scope.getPaginatedData('paginatedImportList', 'importList', 'importedListsPagingOption');
        }
      });

      // paging functions
      scope.$watch('draftMessagesPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.pagingValidation(scope.draftMessagesPagingOption, newVal, oldVal)) {
          scope.getDraftMessages();
        }
      });
      // paging functions
      scope.$watch('sentMessagesPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.pagingValidation(scope.sentMessagesPagingOption, newVal, oldVal)) {
          scope.getSentMessages();
        }
      });

      // paging functions
      scope.$watch('templateMessagesPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.pagingValidation(scope.templateMessagesPagingOption, newVal, oldVal)) {
          scope.templateControl.checkAll = false;
          scope.selectAllMessage(scope.templates, scope.checkedTemplateItems, false, 'UniqueId');
          scope.getTemplates();
        }
      });

      scope.sortColumn = function (columnName) {
        scope.isSortedType = (scope.isSortedType === 'asc') ? 'desc' : 'asc';
        scope.sortDirection = (scope.isSortedType === 'asc');
        scope.currentColumn = columnName;
        scope.templateMessagesPagingOption.currentPage === 1 ? scope.getTemplates() : scope.templateMessagesPagingOption.currentPage = 1; // jshint ignore:line
      };

      // paging functions
      scope.$watch('targetGroupsPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.pagingValidation(scope.targetGroupsPagingOption, newVal, oldVal)) {
          scope.newTargetGroup.checkAll = false;
          scope.selectAllMessage(scope.targetGroups, scope.checkedTargetGroupItems, false, 'Id');
          scope.getTargetGroups(scope.targetGroupSortType.field, scope.targetGroupSortType.order);
        }
      });

      // paging functions for import list matching records details
      scope.$watch('matchingRecipientsPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.matchingRecipientsPagingOption.totalItems > 0) {
          if (scope.pagingValidation(scope.matchingRecipientsPagingOption, newVal, oldVal)) {
            scope.getPaginatedData('paginatedImportMatched', 'importMatched', 'matchingRecipientsPagingOption');
          }
        } else {
          scope.getPaginatedData('paginatedImportMatched', 'importMatched', 'matchingRecipientsPagingOption');
        }
      });

      // paging functions for target group results
      scope.$watch('targetGroupResultsPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.targetGroupResultsPagingOption.totalItems > 0) {
          if (scope.pagingValidation(scope.targetGroupResultsPagingOption, newVal, oldVal)) {
            scope.getPaginatedData('paginatedTargetGroupResults', 'targetGroupResults', 'targetGroupResultsPagingOption');
          }
        } else {
          scope.getPaginatedData('paginatedTargetGroupResults', 'targetGroupResults', 'targetGroupResultsPagingOption');
        }
      });

      // paging functions for import list records not found details
      scope.$watch('recipientsNotFoundPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.recipientsNotFoundPagingOption.totalItems > 0) {
          if (scope.pagingValidation(scope.recipientsNotFoundPagingOption, newVal, oldVal)) {
            scope.getPaginatedData('paginatedImportRecipientsNotFound', 'importRecipientsNotFound', 'recipientsNotFoundPagingOption');
          }
        } else {
          scope.getPaginatedData('paginatedImportRecipientsNotFound', 'importRecipientsNotFound', 'recipientsNotFoundPagingOption');
        }
      });

      // paging functions for import list invalid records details
      scope.$watch('invalidRecodsPagingOption.currentPage', function (newVal, oldVal) {
        if (scope.invalidRecodsPagingOption.totalItems > 0) {
          if (scope.pagingValidation(scope.invalidRecodsPagingOption, newVal, oldVal)) {
            scope.getPaginatedData('paginatedImportInvalidRecords', 'importInvalidRecords', 'invalidRecodsPagingOption');
          }
        } else {
          scope.getPaginatedData('paginatedImportInvalidRecords', 'importInvalidRecords', 'invalidRecodsPagingOption');
        }
      });

      // provide client side paginated data
      scope.getPaginatedData = function (paginationModel, model, pagingOption) {
        scope[paginationModel] = scope[model].slice((scope[pagingOption].currentPage - 1) * scope[pagingOption].pageSize, scope[pagingOption].currentPage * scope[pagingOption].pageSize);
      };

      // sort columns
      scope.sortImportDetails = function (column, paginationModel, model, paginationOption, sortingDirection) {
        var temp = scope.importDetailSortType[column];
        scope.importDetailSortType = {};
        scope.importDetailSortType[column] = temp;
        scope.importDetailSortType[column] = !sortingDirection ? scope.importDetailSortType[column] === 'asc' ? 'desc' : 'asc' : sortingDirection;
        var sortBy = column === 'RecordNumber' ? 'n' : column === 'EndDate' ? 'd' : 's';
        scope[model] = utilitySvc.sortArray(scope[model], column, scope.importDetailSortType[column], sortBy);
        scope[paginationOption].currentPage == 1 ? scope.getPaginatedData(paginationModel, model, paginationOption) : scope[paginationOption].currentPage = 1; // jshint ignore:line
      };

      scope.sortTargetGroupDetails = function (column, paginationModel, model, paginationOption, sortingDirection) {
        var temp = scope.targetGroupDetailSortType[column];
        scope.targetGroupDetailSortType = {};
        scope.targetGroupDetailSortType[column] = temp;
        scope.targetGroupDetailSortType[column] = !sortingDirection ? scope.targetGroupDetailSortType[column] === 'asc' ? 'desc' : 'asc' : sortingDirection;
        var sortBy = column === 'RecordNumber' ? 'n' : column === 'EndDate' ? 'd' : 's';
        scope[model] = utilitySvc.sortArray(scope[model], column, scope.targetGroupDetailSortType[column], sortBy);
        scope[paginationOption].currentPage == 1 ? scope.getPaginatedData(paginationModel, model, paginationOption) : scope[paginationOption].currentPage = 1; // jshint ignore:line
      };

      /* method for sort target groups */
      scope.sortTargetGroups = function (column, direction) {
        var sortDirection = (direction === 'ascending') ? 'descending' : 'ascending';
        scope.targetGroupSortType = { field: column, order: sortDirection };
        scope.targetGroupSortType[column] = sortDirection;
        scope.getTargetGroups(scope.targetGroupSortType.field, scope.targetGroupSortType.order);
      };

      // open import summary popup
      scope.openImportSummaryPopup = function (importList) {
        scope.importResponse = {};
        angular.forEach([1, 4, 2], function (val, key) {
          broadcastSvc.getImportProcessed(importList.Id, val).then(function (res) {
            scope.importResponse[val] = res;
            if (Object.keys(scope.importResponse).length === 3) {
              scope.getSummaryMapped(importList);
              scope.importMatched = scope.importResponse['1'];
              scope.matchingRecipientsPagingOption.totalItems = scope.importMatched.length;
              scope.matchingRecipientsPagingOption.currentPage === 1 ? scope.getPaginatedData('paginatedImportMatched', 'importMatched', 'matchingRecipientsPagingOption') : scope.matchingRecipientsPagingOption.currentPage = 1; // jshint ignore:line

              scope.importRecipientsNotFound = scope.importResponse['2'];
              scope.recipientsNotFoundPagingOption.totalItems = scope.importRecipientsNotFound.length;
              scope.recipientsNotFoundPagingOption.currentPage === 1 ? scope.getPaginatedData('paginatedImportRecipientsNotFound', 'importRecipientsNotFound', 'recipientsNotFoundPagingOption') : scope.recipientsNotFoundPagingOption.currentPage = 1; // jshint ignore:line

              scope.importInvalidRecords = scope.importResponse['4'];
              scope.invalidRecodsPagingOption.totalItems = scope.importInvalidRecords.length;
              scope.invalidRecodsPagingOption.currentPage === 1 ? scope.getPaginatedData('paginatedImportInvalidRecords', 'importInvalidRecords', 'invalidRecodsPagingOption') : scope.invalidRecodsPagingOption.currentPage = 1; // jshint ignore:line

              scope.tabs[0].active = true;
              angular.element('.importSummary').show();
            }
          });
        });
      };

      scope.openTargetGroupSummaryPopup = function (targetGroup) {
        scope.targetGroupResponse = {};
        scope['paginatedTargetGroupResults'] = {};
        broadcastSvc.getTargetGroupResults(targetGroup.Id).then(function (res) {
          scope.targetGroupResults = res;
          scope.getGroupSummaryMapped(targetGroup, scope.targetGroupResults.length);
          scope.targetGroupResponse[targetGroup.Id] = res;
          scope.targetGroupResultsPagingOption.totalItems = scope.targetGroupResults.length;
          scope.targetGroupResultsPagingOption.currentPage === 1 ? scope.getPaginatedData('paginatedTargetGroupResults', 'targetGroupResults', 'targetGroupResultsPagingOption') : scope.targetGroupResultsPagingOption.currentPage = 1; // jshint ignore:line

          scope.tabs[0].active = true;
          angular.element('.targetGroupSummary').show();
        });
      };

      scope.getFormattedStatus = function (status) {
        var formattedStatus;
        switch (status) {
          case 'NotStarted':
            formattedStatus = 'Pending';
            break;
          case 'Running':
            formattedStatus = 'Processing';
            break;
          case 'NotProcessed':
            formattedStatus = 'Not Processed';
            break;
        }
        return formattedStatus;
      };

      // sort broadcast sent details
      scope.sortBroadcastRecipients = function (column, sortIconDirection) {
        var temp = scope.broadcastRecipientsdetail[sortIconDirection];
        scope.broadcastRecipientsdetail = {};
        scope.broadcastRecipientsdetail[sortIconDirection] = temp;
        scope.broadcastRecipientsdetail[sortIconDirection] = scope.broadcastRecipientsdetail[sortIconDirection] === 'asc' ? 'desc' : 'asc';
        scope.sentMessageDetails.message.recipients = utilitySvc.sortArray(scope.sentMessageDetails.message.recipients, column, scope.broadcastRecipientsdetail[sortIconDirection], 's');
      };
      // get json
      http.get(app.root + 'modules/message-center/data.json').success(function (json) {
        scope.jsonData = json;
        // apply permission keys for the tabs
        angular.forEach(json.broadcastMessaging.importlistTabs, function (tab) {
          tab.key = [];
          switch (tab.title) {
            case 'Sent Messages':
              tab.key.push('broadcast-messaging.messages.view');
              break;
            case 'Draft Messages':
              tab.key.push('broadcast-messaging.messages.view');
              break;
            case 'Templates':
              tab.key.push('broadcast-messaging.templates.view');
              break;
            case 'Target Groups':
              tab.key.push('broadcast-messaging.target-groups.view');
              break;
            case 'Imported Lists':
              tab.key.push('broadcast-messaging.imports.view');
              break;
            default:
              break;
          }

        });
        // tabs for broadcast messaging landing page
        scope.tabs = json.broadcastMessaging.importlistTabs;
        if (location.$$search.tab_index) {
          scope.tabChangeEvent(scope.tabs[location.$$search.tab_index]);
        } else {
          // default view
          scope.tabChangeEvent(scope.tabs[0]);
        }

        scope.checkTabExist();
      });
      // tab content show hide depending on permissions
      scope.checkTabExist = function () {
        var keys = [];
        keys.push('broadcast-messaging.messages.view');
        keys.push('broadcast-messaging.messages.view');
        keys.push('broadcast-messaging.templates.view');
        keys.push('broadcast-messaging.target-groups.view');
        keys.push('broadcast-messaging.imports.view');
        scope.keySetTotal = 0;
        angular.forEach(JSON.parse(session.get('currentPermissionSet')), function (permission) {
          angular.forEach(keys, function (key) {
            if (key === permission) {
              scope.keySetTotal++;
            }
          });
        });
      };
      // react on load of every partial view
      scope.partialViewInit = function (menuUrl, apiFunctionName) {
        scope.menuUrl = menuUrl;
        // calls api for respective page
        apiFunctionName ? scope[apiFunctionName]() : null; // jshint ignore:line
      };

      // api calls for getting import list
      scope.getImportList = function () {
        broadcastSvc.getImportList({}).then(function (res) {
          scope.importedListsPagingOption.totalItems = res.length;
        });
        broadcastSvc.getImportList({ sortField: 'EndDate', sortAscending: false, pageSize: scope.importedListsPagingOption.pageSize, pageNumber: scope.importedListsPagingOption.currentPage }).then(function (res) {
          scope.importListControl.checkAll = false;
          scope.checkedListItems = {};
          scope.importList = res;
          scope.sortImportDetails('EndDate', 'paginatedImportList', 'importList', 'importedListsPagingOption', 'desc');
        // scope.importedListsPagingOption.currentPage == 1 ?
        // scope.getPaginatedData('paginatedImportList', 'importList', 'importedListsPagingOption')
        //    : scope.importedListsPagingOption.currentPage = 1;
        });
      };

      // open popup for new import list entry
      scope.openNewListpopUp = function () {
        scope.newImportList = {};
        scope.selectedFiles = undefined;
        broadcastSvc.getSourceIdentifiers().then(function (res) {
          scope.sources = res;
        });
        angular.element('.newImportList').show();
      };

      // open popup for new template
      scope.openNewTemplatepopUp = function (templateId) {
        alertService.clear();
        scope.templateId = templateId;
        scope.newTemplate = {};
        scope.template.Attachments = [];
        broadcastSvc.getCategories().then(function (res) {
          scope.categories = res;
          scope.editFlag = false;
          if (templateId !== undefined) {
            scope.editFlag = true;
            broadcastSvc.getTemplateById(parseInt(templateId)).then(function (res) {
              if (res.Attachments.length > 0) {
                angular.forEach(res.Attachments, function (item) {
                  scope.template.Attachments.push({ 'Name': item.FileName, 'Id': item.UniqueId });
                });
              }
              scope.newTemplate = {
                'name': res.Name,
                'description': res.Description,
                'category': { UniqueId: res.CategoryId, Name: res.CategoryName },
                'subject': res.Subject,
                'message': res.Body
              };
            });
          }
          angular.element('.newTemplate').show();
        });
      };

      // open popup for new target group
      scope.openNewTargetGroupPopUp = function () {
        scope.isNewTargetGroupFlag = true;
        scope.newTargetGroup = {};
        angular.element('.newTargetGroup').show();
      };

      // map data to summary
      scope.getSummaryMapped = function (importList) {
        scope.importSummary.fileName = scope.importResponse[2].length ? scope.importResponse[2][0].Name :
          scope.importResponse[4].length ? scope.importResponse[4][0].Name : 'No Name';
        scope.importSummary.startedProcessingTime = importList.StartDate;
        scope.importSummary.endProcessingTime = importList.EndDate;
        scope.importSummary.totalMatchingRecipients = scope.importResponse[1].length;
        scope.importSummary.totalRecipientsFound = scope.importResponse[2].length + scope.importResponse[1].length;
        scope.importSummary.totalRecipientsNotFound = scope.importResponse[4].length;
      };

      scope.getGroupSummaryMapped = function (targetGroup, count) {
        scope.targetGroupSummary.TargetGroupName = targetGroup.Name;
        scope.targetGroupSummary.ProcessedStartDate = targetGroup.ProcessedStartDate;
        scope.targetGroupSummary.ProcessedEndDate = targetGroup.ProcessedEndDate;
        scope.targetGroupSummary.TotalRecordsFound = count;
      };

      // close popup
      scope.closeDialog = function (popupName) {
        if (popupName === 'targetConfirmDialog') {
          dialogService.hide(popupName);
          return;
        }
        if (popupName === '.newTemplate' && scope.masterForm.$dirty) {
            var confirmDialog = $dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
          confirmDialog.result.then(function () {
            scope.masterForm.$setPristine();
            angular.element(popupName).hide();
          });
          return;
        }
        angular.element(popupName).hide();
      };

      // close popup
      scope.broadcastCloseDialog = function (popupName) {
        if (popupName === 'targetConfirmDialog') {
          dialogService.hide(popupName);
          return;
        }
        if ((popupName === '.newTemplate' || popupName === '.newImportList') && scope.masterForm.$dirty) {
            var confirmDialog = $dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
          confirmDialog.result.then(function () {
            scope.masterForm.$setPristine();
            angular.element(popupName).hide();
          });
          return;
        }
        scope.masterForm.$setPristine();
        angular.element(popupName).hide();
      };

      // close popup
      scope.cancelDialog = function (popupName) {
        scope.masterForm.$setPristine();
        angular.element(popupName).hide();
      };

      // triggers file browser click
      scope.fileUpload = function () {
        angular.element('.upload-file').click();
      };

      // reset tiny-mce height on leaving this module
      scope.$on('$locationChangeStart', function () {
        scope.editorOptions.height = 400;
      });

      // toggle checkboxes from select All checkbox
      scope.selectAll = function (checkListName, checkForItems, state) {
        angular.forEach(checkForItems, function (val, key) {
          checkListName[val.Id] = state;
        });
      };

      // save new import list
      scope.saveImportList = function (newImportList) {
        angular.element('.newImportList').hide();
        broadcastSvc.uploadImportList(newImportList).then(function (res) {
          scope.getImportList();
        });
      };

      // discard import list
      scope.discardImportList = function (checkedListItems) {
        scope.closeDialog('.discardImportList');
        broadcastSvc.deleteImportList(checkedListItems).then(function (res) {
          scope.getImportList();
        }, function () {
          scope.errorMessage = 'Unable to discard Imported List at this time. Please try again later or contact your system administrator.';
          alertService.add('danger', scope.errorMessage, 0, '', 'alert_page-top');
        });
      };

      // confirm import discard
      scope.confirmImportDicsard = function (checkedListItems) {
        broadcastSvc.getIds(checkedListItems).length > 0 ? angular.element('.discardImportList').show() : null; // jshint ignore:line
      };

      // reprocess import list
      scope.reprocessImportList = function (checkedListItems) {
        var promises = [];
        angular.forEach(checkedListItems, function (value, key) {
          if (value) {
            var promise = broadcastSvc.reprocessImportList(key).then(function (res) {
              scope.importListControl.checkAll = false;
              scope.selectAllMessage(scope.importList, scope.checkedListItems, false, 'Id');
            });
            promises.push(promise);
          }
        });
        q.all(promises).then(function () {
          timeout(function () {
            scope.getImportList();
          }, 3000);

        });
      };
      // open sent message details popup
      scope.openSentMessagePopup = function (messageId) {
        scope.initSentMessages(messageId);
      };

      // get sent messages
      scope.getSentMessages = function () {
        if (location.$$search.refuse_cache === 'sent') {
          $httpDefaultCache.remove(app.api.root + 'empower/broadcast-messaging/messages?sortField=DateSent&sortAscending=false&limit=&offset=');
          $httpDefaultCache.remove(app.api.root + 'empower/broadcast-messaging/messages?sortField=DateSent&sortAscending=false&limit=10&offset=1');
          location.$$search = {};
        }

        broadcastSvc.getSentMessages({ sortField: 'DateSent', sortAscending: false, pageSize: null, pageNumber: null }).then(function (res) {
          scope.sentMessagesPagingOption.totalItems = res.length;
        });
        broadcastSvc.getSentMessages({ sortField: 'DateSent', sortAscending: false, pageSize: scope.sentMessagesPagingOption.pageSize, pageNumber: scope.sentMessagesPagingOption.currentPage }).then(function (res) {
          scope.sentMessages = res;
        });
      };

      // get draft messages
      scope.getDraftMessages = function () {
        if (location.$$search.refuse_cache === 'draft') {
          $httpDefaultCache.remove(app.api.root + 'empower/broadcast-messaging/drafts?sortField=DateSent&sortAscending=false&limit=&offset=');
          $httpDefaultCache.remove(app.api.root + 'empower/broadcast-messaging/drafts?sortField=DateSent&sortAscending=false&limit=10&offset=1');
          location.$$search = {};
        }

        broadcastSvc.getDraftMessages({ sortField: 'DateSent', sortAscending: false, pageSize: null, pageNumber: null }).then(function (res) {
          scope.draftMessagesPagingOption.totalItems = res.length;
        });

        broadcastSvc.getDraftMessages({ sortField: 'DateSent', sortAscending: false, pageSize: scope.draftMessagesPagingOption.pageSize, pageNumber: scope.draftMessagesPagingOption.currentPage }).then(function (res) {
          scope.draftMessages = res;

          _.forEach(scope.draftMessages, function (draftMessage) {
            draftMessage.recipientGroups = [];
            var moduleInstanceId = session.get('moduleInstanceId');
            broadcastSvc.getTargetGroups({ moduleInstanceId: moduleInstanceId, sortField: 'Name', sortDirection: 'ascending' })
              .then(function (targetGroups) {
                scope.targetGroups = targetGroups;
                _.forEach(draftMessage.TargetIds, function (targetId) {
                  _.filter(scope.targetGroups, function (target) {
                    if (target.Id === targetId) {
                      draftMessage.recipientGroups.push(target.Name);
                    }
                  });
                });
              });

            _.forEach(draftMessage.ImportIds, function (importId) {
              _.forEach([1, 4, 2], function (val, key) {
                broadcastSvc.getImportProcessed(importId, val).then(function (res) {
                  if (res.length > 0) {
                    if (draftMessage.recipientGroups.indexOf(res[0].Name) < 0) {
                      draftMessage.recipientGroups.push(res[0].Name);
                    }
                  }
                });
              });
            });

          });

        });
      };

      /* get target groups */
      scope.getTargetGroups = function (sortFieldName, sortingOrder) {
        if (sortFieldName === undefined && sortingOrder === undefined) {
          sortFieldName = 'Name';
          sortingOrder = 'ascending';
          scope.targetGroupsPagingOption.currentPage = 1;
          scope.targetGroupSortType = { field: sortFieldName, order: sortingOrder };
        }

        var moduleInstanceId = session.get('moduleInstanceId');
        broadcastSvc.getTargetGroupsCount({ moduleInstanceId: moduleInstanceId }).then(function (res) {
          scope.targetGroupsPagingOption.totalItems = parseInt(res);
          broadcastSvc.getTargetGroups({ moduleInstanceId: moduleInstanceId, sortField: sortFieldName, sortDirection: sortingOrder, pageSize: scope.targetGroupsPagingOption.pageSize, currentPageNumber: scope.targetGroupsPagingOption.totalItems <= scope.targetGroupsPagingOption.pageSize ? 1 : scope.targetGroupsPagingOption.currentPage }).then(function (res) {
            scope.newTargetGroup.checkAll = false;
            scope.selectAllMessage(scope.targetGroups, scope.checkedTargetGroupItems, false, 'Id');
            scope.targetGroups = res;
          });
        });
      };

      /**/
      scope.openDraftMessage = function (draft) {
        location.url('/message-center/compose-broadcast?draftId=' + draft.UniqueId);
      };

      scope.confirmDeleteDraftMessage = function (messageIds) {
        var confirmModalInstance = $modal.open({
          templateUrl: 'confirmDeleteDraftMessageModal.html'
        });

        confirmModalInstance.result.then(function () {
          var deletionQ = [];

          // Modal $close() means its ok to delete
          _.forEach(broadcastSvc.getIds(messageIds), function (messageId) {
            deletionQ.push(broadcastSvc.deleteMessageById(messageId).then());
          });

          // wait till all deletions are succeeded
          q.all(deletionQ).then(function () {
            scope.checkedDraftItems = {};
            scope.draftMessages = broadcastSvc.refreshList(scope.draftMessages, broadcastSvc.getIds(messageIds), 'UniqueId');
          });

        }, function () {
          // Modal $dismiss() means the deletion has been canceled
        });
      };

      // save template
      scope.saveTemplate = function () {
        if (scope.newTemplate.name === undefined || scope.newTemplate.name === '') {
          scope.errorMessageSave = 'The following information was missing or invalid. Please make changes and re-submit: <br /> Name: Not Defined', 0, '', 'alert_mc_broadcastnewtemplete';
        } else {
          scope.newTemplate.Attachments = [];
          if (scope.template.Attachments.length > 0) {
            angular.forEach(scope.template.Attachments, function (item) {
              scope.newTemplate.Attachments.push({ 'uniqueId': +item.Id });
            });
          }
          if (scope.templateId === undefined || scope.templateId === '') {
            broadcastSvc.saveTemplate(scope.newTemplate).then(function (res) {
              if (res.Retval.dbResult === 'NameNotUnique') {
                scope.errorMessageSave = 'There is already a Template with the same name. Please enter a unique name for the new Template.';
                alertService.clear();
                alertService.add('danger', scope.errorMessageSave, 0, '', 'alert_mc_broadcastnewtemplete');
              } else {
                scope.cancelDialog('.newTemplate');
                scope.templateMessagesPagingOption.currentPage === 1 ? scope.getTemplates() : scope.templateMessagesPagingOption.currentPage = 1; // jshint ignore:line
              }
            });
          } else {
            scope.updateTemplate(scope.templateId);
          }
        }
      };

      // get templates
      scope.getTemplates = function () {
        if (location.$$search.refuse_cache === 'template') {
          $httpDefaultCache.remove(app.api.root + 'empower/broadcast-messaging/templates?sortField=DateSent&sortAscending=false&limit=10&offset=1');
          location.$$search = {};
        }

        var sortType = (scope.isSortedType === 'asc') ? true : false;
        broadcastSvc.getTemplates({
          sortField: scope.currentColumn || 'DateSent',
          sortAscending: sortType,
          pageSize: scope.templateMessagesPagingOption.pageSize,
          pageNumber: scope.templateMessagesPagingOption.currentPage
        }).then(function (res) {
          // exception case for checkall: when all data of a page gets deleted
          scope.templateControl.checkAll = false;
          scope.selectAllMessage(scope.templates, scope.checkedTemplateItems, false, 'UniqueId');
          scope.templates = res.Retval;
          scope.templateMessagesPagingOption.totalItems = res.templateCount;
        });

      };

      // confirm discard template
      scope.confirmDiscardTemplate = function () {
        messageSvc.getDynamicText('ConfirmDeletion').then(function (response) {
          scope.DiscardTemplateMessage = response;
        });
        if (broadcastSvc.getIds(scope.checkedTemplateItems).length > 0) {
          angular.element('.discardTemplate').show();
        }
      };

      // discard template
      scope.discardTemplate = function (checkedTemplateItems) {
        broadcastSvc.deleteTemplate(checkedTemplateItems).then(function (res) {
          scope.closeDialog('.discardTemplate');
          scope.getTemplates();
        });
      };

      // save edited template
      scope.updateTemplate = function (templateId) {
        broadcastSvc.updateTemplate(scope.newTemplate, templateId).then(function (res) {
          if (res === 'NameNotUnique') {
            scope.errorMessage = 'There is already a Template with the same name. Please enter a unique name for the new Template.';
          } else {
            scope.cancelDialog('.newTemplate');
            scope.getTemplates();
          }
        });
      };

      scope.processTargetGroup = function (checkedTargetGroupItems) {
        for (var item in checkedTargetGroupItems) {
          if (checkedTargetGroupItems[item]) {
            var targetGroup = _.find(scope.targetGroups, { 'Id': item });
            if (targetGroup && targetGroup.ProcessedStatus === 'NotProcessed') {
              /* jshint ignore:start */
              var empowerBody = {
                'targetId': targetGroup.Id,
                'rulesId': targetGroup.RulesId,
                'description': targetGroup.Description
              };
              broadcastSvc.processTargetGroup(empowerBody).then(function (response) {
                scope.getTargetGroups(scope.targetGroupSortType.field, scope.targetGroupSortType.order);
              });
            /* jshint ignore:end */
            }
            else if (targetGroup && (targetGroup.ProcessedStatus === 'Complete' || targetGroup.ProcessedStatus === 'Error')) {
              /* jshint ignore:start */
              broadcastSvc.reProcessTargetGroup(targetGroup.GroupId).then(function (response) {
                scope.getTargetGroups(scope.targetGroupSortType.field, scope.targetGroupSortType.order);
              });
            /* jshint ignore:end */
            }
          }
        }
      };

      /* method for confirm discard target group */
      scope.confirmDiscardTargetGroup = function () {
        if (broadcastSvc.getIds(scope.checkedTargetGroupItems).length > 0) {
          angular.element('.discardTargetGroup').show();
        }
      };

      /* method for discard target group */
      scope.discardTargetGroup = function (checkedTargetGroupItems) {
        for (var item in checkedTargetGroupItems) {
          if (checkedTargetGroupItems[item]) {
            /* jshint ignore:start */
            broadcastSvc.deleteTargetGroups(item).then(function (response) {
              scope.closeDialog('.discardTargetGroup');
              scope.getTargetGroups(scope.targetGroupSortType.field, scope.targetGroupSortType.order);
            });
          /* jshint ignore:end */
          }
        }
      };

      // get permission related to files, configured by admin
      messageSvc.getFileTypes().then(function (response) {
        scope.uploadFileRestrict = response;
      });

      messageSvc.getDynamicText('MessageCenterInvalidAttachmentFile').then(function (response) {
        scope.MessageCenterInvalidAttachmentFile = response;
      });

      /*function to upload attachments*/
      scope.onFileSelect = function ($files) {
        // $files: an array of files selected, each file has name, size, and type.
        for (var i = 0; i < $files.length; i++) {
          var file = $files[i];
          if (file.name) {
            var fileExtension = file.name.split('.');
            if (file.size > scope.uploadFileRestrict.MaxSize || scope.uploadFileRestrict.FileTypes.indexOf('.' + angular.lowercase(fileExtension[(fileExtension.length - 1)])) === -1) {
              var ext = '', count = 0;
              /* jshint ignore:start */
              scope.uploadFileRestrict.FileTypes.forEach(function (data) {
                count++;
                var lastExt = ((scope.uploadFileRestrict.FileTypes.length) === count) ? '.' : ',';
                ext = ext + ' ' + data + ' ' + lastExt;
              });
              /* jshint ignore:end */

              scope.errorMessage = scope.MessageCenterInvalidAttachmentFile || 'Your attachment cannot be added to the message because it is invalid. The file must be less than ' + scope.uploadFileRestrict.MaxSize + ' KBs and have an extension of ' + ext;
              scope.errorMessage = scope.errorMessage.replace(/\$\$FileSize\$\$/g, Math.floor(scope.uploadFileRestrict.MaxSize / 1024)).replace(/\$\$FileExtensions\$\$/g, ext);
              alertService.clear();
              alertService.add('danger', scope.errorMessage, 0, '', 'alert_mc_broadcastnewtemplete');

              return;
            }
          }
          var fileReader = new FileReader();
          fileReader.readAsArrayBuffer(file);
          /* jshint ignore:start */
          fileReader.onload = function (e) {
            var type = (file.type === '') ? 'application/octet-stream' : file.type;
            var obj = {
              'FileBase64': _arrayBufferToBase64(e.target.result),
              'Details': {
                'Name': file.name,
                'Type': type
              }
            };
            $upload.http({
              url: app.api.root + 'messages/uploadAttachment',
              // headers: {'Content-Type': file.type},
              data: obj
            }).then(function (response) {
              var res = { 'Name': file.name, 'Type': type, 'Id': response.data.results.AttachmentId };
              scope.template.Attachments.push(res);
            }, null, function (evt) {
              scope.progress[index] = parseInt(100.0 * evt.loaded / evt.total);
            });
          };
        /* jshint ignore:end */
        }
      };

      // function convert to base64

      function _arrayBufferToBase64 (buffer) {
        var binary = '';
        var bytes = new Uint8Array(buffer);
        var len = bytes.byteLength;
        for (var i = 0; i < len; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        return window.btoa(binary);
      }

      // function to remove attached file(s)
      scope.removeFile = function (file) {
        /*return the new array and remove the selected file*/
        scope.template.Attachments = _.remove(scope.template.Attachments, function (data) {
          return data.Id !== file.Id;
        });

      };
      /* function to read file  */
      scope.onReaded = function (e, file) {
        alertService.clear();
        if (file.type === 'application/vnd.ms-excel' && file.name.split('.')[1] === 'csv') {
          scope.selectedFiles = [];
          scope.selectedFiles.push({ 'ref': file, 'content': e.target.result });
          scope.newImportList.attachment = utilitySvc.getByteArrayFromBase64(scope.selectedFiles[0].content.split(',')[1]);
        } else {
          scope.errorMessage = 'The following information was missing or invalid. Please make changes and re-submit: <br> File: Please choose only .csv file to upload';
          alertService.clear();
          alertService.add('danger', scope.errorMessage, 0, '', 'alert_broadcast-template');
          return;
        }
      };

      /* function to remove selected file  */
      scope.removeSelectedFile = function (selected) {
        scope.selectedFiles = scope.selectedFiles.filter(function (removeFile) {
          return (selected.ref.name && (selected.ref.name === removeFile.ref.name)) ? false : true;
        });
        scope.newImportList.attachment = [];
      };

      // download import file
      scope.downloadImportFile = function () {
        var blob = new Blob([scope.jsonData.broadcastMessaging.sampleImportList], { type: 'text/csv;charset=utf-8;' });
        // Tell the browser to save as report.txt.
        saveAs(blob, 'Sample Import List.csv');
      };

      var getTemplateContent = new GetDialogTemplate(dialogService);
      var getTargetDialogTemplates = new GetTargetContentDialogTemplates(dialogService);

      /* method for cancel target content */
      scope.cancelTarget = function (form) {
        if (form.$dirty) {
          scope.targetForm = form;
          scope.ruleController = { confirmMessage: 'There are unsaved changes, are you sure you want to Cancel? Any unsaved changes will be lost.' };
          scope.targetConfirmDialogContent = getTemplateContent.getTemplateDialog('targetConfirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), getTargetDialogTemplates.getTargetRulesConfirmDialogContent(), getTargetDialogTemplates.getTargetRulesConfirmDialogFooter('targetConfirmDialog'));
          timeout(function () {
            getTemplateContent.showDialog('targetConfirmDialog');
          }, 100);
          return;
        }
        angular.element('.newTargetGroup').hide();
      };

      /* method for save target content */
      scope.saveTarget = function (form) {
        if (scope.newTargetGroup.Description === undefined) {
          scope.newTargetGroup.Description = '';
        }
        var rulesData = JSON.parse(scope.newTargetGroup.TargetRules);
        var data = { targetGroupEntity: { ModuleInstanceId: session.get('moduleInstanceId'), Name: scope.newTargetGroup.Name, Description: scope.newTargetGroup.Description, RulesText: '' } };

        if (scope.isNewTargetGroupFlag) {
          broadcastSvc.saveRules(rulesData).then(function (response) {
            data.targetGroupEntity.RulesId = response.results.ruleId.toString();
            scope.saveTargetGroup(form, data);
          });
        } else {
          broadcastSvc.updateRules(scope.newTargetGroup.RulesId, rulesData).then(function (response) {
            data.targetGroupEntity.RulesId = scope.newTargetGroup.RulesId;
            scope.updateTargetGroup(form, data);
          });
        }
      };

      /* method for save target group */
      scope.saveTargetGroup = function (form, data) {
        alertService.clear();
        broadcastSvc.saveTargetGroup(data).then(function (reponse) {
          if (reponse.results.Retval === 'NameNotUnique') {
            scope.errorMessage = 'There is already a Target Group with the same name. Please enter a unique name for the new Target Group.';
            return;
          }
          scope.resetTargetFormControls(form);
        });
      };

      /* method for update target group */
      scope.updateTargetGroup = function (form, data) {
        alertService.clear();
        broadcastSvc.updateTargetGroup(scope.newTargetGroup.Id, data).then(function (reponse) {
          if (reponse.results !== undefined && reponse.results.Retval === 'NameNotUnique') {
            scope.errorMessage = 'There is already a Target Group with the same name. Please enter a unique name for the existing Target Group.';
            return;
          }
          scope.resetTargetFormControls(form);
        });
      };

      /* method for cancel confirm click */
      scope.cancelConfirmClick = function (className) {
        dialogService.hide(className);
      };

      /* method for yes confirm click */
      scope.yesConfirmClick = function (className) {
        scope.resetTargetFormControls(scope.targetForm);
        dialogService.hide(className);
      };

      /* method for reset target form controls */
      scope.resetTargetFormControls = function (form) {
        form.$setPristine();
        angular.element('.newTargetGroup').hide();
        scope.getTargetGroups(scope.targetGroupSortType.field, scope.targetGroupSortType.order);
      };

      // select all
      scope.selectAllMessage = function (allData, checkboxObj, checkAllState, dataAttr) {
        _.forEach(allData, function (data) {
          checkboxObj[data[dataAttr]] = checkAllState;
          data.checked = checkAllState;
        });
      };

      /**/
      scope.selectCheckAll = function (allData, checkboxObj, moduleName, dataAttr) {
        var flag = true;
        _.forEach(allData, function (data) {
          if (checkboxObj[data[dataAttr]] === undefined || checkboxObj[data[dataAttr]] === false) {
            flag = false;
          }
          data.checked = checkboxObj[data[dataAttr]];
        });
        scope[moduleName].checkAll = flag;
      };

      /* method for edit rarget group popup */
      scope.editTargetGroupPopUp = function (target) {
        scope.isNewTargetGroupFlag = false;
        scope.newTargetGroup = angular.copy(target);
        angular.element('.newTargetGroup').show();
        scope.getTargetRulesById(target.RulesId);
      };

      /* method for get target rules by id */
      scope.getTargetRulesById = function (ruleId) {
        broadcastSvc.getRuleEngineById(ruleId).then(function (response) {
          scope.newTargetGroup.TargetRules = JSON.stringify(response.results[0]);
        });
      };

      // return html
      scope.toTrusted = function (htmlCode) {
        return sce.trustAsHtml(htmlCode);
      };

    }]);
}(window.app));
