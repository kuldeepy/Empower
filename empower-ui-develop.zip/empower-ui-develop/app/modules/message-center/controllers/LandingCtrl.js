(function (app) {
  'use strict';

  app.controller('MessageCenterLandingCtrl', ['$scope', '$window', 'session', '$location', 'messageCenterMailBoxService', 'messagingService', '$http', 'dialogService', 'alertService', '$timeout', 'Msgctr.Utility', '$translate',
    function (scope, window, session, location, mailboxSvc, messageSvc, http, dialogService, alertService, timeout, utility, $translate) {
      // initialize data
      scope.staticMenus = [];
      scope.currentMailbox = null;
      scope.currentMessage = null;
      scope.checkedMessages = {};
      scope.defaultMessage = {};
      scope.removeMessage = 'false';
      scope.box = 'archive';
      // scope.archiveCheckbox=true;
      scope.draftRole = 'draft';
      /*Default sortable type*/
      scope.isSortedType = 'desc';
      scope.currentColumn = 'DateSent';
      scope.folder = {};
      scope.headerUrl = app.root + 'modules/message-center/templates/landingHeader.html';
      scope.searchFlag = false;
      scope.mailboxViewState = messageSvc.getCurrentState(); // Create default currentState obj for mobile states view
      // get templates in scope variable for popup
      http.get(app.root + 'modules/message-center/templates/popup-templates.html').success(function (htmlData) {
        scope.template = htmlData;
      });

      scope.columns = {};

      scope.userId = angular.fromJson(session.get('userId'));
      scope.sentColumns = { from: $translate.instant('TO'), subject: $translate.instant('MSG_CTR_SUBJECT'), date: $translate.instant('SENT'), panelDate: $translate.instant('SENT'), sortColumn: 'RecipientDisplayNameList' };
      scope.drafColumns = { from: $translate.instant('TO'), subject: $translate.instant('MSG_CTR_SUBJECT'), date: $translate.instant('SAVED'), panelDate: $translate.instant('SAVED'), sortColumn: 'RecipientDisplayNameList' };
      scope.otherColumns = { from: $translate.instant('FROM'), subject: $translate.instant('MSG_CTR_SUBJECT'), date: $translate.instant('RECEIVED'), panelDate: $translate.instant('RECEIVED'), sortColumn: 'SentByDisplayName' };
      scope.searchColumn = { from: $translate.instant('SENDER'), subject: $translate.instant('MSG_CTR_SUBJECT'), folder: $translate.instant('FOLDER'), panelDate:$translate.instant('RECEIVED'), date: 'Received', sortColumn: 'SentByDisplayName' };

      if (scope.model.routeParams.mailbox === 'sent') {
        scope.columns = scope.sentColumns;
      }
      else if (scope.model.routeParams.mailbox === 'draft') {
        scope.columns = scope.drafColumns;
      } else {
        scope.columns = scope.otherColumns;
      }

      scope.pagingOption = {
        // content in one page
        pageSize: 5,
        // total number of items in box
        totalItems: 0,
        currentPage: 1,
        pageOption: []
      };

      scope.setNumberOfPages = scope.pagingOption.pageOption[0];

      scope.$watch('currentMessage',function(newVal,oldVal){
        scope.changedCurrentMessage(newVal,oldVal);
      });

      scope.changedCurrentMessage = function(newVal,oldVal){
         if(!newVal){
          return;
        }

        var currentSelectedMessage= _.find(scope.messages, function(message){
          return message.Id == newVal.Id;
        });

        return messageSvc.getMessageThread(newVal.Id, 10, 1).then(function (res) 
        {
          currentSelectedMessage.messageThread = res.results.Messages.filter(function (item) {
            return item.Id <= currentSelectedMessage.InResponseTo;
          });

          var mailbox = scope.currentMailbox;
          var userid = (mailbox.toUpperCase() === 'SENT' || mailbox.toUpperCase() === 'DRAFT') && !scope.searchFlag ? currentSelectedMessage.To[0].Id : currentSelectedMessage.From[0].Id;

          if(session.get('portal') === 'patient'){
            messageSvc.getStaffUserImage(userid).then(function (imageRes) {
              currentSelectedMessage.Image = (imageRes.results.image === null) ? null : imageRes.results.image;
            });
          }
          else{
            messageSvc.getUserImage(userid).then(function (imageRes) {
              currentSelectedMessage.Image = (imageRes.results.image === null) ? null : imageRes.results.image;
            });
          }
        });
      };

      scope.$watch('pagingOption.currentPage', function (newVal, oldVal) {
        // call api for next page
        alertService.clear();
        var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
        if (oldVal && newVal) {
          if (oldVal !== newVal && newVal !== '' && parseInt(newVal) > 0 && total >= newVal) {
            scope.messageList.checkAll = false;
            scope.selectAllMessage(null, false);
            scope.searchText ? scope.searchMessages(scope.searchText, (scope.searchingInArchive ? 'ARCHIVE' : null), scope.pagingOption.currentPage) : scope.mailboxChanged(scope.model.routeParams.mailbox); // jshint ignore:line
          }
          else if (isNaN(newVal) || parseInt(newVal) >= total || parseInt(newVal) <= 0 || isNaN(parseInt(newVal))) {
            scope.errorMessage = 'Please enter the valid page number.';
          }
        }
      });

      scope.$watch('pagingOption.pageSize', function (oldVal, newVal) {
        // call api for content in one page
        if (oldVal && newVal) {
          if (oldVal !== newVal) {
            scope.pagingOption.currentPage = 1;
            scope.mailboxChanged(scope.model.routeParams.mailbox);
          }
        }
      });
      scope.NoMessageHelpText = $translate.instant('MessageCenter_NoMessageHelpText');
      // get module settings ,basically used here for reply permission
      messageSvc.getModuleSettings().then(function (res) {
        scope.moduleSettings = res;
      });

      scope.haveParent = function (box, defaultMailboxes) {
        return _.filter(defaultMailboxes, function (folder) {
          return (+folder.Id === +box.ParentId) || (box.ParentId === null);
        }).length > 0;
      };
      /* get sort field */
      scope.translateDefaultFolders = function (folderName) {
        var translatedFolderName = '';
        switch (folderName) {
          case 'Inbox':
            translatedFolderName = $translate.instant('INBOX');
            break;
          case 'Sent':
            translatedFolderName = $translate.instant('SENT');
            break;
          case 'Drafts':
            translatedFolderName = $translate.instant('DRAFTS');
            break;
          case 'Archive':
            translatedFolderName = $translate.instant('ARCHIVE');
            break;
          default: 
            translatedFolderName = folderName;

        }
        return translatedFolderName;
      };
      // get api call for all mailboxes
      scope.getMailboxes = function () {
        // load user mailboxes

        var promise = mailboxSvc.getDefaultMailboxes().then(function (defaultMailboxes) {
          scope.defaultMailboxNames = [];
          angular.forEach(defaultMailboxes, function (box) {
            this.push(angular.lowercase(box.Name));
          }, scope.defaultMailboxNames);
          scope.flattenFolder = [];
          scope.userDefinedFolders = _.filter(defaultMailboxes, function (box) {
            scope.archieveRole = !scope.archieveRole ?
              box.Role.toUpperCase() === 'ARCHIVE' ?
                box.Role : null : scope.archieveRole;
            return box.Permissions.IsDeletable === true ? scope.haveParent(box, defaultMailboxes) : false;
          });

          scope.userDefaultFolders = _.filter(defaultMailboxes, function (box) {
            scope.archieveRole = !scope.archieveRole ?
              box.Role.toUpperCase() === 'ARCHIVE' ?
                box.Role : null : scope.archieveRole;
                box.Name = scope.translateDefaultFolders(box.Name);
            return box.Permissions.IsDeletable === false;
          });

          var userFolders = _.filter(defaultMailboxes, function (box) {
            return box.Permissions.IsDeletable === true;
          });

          /* get all the mail box list*/
          scope.mailboxes = userFolders;
          scope.collapseAll();
          scope.getSubFolder(userFolders);
          var currentMailbox = _.findWhere(defaultMailboxes, {Id: scope.model.routeParams.mailbox});
          if (currentMailbox) {
            messageSvc.setCurrentFolder(currentMailbox.Name);
          }
        });
        return promise;
      };
      scope.getMailboxes();

      scope.collapseAll = function () {
        scope.getParentFolder(scope.model.routeParams.mailbox);
        timeout(function () {
          scope.$broadcast('collapseAll', scope.parentId);
          scope.$broadcast('customCollapse', scope.parentId);
        }, 20);
      };
      scope.getParentFolder = function (id) {
        scope.parentId = [];
        var subfolder = scope.mailboxes.filter(function (subfolder) {
          return subfolder.Id === id;
        });
        if (subfolder.length <= 0) {
          return;
        }
        scope.getParent(subfolder[0]);
      };

      scope.getParent = function (item) {
        var subfolder = scope.mailboxes.filter(function (subfolder) {
          return +subfolder.Id === +item.ParentId;
        });
        if (subfolder.length <= 0) {
          return;
        }
        scope.parentId.push(subfolder[0].Id);
        subfolder.forEach(function (sub) {
          scope.getParent(sub);
        });
      };

      scope.getSubFolder = function (defaultMailboxes) {
        var subfolder = [];
        scope.mailboxList = defaultMailboxes.filter(function (item) {
          return item.ParentId === null;
        });
        scope.mailboxList.forEach(function (item) {
          scope.flattenFolder.push(item);
          scope.getsub(item);

        });
      };

      scope.getsub = function (item) {
        var subfolder = scope.mailboxes.filter(function (subfolder) {
          return parseInt(subfolder.ParentId) === parseInt(item.Id);
        });

        if (subfolder.length <= 0) {
          return;
        }
        item.subFolders = subfolder;
        subfolder.forEach(function (sub) {
          scope.flattenFolder.push(sub);
          scope.getsub(sub);
        });
      };
      // react to mailbox changes
      scope.mailboxChanged = function (mailbox, currentPage) {
        currentPage ? scope.pagingOption.currentPage = currentPage : null; // jshint ignore:line
        var obj = { 'Sort': scope.currentColumn + '|' + scope.isSortedType + '', 'Search': scope.searchText, 'Limit': scope.pagingOption.pageSize, 'Position': scope.pagingOption.currentPage };
        if (mailbox) {
          messageSvc.getMessages(mailbox, obj).then(function (messages) {
            if (messages) {
              scope.pagingOption.totalItems = messages.Total;
            }

            scope.messages = messages.Messages;

            var selected = scope.messages.filter(function (item) { return +item.Id === +location.$$search.sltdMesId; });(scope.messages && scope.messages.length > 0) ? scope.setSelectedMessage((selected.length > 0) ? selected[0] : scope.messages[0]) : null; // jshint ignore:line
          });
        }
      };
      scope.discardAllDraft = function (discard) {
        scope.IsMultiple = discard;
        dialogService.show('discardDraft');
      };
      scope.discardDraft = function () {
        var selectedMessage;
        var ischecked = scope.defaultSelectedMessage();
        if (scope.IsMultiple === undefined) {
          ischecked = false;
        }
        messageSvc.deleteMessages(ischecked ? scope.checkedMessages : scope.defaultMessage).then(function (res) {
          scope.messageList.checkAll = false;
          scope.selectAllMessage(null, false);
          scope.closeDialog();
          scope.IsMultiple = undefined;
          scope.refreshMailBox(scope.model.routeParams.mailbox);
        });
      };

      // delete messages from current box
      scope.deleteMessages = function () {
        if (scope.checkedMessages) {
          messageSvc.deleteMessages(scope.checkedMessages).then(function (affectedItems) {
            scope.refreshMailBox(scope.model.routeParams.mailbox);
            alertService.add('success', 'message deleted successfully', 5000);
          });
        }
      };

      scope.defaultSelectedMessage = function () {
        scope.defaultMessage = {};
        var ischecked = false;
        for (var key in scope.checkedMessages) {
          if (scope.checkedMessages[key]) {
            ischecked = true;
          }
        }
        if (scope.currentMessage) {
          scope.defaultMessage[scope.currentMessage.Id] = true;
        }
        return ischecked;
      };

      // set message as read,Unread
      scope.markMessageAs = function (value) {
        var ischecked = scope.defaultSelectedMessage();
        scope.setMessageProperty('IsUnread', value, ischecked ? scope.checkedMessages : scope.defaultMessage);
      };

      // refresh mailbox
      scope.refreshMailBox = function (mailBoxId) {
        scope.mailboxChanged(mailBoxId, 1);
        scope.getMessagesCount();
      };

      /* show dialog for new folder */
      scope.showDialogForNewFolder = function () {
        scope.parent = '';
        scope.folderName = undefined;
        scope.folderObj = undefined;
        dialogService.show('newFolder');
      };

      // checks for duplication of name between folders
      scope.checkForDuplication = function (newfolderName, Id, oldFolderObj) {
        var flag = false;
        var searchForDuplicateNameInExistingFolders = scope.defaultMailboxNames.indexOf(angular.lowercase(newfolderName));
        if (searchForDuplicateNameInExistingFolders !== -1) {
          flag = true;
        }
        for (var key in scope.mailboxes) {
          if ((+scope.mailboxes[key].ParentId === +Id) && scope.mailboxes[key].Name.toUpperCase() === newfolderName.toUpperCase() && scope.mailboxes[key].Id !== (oldFolderObj ? oldFolderObj.Id : undefined)) {
            flag = true;
            break;
          }
        }
        return flag;
      };

      // resets make subfolder of dropdown to blank
      scope.resetParent = function (makeSubFolder) {
        if (makeSubFolder === false) {
          scope.parent = '';
          scope.folderObj = '';
        }
      };

      /* show dialog for new folder ok click event,newfolderName used while adding from move to dropdown */
      scope.createFolder = function (oldFolderObj, newfolderName, isMoveTo) {
        alertService.clear();
        scope.showRequiredField = false;
        var errorMessageCreateFolder = '';
        if (scope.checkForDuplication(newfolderName, (scope.folderObj ? +scope.folderObj.Id : null), oldFolderObj)) {
          errorMessageCreateFolder = $translate.instant('MSG_CTR_FOLDER_NAME_EXISTS');
          alertService.add('danger', errorMessageCreateFolder, 0, '', 'alert_messagecenter_create');
          return;
        }
        scope.parent ? null : scope.parent = ''; // jshint ignore:line
        // isMoveTo ? scope.parent.Id = null : null;
        if (newfolderName) {
          // api service call for adding a folder
          mailboxSvc.createFolder(newfolderName, isMoveTo ? null : scope.parent.Id).then(function (res) {
            scope.folderObj = null;
            scope.folderName = null;
            // alertService.add('success', 'folder added successfully', 5000);
            isMoveTo ? scope.moveTo(res.MailboxId) : scope.getMailboxes(); // jshint ignore:line
          });
          dialogService.close();
        }
        else if (!oldFolderObj && !newfolderName) {
          scope.showRequiredField = true;
          scope.errorMessage = $translate.instant('MSG_CTR_FOLDER_NAME_IS_REQUIRED');
          alertService.add('danger', scope.errorMessage, 0, '', 'alert_messagecenter_create');
        }
      };

      scope.updateFolder = function (oldFolderObj, newfolderName, parent) {
        scope.showRequiredField = false;
        if (scope.checkForDuplication(newfolderName, parent ? parent.Id : null, oldFolderObj)) {
          scope.errorMessage = $translate.instant('MSG_CTR_FOLDER_NAME_EXISTS');
          alertService.add('danger', scope.errorMessage, 0, '', 'alert_messagecenter');
          return;
        }
        else if (!newfolderName) {
          scope.showRequiredField = true;
          scope.errorMessage = $translate.instant('MSG_CTR_FOLDER_NAME_IS_REQUIRED');
          alertService.add('danger', scope.errorMessage, 0, '', 'alert_messagecenter');
          return;
        } else {
          // api service call for renaming folder
          mailboxSvc.updateFolder(oldFolderObj.Id, newfolderName, parent ? parent.Id : null).then(function (res) {
            scope.getMailboxes();
            scope.folderObj = null;
            scope.folderName = null;
            dialogService.close();
          // alertService.add('success', 'folder renamed successfully', 5000);
          });
        }
      };

      /* show dialog for delete folder delete click event */
      scope.deleteFolder = function (folder, box) {
        if (folder) {
          var subFolderIdsList = [];
          _.forEach(folder.subFolders, function (subFolder) {
            subFolderIdsList.push(subFolder.Id);
            _.forEach(subFolder.subFolders, function (subSubFolder) {
              subFolderIdsList.push(subSubFolder.Id);
            });
          });

          mailboxSvc.deleteFolder(folder.Id, box).then(function (res) {
            scope.getParentFolder(folder.Id);
            // saving parent ids of deleting folderId
            var parentIdsByFolderId = scope.parentId;
            // again calling to get parent ids of current view folder
            scope.getParentFolder(scope.model.routeParams.mailbox);
            var parentIdsByRouteMailboxId = scope.parentId;
            scope.getMailboxes().then(function () {
              // check if current view folder or its parent is deleted
              var currentViewFolderExists = _.filter(scope.mailboxes, function (folder) { return +folder.Id === +scope.model.routeParams.mailbox; }).length === 1;
              // if current view folder is not deleted than check if parent is deleted, if yes than goto current parent of deleted one
              currentViewFolderExists ? null : _.contains(parentIdsByRouteMailboxId, parentIdsByFolderId[0]) ? location.url('/message-center/mailbox/' + (parentIdsByFolderId[0] || 'inbox')) : location.url('/message-center/mailbox/inbox'); // jshint ignore:line
            });

          });
        }
        scope.box = 'archive';
        dialogService.close();
      };

      scope.archiveMessages = function () {
        messageSvc.getArchiveFlag(scope.userId).then(function (res) {
          scope.archiveCheckbox = res;
          if (scope.archiveCheckbox) {
            scope.moveTo('archive');
          } else {
            dialogService.show('archive');
          }
        });
      };

      // move message to other folder
      scope.moveTo = function (folderId) {
        if (folderId === 'archive' && scope.archiveCheckbox === true) {
          messageSvc.setArchiveFlag(scope.userId).then(function (res) {});
        }
        var ischecked = scope.defaultSelectedMessage();
        if (folderId) {
          // avoiding user to move message in same folder
          if (scope.model.routeParams.mailbox.toUpperCase() !== folderId && (ischecked === true || Object.keys(scope.defaultMessage).length > 0)) {
            messageSvc.moveMessages(folderId, ischecked ? scope.checkedMessages : scope.defaultMessage).then(function (item) {
              // alertService.add('success', 'Messages moved successfully', 5000);
              scope.messages = [];
              scope.messageList.checkAll = false;
              scope.selectAllMessage(null, false);
              scope.refreshMailBox(scope.model.routeParams.mailbox);
              scope.getMailboxes();
              scope.checkedMessages = {};
            });
          } else {
            scope.messages = [];
            scope.getMailboxes();
          }

          dialogService.close();
        }
      };

      // move message to other folder
      scope.restore = function () {
        var ischecked = scope.defaultSelectedMessage();
        messageSvc.restoreMessages(ischecked ? scope.checkedMessages : scope.defaultMessage).then(function (item) {
          scope.messageList.checkAll = false;
          scope.selectAllMessage(null, false);
          alertService.add('success', $translate.instant('MSG_RESTORE_SUCCESS'), 5000);
          scope.refreshMailBox(scope.model.routeParams.mailbox);
        });
      };

      // converting [{'m1':true},{'m2':false}] to ['m1']
      scope.getCheckedMessages = function () {
        var a = [];
        _.forEach(scope.checkedMessages, function (value, key) {
          value ? a.push(key) : null; // jshint ignore:line
        });
        return a.length;
      };
      // sets Other folder names to specific folder name
      scope.putMailBoxNames = function (messages) {
        _.forEach(messages, function (message) {
          if (message.Folder === 'Other') {
            var boxObject = _.filter(scope.mailboxes, function (box) {
              return message.MailboxId === box.Id;
            });

            message.Folder = (boxObject && boxObject.length) ? boxObject[0].Name : message.Folder;
          }
        });
        return messages;
      };

      // search messages
      scope.searchMessages = function (searchText, box, currentPage) {
        alertService.clear();
        if (!angular.isUndefinedOrNull(searchText) && searchText.length < 3) {
          scope.errorMessage = $translate.instant('MSG_CTR_LESS_THAN_3_CHAR_SEARCH_ACTION');
          alertService.add('danger', scope.errorMessage, 0, '', 'alert_search-message');
          return;
        }
        if (currentPage === 1) {
          // set current page to 1
          scope.pagingOption.currentPage = 1;
        }
        if (scope.lastSearch && !searchText) {
          scope.searchFlag = false;
          scope.columns = scope.tempColumns;
          scope.tempColumns = null;
          scope.searchText = undefined;
          scope.searchingInArchive = false;
          scope.searchBox = null;
          scope.messages = [];
          scope.refreshMailBox(scope.model.routeParams.mailbox);
        }
        scope.lastSearch = searchText;
        if (searchText) {
          var boxName = scope.model.routeParams.mailbox.toUpperCase() === 'ARCHIVE' ? 'INBOX' : scope.model.routeParams.mailbox;

          var obj = { 'Sort': scope.currentColumn + '|' + scope.isSortedType + '', 'Search': searchText, 'Limit': scope.pagingOption.pageSize, 'Position': currentPage };
          messageSvc.getMessages((box === 'ARCHIVE') ? 'ARCHIVE' : boxName, obj).then(function (messages) {
            scope.searchingInArchive = (box === 'ARCHIVE');
            scope.searchBox = (box === 'ARCHIVE') ? 'ARCHIVE' : null;
            scope.searchFlag = true;
            scope.tempColumns ? null : scope.tempColumns = scope.columns; // jshint ignore:line
            scope.columns = scope.searchColumn;
            scope.messages = scope.putMailBoxNames(messages.Messages);
            scope.pagingOption.totalItems = messages.Total;
            (scope.messages && scope.messages.length > 0) ? scope.setSelectedMessage(scope.messages[0]) : null; // jshint ignore:line

          });
        }
      };

      // closes popups
      scope.closeDialog = function () {
        alertService.clear();
        scope.folderName = '';
        scope.removeMessage = 'false';
        scope.folderObj = null;
        scope.showRequiredField = false;
        scope.box = 'archive';
        scope.errorMessage = null;
        dialogService.close();
      };

      scope.submitRecall = function () {
        var req = { 'MessageId': scope.currentMessage.Id, 'RemoveMessage': (scope.removeMessage === 'true') ? true : false };
        messageSvc.recallMessage(req).then(function (res) {
          scope.removeMessage = 'false';
          // alertService.add('success', 'Message recall successfully', 5000);
          scope.mailboxChanged(scope.model.routeParams.mailbox);
          scope.closeDialog();
        });
      };

      scope.printMessages = function () {
        scope.selectedMessage = [];
        scope.messages.filter(function (messageData) {
          _.forEach(scope.checkedMessages, function (value, key) {
            if (key === messageData.Id && value === true) {
              scope.selectedMessage.push(messageData);
            }
          });
        });
        if (scope.selectedMessage.length === 0) {
          scope.selectedMessage.push(scope.currentMessage);
        }
        scope.setPrintData(scope.selectedMessage, $translate.instant('PRINT_MSG'), true);
      };

      scope.setPrintData = function (selectedMessage, title, isPreview) {
        var folder = messageSvc.getCurrentState().currentFolder;
        var printWindow = window.open();
        printWindow.document.write('<html><head>');
        printWindow.document.write('<style type="text/css"> body {font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;font-size: 14px;line-height: 1.42857143;color: #333; background-color: #fff;  } .table{ border-collapse: collapse;width:100%; } .table tr td { padding: 8px;line-height: 1.42857143; } .table tr th { padding: 8px;line-height: 1.42857143;background: #f7f7f7; } </style>');
        printWindow.document.write('</head><body>');
        printWindow.document.write('<br/>');
        printWindow.document.write('<br/>');
        var itemCount = 0;
        selectedMessage.forEach(function (item) {
          itemCount = itemCount + 1;
          printWindow.document.write('<h2>' + title + '</h2>');
          printWindow.document.write( $translate.instant('MSG_CTR_SUBJECT') + ' : ' + item.Subject);
          printWindow.document.write('<br/>');
          if (item.Folder?item.Folder.toUpperCase():folder.toUpperCase() === 'SENT') {
            printWindow.document.write($translate.instant('TO') + ' : ' + item.To[0].Name);
            printWindow.document.write('<br/>');
            printWindow.document.write($translate.instant('SENT') + ' : '  + window.moment(new Date(item.Date)).format('MM/DD/YYYY hh:mm a'));
            printWindow.document.write('<br/>');
            if (item.DateRead && (scope.moduleSettings ? scope.moduleSettings.ReadReceipts : false) && scope.isStaffUser) {
              printWindow.document.write('Read: ' + window.moment(new Date(item.DateRead)).format('MM/DD/YYYY hh:mm a'));
              printWindow.document.write('<br/><br/>');
            }
            if (item.PatientName && scope.isStaffUser) {
              printWindow.document.write('Re:Patient: ' + item.PatientName);
              printWindow.document.write('<br/><br/>');
            }
          }
          else if (item.Folder ? item.Folder.toUpperCase() : folder.toUpperCase() === 'DRAFT') {
            printWindow.document.write($translate.instant('TO') + ' : ' + item.To[0].Name);
            printWindow.document.write('<br/>');
            printWindow.document.write($translate.instant('SAVED') + ' : '+ window.moment(new Date(item.Date)).format('MM/DD/YYYY hh:mm a'));
            printWindow.document.write('<br/>');

          } else {
            printWindow.document.write($translate.instant('FROM') + ' : ' + item.From[0].Name);
            printWindow.document.write('<br/>');
            printWindow.document.write($translate.instant('RECEIVED') + ' : ' + window.moment(new Date(item.Date)).format('MM/DD/YYYY hh:mm a'));
            printWindow.document.write('<br/><br/>');
          }
          printWindow.document.write(item.Body);
          printWindow.document.write('<br/>');
          if (item.messageThread) {
            item.messageThread = utility.sortArray(item.messageThread, 'Date', 'desc', 'd');
            item.messageThread.forEach(function (threadData) {
              printWindow.document.write('<span style="margin-left : 40px" >' + $translate.instant('MSG_CTR_SUBJECT') + ' : ' + threadData.Subject + '</span>');
              printWindow.document.write('<br/>');
              printWindow.document.write('<span style="margin-left : 40px">' + $translate.instant('FROM') + ' : ' + threadData.From[0].Name + '</span>');
              printWindow.document.write('<br/>');
              printWindow.document.write('<span style="margin-left : 40px">' + $translate.instant('RECEIVED') + ' : ' + window.moment(new Date(threadData.Date)).format('MM/DD/YYYY hh:mm a') + '</span>');
              printWindow.document.write('<br/><br/>');
              printWindow.document.write('<div style="margin-left : 40px"><p>' + threadData.Body + '</p></div>');
            });
          }
          if (itemCount === selectedMessage.length) {
            printWindow.document.write('<br/><br/>');
          } else {
            printWindow.document.write('<br/><br/><div style="page-break-after:always"></div>');
          }

        });
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();

      };

      scope.getFormattedDate = function (date) {
        var d = new Date(date.toString());
        return d.getMonth() + '/' + d.getDay() + '/' + d.getFullYear();
      };

      // prevent closing dropdown on select of textbox
      scope.preventClose = function (event) {
        event.stopPropagation();
      };

      scope.isWithinMaxDaysForReplying = function (date) {
        if (scope.moduleSettings && +scope.moduleSettings.DaysPatientReplyAllowed === 0) {
          return true;
        }
        if (date !== undefined && !scope.isStaffUser && scope.moduleSettings) {
          return moment().diff(new Date(date), 'days') < scope.moduleSettings.DaysPatientReplyAllowed;
        } else {
          return true;
        }
      };

      messageSvc.getDynamicText('ReplyDisableText').then(function (response) {
        scope.replyDisableText = response;
      });

      // Switches between view states in mobile
      scope.switchCurrentState = function (state) {
        messageSvc.setCurrentState(state);
      };
      scope.closeActionSheet = function () {
        $('.as-action-sheet').closest('.dropdown-menu').dropdown('toggle');
      };
    }]);

}(window.app));
