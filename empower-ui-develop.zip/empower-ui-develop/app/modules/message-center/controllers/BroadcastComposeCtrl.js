(function (app) {
  'use strict';
  /* global tinyMCE */

  /* broadcast compose controller */
  app.controller('broadcastComposeCtrl', ['$scope', '$location', 'session', 'dialogService', 'messagingService', 'Msgctr.Broadcast', '$upload', 'alertService', '$http',
    function (scope, loc, session, dialogService, mSvc, bSvc, upload, aSvc, http) {
      scope.compose = {};
      scope.uploadFileRestrict = {};
      scope.compose.Attachments = [];
      scope.compose.sendTo = 'User';
      scope.compose.To = [];
      scope.Categories = [];

      /* init function */
      scope.init = function () {
        bSvc.getBroadcastContentCategories(null).then(function (res) {
          scope.Categories = res;
          scope.getDraftInformation();
        });

        // get templates in scope variable for popup
        http.get(app.root + 'modules/message-center/templates/discardBroadCastCompose.html').success(function (htmlData) {
          scope.broadCastTemplate = htmlData;
        });

      };

      /* get draft information */
      scope.getDraftInformation = function () {
        scope.draftId = loc.$$search.draftId;
        if (scope.draftId === null || scope.draftId === undefined) {
          return;
        }

        var obj = {
          'id': scope.draftId,
          'includeRecipients': false,
          'includeAttachments': true
        };
        bSvc.getSentMessageById(obj).then(function (sentResponse) {
          // bSvc.getDetailsByDraftId(scope.draftId).then(function (response) {
          var result = sentResponse;
          scope.compose.body = result.Body;
          // tinyMCE.activeEditor.getBody().textContent = tinyMCE.activeEditor.setContent = scope.compose.body;
          scope.compose.subject = result.Subject;
          scope.senderName = result.SenderName;
          scope.compose.sendTo = result.RecipientType;

          scope.getTemplate(result.TemplateId);

          angular.forEach(result.Attachments, function (attachment) {
            scope.compose.Attachments.push(attachment);

          });

          angular.forEach(result.ImportIds, function (Id) {
            bSvc.getBroadCastMessageImortDetails(Id).then(function (importIdResponse) {
              importIdResponse.Retval.isImportList = true;
              scope.compose.To.push(importIdResponse.Retval);
            });
          });

          scope.compose_target_ids = result.TargetIds;

          bSvc.getModules().then(function (response) {
            var module = _.find(response, { 'ModuleId': 'MessageCenter' });
            bSvc.getTargetGroups({ moduleInstanceId: module.Id }).then(function (res) {
              angular.forEach(scope.compose_target_ids, function (tg) {
                var temp;
                if (_.filter(res, function (target) { if (target.Id === tg) { temp = target; } return target.Id === tg; }).length > 0) {
                  scope.compose.To.push({ 'Name': temp.Name, 'Id': temp.Id, 'isTargetGroupList': true });
                }
              });
            });
          });

          scope.getSender(result.CategoryId);

          for (var categoryIndex = 0; categoryIndex < scope.Categories.length; categoryIndex += 1) {
            var category = scope.Categories[categoryIndex];
            if (category.UniqueId === result.CategoryId) {
              scope.compose.category = category;
              break;
            }
          }

        });

      };

      /* get template by id */
      scope.getTemplate = function (templateId) {
        bSvc.getBroadcastContentTemplates(null).then(function (res) {
          scope.Templates = res;
          angular.forEach(scope.Templates, function (template) {
            if (template.UniqueId === templateId) {
              scope.compose.template = template;
            }
          });
        });
      };

      /* get sender information */
      scope.getSender = function (uniqueId) {
        bSvc.getBroadcastContentSenders(uniqueId).then(function (senderResponse) {
          scope.Senders = senderResponse;

          angular.forEach(scope.Senders, function (sender) {
            if (scope.senderName === sender.DisplayName) {
              scope.compose.from = sender;
            }
          });
        });
      };

      /* get drop-down value */
      scope.getDropDownVal = function (type, Id) {
        if (type.toLowerCase() == 'senders') {
          bSvc.getBroadcastContentSenders(Id).then(function (res) {
            scope[type] = res;
          });
        }
        else if (type.toLowerCase() == 'templates') {
          bSvc.getBroadcastContentTemplates(Id).then(function (res) {
            scope[type] = res;
          });
        }
        else if (type.toLowerCase() == 'categories') {
          bSvc.getBroadcastContentCategories(Id).then(function (res) {
            scope[type] = res;
          });
        }

      };

      /* get templates in scope variable for popup */
      http.get(app.root + 'modules/message-center/templates/popup-templates.html').success(function (htmlData) {
        scope.popupTemplate = htmlData;
      });

      /* load drop-down data */
      angular.forEach(['Templates', 'Categories'], function (val) {
        scope.getDropDownVal(val);
      });

      /* load template */
      scope.loadTemplate = function (previousValue) {
        mSvc.getDynamicText('ConfirmSelection').then(function (response) {
          scope.confirmSelectionTemplate = response;
        });

        // scope.previousValue = (previousValue !== '') ? JSON.parse(previousValue) : '';
        scope.previousValue = previousValue;
        if (scope.broadcast_compose_message.txtBody.$dirty) {
          angular.element('.confirmWarning').show();
          return;
        }
        scope.confirmLoadTemplate();
      };

      // reacts on change of category to get senders list
      scope.updateSendersList = function (category) {
        scope.Senders = [];
        scope.compose.from = '';
        if (category) {
          scope.getDropDownVal('Senders', category.UniqueId);
        } else {
          scope.Category = null;
          scope.Senders = null;
        }
      };

      // validate data
      scope.validate = function () {
        var errorMessage = '';
        var message = 'The following information was missing or invalid. Please make changes and re-submit:<br>';

        if (scope.compose.from === undefined || scope.compose.from.length === 0) {
          errorMessage += 'From: Not Defined <br>';
        }

        if (scope.compose.To === undefined || scope.compose.To.length === 0) {
          errorMessage += 'To: Not Defined <br>';
        }

        if (scope.compose.subject === undefined || scope.compose.subject.length === 0) {
          errorMessage += 'Subject: Not Defined <br>';
        }

        if (scope.compose.body.length === 0) {
          errorMessage += 'Message Body: Not Defined <br>';
        }

        if (scope.compose.body.length > 10000) {
          errorMessage += 'Message Body: Cannot be greater than 10000 characters <br>';
        }

        if (errorMessage.length > 0) {
          aSvc.add('danger', message + errorMessage, '', 'alert_page-top');
          return true;
        }

        return false;
      };

      /* construct broadcast data */
      scope.buildBroadcastData = function () {
        var importIds = [];
        var targetIds = [];
        var attachments = [];

        angular.forEach(scope.compose.To, function (toAddress) {
          if (toAddress.isImportList) {
            importIds.push(toAddress.Id);
          } else if (toAddress.isTargetGroupList) {
            targetIds.push(toAddress.Id);
          }
        });

        angular.forEach(scope.compose.Attachments, function (attachment) {
          attachments.push({ 'UniqueId': (attachment.Id || attachment.UniqueId) });
        });

        return {
          'bmMsg': {
            'AuthorUserId': session.get('userId'),
            'CategoryId': (scope.compose.category === undefined || scope.compose.category === null) ? null : scope.compose.category.UniqueId,
            'SenderId': (scope.compose.from === undefined || scope.compose.from === null) ? null : scope.compose.from.UniqueId,
            'TemplateId': (scope.compose.template === null || scope.compose.template === undefined) ? null : scope.compose.template.UniqueId,
            'Subject': (scope.compose.subject === null || scope.compose.subject === undefined) ? '' : scope.compose.subject,
            'Body': scope.compose.body,
            'RecipientType': scope.compose.sendTo,
            'Recipients': [], // recipient id and target id
            'Attachments': attachments,
            'Images': [],
            'ImportIds': importIds,
            'IsEmailOnlyBroadcastMessage': (scope.compose.sendTo === 'Patient') ? true : false,
            'TargetIds': targetIds
          }
        };

      };

      // send message by calling api
      scope.sendMessage = function () {
        aSvc.clear();
        if (!scope.validate()) {
          var data = scope.buildBroadcastData();
          bSvc.sendBroadcastMessage(data).then(function () {
            scope.deletesavedDraft();
            loc.url('/message-center/broadcast?refuse_cache=sent');
          });
        }
      };

      // deletes saved draft
      scope.deletesavedDraft = function () {
        if (scope.draftId) {
          bSvc.deleteMessageById(scope.draftId).then(function () {});
        }
      };

      // save broadcast message as draft
      scope.loadSaveAsTemplate = function (compose) {
        aSvc.clear();
        if (compose !== null) {
          scope.selectedTemplate = compose.template;
          scope.newTemplate = {
            'name': compose.name,
            'description': compose.description,
            'category': compose.category,
            'subject': compose.subject,
            'message': compose.body // tinyMCE.activeEditor.getContent()
          };
        }
        scope.initialAttachment = angular.copy(compose.Attachments);
        scope.template = { Attachments: compose.Attachments };
        scope.categories = scope.Categories;

        angular.element('.newTemplate').modal('show');
      };

      /* save template */
      scope.saveTemplate = function () {
        if (scope.newTemplate.name === undefined || scope.newTemplate.name === '') {
          aSvc.add('danger', 'The following information was missing or invalid. Please make changes and re-submit: Name: Not Defined', 0, '', 'alert_mc_broadcasttemplete');
        } else {
          scope.newTemplate.Attachments = [];

          if (scope.template.Attachments.length > 0) {
            angular.forEach(scope.template.Attachments, function (item) {
              scope.newTemplate.Attachments.push({ 'uniqueId': item.Id || item.UniqueId });
            });
          }

          bSvc.saveTemplate(scope.newTemplate).then(function (res) {
            if (res.Retval.dbResult === 'NameNotUnique') {
              aSvc.add('danger', 'There is already a Template with the same name. Please enter a unique name for the new Template.', 0, '', 'alert_mc_broadcasttemplete');
            } else {
              // scope.getDropDownVal('Templates');
              scope.closeDialog('.newTemplate');
              loc.url('/message-center/broadcast?refuse_cache=template&&tab_index=2');
            }
          });
        }
      };

      /* closes popups */
      scope.close = function () {
        dialogService.close();
      };

      /* close dialog */
      scope.closeDialog = function (popupName) {
        aSvc.clear();
        scope.compose.Attachments = scope.initialAttachment;
        angular.element(popupName).modal('hide');
      };

      /* save message as draft */
      scope.saveDraft = function (data) {
        bSvc.saveBroadcastMessageAsDraft(data).then(function () {
          loc.url('/message-center/broadcast?refuse_cache=draft&&tab_index=1');
        });
      };

      // save broadcast message as draft
      scope.saveBroadcastMessageAsDraft = function () {
        aSvc.clear();

        var errorMessage = '';
        var message = 'The following information was missing or invalid. Please make changes and re-submit:<br>';

        if (scope.compose.from === undefined || scope.compose.from.length === 0) {
          errorMessage += 'From: Not Defined <br>';
        }

        if (errorMessage.length > 0) {
          aSvc.add('danger', message + errorMessage, 0, '', 'alert_page-top');
          return;
        }

        var data = scope.buildBroadcastData();
        var draftObj = {};
        /* modifying object for saving draft message */
        draftObj.message = data.bmMsg;
        if (scope.draftId === null || scope.draftId === undefined || scope.draftId === 0) {
          scope.saveDraft(draftObj);
          return;
        }

        bSvc.deleteMessageById(scope.draftId).then(function () {
          scope.saveDraft(draftObj);
        });
      };

      /* return the new array and remove the selected file */
      scope.removeFile = function (file) {
        scope.compose.Attachments = _.remove(scope.compose.Attachments, function (data) {
          return data.UniqueId !== (file.Id || file.UniqueId);
        });
        scope.template = { Attachments: scope.compose.Attachments };
      };

      // method to open discard confirmation or save popup
      scope.discardMessage = function () {
        if (scope.broadcast_compose_message.$dirty === true) {
          if (event) {
            event.preventDefault();
          }
          dialogService.show('discardBroadCastCompose');
        } else {
          scope.discard();
        }
      };

      // final discard call and route
      scope.discard = function () {
        loc.url('/message-center/broadcast?refuse_cache=draft&&tab_index=1');
      };

      // open system dialog for file upload
      scope.fileUpload = function () {
        angular.element('.upload-file').click();
      };

      // show dialog for selecting recipients
      scope.showDialog = function () {
        scope.init();
      };

      // removes recipient group from compose 'TO'
      scope.removeRecipients = function (item) {
        scope.compose.To = _.reject(scope.compose.To, item);
      };

      /* get file configuration from admin */
      mSvc.getFileTypes().then(function (response) {
        scope.uploadFileRestrict = response;
      });

      mSvc.getDynamicText('MessageCenterInvalidAttachmentFile').then(function (response) {
        scope.MessageCenterInvalidAttachmentFile = response;
      });

      /* file select */
      scope.onFileSelect = function ($files) {
        aSvc.clear();
        // $files: an array of files selected, each file has name, size, and type.
        for (var i = 0; i < $files.length; i += 1) {
          var file = $files[i];

          if (file.name) {
            var fileExtension = file.name.split('.');
            if (file.size > scope.uploadFileRestrict.MaxSize ||
              scope.uploadFileRestrict.FileTypes.indexOf('.' + angular.lowercase(fileExtension[(fileExtension.length - 1)])) === -1) {
              var ext = '', count = 0;
              /* jshint ignore:start */
              scope.uploadFileRestrict.FileTypes.forEach(function (data) {
                count += 1;
                var lastExt = ((scope.uploadFileRestrict.FileTypes.length) === count) ? '.' : ',';
                ext = ext + ' ' + data + ' ' + lastExt;
              });
              /* jshint ignore:end */
              scope.errorMessage = scope.MessageCenterInvalidAttachmentFile || 'Your attachment cannot be added to the message because it is invalid. The file must be less than ' + scope.uploadFileRestrict.MaxSize + ' KBs and have an extension of ' + ext;
              scope.errorMessage = scope.errorMessage.replace(/\$\$FileSize\$\$/g, Math.floor(scope.uploadFileRestrict.MaxSize / 1024)).replace(/\$\$FileExtensions\$\$/g, ext);

              if (angular.element('.newTemplate.in').length > 0) {
                aSvc.add('danger', scope.errorMessage, 0, '', 'alert_page-new-template-top');
              } else {
                aSvc.add('danger', scope.errorMessage, 0, '', 'alert_page-top');
              }
              return;
            }
          }

          scope.fileDataUpload(file, i);
        }
      };

      /* upload the file */
      scope.fileDataUpload = function (file) {
        var fileReader = new FileReader();
        fileReader.readAsArrayBuffer(file);

        fileReader.onload = function (e) {
          var type = (file.type === '') ? 'application/octet-stream' : file.type;

          upload.http({
            url: app.api.root + 'messages/uploadAttachment',
            data: { 'FileBase64': bSvc.getArrayToBase64(e.target.result), 'Details': { 'Name': file.name, 'Type': type } }
          }).then(function (response) {
            var res = { 'FileName': file.name, 'Type': type, 'UniqueId': response.data.results.AttachmentId };
            scope.compose.Attachments.push(res);
            scope.template = { Attachments: scope.compose.Attachments };

          }, null, function () {
            // scope.progress[index] = parseInt(100.0 * evt.loaded / evt.total);

          });
        };
      };

      /* function to set action on confirm message */
      scope.confirm = function (action) {
        scope.isConfirm = action;
        angular.element('.confirmWarning').hide();
        if (action === false) {
          if (scope.previousValue === '') {
            scope.compose.template = scope.previousValue;
          } else {
            angular.forEach(scope.Templates, function (data) {
              if (data.UniqueId === scope.previousValue.UniqueId) {
                scope.compose.template = data;
              }
            });
          }
        }

        if (scope.isConfirm === true) {
          scope.broadcast_compose_message.$setPristine();
          scope.confirmLoadTemplate();
        }
      };

      /* function to load template */
      scope.confirmLoadTemplate = function () {
        if (scope.compose.template !== null) {
          bSvc.getTemplateById(parseInt(scope.compose.template.UniqueId)).then(function (res) {
            scope.compose.category = {};

            scope.compose.body = res.Body;
            // tinyMCE.activeEditor.getBody().textContent = tinyMCE.activeEditor.setContent = scope.compose.body;
            scope.compose.subject = res.Subject;
            scope.compose.Attachments = res.Attachments;

            angular.forEach(scope.Categories, function (category) {
              if (category.UniqueId === res.CategoryId) {
                scope.compose.category = category;
                scope.updateSendersList(category);
              }
            });
          });
        }
      };
    }]);

}(window.app));
