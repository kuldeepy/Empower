'use strict';

var GetTargetContentDialogTemplates = function () {
  /* method for dialog service content of target rules */
  this.getTargetRulesContent = function () {
    return '<div><div ng-include=\'"/modules/message-center/templates/target-rules-popup.html"\'></div></div>';
  };

  /* method for dialog service content of target rules confirm dialog */
  this.getTargetRulesConfirmDialogContent = function () {
    return '<p ng-bind="ruleController.confirmMessage"></p>';
  };

  /* method for dialog service content of target rules confirm dialog */
  this.getTargetRulesConfirmDialogFooter = function (dialogName) {
    return '<div class="multi-button-bar inside-modal-footer">' +
    '<input type="button" class="margin-right btn btn-primary" ng-click="yesConfirmClick(\'' + dialogName + '\')" value="Yes"/>' +
    '<input type="button" class="margin-right btn btn-secondary" ng-click="cancelConfirmClick(\'' + dialogName + '\')" value="No"/>' +
    '</div>';
  };

};
