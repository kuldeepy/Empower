(function (app) {
  'use strict';

  app.controller('MessageCenterComposeCtrl',
    ['$scope', '$location', 'session', 'messagingService', 'alertService', '$upload', 'dialogService', '$http', '$sce', '$translate','userPermissionsSvc',
      function (scope, location, session, messageSvc, alertService, $upload, dialogService, http, sce ,$translate, userPermissionsSvc) {
        scope.sendingParam = 'SENT';
        scope.showRePatient = true;
        scope.compose = {};
        scope.compose.toIsAStaffUser = false;
        scope.compose.user = angular.fromJson(session.get('userFullName'));
        scope.compose.user.userId = angular.fromJson(session.get('userId'));
        scope.oneAtATime = true;
        scope.user = JSON.parse(session.get('userFullName')) || {};
        scope.returnFolderID = location.$$search.returnFolderID;
        scope.compose.allowreply = true;

        var obj = scope.model.routeParams.messageId.split('_');
        scope.currentMessageId = obj[0] || 0;
        scope.currentMailBox = obj[1] || '';
        // get module settings ,basically used here for reply permission
        messageSvc.getModuleSettings().then(function (res) {
          scope.moduleSettings = res;
        });
        // get templates in scope variable for popup
        http.get(app.root + 'modules/message-center/templates/discardCompose.html').success(function (htmlData) {
          scope.template = htmlData;
        });
        scope.compose.Attachments = [];

        if(scope.model.routeParams.messageId === '_new'){
          if (!userPermissionsSvc.userHasPermission('message-center.messages.create')) {
            location.path('/');
          }
        }

        // get recipients for patient compose mail
        if (!scope.isStaffUser) {
          messageSvc.getRecipient().then(function (users) {
            scope.recipients = _.filter(users, function (user) {
              return (user.Id.toString() !== scope.compose.user.userId.toString() ? true : user.Type != 'User');
            });
            if (scope.model.routeParams.messageId !== '_new' && scope.model.routeParams.messageId.split('_')[1].toUpperCase() === 'DRAFT') {
              scope.getMessageByIDApi();
            }
          });
        }

        // user going for reply
        if (scope.model.routeParams.messageId !== '_new' && scope.model.routeParams.messageId.split('_')[1].toUpperCase() !== 'DRAFT') {
          scope.sendingParam = 'REPLY';
          messageSvc.getMessageById(obj[0], obj[1]).then(function (res) {
            scope.messageThread = res;
            scope.prePolulate(res[0]);
            if (scope.isStaffUser) {
              scope.setupControl();
            }
            scope.showReceipent = false;
            messageSvc.getMessageThread(obj[0], 10, 1).then(function (res) {
              var threadedMessage = res.results.Messages.filter(function (item) {
                return +item.Id <= +scope.messageThread[0].InResponseTo;
              });
              scope.messageThread = scope.messageThread.concat(threadedMessage);
            });
          });
        } else {
          scope.showReceipent = true;
        }

        /**/
        scope.getMessageByIDApi = function () {
          scope.messageThread = [];
          messageSvc.getMessageById(obj[0], obj[1]).then(function (res) {
            scope.messageThreadDraft = res;
            scope.prePolulate(res[0]);
            if (scope.isStaffUser) {
              scope.setupControl();
            }
            messageSvc.getMessageThread(obj[0], 10, 1).then(function (res) {
              var threadedMessage = res.results.Messages.filter(function (item) {
                return +item.Id <= +scope.messageThreadDraft[0].InResponseTo;
              });

              scope.messageThread = threadedMessage;
              scope.compose.ConversationId = scope.messageThread.length > 0 ? scope.messageThread[0].ConversationId : null;
            });
          });
        };

        // set up control show and hide
        scope.setupControl = function () {
          if (scope.compose.recipient.Name) {
            messageSvc.getRoleOfUserById(scope.compose.recipient.Id).then(function (res) {
              angular.forEach(res, function (role) {
                if (role.Name === 'Staff') { scope.compose.toIsAStaffUser = true; }
              });
            });
          }
          scope.showRePatient = scope.compose.rePatient.Name ? false : true;
          scope.showReceipent = scope.compose.recipient.Name ? false : true;
          if (!scope.compose.recipient.Name) { scope.compose.recipient = undefined; }
        };
        // pre-populate fields
        scope.prePolulate = function (response) {
          if (scope.sendingParam === 'REPLY') {
            scope.compose.subject = scope.messageThread[0].Subject.split(':')[0].toUpperCase() === 'RE' ?
              scope.messageThread[0].Subject
              : 'RE: ' + scope.messageThread[0].Subject;
            scope.compose.recipient = scope.messageThread[0].From[0];
          } else {
            scope.compose.subject = response.Subject ? response.Subject : '';
            if (!scope.isStaffUser) {
              angular.forEach(scope.recipients, function (recipient) {
                if (recipient.Id == response.To[0].Id & recipient.Type === 'Physician') {
                  scope.compose.recipient = recipient;
                }
              });

              if (scope.compose.recipient == undefined) {
                scope.compose.recipient = response.To[0];
              }
            } else {
              scope.compose.recipient = response.To[0];
              scope.compose.allowreply = response.IsReplyDisabled || true;
            }

            scope.compose.body = response.Body ? response.Body : '';
            angular.forEach(response.Attachments, function (data) {
              scope.compose.Attachments.push({ Name: data.Name, Type: data.Type, Id: data.Id });
            });
          }
          scope.compose.rePatient = { Name: response.PatientName, Id: response.PatientId };
          scope.compose.ConversationId = response.ConversationId;
          scope.compose.Id = response.Id;
          scope.compose.InResponseTo = response.InResponseTo;
          if (response.Folder.toUpperCase() !== 'DRAFT') {
            scope.compose.InResponseTo = response.Id;
          }

        };

        // staff user
        if (scope.isStaffUser) {
          if (scope.model.routeParams.messageId !== '_new' && scope.model.routeParams.messageId.split('_')[1].toUpperCase() === 'DRAFT') {
            scope.getMessageByIDApi();
          }
        }

        // edit and save draft or reply
        scope.editAndSaveMessage = function (messageId, mailBoxId, navigationUrl) {
          if (!(scope.compose.recipient ? scope.compose.recipient.Name : undefined) && !scope.compose.subject && (scope.compose.body.length === 0) && (scope.compose.Attachments.length === 0)) {
            scope.errorMessage = 'Please fill out at least one field';
            return;
          }
          // scope.deleteDraft(messageId);
          if (!(scope.compose.subject && scope.compose.subject.length > 0)) { scope.compose.subject = ''; }
          messageSvc.saveMessages(scope.compose, mailBoxId).then(function (response) {
            scope.deleteDraft(messageId);
            var draftRes = JSON.parse(response.Status);
            if (navigationUrl) {
              if ((scope.redirectIngUrl || '').split('/').length !== 4) {
                location.url('/message-center/mailbox/' + ((scope.redirectIngUrl || '').split('/')[5] || scope.returnFolderID || 'inbox'));
              } else {
                location.url((scope.redirectIngUrl || '').split('/')[3]);
              }
            } else {
              location.url('/message-center/message/' + draftRes.Id + '_draft?returnFolderID=' + scope.returnFolderID);
            }
            // location.url('message-center/mailbox/draft');
            dialogService.close();
            scope.compose_message.$setPristine();
          });
        };

        // send earlier drafted message
        scope.sendDraftMessage = function (messageId, mailBoxId) {
          if (scope.msgSettingsValidation(mailBoxId) || !(scope.compose.recipient ? scope.compose.recipient.Id : null) || !scope.compose.subject || (scope.compose.body.length === 0)) {
              var message = $translate.instant('MSG_CTR_MISSING_OR_INVALID_INFO') + '<br>' +
                ((scope.compose.recipient ? scope.compose.recipient.Id : null) ? '' : $translate.instant('MSG_CTR_TO')  +': '+ $translate.instant('MSG_CTR_NOT_DEFINED') + '<br>') +
                (scope.compose.subject ? '' : $translate.instant('MSG_CTR_SUBJECT')  +': '+ $translate.instant('MSG_CTR_NOT_DEFINED') + '<br>') +
                (scope.compose.body ? '' : $translate.instant('MSG_CTR_MESSAGE_BODY')  +': '+ $translate.instant('MSG_CTR_NOT_DEFINED') + '<br>') +
              scope.invalidCharactersErrorMessage;
            // scope.errorMessage = message;
            alertService.add('danger', message, 0, '', 'alert_compose-message');
            return;
          }

          if (scope.compose.InResponseTo !== null) {
            mailBoxId = 'REPLY';
            scope.compose.Id = scope.compose.InResponseTo;
          }
          messageSvc.saveMessages(scope.compose, mailBoxId).then(function () {
            scope.deleteDraft(messageId);
            scope.compose_message.$setPristine();
            location.url('/message-center/mailbox/' + scope.returnFolderID + '?sltdMesId=' + obj[0]);
          });

        };

        messageSvc.getMessageValidationSettings().then(function (response) {
          if (response !== null) {
            angular.forEach(response.Fields, function (data) {
              if (data.DataKey === 'MessageBody') {
                scope.messageValidation = data.Filters;
              }
            });
          }
          if (!scope.messageValidation.MaxLength) {
            scope.MessageBodyDisable = true;
          }
        });

        scope.invalidCharactersErrorMessage = '';
        scope.msgSettingsValidation = function (mailBoxId) {

          scope.invalidCharactersErrorMessage = '';
          var error = false;
          if (scope.messageValidation) {
            scope.messageValidation.ValidCharacters = scope.defaultCharacter = "-@,;'.:!?_/" + scope.messageValidation.InvalidCharacters;
            if (scope.messageValidation.InvalidCharacters !== null && mailBoxId.toUpperCase() !== 'DRAFT') {
              var reg = new RegExp('^[a-zA-Z0-9\\s' + scope.messageValidation.ValidCharacters + ']*$', 'i');
              var result = reg.test(scope.compose.body);

              if (scope.compose.body) {
                if (scope.compose.body.length < scope.messageValidation.MinLength || scope.compose.body.length > scope.messageValidation.MaxLength) {

                  scope.invalidCharactersErrorMessage = $translate.instant('MSG_CTR_MESSAGE_BODY_MINMAX_VALIDATION').replace('@@MinLength@@', scope.messageValidation.MinLength).replace('@@MaxLength@@', scope.messageValidation.MaxLength);
                  error = true;

                }
                if (scope.compose.body.disabled) {
                  scope.invalidCharactersErrorMessage = $translate.instant('MSG_CTR_MESSAGE_BODY_MAX_VALIDATION');
                }

              }

              if (result === false) {
                scope.invalidCharactersErrorMessage += $translate.instant('MSG_CTR_MESSAGE_BODY_SPLCAR_VALIDATION').replace('@@ValidCharacters@@', scope.messageValidation.ValidCharacters);
                error = true;
              }
            }
          }
          return error;
        };

        // validates message
        scope.validateMessage = function (mailBoxId) {
          if (mailBoxId === 'SENT' || mailBoxId === 'REPLY') {
            if (scope.msgSettingsValidation(mailBoxId) || !scope.compose.recipient || !scope.compose.subject || (scope.compose.body === undefined) || (scope.compose.body === '')) {
            var message = $translate.instant('MSG_CTR_MISSING_OR_INVALID_INFO') + '<br>' +
              ((!scope.compose || scope.compose.recipient) ? '' : $translate.instant('MSG_CTR_TO')  +': '+ $translate.instant('MSG_CTR_NOT_DEFINED') + '<br>') +
              ((!scope.compose || scope.compose.subject) ? '' : $translate.instant('MSG_CTR_SUBJECT')  +': '+ $translate.instant('MSG_CTR_NOT_DEFINED') + '<br>') +
              ((scope.compose.body === undefined || scope.compose.body === "" ) ? $translate.instant('MSG_CTR_MESSAGE_BODY')  +': '+ $translate.instant('MSG_CTR_NOT_DEFINED') + '<br>' : '') +
              scope.invalidCharactersErrorMessage;
              // scope.errorMessage = sce.trustAsHtml(message).toString();
              alertService.add('danger', message, 0, '', 'alert_compose-message');
              return false;
            }
          }
          if (mailBoxId === 'DRAFT') {
            if (!(scope.compose.recipient ? scope.compose.recipient.Name : undefined) && !scope.compose.subject && !(scope.compose.body) && (scope.compose.Attachments.length === 0)) {
              // scope.errorMessage = 'Please fill out at least one field';
              alertService.add('danger', 'Please fill out at least one field', 0, '', 'alert_compose-message');
              return false;
            }
            if (scope.msgSettingsValidation(mailBoxId)) {
              // scope.errorMessage = scope.invalidCharactersErrorMessage;
              alertService.add('danger', scope.invalidCharactersErrorMessage, 0, '', 'alert_compose-message');
              return false;
            }

            if (!scope.compose.subject) { scope.compose.subject = ''; }
          }
        };

        /* save or send message from compose mail */
        scope.sendOrSaveMessage = function (mailBoxId, navigationUrl) {
          // either edit & save or send already saved draft(or saved reply)
          if (scope.model.routeParams.messageId.split('_')[1].toUpperCase() === 'DRAFT') {
            var messageId = scope.model.routeParams.messageId.split('_')[0].toUpperCase();
            if (mailBoxId === 'DRAFT') {
              scope.editAndSaveMessage(messageId, mailBoxId, navigationUrl);
            } else {
              scope.sendDraftMessage(messageId, mailBoxId);
            }
          } else {
            // validates message
            if (scope.validateMessage(mailBoxId) !== false) {
              // new message send or new reply
              if (!scope.compose.rePatient && !scope.isStaffUser) {
                scope.compose.patientId = JSON.parse(session.get('patient')).patientId;
              } else {
                scope.compose.patientId = null;
              }
              messageSvc.saveMessages(scope.compose, mailBoxId).then(function (response) {
                if (mailBoxId === 'SENT' || mailBoxId === 'REPLY') {
                  location.url('/message-center/mailbox/' + ((scope.redirectIngUrl || '').split('/')[5] || scope.returnFolderID) + '?sltdMesId=' + obj[0]);
                } else {
                  var draftResponse = JSON.parse(response.Status);
                  // location.url('message-center/mailbox/draft');
                  if (navigationUrl) {
                    if ((scope.redirectIngUrl || '').split('/').length !== 4) {
                      location.url('/message-center/mailbox/' + ((scope.redirectIngUrl || '').split('/')[5] || scope.returnFolderID || 'inbox'));
                    } else {
                      location.url((scope.redirectIngUrl || '').split('/')[3]);
                    }
                  } else {
                    location.url('/message-center/message/' + draftResponse.Id + '_draft?returnFolderID=' + scope.returnFolderID);
                  }
                  dialogService.close();
                }
                scope.compose_message.$setPristine();
              });
            }
          }
        };

        /**/
        scope.deleteDraft = function (messageId) {
          var obj = {};
          obj[messageId] = true;
          return messageSvc.deleteMessages(obj).then(function () {
            // location.path('/message-center/mailbox/draft');
          });
        };

        /* closes popups */
        scope.closeDialog = function () {
          scope.folderName = '';
          scope.folderObj = null;
          dialogService.close();
        };

        /**/
        scope.discard = function (event, newUrl) {
          // if ((scope.compose.recipient ? scope.compose.recipient.Name : undefined) || scope.compose.subject || (scope.compose.body ? scope.compose.body.trim() : '') || (scope.compose.Attachments.length !== 0)) {
          if (scope.compose_message.$dirty === true) {
            if (event) {
              event.preventDefault();
            }
            scope.redirectIngUrl = newUrl;
            dialogService.show('discardCompose');
          // location.path('/message-center');
          } else {
            scope.redirectIngUrl = newUrl;
            location.path('/message-center');
          }
        };

        /**/
        scope.discardNoClick = function (messageId) {
          scope.compose.recipient = undefined;
          scope.compose.subject = undefined;
          scope.compose.body = undefined;
          scope.compose.Attachments = [];
          if (messageId !== 0 && scope.returnFolderID != 'inbox') {
            scope.deleteDraft(messageId).then(function () {
              scope.compose_message.$setPristine();
              if ((scope.redirectIngUrl || '').split('/').length !== 4) {
                location.url('message-center/mailbox/' + ((scope.redirectIngUrl || '').split('/')[5] || scope.returnFolderID) + '?sltdMesId=' + obj[0]);
              } else {
                location.url((scope.redirectIngUrl || '').split('/')[3]);
              }
            });
          } else {
            scope.compose_message.$setPristine();
            if ((scope.redirectIngUrl || '').split('/').length !== 4) {
              location.url('message-center/mailbox/' + ((scope.redirectIngUrl || '').split('/')[5] || scope.returnFolderID) + '?sltdMesId=' + obj[0]);
            } else {
              location.url((scope.redirectIngUrl || '').split('/')[3]);
            }
          }
        };

        /**/
        scope.fileUpload = function () {
          if (scope.compose.Attachments.length < 5) {
            angular.element('.upload-file').click();
          }
        };

        /**/
        scope.showDialog = function (type) {
          scope.initSearch(null, type);
          angular.element('.recipientSearch').show();
        };

        /**/
        scope.removeRecipient = function () {
          scope.compose.recipient = undefined;
          scope.compose.rePatient = undefined;
          scope.showReceipent = true;
          scope.showRePatient = true;
        };
        scope.removeRePatient = function () {
          scope.showRePatient = true;
          scope.compose.rePatient = undefined;
        };
        scope.removeFile = function (file) {
          /*return the new array and remove the selected file*/
          scope.compose.Attachments = _.remove(scope.compose.Attachments, function (data) {
            return data.Id !== file.Id;
          });

        };

        messageSvc.getFileTypes().then(function (response) {
          scope.uploadFileRestrict = response;
        });

        messageSvc.getDynamicText('MessageCenterInvalidAttachmentFile').then(function (response) {
          scope.MessageCenterInvalidAttachmentFile = response;
        });

        /**/
        scope.onFileSelect = function ($files, index) {
          alertService.clear();
          // $files: an array of files selected, each file has name, size, and type.
          for (var i = 0; i < $files.length; i += 1) {
            var file = $files[i];

            var fileExention = file.name.split('.');
            if (file.size > scope.uploadFileRestrict.MaxSize || scope.uploadFileRestrict.FileTypes.indexOf('.' + fileExention[(fileExention.length - 1)]) === -1) {
              var ext = '', count = 0;
              /* jshint ignore:start */
              scope.uploadFileRestrict.FileTypes.forEach(function (data) {
                count += 1;
                var lastExt = ((scope.uploadFileRestrict.FileTypes.length) === count) ? '.' : ',';
                ext = ext + ' ' + data + ' ' + lastExt;
              });
              /* jshint ignore:end */
              scope.errorMessageCustom = scope.MessageCenterInvalidAttachmentFile || 'Your attachment cannot be added to the message because it is invalid. The file must be less than ' + scope.uploadFileRestrict.MaxSize + ' KBs and have an extension of ' + ext;
              scope.errorMessageCustom = scope.errorMessageCustom.replace(/\$\$FileSize\$\$/g, Math.floor(scope.uploadFileRestrict.MaxSize / 1024)).replace(/\$\$FileExtensions\$\$/g, ext);
              alertService.add('danger', scope.errorMessageCustom, 0, '', 'alert_compose-message');
              return;
            }

            var fileReader = new FileReader();
            fileReader.readAsArrayBuffer(file);
            /* jshint ignore:start */
            fileReader.onload = function (e) {
              var type = (file.type === '') ? 'application/octet-stream' : file.type;
              var obj = {
                'FileBase64': _arrayBufferToBase64(e.target.result),
                'Details': {
                  'Name': file.name,
                  'Type': type
                }
              };
              $upload.http({
                url: app.api.root + 'empower/message-center/mailboxes/inbox/messages/0/attachments',
                // headers: {'Content-Type': file.type},
                data: obj
              }).then(function (response) {
                var res = { 'Name': file.name, 'Type': type, 'Id': response.data.results.AttachmentId };
                scope.compose.Attachments.push(res);
              }, null, function (evt) {
                // scope.progress[index] = parseInt(100.0 * evt.loaded / evt.total);
              });
            };
          /* jshint ignore:end */
          }
        };

        /* returns trusted html*/
        scope.toTrusted = function (htmlCode) {
          return sce.trustAsHtml(htmlCode);
        };

        scope.$on('$locationChangeStart', function (event, newUrl, oldUrl) {
          if (scope.compose_message.$dirty === true) {
            scope.discard(event, newUrl);

          }
        });

      }]);

  function _arrayBufferToBase64 (buffer) {
    var binary = '';
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i += 1) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

}(window.app));
