(function (app) {
  'use strict';

  app.factory('Msgctr.Utility',
    [function (http, q, session, medseekApi) {
      return {
        sortArray: function (collection, field, direction, fieldType) {
          field = field.split('.').length > 1 ? field.split('.') : field;
          if (!collection) { return; }
          collection.sort(function (a, b) {
            if (direction === 'asc') {
              // for numbers
              if (fieldType === 'n') { return a[field] > b[field] ? 1 : -1; }
              // for date
              if (fieldType === 'd') { return (a[field] ? Date.parse(a[field]) : new Date()) > (b[field] ? Date.parse(b[field]) : new Date()) ? 1 : -1; }
              // for string
              if (fieldType === 's') {
                if (angular.isArray(field) && field.length === 2) { return a[field[0]][field[1]].toUpperCase() > b[field[0]][field[1]].toUpperCase() ? 1 : -1; }
                return a[field].toUpperCase() > b[field].toUpperCase() ? 1 : -1;
              }
            } else {
              if (fieldType === 'n') { return a[field] > b[field] ? -1 : 1; }
              if (fieldType === 'd') { return (a[field] ? Date.parse(a[field]) : new Date()) > (b[field] ? Date.parse(b[field]) : new Date()) ? -1 : 1; }
              if (fieldType === 's') {
                if (angular.isArray(field) && field.length === 2) { return a[field[0]][field[1]].toUpperCase() > b[field[0]][field[1]].toUpperCase() ? -1 : 1; }
                return a[field].toUpperCase() > b[field].toUpperCase() ? -1 : 1;
              }
            }
          });
          return collection;
        },
        getByteArrayFromBase64: function (base64) {
          var byteCharacters = atob(base64);
          var byteNumbers = new Array(byteCharacters.length);
          for (var i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
          }
          // var byteArray = new Uint8Array(byteNumbers);
          return byteNumbers;
        }
      };
    }]);

}(window.app));
