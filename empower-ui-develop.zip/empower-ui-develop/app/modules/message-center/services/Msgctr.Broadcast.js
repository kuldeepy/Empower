(function (app) {
  'use strict';

  app.factory('Msgctr.Broadcast',
    ['$http', '$q', 'session', 'medseekApi',
      function (http, q, session, medseekApi) {
        function getIds (checkedItems) {
          var a = [];
          _.forEach(checkedItems, function (value, key) {
            if (value) { a.push(key); }
          });
          return a;
        }
        function construct (data) {
          return {
            'template': {
              'Name': data.name,
              'Description': (data.description) ? data.description : '',
              'Subject': (data.subject) ? data.subject : '',
              'Body': (data.message) ? data.message : '',
              'IsEnabled': true,
              'LastUpdated': new Date(),
              'CategoryId': (data.category) ? data.category.UniqueId : '',
              'CategoryName': (data.category) ? data.category.Name : '',
              'Attachments': data.Attachments
            }
          };
        }

        function constructEditTemplateData (data, id) {
          return {
            'template': {
              'UniqueId': id,
              'Name': data.name,
              'Description': (data.description) ? data.description : '',
              'Subject': (data.subject) ? data.subject : '',
              'Body': (data.message) ? data.message : '',
              'IsEnabled': true,
              'LastUpdated': new Date(),
              'CategoryId': (data.category) ? data.category.UniqueId : '',
              'CategoryName': (data.category) ? data.category.Name : '',
              'Attachments': data.Attachments
            }
          };
        }
        return {
          /* method for get ids */
          getIds: function (checkedItems) {
            var a = [];
            _.forEach(checkedItems, function (value, key) {
              if (value) { a.push(key); }
            });
            return a;
          },

          /* convert array to base 64 */
          getArrayToBase64: function arrayBufferToBase64 (buffer) {
            var binary = '';
            var bytes = new Uint8Array(buffer);
            var len = bytes.byteLength;
            for (var i = 0; i < len; i++) {
              binary += String.fromCharCode(bytes[i]);
            }
            return window.btoa(binary);
          },

          // get import-list
          getImportList: function (obj) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getImportList.get(null, obj).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // upload new import list
          uploadImportList: function (newImportList) {
            var obj = {
              'sourceIdentifier': newImportList.sourceIdentifier || '',
              'fileName': newImportList.name,
              'description': newImportList.description || '',
              'binaryContent': newImportList.attachment
            };
            var deferred = q.defer();
            medseekApi.broadcastmessaging.uploadImportList.save(null, obj).$promise.then(function (response) {
              deferred.resolve(response.results);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // get categories
          getCategories: function () {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getCategories.get().$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // get source identifiers
          getSourceIdentifiers: function () {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getSourceIdentifiers.get().$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // get templates
          getTemplates: function (condition) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getTemplates.get({ sortField: condition.sortField, sortAscending: condition.sortAscending, limit: condition.pageSize, offset: condition.pageNumber }, null).$promise.then(function (response) {
              deferred.resolve(response.results);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          /* method for delete template */
          deleteTemplate: function (checkedList) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.deleteTemplates.update({}, { 'ids': getIds(checkedList) }).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // save template
          saveTemplate: function (d) {
            var deferred = q.defer();
            var data = construct(d);
            http({
              method: 'POST',
              url: app.api.root + 'empower/broadcast-messaging/templates',
              headers: {
                'Content-Type': 'application/json;charset=utf-8'
              },
              data: data
            }).success(function (response) {
              deferred.resolve(response.results);
            }).error(function (response) {
              deferred.reject();
            });
            return deferred.promise;
          },

          // save edited template
          updateTemplate: function (d, templateId) {
            var deferred = q.defer();
            var data = constructEditTemplateData(d, templateId);
            medseekApi.broadcastmessaging.updateTemplate.update({ id: parseInt(templateId) }, data).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // get sent message by id
          getSentMessageById: function (obj) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getSentMessageById.get({ 'id': obj.id, 'includeRecipients': obj.includeRecipients, 'includeAttachments': obj.includeAttachments }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // get sent messages
          getSentMessages: function (condition) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getSentMessages.get({ sortField: condition.sortField, sortAscending: condition.sortAscending, limit: condition.pageSize, offset: condition.pageNumber }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // get draft messages
          getDraftMessages: function (condition) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getDraftMessages.get({ sortField: condition.sortField, sortAscending: condition.sortAscending, limit: condition.pageSize, offset: condition.pageNumber }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          /* method fot get broadcast content */
          getBroadcastContentSenders: function (categoryId) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getSenders.get({ id: categoryId || '' }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          /* method fot get broadcast content */
          getBroadcastContentCategories: function (categoryId) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getCategories.get({ Id: categoryId || '' }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          /* method fot get broadcast content */
          getBroadcastContentTemplates: function (categoryId) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getTemplates.get({ sortField: 'DateSent', sortAscending: false, limit: null, offset: null }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          // get template by id
          getTemplateById: function (templateId) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getTemplateDetailsById.get({ 'id': templateId }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          /* save broadcast message as draft */
          saveBroadcastMessageAsDraft: function (data) {
            var deferred = q.defer();
            http({
              method: 'POST',
              url: app.api.root + 'empower/broadcast-messaging/drafts',
              headers: {
                'Content-Type': 'application/json;charset=utf-8'
              },
              data: data
            }).success(function (response) {
              deferred.resolve(response.results);
            }).error(function (response) {
              deferred.reject();
            });
            return deferred.promise;
          },

          /* send broadcast message */
          sendBroadcastMessage: function (data) {
            var deferred = q.defer();
            http({
              method: 'POST',
              url: app.api.root + 'empower/broadcast-messaging/messages',
              headers: {
                'Content-Type': 'application/json;charset=utf-8'
              },
              data: data
            }).success(function (response) {
              deferred.resolve(response.results);
            }).error(function (response) {
              deferred.reject();
            });
            return deferred.promise;
          },

          /* method for delete message by id */
          deleteMessageById: function (messageId) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.deleteBroadcastMessage.update({'id': messageId}, { 'messageId': messageId }).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          /*get broadcast message import details*/
          getBroadCastMessageImortDetails: function (data) {
            var id = data;
            var deferred = q.defer();
            http({
              method: 'GET',
              url: app.api.root + 'empower/broadcast-messaging/imported-lists/' + id,
              headers: {
                'Content-Type': 'application/json;charset=utf-8'
              },

            }).success(function (response) {
              deferred.resolve(response.results);
            }).error(function (response) {
              deferred.reject();
            });
            return deferred.promise;
          },

          deleteImportList: function (checkedList) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.deleteImportList.update({}, { 'Ids': getIds(checkedList) }).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          reprocessImportList: function (importId) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.reprocessImportList.save({ id: importId }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          getImportProcessed: function (importId, resultType) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getImportProcessed.get({ id: importId, resultType: resultType }).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          saveRules: function (data) {
            var deferred = q.defer();
            medseekApi.ruleEngine.saveRules.save(null, data).$promise.then(function (response) {
              deferred.resolve(response);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          updateRules: function (ruleId, data) {
            var deferred = q.defer();
            medseekApi.ruleEngine.updateRules.update({ ruleId: ruleId }, data).$promise.then(function (response) {
              deferred.resolve(response);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          getRuleEngineById: function (ruleId) {
            var deferred = q.defer();
            medseekApi.ruleEngine.getRulesById.get({ ruleId: ruleId }).$promise.then(function (response) {
              deferred.resolve(response);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          getTargetGroups: function (target) {
            var deferred = q.defer();
            var promise1 = medseekApi.targetGroups.getTargetGroups.get(target).$promise;
            var promise2 = medseekApi.message.getTargetGroups.get(target).$promise;

            q.all([promise1, promise2])
              .then(function (response) {
                var groups = response[0].results.Retval;
                var processedGroups = response[1].results.Retval;

                groups.forEach(function (group) {
                  var processedGroup = _.find(processedGroups, { 'TargetId': group.Id });
                  group['GroupId'] = (processedGroup) ? processedGroup.Id : null;
                  group['ProcessedStartDate'] = (processedGroup && processedGroup.Status === 'Complete') ? processedGroup.StartDate : null;
                  group['ProcessedEndDate'] = (processedGroup && processedGroup.Status === 'Complete') ? processedGroup.EndDate : null;
                  group['ProcessedStatus'] = (processedGroup) ? processedGroup.Status : 'NotProcessed';
                });
                deferred.resolve(groups);
              }, function (error) {
                deferred.reject(error);
              });
            return deferred.promise;
          },
          getTargetGroupsCount: function (target) {
            var deferred = q.defer();
            medseekApi.targetGroups.getTargetGroupsCount.get(target).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          getTargetGroupResults: function (targetId) {
            var deferred = q.defer();
            medseekApi.message.getTargetGroupResults.get({ targetGroupId: targetId }, {}).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          getTargetGroupProcessed: function (targetId) {
            var deferred = q.defer();
            medseekApi.message.getTargetGroupResults.get({ targetGroupId: targetId }, {}).$promise.then(function (response) {
              var recipients = {};
              if (response.results.Retval.length > 0) {
                recipients.groupId = response.results.Retval[0].GroupId;
                recipients.count = response.results.Retval.length;
                recipients.results = response.results.Retval;
                medseekApi.message.getTargetGroup.get({ groupId: recipients.groupId }, {}).$promise.then(function (response) {
                  recipients.groupName = response.results.Retval.Description;
                  deferred.resolve(recipients);
                });
              }
              else
                deferred.resolve(recipients);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          processTargetGroup: function (target) {
            var deferred = q.defer();
            medseekApi.message.processTargetGroup.save(null, target).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          reProcessTargetGroup: function (targetId) {
            var deferred = q.defer();
            medseekApi.message.reprocessTargetGroup.update({ groupId: targetId }, {}).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          saveTargetGroup: function (data) {
            var deferred = q.defer();
            medseekApi.targetGroups.saveTargetGroup.save(null, data).$promise.then(function (response) {
              deferred.resolve(response);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          updateTargetGroup: function (targetGroupId, data) {
            var deferred = q.defer();
            medseekApi.targetGroups.updateTargetGroup.update({ targetGroupId: targetGroupId }, data).$promise.then(function (response) {
              deferred.resolve(response);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          deleteTargetGroups: function (targetGroupId) {
            var deferred = q.defer();
            medseekApi.targetGroups.deleteTargetGroups.delete({ targetGroupId: targetGroupId }).$promise.then(function (response) {
              deferred.resolve(response);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          getModules: function () {
            var deferred = q.defer();
            medseekApi.getModules.get({}).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          getMessageRecipients: function (messageId) {
            var deferred = q.defer();
            medseekApi.broadcastmessaging.getMessageRecipients.get({ id: messageId }, null).$promise.then(function (response) {
              deferred.resolve(response.results.Retval);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          refreshList: function (collection, exclusions, key) {
            return _.reject(collection, function (v) {
              return _.contains(exclusions, v[key]);
            });
          }
        };
      }]);

}(window.app));
