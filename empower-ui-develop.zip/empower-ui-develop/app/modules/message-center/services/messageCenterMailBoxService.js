(function (app) {
  'use strict';

  app.factory('messageCenterMailBoxService',
    ['$http', '$timeout', '$q', 'medseekApi',
      function (http, timeout, q, medseekApi) {
        return {
          getDefaultMailboxes: function () {
            var deferred = q.defer();
            medseekApi.message_center.mailbox.get(null, null).$promise.then(function (response) {
              deferred.resolve(response.results.Mailboxes);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },

          createMailbox: function (userId, name) {
            mailboxes.push({
              name: name,
              key: name.toLowerCase()
            });
          },
          createFolder: function (folderName, parentId) {
            var deferred = q.defer();
            medseekApi.message_center.mailbox.save(null, { 'MailBoxName': folderName, 'ParentId': parentId || 0 }).$promise.then(function (response) {
              deferred.resolve(response.results);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          updateFolder: function (folderId, newName, parentId) {
            var deferred = q.defer();
            medseekApi.message_center.mailbox.mailboxId.update({mailboxId: folderId}, { 'MailBoxName': newName, 'MailboxId': folderId, 'ParentId': parentId || 0 }).$promise.then(function (response) {
              deferred.resolve(response.results);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          },
          deleteFolder: function (folderId, destinatonMailbox) {
            var deferred = q.defer();
            medseekApi.message_center.mailbox.mailboxId.delete({ mailboxId: folderId, destinationMailboxId: destinatonMailbox }).$promise.then(function (response) {
              deferred.resolve(response.results);
            }, function (error) {
              deferred.reject(error);
            });
            return deferred.promise;
          }
        };
      }]);

}(window.app));
