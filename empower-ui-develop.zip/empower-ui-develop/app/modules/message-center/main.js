(function (app) {
  'use strict';

  /* module root controller */
  app.controller('MessageCenterCtrl', ['$scope', 'session', function (scope, session) {
    /*
    checks the permission set

    */
    scope.checkPermission = function (keys) {
      var counter = 0;
      var check = false;
      var keysCount = keys.length;

      angular.forEach(JSON.parse(session.get('currentPermissionSet')), function (permission) {
        angular.forEach(keys, function (key) {
          if (key === permission) {
            check = true;
            counter++;
          }
        });
      });

      return (keysCount === counter);
    };
    // module level properties
    scope.model = {
      routeParams: {}
    };
    scope.isStaffUser = session.get('portal').toUpperCase() === 'STAFF' ? true : false;

    // rich text editor options
    scope.editorOptions = {
      menubar: false,
      resize: false,
      height: 400,
      plugins: 'emoticons textcolor',
      toolbar: 'bold italic underline strikethrough styleselect bullist numlist undo redo emoticons forecolor',
      statusbar: false
    };

  }]);

})(window.app);
