(function (app) {
  'use strict';

  /* module root controller */
  app.controller('connectToNewPatientCtrl', ['$scope', function (scope) {
    /* initial method called */
    scope.init = function () {};

  }]);

})(window.app);
