(function (app) {
  'use strict';

  app.controller('announcementsCtrl', ['$scope',
    function (scope) {
      scope.contentLimit = 400;
      scope.isReadAll = true;
      scope.isCollapse = false;
      scope.setContentLimit = 400;

      scope.announcements = [
        {
          name: 'New Clinic Opens in Riverside!',
          date: '1/20/2014',
          content: 'We are  proud to announce the grand opening of new cutting edge outpatient clinic in Riverside! Experience shorter wait times, and more personalized care with Dr. Skip Gildersleeve, Dr. Bob Newhart, and their qualified staff.Located conveniently across from the ' +
            'Riverside  bussiness park,the new clinic is sure to make attending your appointments less frustrating by avoiding down town traffic and parking.For more information on the clinic please visit www.clinic.com/about or call 1-888-555-2122 to schedule a new appointment.<br/>' +
            '<img class="irc_mut" src="http://t2.gstatic.com/images?q=tbn:ANd9GcQ3l9lNYA-DOUemjL7AmDKkC2JLAsNq-3-yq-kMc4DWQPAATyNp" width="466" height="243" style="margin-top: 602px;">',
          limitTo: 400
        },
        {
          name: 'New Clinic Opens in Riverside!',
          date: '1/20/2014',
          content: 'We are proud to announce the grand opening of new cutting edge outpatient clinic in Riverside! Experience shorter wait times, and more personalized care with Dr. Skip Gildersleeve, Dr. Bob Newhart, and their qualified staff.Located conveniently across from the ' +
            'Riverside  bussiness park,the new clinic is sure to make attending your appointments less frustrating by avoiding down town traffic and parking.For more information on the clinic visit www.clinic.com/about or call 1-888-555-2122 to schedule a new appointment.' +
            '<img class="irc_mut" src="http://t2.gstatic.com/images?q=tbn:ANd9GcQ3l9lNYA-DOUemjL7AmDKkC2JLAsNq-3-yq-kMc4DWQPAATyNp" width="366" height="243" style="margin-top: 2%;margin-left: 28%;">',
          limitTo: 400
        },
        {
          name: '$79 Mammograms in February',
          date: '1/15/2014',
          content: 'For the month of February,each of our clinics will be offering $79 mammograms when accompanied by a full physical.For more information,visit www.ourclinic.com/mammogram, or  schedule an appointment online by clicking <a  href="http://www.ourclinic.com/mammogram"  target="_blank">this link<a>',
          limitTo: 400
        },
        {
          name: 'Flu Vaccinations are now available!',
          date: '11/09/2013',
          content: "For vaccines are offered in many locations,including doctor's offices,clinics,health departments,pharmacies and college health centers,as well as by many employers,and even in some schools.Even if you don't have a regular doctor or nurse,you can get a flu vaccine somewhere else,like a health department,pharmacy,urgent care clinic,and often your school,college health center,or work." +
            "For vaccines are offered in many locations,including doctor's offices,clinics,health departments,pharmacies and college health centers,as well as by many employers,and even in some schools.Even if you don't have a regular doctor or nurse,you can get a flu vaccine somewhere else,like a health department,pharmacy,urgent care clinic,and often your school,college health center,or work.",
          limitTo: 400
        },
      ];

      scope.readAll = function (announcementContent) {
        announcementContent.limitTo = announcementContent.content.length;
      };

      scope.collapse = function (announcementContent) {
        announcementContent.limitTo = 400;
      };

      scope.printAnnouncement = function () {
        // alert(announcementData.name, announcementData.date);
      };

      scope.saveAnnouncement = function () {
        // alert(announcementData.name, announcementData.date);
      };
    }
  ]);

}(window.app));
