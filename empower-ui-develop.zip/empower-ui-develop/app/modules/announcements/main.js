(function (app) {
  'use strict';

  /* module root controller */
  app.controller('AnnouncementModuleCtrl', ['$scope', function (scope) {
    scope.model = {
      routeParams: {}
    };

    /* variable declarations */
    scope.healthInformation = {
      getMhrUrl: '',
      isPatientAssigned: false,
      sessionFactoryPatient: 'patient',
      updateParentMethodName: 'UPDATE_PARENT',
      importedRecordsMethodName: 'ImportedRecords',
      medicalRecordUrl: 'patients/',
      queryStringMrn: '?mrn=',
      queryStringMedseekId: '?medseekId=',
      sessionPermissions: 'permissions',
      messageClinicalInformation: 'clinicalInformation',
      messagePhysicians: 'physicians',
      messagePharmacies: 'pharmacies',
      messageLocations: 'locations',
      messageDocuments: 'documents',
      currentView: [],
      testResults: [],
      patientName: '',
      welcomeMessage: '',
      error: ''
    };

    /* method for load all clinical data */
    scope.$on(scope.healthInformation.updateParentMethodName, function () {
      scope.initialize();
    });

    scope.$on('patient', function () {
      scope.initialize();
    });

  }]);

})(window.app);
