(function (app) {
  'use strict';

  app.directive('addEvisitPhysician', ['medseekApi', '$filter', 'eVisitSessionSvc', function (api, filter, sessionSvc) {
    return {
      restrict: 'E',
      templateUrl: '/modules/evisits/templates/add-physician.html',
      scope: {
        patient: '=',
        currentPhysicians: '='
      },
      controller: ['$scope', function (scope) {
        scope.showPhysicians = function () {
          if (!scope.physicians) {
            api.evisits.physicians.get({patientId: sessionSvc().currentPatientId()}).$promise.then(function (data) {
              var docs = _.filter(data.results, function (doc) {
                return !_.find(scope.currentPhysicians, { Id: doc.Id });
              });
              scope.filteredPhysicians = scope.physicians = docs;
            });
          }
        };
        scope.physicianDataOptions = {
          data: 'filteredPhysicians',
          columnDefs: [
            { width: 60, cellTemplate: '<div style="text-align:center;"><input ng-change="updateNewDoc(row.entity)" style="float:none;margin: 10px auto 0 auto;" type="radio" name="addDoc" ng-model="newDoc" ng-value="row.entity" /></div>' },
            { field: 'DoctorFullName', displayName: 'Name' },
            { field: 'ImhSpecialty', displayName: 'Type' },
            { field: 'City', displayName: 'City' },
            { field: 'State', displayName: 'State' }
          ],
          enableRowSelection: false
        };
        scope.filterDocs = function (docFilter) {
          scope.filteredPhysicians = filter('filter')(scope.physicians, docFilter);
        };
        scope.selectAndAdd = function () {
          scope.$emit('eVisitDocAdded', scope.newDoc);
          $('#eligibleEvisitPhysician').modal('toggle');
          var doc = _.findIndex(scope.physicians, scope.newDoc);
          scope.physicians.splice(doc, 1);
          scope.filteredPhysicians = scope.physicians;
          scope.newDoc = undefined;
        };
        scope.updateNewDoc = function (doc) {
          scope.newDoc = doc;
        };
      }]
    };
  }]);

}(window.app));
