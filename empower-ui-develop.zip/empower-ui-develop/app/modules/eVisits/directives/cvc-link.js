(function (app) {
  'use strict';

  app.directive('cvcLink', ['$timeout', '$compile', function (timer, compile) {
    return {
      restrict: 'E',
      templateUrl: '/modules/evisits/templates/cvc-link.html',
      scope: {
      },
      link: function (scope, element, attributes, ngModel) {
        scope.popover = function () {
          element.popover({
            content: function () { return $('#cvcPopoverContent').html(); },
            html: true,
            placement: 'top',
            title: 'CVV/CVC',
            container: 'cvc-link',
            template: '<div ng-click="hidePopover()" id="cvcPopover" class="popover cvc" role="tooltip" tabindex="-1"><div class="arrow"></div><h3 class="popover-title" ></h3><div class="popover-content"></div></div>'
          });
          var recompile = function () {
            var c = $('#cvcPopover');
            c[0].focus();
            compile(c[0])(scope);
          };
          timer(recompile, 0);
        };
        scope.hidePopover = function () {
          $('#cvcPopover').popover('hide');
        };
      }
    };
  }
  ]);

}(window.app));
