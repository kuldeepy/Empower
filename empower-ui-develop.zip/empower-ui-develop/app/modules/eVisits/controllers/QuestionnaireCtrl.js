(function (app) {
  'use strict';
  app.controller('eVisitsQuestionnaireCtrl', ['$scope', 'medseekApi', '$q', 'eVisitSessionSvc', 'eVisitErrorHandler', '$rootScope', 'alertService', 'eVisitPhysicianSvc', 'eVisitTypeService', 'eVisitQuestionnaireSvc', '$translate', function (scope, api, q, session, errorHandler, rootScope, alertSvc, doctorService, typeService, eVisitQuestionnaireSvc, translate) {
    var docSvc, focusGained, typeSvc, questionSvc, sessionMgr;
    scope.route = {
      path: '/modules/evisits/views/questionnaire.html',
      name: 'questionnaire'
    };
    questionSvc = eVisitQuestionnaireSvc(scope);
    scope.steps = [{ menu:  translate.instant('CHOOSE_PHYSICIAN')}, { menu:  translate.instant('CHOOSE_EVISIT_TYPE_STEP') }, { menu:  translate.instant('QUESTIONAIRE')}];

    scope.$watch('fc', function (newVal) {
      if (newVal) {
        if (scope.stepIndex === 2) {
          typeSvc.next(questionSvc);
        }
      }
    });
    scope.$watch('answer', function (newVal) {
      if (!scope.currentQuestion || scope.complete) {
        return;
      }
      scope.currentQuestion.setAnswer = newVal;
      if (!isNaN(parseInt(newVal))) {
        sessionMgr.setAnswer(scope.currentQuestion, newVal, scope.questionnaireIndex);
      }
      scope.fc.enableNext(newVal !== -1);
    });
    scope.$watch('stepIndex', function (newVal, oldVal) {
      if (newVal && newVal === 2 && oldVal === 1 && questionSvc) {
        questionSvc.next();
      }
    });
    scope.onFocus = function (flowControl, stepIndex) {
      if (focusGained) {
        return;
      }

      docSvc = doctorService(scope);
      typeSvc = typeService(scope, flowControl);
      sessionMgr = session(scope);
      scope.fc = flowControl;

      flowControl.enableNext(false);
      flowControl.enablePrevious(false);
      flowControl.enableCancel(true);

      docSvc.populateData().then(function () {
        scope.loaded = true;
      });
      focusGained = true;
    };
    scope.onNext = function (flowControl) {
      switch (scope.stepIndex) {
        case 0:
          return docSvc.setPhysician(flowControl);
        case 1:
          return typeSvc.next();
        case 2:
          return questionSvc.next();
      }
    };
    scope.onPrevious = function (flowControl) {
      switch (scope.stepIndex) {
        case 1:
          return typeSvc.previous();
        case 2:
          return questionSvc.back();
        default:
          flowControl.enablePrevious(scope.stepIndex - 1 !== 0);
          flowControl.enableNext(true);
          flowControl.previous();
          break;
      }

    };

    scope.$emit('requestEVisitSettings');
  }]);
})(window.app);
