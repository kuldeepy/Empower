(function (app) {
  'use strict';
  app.controller('eVisitsReviewSubmitCtrl', ['$scope', 'medseekApi', 'eVisitErrorHandler', 'eVisitSessionSvc', '$q', 'eVisitQuestionnaireSvc', '$location', '$timeout', 'dynamicText', '$translate', function (scope, api, errorHandler, sessionSvc, q, questionSvcFunc, location, timeout, dynamicText, translate) {
    var session, questionSvc, initialized;
    scope.steps = this.steps = [{ menu: translate.instant('REVIEW') }, { menu: translate.instant('SUBMIT') }, { menu: translate.instant('CONFIRMATION') }];
    scope.route = {
      path: '/modules/evisits/views/review.html',
      name: 'review'
    };

    scope.$watch('questionnaireIndex', function (newVal, oldVal) {
      if (typeof newVal === 'number' && newVal !== oldVal) {
        var evisit = session.get();
        evisit.index = newVal;
        session.set(evisit);
      }
    });

    scope.$watch(function () { if (!scope.summary) return undefined; return scope.summary.phone; }, function (newVal, oldVal) {
      if (scope.fc)
        scope.fc.enableNext(scope.summary.phone !== undefined);
    });

    scope.onFocus = function (flowControl, stepIndex) {
      if (!initialized) {
        initialized = true;
        questionSvc = questionSvc || questionSvcFunc();
        flowControl.enableNext(true);
        session = sessionSvc(scope);
        scope.questions = session.getQuestions();
        scope.fc = flowControl;
        flowControl.enableNext(true);
        flowControl.showPrevious(scope.stepIndex === 1);
        flowControl.enableCancel(true);
        var topTextPromise = dynamicText.getDynamicText('evisits', 'eVisitReviewPanelTop');
        var summaryPromise = dynamicText.getDynamicText('evisits', 'eVisitPreSubmissionTop');
        var confirmationPromise = dynamicText.getDynamicText('evisits', 'eVisitConfirmation');

        topTextPromise.then(function (data) {
          scope.topText = data.replace(/\r\n/g, '');
        }, errorHandler);

        summaryPromise.then(function (data) {
          scope.summaryText = data.replace(/\r\n/g, '');
        }, errorHandler);

        confirmationPromise.then(function (data) {
          scope.confirmationText = data.replace(/\r\n/g, '');
        }, errorHandler);

        q.all([topTextPromise, summaryPromise]).then(function () {
          scope.loaded = true;
        });
        scope.summary = session.getSummary();
        scope.summary.phone = null;
        if (stepIndex === 2) {
          flowControl.showCancel(false);
          flowControl.showNext(false);
          flowControl.wizardComplete();
        }
      } else {
        scope.questions = session.getQuestions();
      }
    };

    scope.goToQuestion = function (index) {
      questionSvc.goToIndex(index);
      scope.fc.setIndex(scope.currentIndex - 1, 2);
    };
    var submitEncounter = function () {
      var questions = _.map(session.getQuestions(), function (question) {
        return { Text: question.label, Answer: question.field.listItems[question.setAnswer]};
      });
      return api.evisits.current.update({ patientId: session.currentPatientId(), id: session.get() ? session.get().id : '' }, {
        questions: questions,
        cardinfo: scope.summary['payment-summary'],
        comments: scope.summary.comments,
        contactPhone: scope.summary.phone
      }).$promise;
    };

    scope.onNext = function (flowControl) {
      switch (scope.stepIndex) {
        case 0:
          session.setSummary('phone', scope.summary.phone);
          session.setSummary('comments', scope.summary.comments);
          flowControl.showPrevious(true);
          flowControl.enablePrevious(true);
          flowControl.showNext(true);
          flowControl.next();
          break;
        case 1:
          submitEncounter().then(function () {
            flowControl.next();
            flowControl.showCancel(false);
            flowControl.showPrevious(false);
            flowControl.showNext(false);
            flowControl.wizardComplete();
            session.destroy();
          }, errorHandler);
          break;
      }
    };
    scope.onPrevious = function (flowControl) {
      switch (scope.stepIndex) {
        case 1:
          flowControl.showPrevious(false);
          flowControl.showNext(true);
          flowControl.previous();
          break;
        case 0:
          break;
      }
    };
    scope.newEvisit = function () {
      scope.$emit('evisit-complete');
      location.path('/evisits/new');
      session.destroy();
      timeout(app.softRefresh, 10);
      timeout(function () { location.path('/evisits'); }, 20);
    };
    scope.goHome = function () {
      session.destroy();
      location.path('/');
    };
  }]);
})(window.app);
