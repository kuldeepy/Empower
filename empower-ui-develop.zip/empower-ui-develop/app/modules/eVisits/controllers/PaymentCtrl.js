(function (app) {
  'use strict';

  app.controller('eVisitsPaymentCtrl', ['$scope', 'medseekApi', '$location', 'eVisitPaymentService', 'alertService', 'trustCommerceResponses', 'trustCommercePaymentForm', 'eVisitErrorHandler', '$q', 'eVisitSessionSvc', 'dynamicText', '$translate', function (scope, api, location, paymentSvc, alertService, responses, formEntity, errorHandler, q, sessionMgr, dynamicText, translate) {
    var self = this;
    scope.steps = this.steps = [{ menu: translate.instant('COPAY_DISCLAIMER_STEP') }, { menu: translate.instant('ENTER_PAYMENT_INFO_STEP') }];
    scope.formEntity = formEntity;
    scope.formEntity.name=translate.instant(scope.formEntity.name);
    scope.formEntity.fields  = _.filter(formEntity.fields, function (forms) {
      var translatedFieldName = '';
      switch (forms.name) {
        case 'NameOnCard':
          translatedFieldName = translate.instant('NAME_ON_CARD');
          break;
        case 'Country':
          translatedFieldName = translate.instant('COUNTRY');
          break;
        case 'PostalCode':
          translatedFieldName = translate.instant('ZIP_CODE');
          break;
        case 'CardNumber':
          translatedFieldName = translate.instant('CARD_NUMBER');
          break;
        case 'ExpirationMonth':
          translatedFieldName = translate.instant('EXPIRATION_MONTH');
          break;
        case 'ExpirationYear':
          translatedFieldName = translate.instant('EXPIRATION_YEAR');
          break;
        case 'CVVCVCCode':
          translatedFieldName = translate.instant('CVV_CVC_DISCLAIMER ');
          translatedFieldName = translatedFieldName + ' {{CvcLink}}';
          break;
      }
      return forms.label = translatedFieldName;
    });
    scope.formData = {};
    scope.route = {
      path: '/modules/evisits/views/payment.html',
      name: 'payment'
    };

    scope.$on('eVisitSettings', function (sender, settings) {
      if (!scope.fc) {
        return;
      }
      scope.fc.showPrevious(settings.showTerms);
    });

    var initializePaymentSettings = function () {
      var deferred = q.defer();
      var eVisit = sessionMgr().get();
      api.evisits.paymentSettings.get({ patientId: sessionMgr().currentPatientId(), id: eVisit.id, processUrl: scope.returnUrl }).$promise.then(function (settings) {
        scope.paymentSettings = settings.results;
        scope.paymentSettings.amount = parseFloat(settings.results.amount).toFixed(2);
        deferred.resolve();
      }, errorHandler);
      return deferred.promise;
    };

    scope.errorMessage = '';

    

    scope.onFocus = function (flowControl, idx) {
      if (idx) {
        paymentSvc.replaceCvc(scope);
      }
      scope.fc = flowControl;
      if (!scope.initialized) {
        dynamicText.getDynamicText('evisits', 'eVisitCopayInformation').then(function (data) {
          scope.copayDisclaimer = data.replace(/\r\n/g, '');
          flowControl.enableNext(!scope.stepIndex);
          flowControl.enablePrevious(true);
        });
      }
      scope.initialized = true;
      scope.$emit('requestEVisitSettings');
      initializePaymentSettings();
    };

    scope.returnUrl = location.$$absUrl.split('?')[0].replace(location.$$path, '/themes/default/images/human.png');

    this.processPaymentResponse = function (response) {
      response.Status = response.StatusSummary.offenders === 'cc' ? 'Decline' : response.Status;
      var status = responses[response.Status];
      var message = translate.instant(status.message);
      scope.errorMessage = message.replace('$$$$', '$' + scope.paymentSettings.amount);

      if (response.Status === 'Approved') {
        scope.fc.tabComplete();
        return;
      }
      scope.paymentSettings.token = response.StatusSummary.newtoken;
      scope.fc.enableNext(true);
      scope.fc.enablePrevious(true);
      scope.fc.enableCancel(true);
    };

    scope.onNext = function (flowControl) {
      switch (scope.stepIndex) {
        case 0:
          scope.formData.ExpirationMonth = scope.formData.ExpirationMonth ? scope.formData.ExpirationMonth.id : '';
          scope.formData.ExpirationYear = scope.formData.ExpirationYear ? scope.formData.ExpirationYear.id : '';
          scope.formData.Country = scope.formData.Country ? scope.formData.Country.id : undefined;
          scope.stepIndex++;
          flowControl.next();
          paymentSvc.replaceCvc(scope);
          break;
        case 1:
          flowControl.enableNext(false);
          flowControl.enablePrevious(false);
          flowControl.enableCancel(false);
          paymentSvc.process(scope).then(function (data) {
            self.processPaymentResponse(data);
            flowControl.enableNext(true);
            flowControl.enablePrevious(true);
            flowControl.enableCancel(true);
          });
          break;
      }
    };

    scope.onPrevious = function (flowControl) {
      if (scope.stepIndex === 1) {
        flowControl.previous();
      } else {
        flowControl.previousTab();
      }
    };

    function validateField(name, condition) {
      var field = _.find(scope.formEntity.fields, { name: name });
      field.state().$setValidity('ExpirationPart', condition);
    }

    var updateExp = function () {
      if (!scope.formState || !scope.formData.ExpirationMonth || !scope.formData.ExpirationYear) {
        return;
      }
      scope.formState.$setValidity('exp', validateExpirationDate());
      validateField('ExpirationMonth', scope.formData.ExpirationMonth.id, translate.instant('EVISIT_ENTER_EXPIRATION_MONTH_MSG'));
      validateField('ExpirationYear', scope.formData.ExpirationYear.id, translate.instant('EVISIT_ENTER_EXPIRATION_YEAR_MSG'));
      scope.exp = scope.formData.ExpirationMonth.id + '' + scope.formData.ExpirationYear.id;
    };

    var validateExpirationDate = function () {
      scope.errorMessage = '';
      var month = (scope.formData.ExpirationMonth) ? parseInt(scope.formData.ExpirationMonth.id, 10) : 0;
      var year = (scope.formData.ExpirationYear !== undefined) ? parseInt(scope.formData.ExpirationYear.id, 10) : 0;
      if (month && year) {
        var date = new Date();
        var yr = date.getFullYear();
        var mnth = date.getMonth();
        if (new Date(yr, mnth) > new Date(2000 + year, month - 1)) {
          scope.errorMessage = translate.instant('EVISIT_ENTER_EXPIRATION_MONTH_AND_YEAR_MSG');
          return false;
        }
        return true;
      }
    };
    scope.$watch('formData.ExpirationMonth', updateExp);
    scope.$watch('formData.ExpirationYear', updateExp);
    scope.$watch('formState.$valid', function (newVal) {
      if (scope.fc) {
        scope.fc.enableNext(newVal);
      }
    });

  }]);
})(window.app);
