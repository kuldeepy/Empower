(function (app) {
  'use strict';

  /* module root controller */
  app.controller('eVisitsMainCtrl', ['$scope', 'medseekApi', '$location', '$dialogFactory', 'eVisitErrorHandler', 'session', 'eVisitSessionSvc', '$timeout','$translate', function (scope, api, location, dialog, errorHandler, session, eVisitSession, timeout, translate) {
    scope.model = {
      routeParams: {}
    };
    var sessionMgr = eVisitSession(scope);
    var getSettings = function () {
      api.evisits.settings.get({patientId: sessionMgr.currentPatientId(), id: sessionMgr.get().id }, function (data) {
        scope.settings = data.results;
        var evisit = sessionMgr.get();
        if (evisit && evisit.mainIndex) {
          scope.currentIndex = evisit.mainIndex;
          scope.stepIndex = evisit.stepIndex;
        } else {
          scope.currentIndex = (scope.settings.showTerms && scope.settings.hasCheckedTerms) ? 1 : 0;
        }

        scope.loaded = true;
      }, errorHandler);
    };

    var evisit = sessionMgr.get();
    if (!evisit || (evisit && !evisit.id)) {
      api.evisits.create.save({patientId: sessionMgr.currentPatientId()}, {}).$promise.then(function (data) {
        evisit = evisit || {};
        evisit.id = data.results;
        sessionMgr.set(evisit);
        getSettings();
      });
    } else {
      getSettings();
    }

    var patient = JSON.parse(session.get('patient'));
    if (patient && !patient.DOB) {
      location.path('/evisits/no-date-of-birth');
    }
    this.broadCastSettings = function () {
      scope.$broadcast('eVisitSettings', scope.settings);
    };

    this.onControlsAdded = _.once(function (sender, control) {
      var setIdx = function () {
        control.setIndex(scope.currentIndex, scope.stepIndex || 0);
      };
      timeout(setIdx, 0);
    });

    var cancel = this.cancel = function () {
      var evisitId = sessionMgr.get().id;
      var patientId = sessionMgr.currentPatientId();
      sessionMgr.destroy();
      api.evisits.current.delete({patientId: patientId, id: evisitId }, function () {
        location.path('/');
      }, errorHandler);
    };

    this.onCancel = function () {
      var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('EVISITS_CONFIRM_CANCEL_DIALOG_MSG'));
      if (dialogCallback) {
        dialogCallback.result.then(cancel);
      }
    };
  
    this.onComplete = function () {
      scope.$destroy();
    };

    scope.$on('msStepFlowControlsAdded', this.onControlsAdded);
    scope.$on('requestEVisitSettings', this.broadCastSettings);
    scope.$on('stepFlowOnCancel', this.onCancel);
    scope.$on('evisit-complete', this.onComplete);

  }]);

})(window.app);
