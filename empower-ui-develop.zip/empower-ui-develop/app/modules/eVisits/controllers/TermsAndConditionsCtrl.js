(function (app) {
  'use strict';
  app.controller('eVisitsTermsAndConditionsCtrl', ['$scope', 'medseekApi', 'eVisitErrorHandler', 'session', 'eVisitSessionSvc', 'dynamicText', '$translate', function (scope, api, errorHandler, session, evisitSession, dt, translate) {
    scope.steps = this.steps = [{ menu: 'ACCEPT_TERMS_STEP'}];
    scope.hasCheckedTerms = '';
    scope.route = {
      path: '/modules/evisits/views/terms-and-conditions.html',
      name: 'terms'
    };
    dt.getDynamicText('evisits', 'termsandconditions').then(function (dt) {
      scope.terms = (dt || '').replace(/\r\n/g, '');
    });
    scope.$on('eVisitSettings', function (sender, settings) {
      scope.agree = scope.hasCheckedTerms = settings.hasCheckedTerms;
    });

    scope.$watch('agree', function (newVal, oldVal) {
      if (!scope.fc) {
        return;
      }
      scope.fc.enableNext(newVal);
    });

    scope.onFocus = function (flowControl) {
      scope.fc = flowControl;
      flowControl.enableNext(scope.agree);
      flowControl.showPrevious(false);
      flowControl.enableCancel(true);
    };

    scope.onNext = function (flowControl) {
      flowControl.next();
      if (scope.hasCheckedTerms) {
        flowControl.tabComplete();
      } else {
        api.evisits.userSettings.update({patientId: evisitSession().currentPatientId(), userId: session.get('userId') }, { termsAccepted: true }).$promise.then(function () {
          flowControl.tabComplete();
        }, errorHandler);
      }
    };
    scope.$emit('requestEVisitSettings');
  }]);
})(window.app);
