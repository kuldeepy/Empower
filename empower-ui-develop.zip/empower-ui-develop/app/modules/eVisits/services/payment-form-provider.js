(function (app) {
  'use strict';
  var form = {
    'name': 'ENTER_PAYMENT_INFO_STEP',
    'fields': [
      {
        'name': 'NameOnCard',
        'label': 'Name on Card',
        'type': 'TextBox',
        'visible': true,
        'layout': {
          'row': 0,
          'column': 0
        },
        'filters': {
          'Required': true,
          'MaxLength': 50
        },
        'listItems': {

        },
        'model': 'payment.formData.NameOnCard',
        'id': 'payment_formData_NameOnCard',
        'tag': 'input'
      },
      {
        'name': 'Country',
        'label': 'Country',
        'type': 'DropDown',
        'visible': true,
        'layout': {
          'row': 1,
          'column': 0
        },
        'filters': {
          'Required': true,
          'BlankItem': true
        },
        'listItems': [{ id: '102', name: 'United States'}, { id: '103', name: 'Canada'}],
        'model': 'payment.formData.Country',
        'id': 'payment_formData_Country',
        'tag': 'input'
      },
      {
        'name': 'PostalCode',
        'label': 'Zip/Postal Code',
        'type': 'ZipTextBox',
        'visible': true,
        'layout': {
          'row': 1,
          'column': 1
        },
        'filters': {
          'Required': true
        },
        'listItems': {

        },
        'model': 'payment.formData.PostalCode',
        'id': 'payment_formData_PostalCode',
        'tag': 'input'
      },
      {
        'name': 'CardNumber',
        'label': 'Card Number',
        'type': 'CreditCardTextBox',
        'visible': true,
        'layout': {
          'row': 2,
          'column': 0
        },
        'filters': {
          'TextAllowDigits': '',
          'CreditCard': 'true',
          'Required': true,
          'MaxLength': 16
        },
        'listItems': {

        },
        'model': 'payment.formData.CardNumber',
        'id': 'payment_formData_CardNumber',
        'tag': 'input'
      },
      {
        'name': 'ExpirationMonth',
        'label': 'Expiration Month',
        'type': 'DropDown',
        'visible': true,
        'layout': {
          'row': 3,
          'column': 0
        },
        'filters': {
          'Required': true,
          'BlankItem': true
        },
        'listItems': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'].map(function (m) { return { id: m, name: m };}),
        'model': 'payment.formData.ExpirationMonth',
        'id': 'payment_formData_Expiration Month',
        'tag': 'input'
      },
      {
        'name': 'ExpirationYear',
        'label': 'Expiration Year',
        'type': 'DropDown',
        'visible': true,
        'layout': {
          'row': 3,
          'column': 1
        },
        'filters': {
          'Required': true,
          'BlankItem': true
        },
        'listItems': [],
        'model': 'payment.formData.ExpirationYear',
        'id': 'payment_formData_ExpirationYear',
        'tag': 'input'
      },
      {
        'name': 'CVVCVCCode',
        'label': 'CVV\/CVC Code {{CvcLink}}',
        'type': 'TextBox',
        'visible': true,
        'layout': {
          'row': 4,
          'column': 0
        },
        'filters': {
          'MaxLength': '4',
          'TextAllowDigits': '',
          'Required': true
        },
        'listItems': {

        },
        'model': 'payment.formData.CVCCode',
        'id': 'payment_formData_CVCCode',
        'tag': 'input'
      }
    ]
  };
  var year = new Date().getFullYear();
  var listItems = [];
  for (var i = 0; i < 10; i++) {
    var yr = year + i;
    listItems.push({ id: yr.toString().substr(2),  name: yr, value: yr });
  }
  form.fields[5].listItems = listItems;
  app.value('trustCommercePaymentForm', form);
})(window.app);
