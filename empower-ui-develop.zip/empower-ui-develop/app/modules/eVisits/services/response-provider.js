(function (app) {
  'use strict';

  app.value('trustCommerceResponses', {
    Error: {
      message: 'EVISIT_REVIEW_PAYMENT_INFORMATION',
      status: 'danger'
    },
    Approved: {
      message: 'EVISIT_CARD_PREAUTHORIZATION_CONFIRMATION',
      status: 'success'
    },
    Accepted: {
      message: 'EVISIT_CARD_PREAUTHORIZATION_CONFIRMATION',
      status: 'success',
    },
    Decline: {
      message: 'EVISIT_REVIEW_PAYMENT_INFORMATION',
      status: 'danger'
    },
    BadData: {
      message: 'EVISIT_PAYMENT_GATEWAY_CONFIG_PROBLEM',
      status: 'danger'
    }
  });
})(window.app);
