(function (app) {
  'use strict';
  app.factory('eVisitPaymentService', ['$document', '$q', 'medseekApi', '$timeout', '$compile', 'eVisitSessionSvc', function (doc, q, api, timer, compile, sessionSvc) {
    return {
      process: function (scope) {
        var deferred = q.defer();
        var iframe = $('<iframe />');
        iframe.attr('id', scope.paymentSettings.token);
        iframe[0].name = scope.paymentSettings.token;
        var formdata = $('#paymentpost').clone();
        var form = $('<form />');
        form.append(formdata);
        form[0].method = 'POST';
        form[0].target = scope.paymentSettings.token;
        form[0].action = scope.paymentSettings.paymentUrl;
        iframe.append(form);
        iframe.css('display', 'none');
        $('body').append(iframe);

        form.submit();
        iframe.on('load', function () {
          var parser = doc[0].createElement('a');
          parser.href = doc[0].getElementById(scope.paymentSettings.token).contentWindow.location.href;
          var qs = parser.search.substr(1);
          qs = qs.replace(/:/g, '%3A').replace(/%2B/g, '+');
          api.evisits.validatePayment.get({ paymentResponse: btoa(qs), token: scope.paymentSettings.token, id: sessionSvc().get().id, patientId: sessionSvc().currentPatientId() }).$promise.then(function (response) {
            var summary = response.results.CardSummary;
            sessionSvc().setSummary('payment-summary', {
              amount: summary.amount,
              zip: summary.zip,
              cc: summary.cc,
              exp: summary.exp,
              name: summary.name.replace(/\+/, ' ')
            });
            deferred.resolve(response.results);
          });
          iframe.remove();
        });
        return deferred.promise;
      },
      replaceCvc: function (scope) {
        var replace = function replace () {
          var label = $('label:contains("{{CvcLink}}")');
          if (!label.length) {
            timer(replace, 0);
            return;
          }
          label.html(label.text().replace('{{CvcLink}}', '<cvc-link></cvc-link>'));
          compile(label.contents())(scope);
        };
        timer(replace, 0);
      }
    };
  }]);
})(window.app);
