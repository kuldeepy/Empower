(function (app) {
  'use strict';
  app.factory('eVisitQuestionnaireSvc', ['medseekApi', 'eVisitErrorHandler', 'eVisitSessionSvc', 'dynamicText', function (api, errorHandler, eVisitSessionSvc, dynamicText) {
    var scope, sessionMgr;
    return function (scp) {
      sessionMgr = eVisitSessionSvc();
      if (scp) {
        scope = scp;
        scope.questions = [];
      }

      var loadNextQuestion = function loadNextQuestion (answer, back, index) {
        var method = 'get', req = {};
        if (back) {
          method = 'update';
          req.navigation = 'Back';
          req.index = scope.questionnaireIndex - 1;
        } else if (answer) {
          method = 'update';
          req.answer = answer;
          req.id = scope.currentQuestion.id;
        } else if (typeof index === 'number') {
          method = 'update';
          req.index = index;
          req.navigation = 'back';
        }
        scope.loading = true;
        api.evisits.currentQuestion[method]({patientId: sessionMgr.currentPatientId(), id: sessionMgr.get().id, index: scope.questionnaireIndex || 0 }, req).$promise.then(
          function (data) {
            scope.currentQuestion = {
              field: transformQuestion(data.results.question, data.results.question.Text),
              label: data.results.question.Text,
              id: data.results.id,
              answer: undefined
            };
            scope.answer = data.results.currentAnswer;
            scope.complete = data.results.complete;
            if (scope.complete) {
              scope.fc.tabComplete();
            }
            scope.questionnaireIndex = data.results.index;
            scope.fc.enablePrevious(typeof (data.results.index) === 'number' && data.results.index > 0);
            scope.loading = false;
          },
          errorHandler);
      };

      var transformQuestion = function (imhQuestion, imhLabel) {
        var listItems = {};
        angular.forEach(imhQuestion.AnswerChoices, function (answerChoice) {
          listItems[answerChoice.AnswerId] = answerChoice.Text;
        });
        return {
          listItems: listItems,
          name: 'ImhQuestion',
          label: imhLabel,
          id: 'questionnaire_question'
        };
      };

      dynamicText.getDynamicText('evisits', 'eVisitQuestionnairePanel').then(function (data) {
        scope.questionInstructions = data;
      }, errorHandler);

      var nav = {
        forward: function (answer) {
          return loadNextQuestion(answer);
        },
        back: function () {
          if (scope.questionnaireIndex > 0) {
            return loadNextQuestion(undefined, true);
          } else {
            scope.answer = undefined;
            return scope.fc.previous();
          }
        },
        goToIndex: function (idx) {
          return loadNextQuestion(undefined, undefined, idx);
        }
      };

      return {
        next: function () {
          nav.forward(scope.answer);
        },
        back: nav.back,
        goToIndex: nav.goToIndex
      };
    };
  }]);

})(window.app);
