(function (app) {
  'use strict';
  app.factory('eVisitErrorHandler', ['alertService', '$log', function eVisitErrorHandler (svc, log) {
    return function handler (data) {
      log.error(data);
      if (data.data.status !== 403) {
        svc.add('danger', data.data.message || 'Unexpected Error: ', 10000);
      }
    };
  }]);
})(window.app);
