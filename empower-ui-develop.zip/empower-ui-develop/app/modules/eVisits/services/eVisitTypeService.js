(function (app) {
  'use strict';
  app.factory('eVisitTypeService', ['medseekApi', 'eVisitErrorHandler', 'eVisitSessionSvc', 'dynamicText', 'cultureService', function (api, errorHandler, sessionSvc, dynamicText, cultureService) {
    return function (scope, fc) {
      var session = sessionSvc();
      var predefinedQuestionnairePromise = dynamicText.getDynamicText('eVisits', 'eVisitPredefinedEvisitTypeInstructions');
      var selfEnteredPromise = dynamicText.getDynamicText('eVisits', 'eVisitSelfEnteredEvisitTypeInstructions');
      var predefinedListPromise = dynamicText.getDynamicText('eVisits', 'eVisitEvisitTypesInstructions');
      var predefinedTypesDescriptionPromise = dynamicText.getDynamicText('eVisits', 'eVisitPredefinedEvisitTypeTextDescription');
      var typesPromise = api.evisits.questionnaireTypes.get({patientId: session.currentPatientId()}).$promise;

      scope.typeSettings = {};

      predefinedQuestionnairePromise.then(function (data) {
        scope.typeSettings.predefinedText = data;
      }, errorHandler);

      selfEnteredPromise.then(function (data) {
        scope.typeSettings.selfEnteredText = data;
      }, errorHandler);

      predefinedTypesDescriptionPromise.then(function (data) {
        scope.typeSettings.typeDescription = data;
      }, errorHandler);
      predefinedListPromise.then(function (data) {
        scope.typeSettings.predefinedListText = data;
      }, errorHandler);

      typesPromise.then(function (data) {
        scope.typeSettings.types = data.results;
      }, errorHandler);

      scope.$watch('selfEnteredQuestion', function (newVal) {
        fc.enableNext(newVal);
      });
      scope.$watch('selectedType', function (newVal) {
        fc.enableNext(newVal);
      });
      scope.$watch('evisitType', function (newVal) {
        if (newVal) {
          switch (newVal) {
            case 'text':
              fc.enableNext(!!scope.selfEnteredQuestion);
              break;
            case 'list':
              fc.enableNext(!!scope.selectedType);
              break;
            case 'predefined':
              fc.enableNext(true);
          }
        }
      });
      scope.$watch('evisitSpecialType', function (newVal) {
        if (newVal) {
          fc.enableNext(true);
        }
      });
      scope.$watch('stepIndex', function (newVal) {
        if (newVal === 1) {
          fc.enableNext(scope.evisitType);
          fc.enablePrevious(true);
        }
      });
      var processNextStep = function (questionSvc) {      
        var evisit = sessionSvc().getEvisitData();
        if(scope.evisitType && scope.selectedType ){
        evisit.evisitType=scope.evisitType;
        evisit.selectedType=scope.selectedType;
        sessionSvc(scope).setEvisitData(evisit);
        }
        var data = [];
        switch (scope.evisitType||sessionSvc().getEvisitData().evisitType ) {
          case 'text':
            data.push({ Name: scope.selfEnteredQuestion, IsEnabled: true });
            break;
          case 'list':
            data = scope.selectedType || sessionSvc().getEvisitData().selectedType;
            break;
          case 'predefined':
            if (scope.selectedType) {
              data.push(scope.selectedType);
            } else {
              fc.enableNext(false);
              scope.secondTypeStep = true;
              return;
            }
        }
        session.setSummary('complaint', data[0].Name);
        api.evisits.currentQuestionnaires.update({ patientId: session.currentPatientId(), id: session.get().id, culture: cultureService.getCurrentCulture().key }, { questionnaires: data }).$promise.then(function () {          
         if(scope.stepIndex===1){
          fc.next();
          }
          else if(scope.stepIndex===2){         
            questionSvc.next();
          }
        }, errorHandler);
      };
      var svc = {
        next: function (questionSvc) {
          fc.enablePrevious(true);
          processNextStep(questionSvc);
        },
        previous: function () {
          if (!scope.secondTypeStep) {
            fc.previous();
          }
          scope.secondTypeStep = false;
          fc.enableNext(true);
          fc.enablePrevious(false);

        }
      };
      return svc;
    };
  }]);

})(window.app);
