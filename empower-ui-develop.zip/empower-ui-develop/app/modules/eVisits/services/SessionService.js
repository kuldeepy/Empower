(function (app) {
  'use strict';
  app.factory('eVisitSessionSvc', ['session', function (session) {
    var EVISIT = 'current-evisit';
    return function (scope) {
      var manager = {
        get: function () {
          var evisit = session.get(EVISIT);
          var evisitObj = evisit ? JSON.parse(evisit) : null;
          if (evisitObj && scope) {
            scope.eVisitId = evisitObj.id;
            scope.stepIndex = evisitObj.stepIndex;
            if (!scope.questionnaireIndex && typeof evisitObj.index === 'number') {
              scope.questionnaireIndex = evisitObj.index || 0;
            }
          }
          return evisitObj;
        },
        getEvisitData:function(){ return session.get('EVISITDATA')?JSON.parse(session.get('EVISITDATA')):{};},
        setEvisitData:function(evisitData){
           session.set('EVISITDATA', JSON.stringify(evisitData));
        },
        set: function (evisit) {
          if (evisit.id) {
            scope.eVisitId = evisit.id;
          }
          session.set(EVISIT, JSON.stringify(evisit));
        },
        destroy: function () {
          session.clear(EVISIT);
          session.clear(EVISIT + '-questions');
          session.clear(EVISIT + '-summary');
        },
        setAnswer: function (question, val, index) {
          var questions = JSON.parse(session.get(EVISIT + '-questions') || '[]');
          questions.splice(index);
          questions[index] = question;
          session.set(EVISIT + '-questions', JSON.stringify(questions));
        },
        getQuestions: function () {
          return JSON.parse(session.get(EVISIT + '-questions') || '[]');
        },
        getSummary: function (key) {
          var summary = JSON.parse(session.get(EVISIT + '-summary') || '{}');
          return key !== undefined ? summary[key] : summary;
        },
        setSummary: function (key, value) {
          var summary = manager.getSummary();
          summary[key] = value;
          session.set(EVISIT + '-summary', JSON.stringify(summary));
        },
        currentPatientId: function () {
          var patientId = null;
          var patient = session.getObject('patient');
          if (patient) {
            patientId = patient.patientId;
          }
          return patientId;
        }
      };
      if (scope) {
        scope.$watch('stepIndex', function (newVal) {
          if (typeof newVal === 'number' && typeof scope.currentIndex === 'number') {
            manager.set({
              stepIndex: newVal,
              mainIndex: scope.currentIndex,
              id: scope.eVisitId,
              index: scope.questionnaireIndex
            });
          }
        });

        scope.$watch('currentIndex', function (newVal) {
          if (typeof newVal === 'number') {
            manager.set({
              stepIndex: scope.stepIndex || 0,
              mainIndex: newVal || 0,
              id: scope.eVisitId,
              index: scope.questionnaireIndex
            });
          }
        });
        scope.$on('stepFlowStepIndexChanged', function (sender, val) {
          scope.stepIndex = val;
        });
      }
      return manager;
    };
  }]);
})(window.app);
