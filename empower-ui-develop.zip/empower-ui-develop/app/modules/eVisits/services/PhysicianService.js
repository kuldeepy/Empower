(function (app) {
  'use strict';
  app.factory('eVisitPhysicianSvc', ['medseekApi', 'eVisitErrorHandler', 'alertService', '$q', 'session', '$rootScope', '$timeout', 'eVisitSessionSvc', 'dynamicText', function (api, errorHandler, alertSvc, q, session, rootScope, timeout, sessionSvc, dynamicText) {
    return function (scope) {
      var docSvc;

      /* physician grid layout */
      scope.physicianDataOptions = {
        data: 'questionnaire.physicians',
        columnDefs: [
          { width: 100, cellTemplate: '<div style="text-align:center;"><input style="float:none;margin: 10px auto 0 auto;" type="radio" name="dosc" ng-model="questionnaire.doc" ng-value="row.entity" /></div>' },
          { field: 'DoctorFullName', displayName: "Physician's Name" },
          { field: 'ImhSpecialty', displayName: 'Primary Specialty' }
        ],
        enableRowSelection: false
      };

      /* event handlers */
      scope.$on('eVisitSettings', function (sender, settings) {
        scope.canAddPhysicians = settings.canAddPhysicians;
      });
      scope.$emit('requestEVisitSettings');

      scope.$watch('doc', function (newVal) {
        if (scope.fc) {
          scope.fc.enableNext(newVal);
        }
      });
      rootScope.$on('eVisitDocAdded', function (sender, doc) {
        var found = _.find(scope.physicians, doc);
        if (!found) {
          docSvc.addPhysicianToProfile(doc);
        }
        scope.doc = found || doc;
      });
      scope.$watch('stepIndex', function (newVal) {
        if (newVal === 0 && scope.physicianDataOptions.ngGrid) {
          scope.physicianDataOptions.ngGrid.buildColumns();
        }
      });

      /* service definition */
      docSvc = {
        addPhysicianToProfile: function (doc) {
          scope.physicians.push(doc);
          api.evisits.patientPhysicians.save({patientId: sessionSvc().currentPatientId(), id: sessionSvc().get().id }, { physician: doc }).$promise.then(function () {
            alertSvc.add('success', doc.DoctorFullName + ' has been added to your profile.', 8000);
          }, errorHandler);
        },
        populateData: function () {
          var deferred = q.defer();
          var patient = scope.patient = JSON.parse(session.get('patient'));
          var textPromise = dynamicText.getDynamicText('evisits', 'eVisitPhysicianSelection');
          var physiciansPromise = api.evisits.physicians.get({ patientId: patient.patientId }).$promise;

          textPromise.then(function (response) {
            scope.headerText = response;
          }, errorHandler);

          physiciansPromise.then(function (response) {
            scope.physicians = response.results;

            /* get can't add physicians text */
            if (!scope.physicians.length) {
              dynamicText.getDynamicText('evisits', 'eVisitUnableToAddPhysicians').then(function (data) {
                scope.cannotAddPhysiciansText = data;
              });
            }
          }, errorHandler);

          q.all([textPromise, physiciansPromise]).then(function () {
            deferred.resolve();
          });
          return deferred.promise;
        },
        setPhysician: function (fc) {
          var service = sessionSvc();
          api.evisits.currentPhysician.update({patientId: service.currentPatientId(), id: service.get().id }, scope.doc).$promise.then(angular.noop, errorHandler);
          service.setSummary('physician', scope.doc);
          service.setSummary('patient', scope.patient);
          fc.next();
          fc.enablePrevious(true);
        }
      };

      return docSvc;
    };
  }]);
})(window.app);
