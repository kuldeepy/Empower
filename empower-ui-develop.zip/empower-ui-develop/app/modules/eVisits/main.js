(function (app) {
  'use strict';

  /* module root controller */
  app.controller('eVisitsLandingCtrl', ['$scope', 'session', function (scope, session) {
    scope.model = {
      routeParams: {}
    };
    var patient = session.getObject('patient');
    if (patient) {
      scope.patientId = patient.patientId;
    }
  }]);

})(window.app);
