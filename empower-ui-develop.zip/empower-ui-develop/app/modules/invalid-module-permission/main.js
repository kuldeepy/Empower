(function (app) {
  'use strict';

  /* module root controller */
  app.controller('ErrorMainCtrl', ['$scope', function (scope) {
    scope.model = {
      routeParams: {}
    };

    /* initial method called */
    scope.init = function () {};

  }]);

})(window.app);
