(function (app) {
  'use strict';

  app.controller('ErrorCtrl', ['$scope', 'session', function (scope, session) {
    scope.invalidModuleName = '';

    /* function called initially on controller */
    scope.init = function () {
      scope.invalidModuleName = scope.getInvalidModuleName();
    };

    /* get invalid module name */
    scope.getInvalidModuleName = function () {
      var moduleName = session.get('invalidModuleName');
      return (moduleName.length > 0) ? moduleName.trim().replace('/', '') : '';
    };

  }]);
}(window.app));
