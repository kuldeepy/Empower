
'use strict';
(function (app) {
  // container for data to be used for messages;
  var apiRoutes = {};
  window.apiRoutes = apiRoutes;


  app.ng.run(['$rootScope', function (rootScope) {
    rootScope.apiRoutes = apiRoutes;
  }]);

  var cacheSetting = {get: { method: 'GET', cache: true}};
  var ignoreLoadingBarSetting = {get: { method: 'GET', cache: true, ignoreLoadingBar: true}};
  // Property values below may one of the following forms:
  //   - a string identifying the relative URI
  //   - an object describing the child properties
  //   - an array containing the elements
  //       0: the URI string
  //       1: the service name of the model translator
  //       2: the child properties object.
  apiRoutes.url =
  {
    samlRequest: ['empower/sso/saml/identity-provider/:configId/:action',undefined,{}],
    'patients': ['patients/:patientId/', undefined, {
      blueButtonDownload: 'blue-button-download',
      locations: 'locations/',
      physicians: 'physicians',
      saveLocation: 'locations/:locationId',
      savePhysician: 'physician/:physicianId',
      viewDemographics: 'viewDemographics',
      Guarantor: 'Guarantor',
      primaryGuarantor: 'Guarantor/:guarantorId/primary',
      deleteGuarantor: 'Guarantor/:guarantorId',
      primaryPhysician: 'Physician/:physicianId/primary',
      primaryLocation: 'location/:locationId/primary'
    }],

    'patientProfiles': ['empower/user-management/patients', undefined, {}],
    'userProfiles': ['empower/user-management/users', undefined, {}],
    'patientRelationShips': ['empower/user-management/patients/:patientId/relationships', undefined, {}],
    'userRelationShips': ['empower/user-management/users/:userId/relationships', undefined, {}],
    'userRelationShipAcessLevel': ['empower/user-management/patients/:patientId/relationships/:userId/access-level', undefined, {}],

    'selfEntered': ['patients/:patientId/clinicalInformation/:viewKey?mrn=:mrn', undefined, {}],
    'updateSelfEntered': ['patients/:patientId/clinicalInformation/:viewKey/:healthInformationId?mrn=:mrn', undefined, {}],
    'termsAndCondition': ['dynamicTexts/:moduleName/:key', undefined, {},cacheSetting],
    'pinVerification': ['enrollmentPins/:pin', undefined, {}],
    'setInvitationToEnrolled': ['enrollment/:pin/enrolled?medseekId=:medseekId', undefined, {}],
    'verifyPassword': ['users/violations/:username/:password', undefined, {}],
    'verifyEmailAddress': ['users?userEmailId=:userEmailAddress', undefined, {}],
    'verifyUserName': ['users?userName=:userName', undefined, {}],
    'reportIncorrectDemographics': ['patients/:patientId/incorrectDemographics/:userId/report', undefined, {}],
    'auditUserSignUp': ['users/:userId/userSignUpAudit', undefined, {}],
    'sendVerificationEmail': ['enrollment/sendVerificationEmail/:userEmailAddress?portalWebsiteUrl=:portalWebsiteUrl&forceNewCode=:forceNewCode&lang=:lang', undefined, {}],
    'validateEmailVerificationCode': ['enrollment/validateEmailVerificationCode/:userEmailAddress/:verificationCode', undefined, {}],
    'signUpRegistrationCompleted': ['enrollment/signUpRegistrationCompleted', undefined, {}],
    'securityQuestions': ['settings/users/securityQuestions', undefined, {}],
    'passwordRequirements': ['settings/users/passwordRequirements', undefined, {}],
    'locations': ['locations', undefined, {
      'page': ['/page', undefined, {}],
    }],

    pharmacy: ['empower/patients/', undefined, {
      getPharmacies: 'pharmacies',
      getPatientPharmacies: ':patientId/pharmacies',
      deletePatientPharmacy: ':patientId/pharmacy/:pharmacyId',
      copyPatientPharmacy: ':patientId/pharmacy/:pharmacyId',
      savePatientPharmacy: ':patientId/pharmacy/:pharmacyId/savePharmacy'
    }],



    demography: ['patients', undefined, {
      copyDemography: '/demographics',
      editDemography: '/editDemographics',
      editUserDemographics: '/users/:userId'

    }
    ],
    pharmacies: ['pharmacies/', undefined, {
      search: 'searchPharmacies'
    }],
    insurances: ['insurances/', undefined, {
      'getDynamicFormForPayer': ['payerForm/:payerId', undefined, {}],
      'getLinkedPatientValue': [':patientId/:insuranceId/insurance', undefined, {}],
      'searchlist': ['searchlist', undefined, {}]
    }],
    targetGroups: ['targetGroups/', undefined, {
      'insurances': ['insurances', undefined, {}],
      'getTargetGroups': [':moduleInstanceId', undefined, {}],
      'getTargetGroupsCount': [':moduleInstanceId/count', undefined, {}],
      'getTargetGroupsParameter': ['rules/rulesParameterData', undefined, {}],
      'saveTargetGroup': ['', undefined, {}],
      'updateTargetGroup': [':targetGroupId', undefined, {}],
      'deleteTargetGroups': [':targetGroupId', undefined, {}],
      'patientCampains': [':userId/campaigns', undefined, {}],
    }],


    'getModules': ['modules', undefined, {}],

    ruleEngine: ['ruleEngine/', undefined, {
      'getRulesById': ['rules/:ruleId', undefined, {}],
      'saveRules': ['rules', undefined, {}],
      'updateRules': ['rules/:ruleId', undefined, {}]
    }],

    'getLocations': ['locations', undefined, {
      'byExternalIds': ['/search/externalbyids', undefined, {}]
    }],

    'getPhysicians': ['physicians', undefined, {
      'locations': ['/locations/:physicianId', undefined, {}],
      'byexternalids': ['/byexternalids', undefined, {}],
      'physician': ['/:physicianId', undefined, {}],
    }],
    'evisits': {
      settings: 'empower/patients/:patientId/evisits/settings',
      userSettings: 'empower/patients/:patientId/evisits/user/:userId/settings',
      paymentSettings: 'empower/patients/:patientId/evisits/:id/payment/settings',
      create: 'empower/patients/:patientId/evisits',
      current: 'empower/patients/:patientId/evisits/:id',
      validatePayment: 'empower/patients/:patientId/evisits/:id/payments/:token',
      currentPhysician: 'empower/patients/:patientId/evisits/:id/physician',
      physicians: 'empower/patients/:patientId/evisits/physicians',
      questionnaireTypes: 'empower/patients/:patientId/evisits/questionnaire/types',
      questionnaireIndex: 'empower/patients/:patientId/evisits/:id/questionnaire-index',
      currentQuestionnaires: 'empower/patients/:patientId/evisits/:id/language/:culture/questionnaires',
      currentQuestion: 'empower/patients/:patientId/evisits/:id/questionnaire-questions/:index',
      patientPhysicians: 'empower/patients/:patientId/evisits/:id/patient-physicians'
    },
    'topMenuNavigation': ['portals/:portalId/properties/:displayTopNavMenu', undefined, {}],
    'navigationMenus': ['users/:userId/patients/:patientId/navigations', undefined, {}],
    'staffNavigations': ['users/:userId/navigations', undefined, {},cacheSetting],
    'userPatientNavigations': ['users/:userId/patients/:patientId/navigations', undefined, {}],
    'userNavigations': ['users/:userId/navigations', undefined, {}],
    'userManagement': ['api/empower/staff/user-management/', undefined, {
      'settings': ['settings/', undefined, {
        'searchResults': ['search-results', undefined, {}]
      }]
    }],
    'loginToApplication': ['empower/sessions', undefined, {}],
    'roles': ['empower/roles', undefined, {},cacheSetting],
    'genders': ['empower/genders', undefined, {},cacheSetting],
    'enrollmentDynamicForms': ['dynamicForms/enrollment/ChallengeQuestions', undefined, {}],
    'enrollmentStatus': ['enrollment/statuses', undefined, {}],
    'mhrData': ['patients/:patientId/clinicalInformation?mrn=:mrn', undefined, {}],
    'getEnrollmentSettings': ['modules/:moduleName/settings', undefined, {}],

    'getEmpowerDynamicTexts':['empowerDynamicTexts', undefined,{},cacheSetting],
    'getDynamicTexts': ['dynamicTexts/:moduleName/:key', undefined, {},cacheSetting],
    'countries': ['empower/countries/:countryId', undefined, {},cacheSetting],
    'states': ['empower/countries/:countryId/states', undefined, {},cacheSetting],
    'allStates': ['empower/states', undefined, {},cacheSetting],
    'profileLookups': ['empower/profileLookUps', undefined, {},cacheSetting],
    'profileAllLookups': ['empower/profileLookUps/all', undefined, {},cacheSetting],
    'cssContent': ['cssContent/getAllCssContent/:portalType', undefined, {}, cacheSetting],

    // for getting the echo
    'patientManagement': ['echoData', undefined, {}],
    'patientsResource': {
        physicians: 'patients/:patientId/physicians',
        locations: 'patients/:patientId/locations',
        addPhysician: 'empower/patients/:patientId/physicians',
        addLocation: 'patients/:patientId/locations/:locationId',
        guarantors: 'patients/:patientId/Guarantor',
        emergencycontacts: 'patients/:patientId/emergencycontacts',
        insurances: 'patients/:patientId/insurances',
        pharmacies: 'patients/:patientId/pharmacies'
    },
    'dynamicForms': ['dynamicForms/:module/:key', undefined, {}],
    'dynamicFormsById': ['dynamicForms/formids/id/:formId', undefined, {}],
    'userDemographics': ['dynamicForms/profile/PortalUserDemographics', undefined, {}],
    'saveUsers': ['users', undefined, {}],
    'getTasksDetails': ['tasks/:taskId', undefined, {}],
    'validatePinWithChallengeAnswers': ['users/:userid/validatePinWithChallengeAnswers', undefined, {}],
    'saveUserInformation': ['users/:userId/profile', undefined, {}],
    'sessions': {
      session: 'empower/sessions/:userid',
    },
    'getSpecialCharacters': ['portals/specialCharacters', undefined, {}, cacheSetting],
    'userSettings': {
      generic: 'users/:userId/settings',
      patients: 'users/:userid/patients',
      editUserImage: 'users/:userId/profileimage',
      editUserImageCrop: 'users/:userId/profileimage?action=:actionName',
      loadUserImage: 'users/:userId/image',
    },

    task_center: ['empower/tasks/', undefined, {
      getTaskDetailsByRole:[':taskId/details?roleId=:role', undefined, {}],
      getTasks: [':taskScope?pageSize=:pageSize&pageNumber=:pageNumber&sortDirection=:sortDirection&taskState=:taskState&taskType=:taskType&roleId=:roleId', undefined, {}],
      getTask: [':taskId/details', undefined, {}],
      getDiscussions: [':taskId/discussions', undefined, {}],
      completeTask: [':taskId', undefined, {}],
      saveMembers: [':taskId/discussions/:discussionId', undefined, {}],
      saveComments: [':taskId/discussions/:discussionId/comments', undefined, {}],
      editComment: [':taskId/discussions/:discussionId/comments/:commentId', undefined, {}],
      deleteComment: [':taskId/discussions/:discussionId/comments/:commentId?userId=:userId&workflowInstanceId=:workflowInstanceId', undefined, {}],
      saveNotes: [':taskId/notes', undefined, {}],
      deleteNotes: [':taskId/note/:noteId?patientId=:patientId', undefined, {}],
      saveDiscussions: [':taskId/discussions?workflowInstanceId=:workflowInstanceId', undefined, {}],
      getMembers: [':taskId/users?patientId=:patientId', undefined, {}],
      putDiscussion: [':taskId/discussions/:discussionId?userId=:userId', undefined, {}],
      taskSearch: ['search', undefined, {}],
      getAssignedTaskData: [':taskId/assignments?workflowInstanceId=:workflowInstanceId&excludeCurrent=:excludeCurrent', undefined, {}],
      approveTask: [':taskId/action', undefined, {}],
      getAllDiscussion: [':userId/discussion', undefined, {}]
    }],

    'taskCenter': {
      getDiscussions: 'tasks/:taskId/discussions',
      getSavedSearch: 'users/:userid/:moduleName/searches',
      deleteSavedSearch: 'users/:userid/:moduleName/searches',
      saveSearch: 'users/:userid/:moduleName/searches',
      getPatientHealthRecords: 'patients/:patientId/clinicalInformation?mrn=:mrn',
      getDiscussion: 'tasks/:taskId/discussions/:discussionId?userId=:userId',
      getDocuments: 'patients/:patientId/documents?medseekId=:medseekId',
      taskType: 'empower/tasks/types'
    },

    appointments: ['empower/patients/:patientId/appointments/', undefined, {
      getAppointments: [':isFutureAppointment?mid=:medseekId&directOnly=false', undefined, {}],
      getAppointmentById: [':appointmentId/appointments?source=internal', undefined, {},cacheSetting],
      getDynamictext: ['dynamic-text/', undefined, {},cacheSetting],
      getAppointmentType: ['appointment-types/search', undefined, {},cacheSetting],
      getAllDynamicText: ['dynamic-text', undefined,{}, cacheSetting],
      savePreRegistrationInformation: [':id/pre-register', undefined, {}],
      saveNewAppointment: ['schedule-internal-request', undefined, {}],
      rescheduleIndirectAppointment: ['reschedule-internal-request', undefined, {}],
      cancelIndirectAppointment: ['cancel-internal-request', undefined, {}],
      appntResponeType: ['response-type', undefined, {},cacheSetting],
      directAvailableAppointment: ['available-slots/search', undefined, {}],
      scheduleExternalAppointment: ['schedule-external-request', undefined, {}],
      getAppointmentByExternalId: ['directAppointmentDetails/:appointmentExternalId', undefined, {}],
      rescheduleDirectAppointment: ['reschedule-external-request', undefined, {}],
      cancelExternalAppointment: ['cancel-external-request', undefined, {}]
    }],

    'messageCenter': {
      getMessages: '/messages/messagelist/:mailboxId'
    },
    staff: ['api/empower/staff/', undefined, {
      'physicians': ['physicians', undefined, {}],
      'portals': ['portals/:portalId', undefined, {
        roles: ['/roles/:roleId', undefined, {
          permissions: ['/permissions', undefined, {}]
        }]
      }],
      'accessLevelDefinition': ['access-level-definition', { isArray: true }, {}],
      'rolePermissionsDefinition': ['role-permissions-definition', { isArray: true }, {}],
      'userManagement': ['user-management/', undefined, {
        'settings': ['settings/', undefined, {
          severReasons: ['sever-relationship-reasons', undefined, {}]
        }],
        'patients': ['patients/:uniqueId', undefined, {
          'locations': ['/locations', undefined, {}],
          'physicians': ['/physicians', undefined, {}],
          'invitations': ['/invitations', undefined, {}],
          'relationships': ['/relationships/:userId', undefined, {
            'accessLevel': ['/access-level', undefined, {}],
            'status': ['/status', undefined, {}]
          }]
        }],
        'users': ['users/:userId', undefined, {
          'relationships': ['/relationships', undefined, {}],
          'roles': ['/roles', undefined, {}],
          'invitations': ['/invitations', undefined, {}]

        }],
        'invitations': ['manage-invitations/:pin', undefined, {}]
      }]
    }],
    authz: ['api/empower/authz', undefined, {
      'getDecision': ['/get-decision', undefined, {}]
    }],

    appointment: ['appointments/', undefined, {
      'getDynamicText': ['dynamictext/:moduleName/:key', undefined, {},cacheSetting]
    }],

    message: ['messages/', undefined, {
      'mailbox': ['mailboxes', undefined, {}],
      'deleteMailbox': ['mailboxes/:mailboxId/:destinationFoldeId', undefined, {}],
      'renameMailbox': ['mailboxes/name', undefined, {}],
      //'uploadImportList': ['broadcastMessaging/import/upload', undefined, {}],
      'updateTemplate': ['broadcastMessaging/template/:templateId/update', undefined, {}],
      'deleteTemplate': ['broadcastMessaging/templates', undefined, {}],
      'getModuleSettings': [':moduleName/settings/modulesettings', undefined, {}, cacheSetting],
      'getTargetGroups': ['targetGroups', undefined, {}],
      'getTargetGroup': ['targetGroups/:groupId', undefined, {}],
      'getTargetGroupResults': ['targetGroups/:targetGroupId/results', undefined, {}],
      'processTargetGroup': ['targetGroups', undefined, {}],
      'reprocessTargetGroup': ['targetGroups/:groupId', undefined, {}],
      'deleteTargetGroup': ['targetGroups/:groupId', undefined, {}],
      'messageValidatorSettings': ['dynamicform/:moduleName/messageBody', undefined, {}],
      'getDynamicText': ['dynamictext/:moduleName/:key', undefined, {},cacheSetting]
    }],

    message_center: ['empower/message-center/', undefined, {
      'mailbox': ['mailboxes', undefined, {
        'mailboxId': ['/:mailboxId', undefined, {
          'count': ['/messages/count?unread=:unread', undefined, {}],
          'message': ['/messages?searchText=:searchText&offset=:offset&limit=:limit', undefined, {}],
          'createNewMessages': ['/messages', undefined, {}],
          'messageById': ['/messages/:messageId', undefined, {}],
          'downloadAttachment': ['/messages/:messageId/attachments/:attachmentId', undefined, {}],
          'moveOrRestore': ['/messages/:messageId/folder?action=:action', undefined, {}],
        }],
      }],

      'recall': ['message-recall', undefined, {}],
      'patientRecipient': ['recipients/patients', undefined, {}],
      'staffRecipient': ['recipients/staff', undefined, {}],
    }],

    broadcastmessaging: ['empower/broadcast-messaging/', undefined, {
      'getCategories': ['categories', undefined, {}],
      'getSenders': ['categories/:id/senders', undefined, {}],
      'getBroadcastContentTemplates': ['templates', undefined, {}],
      'getTemplateDetailsById': ['templates/:id', undefined, {}],
      'getTemplates': ['templates?sortField=:sortField&sortAscending=:sortAscending&limit=:limit&offset=:offset', undefined, {}],
      'deleteTemplates': ['templates', undefined, {}],
      'updateTemplate': ['templates/:id', undefined, {}],

      'getImportList': ['imported-lists', undefined, {}],
      'reprocessImportList': ['imported-lists/:id/reprocess', undefined, {}],
      'deleteImportList': ['imported-lists', undefined, {}],
      'getImportProcessed': ['imported-lists/:id/result-type/:resultType', undefined, {}],

      'deleteBroadcastMessage': ['drafts/:id', undefined, {}],
      'getDraftMessages': ['drafts?sortField=:sortField&sortAscending=:sortAscending&limit=:limit&offset=:offset', undefined, {}],
      'getSourceIdentifiers': ['source-identifiers', undefined, {}],
      'getSentMessageById': ['messages/:id?includeRecipients=:includeRecipients&includeAttachments=:includeAttachments', undefined, {}],
      'getSentMessages': ['messages?sortField=:sortField&sortAscending=:sortAscending&limit=:limit&offset=:offset', undefined, {}],
      'getMessageRecipients': ['messages/:id/recipients', undefined, {}],
      'uploadImportList': ['imported-lists', undefined, {}],

    }],
    relationshipClassifications: ['empower/patient-relationship-classifications',undefined,{},cacheSetting],
    patient: ['patients/', undefined, {
      'custodians': [':patientId/custodians', undefined, {}],
      'blueButtonDownload': [':medseekPatientId/blue-button-download', undefined, {}],
      'pharmacies': [':patientId/pharmacies', undefined, {}],
      'educationalInfo': [':patientId/educationalInfo', undefined, {}],
      'physicians': [':patientId/physicians', undefined, {}],
      'locations': [':patientId/locations', undefined, {}],
      'clinicalInformation': [':patientId/clinicalInformation?mrn=:mrn', undefined, {}],
      'medications': [':patientId/medications', undefined, {}],
      'selfEntered': [':patientId/clinicalInformation/:viewKey', undefined, {}],
      'selfEnteredUpdate': [':patientId/clinicalInformation/:viewKey/:healthInformationId?mrn=:mrn&documentIds=:documentIds', undefined, {}],
      'prescriptionRenewals': [':patientId/madications/prescription-renewals', undefined, {}],
      'dispute': [':patientId/clinicalInformation/:viewKey/:healthInformationId/dispute', undefined, {}],
      'documents': [':patientId/documents?medseekId=:medseekId', undefined, {}],
      'documentsByFile': [':patientId/documents/:fileId', undefined, {}],
      'documentsById': [':patientId/documents/:documentId?medseekId=:medseekId', undefined, {}],
      'transmit': [':patientId/documents/:fileId/transmit/', undefined, {}],
      'patientById': [':patientId', undefined, {}],
      'patientByMrn': [':mrn/patient', undefined, {}],
      'patientSearch': ['search', undefined, {}],
      'custodianLevels': ['custodian-levels', undefined, {},cacheSetting],
      'locationsById': [':patientId/locations/:locationId', undefined, {}],
      'relationship': ['relationship', undefined, {}],
      'physicianById': [':patientId/physician/:physicianId', undefined, {}],
      'pharmacyById': [':patientId/pharmacy/:pharmacyId', undefined, {}],
      'getEmergencyContact': [':patientId/emergencycontacts', undefined, {}],
      'emergencyContact': [':patientId/emergencycontacts/:emergencyContactId', undefined, {}],
      'updateExternalPatient': [':patientId/:patientUniqueId/:portalUserId', undefined, {}],
      'getInsurances': [':patientId/insurances', undefined, {}],
      'saveorUpdateInsurance': [':patientId/insurances/:insuranceId', undefined, {}],
      'deleteInsurance': [':patientId/insurances/:insuranceId/deleteInsurance', undefined, {}],
      'copyInsurance': [':patientId/insurance/:insuranceId', undefined, {}],
      'copyEmergencyContact': [':patientId/copyEmergencyContact', undefined, {}],
      'copyGuarantor': [':patientId/copyGuarantor', undefined, {}],
      'copyPhysician': ['copyPhysician', undefined, {}],
      'setPatientDefaultEmergencyContact': [':patientId/emergencycontacts/:emergencyContactId/default', undefined, {}],
      'getPatientsDocuments': [':patientId/documents/:fileId?medseekId=:medseekId&documentId=:documentId&fileName=:fileName&actionType=:actionType&format=:format', undefined, {}],
      'editProfileImage': [':patientId/profileimage', undefined, {}],
      'editProfileImageCrop': [':patientId/profileimage?action=:actionName', undefined, {}],
      'approveEditPatientDemographics': ['patient/ApprovePatientUpdate', undefined, {}],
      'deleteProfileImage': [':patientId/deleteImage', undefined, {}],
      'approvePhysician': [':patientPhysicianId/physicians', undefined, {}],
      'approveAll': ['approveAllTask', undefined, {}],
      'patientAuditLog': [':patientId/auditLog', undefined, {}]
    }],

    patient_management: ['empower/patients/', undefined, {
      patientDemographics: [':patientId/demographics', undefined, {}],
      profileImage: [':patientId/profile-image', undefined, {}],
      locations: [':patientId/locations', undefined, {}],
      locationById: [':patientId/locations/:locationId', undefined, {}],
      emergencyContact: [':patientId/emergency-contacts', undefined, {}],
      emergencyContactById: [':patientId/emergency-contacts/:contactId?isLinked=:isLinked', undefined, {}],
      insurances: [':patientId/insurances', undefined, {}],
      insuranceById: [':patientId/insurances/:insuranceId', undefined, {}],
      physicians: [':patientId/physicians', undefined, {}],
      physicianById: [':patientId/physicians/:physicianId', undefined, {}],
      guarantors: [':patientId/guarantors', undefined, {}],
      guarantorById: [':patientId/guarantors/:guarantorId', undefined, {}],
      pharmacies: [':patientId/pharmacies', undefined, {}],
      pharmaciesById: [':patientId/pharmacies/:pharmacyId', undefined, {}],
      addPhysician: ':patientId/physician/:physicianId',
      addLocation: ':patientId/locations/:locationId',
      getAccessLevelDefination: [':patientId/access-level-definition', undefined, {}]
    }],
    healthInformation: ['empower/patients/', undefined, {
      'getPatientHealthInformationViews': [':patientId/health-info/?mrn=:mrn', undefined, {}],
      'getImportedRecords': [':patientId/clinical-documents?medseekId=:medseekId', undefined, {}],
      'getImportedRecordsByDocumentId': [':patientId/clinical-documents/:documentId?medseekId=:medseekId&fileId=:fileId&fileName=:fileName&actionType=:actionType&format=:format', undefined, {}],
      'transmitClinicalDocument': [':patientId/documents/:documentId/transmit', undefined, {}],
      'blueButtonDownload': [':patientId/blue-button-download?medseekPatientId=:medseekPatientId&startDate=:startDate&endDate=:endDate&format=:format&excludedComponents=:excludedComponents', undefined, {}],
      'getPatientHealthInfoDetails': [':patientId/health-info/:viewkey?mrn=:mrn', undefined, {}],
      'getPatientWeights': [':patientId/weights?mrn=:mrn', undefined, {}],
      'getRequestForm': [':patientId/requests/:requestId/request-type', undefined, {}],
      'deleteImportedDocumentsById': [':patientId/documents/:documentId', undefined, {}],
      'deleteAllImportedDocuments': [':patientId/documents', undefined, {}],
      'deleteExternalHealthInfoData': [':patientId/health-info/:viewKey/:healthInformationId?mrn=:mrn&documentIds=:documentIds&comments=:comments', undefined, {}],
      'contentService': [':patientId/health-info/:viewKey/:healthInformationId/education-material?searchkey=:searchkey&searchtype=:searchtype&patientDob=:patientDob&gender=:gender'],
      'infoButtonService': [':patientId/infobutton?code=:code&codeSystemId=:codeSystemId&keyword=:keyword&patientDob=:patientDob&gender=:gender'],
      'postSelfEnteredData': [':patientId/health-info/:viewkey?mrn=:mrn', undefined, {}],
      'deleteSelfEnteredData': [':patientId/health-info/:viewkey/:id?mrn=:mrn', undefined, {}]
    }],
    location: ['locations/', undefined, {
      'locationDetails': [':patientId', undefined, {}],
      'locationsList': ['all/paging', undefined, {}],
    }],
    physicians: ['physicians/', undefined, {
      'physicianById': [':physicianId', undefined, {}]
    }],
    posEnrollment: ['empower/pos-enrollment-invitation', undefined, {}],


    'patientSearch': {
      getDynamicForm: 'dynamicForms/profile/AddPatientDemographics',
      getPatientFilterData: 'patients/search',
      getPatientById: 'patients/:patientId',
    },
    'myHealthInformation': {
      saveTransmits: 'patients/:patientId/documents/:fileId/transmit/'
    },
    'users': {
      'profile': ['users/:userId/profile', undefined, {}],
      'copyUserToSelfProfile': ['users/:userId/userProfile?patientId=:patientId', undefined, {}],
      'passwordLookup': ['users/:key/lookup/password', undefined, {}],
      'failedAttempt': ['users/:userId/settings/authentication-attempt', undefined, {}],
      'lockedout': ['users/:userId/settings/lockedout', undefined, {}],
      'language': ['users/:userId/settings/language', undefined, {}],
      'currentPatient': ['users/:userId/current-patient', undefined, {}],
      userPatientRelationship: 'users/:userId/relationships/true/true'
    },

    'departments': ['request/departments', undefined, {}],

    portals: ['portals/:portalId', undefined, {
      'accessLevels': ['/access-levels', undefined, {}]
    }],

    'notificationAuditLog': {
      getActivityData: 'notificationCenter/auditlog',
      getActivityDataWithOffSet: 'notificationCenter/auditlogWithOffSet',
    },

    'modules': ['modules/', undefined, {
      'settings': [':moduleName/settings', undefined, {},cacheSetting]
    }],

    'moduleSetting': 'modules/:moduleName/settings/',
    'rememberThisDeviceSettings': 'settings/',

    'settings': ['settings/', undefined, {
      'modules': ['modules/:moduleName', undefined, {}, cacheSetting],
      'admin': ['admin', undefined, {}, cacheSetting],
      'profileForm': ['profile/dynamicform/:formId', undefined, {}],
      'usernameToolTip': ['tooltips?key=:key', undefined, {}],
      'landingpage': ['landingpage/landingPageTourSetings', undefined, {}],
    }],

    'user': ['users/', undefined, {
      'settings': [':userid/settings?key=:key', undefined, {}],
      'patients': [':userid/patients', undefined, {}],
      'admin': [':userId/profile', undefined, {}],
      'timeZone': [':userId/settings/timezone', undefined, {}],
      'activateAccount': [':userid/account/false?sendEmail=:sendEmail', undefined, {}],
      'deactivateAccount': [':userid/account/true?sendEmail=:sendEmail', undefined, {}],
      'securityQuestions': [':userid/securityQuestions', undefined, {}],
      'forcePasswordExpiration': [':userid/forcePasswordExpiration', undefined, {}],
      'sendResetPasswordEmail': [':userid/sendResetPasswordEmail', undefined, {}],
      'restoreRelationship': [':userid/restoreRelationship/:patientId?staffComment=:staffComment&updatedAccessLevelId=:updatedAccessLevelId', undefined, {}],
      'current': ['current/', undefined, {
        'permissionSet': ['permission-set', undefined, {}]
      }],
      'notificationPreferences': [':userid/settings/notification/preferences', undefined, {}],
      'getNotificationPreferences': [':userid/settings/notification/:key', undefined, {}],
      'passwordLink': [':userid/password/reset-link', undefined, {}],
      'updateLanguage': [':userId/settings/language', undefined, {}]
    }],
    'request': ['request/', undefined, {
      'getDataRelation': ['dataRelations/:entityType', undefined, {}],
    }],

    'requestCenter': ['empower/', undefined, {
      getAllPendingRequests: ['patients/requests/pending', undefined, {}],
      getAllCompletedRequests: ['patients/requests/completed', undefined, {}],
      departments: ['requests/departments', undefined, {}],
      getRequestDetail: ['patients/:patientId/requests/:requestId', undefined, {}],
      dynamicText: ['requests/dynamic-text/:key', undefined, {}],
      getDataRelation: ['data-relations/:entityType', undefined, {}],
      getRequestDataByModule: ['patients/:patientId/requests/:requestId/request-type', undefined, {}],
      saveRequest: ['patients/:patientId/requests', undefined, {}],
      getRequests: ['requests/request-types', undefined, {}],
      getDiscussionsForRequestCenter: ['requests/tasks/:taskId/discussions', undefined, {}],
      updateDiscussionsForRequestCenter: ['requests/tasks/:taskId/discussions/:discussionId', undefined, {}],
      saveComments: ['requests/tasks/:taskId/discussions/:discussionId/comments', undefined, {}],
      editComment: ['requests/tasks/:taskId/discussions/:discussionId/comments/:commentId', undefined, {}],
      deleteComment: ['requests/tasks/:taskId/discussions/:discussionId/comments/:commentId?userId=:userId&workflowInstanceId=:workflowInstanceId&patientId=:patientId', undefined, {}]
    }],

    'specialties': ['specialties/', undefined, {}],

    'tasks': ['tasks/', undefined, {
      'task': [':taskId', undefined, {}],
      'approveAppoinment': [':taskId/approve/appointment/:appointmentid', undefined, {}]
    }],

    'patientManagement1': ['echoData', undefined, {}],

    'recipients': ['messages/recipients', undefined, {
    }],

    'healthTracker': 'patients/:patientId/:trackerName?mrn=:mrn',
    'putPatientHeight': 'users/:userid/settings',
    'getPatientHeight': 'users/:userid/settings?key=:key',

    'getDefaultLandingPageTiles': ['settings/:portalType/:userid/landingPageTileSettings?key=:key', undefined, {}],
    'userTiles': ['users/current/landing-page/tiles', undefined, {}],
    'landingPageTour': ['settings/landingpage/landingPageTourSetings', undefined, {}],
    'getPatientHealthInformationPath': ['patients/:patientId/clinicalInformation?mrn=:mrn', undefined, {}],
    'getPatientClinicalDocumentsPath': ['patients/:patientId/documents?medseekId=:medseekId', undefined, {}],
    'getpatientsPath': 'users/:userid/patients',
    'notificationsCenter': {
      'getModuleSettingsPath': ['modules/:moduleName/settings', undefined, {}],
      'getDynamicTextsPath': ['notificationCenter/:moduleName/dynamicTexts', undefined, {}],
      //'postMarkPatientNotificationsAsReadPath': ['notificationCenter/:userId/:medseekPatientId/markNotificationsAsRead', undefined, {}],
      'postMarkPatientNotificationsAsReadPath': ['notificationCenter/:userId/markNotificationsAsRead', undefined, {}],
      'getPatientNotificationsPath': ['notificationCenter/notifications', undefined, {}],
      'getAllPatientNotificationsPath': ['notificationCenter/:userId/:medseekPatientId/notifications?status=:status', undefined, {}],
      'postPatientNotificationsPath': ['notificationCenter/:userId/:medseekPatientId', undefined, {}],

      'getNoitificationsTypesDynamicTextsPath': ['dynamicTexts/:moduleName/dynamicText', undefined, {}],
      'getSettingsAndDynamicTexts':['notificationCenterInformation',undefined,{}],
      'getDynamicTexts': ['dynamicTexts/:moduleName/:key', undefined, {}, cacheSetting],
      'getAllStaffNotification': ['notificationCenter/:userId/notifications', undefined, {}],
      'postMarkStaffNotificationsAsReadPath': ['notificationCenter/:userId/markStaffNotificationsAsRead', undefined, {}],
      'getStaffNotificationsPath': ['notificationCenter/staffNotifications', undefined, {}],
      'getStaffFilterNotification': ['notificationCenter/staff/', undefined, {}]
    },
    'getRoleOfUserById': 'users?userId=:userId',

    'getLinkedUsers': ['patients/relationship'],
    'sendMessage': ['messages/'],
    'contentService': ['contentService?searchkey=:searchkey&searchtype=:searchtype&patientDob=:patientDob&gender=:gender'],
    'contentDocument': ['contentService/:contentId?contentTypeId=:contentTypeId'],
    mhrRequests: ['empower/requests/', undefined, {
      'getAllRequests': ['request-types', undefined, {}],

    }],

    getLoginBanners: ['getLoginBanners',undefined,{},ignoreLoadingBarSetting],
    applicationSettings: 'applicationSettings/:key/GetString',
    findRecommendedArticlesContentService: 'contentService/recommended-articles',
    iframes: ['empower/iframes/:moduleInstanceId', undefined, {}],
    challengeQuestionAttempts: ['empower/challenge-question-attempts', undefined, {}],
    samlLogoutRequests : ['empower/sso/saml/service-provider/requests/logout', undefined, {}],
    samlLogoutResponseValidations: ['empower/sso/saml/service-provider/responses/logout/validations', undefined, {}],
    updateApprovePatientAccessLevel: ['empower/patients/:patientId/relationships/:userId/access-level', undefined, {}],
    getAllAdminSettingsDynamicTexts: ['dynamicTexts?lang=:culture&portalId=:portalId'],
    getCurrentPortalDetail: ['empower/portals/current']

  };


  apiRoutes.portal = [{
    url: '/login/patient',
    value: 'patient'
  },
  {
    url: '/login/staff',
    value: 'staff'
  }
  ];

})(window.app);
