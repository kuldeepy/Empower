﻿app.ng.config(function (apiProvider) {

  apiProvider.setBaseRoute(app.api.root);

  /*patient modules routes*/
  apiProvider.endpoint('patients').route(apiRoutes.url.userSettings.patients).model({});

  /* session modules routes*/
  apiProvider.endpoint('session').route(apiRoutes.url.sessions.session);

  apiProvider.endpoint('taskList').route(apiRoutes.url.taskCenter.getTasks);
  apiProvider.endpoint('task').route(apiRoutes.url.taskCenter.getTask);
  apiProvider.endpoint('notes').route(apiRoutes.url.taskCenter.saveNotes);
  apiProvider.endpoint('deleteNote').route(apiRoutes.url.taskCenter.deleteNotes);
  apiProvider.endpoint('getTaskAssignData').route(apiRoutes.url.taskCenter.getAssignedTaskData);
  apiProvider.endpoint('getSavedSearch').route(apiRoutes.url.taskCenter.getSavedSearch);
  apiProvider.endpoint('getTaskTypes').route(apiRoutes.url.taskCenter.taskType);
  apiProvider.endpoint('deleteSavedSearch').route(apiRoutes.url.taskCenter.deleteSavedSearch);
  apiProvider.endpoint('getPatientHealthRecords').route(apiRoutes.url.taskCenter.getPatientHealthRecords);
  apiProvider.endpoint('saveSearch').route(apiRoutes.url.taskCenter.saveSearch);
  apiProvider.endpoint('completeTask').route(apiRoutes.url.taskCenter.completeTask);
  apiProvider.endpoint('taskSearch').route(apiRoutes.url.taskCenter.taskSearch);
  apiProvider.endpoint('discussionList').route(apiRoutes.url.taskCenter.getDiscussions);
  apiProvider.endpoint('discussion').route(apiRoutes.url.taskCenter.getDiscussion);
  apiProvider.endpoint('saveDiscussions').route(apiRoutes.url.taskCenter.saveDiscussions);
  apiProvider.endpoint('saveComments').route(apiRoutes.url.taskCenter.saveComments);
  apiProvider.endpoint('saveMembers').route(apiRoutes.url.taskCenter.SaveMembers);
  apiProvider.endpoint('memberList').route(apiRoutes.url.taskCenter.getMembers);
  apiProvider.endpoint('documents').route(apiRoutes.url.taskCenter.getDocuments);
  apiProvider.endpoint('deleteComment').route(apiRoutes.url.taskCenter.deleteComment);
  apiProvider.endpoint('editComment').route(apiRoutes.url.taskCenter.editComment);
  apiProvider.endpoint('putDiscussion').route(apiRoutes.url.taskCenter.putDiscussion);

  apiProvider.endpoint('getDynamicForm').route(apiRoutes.url.patientSearch.getDynamicForm);
  apiProvider.endpoint('getPatientFilterData').route(apiRoutes.url.patientSearch.getPatientFilterData);
  
  apiProvider.endpoint('userSettings').route(apiRoutes.url.userSettings.generic);
  apiProvider.endpoint('loadUserImage').route(apiRoutes.url.userSettings.loadUserImage);
  apiProvider.endpoint('editUserImage').route(apiRoutes.url.userSettings.editUserImage);
  apiProvider.endpoint('editUserImageCrop').route(apiRoutes.url.userSettings.editUserImageCrop);

  apiProvider.endpoint('saveTransmits').route(apiRoutes.url.myHealthInformation.transmitClinicalDocument);
  
  apiProvider.endpoint('getPatientById').route(apiRoutes.url.patientSearch.getPatientById);
  apiProvider.endpoint('getLinkedUsers').route(apiRoutes.url.getLinkedUsers);
  apiProvider.endpoint('sendMessage').route(apiRoutes.url.sendMessage);
});
