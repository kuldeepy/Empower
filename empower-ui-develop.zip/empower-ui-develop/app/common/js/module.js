
(function (app) {

  'use strict';

  function getModuleData(moduleName) {
    var json = {

      confirmDialog: {
        dialog: {
          controller: 'confirmDialogCtrl',
          templateUrl: '/templates/dialog-templates/confirmDialog.html'
        }
      },
      alertDialog: {
        dialog: {
          controller: 'alertDialogCtrl',
          templateUrl: '/templates/dialog-templates/alertDialog.html'
        }
      },
      customDialog: {
        dialog: {
          controller: 'customDialogCtrl',
          templateUrl: '/templates/dialog.html'
        }
      },
      transmitAgreePopupDialog: {
        dialog: {
          controller: 'transmitAgreePopupDialogCtrl',
          templateUrl: '/templates/transmit-agree-popup.html'
        }
      },
      transmitPopupDialog: {
        dialog: {
          controller: 'transmitPopupDialogCtrl',
          templateUrl: '/templates/transmit-popup.html'
        }
      },
      userImageUpload: {
        dialog: {
          controller: 'userImageUploadDialogCtrl',
          templateUrl: '/templates/user-upload-image.html'
        }
      },
      patientImageUpload: {
        dialog: {
          controller: 'patientImageUploadDialogCtrl',
          templateUrl: '../../templates/user-upload-image.html'
        }
      },
      clinicalDocumentDowloadPDialog: {
        dialog: {
          controller: 'clinicalDocumentDowloadDialogCtrl',
          templateUrl: '/templates/clinical-documents-download-popup.html'
        }
      },
      addDiscussionDialog: {
        dialog: {
          controller: 'addDiscussionCtrl',
          templateUrl: '/modules/task-center/templates/addDiscussion.html'
        }
      },
      addNoteDialog: {
        dialog: {
          controller: 'addNoteCtrl',
          templateUrl: '/modules/task-center/templates/addNote.html'
        }
      },
      editDiscussionDialog: {
        dialog: {
          controller: 'editDiscussionCtrl',
          templateUrl: '/modules/task-center/templates/editDiscussion.html'
        }
      },
      allergies: {
        dialog: {
          controller: 'dialogCtrl',
          templateUrl: '/templates/dialog.html'
        }
      },
      common: {
        dialog: {
          controller: 'commonCtrl',
          templateUrl: '/templates/dialog.html'
        }
      },
      taskCenter: {
        dialog: {
          controller: 'dialogCtrl',
          templateUrl: '/templates/dialog.html'
        }
      },
      taskCenterDisputeApproveTask: {
        dialog: {
          controller: 'TaskCenterDisputeApproveTaskCtrl',
          templateUrl: '/modules/task-center/views/approveDisputeTask.html'
        }
      },
      taskCenterInquiryApproveTask: {
        dialog: {
          controller: 'TaskCenterInquiryApproveTaskCtrl',
          templateUrl: '/modules/task-center/views/approveInquiryTask.html'
        }
      },
      taskCenterMarkCompleteTask: {
         dialog: {
           controller: 'TaskCenterMarkCompleteTaskCtrl',
           templateUrl: '/modules/task-center/views/markCompleteTask.html'
         }
       },
       taskCenterDenyTask: {
        dialog: {
          controller: 'TaskCenterDenyTaskCtrl',
          templateUrl: '/modules/task-center/views/denyTask.html'
        }
      },
      termsAndConditionDialog: {
        dialog: {
          controller: 'TermsAndConditionCtrl',
          templateUrl: '/modules/enrollment/templates/terms-and-condition-popup.html'
        }
      },
      printDialog: {
        dialog: {
          controller: 'PrintCtrl',
          templateUrl: '/templates/print.html'
        }
      },
      doesNotKnowChallengeDialog: {
        dialog: {
          controller: 'DoesNotKnowChallengeAnswerCtrl',
          templateUrl: '/modules/add-patient/templates/Does-Not-Know-Challenge-Answer.html'
        }
      },
      informationNotCorrectDialog: {
        dialog: {
          controller: 'InformationNotCorrectCtrl',
          templateUrl: '/modules/add-patient/templates/information-not-correct-popup.html'
        }
      },
      patientInformationNotCorrectDialog: {
        dialog: {
          controller: 'InformationNotCorrectCtrl',
          templateUrl: '/modules/appointments/templates/information-not-correct-popup.html'
        }
      },
      optOutEnrollmentDialog: {
         dialog: {
           controller: 'OptOutOfEnrollmentCtrl',
           templateUrl: '/modules/user-management/templates/opt-out-of-enrollment-popup.html'
         }
       },
       deleteOptOutEnrollmentDialog: {
         dialog: {
           controller: 'deleteOptOutEnrollmentCtrl',
           templateUrl: '/modules/user-management/templates/delete-opt-out-of-enrollment-popup.html'
         }
       },
       severConnectionPromoteUserDialog: {
         dialog: {
           controller: 'severConnectionPromoteUserCtrl',
           templateUrl: '/modules/user-management/templates/sever-connection-promote-user-popup.html'
         }
       },
       expireInvitationDialog: {
         dialog: {
           controller: 'ExpireInvitationCtrl',
           templateUrl: '/modules/user-management/templates/expire-invitation-popup.html'
         }
       },
       ageOfMajorityDialog: {
        dialog: {
          controller: 'OverrideAgeOfMajorityCtrl',
          templateUrl: '/modules/user-management/templates/override-age-of-majority-popup.html'
        }
      },
      activateAccountDialog: {
        dialog: {
          controller: 'ActivateAccountCtrl',
          templateUrl: '/modules/user-settings/templates/activate-account-popup.html'
        }
      },
      deactivateAccountDialog: {
        dialog: {
          controller: 'DeactivateAccountCtrl',
          templateUrl: '/modules/user-settings/templates/deactivate-account-popup.html'
        }
      },
      resetPasswordDialog: {
        dialog: {
          controller: 'ResetPasswordCtrl',
          templateUrl: '/modules/user-settings/templates/reset-password-popup.html'
        }
      },
      resetSecurityAnswersDialog: {
        dialog: {
          controller: 'ResetSecurityAnswersCtrl',
          templateUrl: '/modules/user-settings/templates/reset-security-answers-popup.html'
        }
      },
      customizeAccessLevelDialog: {
        dialog: {
          controller: 'CustomizeAccessLevelCtrl',
          templateUrl: '/modules/user-settings/templates/customize-access-level-popup.html'
        }
      },
      resendInvitationDialog: {
         dialog: {
           controller: 'ResendInvitationCtrl',
           templateUrl: '/modules/user-management/templates/resend-invitation-popup.html'
         }
      },
      taskCenterCompleteTask: {
        dialog: {
          controller: 'TaskCenterCompleteTaskCtrl',
          templateUrl: '/modules/task-center/views/completeTask.html'
        }
      }
    };

    return json[moduleName];
  }

  app.factory('$moduleData', [function () {

    return {
      module: function (moduleName) {
        return getModuleData(moduleName);
      }
    };

  }]);

})(window.app);
