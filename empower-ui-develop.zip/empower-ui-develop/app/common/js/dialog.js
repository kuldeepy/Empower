(function (app) {
  'use strict';

  /* get dialog data */
  function getDialogData(modal, moduleData, moduleName, header, message, footer, progress, data, windowClass,scope) {

    return modal.open({
      templateUrl: moduleData.module(moduleName).dialog.templateUrl,
      controller: moduleData.module(moduleName).dialog.controller,
      resolve: {
        header: function () { return (header !== undefined) ? angular.copy(header) : undefined; },
        message: function () { return (message !== undefined) ? angular.copy(message) : undefined; },
        footer: function () { return (footer !== undefined) ? angular.copy(footer) : undefined; },
        progress: function () { return (progress !== undefined) ? angular.copy(progress) : undefined; },
        data: function () { return angular.copy(data); },
        windowClass: function () { return (windowClass !== undefined) ? angular.copy(windowClass) : undefined; }
      },
      backdrop: 'static',
      keyboard: false,
      scope: scope,
      windowClass: 'modal ' + windowClass
    });
  }

  /* dialog factory */
  app.factory('$dialogFactory', ['$modal', '$moduleData', function (modalTest, moduleData) {

    var getDialog = function (moduleName, header, message, footer, progress, data, windowClass,scope) {
      return getDialogData(modalTest, moduleData, moduleName, header, message, footer, progress, data, windowClass,scope);
    };

    return {
      error: function (moduleName, header, message, windowClass) { return getDialog(moduleName, undefined, message, undefined, undefined, undefined, windowClass); },
      wait: function (moduleName, header, message, progress, windowClass) { return getDialog(moduleName, undefined, message, undefined, progress, undefined, windowClass); },
      alert: function (moduleName, header, message, windowClass) { return getDialog(moduleName, header, message, undefined, undefined, undefined, windowClass); },
      confirm: function (moduleName, header, message, windowClass) { return getDialog(moduleName, header, message, undefined, undefined, undefined, windowClass); },
      create: function (moduleName, header, windowClass,scope) { return getDialog(moduleName, header, message, undefined, undefined, undefined, windowClass,scope); },
      custom: function (moduleName, header, message, footer, windowClass) { return getDialog(moduleName, header, message, footer, undefined, undefined, windowClass); },
    };
  }]);

  /* dialog controller for confirm */
  app.controller('customDialogCtrl', ['$scope', '$modalInstance', 'header', 'message', 'footer', function (scope, modalInstance, header, message, footer) {
    scope.header = header;
    scope.message = message;
    scope.footer = footer;

    scope.no = function () {
      modalInstance.dismiss();
    };
    
    scope.close = function () {
      modalInstance.dismiss();
    };

    scope.yes = function () {
      modalInstance.close();
    };

  }]);

  /* dialog controller for confirm */
  app.controller('confirmDialogCtrl', ['$scope', '$modalInstance', 'header', 'message', function (scope, modalInstance, header, message) {
    var uniqueId = Math.random() * 100;
    scope.myId= "iui_dialog" + uniqueId;
    scope.header = header;
    scope.message = message;

    scope.no = function () {
      modalInstance.dismiss();
    };

    scope.yes = function () {
      modalInstance.close();
    };

  }]);

  /* dialog controller for alert */
  app.controller('alertDialogCtrl', ['$scope', '$modalInstance', 'header', 'message', function (scope, modalInstance, header, message) {
    scope.header = header;
    scope.message = message;

    scope.ok = function () {
      modalInstance.close();
    };
    scope.close = function () {
      modalInstance.dismiss();
    };

  }]);

}(window.app));
