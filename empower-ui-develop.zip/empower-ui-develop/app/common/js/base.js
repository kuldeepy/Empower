
'use strict';

(function () {

  // container for data to be used for generic purpose
  var base = {};
  window.base = base;
  base.status = false;
  base.container = base.footer = '';
  base.header = '';
  var json = {
    "dialog": {
      "types": [
          {
            "type": "CompleteTask",
            "headerText": "Complete Task?",
            "icon": "",
            "text": "",
            "buttons": [
              { "displayText": "No", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": true },
              { "displayText": "Yes", "retVal": true, "isEvent": true, "focus": false, "cssClass": "btn btn-primary" }

            ]
          },
        {
          "type": "Confirm",
          "headerText": "Confirm",
          "icon": "glyphicon glyphicon-question-sign",
          "text": "All changes will be lost. Do you want to continue?",
          "buttons": [
            { "displayText": "No", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": true },
            { "displayText": "Yes", "retVal": true, "isEvent": true, "focus": false }

          ]
        },
        {
          "type": "Alert",
          "headerText": "Alert",
          "icon": "glyphicon glyphicon-warning-sign",
          "text": "",
          "buttons": [
            { "displayText": "Ok", "retVal": true, "dismiss": "data-dismiss='modal'", "isEvent": true, "focus": true }
          ]
        },
        {
          "type": "Accept",
          "headerText": "Terms and Conditions",
          "icon": "",
          "text": "Click Accept if you accept the terms and conditions?",
          "buttons": [
            { "displayText": "I Decline", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": true },
            { "displayText": "I Accept", "retVal": true, "isEvent": true, "focus": false }
          ]
        },
        {
          "type": "Agree",
          "headerText": "Terms and Conditions",
          "icon": "",
          "text": "Click Accept if you accept the terms and conditions?",
          "buttons": [
            { "displayText": "Disagree", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": true },
            { "displayText": "Agree", "retVal": true, "isEvent": true, "focus": false }
          ]
        },
         {
           "type": "Tour",
           "headerText": "Welcome to Empower!",
           "icon": "",
           "text": "",
           "buttons": [
             { "displayText": "Skip the rest of the tour", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": true, "cssClass": 'btn btn-default pull-left' },
             { "displayText": "Next", "retVal": true, "isEvent": true, "focus": false, "cssClass": 'btn btn-warning pull-right' }
           ]
         },
         {
           "type": "Logout",
           "headerText": "Logout",
           "icon": "glyphicon glyphicon-warning-sign",
           "text": "",
           "buttons": [
           ]
         },
         {
           "type": "uploadImage",
           "headerText": "Edit Image",
           "icon": "",
           "text": "All changes will be lost. Do you want to continue?",
           "uploadControl": [
            { "type": "file", "model": "image", "retVal": true, "isEvent": true, "focus": true, "directive": "ms-image-upload" }
           ],
           "uploadButtons": [
             { "displayText": "Upload", "retVal": true, "isEvent": false, "focus": false, "directive": "ms-upload-click" },
             { "displayText": "Cancel", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": true, "directive": "" }

           ],
           "corpButtons": [
             { "displayText": "Save", "retVal": true, "isEvent": true, "focus": false, "directive": "" },
             { "displayText": "Cancel", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": true, "directive": "" }
           ],
           "buttons": [
           ]
         },
         {
           "type": "Incorrect",
           "headerText": "Confirm",
           "icon": "glyphicon glyphicon-check",
           "text": "All changes will be lost. Do you want to continue?",
           "commentWindow": [
            { "type": "span", "retVal": false, "isEvent": false, "focus": false },
             { "type": "textarea", "model": "generic.demographics", "retVal": false, "isEvent": false, "focus": true }
           ],
           "buttons": [
              { "displayText": "Send", "retVal": true, "isEvent": true, "focus": false },
             { "displayText": "Cancel", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": true }
           ]
         },
        {
          "type": "Report",
          "headerText": "Confirm",
          "icon": "glyphicon glyphicon-check",
          "text": "All changes will be lost. Do you want to continue?",
          "buttons": [
            { "displayText": "I want to Try again", "retVal": false, "dismiss": "data-dismiss='modal'", "focus": false },
             { "displayText": "Cancel, I will contact staff", "retVal": true, "isEvent": true, "focus": true }
          ]
        }
      ]
    }
  };

  /* get dialog status */
  base.getStatus = function (status) {
    base.status = status;
  };

  /* create dialog */
  base.createDialog = function (type, customText, callBack, headerText) {

    var dialogTypes = json.dialog.types;
    var filteredType = '';

    for (var index = 0; index < dialogTypes.length; index++) {
      if (dialogTypes[index].type === type) {
        filteredType = dialogTypes[index];
      }
    }

    base.header = base.footer = base.container = '';

    var bodyContent = filteredType.text;
    if (customText.length > 0) bodyContent = customText;
    if (headerText.length > 0) filteredType.headerText = headerText;

    if (type == 'Incorrect') {
      var content = '';
      for (var index = 0; index < filteredType.commentWindow.length; index++) {
        generic.demographics = '';
        var typeBody = filteredType.commentWindow[index].type;
        if (typeBody == 'span') {
          content += "<span>Comment : </span>";
        } else {
          content += "<" + typeBody + " rows='4' cols='50' ng-model='" + filteredType.commentWindow[index].model + "'></" + typeBody + ">";
        }
      }

      bodyContent = content;
    }

    if (type == "uploadImage") {

      generic.isOpenUpload = true;
      generic.imageData = "";
      var uploadButtonsControl = '';
      for (var index = 0; index < filteredType.uploadButtons.length; index++) {
        var ngUploadClick = (filteredType.uploadButtons[index].isEvent) ? " ng-click='" + callBack + "'" : filteredType.uploadButtons[index].dismiss;
        uploadButtonsControl += "<button tab-index='1' " + filteredType.uploadButtons[index].directive + " focus-ok='" + filteredType.uploadButtons[index].focus + "' class='btn btn-warning' " + ngUploadClick + ">" + filteredType.uploadButtons[index].displayText + "</button>";
      }

      var corpButtonsControl = '';
      for (var index = 0; index < filteredType.corpButtons.length; index++) {
        var ngCorpClick = (filteredType.corpButtons[index].isEvent) ? " ng-click='" + callBack + "'" : filteredType.corpButtons[index].dismiss;
        corpButtonsControl += "<button tab-index='1' " + filteredType.corpButtons[index].directive + " focus-ok='" + filteredType.corpButtons[index].focus + "' class='btn btn-warning' " + ngCorpClick + ">" + filteredType.corpButtons[index].displayText + "</button>";
      }

      bodyContent = '<div>' +
        '<div class="uploadContainer"><div>' +
          '<div class="upload-image-popup inActive" ng-click="uploadImagePopupClick()" >1. Upload Image</div>' +
          '<div><div ng-show="generic.isOpenUpload"><div><input ms-image-upload type="file" ng-model="uploadFile" name="upload"><span class="glyphicon glyphicon-info-sign information-icon" tooltip="{{userInformationData.imageCriteria}}" tooltip-placement="bottom"></span></div>' +
          '<div><span class="imageError"></span></div>' +
          '<div><div class="upload-image-popup-control text-right">' + uploadButtonsControl + '</div></div></div></div>' +
        '</div></div>' +
        '<div class="uploadContainer"><div>' +
          '<div class="upload-image-popup">2. Crop Image</div>' +
          '<div><div ng-show="!generic.isOpenUpload"><div class="imageAppend"></div>' +
          '<div><div class="upload-image-popup-control text-right">' + corpButtonsControl + '</div></div></div></div>' +
          '</div></div>' +
        '</div>';
    }
    //<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    base.header = '<h4 class="modal-title" >' + filteredType.headerText + '</h4>';
    if (filteredType.icon.trim().length === 0)
      base.container = "<div class='row'><div class='col-md-12 popup-scroll-bar'>" + "<div class='popup-body'>" + bodyContent + "</div></div></div>";
    else
      base.container = '<div class="row">' +
                          '<div class="col-md-12">' +
                            '<div class="col-md-2">' +
                              '<div class="popup-icon ' + filteredType.icon + '"> </div>' +
                            '</div>' +
                            '<div class="col-md-10">' +
                              '<div class="popup-body">' + bodyContent + '</div>' +
                            '</div>' +
                          '</div>' +
                        '</div>';

    for (var index = 0; index < filteredType.buttons.length; index++) {
      var ngClick = (filteredType.buttons[index].isEvent) ? " ng-click='" + callBack + "'" : filteredType.buttons[index].dismiss;

      if (filteredType.buttons[index].cssClass !== undefined)
        base.footer += "<button tab-index='1' focus-ok='" + filteredType.buttons[index].focus + "' class='" + filteredType.buttons[index].cssClass + "' " + ngClick + ">" + filteredType.buttons[index].displayText + "</button>";
      else
        base.footer += "<button tab-index='1' focus-ok='" + filteredType.buttons[index].focus + "' class='btn btn-default' " + ngClick + ">" + filteredType.buttons[index].displayText + "</button>";
    }

  };

})();