(function(app, localStorage) {
  'use strict';

  /**
   Configures the translation provider.
   */
  app.ng.config(function($translateProvider) {
    // use our custom loader.
    $translateProvider.useLoader('translateLoaderSvc');

    // set escape strategy.
    $translateProvider.useSanitizeValueStrategy('escapeParameters');

    // show the english text if any translations are missing.
    
    $translateProvider.fallbackLanguage('en');

    // start off using the language previously selected by the user.
    var storedCulture = localStorage.getItem('user.preferences.cultureName');
    if(storedCulture) {
      $translateProvider.preferredLanguage(storedCulture);
    } else {
      // fall back to the browser preferences.
      $translateProvider.determinePreferredLanguage();
    }

  });

  app.ng.config(function (tmhDynamicLocaleProvider) {
    
    tmhDynamicLocaleProvider.localeLocationPattern('https://cdnjs.cloudflare.com/ajax/libs/angular-i18n/1.4.6/angular-locale_{{locale}}.min.js');
  });

})(window.app, window.localStorage);