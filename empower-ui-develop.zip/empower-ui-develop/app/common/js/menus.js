﻿(function (app) {
  'use strict';
  // Need to move the functions below to MenuService.js
  /* menu(s) for home page */
  //moved all the functions to MenuService.js,has to be removed/delete this file after code review(EMPO-8448)

  app.factory('Menus', ['$q', 'session', 'medseekApi', 'iFrameDetectorSvc', 'MenuService', function (q, session, api, iFrameDetector, MenuService) {

    var Menus = {};
    var deferred = q.defer();

    /* get top menus */
    var getTopMenus = function (isTopMenuNavigationEnabled) {
      return (isTopMenuNavigationEnabled) ? [{ order: 1, icon: 'home', menuName: 'Home', route: '/', isVisible: true, selected: 'top-menu-selected' },
          { order: 2, icon: 'envelope-o', menuName: 'My Messages', route: '/message-center', isVisible: true, selected: 'top-menu-normal' },
          { order: 3, icon: 'flag', menuName: 'Notifications', count: 3, isShowCount: true, route: '/notification-center', isVisible: true, selected: 'top-menu-normal' },
          { order: 4, icon: 'star', menuName: 'My Favorites', count: 3, route: 'my-favourites', isVisible: true, selected: 'top-menu-normal' }
      ] : [];
    };

    /* get patient routes */
    var getPatientRoutes = function () {
      return [
              { moduleId: 'Profile', route: '/view-edit-profile', icon: 'edit_profile', hideForMobile: true, Permission: ['{{patientId}}.patient-management'], isUserNav: false },
              { moduleId: 'ToDos', route: '/to-dos', icon: 'to_dos', hideForMobile: true, isUserNav: false },
              { moduleId: 'MessageCenter', route: '/message-center', icon: 'messages', hideForMobile: false, Permission: ['message-center'], isUserNav: true },
              { moduleId: 'CareCommunity', route: '/care-community', icon: 'care_community', hideForMobile: true, isUserNav: false },
              { moduleId: 'ActivityLog', route: '/activity-log', icon: 'activity_log', hideForMobile: true, isUserNav: false },
              { moduleId: 'Goal', route: '/goals', icon: 'goals', hideForMobile: true, isUserNav: false },
              { moduleId: 'AppointmentRequest', route: '/appointments', icon: 'appointments', hideForMobile: false, Permission: ['{{patientId}}.appointments'], isUserNav: false },
              { moduleId: 'eVisits', route: '/eVisits', icon: 'evisits', hideForMobile: false, Permission: ['{{patientId}}.evisits.view'], isUserNav: false },
              { moduleId: 'RequestCenter', route: '/request-center', icon: 'my_requests', hideForMobile: false, Permission: ['request-center'], isUserNav: true },
              { moduleId: 'EducationCenter', route: '/education-center', icon: 'education_center', hideForMobile: true, isUserNav: false },
              { moduleId: 'Mhr', route: '/my-health-information', icon: 'health_information', hideForMobile: false, Permission: ['{{patientId}}.health-information'], isUserNav: false },
              { moduleId: 'UserSettings', route: '/user-settings', icon: 'settings', hideForMobile: false, Permission: ['user-settings'], isUserNav: true },
              { moduleId: 'iframe', route: '/content/{{moduleInstanceId}}/{{name}}', hideForMobile: false, Permission: ['*'], isUserNav: true }
      ];
    };

    /* get staff routes */
    var getStaffRoutes = function () {
      return [
              { moduleId: 'MessageCenter', route: '/message-center', icon: 'messages', Permission: ['message-center'], isUserNav: true },
              { moduleId: 'TaskCenter', route: '/task-center', icon: 'task_center', Permission: ['task-center'], isUserNav: false },
              { moduleId: 'Reporting', route: '/report', icon: 'reporting', Permission: ['reports.analytic-reports.full-access'], isUserNav: false },
              { moduleId: 'UserManagement', route: '/user-management', icon: 'user_management', Permission: ['user-management'], isUserNav: false },
              { moduleId: 'UserSettings', route: '/user-settings', icon: 'settings', Permission: ['user-settings'], isUserNav: true },
              { moduleId: 'iframe', route: '/content/{{moduleInstanceId}}/{{name}}', hideForMobile: false, Permission: ['*'], isUserNav: false }
      ];
    };

    /* populates the patient navigation items with route data */
    var populatePatientMenus = function (data, ecoAppMenus, patientFirstName, patientId) {
      var patientMenus = [];
      var tempPatientMenus = [];
      angular.forEach(data.results, function (patientMenu) {

        if (patientMenu.PageType.toUpperCase() === 'STATIC') {
          getStaticMenues(patientMenu, tempPatientMenus);
          return;//skip second loop
        }
        angular.forEach(getPatientRoutes(), function (route) {
          if (patientMenu.ModuleId && patientMenu.ModuleId.trim().toUpperCase() === route.moduleId.trim().toUpperCase()) {
            patientMenu.Name = patientMenu.Name;
            patientMenu.Icon = route.icon;
            patientMenu.Route = route.route.replace('{{name}}', patientMenu.Name).replace('{{moduleInstanceId}}', patientMenu.ModuleInstanceId);
            patientMenu.isUserNav = route.isUserNav;
            patientMenu.Permission = _.map(route.Permission, function (p) { return p.replace('{{patientId}}', patientId || ''); });
            tempPatientMenus.push(patientMenu);
          }
        });
      });
      MenuService.updateRouteTitles(tempPatientMenus);
      ecoAppMenus.navigation = tempPatientMenus;
    };

    /* populates the staff navigation items with route data */
    var populateStaffMenus = function (data, ecoAppMenus) {
      var staffMenus = [];
      var tempStaffMenus = [];
      angular.forEach(data.results, function (staffMenu) {
        if (staffMenu.PageType.toUpperCase() === 'STATIC') {
          getStaticMenues(staffMenu, tempStaffMenus);
          return;//skip second loop
        }
        angular.forEach(getStaffRoutes(), function (route) {
          if (staffMenu.ModuleId && staffMenu.ModuleId.trim().toUpperCase() === route.moduleId.trim().toUpperCase()) {
            staffMenu.Name = staffMenu.Name;
            staffMenu.Icon = route.icon;
            staffMenu.Route = route.route.replace('{{name}}', staffMenu.Name).replace('{{moduleInstanceId}}', staffMenu.ModuleInstanceId);
            staffMenu.Permission = route.Permission;
            staffMenu.isUserNav = route.isUserNav;
            tempStaffMenus.push(staffMenu);
          }
        });
      });

      MenuService.updateRouteTitles(tempStaffMenus);

      ecoAppMenus.navigation = tempStaffMenus;
    };

    function addIFrameHostParam(req) {
      var iFrameHost = iFrameDetector.detectIFrameHost();
      if (iFrameHost) {
        req.iFrameHost = iFrameHost;
      }
    }

    function getStaticMenues(menu, tempMenus) {

      menu.Name = menu.Name;
      menu.Icon = '';
      menu.Route = '/static-page/' + menu.ContentId;
      tempMenus.push(menu);
    }


    /* get patient default left menus */
    Menus.getPatientDefaultLeftMenus = function (isSelfPatient, patientName, noOfLinkedPatients) {

      if (isSelfPatient || (!isSelfPatient && noOfLinkedPatients <= 1)) {
        return {
          navigation: [
            { ModuleId: 'Profile', Name: 'View ' + patientName + ' Profile', PageTarget: 'self', ModuleInstanceId: '0', Route: '/view-edit-profile', Icon: 'edit_profile', hideForMobile: false, isUserNav: true },
            { ModuleId: 'ConnectToNewPatient', Name: 'Add Patient', PageTarget: 'self', ModuleInstanceId: '0', Route: '/connect-to-new-patient', Icon: 'plus-square', hideForMobile: true, isUserNav: false }
          ]
        };
      }
      else {
        return {
          navigation: [
            { ModuleId: 'Profile', Name: 'View ' + patientName + ' Profile', PageTarget: 'self', ModuleInstanceId: '0', Route: '/view-edit-profile', Icon: 'edit_profile', hideForMobile: false, isUserNav: true },
            { ModuleId: 'SwitchPatient', Name: 'Switch Patient', PageTarget: 'self', ModuleInstanceId: '0', Route: '/switch-patient', Icon: 'anchor', hideForMobile: false, isUserNav: false },
            { ModuleId: 'ConnectToNewPatient', Name: 'Connect with New Patient', PageTarget: 'self', ModuleInstanceId: '0', Route: '/connect-to-new-patient', Icon: 'plus-square', hideForMobile: true, isUserNav: false }
          ]
        };
      }
    };

    /* get user default menus */
    Menus.getUserDefaultMenus = function (isStaffUser) {

      var results = {
        navigation: [
          /*{ ModuleId: 'MessageCenter', Name: 'My Messages', PageTarget: 'self', ModuleInstanceId: '0', Route: '/message-center', Icon: 'envelope', hideForMobile: false, Permission: ['message-center.messages.view'] }
          { ModuleId: 'Favorites', Name: 'My Favorites', PageTarget: 'self', ModuleInstanceId: '0', Route: '/favorites', Icon: 'star', hideForMobile: true },
          { ModuleId: 'Community', Name: 'My Community', PageTarget: 'self', ModuleInstanceId: '0', Route: '/community', Icon: 'group', hideForMobile: true },
          { ModuleId: 'AccountActivity', Name: 'My Account Activity', PageTarget: 'self', ModuleInstanceId: '0', Route: '/account-activity', Icon: 'user-md', hideForMobile: true },
          { ModuleId: 'Appointments', Name: 'Appointments', PageTarget: 'self', ModuleInstanceId: '0', Route: '/appointments', Icon: 'list-alt', hideForMobile: false },
          { ModuleId: 'UserSettings', Name: 'My Settings', PageTarget: 'self', ModuleInstanceId: '0', Route: '/user-settings', Icon: 'cogs', hideForMobile: false, Permission: ['user-settings'] }*/
          //{ ModuleId: 'Announcement', Name: 'Announcement', PageTarget: 'self', ModuleInstanceId: '0', Route: '/announcements', Icon: 'cogs' }
        ]
      };

      // if (isStaffUser){
      //   results.navigation.splice(1,1);
      //   results.navigation.push({ ModuleId: 'UserManagement', Name: 'User Management', PageTarget: 'self', ModuleInstanceId: '0', Route: '/user-management', Icon: 'group' });
      // }
      return results;

    };

    Menus.getPatientEcoAppMenusPreloaded = function (isSelfPatient, patientName, patientId, noOfLinkedPatients, menuData) {
      var ecoAppMenus = {};
      var userId = session.get('userId');
      var req = { userId: userId, patientId: patientId };
      addIFrameHostParam(req);
      populatePatientMenus(menuData, ecoAppMenus, (isSelfPatient) ? '' : patientName, patientId);
      return ecoAppMenus;
    };

    Menus.getPatientEcoAppMenus = function (isSelfPatient, patientName, patientId, noOfLinkedPatients) {
      var ecoAppMenus = {};
      Menus.getNavigations(patientId)
     .then(function (data) {
       populatePatientMenus(data, ecoAppMenus, (isSelfPatient) ? '' : patientName, patientId);
       deferred.resolve(ecoAppMenus);
     }, function (response) {
       deferred.reject(response.data.developerMessage);
     });
      MenuService.setMenus(deferred.promise);
      return deferred.promise;
    };

    Menus.getStaffEcoAppMenus = function () {
      var ecoAppMenus = {};
      Menus.getNavigations()
     .then(function (data) {
       populateStaffMenus(data, ecoAppMenus);
       deferred.resolve(ecoAppMenus);
     }, function (response) {
       deferred.reject(response.data.developerMessage);
     });

      return deferred.promise;
    };

    /* 
      gets the navigation items for the current user from the API.  
      patientId param is optional. 
    */
    Menus.getNavigations = function (patientId) {
      var userId = session.get('userId');
      var req = { userId: userId };
      addIFrameHostParam(req);
      if (patientId) {
        req.patientId = patientId;
        return api.userPatientNavigations.get(req).$promise;
      }
      return api.userNavigations.get(req).$promise;
    }




    return Menus;
  }]);
})(window.app);
