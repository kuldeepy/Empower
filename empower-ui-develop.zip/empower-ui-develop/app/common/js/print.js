﻿'use strict';

var Facsimile = function () {

  /* get contents to print */
  this.getContentsToPrint = function (dataCollection) {
    var printData = '<table class="table btn-sm table-bordered" border="1"> <thead>';

    if (dataCollection.length > 0)
      for (var column in dataCollection[0])
        printData += '<th>' + column + '</th>';

    printData += '</thead> <tbody>';

    for (var row = 0; row < dataCollection.length; row++) {
      printData += '<tr>';
      for (var column in dataCollection[row]) {
        printData += '<td>' + dataCollection[row][column] + '</td>';
      }
      printData += '</tr>';
    }

    printData += '</tbody> </table>';

    return printData;
  };

  /* get contents to print text */
  this.getContentsToPrintText = function (dataCollection) {
    var printData = '<table class="table btn-sm table-bordered" border="1"> <thead>';

    printData += '<tbody>';
    for (var row = 0; row < dataCollection.length; row++) {
      printData += '<tr></br><b>Report</b></br><span>' + dataCollection[row].Report + '</span>';
      printData += '<b>Notes</b><span>' + dataCollection[row].Notes + '</span></tr>';      
    }
    printData += '</table>';

    return printData;
  };  

  /* get specific contents to print */
  this.getSpecificContentsToPrint = function (details) {
    var printDetails = '';
    if (details.length > 0) printDetails += '<table class="table btn-sm table-bordered"  border="1"> <tbody>';

    angular.forEach(details, function (detail) {
      if (detail.key !== undefined) printDetails += '<tr> <td>' + detail.key + '</td> <td>' + detail.value + '</td> </tr>';
    });

    printDetails += '</tbody> </table>';
    return printDetails;
  };

  this.getTrendedChart = function (data) {
    return '<div>' + data + '</div>';
  };

  /* get specific contents to print */
  this.getSpecificContentsToPrintWithAddOn = function (details, addOn) {
    var printDetails = '';
    if (details.length > 0) printDetails += '<table class="table btn-sm table-bordered"  border="1"> <tbody>';

    angular.forEach(details, function (detail) {
      if (detail.key !== undefined) printDetails += '<tr> <td>' + detail.key + '</td> <td>' + detail.value + '</td> </tr>';
    });
    printDetails += '</tbody> </table>';
    printDetails += '<br/><br/>';
    printDetails += 'Table With Results';
    printDetails += addOn;   
    return printDetails;
  };

  /* get specific contents to print */
  this.getSpecificContentsToPrintWithTrendChart = function (addOn, chart,legendHtml) {
    var printDetails = '';
    if (legendHtml !== undefined && legendHtml != '') {
        printDetails += legendHtml;
        printDetails += '<br/><br/>';
    }
    //printDetails += '<h2>Test Result Observation Trend Section</h2>';
    printDetails += chart;  
    printDetails += '<br/><br/>';
    printDetails += addOn;   
    return printDetails;
  };

  this.getJSDateFormat = function (dateFormat, date) {
    var jsDateFormat = '';
    if ((date) && date !== '') {
      switch (dateFormat) {
        case 'YYYY':
          jsDateFormat = moment(date).format('YYYY');
          break;
        case 'MM/YYYY':
          jsDateFormat = moment(date).format('MM/YYYY');
          break;
        case 'MM/DD/YYYY':
          jsDateFormat = moment(date).format('MM/DD/YYYY');
          break;
        case 'MM/DD/YYYY hh:mm':
          jsDateFormat = moment(date).format('MM/DD/YYYY hh:mm A');
          break;
        default:
          jsDateFormat = date;
          break;
      }
    }
    return jsDateFormat;
  };
  
  /* set data to print with/without preview options */
  this.setPrintData = function (data, title, isPreview, portalName) {
      var printWindow = window.open();
      angular.element('.tooltip').hide();
      var headerText = (portalName !== undefined && portalName !== '') ? portalName : 'MEDSEEK - Empower';
      printWindow.document.write('<html><head><title>' + headerText + ' (' + title + ')</title>');
      printWindow.document.write("<style type='text/css'> body {font-family: 'Helvetica Neue',Helvetica,Arial,sans-serif;font-size: 14px;line-height: 1.42857143;color: #333; background-color: #fff;  } .table{ border-collapse: collapse;width:100%; } .table tr td { padding: 8px;line-height: 1.42857143; } .table tr th { padding: 8px;line-height: 1.42857143;background: #f7f7f7; } </style>");

      printWindow.document.write('</head><body>');
      printWindow.document.write('<br/>');
      printWindow.document.write('<h2>' + title + '</h2>');
      printWindow.document.write('<br/><br/>');
      printWindow.document.write(data);
      printWindow.document.write('</body></html>');
      printWindow.print();
      printWindow.close();

      //location.reload();
  };
 
};
