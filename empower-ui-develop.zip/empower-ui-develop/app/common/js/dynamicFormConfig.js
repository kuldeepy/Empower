
(function (app) {
  'use strict';

  app.config(['dynamicFormsProvider', function(dynamicFormsProvider){
    // filter mappings
    dynamicFormsProvider.mapFilter('Required', 'ng-required');

    // /* error message values:
    //  * viewValue - the value of the form field
    //  * filterValue - the value of the filter attribute
    //  * form - the dynamic form entity
    //  * field - the form field entity
    // */
    dynamicFormsProvider.mapError('CreditCard', 'VALID_CARD_NUMBER_REQD');
    dynamicFormsProvider.mapError('ExpirationPart', 'FIELD_REQD');
    dynamicFormsProvider.mapError('required', 'FIELD_REQD');
    dynamicFormsProvider.mapError('email', 'VALID_EMAIL_REQD');
    dynamicFormsProvider.mapError('MaxLength', 'MAXLENGTH_REQD');
    dynamicFormsProvider.mapError('MinLength', 'MINLENGTH_REQD');
    dynamicFormsProvider.mapError('Retype', 'RETYPE_REQD');
  }]);

  // field label filter, for use with Retype validator

  app.filter('fieldLabel', function () {
    return function (fieldName, form) {
      for(var i = 0; i < form.fields.length; i++) {
        if(form.fields[i].name === fieldName) {
          return form.fields[i].label;
        }
      }
      return '';
    };
  });

}(window.app));
