
'use strict';

(function () {

  // container for data to be used for validate purpose
  var validate = {};
  window.validate = validate;
  validate.dynamicData = new Array(100);
  validate.http = '';
  validate.q = '';
  validate.compareObject = {};

  app.ng.run(['$rootScope', '$http', function (rootScope, http, q) {
    rootScope.validate = validate;
    validate.http = http;
  }]);

})(window.app);