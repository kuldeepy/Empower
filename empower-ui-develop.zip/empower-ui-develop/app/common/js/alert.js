﻿'use strict';

var Memo = function (scope) {

  var transition = 'slow';

  /* error/success/information messages */
  this.messages = [];

  /* set slider for container */
  this.setSlider = function (sliderClass, isError) {

    $(sliderClass).slideDown(transition);
    this.toggleAlert = true;

    setTimeout(function () {

      $(sliderClass).slideUp(transition);
      this.toggleAlert = false;

    }, isError ? 10000 : 20000);

  };

  /* get messages */
  this.getMessages = function () {
    var messageCollection = '';

    angular.forEach(this.messages, function (message) {
      messageCollection += '<div>' + message + '</div>';
    });

    return messageCollection;
  };

  /* get message container */
  this.getMessageContainer = function (parentClass, childClass, isError) {

    var sliderClass = (scope.isParent) ? parentClass : childClass;
    this.setSlider(sliderClass, isError);

    return isError
      ? '<div class="' + sliderClass.slice(1) + ' col-md-12 padding alert alert-danger margin-top"><div class="col-md-12 padding-reset"><div class="">' + this.getMessages() + '</div></div></div>'
      : '<div class="' + sliderClass.slice(1) + ' col-md-12 padding alert alert-success margin-top"><div class="col-md-12 padding-reset"><div class="message-icon"><img class="margin-right" src="../../../themes/default/images/icon_success.png" /></div><div class="message-text margin-top-5">' + this.getMessages() + '</div></div></div>';
  };

  /* show message container */
  this.showContainer = function (parentClass, childClass, containerType) {

    return (parentClass.trim().length > 0 && childClass.trim().length > 0)
      ? this.getMessageContainer(parentClass, childClass, (containerType === 'error') ? true : false)
      : '<div class="col-md-12 padding-15 alert alert-info"><div class="message-icon"></div><div class="">' + this.getMessages() + '</div></div>';
  };

  /* show success message container */
  this.success = function () {
    return this.showContainer('.success-container-parent', '.success-container-child', 'success');
  };

  /* show error message container */
  this.error = function (message) {
    return this.showContainer('.error-container-parent', '.error-container-child', 'error');
  };

  /* show information message container */
  this.information = function (message) {
    return this.showContainer('', '', 'information');
  };

  this.clear = function(message){
    return message;
  };
};
