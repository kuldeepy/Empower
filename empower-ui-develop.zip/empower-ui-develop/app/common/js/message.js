
'use strict';

(function () {

  // container for data to be used for messages;
  var message = {};
  window.message = message;
  app.ng.run(['$rootScope', function (rootScope) {
    rootScope.message = message;
  }]);

  message.dialogMessages = {
    cancelConfirmMessage: 'All changes will be lost. Do you want to continue?',
    cancelUnsavedConfirmMessage: 'All changes will be lost. Do you want to cancel?',
    haveUnsavedChanges : 'You currently have unsaved changes. All changes will be lost. Do you want to continue?'
  };

  message.healthInformationController = {
    LandingPageTopTextKey: 'LandingPageTopText',
    LandingPageTopText: ''
    , DownloadAgreementDynamicTextKey: 'DownloadAgreement'
    , DownloadAgreementDynamicText: ''
    , noRecordFound: 'There are no records at this time'
    , noRecordFoundWeightAndBmi: 'There are no Weight and Bmi records at this time.'
    , noRecordFoundBloodPressure: 'There are no Blood Pressure records at this time.'
    , noRecordFoundBloodGlucose: 'There are no Blood Glucose records at this time.'
    , noRecordFoundCholesterol: 'There are no Cholesterol records at this time.'
  };

  message.medicalHistoryController = {
    informationMessage: 'Below are all of the medical history we have on file for Joyce Campbell. Please review the information for accuracy and if necessary, use the below to take an appropriate action.'
  };

  message.clinicalDocumentsController = {
      testResultesChartNoRecordMessage: 'There are no test result observations in the last @@filterType@@'
  };

  message.notFound = {
    allergies: 'There are no allergy records at this time.'
    , medications: 'There are no active medication records at this time.'
    , conditions: 'There are no condition records at this time.'
    , noPatientFound: 'There are no patient associated to you. Please connect to a patient to view health information.'
  };

  message.error = {
    blueButtonDownload: 'Unfortunately, we are not able to download your clinical data at this time. Please try again later or contact your system administrator if this continues.',
    downloadClinicalDocumnet: 'Unfortunately, we are not able to download your document at this time. Please try again later or contact your system administrator if this continues.'
  };

  message.alert = {

  };

  message.success = {

  };

  message.lockPopup = {
    popupMarkAsPrivateMessage: 'If you choose to continue, the record will be marked as private and other users with access to the patient\'s health information will no longer be able to view the record. Do you wish to continue?'
    , popupMarkAsNotPrivateMessage: 'The record is now private.'
  };
  message.deletePopup = {
    deleteMessage: 'Are you sure you want to remove this item from the patient\'s record?'
  };

  message.openEnrollmentController = {
    wizardCancelConfirm: 'All your input will be lost. Cancel anyway?'
  };

  message.taskCenterHealthRecordCtrl = {
    noMedicalRecordFound: 'There are no records available for this patient.'
  };

  message.taskCenterAssignOwnerToTaskController = {
    successTaskAssigned: 'Task has been successfully assigned to '
      , successTaskReassigned: 'Task has been successfully re-assigned from '
      , successTaskUnassigned: ' has been unassigned from this task and the task is now "Unassigned"'
      , errorTaskAssigned: 'Task has not been successfully assigned to '
      , errorTaskReassigned: 'Task has not been successfully re-assigned from '
      , errorTaskUnassigned: ' has not been unassigned from this task and the task is now "Unassigned"'
      , requireUserName: 'Please select a valid task owner and try again'
  };

  message.taskCenterNotesController = {
    errorSpecialCharacter: 'Notes field accepts only alphabets, numbers and special characters listed on the info icon. Please modify your input and resubmit.'
  };

  message.taskCenterDiscussionController = {
    confirmPopupCloseMessage: 'You have unsaved changes on this discussion. Do you want to discard them?'
    , errorSaveEmptyMessage: 'Highlighted fields are mandatory, please provide an input and submit again'
    , errorSaveEmptyComment: 'Comment is mandatory, please provide an input and save again'
    , errorSaveSpecialCharacterMessage: 'Activity field accepts only alphabets, numbers and special characters listed on the info icon'
    , errorSaveCommentsSpecialCharacterMessage: 'Comment field accepts only alphabets, numbers and special characters listed on the info icon'
    , errorSaveDiscussionNameMessage: 'Discussion Name already exist'
  };

  message.userSettingsUserInformationController = {
    imageUploadSuccessMessage: 'Your profile image has been updated successfully.'
    , removeImageConfirmMessage: 'Are you sure you want to remove the profile image?'
    , imageUploadErrorMessage: 'We are unable to upload your image at this time, please contact the system administrator.'
    , updateUserAndPatientSuccess:'Your user and patient account information have been updated successfully.'
    , passwordChangeSuccess:'Your password has been changed successfully.'
  };



  message.userSettingsCloseAccountController = {
    closeAccountConfirmMessage: 'Are you sure you would like to close your account? All links to patient records will be severed.'
  };

  message.openEnrollment = {

    welcomeMessage: 'By signing up here, you\’ll gain anytime access to your patient record and valuable services. We\’ll guide you step-by-step through the process, which is quick, easy, and secure. It should take just a few minutes to complete.'
    , haveAPin: 'A Patient Identification Number (PIN) is provided by your provider\'s office. Do you have a PIN for the patient record you would like to connect to?'
    , enterPin: 'The PIN is used to verify you are authorized to connect to this patient record. If you do not have a PIN, please select the appropriate option.'
    , validUserPinInformation: 'This PIN was generated for you, @@userName@@ to connect to your patient record. If this information is not correct, please contact your provider\'s office to get a new PIN. If this information is correct, click Next to proceed to the next step.'
    , alreadyUserNameExists: 'We\'re sorry but the username @@userName@@ is already taken by another user. Please pick another username.'
    , noPinRelationshipToPatientRecord: 'Would you like to connect to your own patient record or someone else\'s patient record?'
    , pinAlreadyUsed: 'The PIN you used is not associated to any patient records. Please verify the number and try again. If you do not have a PIN, click on the "I do not have a PIN" link below.'
    , enterEmailAddress: 'Please enter the email you would like to associate with your account.'

    , accountSetupCreateUserName: 'Please create a username. Your username may be any combination of letters and numbers and should not exceed 35 characters.'
    //, accountSetupCreateUserName:'Please create a username. Your username may be any combination of letters and numbers with NO special characters included ($$specialcharacters$$). Make sure it is something easy to remember.'
    , accountSetupCreatePassword: 'Please create a password. Your password must be at least 6 characters and may be any combination of letters and numbers, with at least ONE special character ($$specialcharacters$$).'

    , accountSetupSecurityQuestions: 'In case you lose or forget your password, these security questions will help you unlock your account.'
    , accountSetupUserDemographics: 'Please provide your information below for your user account. The patient information will be collected at a later step.'
    , accountSetupPatientDemographics: 'Please enter the following information to help us identify the patient you would like to connect to. The fields with an asterisk next to them are required'
    , success: 'You have successfully created your account! you may go to the Home Page or Take the Tour of Empower!'
    , accountSetupEmailVerification: 'For your security, we need you to confirm your email address. Please log in to your email and enter your verification code.'
    , successNoPinMyRecord: 'You have successfully created your account and submitted the request to connect with your patient record. Please give us at least 24 hours to complete your request. You may go to the Home Page or Take the Tour of Empower!'
    , challengeQuestion: 'The following steps are challenge questions to verify you are authorized to connect to this patient record. If you do not know the answers to the questions, you will not be able to connect to this patient record.'
    , verifyDemographicInformation: 'You successfully completed the challenge questions. Please take a moment to verify the following demographic information.'
    , inputClinicalInformation: 'Let\'s input some clinical information.'
    , connectToExternalSources: 'By connecting to Physicians, Locations and Pharmacies, you can set up a direct link through Empower to these people and places. Have a question about your last visit to your General Practitioner? Once connected, you can use the Request Center to route your question to your General Practitioner\'s office. Also by connecting to the appropriate people and places, you can set up, cancel or reschedule appointments, refill your prescriptions, and much more. Try it now!'
    , locations: 'The following locations are already linked to your account. If you not have any linked locations of if you would like to add another location, click the <b>Add a Location</b> button.'
    , accountSetupCreatePasswordLow: 'Password cannot start or end with a space. Password length must be greater than or equal to the configured minimum length.'
    , accountSetupCreatePasswordMedium: 'Password cannot contain username. The password must contain at least one uppercase letter, one lowercase letter and one number or special character(!,@,%,&,*).'
    , accountSetupCreatePasswordHigh: 'Password cannot contain three or more consecutive characters from username. The password must contain at least one uppercase letter, one lowercase letter and one number or special character(!,@,%,&,*).'
    , accountSetupRequiredInformationMissing: 'Please fill out all of the required information and try again.'

    ,selfPinMessages : 'This PIN was generated for you, $$UserName$$, to connect to your patient record. If this information is not correct, please contact your provider\'s office to get a new PIN. If this information is correct, click Next to proceed to the next step.'
    ,otherPinMessages : 'This PIN was generated for you, $$UserName$$, to connect to $$PatientName$$\'s patient record. If this information is not correct, please contact your provider\'s office to get a new PIN. If this information is correct, click Next to proceed to the next step.'
  };

  message.validation = {
    errorEmailAddressMandatory: 'The email you have entered is not a valid email.'
    , errorEmailConfirmEmailCompare: 'The emails do not match.'
    , errorUserNameMandatory: 'Enter Username'
    , errorPasswordMandatory: 'Enter Password'
    , errorPasswordConfirmPasswordCompare: 'Passwords do not match'
    , errorSecurityQuestion: 'Required information missing'
    , errorRequiredInformaion: 'Please fill out all of the required information and try again'
    , errorUserNameInvalid: 'The following characters are not allowed ($$specialcharacters$$). Please verify your input and try again'
    , errorEmailVerificationMandatory: 'Enter Email Verification Code'

    , errorEmailVerificationIncorrect: 'The verification code you entered is invalid. Please check the code and try again.'
    , errorEmailVerificationExpired: 'The verification code you entered is expired. Please check the code or select to resend email and try again.'
    , errorEmailVerificationNotSent : 'Unfortunately, we are unable to verify your email at this time. Please try again later or contact your system administrator if this continues.'
    , errorMinAge: 'You must be at least @@minAge@@ years old to have a portal account. Please review your date of birth and try again.'
    , errorMinAgeValidation: 'You must be at least @@minAge@@. years old to have a portal account. Please review your date of birth and try again.'
  };

  message.dynamicText = {
    termsAndCondition: { moduleName: 'Enrollment', key: 'TermsAndConditions' },
    termsAndConditionIAgree: { moduleName: 'Enrollment', key: 'TermsAndConditionsReadText' }
  };

  message.MedicalHistoryCtrl = {
    errorDateStartedMessage: 'Date Started and Date Ended cannot be prior to patient birth date '
   , errorDateStartedOnlyMeassage: 'Date Started cannot be prior to patient birth date '
   , errorDateEndedMessage: 'Date Ended should be equal or greater than Date Started'
   , errorCurrentDateMeassage: 'Date Started and Date Ended cannot be greater than Current Date '
   , errorNoValueMessage: 'Please enter a value for Date Started and try again.'
   , errorDOBViaDOD: 'Date of Death cannot be less than Date of Birth.' 
  };

  message.regExp = {

    emailRegExp : '/^[A-Za-z0-9._-]+@[A-Za-z0-9]+\\.{1}[A-Za-z]{2,4}$/'
    , userNameRegExp : '/^[A-Za-z0-9.@]*$/' 
    , passwordRegExp : '/^[A-Za-z0-9]*$/'
    , passwordLowRegExp : '/^[A-Za-z0-9]*$/'
    , passwordMediumRegExp : '/^[A-Za-z0-9!@%&*]*$/g'
    , passwordHighRegExp : '/^[A-Za-z0-9!@%&*]*$/g'

    /*created new variable for match passowrd*/
    , passwordMediumRegexForSignUp : /^[A-Za-z0-9\!\@\%\&\*]*$/
    , passwordLowRegexForSignUp : /^[A-Za-z0-9]*$/
  };

  message.type = {
    text: 'text'
   , password: 'password'
  };

  message.taskCenterDispute = {
    noRecordFound: 'The record disputed in this request has already been removed from the patient\'s health information. Click Next to complete the task.'
  };

  message.TaskCenterController = {
    taskComplete: '@@taskName@@  will be marked completed. Are you sure to continue?'
    , taskApproveSuccess: 'Task approved successfully'
    , taskApproveError: 'Task could not be Approved'
    , serverError: 'Please Contact Your System Administrator'
    , taskCompleteSuccess : 'Task was marked as completed'
    , concurrencyError: 'This task has been modified by someone else. Click \'Ok\' to refresh your current view.'
    , taskCompleteError: 'Task could not be complete.'
    , unableToFetchClinicalData: 'Unable to fetch clinical data, Please Contact Your System Administrator'
  };

  message.transmitPopupDialogCtrl = {
    messageValidationError: 'The message cannot include special characters. Please check your message and try again.'
    , EmailValidationError: 'Please enter a valid email address and try again.'
    , DirectCertifiedEmailValidationError: 'Please enter a direct certified email address and try again.'
    , transmitDocumentError: 'Unfortunately, we are not able to send your message at this time. Please try again later or contact your system administrator if this continues.'
  };

  message.class = {
    postValidationCheck: '.ng-invalid-pattern'
  };

  message.info = {
    available: 'Available',
    error: 'This email address is already used. Please provide a different email.',
    invalid: 'The email entered is not a valid email.',
    confirmEmailError: 'Email & Confirm Email address does not match.',
    confirmEmailMatch: ''
  };
    message.userNameInfo = {
    available: 'Available',
    error: 'This username is already used. Please provide a different username.',
    invalid: 'Username provided by you contains characters that are not allowed. Please verify with username criteria listed above and try again.',
    confirmEmailError: 'Email & Confirm Email address does not match',
    confirmEmailMatch: ''
  };

  message.connectPatientController = {
    noRecodFoundClinical: 'You have no @@name@@ associated with this patient record.'
  };

  message.activateUserAccount = {
    verifyUserInformation: 'Click next to activate account for this user or cancel to go back'
    , restoreConnection: 'Following users were connected to this user account at the time of its deactivation. You may choose to restore one or more of these connections and keep the last used access level or modify them. Click next to restore the selected connections or skip to notification. Cancel to abort the account activation.'
    , notifyUser: 'You may send an email notification to the user informing him about activation of his or her account.'
    , notificationMessage: 'Account for @@patient_name has been activated and @@no_of_restored_connections connection restored'
  };

  message.accessLevel = {
    headerInformation: 'You are viewing the detailed permissions defined for "Full Access". You may make changes here to setup customized permissions for user @@patient_name connecting to patient record of @@connected_patient_name'
  };

  message.optOutOfEnrollmentController = {
    enrollmentMessage: 'This Patient has not yet opted out of Enrollment. Select the checkbox below and save to Opt Out of Enrollment'
    , successOptOutEnrollmentMessage: '@@patientName@@ has been successfully marked as \'Opted Out of Enrollment\''
  };

  message.expireInvitationController = {
    successExpireInvitationMessage: 'The invitation and associated PIN has been successfully expired'
  };

  message.overrideAgeOfMajorityController = {
    successMajorityMessage: 'Changes for Age of Majority rules have been saved successfully'
  };

  message.resetSecurityAnswersController = {
    successResetAnswersMessage: 'The user\'s answers have been cleared. The user will be asked to re-establish them before they can login again'
  };

  message.activateAccountController = {
    successActivateMessage: '@@userName@@\'s account has been activated and @@connections@@ connection(s) have been restored.'
  };

  message.deactivateAccountController = {
    successDeactivateMessage: '@@userName@@\'s account has been deactivated and all connections have been severed.'
  };

  message.resendInvitationController = {
    confirmInvitationMessage: 'Resending of invitation will expire the original PIN and a new invitation and PIN will be generated. Are you sure to continue?'
    , successInvitationMessage: 'Previous invitation has been expired and a new invitation has been sent.'
  };

  message.navigationAway = {
    allNavigationAway : 'You currently have unsaved changes. All your changes will be lost. Are you sure you want to leave this page?',
    TopMenunavigationAway : ''
  };

  message.patientProfile = {
    noSelectRecordMessage: 'PATIENT_MANAGEMENT_SELECT_ATLEAST_ONE_COMPONENT',
    noSelectPersonMessage: 'PATIENT_MANAGEMENT_SELECT_PERSON',
    emergencyContact: {
      noRecordFound: '$$PatientName$$ does not have any Emergency Contacts at this time. Click the Add Emergency Contact icon to add a new Emergency Contact to $$PatientName$$\'s profile',
      deleteError: 'unable to delete patient Emergency Contact',
      deleteSuccess: '',
      addContact: 'ADD_EMERGENCY_CONTACT_TO_PROFILE',
      editContact: 'EDIT_EMERGENCY_CONTACT_IN_PROFILE',
      cancelMessage : 'Are you sure want to cancel copying of Emergency Contact?'
    },
    locations: {
      noRecordFound: '$$PatientName$$ does not have any locations at this time. Click the Add location icon to add a new location to $$PatientName$$\'s profile',
      deleteError: 'unable to delete patient location',
      deleteSuccess: '',
      addContact: 'ADD_EMERGENCY_CONTACT_TO_PROFILE',
      editContact: 'EDIT_EMERGENCY_CONTACT_IN_PROFILE'
    },
    physicians: {
      noRecordFound: '$$PatientName$$ does not have any physicians at this time. Click the Add Physician icon to add a new physician to $$PatientName$$\'s profile',
      deleteError: 'unable to delete patient physician',
      deleteSuccess: '',
      addContact: 'ADD_EMERGENCY_CONTACT_TO_PROFILE',
      editContact: 'EDIT_EMERGENCY_CONTACT_IN_PROFILE',
    },
    gauarntors: {
      noRecordFound: '$$PatientName$$ does not have any guarantors at this time. Click the Add Guarantor icon to add a new guarantor to  $$PatientName$$\'s profile.',
      deleteError: 'unable to delete patient gauarntor',
      deleteSuccess: '',
      addGuarantor: 'ADD_GUARANTOR_TO_PROFILE',
      editGuarantor: 'EDIT_GUARANTOR_IN_PROFILE',
    }
  },

  message.appointment = {
    preRegistrationFail : 'Unfortunately, we are not able to pre-register the patient for the selected appointment at this time. Please try again later or contact your healthcare provider if this continues.',
    reScheduleFail:'Unfortunately, we are not able to reschedule the patient’s appointment at this time. Please try again later or contact your healthcare provider if this continues.',
    scheduleFailForStaff:'Unfortunately, your request cannot be processed. Please try again later or contact administrator.'
  }

})(window.app);
