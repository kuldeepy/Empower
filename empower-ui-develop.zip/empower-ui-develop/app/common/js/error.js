﻿'use strict';

var ErrorMessage = function () {

  this.login = {
    userLogin: 'Unable to login. Please try again later or contact your system administrator',
    resetUser: 'Unable to reset your password. Please try again later or contact your system administrator',
    forgotUsername: 'Unable to process for forgot password. Please try again later or contact your system administrator',
    forgotPassword: 'Unable to process for forgot username. Please try again later or contact your system administrator',
    challengeQuestions: 'Unable to login with Challenge Questions . Please try again later or contact your system administrator'
  };

  this.settings = {
    tile: 'Unable to display settings page. Please try again later or contact your system administrator',
    reset: 'We are unable to change your password, please contact your system administrator',
    save: 'Unable to save changes. Please try again later or contact your system administrator'
  };

  this.termsAndCondition = {
    iAgree: 'Please confirm that you meet the minimum age requirement to create an account by checking the box below'
  }

};
