'use strict';

/* node api call */
var MedseekApiCall = function (scope, api, q) {

  /* get all locations */
  this.locations = function () {
    var deferred = q.defer();

    api.getLocations.get({}).$promise.then(function (response) {
      deferred.resolve(response.results);
    }, function (response) {
      deferred.reject(response.data.developerMessage);
    });
    return deferred.promise;
  };

  /* get all physicians */
  this.physicians = function () {
    var deferred = q.defer();

    api.getPhysicians.get({}).$promise.then(function (response) {
      deferred.resolve(response.results);
    }, function (response) {
      deferred.reject(response.data.developerMessage);
    });
    return deferred.promise;
  };

  /* get all target groups based on moduleInstanceId */
  this.targetGroups = function (moduleInstanceId) {
    var deferred = q.defer();

    api.targetGroups.getTargetGroups.get({ moduleInstanceId: moduleInstanceId }).$promise.then(function (response) {
      deferred.resolve(response.results.Retval);
    }, function (response) {
      deferred.reject(response.data.developerMessage);
    });
    return deferred.promise;
  };

  /* get all target groups Parameter */
  this.targetGroupsParameter = function () {
    var deferred = q.defer();

    api.targetGroups.getTargetGroupsParameter.get(null).$promise.then(function (response) {
      deferred.resolve(response.results);
    }, function (response) {
      deferred.reject(response.data.developerMessage);
    });
    return deferred.promise;
  };

};