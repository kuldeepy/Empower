'use strict';

(function (app) {

  app.factory('myHealthInformation',myHealthInformation);

  myHealthInformation.$inject = ['$rootScope', '$compile', '$http', '$q', 'session', '$dialogFactory', 'alertService', '$timeout', 'dialogService','$translate', 'generic', 'PatientInfoInWizardService'];

  function myHealthInformation (rootScope, compile, http, q, sessionFactory, dialog, alertServices, timeout, dialogSvc, translate, generic, PatientInfoInWizardService) {

    // container for data to be used for my health information
    var myHealthInformation = {};
    var vowelList = ['a', 'e', 'i', 'o', 'u'];

    rootScope.myHealthInformation = myHealthInformation;
    generic.dataModel = [{
      selectedData: []
    }];

    myHealthInformation.data = {
      header: ''
      , selectedRow: {}
      , selectedClass: ''
      , isAdd: true
    };
    /* variable declarations */
    myHealthInformation.controllerData = {
      dataModel: {},
      dataModelRXRN: {},
      detailedView: []
      , viewClassName: '.isView'
      , deleteClassName: '.isDelete'
      , disputeClassName: '.isDispute'
      , lockClassName: '.isLock'
      , editClassName: '.isEdit'
      , addClassName: '.isAdd'
      , printClassName: '.isPrint'
      , askQuestionClassName: '.isAskQuestion'
      , renewClassName: '.isRenew'
      , educationCenterClassName: '.isEducationCenter'
      , healthInformationClassName: '.my-heath-information-view'
      , popupConfirmationHeader: 'Confirmation'
      , updatedMessage: 'Updated'
      , updateParentMethodName: 'UPDATE_PARENT'
      , patientEnteredMessage: 'Patient Entered'
      , queryStringMrn: '?mrn='
      , sessionUserName: 'user'
      , methodNameYesClick: 'yesClick()'
      , allergyAddHeaderDescription: 'You have selected to add an {{myHealthInformation.data.DataTypeName}} record to the patient\'s profile. Please enter the information below or click on the cancel button to go back to the patient\'s {{myHealthInformation.data.DataTypeName}} page. The fields marked in red are required.'
      , isTrendResultsView: false
      , requestType: []
      , confirmationMessage: ''
      , isClinicalDocument: false
      , successMessage: ''
    };

    myHealthInformation.testFun = function (data) {

      var displayRecord = [];
      for (var k in data) {
        displayRecord.push({ key: k, value: data[k] })
      }
      return displayRecord;
    };

    /* method for reset the view in popup*/
    myHealthInformation.resetViews = function () {
      $(myHealthInformation.controllerData.viewClassName).hide();
      $(myHealthInformation.controllerData.deleteClassName).hide();
      $(myHealthInformation.controllerData.disputeClassName).hide();
      $(myHealthInformation.controllerData.lockClassName).hide();
      $(myHealthInformation.controllerData.editClassName).hide();
      $(myHealthInformation.controllerData.addClassName).hide();
      $(myHealthInformation.controllerData.printClassName).hide();
      $(myHealthInformation.controllerData.askQuestionClassName).hide();
      $(myHealthInformation.controllerData.renewClassName).hide();
      $(myHealthInformation.controllerData.educationCenterClassName).hide();
      myHealthInformation.data.isAdd = false;
    };

    //myHealthInformation.isClinicalDocumentView = false;

    function pushDefaults(defaultValues) {
      generic.dataModel = [{ selectedData: [] }];
      angular.forEach(defaultValues, function (value, fieldName) {
        generic.dataModel[0].selectedData[fieldName] = value;
      });
    };

    /* add record */
    myHealthInformation.addRecord = function (className, isadd, defaultValues) {
      alertServices.clear();
      pushDefaults(defaultValues);
      if (generic.fieldsData) {
        generic.fieldsData.changed = true;
      }
      myHealthInformation.data.selectedRow = {};
      myHealthInformation.resetViews();
      myHealthInformation.data.selectedClass = className;
      $(className).show();
      generic.displayPopup(myHealthInformation.controllerData.healthInformationClassName);
      if (myHealthInformation.data.Name === 'Medications') {
        generic.dataModel[0].selectedData.status = 'Active';
      }
    };

    /* method for assign source*/
    myHealthInformation.assignSource = function (source) {
      myHealthInformation.source = source;
    };

    /* view record */
    myHealthInformation.viewRecord = function (row) {
      if (myHealthInformation.controllerData.isClinicalDocument === true) {
        myHealthInformation.controllerData.detailedView = [];
      }
      if (myHealthInformation.data) {
        return generic.filterRecord(myHealthInformation.data.selectedRow, myHealthInformation.controllerData.detailedView, myHealthInformation.data);
      }
    }

    /* Educational Article click */
    myHealthInformation.educationalArticleClick = function (row) {
      var patient = JSON.parse(sessionFactory.get('patient'));
      var educationalArticleUrl = app.api.root + 'patients/' + patient.patientId + '/educationalInfo?Search=' + row.name + '&MedseekId=' + row.medseekRecordId + '&patientId=' + patient.patientId + '&KnowledgeSearch=true';
      http({
        method: generic.GetType,
        url: educationalArticleUrl,
        headers: {
          'Authorization': 'bearer ' + sessionFactory.get('sessionId'),
          'Content-Type': 'application/json;charset=utf-8',
        }
      }).success(function (response, status, header, config) {
        var mime = header('Content-Type');
        var file = new Blob([response], { type: mime });
        myHealthInformation.educationalArticleView = true;
        myHealthInformation.showEducationalArticleData(response);
      }).error(function (data, status, header, config) {
        generic.errorMessages.push(translate.instant('HL_UNABLE_TO_DOWNLOAD_DOCUMENT'));
        generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
      });

    };

    myHealthInformation.editRecord = function (className, row) {
      if (generic.fieldsData) {
        generic.fieldsData.changed = true;
      }
      if (myHealthInformation.actionForm && myHealthInformation.actionForm.$dirty) {
        myHealthInformation.openPopup(className, row, true);
      }
      else {
        myHealthInformation.isEditRecord(className, row);
      }
    }

    /* edit record */
    myHealthInformation.isEditRecord = function (className, row) {
      var prefix = '';
      var patient = JSON.parse(sessionFactory.get('patient'));
      if (className === '.isDispute') {
        prefix = 'DIS';
      } else if (className === '.isAskQuestion') {
        prefix = 'AAQ';
      } else if (className === '.isRenew') {
        prefix = 'RXRN';
      }
      //to get the request type and other detail from request center
      http({
        method: 'GET'
          , url: app.api.root + 'empower/requests/request-types'
      }).success(function (response) {
        myHealthInformation.controllerData.requestType = [];
        angular.forEach(response.results.Retval, function (data) {
          if (data.IdPrefix === prefix) {
            myHealthInformation.controllerData.requestType.push(data);
          };
        });
        if (myHealthInformation.controllerData.requestType[0]) {
          if (myHealthInformation.controllerData.requestType[0].Name === 'Dispute Health Information') {
            myHealthInformation.controllerData.disputeHealthInformation = true;
          }
        }
        if (myHealthInformation.controllerData.requestType.length > 0) {
          myHealthInformation.getRequestForm(patient.patientId, myHealthInformation.controllerData.requestType[0].Id);
          var uObject, pObject;
          angular.forEach(myHealthInformation.controllerData.requestType[0].ManageText, function (data) {
            uObject = JSON.parse(sessionFactory.get('userObject'))||{};
            pObject = JSON.parse(sessionFactory.get('patient'))||{};
            data.Text = data.Text.split('$$UserName$$').join(sessionFactory.get('username'));
            data.Text = data.Text.split('$$PatientName$$').join(pObject.patientName);
            data.Text = data.Text.split('$$UserFullName$$').join(sessionFactory.get('user'));
            data.Text = data.Text.split('$$UserFirstName$$').join(uObject.firstName);
            data.Text = data.Text.split('$$PatientName$$').join(pObject.patientName);
            data.Text = data.Text.split('$$PatientFirstName$$').join(pObject.patientFirstName);
            data.Text = data.Text.replace(/&nbsp;/g, ' ');
            if (data.Key === 'Confirmation Summary') {
              myHealthInformation.controllerData.confirmationMessage = data.Text;
            }
            if (data.Key === 'Request Submitted - Success Message') {
              myHealthInformation.controllerData.successMessage = data.Text;
            }
            if (data.Key === 'Staff Approval Required for New Physician') {
              myHealthInformation.controllerData.requireStaffApproval = data.Text;
            }
            if (data.Key === 'Select Physician') {
              myHealthInformation.controllerData.selectPhysician = data.Text;
            }
            if (data.Key === 'Select Location') {
              myHealthInformation.controllerData.selectLocation = data.Text;
            }
            if (data.Key === 'Terms And Conditions') {
              myHealthInformation.controllerData.termsWelcomeMessage = data.Text;
            }
            if (data.Key === 'Confirm Record') {
              myHealthInformation.controllerData.confirmRecord = data.Text;
            }
          });
          
          var injectO = {
            UserName: sessionFactory.get('username'),
            UserFullName: sessionFactory.get('user'),
            UserFirstName: uObject.firstName,
            PatientName: pObject.patientName,
            PatientFirstName: pObject.patientFirstName
          };

          switch (myHealthInformation.controllerData.requestType[0].IdPrefix) {
            case 'AAQ':
            case 'DIS':
              myHealthInformation.controllerData.confirmRecord = translate.instant('RequestCenter_ConfirmRecord_' + myHealthInformation.controllerData.requestType[0].IdPrefix, injectO);
              myHealthInformation.controllerData.selectPhysician = translate.instant('RequestCenter_SelectPhysician_' + myHealthInformation.controllerData.requestType[0].IdPrefix);
              myHealthInformation.controllerData.selectLocation = translate.instant('RequestCenter_SelectLocation_' + myHealthInformation.controllerData.requestType[0].IdPrefix);
              myHealthInformation.controllerData.successMessage = translate.instant('RequestCenter_RequestSubmittedSuccessMessage_' + myHealthInformation.controllerData.requestType[0].IdPrefix);
              break;
            case 'RXRN':
              myHealthInformation.controllerData.confirmationMessage = translate.instant('RequestCenter_ConfirmationSummary_RXRN', injectO);
              myHealthInformation.controllerData.selectPhysician = translate.instant('RequestCenter_SelectPhysician_RXRN');
              myHealthInformation.controllerData.selectLocation = translate.instant('RequestCenter_SelectLocation_RXRN');
              myHealthInformation.controllerData.successMessage = translate.instant('RequestCenter_RequestSubmittedSuccessMessage_RXRN');
              break;
          } 
        }
      }).error(function (data, status, header, config) {
        alertServices.add('danger', '', 10);
      });

      alertServices.clear();
      generic.className = className;
      myHealthInformation.setDataModel(className);
      myHealthInformation.data.selectedClass = className;
      generic.dataModel[0].selectedData = myHealthInformation.data.selectedRow = (row !== undefined) ? row : angular.copy(myHealthInformation.data.selectedRow);

      if (className === '.isEducationCenter') {
        generic.scope.getEducationArticle(myHealthInformation.data.selectedRow);
      }

      myHealthInformation.resetViews();
      myHealthInformation.data.isAdd = true;
      myHealthInformation.recompile(myHealthInformation.data.selectedClass);
      $(className).show(myHealthInformation.controllerData.editClassName);
      generic.displayPopup(myHealthInformation.controllerData.healthInformationClassName);
      if (myHealthInformation.data.selectedRow != undefined && myHealthInformation.data.Name !== 'Clinical Documents') {
        if (myHealthInformation.data.selectedRow.sectionName === 'socialHistories') {
          var nameValue = myHealthInformation.data.selectedRow.type;
        }
        else if (myHealthInformation.data.selectedRow.sectionName === 'familyHistories') {
          var nameValue = myHealthInformation.data.selectedRow.condition;
        }
        else {
          var nameValue = myHealthInformation.data.selectedRow.name;
        }
        myHealthInformation.data.header = '<dl class="dl-horizontal dt-as-left-aligned short-list">' +
        '<dt>' + translate.instant('NAME') +  '</dt>' +
        '<dd>' + (nameValue || generic.NslashA) + '</dd>' +
        '<dt>' + translate.instant('SOURCE') + '</dt>' +
        '<dd>' + (myHealthInformation.data.selectedRow.source || generic.NslashA) + '</dd>' +
        '</dl>';

      } else if (myHealthInformation.data.selectedRow != undefined) {
        myHealthInformation.data.header = '<dl class="dl-horizontal dt-as-left-aligned short-list">' +
        '<dt>' + translate.instant('TYPE') + '</dt>' +
        '<dd>' + (_.find(myHealthInformation.viewRecord(), function (item) { return item.key === 'Type' }).value || generic.NslashA) + '</dd>' +
        '<dt>' + translate.instant('SOURCE') + '</dt>' +
        '<dd>' + (myHealthInformation.data.selectedRow.source || generic.NslashA) + '</dd>' +
        '</dl>';
      }
      myHealthInformation.isTestResultsObservationsGridVisible = false;
      myHealthInformation.isTestResultsObservationsHistoryGridVisible = false;
    };
   
    myHealthInformation.getRequestForm = function (patientId, requestId) {
      var url = app.api.root + 'empower/patients/' + patientId + '/requests/' + requestId + '/request-type';
      http({
        method: 'GET'
          , url: url
      }).success(function (response) {
        if (myHealthInformation.controllerData.requestType[0].IdPrefix === 'RXRN') {
          timeout(function () { myHealthInformation.loadRenewPrescriptionDropdowns(response.results.Retval.RequestFormData); }, 500);
        } else if (myHealthInformation.controllerData.requestType[0].IdPrefix === 'AAQ') {
          myHealthInformation.controllerData.profileFormAAQ = response.results.Retval.RequestFormData;
        } else if (myHealthInformation.controllerData.requestType[0].IdPrefix === 'DIS') {
          myHealthInformation.controllerData.profileFormDIS = response.results.Retval.RequestFormData;
        } else {
          myHealthInformation.controllerData.profileForm = response.results.Retval.RequestFormData;
        }
        if (response.results.Retval.Routing !== null || response.results.Retval.Routing !== undefined) {
          myHealthInformation.controllerData.routing = response.results.Retval.Routing;
        }
      }).error(function (data, status, header, config) {
        alertServices.add('danger', '', 10);
      });
    };


    /* method for load the renew prescription data */
    myHealthInformation.loadRenewPrescriptionDropdowns = function (result) {
      var patient = JSON.parse(sessionFactory.get('patient'));
      PatientInfoInWizardService.getPharmacies(patient.patientId).then(function (response) {
        myHealthInformation.controllerData.pharmacyData = (response.length > 0 && response.results) ? response.results.Retval : response;
        var pharmacyData = {};
        pharmacyData[''] = '';
        if (response.length > 0 && response.results) {
          angular.forEach(response.results.Retval, function (record) {
            pharmacyData[record.Id] = record.Name;
          });
        }
        myHealthInformation.controllerData.pharmacies = pharmacyData;
        myHealthInformation.controllerData.profileFormRXRN = result;
        myHealthInformation.loadDynamicFormsData();
      });
    };

    /* method for load the dynamic forms data */
    myHealthInformation.loadDynamicFormsData = function () {
      angular.forEach(myHealthInformation.controllerData.profileFormRXRN.fields, function (field) {
        if (field.name === 'Pharmacy') {
          field.listItems = myHealthInformation.controllerData.pharmacies;
        }
      });

      myHealthInformation.controllerData.dataModelRXRN = {};
      for (var key in myHealthInformation.data.selectedRow) {
        if (myHealthInformation.isFormFieldPresent(key)) {
          var keyName = ((key.charAt(0).toUpperCase() + key.slice(1)) !== 'Name') ? key.charAt(0).toUpperCase() + key.slice(1) : 'Medication';
          myHealthInformation.controllerData.dataModelRXRN[keyName] = myHealthInformation.data.selectedRow[key];
        }
      }
    };

    /* method for check the form filed present in forms */
    myHealthInformation.isFormFieldPresent = function (key) {
      var dataModelCollection = ['name', 'dosage', 'dateStarted', 'comments', 'route', 'strength', 'frequency', 'pharmacy', 'prescribedBy', 'pharmacyPhone', 'quantity'];
      return _.find(dataModelCollection, function (name) {
        return key === name;
      });
    };

    myHealthInformation.setDataModel = function (className) {
      switch (className) {
        case ".isDispute":
          generic.dataModel = [{ selectedData: [] },
           { Dispute: { value: '', isRequired: true } }
          ];
          break;

        case ".isAskQuestion":
          generic.dataModel = [{ selectedData: [], physician: { value: [], isRequired: true }, location: { value: [], isRequired: true } },
            { Question: { value: '', isRequired: true } }
          ];
          break;

        case ".isRenew":
          generic.dataModel = [{ medicine: { value: [], isRequired: true } },
           { physician: { value: [], isRequired: true }, location: { value: [], isRequired: true } },
           { Comment: { value: '', isRequired: true } }
          ];
          break;

        default:
          generic.dataModel = [{ selectedData: [] }];
      }
    }

    myHealthInformation.recompile = function (className) {
      switch (className) {
        case '.isDispute':
          compile($('.ms-health-information-popup-dispute')[0])(generic.scope);
          break;
        case '.isAskQuestion':
          compile($('.ms-health-information-popup-ask')[0])(generic.scope);
          break;
        case '.isRenew':
          compile($('.ms-health-information-popup-renew')[0])(generic.scope);
          break;
        default:
      }
    }

    /* show data */
    myHealthInformation.showData = function (row) {
      myHealthInformation.resetViews();

      if (myHealthInformation.isClinicalDocumentView)
        timeout(function () { $(myHealthInformation.controllerData.viewClassName).show(); }, 10);
      else
        $(myHealthInformation.controllerData.viewClassName).show();

      myHealthInformation.data.selectedClass = myHealthInformation.controllerData.viewClassName;
      generic.displayPopup(myHealthInformation.controllerData.healthInformationClassName);
      myHealthInformation.data.selectedRow = row;
      myHealthInformation.selectedRowData = angular.copy(row);
      myHealthInformation.data.isAdd = true;
    };

    /* show data */
    myHealthInformation.showEducationalArticleData = function (data) {
      compile($('.educationArticleView')[0])(generic.scope);
      generic.displayPopup('.educationArticleView');
      myHealthInformation.SearchPhrase = data.results.Retval[0].SearchPhrase;
      myHealthInformation.educationalArticle = data.results.Retval[0].Contents;
    };

    /* cancel click */
    myHealthInformation.cancelClick = function () {
      /*if(location.search.indexOf('isPopup=true') > -1){
        location.search = '';
      }*/
      alertServices.clear();
      (generic.isDirtyForm) ? myHealthInformation.closePopup(myHealthInformation.controllerData.healthInformationClassName) : myHealthInformation.openPopup(myHealthInformation.controllerData.methodNameYesClick);
    };

    /* no click */
    myHealthInformation.noClick = function () {
      myHealthInformation.closePopup(myHealthInformation.controllerData.healthInformationClassName);
    };

    /* dispute ok click */
    myHealthInformation.disputeOkClick = function () {
      myHealthInformation.closePopup(myHealthInformation.controllerData.healthInformationClassName);
    };

    /* close popup */
    myHealthInformation.closePopup = function (className) {
      $(className).modal(generic.closePopupModalClassName);
      myHealthInformation.clearErrorMessage();
    };

    /* close click*/
    myHealthInformation.closeClick = function () {
     /* if(location.search.indexOf('isPopup=true') > -1){
        location.search = '';
      }*/
      if (myHealthInformation.actionForm.$dirty || generic.isDirtyForm == false) {
        myHealthInformation.openPopup(myHealthInformation.controllerData.methodNameYesClick);
      } else {
        myHealthInformation.controllerData.dataModel = {};
        myHealthInformation.closePopup(myHealthInformation.controllerData.healthInformationClassName);
        if (myHealthInformation.data.Key === 'testResults') {
          myHealthInformation.testResultInit();
        }
      }
    };

    /* open popup */
    myHealthInformation.openPopup = function (methodName, row, isEdit) {
      var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
      dialogCallback.result.then(function () {
        if (isEdit) {
          myHealthInformation.actionForm.$setPristine();
          myHealthInformation.controllerData.dataModel = {};
          myHealthInformation.isEditRecord(methodName, row);
        } else {
          myHealthInformation.actionForm.$setPristine();
          myHealthInformation.controllerData.dataModel = {};
          generic.isDirtyForm = true;
          myHealthInformation.closePopup(myHealthInformation.controllerData.healthInformationClassName);
          if (myHealthInformation.data.Key === 'testResults') {
            myHealthInformation.testResultInit();
          }
        }
      });
    };

    /* clear error message */
    myHealthInformation.clearErrorMessage = function () {
      alertServices.clear();
      generic.successObject = [];
      generic.errorMessages = [];
      generic.alertObject.message = [];
    };

    myHealthInformation.checkDuplicateDateAndTime = function (newDate) {
      var newDate = new Date(newDate);
      angular.forEach(myHealthInformation.data.Records, function (record) {
        var recordDate = new Date(record.date);
        if (myHealthInformation.keepGoing) {

          if (myHealthInformation.isSameDateWithOutSeconds(newDate, recordDate)) {
            myHealthInformation.keepGoing = false;
          }
        }
        if (!myHealthInformation.keepGoing) {
          var message = translate.instant('HL_CANNOT_SAVE_RECORD_WITH_SAME_DATE_AND_TIME');
          alertServices.add('danger', message, 0, '', 'alert_health-information-popup');
          return;
        }
      });
    }

    myHealthInformation.isSameDateWithOutSeconds = function (date1, date2) {

      if (moment(date1).isSame(moment(date2), 'year')
        && moment(date1).isSame(moment(date2), 'month')
        && moment(date1).isSame(moment(date2), 'day')
        && moment(date1).isSame(moment(date2), 'hour')
        && moment(date1).isSame(moment(date2), 'minute')) {
        return true;
      }
      else
        return false;
    }

    /* send request */
    myHealthInformation.SendRequest = function (methodType, patient, medicalRecordUrl, methodAction, errorMethodAction) {
      var jsonData = myHealthInformation.constructJsonObject();
      if (methodType == "DELETE") {
        jsonData.isDelete = true;
        methodType = 'PUT';
      }

      myHealthInformation.keepGoing = true;
      if (methodType === 'POST') {
        var isHealthTracker = false;
        var newDate;
        switch (myHealthInformation.data.DataTypeName) {
          case 'bloodPressure':
            newDate = myHealthInformation.convertUtcToPreferredTimeZoneFormat(jsonData.data.bloodPressure.date);
            isHealthTracker = true;
            break;
          case 'bloodGlucose':
            newDate = myHealthInformation.convertUtcToPreferredTimeZoneFormat(jsonData.data.bloodGlucose.date);
            isHealthTracker = true;
            break;
          case 'cholesterol':
            newDate = myHealthInformation.convertUtcToPreferredTimeZoneFormat(jsonData.data.cholesterol.date);
            isHealthTracker = true;
            break;
          case 'weight':
            newDate = myHealthInformation.convertUtcToPreferredTimeZoneFormat(jsonData.data.weight.date);
            isHealthTracker = true;
            break;
          default:
            break;
        }
        if(isHealthTracker){
          angular.forEach(myHealthInformation.data.Records, function (record) {
            var recordDate = moment(record.date).format("YYYY-MM-DDTHH:mm:ss");
            if (myHealthInformation.keepGoing) {
              if (myHealthInformation.isSameDateWithOutSeconds(newDate, recordDate)) {
                myHealthInformation.keepGoing = false;
              }
            }
            if (!myHealthInformation.keepGoing) {
              var message = translate.instant('HL_CANNOT_SAVE_RECORD_WITH_SAME_DATE_AND_TIME');
              alertServices.add('danger', message, 0, '', 'alert_health-information-popup');
              return;
            }
          });
        }
      }

      if (myHealthInformation.keepGoing) {
        myHealthInformation.httpService(
          methodType
          , medicalRecordUrl
          , sessionFactory.get(generic.sessionIdVariable)
          , jsonData)
        .then(function (success) {
          generic.scope.$emit(myHealthInformation.controllerData.updateParentMethodName, myHealthInformation.controllerData.updatedMessage);
          myHealthInformation.closePopup(myHealthInformation.controllerData.healthInformationClassName);
          myHealthInformation.clearErrorMessage();
          generic.isDirtyForm = true;
          var sectionName = generic.scope.getItemName(myHealthInformation.data);
          var message = '';

          if(jsonData.isDelete)
          {
            message = translate.instant('HL_SUCCESSFULLY_DELETED_HEALTH_RECORD', { patientName: patient.patientName, sectionName: sectionName.toLowerCase() });
          }
          else
          {
            message = translate.instant('HL_SUCCESSFULLY_SAVED_HEALTH_RECORD', { patientName: patient.patientName, sectionName: sectionName.toLowerCase() });
          }
          
          alertServices.add('success', message, 10000);
        }, function (error) {

          var message = '';

          if(jsonData.isDelete)
          {
            message = translate.instant('HEALTH_INFO_UNABLE_TO_SAVE_ERROR');
          }
          else
          {
            message = translate.instant('HEALTH_INFO_UNABLE_TO_SAVE_ERROR');
          }

          alertServices.add('danger', message, 0, '', 'alert_health-information-popup');
        });
      }
    };

    myHealthInformation.markAsPrivateDone = function () {
      myHealthInformation.closePopup(myHealthInformation.controllerData.healthInformationClassName);
      generic.scope.$emit(myHealthInformation.controllerData.updateParentMethodName, myHealthInformation.controllerData.updatedMessage);
      if (myHealthInformation.data.Key === 'testResults') {
        myHealthInformation.testResultInit();
      }
    };

    /* mark as private */
    myHealthInformation.markAsPrivate = function (patient, medicalRecordUrl, successMessage, errorMessage) {

      myHealthInformation.httpService(generic.PutType, medicalRecordUrl, sessionFactory.get(generic.sessionIdVariable), patient)
      .then(function (success) {
        myHealthInformation.clearErrorMessage();
      }, function (error) {
        alertServices.add('danger', errorMessage, 0, '', 'alert_health-information-popup');
      });
    };

    myHealthInformation.markDocumentAsPrivate = function (document, updateDocumentUrl, successMessage, errorMessage) {
      myHealthInformation.httpService(generic.PutType, updateDocumentUrl, sessionFactory.get(generic.sessionIdVariable), document)
      .then(function (success) {
        myHealthInformation.clearErrorMessage();
      }, function (error) {
        alertServices.add('danger', errorMessage, 0, '', 'alert_health-information-popup');
      });
    };

    /* mark as Read */
    myHealthInformation.markAsRead = function (patient, medicalRecordUrl) {
      myHealthInformation.httpService(generic.PutType, medicalRecordUrl, sessionFactory.get(generic.sessionIdVariable), patient)
      .then(function (success) {
        myHealthInformation.clearErrorMessage();
      });
    };

    /* get url */
    myHealthInformation.getUrl = function (currentClassName, type, patient) {
      return 'clinicalInformation/' + myHealthInformation.data.Key + ((currentClassName === type) ? generic.empty : generic.urlBackSlash + myHealthInformation.data.selectedRow.id) + myHealthInformation.controllerData.queryStringMrn + patient.mrn;
    };

    /* method for validation */
    myHealthInformation.validation = function () {

      myHealthInformation.clearErrorMessage();
      angular.forEach(generic.fieldsData.fields, function (field) {
        if (field.visible && field.required && (field.$value === undefined || field.$value.length === 0)) {
      
          generic.errorMessages.push(translate.instant('SIGNUP_REQUIRED_INFO_MISSING_ERROR'));
          alertServices.add('danger', translate.instant('SIGNUP_REQUIRED_INFO_MISSING_ERROR'), 0, '', 'alert_health-information-popup');
        }

        if (field.type === "DatePicker" && field.$value && field.filters.NoFutureDate) {
        
          if(moment(field.$value).isAfter(moment(), 'day'))
          {
            generic.errorMessages.push(translate.instant('FUTURE_DATE_IS_NOT_ALLOWED'));
            alertServices.add('danger', translate.instant('FUTURE_DATE_IS_NOT_ALLOWED'), 0, '', 'alert_health-information-popup');
          }
        }

        if (field.type === "AutoComplete" && field.$value && !field.itemSelected) {
        
          var res = myHealthInformation.data.ItemName.toLowerCase().substring(0, 1);
          var article = (vowelList.indexOf(res) > -1) ? translate.instant('AN_LBL') : translate.instant('A_LBL');
          var componentName = myHealthInformation.data.ItemName;
          componentName = generic.scope.getItemName(myHealthInformation.data)
          generic.errorMessages.push(translate.instant('HL_SELECT_FROM_SUGGESTED_VALUES', { article: article, sectionName: componentName }));
          alertServices.add('danger', translate.instant('HL_SELECT_FROM_SUGGESTED_VALUES', { article: article, sectionName: componentName }), 0, '', 'alert_health-information-popup');
        }

      });
      return (generic.errorMessages.length <= 0);
    };

    /* method for validation */
    myHealthInformation.checkRequired = function () {
      if (generic.fieldsData) {
        var requiredField = _.find(generic.fieldsData.fields, function (field) {
          return (field.visible && field.required && (field.$value === undefined || field.$value.length === 0));
        });
      }


      if (requiredField)
        return true;
      else
        false;
    };

    /* http method */
    myHealthInformation.httpService = function (type, url, sessionId, data) {
      var deferred = q.defer();
      http(
      {
        method: type,
        url: app.api.root + url,
        headers: {
          'Authorization': 'bearer ' + sessionId,
          'Content-Type': 'application/json;charset=utf-8'
        },
        data: data
      })
      .success(function (response, status, headers, config) {
        deferred.resolve(response);
      })
      .error(function (error) {
        deferred.reject(error);
      });

      return deferred.promise;
    };

    /* method to check the permissions for grid menus  */
    myHealthInformation.isShowButton = function (Buttons, source, className) {

      if (source != undefined && source.indexOf(myHealthInformation.controllerData.patientEnteredMessage) > -1) {
        return (Buttons != undefined && Buttons.selfEntered != undefined) ?
         Buttons.selfEntered[className] : false;
      }
      else {
        return (Buttons != undefined && Buttons.external != undefined) ? Buttons.external[className] : false;
      }

    };


    /* method to check the permissions whether have the access to canView, canEdit, canDelete for popup menus */
    myHealthInformation.isAccessPermission = function (Buttons, source, className) {
      if (source != undefined && source.indexOf(myHealthInformation.controllerData.patientEnteredMessage) > -1) {
        if ((myHealthInformation.data.Key === 'weights' || myHealthInformation.data.Key === 'height-weight-bmi') && className === 'canEdit') {
          return false;
        } else {
          return Buttons;
        }
      }
      else {
        return false;
      }
    }

    myHealthInformation.convertDateToUtcFormat = function (dateValue) {
      if (sessionFactory.get('userTimezone')) {
        myHealthInformation.userTimeZone = JSON.parse(sessionFactory.get('userTimezone')).MomentTimeZoneId;
      }
      var d = moment(dateValue).format().replace(moment().format('Z'),moment().tz(myHealthInformation.userTimeZone).format('Z'))
      return moment.utc(d).format("YYYY-MM-DDTHH:mm:ss");
    };

    myHealthInformation.convertUtcToPreferredTimeZoneFormat = function(dateValue){
      if (sessionFactory.get('userTimezone')) {
        myHealthInformation.userTimeZone = JSON.parse(sessionFactory.get('userTimezone')).MomentTimeZoneId;
      }
      return moment.utc(dateValue).tz(myHealthInformation.userTimeZone).format("YYYY-MM-DDTHH:mm:ss");
    };

    myHealthInformation.convertToPreferredTimeZoneDateTime = function(dateValue){
      var dateVal = new Date();
      if (sessionFactory.get('userTimezone')) {
        myHealthInformation.userTimeZone = JSON.parse(sessionFactory.get('userTimezone')).MomentTimeZoneId;
      }
      if(dateValue !== null)
      {
        dateVal = new Date(moment(dateValue).format("YYYY-MM-DDTHH:mm:ss"));
      }else{
        dateVal = new Date(moment().tz(myHealthInformation.userTimeZone).format("YYYY-MM-DDTHH:mm:ss"));
      }
      return new Date(dateVal.getUTCFullYear(), dateVal.getUTCMonth(), dateVal.getUTCDate(),  dateVal.getUTCHours(), dateVal.getUTCMinutes(), dateVal.getUTCSeconds());
    };

    /* method for construct JSON data for add, save and delete */
    myHealthInformation.constructJsonObject = function () {
      var jsonData = {};
        var clinicalData = {};

        angular.forEach(generic.dataModel[0], function (field) {
          for (var key in field) {
            var value = field[key];
            if (Object.prototype.toString.call(value) === '[object Date]') {
              clinicalData[key] = myHealthInformation.convertDateToUtcFormat(value);
            }
            else {
              clinicalData[key] = value;
            }
          }
        });
        clinicalData.source = myHealthInformation.controllerData.patientEnteredMessage + ' (' + sessionFactory.get(myHealthInformation.controllerData.sessionUserName) + ')';
        delete clinicalData.Button;
        jsonData.data = {};
        jsonData.data[myHealthInformation.data.DataTypeName] = clinicalData;
        return jsonData;
    };


    myHealthInformation.getAddDescription = function (name) {
      var headerMessage = '';
      if (myHealthInformation.data.ItemName && myHealthInformation.data.selectedClass) {
        var sectionName = generic.scope.getItemName(myHealthInformation.data);
        
        if (myHealthInformation.data.selectedClass == '.isAdd') {
          var res = myHealthInformation.data.ItemName.toLowerCase().substring(0, 1);
          var article = (vowelList.indexOf(res) > -1) ? translate.instant('AN_LBL') : translate.instant('A_LBL');
          headerMessage = translate.instant('HL_ADD_HEALTH_RECORD', { article: article, sectionName: sectionName.toLowerCase() }) + '<p class="required-field">' + translate.instant('REQUIRED_LABEL') + '</p>';
        }

        if (myHealthInformation.data.selectedClass == '.isEdit')
          headerMessage = translate.instant('HL_EDIT_HEALTH_RECORD', { sectionName: sectionName.toLowerCase() }) + '<p class="required-field">' + translate.instant('REQUIRED_LABEL') + '</p>';

        return (myHealthInformation.data.selectedClass === ".isEdit" || myHealthInformation.data.selectedClass === ".isAdd") ? headerMessage : undefined;
      }

      else {
        myHealthInformation.data.ItemName = name;
        if (myHealthInformation.data.ItemName) {
          var res = myHealthInformation.data.ItemName.toLowerCase().substring(0, 1);
          var article = (vowelList.indexOf(res) > -1) ? translate.instant('AN_LBL') : translate.instant('A_LBL');
          var sectionName = generic.scope.getItemName(myHealthInformation.data);
          headerMessage = translate.instant('HL_ADD_HEALTH_RECORD', { article: article, sectionName: sectionName.toLowerCase() }) + '<p class="required-field">' + translate.instant('REQUIRED_LABEL') + '</p>';
          return headerMessage;
        }
      }

    };


    myHealthInformation.getHealthInformationViewKey = function (viewKey) {

      var newViewKey = '';
      if (viewKey) {
        switch (viewKey.toLowerCase()) {
          case 'bloodglucoses':
            newViewKey = 'blood-glucoses';
            break;
          case 'bloodpressures':
            newViewKey = 'blood-pressures';
            break;
          case 'socialhistories':
            newViewKey = 'social-histories';
            break;
          case 'familyhistories':
            newViewKey = 'family-history';
            break;
          case 'testresults':
            newViewKey = 'test-results';
            break;
          case 'importedrecords':
            newViewKey = 'clinical-documents';
            break;
          case 'weights':
          case 'growthcharts':
            newViewKey = 'height-weight-bmi';
            break;
          case 'problems':
            newViewKey = 'conditions';
            break;
          default:
            newViewKey = viewKey;
        }
      }
      return newViewKey;

    }

    myHealthInformation.getHealthInformationViewisClinical = function (viewKey) {
      var newViewKey = '';
      if (viewKey) {
        switch (viewKey.toLowerCase()) {
          case 'clinical-documents':
          case 'importedrecords':
            newViewKey = '.dispute';
            break;
          default:
            newViewKey = '.external.dispute';
        }
      }
      return newViewKey;
    }

    myHealthInformation.replaceVariablePlaceHolders = function (dynamicText, patient, user, userName, isStaff) {
      if(isStaff){
       dynamicText = dynamicText.replace('$$StaffFirstName$$', user.firstName);
      }else{
        dynamicText = dynamicText.replace('$$StaffFirstName$$', '');
      }
      return dynamicText.replace('$$PatientName$$', patient.patientName).replace('$$PatientFirstName$$', patient.patientFirstName).replace('$$UserFirstName$$', user.firstName).replace('$$UserName$$', userName);
    }

    myHealthInformation.getMhrAccessLevelPermissions = function (key, patientId) {
      var array = [];
      if (key && patientId) {
        array = [patientId + '.health-information.' + key + '.manage',
         patientId + '.health-information.' + key + '.mark-private',
         patientId + '.health-information.' + key + '.transmit',
         patientId + '.health-information.' + key + '.download',
         patientId + '.health-information.' + key + '.renew-prescription',
         patientId + '.health-information.' + key + '.education.view',
         patientId + '.health-information.' + key + '.ask',
         patientId + '.health-information.' + key + myHealthInformation.getHealthInformationViewisClinical(key)]
      }
      return array;
    }

    myHealthInformation.getMedicalHistoryAccessLevelPermissions = function (patientId) {
      var array = [];
      if (patientId) {
        array = [patientId + '.health-information.family-history.view',
          patientId + '.health-information.social-histories.view',
        patientId + '.health-information.immunizations.view',
        patientId + '.health-information.procedures.view']
      }
      return array;
    };

    myHealthInformation.getHealthTrackersAccessLevelPermissions = function (patientId) {
      var array = [];
      if (patientId) {
        array = [patientId + '.health-information.height-weight-bmi.view',
          patientId + '.health-information.cholesterols.view',
        patientId + '.health-information.blood-pressures.view',
        patientId + '.health-information.blood-glucoses.view']

      }
      return array;
    };
    return myHealthInformation;
  }
})(window.app);
