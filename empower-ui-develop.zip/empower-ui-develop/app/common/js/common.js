'use strict';

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

(function (app) {
  // container for data to be used for generic purpose
  var generic = {};
  generic.credentials = {};

  generic.isLogout = false;

  /* declaration of variables */

  generic.characterLimit = 500;

  generic.printContents = '';

  generic.focus = '';
  generic.NslashA = 'N/A';
  generic.empty = '';
  generic.results = [];
  generic.JSONData = generic.TimeZonesJSONData = generic.TimeZoneJSONData = generic.NotificationResponse = {};
  generic.isDirtyForm = true;
  generic.isWizard = false;
  generic.popUpResult = false;
  generic.toggleAlert = false;
  generic.scope = {};
  generic.isContinue = false;
  generic.isError = false;
  generic.errorMessages = [];
  generic.activeFormName = generic.linkClicked = generic.other = '';
  generic.isSecuritySettings = false;
  generic.status = false;
  generic.portal = '';
  generic.isError = false;
  generic.http = null;
  generic.q = null;
  generic.isPasswordExpired = false;
  generic.oldPassword = '';
  generic.newPassword = '';
  generic.confirmPassword = '';
  generic.constructedObject = {};
  generic.errorMessage = '';
  generic.opensignup = [];
  generic.isSignUp = false;
  generic.dynamicFields = [];
  generic.runOnce = 1;
  generic.userName = '';
  generic.password = '';
  generic.dynamicTextMessage = '';
  generic.urlBackSlash = '/';
  generic.urlForwardSlash = '/';
  generic.isStartUp = false;
  generic.trueValue = true;
  generic.falseValue = false;
  generic.nullValue = null;
  generic.emptyString = '';
  generic.dateFieldName = 'date';
  generic.GetType = 'GET';
  generic.PostType = 'POST';
  generic.PutType = 'PUT';
  generic.dot = '.';
  generic.questionMark = '?';
  generic.closePopupModalClassName = 'hide';
  generic.enrollmentPin = "";
  generic.popupConfirmType = 'Confirm';
  generic.orderAsc = 'asc';
  generic.orderDesc = 'desc';
  generic.error = '';

  generic.sessionIdVariable = 'sessionId';
  generic.errorMessageType = 'danger';
  generic.successMessageType = 'success';
  generic.errorGlyphiconIcon = 'glyphicon glyphicon-remove-sign';
  generic.alertObject = { type: '', icon: '', message: [] };
  var errorShowHelp = 'If you are having trouble logging in to your account please contact your System Administrator using a method noted below <br/><br/> Email: systemadmin@bchs.org <br/>Phone: (205) 333-3333';

  app.ng.run(['$cacheFactory', '$rootScope', '$http', '$location', '$compile', '$q', '$cookieStore', 'httpFactory', '$dialogFactory', 'session', '$translate', function (cacheFactory, rootScope, http, location, compile, q, cookieStore, httpFactory, dialog, session, translate) {
    rootScope.generic = generic;
    generic.setData(http, location, compile, q);
    generic.cookieStore = cookieStore;
    generic.httpFactory = httpFactory;
    generic.cacheFactory = cacheFactory;

    generic.dialog = dialog;
    generic.session = session;
    generic.translate = translate;
  }]);

  generic.data = {
    http: '', scope: '', session: '', location: '', auth: '', compile: '', q: ''
  };

  generic.dataModel = {};
  generic.response = {};

  generic.setData = function (http, location, compile, q) {
    generic.data = { http: http, location: location, compile: compile, q: q }
  };

  /* sort the grid results data based on the field & direction */
  generic.sortData = function (field, direction) {
    if (!generic.results) return;
    generic.results.sort(function (a, b) {
      if (direction == "asc") {
        return a[field] > b[field] ? 1 : -1;
      } else {
        return a[field] > b[field] ? -1 : 1;
      }
    });
  };

  /* sort the array based on the field & direction */
  generic.sortArray = function (collection, field, direction, fieldIsDateType) {
    if (!collection) return;

    else if (fieldIsDateType !== true) {
      collection.sort(function (a, b) {
        if (direction == "asc") {
          return (typeof a[field] === 'string' && a[field] && b[field]) ? (a[field].toLowerCase() > b[field].toLowerCase() ? 1 : -1) : (a[field] > b[field] ? 1 : -1);
        } else {
          return (typeof a[field] === 'string' && a[field] && b[field]) ? (a[field].toLowerCase() > b[field].toLowerCase() ? -1 : 1) : (a[field] > b[field] ? -1 : 1);
        }

      });
      return collection;
    }
    else if (fieldIsDateType === true) {
      collection.sort(function (a, b) {
        if (direction == "asc") {
          return Date.parse(a[field]) > Date.parse(b[field]) ? 1 : -1;
        }
        else {
          return Date.parse(a[field]) > Date.parse(b[field]) ? -1 : 1;
        }
      });
      return collection;
    }
  };

  generic.getDashboardMenus = function () {

    generic.menus = [
    {
      "menu": "My Checkins", "count": 8, "icon": "ok", "color": "red"
      , "data": [{ "name": "Task A" }]
    },
    {
      "menu": "My Tasks", "count": 15, "icon": "list", "color": "blue"
      , "data": [
      { "name": "Joseph is added", "image": "male.png" }
      , { "name": "Jinson data is modified", "image": "male.png" }
      , { "name": "Joyce linked a patient", "image": "female.png" }
      , { "name": "Joyce linked a patient", "image": "female.png" }
      ]
    },
    {
      "menu": "My Schedule", "count": 3, "icon": "calendar", "color": "purple"
      , "data": [
      { "name": "Appointment at 9:30 a.m" }
      , { "name": "Appointment at 10:30 a.m" }
      , { "name": "Appointment at 11:00 a.m" }
      ]
    },
    {
      "menu": "Message Center", "count": 2, "icon": "envelope", "color": "green"
      , "data": [
      { "name": "Jones (staff member) is added" }
      , { "name": "Angelica (staff member) is added" }
      ]
    },
    {
      "menu": "My Goals", "count": 8, "icon": "star-empty", "color": "blue"
      , "data": [
      { "name": "Lorem ipsum dolor sit amet" }
      , { "name": "Lorem ipsum dolor sit amet" }
      , { "name": "Lorem ipsum dolor sit amet" }
      , { "name": "Lorem ipsum dolor sit amet" }
      ]
    },
    {
      "menu": "My Activity Log", "count": 35, "icon": "stats", "color": "grey"
      , "data": [
      { "name": "Jones updated address" }
      , { "name": "Micheal updated email" }
      , { "name": "Andrew updated security settings" }
      , { "name": "Dennis (patient) is added" }
      ]
    },
    { "menu": "Request Center", "icon": "question-sign", "color": "purple", "links": [{ "name": "General" }, { "name": "Appointment Request" }, { "name": "Billing" }, { "name": "Rx Renewal" }, { "name": "Referral Request" }, { "name": "Record Dispute" }] },
    { "menu": "Manage Settings", "icon": "cog", "color": "green", "links": [{ "name": "Update User Information", "url": "/user-settings/user-information" }, { "name": "Change Password", "url": "/user-settings/security-settings" }, { "name": "Change Security Questions", "url": "/user-settings/security-settings#SecurityQuestions" }, { "name": "Update My Preferences", "url": "/user-settings/preferences" }] }
    ];

    var data = [];
    var routes = app.routes;

    for (var key in app.routes) {
      var menuName = app.routes[key].title;

      for (var index = 0; index < generic.menus.length; index++) {
        var menuData = generic.menus[index];

        if (menuName.toUpperCase() == menuData.menu.toUpperCase()) {
          data.push({
            'name': menuName,
            'route': key,
            'count': menuData.count,
            'img': menuData.icon,
            'links': menuData.links,
            'data': menuData.data,
            'color': menuData.color
          });
        }
      }
    }

    return data;
  };

  generic.getMenus = function (portalName, other) {

    generic.menus = [
      { menu: "Manage Settings", "icon": "cog", "navigate": "/user-settings/user-information" },
      { menu: "My Health Information", "icon": "chevron-right", "other": true, "navigate": "/my-health-information" },
      { menu: "Task Center", "count": 15, "icon": "list", "other": true, "navigate": "/task-center" },
      { menu: "Patient Search", "icon": "chevron-right", "other": true, "navigate": "/patient-search" },
      //{ menu: "User Management", "icon": "chevron-right", "other": true, "navigate": "/user-management" }
    ];

    var data = [];
    var routes = app.routes;

    if (other !== "other") {
      for (var key in app.routes) {
        var menuName = app.routes[key].title;

        for (var index = 0; index < generic.menus.length; index++) {
          var menuData = generic.menus[index];

          if (menuName.toUpperCase() == menuData.menu.toUpperCase()) {
            data.push({
              'name': menuName,
              'route': key,
              'count': menuData.count,
              'img': menuData.icon
            });
          }
        }
      }
    }
    for (var index = 0; index < generic.menus.length; index++) {
      var menuData = generic.menus[index];

      if (menuData.other) {
        data.push({
          'name': menuData.menu,
          'route': menuData.navigate,
          'count': menuData.count,
          'img': menuData.icon
        });
      }
    }

    var output = [], keys = [];

    angular.forEach(data, function (item) {
      var key = item.name;
      if (keys.indexOf(key) === -1) {
        keys.push(key);
        output.push(item);
      }
    });

    return output;
  };

  /* show popup window */
  generic.showPopup = function ($compile) {
    $('.popup-header')[0].innerHTML = base.header;
    $('.popup-body')[0].innerHTML = base.container;
    $('.popup-footer-modal')[0].innerHTML = base.footer;
    $compile($('.popup-body')[0])(generic.scope);
    $compile($('.popup-footer-modal')[0])(generic.scope);

    $('.openGenericPopUp').modal({ 'backdrop': 'static', keyboard: false });
  };

  /* success alert  */
  generic.alert = function (form) {
    $('.success-info').slideDown('slow');
    generic.toggleAlert = true;

    setTimeout(function () {
      $('.success-info').slideUp('slow');
      generic.toggleAlert = false;
    }, 5000);
    form.$setPristine();
  };

  generic.clearSession = function (session, auth) {
    if (session === undefined) return;
    session.clear('sessionId');
    session.clear('username');
    session.clear('userId');
    session.clear('user');
    session.clear('sessionTime');
    session.clear('patient');
    session.clear('permissions');
    session.clear('userPermissions');
    session.clear('rowLevelUserPermissions');
    session.clear('currentPermissionSet');
    session.clear('current-evisit');
    session.clear('current-evisit-questions');
    session.clear('clinicalSummary');
    session.clear('emergencyAccess');
    session.clear('route');
    generic.clearSessionByKey(session, 'patientPinToConnect');
    generic.clearSessionByKey(session, 'returnUrl');
    generic.clearSessionByKey(session, 'userObject');

    generic.cookieStore.remove('searchInfo');
    generic.cookieStore.remove('iAmViewing');
    generic.cookieStore.remove('completed');

    auth.setToken(undefined);
    generic.isChallengeQuestion = false;
    generic.challengeQuestions = [];

    var $httpDefaultCache = generic.cacheFactory.get('$http');
    $httpDefaultCache.removeAll();
  };

  generic.changeTabTest = function () {
    if (generic.isDirtyForm) {
      generic.location.href = "/";
    }
  };

  /* For change first character uppercase*/
  app.filter('uppercaseFirst', function () {
    return function (str) {
      return str.replace(/^(\w)/, function (w) { return w.toUpperCase(); });
    };
  });

  /* display the success message*/
  generic.alertMessage = function (message) {
    generic.setMessageContent('success', 'glyphicon glyphicon-ok-sign');
    generic.errorMessages.push(message);
  };

  generic.closePopUp = function () {
    $('.openGenericPopUp').modal('hide');
  };

  generic.okClick = function () {
    $('.openGenericPopUp').modal('hide');
  };

  /* set error message to generic object */
  generic.setMessageContent = function (type, icon) {
    generic.alertObject = {
      type: type,
      icon: icon,
      message: generic.errorMessages
    };
    (type.trim().toUpperCase() === 'SUCCESS') ? generic.success() : generic.alert();
  };

  /* set success message to generic success object */
  generic.successMessageContent = function (message) {
    generic.successObject = {
      message: [message]
    };
    generic.success();
  };

  /* alert (error/warning) method section will be visible for 5 seconds */
  generic.alert = function () {
    $('.success-info').slideDown('slow');
    generic.toggleAlert = true;
    setTimeout(function () {
      $('.success-info').slideUp('slow');
      generic.toggleAlert = false;
    }, 5000);
  };

  /* alert (success) method - section will be visible for 20 seconds */
  generic.success = function () {
    $('.success-info').slideDown('slow');
    generic.toggleAlert = true;

    setTimeout(function () {
      $('.success-info').slideUp('slow');
      generic.toggleAlert = false;
    }, 20000);
    if (generic.form !== undefined)
      generic.form.$setPristine();
  };

  /* reset error messages */
  generic.resetErrorMessages = function () {
    generic.alertObject.message = [];
    generic.errorMessages = [];
    generic.isSecurityQuestion = false;
    generic.isResponseError = false;
  };

  generic.buildFormData = function (formData, formName) {
    var formObject = {
      name: formName,
      description: '',
      beforeUnloadWarning: false,
      fields: []
    };

    angular.forEach(formData.Fields, function (data) {
      var count = 0;
      data.Filters.Required = data.IsRequired
      formObject.fields.push({
        name: data.DataKey,
        type: data.Type,
        buttonType: data.ButtonType,
        label: generic.translate.instant(data.Label),
        className: (data.Type === "msButton") ? data.ClassName : 'form-control',
        visible: data.IsVisible,
        required: data.IsRequired,
        pattern: data.FiltersRegEx,
        filters: data.Filters,
        rowIndex: data.RowIndex,
        layout: {
          row: data.RowIndex,
          column: data.ColumnIndex
        },
        data: data.ListItems,
        listItems: data.ListItems,
        description: data.Description,
        checkDirty: data.CheckDirty,
        event: data.Event,
        eventAttribute: data.EventAttribute,
        methodType: data.MethodType,
        url: data.Url,
        headers: data.Header,
        skipUrl: data.SkipUrl,
        nextUrl: data.NextUrl,
        successMessage: data.SuccessMessage
      });

    });

    return formObject;
  };

  generic.buildSubColumnsData = function (formData, formName) {

    var formObject = {
      name: formName,
      description: '',
      beforeUnloadWarning: false,
      fields: []
    };

    angular.forEach(formData.Fields, function (data) {

      formObject.fields.push({
        name: data.DataKey,
        type: data.Type,
        buttonType: data.ButtonType,
        label: data.Label,
        className: (data.Type === "msButton") ? data.ClassName : 'form-control',
        visible: data.IsVisible,
        required: data.IsRequired,
        pattern: data.FiltersRegEx,
        filters: data.Filters,
        rowIndex: data.RowIndex,
        layout: {
          row: data.RowIndex,
          column: data.ColumnIndex
        },
        data: data.ListItems,
        description: data.Description,
        checkDirty: data.CheckDirty,
        event: data.Event,
        eventAttribute: data.EventAttribute,
        methodType: data.MethodType,
        url: data.Url,
        headers: data.Header,
        skipUrl: data.SkipUrl,
        nextUrl: data.NextUrl,
        successMessage: data.SuccessMessage
      });

    });

    return formObject;
  };

  generic.getObjectData = function (data) {
    return (data === undefined) ? null : data;
  };

  /* get buttons for user information */
  generic.getUserInformationButtons = function (model, className, label, text, rowIndex, columnIndex, eventName, methodType, url, eventAttribute, sessionId, SuccessMessage) {

    return {
      DataKey: model,
      ClassName: className,
      Type: "msButton",
      ButtonType: "button",
      Label: label,
      TextLabel: text,
      IsVisible: true,
      RequiredIfVisible: false,
      ColumnIndex: columnIndex,
      RowIndex: rowIndex,
      Event: eventName,
      MethodType: methodType,
      Url: url,
      EventAttribute: eventAttribute,
      CheckDirty: false,
      Header: {
        'Authorization': sessionId,
        'Content-Type': 'application/json;charset=utf-8'
      },
      SuccessMessage: SuccessMessage

    };
  };

  var getJSDateFormat = function (dateFormat, date) {
    var jsDateFormat = '';
    switch (dateFormat) {
      case 'YYYY':
        jsDateFormat = moment(date).format('YYYY');
        break;
      case 'MM/YYYY':
        jsDateFormat = moment(date).format('MM/YYYY');
        break;
      case 'MM/DD/YYYY':
        jsDateFormat = moment(date).format('MM/DD/YYYY');
        break;
      case 'MM/DD/YYYY hh:mm':
        jsDateFormat = moment(date).format('MM/DD/YYYY hh:mm A');
        break;
      default:
        jsDateFormat = date;
        break;
    }
    return jsDateFormat;
  };

  /* to filter record to remove unwanted fields */
  generic.filterRecord = function (items, columns, entity) {
    if (items && columns && entity) {
      var result = [], fieldValue = '', dateFormat = '';
      angular.forEach(generic.healthInformationDateFormat, function (format) {
        if (format.Key === entity.Key) {
          return dateFormat = format.DateFormat;
        }
      });

      if(items.Key == "immunizations")
      {
          items.reaction = (items.reaction == "true")? "Yes":"No";
      }


      angular.forEach(columns, function (field) {
        fieldValue = '';
        angular.forEach(items, function (value, key) {
          if (key !== 'Button' && field.DataKey === key && (field.DataKey === 'dateStarted' || field.DataKey === 'dateofbirth' || field.DataKey === 'onsetdate' || field.DataKey === 'dateofdeath' || field.DataKey === 'date' || field.DataKey === 'yearStarted' || field.DataKey === 'yearStopped')) {
            fieldValue = getJSDateFormat(dateFormat, value);
          } else if (key !== 'Button' && field.DataKey == key) {
            fieldValue = value;
          }
        });
        if (items.source) {
          if (items.source.indexOf('Patient Entered') > -1 && field.TextLabel == 'Comments' && fieldValue != null && fieldValue != '')
            result.push({ key: field.TextLabel, value: fieldValue });
          else if (field.TextLabel != 'Comments' && fieldValue != null && fieldValue != '')
            result.push({ key: field.TextLabel, value: fieldValue });
        } else if (items.source === '' && field.TextLabel != 'Comments' && fieldValue != null && fieldValue != '') {
          result.push({ key: field.TextLabel, value: fieldValue });
        }
      });

      if (columns == null || columns.length == 0)
        angular.forEach(items, function (value, key) {
          if (key !== 'Button' && (key === 'dateStarted' || key === 'dateofbirth' || key === 'onsetdate' || key === 'dateofdeath' || key === 'date' || key === 'yearStarted' || key === 'yearStopped' || key === 'effectiveDateTime' || key === 'dischargeDate' || key === 'visitDate')) {
            fieldValue = getJSDateFormat(dateFormat, value);
          } else if (key !== 'Button') {
            fieldValue = value;
          }

          key = generic.capitaliseFirstLetter(key)

          key = key.replace(/([a-z])([A-Z])/g, '$1 $2');
          if (items.displayName === 'Continuity of Care Document') {
            if (key !== 'Button' && (key === 'Source' || key === 'Type' || key === 'Date')) {
              if (key === 'Type') {
                fieldValue = fieldValue.replace(/([a-z])([A-Z])/g, '$1 $2');
              }
              if (key === 'Source') { key = 'COMM_SOURCE' };
              result.push({ key: key, value: fieldValue });
            }
          } else if (items.displayName === 'Clinical Summary') {
            if (key !== 'Button' && (key === 'Source' || key === 'Type' || key === 'Visit Date')) {
              if (key === 'Type') {
                fieldValue = fieldValue.replace(/([a-z])([A-Z])/g, '$1 $2');
              }
              if (key === 'Source') { key = 'COMM_SOURCE' };
              result.push({ key: key, value: fieldValue });
            }
          } else if (items.displayName === 'Discharge Summary') {
            if (key !== 'Button' && (key === 'Source' || key === 'Type' || key === 'Discharge Date')) {
              if (key === 'Type') {
                fieldValue = fieldValue.replace(/([a-z])([A-Z])/g, '$1 $2');
              }
              if (key === 'Source') { key = 'COMM_SOURCE' };
              result.push({ key: key, value: fieldValue });
            }
          } else if (items.displayName === 'Referral Summary') {
            if (key !== 'Button' && (key === 'Source' || key === 'Type' || key === 'Effective Date Time')) {
              if (key === 'Type') {
                fieldValue = fieldValue.replace(/([a-z])([A-Z])/g, '$1 $2');
              }
              if (key === 'Source') { key = 'COMM_SOURCE' };
              result.push({ key: key, value: fieldValue });
            }
          }
        });
    }
    return result;
  }

  /* to filter record to remove unwanted fields */
  generic.disputeFilterRecord = function (items, columns) {
    var result = [];
    angular.forEach(items, function (value, key) {
      if (key !== 'Button') {
        angular.forEach(columns, function (field) {
          if (key !== 'Button' && field.field === key) {
            result.push({ key: field.displayName, value: value });
            //result[field.displayName] = value;
          }
        });
      }
    });
    return result;
  }

  generic.isChallengeQuestion = false;

  /* set the session values */
  generic.setSession = function (response, headers, session, isUserDemographicUpdate, userData, cultureService) {
    if (!isUserDemographicUpdate) {
      session.set('sessionId', headers('Session-Id') || response.results.sessionId);
      session.set('userObject', JSON.stringify(response.results));
      session.set('user', response.results.firstName + ' ' + response.results.lastName);
      session.set('userFullName', JSON.stringify({ firstName: response.results.firstName || '', middleName: response.results.middleName || '', lastName: response.results.lastName || '', emailAddress: response.results.emailAddress || '' }));
      session.set('userId', response.results.userId);
      if (cultureService) {
        cultureService.setCulture({ key:response.results.cultureName });
      }
    } else {
      session.set('userFullName', JSON.stringify({ firstName: userData.firstName || '', middleName: userData.middleName || '', lastName: userData.lastName || '', emailAddress: (userData.emailAddress) ? userData.emailAddress : '' }));
    }
  };

  /* set the session value */
  generic.setValuesInSessionStore = function (name, data, session) {
    session.set(name, JSON.stringify(data));
  };

  /* set the session value */
  generic.getValuesInSessionStore = function (key, session) {
    return session.get(key);
  };

  /*delete session values by key*/
  generic.clearSessionByKey = function (session, key) {
    session.clear(key);
  };

  /*Handling return url*/
  generic.handleUrlFlow = function (location, gotToThisUrl, session) {
    if (gotToThisUrl) {
      location.path(app.root + gotToThisUrl);
    }
    else if (session) {
      var retUrl = generic.getValuesInSessionStore('returnUrl', session);
      if (retUrl) {
        location.path(app.root + retUrl);
      }
      else {
        location.path('/');
      }
    }
    else {
      location.path('/');
    }
  };

  /* set the session value */
  generic.storeSessionTimeOut = function (results, session) {
    var sessionTimeoutInMinutes = results.SessionTimeoutInMinutes || 2,
    absoluteSessionTimeoutInHours = results.AbsoluteSessionTimeoutInHours || 1,
    priorSessionTimeoutInMinutes = results.PriorSessionTimeoutInMinutes || 1;

    var absoluteSessionTimeout = new Date();
    absoluteSessionTimeout.setHours(absoluteSessionTimeout.getHours() + absoluteSessionTimeoutInHours);

    var obj = { 'SessionTimeoutInMinutes': sessionTimeoutInMinutes, 'AbsoluteSessionTimeoutInHours': absoluteSessionTimeout, 'PriorSessionTimeoutInMinutes': priorSessionTimeoutInMinutes };
    generic.setValuesInSessionStore('sessionTime', obj, session);
  };

  /* set cookie value */
  generic.setCookies = function (cookieValue, cookieName) {
    (cookieValue) ? generic.cookieStore.put(cookieName, cookieValue) : generic.cookieStore.remove(cookieValue);
  };

  generic.getDynamicStringByKey = function (key, moduleName) {
    var deferred = generic.data.q.defer();
    generic.httpFactory.apiPath = 'dynamicTexts/' + (moduleName || 'empower') + '/' + key;
    generic.httpFactory.headers = {
      'Content-Type': 'application/json;charset=utf-8'
    };
    generic.httpFactory.get().then(function (response) {
      generic.dynamicTextMessage = response.results.Retval;
      deferred.resolve(generic.dynamicTextMessage);
    }, function (error) {
      generic.setErrorMessage(error);
      deferred.reject(error);
    });

    return deferred.promise;
  };

  generic.getApplicationSetting = function (key) {
    var deferred = generic.data.q.defer();
    generic.httpFactory.apiPath = 'applicationSettings/' + key;
    generic.httpFactory.headers = {
      'Content-Type': 'application/json;charset=utf-8'
    };
    generic.httpFactory.get().then(function (response) {
      generic.applicationSetting = response.results;
      deferred.resolve(generic.applicationSetting);
    }, function (error) {
      generic.setErrorMessage(error);
      deferred.reject(error);
    });

    return deferred.promise;
  };

  generic.closePopup = function () {
    $('.openGenericPopUp').modal('hide');
  };

  generic.tagCase = function (name) {
    return name[0].toLowerCase() + name.substr(1).replace(/([A-Z])/g, function (match, ch) { return '-' + ch.toLowerCase(); });
  };

  /* get menus */
  generic.getMenuData = function (menuName, completedStatus, icon, startIcon) {
    return { menu: menuName, status: completedStatus, icon: icon, startIcon: startIcon };
  };

  /* set error message */
  generic.setErrorMessage = function (message) {
    generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
    generic.errorMessages.push(message);
  };


  /* set compare object */
  generic.setCompareObject = function (compareTo, compareValue) {
    generic.compareObject = { compare: compareTo, value: compareValue };
  };


  generic.validateIsRequired = function (data, dataModel) {

    var isError = false;
    var errorMessage = dataModel.defaultErrorMessage || 'Please enter the required fields!';
    if (dataModel.isRequired === true && (dataModel.value === '' || dataModel.value === undefined || dataModel.value.length === 0)) {
      generic.setErrorMessage(errorMessage);
      isError = true;
    }

    if (dataModel.compareTo !== undefined && dataModel.compareTo.trim().length > 0) {
      generic.setCompareObject(dataModel.compareTo, dataModel.value);
    }

    if (generic.compareObject !== undefined && generic.compareObject.value !== null && data === generic.compareObject.compare && dataModel.value !== generic.compareObject.value) {
      generic.setErrorMessage(dataModel.comparedWith + ' does not match');
      isError = true;
    }
    return isError;
  };

  generic.validateRequiredField = function (currentStepData, dynamicData) {
    generic.resetErrorMessages();
    if (dynamicData !== undefined) {
      angular.forEach(dynamicData.fields, function (field) {
        if (field.visible && field.required && (field.$value === undefined || field.$value.length === 0)) {
          generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
          generic.errorMessages.push(field.label + ' should be entered');
        }
      });
    } else {
      for (var data in currentStepData) {
        var dataModel = currentStepData[data];

        if (Array.isArray(dataModel)) {
          for (var data in dataModel) {
            generic.validateIsRequired(data, dataModel[data]);
          }
        }
        else
          generic.validateIsRequired(data, dataModel);
      }
    }
    return (generic.errorMessages.length === 0) ? false : true;
  };

  generic.objectLengthLegacy = function (object) {
    var length = 0;
    for (var key in object) {
      var dataModel = object[key];
      if (dataModel.postAndValidate === true) {
        ++length;
      }
    }
    return length;
  };

  /* get grid column */
  generic.getGridColumn = function (field, displayName, width, cellTemplate) {
    return { field: field, displayName: displayName, width: width, cellTemplate: cellTemplate };
  };

  /* set grid columns */
  generic.setGridColumns = function (column, gridColumns) {
    angular.forEach(gridColumns, function (gridColumn) {
      column.push(generic.getGridColumn(gridColumn.field, gridColumn.displayName, gridColumn.width, gridColumn.cellTemplate));
    });
  };

  generic.getPermissionByKey = function (permissions, type) {
    var permission;
    if (permissions !== undefined && permissions !== null) {
      angular.forEach(permissions, function (data, key) {
        if (key.toUpperCase() == type.toUpperCase()) permission = data;
      });
    }
    return permission;
  };

  generic.getGridData = function (dataValue, isCellTemplate, moduleSettingsDateFormat, actionItems) {
    var recordSet = [], data = [], headerColumn = [], subData = [], subGridHeaderColumns = [],
     subColumn = [], column = [], rowActions = {}, fieldsData = [], permissions = {}, detailedView = [];

    recordSet = dataValue;

    permissions = actionItems;
    fieldsData = generic.buildFormData(dataValue.FormEntity, dataValue.Key);
    headerColumn = generic.sortArray(dataValue.GridEntity.Columns, 'Index', 'asc');

    if (dataValue.DetailFormEntity)
      detailedView = generic.getDetailedView(dataValue.DetailFormEntity.Fields);

    subGridHeaderColumns = generic.sortArray(dataValue.GridEntity.SubColumns, 'Index', 'asc');
    subData = dataValue.SubRecords;
    rowActions = dataValue.GridEntity.RowActions;



    angular.forEach(dataValue.Records, function (record) {

      record.isclinicaldocument = false;
      if (record.documents) {
        var documents = JSON.parse(record.documents);
        var clinicalSource = _.max(documents, function (cl) {
          return cl.id !== '' && parseInt(cl.id);
        });
        record.isclinicaldocument = clinicalSource.isclinicaldocument;
        record.source = (clinicalSource.documentType === 'StructuredClinicalSummary') ? clinicalSource.physician : clinicalSource.location;
      }
      if (record.markAsPrivate === true && generic.session.get('userId') === record.markedBy) {
        data.push(record);
      }
      else if (record.markAsPrivate === false) {
        data.push(record);
      }
    });

    //var dateTimeFilter = '<div ng-show="!row.entity.Button.access.canView" >{{COL_FIELD | date : \'MM/dd/yyyy hh:mm a\'}}</div><div class="cursor-pointer" ng-show="row.entity.Button.access.canView"><a ng-click="showData(row.entity)" >{{COL_FIELD | date : \'MM/dd/yyyy hh:mm a\'}}</a></div>';
    var dateFilter = '<div ng-show="!row.entity.Button.access.canView" > {{COL_FIELD | mhrDateFilter : \'' + moduleSettingsDateFormat + '\'}}</div><div class="cursor-pointer" ng-show="row.entity.Button.access.canView"><a ng-click="showData(row.entity)" >{{COL_FIELD | mhrDateFilter :  \'' + moduleSettingsDateFormat + '\'}}</a></div>';
    var format = 'String';
    var filter = '';

    // cell template without date format
    //var dateFilter = '<div ng-show="!row.entity.Button.access.canView" >{{COL_FIELD}}</div><div class="cursor-pointer" ng-show="row.entity.Button.access.canView"><a ng-click="showData(row.entity)" tooltip="{{COL_FIELD}}" tooltip-append-to-body="true" tooltip-placement="bottom">{{COL_FIELD}}</a></div>';
    angular.forEach(headerColumn, function (data) {
      var cellTemplate = isCellTemplate;
      var dateformat = '';
      if (data.DataName == 'date' || data.DataName == 'yearStarted' || data.DataKey === 'yearStopped' || data.DataName == 'onsetdate' || data.DataName == 'dateofbirth' || data.DataName == 'dateofdeath' || data.DataName == 'dischargeDate' || data.DataName == 'visitDate') {
        //(dataValue.Group=='Health Trackers')? cellTemplate=dateTimeFilter : cellTemplate=dateFilter
        cellTemplate = dateFilter;
        dateformat = moduleSettingsDateFormat;

      }
      column.push({ field: data.DataName, dateformat: dateformat , cellTemplate: cellTemplate, displayName: data.HeaderText, width: '*' });
    });

    angular.forEach(subGridHeaderColumns, function (subData) {
      var cellTemplate = isCellTemplate;
      if (subData.DataName == 'date' || subData.DataName == 'yearStarted' || subData.DataKey === 'yearStopped' || subData.DataName == 'onsetdate' || subData.DataName == 'dateofbirth' || subData.DataName == 'dateofdeath') {
        cellTemplate = dateFilter
        format = 'Date';
        filter = '| mhrDateFilter : \'' + moduleSettingsDateFormat + '\'';
      }
      subColumn.push({ field: subData.DataName, filter: filter, format: format, cellTemplate: cellTemplate, displayName: subData.HeaderText, width: '*' });
    });

    return { data: data, column: column, subData: subData, subColumn: subColumn, rowActions: rowActions, recordSet: recordSet, fieldsData: fieldsData, permissions: permissions, detailedView: detailedView };
  };

  generic.getDetailedView = function (collection) {
    var displayedCollection = [];
    var sortedCollection = generic.sortArray(collection, 'RowIndex', 'asc');
    angular.forEach(sortedCollection, function (record) {
      if (record.IsVisible) {
        displayedCollection.push(record);
      }
    });
    return displayedCollection;
  };

  /* display popup */
  generic.displayPopup = function (className) {
    $(className).modal({ 'backdrop': 'static', keyboard: false });
    window.setTimeout(function () {
      $(className).find('input[type=search]').focus();
    }, 100);
  };

  /* close popup */
  generic.closePopup = function (className) {
    $(className).modal('hide');
  };

  generic.getNewAndOldTestResults = function (data) {
    generic.oldTestResults = [];
    generic.newTestResults = [];
    var oldTestResults = [], newTestResults = [], loggedinUserId = 1;
    if (data) {
      if (data.UserId === loggedinUserId) {
        data.Records.forEach(function (data) {
          if (data.isViewed === true) {
            generic.oldTestResults.push(data);
          }
          else {
            generic.newTestResults.push(data);
          }
        });
      }
    }
    return { oldTestResults: generic.oldTestResults, newTestResults: generic.newTestResults };
  };

  generic.buildJSONDataForWizard = function () {
    if (generic.dataModel[3].Addresses == undefined) {
      generic.dataModel[3].Addresses = [];
      generic.dataModel[3].Addresses.push({
        'AddressLine1': generic.dataModel[3].AddressLine1,
        'AddressLine2': generic.dataModel[3].AddressLine2,
        'City': generic.dataModel[3].City,
        'State': generic.dataModel[3].State,
        'Country': generic.dataModel[3].Country,
        'ZipCode': generic.dataModel[3].ZipCode,
        'Id': (generic.dataModel[3].AddressId) ? generic.dataModel[3].AddressId : '',
      })
    } else {
      generic.dataModel[3].Addresses[0].AddressLine1 = generic.dataModel[3].AddressLine1;
      generic.dataModel[3].Addresses[0].AddressLine2 = generic.dataModel[3].AddressLine2;
      generic.dataModel[3].Addresses[0].City = generic.dataModel[3].City;
      generic.dataModel[3].Addresses[0].State = generic.dataModel[3].State;
      generic.dataModel[3].Addresses[0].Country = generic.dataModel[3].Country;
      generic.dataModel[3].Addresses[0].ZipCode = generic.dataModel[3].ZipCode;
      generic.dataModel[3].Addresses[0].Id = (generic.dataModel[3].AddressId) ? generic.dataModel[3].AddressId : '';
    }

    //if (generic.dataModel[3].PhoneNumbers == undefined) {
    //  generic.dataModel[3].PhoneNumbers = [];
    //  generic.dataModel[3].PhoneNumbers.push({
    //    'PhoneNumber': generic.dataModel[3].EveningPhone,
    //    'Extension': generic.dataModel[3].EveningPhoneExt,
    //    'Id': (generic.dataModel[3].EveningPhoneId) ? generic.dataModel[3].EveningPhoneId : '',
    //    'PhoneType': 4001
    //  });
    //  generic.dataModel[3].PhoneNumbers.push({
    //    'PhoneNumber': generic.dataModel[3].DaytimePhone,
    //    'Extension': generic.dataModel[3].DaytimePhoneExt,
    //    'Id': (generic.dataModel[3].DaytimePhoneId) ? generic.dataModel[3].DaytimePhoneId : '',
    //    'PhoneType': 4002
    //  });
    //  generic.dataModel[3].PhoneNumbers.push({
    //    'PhoneNumber': generic.dataModel[3].MobilePhone,
    //    'Id': (generic.dataModel[3].MobilePhoneId) ? generic.dataModel[3].MobilePhoneId : '',
    //    'PhoneType': 4003
    //  });

    //  angular.forEach(generic.dataModel[3].PhoneNumbers, function (userPhoneData) {
    //    if (userPhoneData.PhoneType == '4001') {
    //      userPhoneData.Id = (generic.dataModel[3].EveningPhoneId) ? generic.dataModel[3].EveningPhoneId : '';
    //      userPhoneData.PhoneNumber = (generic.dataModel[3].EveningPhone) ? generic.dataModel[3].EveningPhone : '';
    //      userPhoneData.Extension = (generic.dataModel[3].EveningPhoneExt) ? generic.dataModel[3].EveningPhoneExt : '';
    //    } else if (userPhoneData.PhoneType == '4002') {
    //      userPhoneData.Id = (generic.dataModel[3].DaytimePhoneId) ? generic.dataModel[3].DaytimePhoneId : '';
    //      userPhoneData.PhoneNumber = (generic.dataModel[3].DaytimePhone) ? generic.dataModel[3].DaytimePhone : '';
    //      userPhoneData.Extension = (generic.dataModel[3].DaytimePhoneExt) ? generic.dataModel[3].DaytimePhoneExt : '';
    //    } else if (userPhoneData.PhoneType == '4003') {
    //      userPhoneData.Id = (generic.dataModel[3].MobilePhoneId) ? generic.dataModel[3].MobilePhoneId : '';
    //      userPhoneData.PhoneNumber = (generic.dataModel[3].MobilePhone) ? generic.dataModel[3].MobilePhone : '';
    //    }
    //  });
    //}


  };

  generic.capitaliseFirstLetter = function (string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  };
  app.value('generic',generic);
  
})(window.app);
