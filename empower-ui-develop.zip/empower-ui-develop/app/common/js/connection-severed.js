
  app.controller('ConnectionSeveredMessageCtrl',['$scope','severedPatient','patients','isDisableProfileImage','$location',function(scope,severedPatient,patients,isDisableProfileImage,location){
    scope.message = 'You no longer have access to ' + severedPatient.FirstName + '\'s patient record. Please contact your provider\'s office if you need further details.';
    scope.patients = patients;
    scope.isDisableProfileImage = isDisableProfileImage;

    scope.navigateToEnrollment = function(){
      scope.$close();
      location.path('/add-patient/no-pin');
    };

  }]);