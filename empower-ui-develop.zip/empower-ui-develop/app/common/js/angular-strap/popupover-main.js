﻿/**
 * angular-strap
 * @version v2.0.3 - 2014-06-23
 * @link http://mgcrea.github.io/angular-strap
 * @author Olivier Louvignes (olivier@mg-crea.com)
 * @license MIT License, http://www.opensource.org/licenses/MIT
 */
(function(window, document, undefined) {
'use strict';

// Source: popover.tpl.demo.js
angular.module('app').run([
  '$templateCache',
  function ($templateCache) {
    $templateCache.put('popover/docs/popover.tpl.demo.html', '<div class="popover" tabindex="-1">'+
  '<div class="arrow"></div>'+
  '<div class="popover-title"><span ng-bind-html="controllerData.popover.title" ng-show="controllerData.popover.title" class="pull-left"></span><span class="glyphicon glyphicon-remove-circle pull-right cursor-pointer" ng-click="$hide(); closeParent(\'isPriority\');"></span>' +
  '<div class="popover-content">' +
    '<form name="popoverForm">'+
      '<div class="col-md-12 padding-reset margin-top-20">'+
        'Would you like to change the priority of this task?' +
      '</div>'+
      '<div class="col-md-12 padding-reset margin-top-15 margin-bottom">'+
        '<div class="col-md-4 text-center" ng-click="setPriority(2)">'+
          '<div class="cursor-pointer text-decoration">'+
            '<img src="/themes/default/images/icon_high.png" width="30">'+
            '<br />'+
            '<span class="pull-left margin-top-5">High</span>' +
          '</div>'+
        '</div>'+
        '<div class="col-md-4 text-center" ng-click="setPriority(1)">'+
          '<div class="cursor-pointer text-decoration">'+
            '<img src="/themes/default/images/icon_medium.png" width="30">'+
            '<br />'+
            '<span class="pull-left margin-top-5">Normal</span>' +
          '</div>'+
        '</div>'+
        '<div class="col-md-4 text-center" ng-click="setPriority(0)">'+
          '<div class="cursor-pointer text-decoration">'+
            '<img src="/themes/default/images/icon_low.png" width="30">'+
            '<br />'+
            '<span class="pull-left margin-top-5">Low</span>' +
          '</div>'+
        '</div>'+
      '</div>'+
    '</form>'+
  '</div>'+
'</div>');
  }
]);





})(window, document);