(function (app, $, AppUtilities, angular, message) {
  'use strict';

  app.controller('MasterLayoutCtrl', ['$scope', '$q', '$http', '$location', 'auth', 'session', '$timeout', '$idle', 'api', '$dialogFactory', '$cacheFactory', 'medseekApi', 'alertService', 'dialogService', 'NotificationsService', 'styleInjector', '$rootScope', 'Menus', '$filter', 'PatientMapperService', '$interpolate', 'userPermissionsSvc', '$modal', '_', '$window', 'iFrameDetectorSvc', 'profileImage', 'messagingService', 'MenuService', 'ssoSessionSvc', '$translate', 'localStorageSvc', 'generic',
    function (scope, q, http, location, auth, session, $timeout, $idle, api, dialog, cache, msApi, alertService, dialogService, NotificationsService, styleInjector, $rootScope, Menus, $filter, patientMapper, $interpolate, userPermissionsSvc, modal, _, window, iFrameDetector, profileImage, messageSvc, MenuService, ssoSessionSvc, translate, localStorageSvc, generic) {
      /* scope variables */
      scope.isSetting = false;
      scope.isMasterHeadAll = false;
      scope.isMasterHeadLeft = false;
      scope.isMasterHeadCenter = false;
      scope.isMasterHeadRight = false;

      scope.isRightBorderAll = false;
      scope.isRightBorderTop = false;
      scope.isRightBorderMiddle = false;
      scope.isRightBorderBottom = false;

      scope.isLeftBorderAll = false;
      scope.isLeftBorderTop = false;
      scope.isLeftBorderMiddle = false;
      scope.isLeftBorderBottom = false;

      scope.isFooterAll = false;
      scope.isFooterLeft = false;
      scope.isFooterCenter = false;
      scope.isFooterRight = false;
      scope.isSwitchPatient = false;
      scope.isTopMenu = false;
      scope.currentDate = new Date();
      scope.baseMessages = { count: undefined };
      var sessionTimeOut = JSON.parse(generic.getValuesInSessionStore('sessionTime', session));
      var userId = session.get('userId');
      scope.patient = JSON.parse(session.get('patient')) || {};
      scope.patientId = scope.patient.patientId;

      scope.user = JSON.parse(session.get('userObject')) || {};
      scope.groupPredicate = 'groupOrder';
      scope.predicate = 'order';
      scope.isCollapse = false;
      scope.showPatientDropdown = false;
      scope.linkedPatientContent = '';
      generic.scope = scope;
      scope.notificationCenterDynamicTexts = {};
      scope.tourSteps = [];
      scope.linkedPatients = [];
      scope.isOpenPopUp = false;

      // Accessibility Feature. Allows screen readers to jump over the navigation to the main content area
      scope.skipToMainContent = function ($event) {
        if ($event) { $event.preventDefault(); }
        var mainContent = document.querySelector('#maincontent');
        mainContent.focus();
      };

      scope.baseLayoutData = {
        currentIndex: 0,
        sessionTimeOut: {
          type: 'Logout',
          header: 'SESSION_TIMED_OUT',
          content: scope.SessionInactivityWarning,
          addOn: '<div class="text-right form-group"><a href="" role="button" class="btn btn-primary" ng-click="yes()" translate="OK_BUTTON_LABEL"></a></div>'
        },
        isAbsoluteTimeOut: true,
        sessionInactivityTimeOut: 300,
        warningTimeOut: 60,
        sessionAbsoluteTimeOut: 1,
        isWarning: false
      };
      scope.notificationHeaderData = [];
      scope.limitNotificationSize = 5;
      scope.isSetting = false;
      scope.notificationMessage = '';
      scope.markAllRead = false;

      /* load time zone object */
      scope.getTimeZone = function () {
        http({
          method: 'GET',
          url: app.api.root + 'users/' + userId + '/settings/timezone',
          headers: {
            'Authorization': auth.getToken(),
            'Content-Type': 'application/json;charset=utf-8'
          },
        }).success(function (response) {
          session.set('userTimezone', JSON.stringify(response.results));
        });
      };

      scope.getPortalDetails = function () {
        var deferred = q.defer();
        var portalType = session.get('portal');

        http({
          method: 'GET',
          url: app.api.root + 'users/portalDetails/' + portalType,
          headers: {
            'Content-Type': 'application/json;charset=utf-8'
          },
          ignoreLoadingBar: true
        }).success(function (response) {
          deferred.resolve(response.results);
        }).error(function () { });
        return deferred.promise;
      };

      scope.handleTimeZone = function () {
        sessionTimeOut = JSON.parse(generic.getValuesInSessionStore('sessionTime', session));
        scope.getTimeZone();
        var currentAbsuluteTime = new Date(sessionTimeOut.AbsoluteSessionTimeoutInHours);
        var currentTime = new Date();
        scope.baseLayoutData.sessionAbsoluteTimeOut = currentAbsuluteTime - currentTime;
        scope.setIdleTime(scope.baseLayoutData.sessionInactivityTimeOut, scope.baseLayoutData.warningTimeOut);
        scope.absoluteTimeOut();
      };

      scope.initializeUser = function () {
        userId = scope.getUserIdFromSession();
        var route = session.get('route');
        if (route) {
          route = JSON.parse(route);
          app.routing.routeParams.moduleInstanceId = route.ModuleInstanceId;
        }

        scope.user = JSON.parse(session.get('userFullName')) || {};

        if (session.get('portal').trim().toUpperCase() === 'PATIENT') {
          scope.isStaff = false;
          scope.getPatients();
        } else {
          scope.isStaff = true;
          scope.refreshLeftMenus();
        }
        scope.regex();

        scope.handleTimeZone();

        scope.getSettingsForProfileImage();
        messageSvc.getMessagesCount().then(function (res) {
          scope.baseMessages.count = res > 0 ? res : undefined;
        });
        scope.getMessageCenterModuleSettings();
        scope.setUserImage(userId);
        var cultureName = localStorageSvc.get('cultureName');
        if (cultureName) {
          translate.use(cultureName);
        }
      };

      scope.loadEmpowerDynamicText = function () {
        translate.use(localStorageSvc.get('cultureName') || translate.preferredLanguage()).then(function () {
          translate([
               'MedSeek_Portal_Server_AuthProvider_SessionInactivityWarning',
               'MedSeek_Portal_Server_AuthProvider_AbsoluteSessionInactivityWarning',
               'MedSeek_Portal_Server_AuthProvider_LogoutSessionInactivityWarning',
               'MedSeek_Portal_Server_AuthProvider_LogoutAbsoluteSessionInactivityWarning'
          ]).then(function (values) {
            var keys = Object.keys(values);
            scope.SessionInactivityWarning = values[keys[0]];
            scope.AbsoluteSessionInactivityWarning = values[keys[1]];
            scope.LogoutSessionInactivityWarning = values[keys[2]];
            scope.LogoutAbsoluteSessionInactivityWarning = values[keys[3]];
          });
        });
      };

      /* initialize controller */
      scope.initialize = function () {
        scope.ShowLeftnav = true;
        scope.getAllPatientNotifications();
        scope.loadEmpowerDynamicText();
        if (sessionTimeOut !== null) {
          if (sessionTimeOut.SessionTimeoutInMinutes !== null) {
            scope.baseLayoutData.sessionInactivityTimeOut = (sessionTimeOut.SessionTimeoutInMinutes * 60) - (sessionTimeOut.PriorSessionTimeoutInMinutes * 60);
          }

          if (sessionTimeOut.PriorSessionTimeoutInMinutes !== null) {
            scope.counter = scope.baseLayoutData.warningTimeOut = (sessionTimeOut.PriorSessionTimeoutInMinutes * 60);
          }

          scope.fetchNotifications();

          scope.initializeUser();
          scope.getLandingPageModuleSettings();

          scope.tourSetUp();

          scope.isTopMenu = true;

          msApi.appointments.getDynamictext.get({ patientId: 0 }, null).$promise.then(function (res) {
            scope.appointmentDynamicText = res.results;
          });

          var locUrl = location.search();
          if (locUrl && locUrl.returnUrl) {
            location.url(locUrl.returnUrl);
            return;
          }

          /* for open take a tour default */
          $timeout(function () {
            var urlPath = location.path();
            if (urlPath.indexOf('tour') > 0) {
              scope.openTour();
            }
          }, 5000);

        }
      };

      scope.getLandingPageModuleSettings = function () {
        msApi.settings.landingpage.get({}, null).$promise.then(function (response) {
          scope.landingpageDisplaySetting = response.results.enableTour;
        });
      };

      scope.checkPinSettings = function (flowControl) {
        scope.pinDetails = JSON.parse(session.get('pin'));
        if (scope.pinDetails && scope.pinDetails.patient) {
          location.path('/signup/enrollment');
          return;
        }
      };

      /* get setting for profile image */
      scope.getSettingsForProfileImage = function () {
        msApi.notificationsCenter.getModuleSettingsPath.get({ moduleName: 'profile' }).$promise.then(function (response) {
          scope.isDisableProfileImage = response.results.Retval.DisableProfileImage;
        });
      };

      /* get user image */
      scope.setUserImage = function (userId) {
        api.loadUserImage.get({ userId: userId }).then(function (response) {
          profileImage.register(response.results);
          scope.user.image = profileImage.source();
          session.set('userFullName', JSON.stringify(scope.user));
        });
      };

      scope.$on('userProfilePhotoChanged', function (event, result) {
        scope.user.image = result.image;
        session.set('userFullName', JSON.stringify(scope.user));
      });

      /* set user details */
      scope.setUserProfileDetails = function (userId) {
        msApi.users.profile.get({ userId: userId }).$promise.then(function (response) {
          if (response.results) {
            scope.user.firstName = response.results.FirstName;
            scope.user.gender = response.results.Gender;
            scope.user.lastName = response.results.LastName;
            scope.user.middleName = response.results.MiddleName;
            session.set('userFullName', JSON.stringify(scope.user));
            scope.refreshLeftMenus();
          }
        });
      };
      scope.$watch('app.currentRoute', function () {
        scope.getDynamicScriptAndCss();
      });

      /* get notification center module settings */
      scope.getMessageCenterModuleSettings = function () {
        msApi.message.getModuleSettings.get({ moduleName: 'messagecenter' }, null).$promise.then(function (response) {
          scope.messageCenterDisplaySetting = response.results.Retval.ShowInTopNav && userPermissionsSvc.userHasPermission('message-center');
        });
      };

      scope.getDynamicScriptAndCss = function () {
        scope.scripts = [];
        scope.portalType = session.get('portal');
        var utilities = new AppUtilities(scope, msApi, q, http);
        utilities.getAllCssContent(scope.portalType).then(function (res) {
          if (scope.leftGroupMenus && scope.leftGroupMenus.navigation && scope.leftGroupMenus.navigation.length > 0) {
            scope.leftGroupMenus.navigation.forEach(function (leftMenu) {
              if (app.currentRoute.toLowerCase() === leftMenu.Route.toLowerCase()) {
                scope.scripts.push(utilities.getAppScriptOrStyle(leftMenu.Name, false, res));
                styleInjector.addStyle(utilities.getAppScriptOrStyle(leftMenu.Name, true, res));
              }
            });
          }
          scope.scripts.push(utilities.getGlobalScriptOrStyle(false, res));
          styleInjector.addStyle(utilities.getGlobalScriptOrStyle(true, res));
        });
      };

      /* get all notifications */
      scope.getAllNotifications = function () {
        if (scope.isSetting) {
          scope.isSetting = false;
        } else {
          scope.isSetting = true;
        }
      };

      /* calculate age */
      scope.calculateAge = function (birthMonth, birthDay, birthYear) {
        var age = 0;
        var todayDate = new Date();
        var todayYear = todayDate.getFullYear();
        var todayMonth = todayDate.getMonth();
        var todayDay = todayDate.getDate();
        age = todayYear - birthYear;
        if ((todayMonth < birthMonth - 1) || (birthMonth - 1 === todayMonth && todayDay < birthDay)) {
          age = age - 1;
        }
        return age;
      };

      /* absolute timeout */
      scope.absoluteTimeOut = function () {
        var dialogCallback, modalOpen;
        scope.absoluteWarningTimer = $timeout(function () {
          scope.baseLayoutData.isAbsoluteTimeOut = true;
          modalOpen = true;
          if (scope.sessionTimeOutPopupOpen) {
            scope.sessionDialogCallback.close();
          }
          dialogCallback = dialog.custom('customDialog', 'Absolute Timeout', scope.AbsoluteSessionInactivityWarning, '<div class="col-md-12 padding-reset margin-top"><a href="" role="button" class="btn btn-default pull-right margin-right" ng-click="no()" translate="OK_BUTTON_LABEL"></a></div>');
          dialogCallback.result.then(function () { }, function () {
            modalOpen = false;
          });
        }, (scope.baseLayoutData.sessionAbsoluteTimeOut) - 60000);

        scope.absoluteLogoutTimer = $timeout(function () {
          if (modalOpen) {
            dialogCallback.close();
          }
          scope.NavigateTo(scope.LogoutAbsoluteSessionInactivityWarning);
        }, (scope.baseLayoutData.sessionAbsoluteTimeOut));
      };

      /* method to restrict special character for save search */
      scope.restrictSpecialCharacters = function (data) {
        return data.replace(/[^a-z\d\s]+/gi, '');
      };

      /* get path */
      scope.unbindWatch = scope.$watch(function () {
        return location.path();
      }, function (val) {
        $('.modal-backdrop').css('display', 'none');

        var params = location.search();
        if (params.token) {
          auth.useToken(params.token, params.portal, app.currentRoute).then(function () {
            scope.initializeUser();
          });
        }

        if (auth.hasToken()) {
          generic.isDirtyForm = true;
          scope.currentView = val.substr(app.currentRoute.length + 1);
        } else {
          if (window.location.search === '?p=staff') {
            session.set('portal', 'staff');
          } else {
            session.set('portal', 'patient');
          }
          var queryString = '?returnUrl=' + window.location.pathname;
          var navigateTo = '/login/' + (session.get('portal') || 'patient') + queryString;
          generic.clearSession(session, auth);
          location.url(navigateTo);
        }
      });

      /* logout app */
      scope.logout = function () {
        scope.$broadcast('eventLogout');
        api.session.remove({ userid: userId }).then(function () {
          generic.clearSession(session, auth);
          if (cache.get('taskCenterCache')) {
            cache.get('taskCenterCache').destroy();
          }
          ssoSessionSvc.logout().then(function (isSsoLogout) {
            if (!isSsoLogout) {
              scope.NavigateTo('');
            }
          });
        });
      };

      /* to get regex pattern */
      scope.regex = function () {
        msApi.getSpecialCharacters.get().$promise.then(function (response) {
          if (response.results !== undefined) {
            var rawPattern = response.results.Retval.regexPattern;
            var parts = rawPattern.split('A-Za-z0-9');
            parts[1] = parts[1].replace(/\-/g,'\\-');
            parts[1] = parts[1].replace(/\$/g,'\\$');
            parts[1] = parts[1].replace(/\^/g,'\\^');
            parts[1] = parts[1].replace(/\./g,'\\.');
            generic.regexPattern = new RegExp(parts.join('A-Za-z0-9'));
            generic.specialCharactersAllowed = response.results.Retval.specialCharactersAllowed;
            generic.allowSpecialCharacters = (response.results.Retval.specialCharactersAllowed).replace(/,/g, ' ');
            generic.allowSpecialCharacters = (generic.allowSpecialCharacters === '') ? translate.instant('NO_SPECIAL_CHARACTERS_ARE_ALLOWED') : translate.instant('SPECIAL_CHARACTERS_ALLOWED_ARE',{characterList:generic.allowSpecialCharacters});
          }
        }, function () { });
      };

      /* renew session */
      scope.renewSession = function () {
        api.session.update({ userid: userId }, { 'fullSessionId': session.get('sessionId') }).then(function () { });
      };

      /* navigate to */
      scope.NavigateTo = function (error) {
        // User logged out
        if (error !== '') {
          $rootScope.sessionLogoutError = error;
        }
        var navigateTo = '/login/' + (session.get('portal') || 'patient') + '?p=' + session.get('portalName');
        $timeout.cancel(scope.absoluteLogoutTimer);
        $timeout.cancel(scope.absoluteWarningTimer);
        generic.clearSession(session, auth);
        generic.userLoggedOut = true;
        generic.isDirtyForm = true;
        scope.unbindWatch();
        $timeout.cancel(scope.forceLogOut);
        location.url(navigateTo);
      };
      scope.NavigateToAddAPatient = function (navigateTo) {
        location.url(navigateTo);
      };

      /* Tour steps configs*/
      scope.tourConfigs = [{
        WelcomeEmpower: {
          orphan: true,
          placement: 'bottom'
        },
        HomePage: {
          path: '/',
          element: '.landingpage-tiles-container',
          orphan: true,
          placement: 'top',
          prev: -1,
          onShown: function (tour) {
            if ($('.popover')) {
              $('.popover').css('top', '310px');
              $('.popover .arrow').css('display', 'none');
            }
          }
        },
        Rearrange: {
          path: '/',
          element: '.icon-drag:first',
          onShow: function (tour) {
            var iconDrag = $('.icon-drag:first');
            if (iconDrag && iconDrag.offset()) {
              var rightWidth = (($(window).width() + $(window).scrollLeft()) - (iconDrag.offset().left + iconDrag.outerWidth(true)));
              if ((rightWidth) && (rightWidth < 500)) {
                this.placement = 'bottom';
              }
              iconDrag.parentsUntil('ul', 'li').addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $('.icon-drag:first').parentsUntil('ul', 'li').removeClass('tour-step-backdrop');
          }
        },
        RemoveTile: {
          path: '/',
          element: '.round-icon_tile_close:first',
          onShow: function (tour) {
            var iconRemove = $('.icon-remove:first');
            if (iconRemove && iconRemove.offset()) {
              var rightWidth = (($(window).width() + $(window).scrollLeft()) - (iconRemove.offset().left + iconRemove.outerWidth(true)));
              if ((rightWidth) && (rightWidth < 500)) {
                this.placement = 'bottom';
              }
              iconRemove.closest('.tile-container-div').parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $('.icon-remove:first').closest('.tile-container-div').parent().removeClass('tour-step-backdrop');
          }
        },
        QuickLinks: {
          path: '/',
          element: '.tile-responsive-landing__i-want-to',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Appointments: {
          path: '/',
          element: '.tile-responsive-landing__my-appointments',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        AllAppointments: {
          path: '/',
          element: '.tile-responsive-landing__all-appointments',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        ActivityLog: {
          path: '/',
          element: '.tile-responsive-landing__recent-activity',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Announcements: {
          path: '/',
          element: '.announcements-container',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Requests: {
          path: '/',
          element: '.tile-responsive-landing__my-requests',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        MyNewMessages: {
          path: '/',
          element: '.my-messages-container',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Medications: {
          path: '/',
          element: '.tile-responsive-landing__my-medications',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Allergies: {
          path: '/',
          element: '.tile-responsive-landing__my-allergies',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Conditions: {
          path: '/',
          element: '.tile-responsive-landing__my-conditions',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        FamilyHistory: {
          path: '/',
          element: '.tile-responsive-landing__my-family-history',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        SocialHistory: {
          path: '/',
          element: '.tile-responsive-landing__my-social-history',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Procedures: {
          path: '/',
          element: '.tile-responsive-landing__my-procedures',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Immunizations: {
          path: '/',
          element: '.tile-responsive-landing__my-immunizations',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        WeightAndHeight: {
          path: '/',
          element: '.tile-responsive-landing__my-weight-and-height',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        BloodGlucose: {
          path: '/',
          element: '.tile-responsive-landing__my-blood-glucose',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        BloodPressure: {
          path: '/',
          element: '.tile-responsive-landing__my-blood-pressure',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        Cholesterol: {
          path: '/',
          element: '.tile-responsive-landing__my-cholesterol',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        TestResults: {
          path: '/',
          element: '.tile-responsive-landing__my-test-results',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        ClinicalDocuments: {
          path: '/',
          element: '.tile-responsive-landing__my-clinical-documents',
          onShow: function (tour) {
            if ($(this.element)) {
              var container = $(this.element);
              this.placement = ((container.offset() && container.offset().left) < 500) ? 'right' : 'left';
              container.parent().addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $(this.element).parent().removeClass('tour-step-backdrop');
          }
        },
        LeftNavMenu: {
          path: '/',
          element: '.left-user-menu-wrapper',
          onShown: function (tour) {
            if ($('.tour-step-background')) {
              $('.tour-step-background').hide();
            }
          },
          onHide: function (tour) {
            $('.left-user-menu-wrapper').removeClass('tour-step-backdrop');
          }
        },

        SwitchPatient: {
          path: '/',
          element: '.selected-patient-wrapper',
          onShow: function (tour) {
            if ($('.selected-patient-wrapper')) {
              $('.selected-patient-wrapper > .dropdown-menu').addClass('tour-step-backdrop');
            }
          },
          onShown: function (tour) {
            if ($('.tour-step-background')) {
              $('.tour-step-background').hide();
              $('.tour-step-background').css('display', 'block');
            }
            $('.selected-patient-wrapper > div').addClass('open');
          },
          onHide: function (tour) {
            $('.selected-patient-wrapper > .dropdown-menu ').removeClass('tour-step-backdrop');
            $('.selected-patient-wrapper > div').removeClass('open');
            $('.tour-step-background').show();
          }
        },

        ViewProfile: {
          path: '/',
          element: '#navigationlist_menuitem_profile',
          onShow: function (tour) {
            if ($('#navigationlist_menuitem_profile')) {
              $('#navigationlist_menuitem_profile > .dropdown-menu').addClass('tour-step-backdrop');
            }
          },
          onHide: function (tour) {
            $('#navigationlist_menuitem_profile > .dropdown-menu').removeClass('tour-step-backdrop');
          }
        },
        ConnecPatient: {
          path: '/',
          element: '.selected-patient-wrapper',
          onShow: function (tour) {
            if ($('.selected-patient-wrapper')) {
              $('.selected-patient-wrapper > .dropdown-menu').addClass('tour-step-backdrop');
            }
          },
          onShown: function (tour) {
            if ($('.tour-step-background')) {
              $('.tour-step-background').hide();
              $('.tour-step-background').css('display', 'block');
            }
            $('.selected-patient-wrapper > div').addClass('open');
          },
          onHide: function (tour) {
            $('.selected-patient-wrapper > .dropdown-menu ').removeClass('tour-step-backdrop');
            $('.selected-patient-wrapper > div').removeClass('open');
            $('.tour-step-background').show();
          }
        },

        Home: {
          path: '/',
          element: '.tour-step-home',
          placement: 'bottom'
        },
        Messages: {
          path: '/',
          element: '.tour-step-messages',
          placement: 'bottom'
        },
        Notifications: {
          path: '/',
          element: '.tour-step-notifications',
          placement: 'bottom'
        },
        AddATile: {
          path: '/',
          element: '.add-a-tile'
        },
        RestartTour: {
          path: '/',
          element: '#masterLayout_menuitem_takeTheTour',
          placement: 'bottom',
          next: 0,
          onShow: function (tour) {
            var previous = translate.instant('PREVIOUS_BTN');
            var restartTourText = translate.instant('LANDINGPAGE_TOUR_RESTART_THE_TOUR');
            var finishTourText = translate.instant('LANDINGPAGE_TOUR_FINISH_TOUR');
            var pauseText = translate.instant('PAUSE');
            $('#masterLayout_dropdown_userDropdown > .dropdown-menu').addClass('in-tour');
            this.template = '<div class="popover popover-tour"><div class="arrow"></div> <button type="button" class="close" data-role="end"><span class="sr-only" translate="CLOSE"></span></button><h3 class="popover-title"></h3> <div class="popover-content"></div> <div class="popover-navigation"> <button class="btn btn-default" data-role="prev">' + previous + '</button> <button class="btn btn-default" data-role="next">' + restartTourText + '</button> <button class="btn btn-primary" data-role="end">' + finishTourText + '</button> <button class="btn btn-default" data-role="pause-resume" data-pause-text="Pause" data-resume-text="Resume">' + pauseText + '</button></div> </div>';
          },
          onShown: function (tour) {
            if ($('.tour-step-background')) {
              $('.tour-step-background').hide();
              $('.tour-step-background').css('display', 'block');
            }
            $('#masterLayout_dropdown_userDropdown').addClass('open');
          },
          onHide: function (tour) {
            $('#masterLayout_dropdown_userDropdown > .dropdown-menu').removeClass('in-tour');
            $('#masterLayout_dropdown_userDropdown').removeClass('open');
            $('.tour-step-background').show();
          }
        }
      }];

      /* function to get tour data */
      scope.getTourData = function () {
        var deferred = q.defer();
        msApi.landingPageTour.get({}).$promise.then(function (response) {
          deferred.resolve(response.results);
        }, function (response) {
          deferred.reject(response);
        });
        return deferred.promise;
      };

      /* function to setup tour */
      scope.tourSetUp = function () {
        return scope.getTourData().then(function (response) {
          if (response.enableTour) {
            var title, content;
            var tourConfigs = scope.tourConfigs[0];
            translate.use(localStorageSvc.get('cultureName') || translate.preferredLanguage()).then(function () {
              angular.forEach(response.tours, function (step, key) {
                if ((tourConfigs[step.tileName]) && (step.includeInTour)) {
                  title = step.title;
                  var tileName = step.tileName;
                  step = tourConfigs[step.tileName];
                  step.title = translate.instant(('LANDINGPAGE_TOUR_' + tileName.toUpperCase()));
                  step.contentKey = 'LandingPage_Tour_' + tileName + '_' + response.portalId;
                  this.push(step);
                }
              }, scope.tourSteps);
            });
          }
        }).then(function (response) {

        });
      };
      /* open tour popup */
      scope.openTour = function () {
        var skipTourText = translate.instant('LANDINGPAGE_TOUR_SKIP_TOUR');
        location.path('/');
        if (session.get('portal').trim().toUpperCase() === 'PATIENT') {
          if (scope.tourSteps.length > 0) {
            var tour = new Tour({
              steps: scope.tourSteps,
              backdrop: true,
              storage: false,
              translateValue: { skipTourText: skipTourText, pause: translate.instant('LANDINGPAGE_TOUR_PAUSE'), next: translate.instant('NEXT_BTN'), previous: translate.instant('PREVIOUS_BTN'), close: translate.instant('Close') },
              onEnd: function (tour) {
                if (tour.getCurrentStep() !== (scope.tourSteps.length - 1)) {
                  tour.setCurrentStep((scope.tourSteps.length - 1));
                  tour.init();
                  tour.start(true);
                  return;
                }
                if ($('.tiles-backdrop')) {
                  $('.tiles-backdrop').toggleClass('hide-backdrop');
                }
              }
            });
            var patient = JSON.parse(session.get('patient') || '{}');
            var userObject = JSON.parse(session.get('userObject') || '{}');
            var dynamicValues = {
              userFirstName: userObject.firstName,
              userLastName: userObject.lastName,
              userEmailAddress: userObject.emailAddress,
              userName: session.get('user') || '',
              patientName: patient.patientName,
              patientFirstName: patient.firstName || patient.patientFirstName,
              patientLastName: patient.lastName || patient.patientLastName
            };
            _.forEach(scope.tourSteps, function (step) {
              step.content = function () {
                return translate.instant(step.contentKey, dynamicValues);
              };
            });
            patient = JSON.parse(session.get('patient') || '{}');
            userObject = JSON.parse(session.get('userObject') || '{}');
            dynamicValues = {
              userFirstName: userObject.firstName,
              userLastName: userObject.lastName,
              userEmailAddress: userObject.emailAddress,
              userName: session.get('user') || '',
              patientName: patient.patientName,
              patientFirstName: patient.firstName || patient.patientFirstName,
              patientLastName: patient.lastName || patient.patientLastName
            };
            _.forEach(scope.tourSteps, function (step) {
              step.content = function () {
                return translate.instant(step.contentKey, dynamicValues);
              };
            });
            tour.setCurrentStep(0);
            tour.init();
            tour.start(true);
            if ($('.tiles-backdrop')) {
              $('.tiles-backdrop').toggleClass('hide-backdrop');
            }
          }
        }
      };

      scope.bindFirstNameToken = function (name) {
        var patient = JSON.parse(session.get('patient')) || {};
        return name.replace(/\$\$PatientFirstName\$\$/gm, patient.firstName || '');
      };

      /* set idle time */
      scope.setIdleTime = function (idleDuration, warningDuration) {
        if (moment(new Date(sessionTimeOut.AbsoluteSessionTimeoutInHours) - 60000).diff(new Date(), 'seconds') > (idleDuration)) {
          $idle._options().idleDuration = idleDuration;
          $idle._options().warningDuration = warningDuration;
          $idle.watch();
        }
      };

      /* renew session click event */
      scope.renewSessionClick = function () {
        scope.baseLayoutData.isWarning = false;
        scope.counter = scope.baseLayoutData.warningTimeOut;
        scope.renewSession();
        $timeout.cancel(scope.forceLogOut);
        $idle.unwatch();
        scope.setIdleTime(scope.baseLayoutData.sessionInactivityTimeOut, scope.baseLayoutData.warningTimeOut);
        scope.baseLayoutData.isWarning = false;
        $('.openGenericPopUp').modal('hide');
      };

      /* close session */
      scope.closeSession = function () {
        scope.NavigateTo('');
        $timeout.cancel(scope.forceLogOut);
      };

      /* force log off */
      scope.forceTologoff = function (time) {
        scope.forceLogOut = $timeout(function () {
          scope.NavigateTo(scope.LogoutSessionInactivityWarning);
        }, (time * 10000));
      };

      /* check for idle warning time */
      scope.$on('$idleWarn', function (e, countdown) {
        if (scope.baseLayoutData.isWarning === false) {
          scope.counter = scope.baseLayoutData.warningTimeOut;
          $timeout.cancel(scope.countdownTime);
          scope.countdown();
          scope.sessionTimeOutPopupOpen = true;
          translate.use(localStorageSvc.get('cultureName') || translate.preferredLanguage()).then(function () {
            scope.sessionDialogCallback = dialog.custom('customDialog', translate.instant(scope.baseLayoutData.sessionTimeOut.header), scope.SessionInactivityWarning, scope.baseLayoutData.sessionTimeOut.addOn);
            scope.sessionDialogCallback.result.then(function () {
              scope.sessionTimeOutPopupOpen = false;
              scope.renewSessionClick();
            }, function () {
              scope.sessionTimeOutPopupOpen = false;
              scope.closeSession();
            });
          });
          $timeout.cancel(scope.forceLogOut);
          scope.forceTologoff(scope.counter * 60);
        }
        scope.baseLayoutData.isWarning = true;
      });

      /* check for idle timeout */
      scope.$on('$idleTimeout', function () {
        scope.NavigateTo(scope.LogoutSessionInactivityWarning);
      });

      /* start count down */
      scope.countdown = function () {
        scope.countdownTime = $timeout(function () {
          scope.counter = scope.counter - 1;
          scope.countdown();
        }, 1000);
      };

      /* collapse left menu */
      scope.collapse = function () {
        scope.isCollapse = (scope.isCollapse) ? false : true;
      };

      /* get patients */
      scope.getPatients = function () {
        scope.patient = JSON.parse(session.get('patient')) || false;

        if (!scope.patient) {
          var menu = JSON.parse(session.get('userObject')).menu;
          var patientList = JSON.parse(session.get('userObject')).patientList;
          if (menu && patientList) {
            var response = {};
            response.results = patientList;
            var responseMenu = {};
            responseMenu.results = menu;
            scope.handleGetPatientsResult(response, responseMenu);
          } else {
            api.patients.get({ userid: userId }).then(function (response) {
              scope.handleGetPatientsResult(response, menu);
            }, function (data) { });
          }
        } else {
          scope.refreshLeftMenus();
        }
      };

      scope.handleGetPatientsResult = function (response, menu) {
        var isSelfPatient = false;
        if (response.results.Retval.length > 0) {
          var patientData = null, patient = {}, patientobj = {};
          patientobj = { race: [] };
          response.results.Retval = _.sortBy(response.results.Retval, function (results) {
            results.MiddleName = (results.MiddleName) ? results.MiddleName.toUpperCase() : '';
            return [results.FirstName.toUpperCase(), results.MiddleName, results.LastName.toUpperCase()];
          });

          angular.forEach(response.results.Retval, function (data) {
            if (data.PortalUserRelationships) {
              isSelfPatient = (data.PortalUserRelationships.RelationshipClassification) ? data.PortalUserRelationships.RelationshipClassification.trim().toUpperCase() === 'SELF' : data.PortalUserRelationships.RelationshipClassification;
            }
            if (isSelfPatient) {
              patientData = data;
              var userObject = JSON.parse(session.get('userObject'));
              userObject.hasSelf = true;
              userObject.selfPatientId = patientData.Id;
              session.set('userObject', JSON.stringify(userObject));
            }
          });

          patient = (patientData === null) ? response.results.Retval[0] : patientData;

          patientobj = patientMapper.map(patient);
          /* Save Patient Notifications */
          var reqObject = {
            userId: (userId) ? parseInt(userId) : '',
            medseekPatientId: (patientobj) ? patientobj.mrn : ''
          };

          generic.setValuesInSessionStore('patient', patientobj, session);
          scope.refreshLeftMenus(response, menu);
          var setPatient = { patient: { 'id': patient.Id } };
          scope.setCurrentPatientContext(setPatient);
          scope.savePatientNotifications(scope, msApi, q, reqObject);
          scope.$emit('patient', '');
          generic.setValuesInSessionStore('permissions', patient.userPermissions, session);
        } else {
          scope.refreshLeftMenus();
        }
      };

      /* change page url */
      scope.changePageUrl = function (menu) {
        scope.resetTopMenus();

        var viewRoute = (menu.route.trim().length > 0) ? menu.route : '';

        if (viewRoute.length > 0) {
          if (!generic.isDirtyForm) {
            var dialogCallback = dialog.confirm('confirmDialog', 'Confirm', translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
            dialogCallback.result.then(function () {
              generic.isDirtyForm = generic.trueValue;
              scope.changeTabUrl(viewRoute);
            });
            return;
          }

          scope.changeTabUrl(viewRoute, menu);
        }
      };

      /* get menus */
      scope.getMenus = function (portalName, isSelfPatient, loadedPatientResponse, menu) {
        var name = '';
        var patient = JSON.parse(session.get('patient')) || false;


        if (patient) {
          var patientName = (patient.patientName !== undefined) ? patient.patientName.split(' ') : '';
          name = (isSelfPatient) ? 'My ' : (patientName.length > 0) ? patientName[0] + '\'s ' : '';
        }
        else {
          name = 'My ';
        }

        if (loadedPatientResponse && menu) {
          scope.getLinkedPatients(loadedPatientResponse);

          var noOfLinkedPatients = scope.linkedPatients.length;
          scope.patientDefaultLeftMenus = MenuService.Menus.getPatientDefaultLeftMenus(isSelfPatient, name, noOfLinkedPatients);
          var portal = session.get('portal');
          if (portal != 'staff') {
            scope.leftGroupMenus = MenuService.Menus.getPatientEcoAppMenusPreloaded(isSelfPatient, name, patient.patientId, scope.linkedPatients.length, menu);
            scope.messagesCultureValue = MenuService.Menus.messagesCultureValue;
            scope.notificationsCultureValue = MenuService.Menus.notificationsCultureValue;
            scope.getDynamicScriptAndCss();
          }
          else {

            MenuService.Menus.getStaffEcoAppMenus().then(function (res) {
              scope.leftGroupMenus = res;
              scope.getDynamicScriptAndCss();
            });
          }

          // get user default menus
          scope.userDefaultLeftMenus = MenuService.Menus.getUserDefaultMenus(scope.isStaff);
        }
        else {
          scope.getLinkedPatientPromise = api.patients.get({ userid: userId }).then(function (response) {
            scope.getLinkedPatients(response);

            var noOfLinkedPatients = scope.linkedPatients.length;
            scope.patientDefaultLeftMenus = MenuService.Menus.getPatientDefaultLeftMenus(isSelfPatient, name, noOfLinkedPatients);
            var portal = session.get('portal');
            if (portal != 'staff') {
              MenuService.Menus.getPatientEcoAppMenus(isSelfPatient, name, patient.patientId, scope.linkedPatients.length).then(function (res) {
                scope.messagesCultureValue = MenuService.Menus.messagesCultureValue;
                scope.notificationsCultureValue = MenuService.Menus.notificationsCultureValue;
                scope.leftGroupMenus = res;
                scope.getDynamicScriptAndCss();
              });
            }
            else {
              MenuService.Menus.getStaffEcoAppMenus().then(function (res) {
                scope.leftGroupMenus = res;
                scope.getDynamicScriptAndCss();
              });
            }

            // get user default menus
            scope.userDefaultLeftMenus = MenuService.Menus.getUserDefaultMenus(scope.isStaff);
          });
        }
        msApi.targetGroups.patientCampains.get({ userId: userId }).$promise.then(function (response) {
          if (response.results.Retval && response.results.Retval.length) {
            scope.patientCampaigns = response.results.Retval;
            scope.bodyContentWithCampaign = ((scope.patientCampaigns[0].DisplayArea.Area5.ImageSource !== null || scope.patientCampaigns[0].DisplayArea.Area5.ImageSource !== undefined) && scope.patientCampaigns[0].DisplayArea.Area5.IsEnabled === true) ? 'body-content-with-campaign' : '';
          }
        }, function (error) {
        });
      };

      /* get all linked patients for the user */
      scope.getLinkedPatients = function (response) {
        var linkedPatients = [];
        var linkedPatient = '';
        scope.linkedPatients = [];
        scope.linkedPatientWithSelf = angular.copy(response.results.Retval);
        scope.linkedPatients = _.filter(response.results.Retval, function (patient) {
          return (scope.patient.patientId !== patient.Id);
        });

        var patients = scope.linkedPatients;
        // scope.linkedPatients = _.sortBy(patients, 'FirstName');
        scope.linkedPatients = _.sortBy(patients, function (results) {
          results.MiddleName = (results.MiddleName) ? results.MiddleName.toUpperCase() : '';
          return [results.FirstName.toUpperCase(), results.MiddleName, results.LastName.toUpperCase()];
        });

        angular.forEach(scope.linkedPatients, function (linkedPatient) {
          linkedPatient.age = linkedPatient.DateOfBirth ? scope.calculateAge(new Date(linkedPatient.DateOfBirth).getMonth(), new Date(linkedPatient.DateOfBirth).getDate(), new Date(linkedPatient.DateOfBirth).getFullYear()) + ' years old' : undefined;
          linkedPatient.profileImage = linkedPatient.Image;
          if (linkedPatient.PortalUserRelationships !== undefined) {
            linkedPatient.access = linkedPatient.PortalUserRelationships.AccessLevelName || 'Custom';
            linkedPatient.relationship = linkedPatient.PortalUserRelationships.RelationshipClassification;
          }
        });
      };

      /* reset top menus */
      scope.resetTopMenus = function () {
        if (scope.topMenus !== null && scope.topMenus.length > 0) {
          angular.forEach(scope.topMenus, function (topMenu) {
            topMenu.selected = 'top-menu-normal';
          });
        }
      };

      /* change the navigation url */
      scope.changeTabUrl = function (viewRoute, menu) {
        if (session.get('showSuccessMessage')) {
          session.clear('showSuccessMessage');
        }
        alertService.clear();
        if (!generic.isDirtyForm || (scope.masterForm && scope.masterForm.$dirty)) {
          var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_LEAVE_PAGE'));
          dialogCallback.result.then(function () {
            scope.masterForm.$setPristine();
            scope.pathNavigation(viewRoute, menu);
          });
        } else {
          scope.pathNavigation(viewRoute, menu);
        }
      };

      scope.pathNavigation = function (viewRoute, menu) {
        if (viewRoute === '/switch-patient') {
          scope.isSwitchPatient = true;

        } else {
          try {
            location.url(location.path()); // will remove extra parameters in the url when clicked on nav menu's
          } catch (e) {
            console.log(e);
          }
          if (menu) {
            session.set('route', JSON.stringify(menu));
            $timeout(function () {
              app.routing.routeParams.moduleInstanceId = menu.ModuleInstanceId;
            }, 150);
          }
          location.path(viewRoute);
        }
      };

      scope.openNotificationsFlyout = function () {
        scope.isSetting = true;
      };

      /* switch patient menus */
      scope.switchPatient = function (selectedPatient, showNotDirty, redirectingFlag) {
        if (selectedPatient !== undefined) {
          api.patients.get({ userid: userId }).then(function (response) {
            if (!_.find(response.results.Retval, { Id: selectedPatient.Id })) {
              scope.linkedPatients = response.results.Retval;
              return modal.open({
                templateUrl: '/templates/dialog-templates/severed-connection-modal.html',
                controller: 'ConnectionSeveredMessageCtrl',
                backdrop: 'static',
                resolve: {
                  severedPatient: function () {
                    return selectedPatient;
                  },
                  patients: function () {
                    return response.results.Retval;
                  },
                  isDisableProfileImage: function () {
                    return scope.isDisableProfileImage;
                  }
                }
              }).result.then(function (patient) {
                if (patient) {
                  doSwitchPatient(patient);
                }
                scope.getLinkedPatients(response);
              });
            }

            doSwitchPatient(selectedPatient);
            function doSwitchPatient(selectedPatient) {
              scope.getDemographicsPendingApprovalTasks();
              var setPatient = { patient: { 'id': selectedPatient.Id } };
              if (!showNotDirty && scope.masterForm.$dirty) {
                var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('UNSAVED_CHNAGES_IN_FORM'));
                dialogCallback.result.then(function () {
                  scope.masterForm.$setPristine();
                  scope.setSwitchPatientContext(setPatient, redirectingFlag, selectedPatient);
                });
              } else {
                scope.setSwitchPatientContext(setPatient, redirectingFlag, selectedPatient);
              }
            }
          });
        }
      };

      scope.$on('updatePatient', function (event, patientId) {
        scope.setSwitchPatient('', patientId, true);
      });

      scope.setSwitchPatient = function (selectedPatient, patientId, redirectingFlag) {
        if (location.path() === '/') {
          scope.$broadcast('Landingpage', '');
        }
        var patientobj = {};
        patientobj = { race: [] };
        if (selectedPatient) {
          patientobj = {
            patientId: selectedPatient.Id,
            externalIdentifiers: selectedPatient.ExternalIdentifiers,
            medseekId: selectedPatient.MedseekId,
            mrn: selectedPatient.MedicalRecordNumber,
            patientName: selectedPatient.FirstName + ' ' + selectedPatient.MiddleName + ' ' + selectedPatient.LastName,
            patientFirstName: selectedPatient.FirstName,
            patientMiddleName: selectedPatient.MiddleName,
            patientLastName: selectedPatient.LastName,
            patientImage: selectedPatient.Image,
            DOB: selectedPatient.DateOfBirth,
            gender: selectedPatient.Gender,
            age: selectedPatient.DateOfBirth ? scope.calculateAge(new Date(selectedPatient.DateOfBirth).getMonth(), new Date(selectedPatient.DateOfBirth).getDate(), new Date(selectedPatient.DateOfBirth).getFullYear()) : undefined,
            address1: selectedPatient.Address1,
            address2: selectedPatient.Address2,
            city: selectedPatient.City,
            state: selectedPatient.State,
            zipCode: selectedPatient.ZipCode,
            country: selectedPatient.Country,
            mobilePhone: selectedPatient.MobilePhone,
            homePhone: selectedPatient.EveningPhone,
            workPhone: selectedPatient.DaytimePhone,
            relationShip: selectedPatient.relationship,
            dateOfBirth: selectedPatient.DateOfBirth,
            socialSecurityNumber: selectedPatient.SocialSecurityNumber,
            maritalStatus: selectedPatient.MaritalStatus,
            race: selectedPatient.Races,
            ethnicity: selectedPatient.Ethnicity,
            preferredLanguage: selectedPatient.PreferredLanguage,
            lastUpdated: selectedPatient.LastUpdatedOn,
            countryName: selectedPatient.CountryName,
            stateName: selectedPatient.StateName
          };
          generic.setValuesInSessionStore('patient', patientobj, session);

          /* Save Patient Notifications */
          var reqObject = {
            userId: (userId) ? userId : '',
            medseekPatientId: (patientobj) ? patientobj.mrn : ''
          };
          if (reqObject.userId && reqObject.medseekPatientId) {
            scope.savePatientNotifications(scope, msApi, q, reqObject);
          }
          if (!redirectingFlag) {
            scope.refreshMenu('/');
          } else {
            scope.refreshLeftMenus();
          }
        } else {
          api.patients.get({ userid: userId }).then(function (response) {
            if (response.results.Retval.length > 0) {
              var patientData = null, patient = {}, patientobj = {};

              angular.forEach(response.results.Retval, function (data) {
                if (data.Id === patientId) {
                  patientData = data;
                }
              });
              patient = (patientData === null) ? response.results.Retval[0] : patientData;
              patientobj = { race: [] };
              patientobj = {
                patientId: patient.Id,
                mrn: patient.MedicalRecordNumber,
                externalIdentifiers: patient.ExternalIdentifiers,
                medseekId: patient.MedseekId,
                patientName: patient.FirstName + ' ' + patient.MiddleName + ' ' + patient.LastName,
                patientFirstName: patient.FirstName,
                patientMiddleName: patient.MiddleName,
                patientLastName: patient.LastName,
                patientImage: patient.Image,
                DOB: patient.DateOfBirth,
                gender: patient.Gender,
                age: patient.DateOfBirth ? scope.calculateAge(new Date(patient.DateOfBirth).getMonth(), new Date(patient.DateOfBirth).getDate(), new Date(patient.DateOfBirth).getFullYear()) : undefined,
                address1: patient.Address1,
                address2: patient.Address2,
                city: patient.City,
                state: patient.State,
                zipCode: patient.ZipCode,
                country: patient.Country,
                mobilePhone: patient.MobilePhone,
                homePhone: patient.EveningPhone,
                workPhone: patient.DaytimePhone,
                relationShip: patient.PortalUserRelationships.RelationshipClassification,
                dateOfBirth: patient.DateOfBirth,
                socialSecurityNumber: patient.SocialSecurityNumber,
                maritalStatus: patient.MaritalStatus,
                race: patient.Race,
                ethnicity: patient.Ethnicity,
                preferredLanguage: patient.PreferredLanguage,
                lastUpdated: patient.LastUpdatedOn,
                countryName: patient.CountryName,
                stateName: patient.StateName

              };

              /* Save Patient Notifications */
              generic.setValuesInSessionStore('patient', patientobj, session);

              /* Save Patient Notifications */
              var reqObject = {
                userId: (userId) ? userId : '',
                medseekPatientId: (patientobj) ? patientobj.mrn : ''
              };
              if (reqObject.userId && reqObject.medseekPatientId) {
                scope.savePatientNotifications(scope, msApi, q, reqObject);
              }
              /* var url = location.path();
               scope.refreshMenu(url);*/

              if (!redirectingFlag) {
                scope.refreshMenu('/');
              } else {
                scope.refreshLeftMenus();
                $rootScope.$broadcast('patient', '');
              }

            }
          }, function (data) { });
        }
        // after switching patient context, refresh user premissions
        userPermissionsSvc.updatePermissions();
      };

      scope.setSwitchPatientConnect = function (selectedPatient, patientId, redirectingFlag, url) {
        if (location.path() === '/') {
          scope.$broadcast('Landingpage', '');
        }
        var patientobj = {};
        patientobj = { race: [] };
        if (selectedPatient) {
          patientobj = {
            patientId: selectedPatient.Id,
            externalIdentifiers: selectedPatient.ExternalIdentifiers,
            medseekId: selectedPatient.MedseekId,
            mrn: selectedPatient.MedicalRecordNumber,
            patientName: selectedPatient.FirstName + ' ' + selectedPatient.MiddleName + ' ' + selectedPatient.LastName,
            patientFirstName: selectedPatient.FirstName,
            patientMiddleName: selectedPatient.MiddleName,
            patientLastName: selectedPatient.LastName,
            patientImage: selectedPatient.Image,
            DOB: selectedPatient.DateOfBirth,
            gender: selectedPatient.Gender,
            age: selectedPatient.DateOfBirth ? scope.calculateAge(new Date(selectedPatient.DateOfBirth).getMonth(), new Date(selectedPatient.DateOfBirth).getDate(), new Date(selectedPatient.DateOfBirth).getFullYear()) : undefined,
            address1: selectedPatient.Address1,
            address2: selectedPatient.Address2,
            city: selectedPatient.City,
            state: selectedPatient.State,
            zipCode: selectedPatient.ZipCode,
            country: selectedPatient.Country,
            mobilePhone: selectedPatient.MobilePhone,
            homePhone: selectedPatient.EveningPhone,
            workPhone: selectedPatient.DaytimePhone,
            relationShip: selectedPatient.relationship,
            dateOfBirth: selectedPatient.DateOfBirth,
            socialSecurityNumber: selectedPatient.SocialSecurityNumber,
            maritalStatus: selectedPatient.MaritalStatus,
            race: selectedPatient.Races,
            ethnicity: selectedPatient.Ethnicity,
            preferredLanguage: selectedPatient.PreferredLanguage,
            lastUpdated: selectedPatient.LastUpdatedOn,
            countryName: selectedPatient.CountryName,
            stateName: selectedPatient.StateName
          };
          generic.setValuesInSessionStore('patient', patientobj, session);

          /* Save Patient Notifications */
          var reqObject = {
            userId: (userId) ? userId : '',
            medseekPatientId: (patientobj) ? patientobj.mrn : ''
          };
          if (reqObject.userId && reqObject.medseekPatientId) {
            scope.savePatientNotifications(scope, msApi, q, reqObject);
          }
          if (!redirectingFlag) {
            scope.refreshMenu(url);
          } else {
            scope.refreshLeftMenus();
          }
        } else {
          api.patients.get({ userid: userId }).then(function (response) {
            if (response.results.Retval.length > 0) {
              var patientData = null, patient = {}, patientobj = {};

              angular.forEach(response.results.Retval, function (data) {
                if (data.Id === patientId) {
                  patientData = data;
                }
              });
              patient = (patientData === null) ? response.results.Retval[0] : patientData;
              patientobj = { race: [] };
              patientobj = {
                patientId: patient.Id,
                mrn: patient.MedicalRecordNumber,
                externalIdentifiers: patient.ExternalIdentifiers,
                medseekId: patient.MedseekId,
                patientName: patient.FirstName + ' ' + patient.MiddleName + ' ' + patient.LastName,
                patientFirstName: patient.FirstName,
                patientMiddleName: patient.MiddleName,
                patientLastName: patient.LastName,
                patientImage: patient.Image,
                DOB: patient.DateOfBirth,
                gender: patient.Gender,
                age: patient.DateOfBirth ? scope.calculateAge(new Date(patient.DateOfBirth).getMonth(), new Date(patient.DateOfBirth).getDate(), new Date(patient.DateOfBirth).getFullYear()) : undefined,
                address1: patient.Address1,
                address2: patient.Address2,
                city: patient.City,
                state: patient.State,
                zipCode: patient.ZipCode,
                country: patient.Country,
                mobilePhone: patient.MobilePhone,
                homePhone: patient.EveningPhone,
                workPhone: patient.DaytimePhone,
                relationShip: patient.PortalUserRelationships.RelationshipClassification,
                dateOfBirth: patient.DateOfBirth,
                socialSecurityNumber: patient.SocialSecurityNumber,
                maritalStatus: patient.MaritalStatus,
                race: patient.Race,
                ethnicity: patient.Ethnicity,
                preferredLanguage: patient.PreferredLanguage,
                lastUpdated: patient.LastUpdatedOn,
                countryName: patient.CountryName,
                stateName: patient.StateName

              };

              /* Save Patient Notifications */
              generic.setValuesInSessionStore('patient', patientobj, session);

              /* Save Patient Notifications */
              var reqObject = {
                userId: (userId) ? userId : '',
                medseekPatientId: (patientobj) ? patientobj.mrn : ''
              };
              if (reqObject.userId && reqObject.medseekPatientId) {
                scope.savePatientNotifications(scope, msApi, q, reqObject);
              }
              if (!redirectingFlag) {
                scope.refreshMenu(url);
              } else {
                scope.refreshLeftMenus();
              }

            }
          }, function (data) { });
        }
        // after switching patient context, refresh user premissions
        userPermissionsSvc.updatePermissions();
      };

      scope.setPatientPermissions = function (selectedPatient, patientId, redirectingFlag, url) {
        if (location.path() === '/') {
          scope.$broadcast('Landingpage', '');
        }
        var patientobj = {};
        patientobj = { race: [] };
        if (selectedPatient) {
          patientobj = {
            patientId: selectedPatient.Id,
            externalIdentifiers: selectedPatient.ExternalIdentifiers,
            medseekId: selectedPatient.MedseekId,
            mrn: selectedPatient.MedicalRecordNumber,
            patientName: selectedPatient.FirstName + ' ' + selectedPatient.MiddleName + ' ' + selectedPatient.LastName,
            patientFirstName: selectedPatient.FirstName,
            patientMiddleName: selectedPatient.MiddleName,
            patientLastName: selectedPatient.LastName,
            patientImage: selectedPatient.Image,
            DOB: selectedPatient.DateOfBirth,
            gender: selectedPatient.Gender,
            age: selectedPatient.DateOfBirth ? scope.calculateAge(new Date(selectedPatient.DateOfBirth).getMonth(), new Date(selectedPatient.DateOfBirth).getDate(), new Date(selectedPatient.DateOfBirth).getFullYear()) : undefined,
            address1: selectedPatient.Address1,
            address2: selectedPatient.Address2,
            city: selectedPatient.City,
            state: selectedPatient.State,
            zipCode: selectedPatient.ZipCode,
            country: selectedPatient.Country,
            mobilePhone: selectedPatient.MobilePhone,
            homePhone: selectedPatient.EveningPhone,
            workPhone: selectedPatient.DaytimePhone,
            relationShip: selectedPatient.relationship,
            dateOfBirth: selectedPatient.DateOfBirth,
            socialSecurityNumber: selectedPatient.SocialSecurityNumber,
            maritalStatus: selectedPatient.MaritalStatus,
            race: selectedPatient.Races,
            ethnicity: selectedPatient.Ethnicity,
            preferredLanguage: selectedPatient.PreferredLanguage,
            lastUpdated: selectedPatient.LastUpdatedOn,
            countryName: selectedPatient.CountryName,
            stateName: selectedPatient.StateName
          };
          generic.setValuesInSessionStore('patient', patientobj, session);

          /* Save Patient Notifications */
          var reqObject = {
            userId: (userId) ? userId : '',
            medseekPatientId: (patientobj) ? patientobj.mrn : ''
          };
          if (reqObject.userId && reqObject.medseekPatientId) {
            scope.savePatientNotifications(scope, msApi, q, reqObject);
          }

        } else {
          api.patients.get({ userid: userId }).then(function (response) {
            if (response.results.Retval.length > 0) {
              var patientData = null, patient = {}, patientobj = {};

              angular.forEach(response.results.Retval, function (data) {
                if (data.Id === patientId) {
                  patientData = data;
                }
              });
              patient = (patientData === null) ? response.results.Retval[0] : patientData;
              patientobj = { race: [] };
              patientobj = {
                patientId: patient.Id,
                mrn: patient.MedicalRecordNumber,
                externalIdentifiers: patient.ExternalIdentifiers,
                medseekId: patient.MedseekId,
                patientName: patient.FirstName + ' ' + patient.MiddleName + ' ' + patient.LastName,
                patientFirstName: patient.FirstName,
                patientMiddleName: patient.MiddleName,
                patientLastName: patient.LastName,
                patientImage: patient.Image,
                DOB: patient.DateOfBirth,
                gender: patient.Gender,
                age: patient.DateOfBirth ? scope.calculateAge(new Date(patient.DateOfBirth).getMonth(), new Date(patient.DateOfBirth).getDate(), new Date(patient.DateOfBirth).getFullYear()) : undefined,
                address1: patient.Address1,
                address2: patient.Address2,
                city: patient.City,
                state: patient.State,
                zipCode: patient.ZipCode,
                country: patient.Country,
                mobilePhone: patient.MobilePhone,
                homePhone: patient.EveningPhone,
                workPhone: patient.DaytimePhone,
                relationShip: patient.PortalUserRelationships.RelationshipClassification,
                dateOfBirth: patient.DateOfBirth,
                socialSecurityNumber: patient.SocialSecurityNumber,
                maritalStatus: patient.MaritalStatus,
                race: patient.Race,
                ethnicity: patient.Ethnicity,
                preferredLanguage: patient.PreferredLanguage,
                lastUpdated: patient.LastUpdatedOn,
                countryName: patient.CountryName,
                stateName: patient.StateName
              };

              /* Save Patient Notifications */
              generic.setValuesInSessionStore('patient', patientobj, session);

              /* Save Patient Notifications */
              var reqObject = {
                userId: (userId) ? userId : '',
                medseekPatientId: (patientobj) ? patientobj.mrn : ''
              };
              if (reqObject.userId && reqObject.medseekPatientId) {
                scope.savePatientNotifications(scope, msApi, q, reqObject);
              }
              /* var url = location.path();
               scope.refreshMenu(url);*/
            }
          }, function (data) { });
        }
        // after switching patient context, refresh user premissions
        userPermissionsSvc.updatePermissions(true);
      };

      scope.refreshMenu = function (url) {
        scope.refreshLeftMenus();
        scope.getDemographicsPendingApprovalTasks();
        location.path(url);
        $rootScope.$broadcast('patient', '');
      };

      /* close linked patient */
      scope.closeLinkedPatient = function () {
        dialogService.close();
      };

      /* refresh left menus */
      scope.$on('patient', function (evnt) {
        // scope.refreshLeftMenus();
      });

      /* refresh left menus */
      // patient is optional param
      scope.refreshLeftMenus = function (patients, loadedmenu) {
        scope.user.gender = (scope.user.gender === undefined) ? 2 : scope.user.gender;
        scope.patient = JSON.parse(session.get('patient')) || {};
        var isSelfPatient = (scope.patient.relationShip !== undefined) ? scope.patient.relationShip.trim().toUpperCase() === 'SELF' : scope.patient.relationShip;
        var portalName = session.get('portal');

        scope.getMenus(portalName, isSelfPatient, patients, loadedmenu);
        if (scope.isStaff) {
          scope.userMessageIndicator = '<h5> ' + translate.instant('LOGGED_IN_AS') + ': </h5><h4>' + scope.user.firstName + ' ' + scope.user.middleName + ' ' + scope.user.lastName + '</h4>';
          scope.userNameOnly = '<h4>' + scope.user.firstName + ' ' + scope.user.middleName + ' ' + scope.user.lastName + '</h4>';
        } else {
          if (isSelfPatient === undefined) {
            scope.userMessageIndicator = '<h5> ' + translate.instant('LOGGED_IN_AS') + ': </h5><h4>' + scope.user.firstName + ' ' + scope.user.middleName + ' ' + scope.user.lastName + '</h4>';
            scope.userNameOnly = '<h4>' + scope.user.firstName + ' ' + scope.user.middleName + ' ' + scope.user.lastName + '</h4>';
          } else {
            scope.userMessageIndicator = (isSelfPatient) ?
              '<h5> ' + translate.instant('LOGGED_IN_AS') + ': </h5><h4>' + scope.user.firstName + ' ' + scope.user.middleName + ' ' + scope.user.lastName + '</h4>'
              : '<h5>' + scope.user.firstName + ', ' + translate.instant('YOU_ARE_VIEWING') + ': </h5><h4>' + scope.patient.patientName + '</h4>';
            scope.userNameOnly = '<h4>' + scope.user.firstName + ' ' + scope.user.middleName + ' ' + scope.user.lastName + '</h4>';
          }

          if (isSelfPatient === undefined) {
            scope.userProfileText = translate.instant('VIEW_PATIENTS_PROFILE', { patient: scope.user.firstName });
          } else {
            scope.userProfileText = (isSelfPatient) ?
              translate.instant('LANDINGPAGE_TOUR_VIEWPROFILE')
              : translate.instant('VIEW_PATIENTS_PROFILE',{patient:scope.patient.patientFirstName});
          }
          translate.use(localStorageSvc.get('cultureName')||translate.preferredLanguage()).then(function(){
          scope.profileText = (isSelfPatient) ?
            translate.instant('PATIENT_MANAGEMENT_MY_PROFILE') + ' - ' + scope.patient.patientName
            : translate.instant('VIEW_PATIENTS_PROFILE', { patient: scope.patient.patientFirstName });   
          })
          
        }
        // scope.checkPinSettings();
      };

      /* check if it is staff portal */
      scope.isStaffPortal = function () {
        if (session.get('portal')) {
          return (session.get('portal') === 'staff') ? true : false;
        }
      };

      /* get user id form session */
      scope.getUserIdFromSession = function () {
        return (session.get('userId')) ? session.get('userId') : '';
      };

      /* get PatientDetails from session */
      scope.getPatientDetailsFromSession = function () {
        return (session.get('patient')) ? JSON.parse(session.get('patient')) : '';
      };

      /* get notification center module settings */
      scope.getNotificationCenterModuleSettings = function () {
        NotificationsService.getNotificationSettings(scope, msApi, q, 'NotificationCenter').then(function (data) {
          scope.notificationSettings = data.results.Retval;
        });
      };

      /* get notification center module settings dynamic settings*/
      scope.getNotificationsLandingPageDynamicTexts = function (key) {
        NotificationsService.getDynamicTextMessage(scope, msApi, q, 'NotificationCenter', key).then(function (data) {
          scope.notificationCenterDynamicTexts.landinPage = NotificationsService.getDynamicNotificationTextsWithTokenValues(session, data.results.Retval, '');
        });
      };

      /* get notification center module settings dynamic settings*/
      scope.getNoNewNotificationsDynamicTexts = function (key) {
        NotificationsService.getDynamicTextMessage(scope, msApi, q, 'NotificationCenter', key).then(function (data) {
          scope.notificationCenterDynamicTexts.noNewNotifications = NotificationsService.getDynamicNotificationTextsWithTokenValues(session, data.results.Retval, '');

        });
      };

      /* get notification center module settings dynamic settings*/
      scope.getNoNotificationsDynamicTexts = function (key) {
        NotificationsService.getDynamicTextMessage(scope, msApi, q, 'NotificationCenter', key).then(function (data) {
          scope.notificationCenterDynamicTexts.noNotifications = NotificationsService.getDynamicNotificationTextsWithTokenValues(session, data.results.Retval, '');

        });
      };

      /* construct  patient notifications request object */
      scope.getNotificationsReqObject = function () {
        var patient = scope.getPatientDetailsFromSession();
        if (patient && patient.relationShip.toLowerCase() === 'self') {
          patient.mrn = '';
        }
        var reqObject = {
          'userId': parseInt(scope.getUserIdFromSession()),
          'medseekPatientId': patient.mrn
        };
        return reqObject;
      };

      /* construct  patient notifications request object */
      scope.getAllNotificationsRequestObject11 = function () {
        var patient = scope.getPatientDetailsFromSession();
        if (patient && patient.relationShip.toLowerCase() === 'self') {
          patient.mrn = '';
        }
        var reqObject = {
          'userId': parseInt(scope.getUserIdFromSession()),
          'medseekPatientId': patient.mrn,
          status: 'UnRead'
        };
        return reqObject;
      };

      /* construct all patient notifications request object */
      scope.getAllNotificationsRequestObject = function () {
        var reqObject = {};
        var patient = scope.getPatientDetailsFromSession();
        if (!scope.isStaffPortal()) {
          reqObject = { userId: parseInt(scope.getUserIdFromSession()), medseekPatientId: (patient.mrn) ? patient.mrn : '', status: 'UnRead' };
        } else {
          reqObject = { userId: parseInt(scope.getUserIdFromSession()), status: 'UnRead' };
        }
        return reqObject;
      };

      /* get all patient notifications*/
      scope.getAllPatientNotifications = function () {
        var reqObject = scope.getAllNotificationsRequestObject();
        var notification = {};
        var results = [];
        NotificationsService.getNotificationTypesDynamicText(scope, msApi, q, 'NotificationCenter').then(function (notificationTypeDynamicTexts) {
          NotificationsService.getPatientNotifications(scope, msApi, q, reqObject).then(function (data) {
            scope.notificationHeaderData = [];
            if (data.results !== undefined && data.results.Retval) {
              if (scope.isStaff || scope.isStaff === true || scope.isStaff === 'true') {
                results = data.results.Retval.Results;
              } else {
                results = data.results.Retval;
              }
              if (results.length > 0) {
                scope.isRead = true;
                if (notificationTypeDynamicTexts.results) {
                  angular.forEach(results, function (headerdata) {
                    if (headerdata.IsNew === true && headerdata.Read === false) {
                      scope.isRead = false;
                      if (session.get('patient') && session.get('user')) {
                        notification = NotificationsService.mapNotifications(headerdata, notificationTypeDynamicTexts.results, session, scope.isStaff, userPermissionsSvc);
                      } else {
                        notification = NotificationsService.mapNotifications(headerdata, notificationTypeDynamicTexts.results, session, scope.isStaff, userPermissionsSvc);
                      }
                      if (notification) {
                        scope.notificationHeaderData.push(notification);
                      }
                    }
                  });
                }
              }
            }
          });
        });
      };

      /* construct  patient notifications request object */
      scope.getMarkAsReadNotificationsReqObject = function () {
        var patient = scope.getPatientDetailsFromSession();
        var reqObject = {
          'userId': parseInt(scope.getUserIdFromSession()),
          'medseekPatientId': patient.mrn
        };
        return reqObject;
      };

      /*navigate to corresponding pages based on type*/
      scope.navigateTo = function (notification) {
        NotificationsService.markAsReadFlyOutNoitications(scope, session, event, msApi, q, scope.notificationHeaderData, notification, scope.getMarkAsReadNotificationsReqObject(), scope.notificationSettings.NotificationFlyOutPageSize, true, location);
      };

      /* mark as read*/
      scope.markAsRead = function (notification) {
        NotificationsService.markAsReadFlyOutNoitications(scope, session, event, msApi, q, scope.notificationHeaderData, notification, scope.getMarkAsReadNotificationsReqObject(), scope.notificationSettings.NotificationFlyOutPageSize);
      };

      scope.$on('notificationsHeaderData', function () {
        scope.getAllPatientNotifications();
      });

      /*emit on switch patient notifications*/
      scope.$on('openSwitchPatientFlyOut', function () {
        $('.nav li > .switch_patient').click();
      });

      /* save patient notifications */
      scope.savePatientNotifications = function (scope, medseekApi, q, reqObject) {
        NotificationsService.postPatientNotifications(scope, msApi, q, reqObject).then(function (response) {
          scope.fetchNotifications();
        });
      };

      scope.getSettingsAndDynamicTexts = function () {
        NotificationsService.getSettingsAndDynamicTexts(scope, msApi, q).then(function (data) {
          scope.notificationSettings = data.results.settings.Retval;

          data.results.dynamicText.forEach(function (result) {
            if (result.key === 'Notification.NotificationsLandingPage') {
              scope.notificationCenterDynamicTexts.landinPage = NotificationsService.getDynamicNotificationTextsWithTokenValues(session, result.value, '');
            }

            if (result.key === 'Notification.NoNewNotifications') {
              scope.notificationCenterDynamicTexts.noNewNotifications = NotificationsService.getDynamicNotificationTextsWithTokenValues(session, result.value, '');
            }

            if (result.key === 'Notification.NoNotifications') {
              scope.notificationCenterDynamicTexts.noNotifications = NotificationsService.getDynamicNotificationTextsWithTokenValues(session, result.value, '');
            }

            if (result.key === 'Notification.PatientConnectionRestored') {
              scope.notificationCenterDynamicTexts.patientConnectionRestored = result;
            }

            if (result.key === 'Notification.PermissionsUpdated') {
              scope.notificationCenterDynamicTexts.permissionsUpdated = result;
            }

            if (result.key === 'Notification.PatientConnectionRestoredOthers') {
              scope.notificationCenterDynamicTexts.patientConnectionRestoredOthers = result;
            }

          });

          scope.getAllPatientNotifications();
        });

      };

      /* calls to fetch Notifications for staff and patient */
      scope.fetchNotifications = function () {
        $timeout(function () {
          scope.getSettingsAndDynamicTexts();
        }, 1000);
      };

      scope.SetDateOfBirth = function (data) {
        return $filter('date')(data, 'dd/MM/yyyy');
      };

      scope.setSsn = function (data) {
        if (data) {
          return ('***' + '-' + '***' + '-' + data.slice(6, 9)).trim();
        }
      };

      scope.setGender = function (data) {
        var gender;
        switch (data) {
          case '1':
            gender = 'Unknown';
            break;
          case '2':
            gender = 'Male';
            break;
          case '3':
            gender = 'Female';
            break;
          default:
            gender = 'UnKnow';
        }

        return gender;
      };

      scope.buildDemographicsPendingApprovalTasksRequest = function (taskName) {
        if (session.get('patient')) {
          scope.patient = JSON.parse(session.get('patient'));
        }
        if (session.get('userFullName')) {
          scope.user = JSON.parse(session.get('userFullName'));
        }
        scope.getTaskBody = {
          'Fields': {
            'ScopeOfSearch': 'allTasks',
            'TaskStatus': 'Pending',
            'UserFirstName': scope.user.firstName,
            'PatientFirstName': scope.patient.patientFirstName,
            'TaskName': taskName

          },
          'pageSize': null,
          'pageNumber': null,
          'sortField': '',
          'sortDirection': 'Descending'
        };
        return scope.getTaskBody;
      };

      scope.isPatientDemographicTaskPending = false;
      scope.getDemographicsPendingApprovalTasks = function () {
        if (scope.isStaff) {
          return;
        }
        scope.isPatientDemographicTaskPending = false;
        msApi.task_center.taskSearch.save(scope.buildDemographicsPendingApprovalTasksRequest('Demographic Update Approval Request')).$promise.then(function (copyResponse) {
          scope.copyResponse = copyResponse.results;
          if (scope.copyResponse.Count >= 1) {
            scope.isPatientDemographicTaskPending = true;
          }
        });
      };
      scope.setCurrentPatientContext = function (setPatient) {
        var userId = session.get('userId');
        msApi.users.currentPatient.update({ userId: userId }, setPatient).$promise.then(function (response) { }, function (error) { });
      };

      scope.setSwitchPatientContext = function (setPatient, redirectingFlag, selectedPatient) {
        var userId = session.get('userId');
        msApi.users.currentPatient.update({ userId: userId }, setPatient).$promise.then(function (response) {
          if (response.results.Retval) {
            scope.setSwitchPatient('', selectedPatient.Id, redirectingFlag);
          }
        }, function (error) {
          alertService.add('danger', translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SWITCH_PATIENT'), 2000);
        });
      };

      scope.checkPermission = function (keys) {
        var counter = 0;
        var check = false;
        var keysCount = keys.length;

        angular.forEach(JSON.parse(session.get('currentPermissionSet')), function (permission) {
          angular.forEach(keys, function (key) {
            if (key === permission) {
              check = true;
              counter++;
            }
          });
        });

        return (keysCount === counter);
      };

      scope.getMainStyle = function () {
        if (!scope.ShowLeftnav) {
          return '0px';
        }
      };

      scope.getMenuName = function (moduleId) {
        if (scope.leftGroupMenus) {
          var header = _.result(_.find(scope.leftGroupMenus.navigation, function (item) { return item.ModuleId === moduleId; }), 'Name');
          return header ? header : 'n/a';
        }
        return 'n/a';
      };

    }]);
  app.publish('moduleReady', 'layouts/master');

}(window.app, window.$, window.AppUtilities, window.angular, window._, window.message));
