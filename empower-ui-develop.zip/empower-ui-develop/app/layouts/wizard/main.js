(function () {
  'use strict';

  app.controller('WizardLayoutCtrl', ['$scope', function (scope) {}]);

  app.publish('moduleReady', 'layouts/wizard');

}());
