(function () {
  'use strict';

  app.controller('LoginLayoutCtrl', ['$scope', '$location', 'session', 'medseekApi', 'alertService', 'dynamicText', function (scope, location, session, medseekApi, alertService, dynamicText) {
    scope.layoutDescription = 'Log in Layout';

    scope.init = function () {
      var locPath = location.path();
      var locUrl = location.search();
      if (locUrl && locUrl.pin) {
        scope.validatePin(locUrl.pin);
      }
      else if (locUrl && locUrl.Pin) {
        scope.validatePin(locUrl.Pin);
      }
    };

    scope.validatePin = function (pin) {
      medseekApi.pinVerification.get({ pin: pin, isExcludeDetails: true }).$promise.then(function (response) {
        var res = response.results.Retval;
        if (res.ValidationResponseKey !== 'Success') {
          /* jshint ignore:start */
          (res.ValidationResponseKey === 'InvalidPin') ? scope.displayDynamicTextForPin(res.ValidationResponseKey) :
            (res.ValidationResponseKey === 'PinAlreadyUsed') ? scope.displayDynamicTextForPin('AlreadyUsedPin') :
              (res.ValidationResponseKey === 'ExpiredPin') ? scope.displayDynamicTextForPin('ExpiredPin') :
                (res.ValidationResponseKey === 'LockedPin') ? scope.displayDynamicTextForPin('LockedPin') : alertService.add('danger', res.ValidationResponseKey, 10000);
          return;
        /* jshint ignore:end */
        }
        var profilePatientRelationShip = res.ExternalPatients[0].ProfilePatientRelationShip;

        var emailAddress = profilePatientRelationShip.UserEmail;
        var existingUser = {};

        if (emailAddress) {
          medseekApi.verifyEmailAddress.get({ userEmailAddress: emailAddress }).$promise.then(function (response) {
            if (response.results.role) {
              existingUser.isExits = true;
              session.set('pin', JSON.stringify({pin: pin, patient: res.ExternalPatients[0], relationShipType: profilePatientRelationShip.RelationShip, existingUser: scope.existingUser}));
              return;
            } else {
              existingUser.isExits = false;
              session.set('pin', JSON.stringify({pin: pin, patient: res.ExternalPatients[0], relationShipType: profilePatientRelationShip.RelationShip, existingUser: scope.existingUser}));
              location.path('signup');
            }
          });
        }
      }, function (response) {
        scope.errorMessage = response.developerMessage;
      });
    };

    /* method for display dynamic text message */
    scope.displayDynamicTextForPin = function (keyName) {
      dynamicText.getDynamicText('Enrollment', keyName).then(function (response) {
        scope.error = response;
        scope.errorMessage = scope.error;
      }, function (error) {
        scope.error = error;
        scope.errorMessage = scope.error;
      });
    };

  }]);

}());
