(function () {
  'use strict';
  app.controller('BareLayoutCtrl', [function () {}]);
  app.publish('moduleReady', 'layouts/bare');
}());
