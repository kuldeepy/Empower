(function (app) {
  'use strict';
  app.controller('LandingLayoutCtrl', ['$scope', 'session', '$rootScope', 'generic', function (scope, session, rootScope, generic) {
    /* initialize controller */
    scope.initialize = function () {
      scope.dashboardMenus = generic.getDashboardMenus();
      scope.leftMenus = generic.getMenus(session.get('portal'), '');
      scope.patient = JSON.parse(session.get('patient')) || {};
      rootScope.$on('session-patient-updated', function (evnt, patient) {
        scope.patient = JSON.parse(patient);
      });
    };

  }]);

  app.publish('moduleReady', 'layouts/default');
}(window.app));
