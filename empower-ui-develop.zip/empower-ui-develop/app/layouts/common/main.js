(function () {
  'use strict';
  app.controller('CommonLayoutCtrl', ['$scope', function (scope) {}]);
  app.publish('moduleReady', 'layouts/common');
}());
