(function () {
  'use strict';

  app.controller('LoginBaseLayoutCtrl', ['$scope', '$location', 'session', 'auth', 'medseekApi', '$q', '$http', 'styleInjector', 'AppUtilities',function (scope, location, session, auth, msApi, q, http, styleInjector, AppUtilities) {
    scope.isLogin = false;
    scope.layoutDescription = 'Login Basic Layout';

    scope.$watch(function () {
      scope.path = location.path().substring(location.path().lastIndexOf('/') + 1, location.path().length);
      scope.isLogin = !(scope.path === 'patient' || scope.path === 'staff');
      return location.path();
    }, function (val) {
      $('.modal-backdrop').css('display', 'none');
      scope.currentView = val.substr(app.currentRoute.length + 1);
    });

    scope.$watch('app.currentRoute', function () {
      scope.getDynamicScriptAndCss();
    });

    scope.getDynamicScriptAndCss = function () {
      scope.scripts = [];
      scope.portalName = location.path().substring(location.path().lastIndexOf('/') + 1, location.path().length);
      var utilities = new AppUtilities();
      utilities.getAllCssContent(scope.portalName).then(function (res) {
        scope.scripts.push(utilities.getGlobalScriptOrStyle(false, res));
        styleInjector.addStyle(utilities.getGlobalScriptOrStyle(true, res));
      });
    };

  }]);
  app.publish('moduleReady', 'layouts/base');
}());
