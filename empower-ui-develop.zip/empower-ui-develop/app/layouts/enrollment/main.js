(function () {
  'use strict';
  app.controller('EnrollmentLayoutCtrl', ['$scope', function (scope) {
    /* scope variables */
    scope.layoutDescription = 'Enrollment Layout';
    scope.errorMessage = '';

    /* initialize controller */
    scope.initialize = function () {};

  }]);
}());
