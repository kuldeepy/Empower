(function () {
  'use strict';
  app.controller('DefaultLayoutCtrl', ['$scope', 'session', 'userService', function (scope, session, userService) {
    /* scope variables */
    scope.patient = JSON.parse(session.get('patient')) || {};
    scope.layoutDescription = 'Default Layout';
    scope.height = 0;

    scope.init = function () {
      userService.isModulePermission();
    };

  }]);

  app.publish('moduleReady', 'layouts/default');
}());
