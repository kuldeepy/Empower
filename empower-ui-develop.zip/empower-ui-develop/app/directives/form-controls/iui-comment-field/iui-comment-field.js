(function (app) {
  'use strict';

  app.directive('iuiCommentField', [function () {
    return {
      restrict: 'E',
      scope: {
        commentType: '=',
        ngModel: '=',
        fieldId: '@',
        totalCharacters: '=',
        pattern: '=',
        allowSpecialCharacters: '=',
        editMode: '=',
        required: '@'
      },
      templateUrl: '/directives/form-controls/iui-comment-field/iui-comment-field.html'
    };
  }]);
}(window.app));
