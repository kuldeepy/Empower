(function (app) {
  'use strict';
  app.directive('iuiRequiredEditPermission', ['$log', 'userPermissionsSvc', function (log, userPermissionsSvc) {
    return {
      scope: false,
      restrict: 'A',
      link: function (scope, element, attrs) {
        if (!attrs.iuiRequiredEditPermission) {
          return;
        }
        var array = JSON.parse(attrs.iuiRequiredEditPermission);
        if (!userPermissionsSvc.userHasPermission(array)) {
          element.attr('disabled', 'disabled');
        }
      }
    };
  }]);
}(window.app));
