(function (app) {
  'use strict';

  /* colllection for bind the dynamic filed value */
  var dataModelCollection = ['name', 'dosage', 'dateStarted', 'comments', 'route', 'strength', 'frequency', 'pharmacy', 'prescribedBy', 'pharmacyPhone', 'quantity'];

  /* directive for renew prescription */
  app.directive('msHealthInformationPopupRenew', ['generic', 'myHealthInformation', function (generic, myHealthInformation) {
    return {
      restrict: 'C',
      scope: true,
      templateUrl: app.root + 'modules/my-health-information/templates/my-health-information-popup-renew.html',
      link: function (scope) {
        scope.renewData = {
          leftMenus: []
        };

      },
      controller: function ($scope, $http, $location, $compile, alertService, session, $q, $dialogFactory, medseekApi, $translate, PatientInfoInWizardService, moduleSettingsFactory) {
        $scope.iuiId = 'renew';
        $scope.selectedPhysicianInGrid = [];
        $scope.selectedPhysicianLocation = [];

        $scope.filterPhysicianOptions = {
          filterPhysicianText: ''
        };

        $scope.filterLocationOptions = {
          filterLocationText: '',
          useExternalFilter: false
        };

        $scope.sortOptions = { fields: ['LastName'], directions: ['asc'] };
        $scope.pagingOption = { pageSize: 10, totalItems: 100, currentPage: 1, pageOption: [10] };
        $scope.setNumberOfPages = $scope.pagingOption.pageOption[0];

        $scope.isRenewSuccess = false;

        $scope.controller = {
          physicianData: [],
          physicianColumns: [],
          physicianLocationData: [],
          physicianLocationColumns: [],
          patientsPhysicians: [],
          physiciansLocation: [],
          gridOptionsForPhysician: {
            showSelectionCheckbox: true,
            checkboxCellTemplate: '<div class="ngSelectionCell"><input tabindex="-1" class="ngSelectionCheckbox" type="radio" ng-checked="row.selected" ng-click="getPhysiciansLocations(row.entity)"/></div>',
            multiSelect: false,
            data: 'controller.physicians',
            enableColumnResize: true,
            enablePaging: true,
            pagingOptions: $scope.pagingOptions,
            columnDefs: [{ field: 'DoctorFullName', displayName: 'Physician', width: '*' }, { field: 'SpecialtyName', displayName: 'Speciality', width: '*' }],
            plugins: [new ngGridFlexibleHeightPlugin()] // jshint ignore:line
          },
          gridOptionsPhysicianLocation: {
            showSelectionCheckbox: true,
            checkboxCellTemplate: '<div class="ngSelectionCell"><input tabindex="-1" class="ngSelectionCheckbox" type="radio" ng-checked="row.selected" ng-click="getPhysiciansByLocation(row.entity)"/></div>',
            multiSelect: false,
            selectAll: function (state) {
              return state;
            },
            data: 'controller.locations',
            enableColumnResize: true,
            enablePaging: true,
            pagingOptions: $scope.pagingOptions,
            keepLastSelected: false,
            columnDefs: [{ field: 'LocationName', displayName: 'Location Name', width: '*' }, { field: 'City', displayName: 'City', width: '*' }],
            plugins: [new ngGridFlexibleHeightPlugin()] // jshint ignore:line
          },
          confirmMessage: 'Thank you. The request to ask a quetion has been submitted.<br/> You will receive a response within 1-3 business days. You may check on the status of this request in the View Pending section of the request Center.',
          locationHeader: '<h4>Select Location</h4> The provider you have selected is associated with multiple locations. Please select the location you would like to have the renewal request sent to.',
          gridAllPhysicians: {
            showSelectionCheckbox: true,
            checkboxCellTemplate: '<div class="ngSelectionCell"><input tabindex="-1" class="ngSelectionCheckbox" type="radio" ng-checked="row.selected" /></div>',
            multiSelect: false,
            afterSelectionChange: function () {
              $scope.postPhysicians();
            },
            selectAll: function (state) {
              return state;
            },
            data: 'controller.allPhysicians',
            enableColumnResize: true,
            enablePaging: true,
            pagingOptions: $scope.pagingOptions,
            keepLastSelected: false,
            columnDefs: [{ field: 'FirstName', displayName: 'First Name', width: '*' }, { field: 'LastName', displayName: 'Last Name', width: '*' }],
            filterOptions: $scope.filterPhysicianOptions,
            plugins: [new ngGridFlexibleHeightPlugin()] // jshint ignore:line
          },
          gridAllLocations: {
            showSelectionCheckbox: true,
            checkboxCellTemplate: '<div class="ngSelectionCell"><input tabindex="-1" class="ngSelectionCheckbox" type="radio" ng-checked="row.selected" /></div>',
            multiSelect: false,
            afterSelectionChange: function () {
              $scope.postPhysicians();
            },
            selectAll: function (state) {
              return state;
            },
            data: 'controller.allLocations',
            enableColumnResize: true,
            enablePaging: true,
            pagingOptions: $scope.pagingOptions,
            keepLastSelected: false,
            columnDefs: [{ field: 'locationName', displayName: 'Name', width: '*' }, { field: 'address1', displayName: 'Address', width: '*' }, { field: 'city', displayName: 'City', width: '*' }, { field: 'state', displayName: 'State', width: '*' }],
            plugins: [new ngGridFlexibleHeightPlugin()], // jshint ignore:line
            filterOptions: $scope.filterLocationOptions
          },
          isAddPhysicianSuccess: false,
          isAddLocationSuccess: false,
          selectedPhysicianName: '',
          selectedPhysicianId: 0,
          selectedLocationName: '',
          selectedLocationId: 0,
          locationNotInProfileMsg: '',
          physicianNotInProfileMsg: '',
          requestId: 0
        };

        /* Close popup at the final step*/
        $scope.closeRenewPopup = function () {
          $scope.isAccepted = false;
          myHealthInformation.closeClick('.my-heath-information-view');

        };

        /**/
        $scope.setDirty = function () {
          generic.isDirtyForm = false;
        };

        /**/
        $scope.cancel = function (form) {
          if (form.$dirty) {
              var confirmDialog = $dialogFactory.confirm('confirmDialog', $translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), $translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
            confirmDialog.result.then(function () {
              myHealthInformation.controllerData.dataModelRXRN = {};
              $scope.closePopup('.my-heath-information-view');
              myHealthInformation.actionForm.$setPristine();
            });
            return;
          }
          myHealthInformation.closeClick('.my-heath-information-view');
        };

        /* reset error message and set the previous step */
        $scope.resetErrorAndGotoPreviousStep = function (routingOrder) {
          window.setTimeout(function () {
            $(window).resize();
            $(window).resize();
          }, 10);
          $scope.controller.error = '';
          $scope.menuStepIndex -= 1;

          if (routingOrder === 'routingOrderTwo' && $scope.selectedDifferentPhysicianId) {
            $scope.phySelectedId = +$scope.selectedDifferentPhysicianId;
          }
          if (routingOrder === 'dynamicForm' && $scope.selectedDifferentPhysicianId && ($scope.controller.selectedLocationId === undefined || $scope.controller.selectedLocationId === 0)) {
            $scope.diffPhySelectedId = +$scope.selectedDifferentPhysicianId;
          }
          if (routingOrder === 'routingOrderTwo' && $scope.selectedDifferentLocationId) {
            $scope.locSelectedId = +$scope.selectedDifferentLocationId;
          }
          if (routingOrder === 'dynamicForm' && $scope.selectedDifferentLocationId && ($scope.controller.selectedPhysicianId === undefined || $scope.controller.selectedPhysicianId === 0)) {
            $scope.diffLocSelectedId = +$scope.selectedDifferentLocationId;
          }

          if (routingOrder === 'dynamicForm' && !$scope.routingOrderTwoEnabled) {
            $scope.resetErrorAndGoToStep($scope.currentStepIndex - 2);
          } else {
            $scope.previousStep();
          }
        };

        /* reset error message and set the next step */
        $scope.resetErrorAndSetStep = function (stepNumber) {
          $scope.controller.error = '';
          $scope.nextStep();
        };

        $scope.$watch('myHealthInformation.controllerData.routing', function () {
          if (myHealthInformation.controllerData.routing !== undefined && myHealthInformation.controllerData.requestType[0].IdPrefix === 'RXRN') {
            window.setTimeout(function () {
              $(window).resize();
              $(window).resize();
            }, 10);

            $scope.currentStepIndex = 0;
            $scope.menuStepIndex = 0;
            $scope.renewData.leftMenus = [];
            if (myHealthInformation.controllerData.routing.DataRows !== null && myHealthInformation.controllerData.requestType[0].IdPrefix === 'RXRN') {
              if (myHealthInformation.controllerData.requestType[0].EnableTermsAndConditions) {
                $scope.renewData.leftMenus.push(generic.getMenuData($translate.instant('TERMS_AND_CONDITIONS_MENU'), $scope.renewData.leftMenus.length + 1, ''));
              } else {
                $scope.resetErrorAndGoToStep($scope.currentStepIndex + 1);
              }

              angular.forEach(myHealthInformation.controllerData.routing.DataRows, function (data) {
                if (data.Position === 0) {
                  $scope.routingOrderOne = (data.Enabled) ? data.Entity : '';
                  $scope.routingOrderOneRequired = data.Required;
                  $scope.routingOrderOneEnabled = data.Enabled;
                }
                else if (data.Position === 1) {
                  $scope.routingOrderTwo = (data.Enabled) ? data.Entity : '';
                  $scope.routingOrderTwoRequired = data.Required;
                  $scope.routingOrderTwoEnabled = data.Enabled;
                }

                if ((data.Position === 0 && $scope.routingOrderOneEnabled) || (data.Position === 1 && $scope.routingOrderTwoEnabled)) {
                  var menuObj = generic.getMenuData($translate.instant('SELECT') + ' ' + data.Entity, $scope.renewData.leftMenus.length + 1, 'envelope');
                  if (typeof(menuObj) === 'object') {
                      switch(data.Entity.toLowerCase()){
                        case 'physician':
                          menuObj.displayName = $translate.instant('SELECT') + ' ' + $translate.instant('PHYSICIAN');
                          break;
                        case 'location':
                          menuObj.displayName = $translate.instant('SELECT') + ' ' + $translate.instant('LOCATION');
                          break;
                      }
                  }
                  $scope.renewData.leftMenus.push(menuObj);

                  //$scope.renewData.leftMenus.push(generic.getMenuData($translate.instant('SELECT') + ' ' + data.Entity, $scope.renewData.leftMenus.length + 1, 'envelope'));
                  if (data.Entity === 'Physician') {
                    $scope.physicianProfileOnly = data.ForProfileOnly;
                    $scope.getPatientsPhysicians();
                  } else {
                    $scope.locationProfileOnly = data.ForProfileOnly;
                    $scope.getPatientsLocations();
                  }
                }
              });

              if (!$scope.physicianProfileOnly || ($scope.routingOrderTwo === 'Physician')) {
                moduleSettingsFactory.getModuleSettings('profile').then(function (response) {
                  $scope.controller.requireApprovalForPhysicians = response.RequireApprovalForPhysicians;
                });
              }

              if (!myHealthInformation.controllerData.requestType[0].EnableTermsAndConditions && !$scope.routingOrderOneEnabled && !$scope.routingOrderTwoEnabled) {
                $scope.resetErrorAndGoToStep($scope.currentStepIndex + 2);
              }

              if ($scope.routingOrderOneEnabled && $scope.routingOrderTwoEnabled) {
                $scope.getAllPhysiciansData();
                $scope.getAllLocationsData();
              }

              $scope.renewData.leftMenus.push(generic.getMenuData($translate.instant('PRESCRIPTION'), $scope.renewData.leftMenus.length + 1));
              $scope.renewData.leftMenus.push(generic.getMenuData($translate.instant('SUMMARY'), $scope.renewData.leftMenus.length + 1));

            } else {
              if (myHealthInformation.controllerData.requestType[0].EnableTermsAndConditions) {
                $scope.renewData.leftMenus.push(generic.getMenuData($translate.instant('TERMS_AND_CONDITIONS_MENU'), $scope.renewData.leftMenus.length + 1, ''));
              }
              $scope.renewData.leftMenus.push(generic.getMenuData($translate.instant('PRESCRIPTION'), '1'));
              $scope.renewData.leftMenus.push(generic.getMenuData($translate.instant('SUMMARY'), '2'));
              $scope.resetErrorAndGoToStep($scope.currentStepIndex + 2);
            }
          }
        });

        /* reset error message and set the next step */
        $scope.confirmNextClick = function (routingOrder) {
          window.setTimeout(function () {
            $(window).resize();
            $(window).resize();
          }, 10);
          generic.successObject = {};
          $scope.showDifferenctLocLink = false;
          $scope.showDifferentPhyLink = false;
          if ($scope.renewData.leftMenus[$scope.menuStepIndex].menu === 'Select Physician' && $scope.controller.requireApprovalForPhysicians && !$scope.isPhysicianPresent && $scope.routingOrderTwo === 'Physician') {
            $scope.addPhysician('.physicianSearch');
            var alertDialog = $dialogFactory.alert('alertDialog', 'Add Physician', myHealthInformation.controllerData.requireStaffApproval);
            alertDialog.result.then(function () {
              $scope.closePopup('.my-heath-information-view');
            });
            return;
          } else if ($scope.renewData.leftMenus[$scope.menuStepIndex].menu === 'Select Physician' && $scope.selectedDifferentPhysicianId && !$scope.isPhysicianPresent && $scope.routingOrderTwo === 'Physician') {
            $scope.addPhysician('.physicianSearch');
          } else if ($scope.renewData.leftMenus[$scope.menuStepIndex].menu === 'Select Location' && $scope.selectedDifferentLocationId && !$scope.isLocationPresent && $scope.routingOrderTwo === 'Location') {
            $scope.addLocation('.locationSearch');
          }

          $scope.controller.error = '';
          $scope.menuStepIndex += 1;

          if ($scope.routingOrderOne === 'Physician' && ($scope.controller.selectedPhysicianId === undefined || $scope.controller.selectedPhysicianId === 0)) {
            $scope.showDifferenctLocLink = true;
          }
          if ($scope.routingOrderOne === 'Location' && ($scope.controller.selectedLocationId === undefined || $scope.controller.selectedLocationId === 0)) {
            $scope.showDifferentPhyLink = true;
          }

          if (routingOrder === 'terms' && !$scope.routingOrderOneEnabled && !$scope.routingOrderTwoEnabled) {
            $scope.resetErrorAndGoToStep($scope.currentStepIndex + 3);
          }
          else if (routingOrder === 'routingOrderOne' && !$scope.routingOrderTwoEnabled) {
            $scope.resetErrorAndGoToStep($scope.currentStepIndex + 2);
          } else {
            $scope.nextStep();
          }
        };

        /* reset error message and set the next step */
        $scope.resetErrorAndGoToStep = function (stepNumber) {
          $scope.controller.error = '';
          $scope.setStep(stepNumber);
        };

        /* reset error message and set the next step */
        $scope.enterRenewDetailsNextClick = function (stepNumber) {
          $scope.controller.error = '';
          generic.errorMessages = [];
          myHealthInformation.actionForm.$setPristine();
          if (myHealthInformation.controllerData.dataModelRXRN.Medication !== '' && myHealthInformation.controllerData.dataModelRXRN.Dosage !== '' && myHealthInformation.controllerData.dataModelRXRN.Medication !== undefined && myHealthInformation.controllerData.dataModelRXRN.Dosage !== undefined) {
            $scope.saveRenewPrescriptionData();
          }
        };

        /* Save renew prescription detail */
        $scope.saveRenewPrescriptionData = function () {
          if (myHealthInformation.controllerData.dataModelRXRN !== '') {
            var patient = JSON.parse(session.get('patient'));
            var sessionId = session.get('sessionId');
            var requestEntity = {};
            requestEntity.RequestPrefix = myHealthInformation.controllerData.requestType[0].IdPrefix;
            requestEntity.RequestType = myHealthInformation.controllerData.requestType[0].Name;
            requestEntity.RequestTypeName = myHealthInformation.data.Key;
            requestEntity.PatientId = patient.patientId;
            requestEntity.PatientName = patient.patientName;
            requestEntity.CompletionMode = myHealthInformation.controllerData.requestType[0].CompletionType;
            requestEntity.PhysicianId = $scope.controller.selectedPhysicianId || 0;
            requestEntity.PhysicianName = $scope.controller.selectedPhysicianName || '';
            requestEntity.LocationId = $scope.controller.selectedLocationId || 0;
            requestEntity.LocationName = $scope.controller.selectedLocationName || '';
            requestEntity.DepartmentId = 0;
            requestEntity.DepartmentName = '';
            requestEntity.Detail = JSON.stringify($scope.getDetails());
            var renewPrescriptionData = {};
            renewPrescriptionData.Question = myHealthInformation.controllerData.dataModelRXRN.Comments || '.';
            renewPrescriptionData.MhrHealthRecord = JSON.stringify($scope.healthInformation.currentView);
            renewPrescriptionData.RequestEntity = requestEntity;
            renewPrescriptionData.MedseekRecordId = generic.dataModel[0].selectedData.medseekRecordId;
            var renewPath = 'empower/patients/' + patient.patientId + '/prescription-renewal';
            if (generic.errorMessages.length === 0) {
              $http({
                method: 'POST',
                url: app.api.root + renewPath,
                // 'patients/' + patient.patientId + '/clinicalInformation/' + myHealthInformation.data.Key + '/PrescriptionRenewal',
                headers: {
                  'Authorization': 'bearer ' + sessionId,
                  'Content-Type': 'application/json;charset=utf-8'
                },
                data: {
                  'messageBody': JSON.stringify(renewPrescriptionData)
                }
              }).success(function (response, status, header, config) {
                myHealthInformation.controllerData.dataModelRXRN = {};
                $scope.controllerData.requestId = response.results.Retval;
                $scope.isRenewSuccess = true;
                generic.isDirtyForm = generic.trueValue;
                $scope.menuStepIndex += 1;
                $scope.nextStep();
              }).error(function (data) {
                generic.errorMessages.push('Unfortunately, we are not able to submit your request at this time. Please try again later or contact your healthcare provider if this continues.');
                generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
              });
            }
          }
        };

        /*get the request details*/
        $scope.getDetails = function () {
          var details = [
            { type: 'Renew Prescription', key: 'Medication', value: myHealthInformation.controllerData.dataModelRXRN.Medication },
            { type: 'Renew Prescription', key: 'Dosage', value: myHealthInformation.controllerData.dataModelRXRN.Dosage },
            { type: 'Renew Prescription', key: 'Strength', value: myHealthInformation.controllerData.dataModelRXRN.Strength },
            { type: 'Renew Prescription', key: 'Quantity', value: myHealthInformation.controllerData.dataModelRXRN.Quantity },
            { type: 'Renew Prescription', key: 'Frequency', value: myHealthInformation.controllerData.dataModelRXRN.Frequency },
            { type: 'Renew Prescription', key: 'Pharmacy', value: (myHealthInformation.controllerData.dataModelRXRN.Pharmacy) ? ((myHealthInformation.controllerData.dataModelRXRN.Pharmacy.name === '') ? '' : myHealthInformation.controllerData.dataModelRXRN.Pharmacy.name) : '' },
            { type: 'Renew Prescription', key: 'Pharmacy Phone', value: myHealthInformation.controllerData.dataModelRXRN.PharmacyPhone },
            { type: 'Renew Prescription', key: 'Prescribed By', value: myHealthInformation.controllerData.dataModelRXRN.PrescribedBy },
            { type: 'Renew Prescription', key: 'Date Started', value: moment(myHealthInformation.controllerData.dataModelRXRN.DateStarted).format('MM/DD/YYYY') },
            { type: 'Renew Prescription', key: 'Route', value: (myHealthInformation.controllerData.dataModelRXRN.Route) ? myHealthInformation.controllerData.dataModelRXRN.Route.name : '' }
          ];
          return details;
        };

        /* watch function for pagination - page size */
        $scope.$watch('searchText', function () {
          if ($scope.searchText !== undefined && $scope.searchText !== '') {
            $scope.physicianName = '';
            $scope.controller.allPhysicians = [];
            $scope.isSearch = true;
            var body = {};
            $scope.pagingOption.currentPage = 1;
            $scope.getDifferentPhysician();
          }
        });

        /* construct search criteria */
        $scope.constructSearchPhysiciansReqObject = function (reqObject) {
          var patient = JSON.parse(session.get('patient'));
          if ($scope.isSearch && $scope.searchText) {
            return {
              'fullName': $scope.searchText,
              'sortField': typeof $scope.orderByField === 'undefined' ? $scope.sortOptions.fields[0] : $scope.orderByField,
              'sortDirection': typeof $scope.sortOrder === 'undefined' ? $scope.getSortDirection($scope.sortOptions.directions[0]) : $scope.getSortDirection($scope.sortOrder),
              'pageSize': $scope.pagingOption.pageSize,
              'currentPageNumber': $scope.pagingOption.currentPage,
              'patientId': patient.patientId

            };
          } else {
            return {
              'sortField': typeof $scope.orderByField === 'undefined' ? $scope.sortOptions.fields[0] : $scope.orderByField,
              'sortDirection': typeof $scope.sortOrder === 'undefined' ? $scope.getSortDirection($scope.sortOptions.directions[0]) : $scope.getSortDirection($scope.sortOrder),
              'pageSize': $scope.pagingOption.pageSize,
              'currentPageNumber': $scope.pagingOption.currentPage,
              'patientId': patient.patientId
            };
          }
        };

        /* get sort direction */
        $scope.getSortDirection = function (direction) {
          var mapedDirection = '';
          switch (direction.toLowerCase()) {
            case 'asc':
              mapedDirection = 'Ascending';
              break;
            case 'desc':
              mapedDirection = 'Descending';
              break;
            default:
              mapedDirection = 'Ascending';
              break;
          }
          return mapedDirection;
        };

        /* sort physicians search results */
        $scope.sortSearchPhysicians = function (type) {
          var total = (Math.floor($scope.pagingOption.totalItems / $scope.pagingOption.pageSize) >= $scope.pagingOption.totalItems / $scope.pagingOption.pageSize) ? Math.floor($scope.pagingOption.totalItems / $scope.pagingOption.pageSize) : Math.floor($scope.pagingOption.totalItems / $scope.pagingOption.pageSize) + 1;
          if ($scope.pagingOption.currentPage > total) {
            return;
          }
          $scope.sortOrder = $scope.sortOptions.directions[0] === 'desc' ? 'asc' : 'desc';
          $scope.reverseSort = $scope.sortOrder === 'asc' ? true : false;
          $scope.sortOptions.directions[0] = $scope.sortOrder;
          $scope.isSearch = true;
          $scope.orderByField = type;
          $scope.getDifferentPhysician();
        };

        /* watch function for pagination - current page */
        $scope.$watch('pagingOption.currentPage', function (newVal, oldVal) {
          alertService.clear();
          var total = (Math.floor($scope.pagingOption.totalItems / $scope.pagingOption.pageSize) >= $scope.pagingOption.totalItems / $scope.pagingOption.pageSize) ? Math.floor($scope.pagingOption.totalItems / $scope.pagingOption.pageSize) : Math.floor($scope.pagingOption.totalItems / $scope.pagingOption.pageSize) + 1;
          if (oldVal !== newVal && newVal !== '' && parseInt(newVal) > 0 && total >= newVal) {
            $scope.getDifferentPhysician();
          }
          else if (isNaN(newVal) || parseInt(newVal) >= total || parseInt(newVal) <= 0 || isNaN(parseInt(newVal))) {
            alertService.add('danger', 'Please enter the valid page no');
          }
        });

        /* watch function for pagination - page size */
        $scope.$watch('pagingOption.pageSize', function (oldVal, newVal) {
          if (oldVal !== newVal) {
            $scope.pagingOption.currentPage = 1;
            $scope.getDifferentPhysician();
          }
        });

        /* method for get different physician */
        $scope.getDifferentPhysician = function () {
          $scope.controller.isAddPhysicianSuccess = false;
          generic.displayPopup('.physicianSearch');
        };

        /* method for get different location */
        $scope.getDifferentLocation = function () {
          $scope.controller.isAddLocationSuccess = false;
          generic.displayPopup('.locationSearch');
        };

        /* method for get patient physicians */
        $scope.getPatientsPhysicians = function () {
          var patient = JSON.parse(session.get('patient'));
          PatientInfoInWizardService.getPatientsPhysicians(patient.patientId, !$scope.routingOrderOneRequired).then(function (response) {
            $scope.controller.physicians = response;
            $scope.controller.patientPhysicians = response;
          });
        };

        /* method for get physicians locations */
        $scope.getPhysiciansLocations = function (row) {
          $scope.showDifferenctLocLink = false;
          $scope.controller.physicianNotInProfileMsg = '';
          $scope.controller.locationNotInProfileMsg = '';
          $scope.showDifferenctLocLink = false;
          myHealthInformation.actionForm.$dirty = true;
          $scope.controller.selectedPhysicianName = (row.FirstName && row.LastName) ? (row.FirstName + ' ' + row.LastName) : row.DoctorFullName;
          $scope.controller.selectedPhysicianId = +row.FindADoctorId || +row.Id;
          if ($scope.routingOrderOne === 'Physician') {
            if (+row.FindADoctorId === 0) {
              $scope.controller.selectedPhysicianId = 0;
              $scope.controller.selectedLocationName = '';
              $scope.controller.selectedLocationId = 0;
              $scope.showDifferenctLocLink = true;
              var patient = JSON.parse(session.get('patient'));
              PatientInfoInWizardService.getPatientsLocations(patient.patientId, !$scope.routingOrderTwoRequired).then(function (response) {
                $scope.controller.locations = response;
                $scope.controller.patientLocations = response;
              });
            } else {
              var data = { moduleInstanceId: myHealthInformation.controllerData.requestType[0].RequestFormData.ModuleInstanceId, entityTypeId: 'Location', criteriaList: [{ CriteriaType: 'RelatedTo', EntityTypeId: 'Physician', EntityId: +row.FindADoctorId || +row.Id }], useParticipantFiltering: true };
              PatientInfoInWizardService.postDataRelationsByCriteria(data, 'Location').then(function (response) {
                response.results.Retval.forEach(function (result) {
                  result.LocationName = result.Name;
                  result.LocationId = result.Id;
                  var findLocationData = _.find($scope.controller.locationsData, { locationId: result.Id });
                  if (findLocationData) {
                    result.City = findLocationData.city;
                  }
                });
                $scope.controller.locations = response.results.Retval;
                if (!$scope.routingOrderTwoRequired) {
                  $scope.controller.locations.push({ LocationId: 0, LocationName: $translate.instant('PATIENT_MANAGEMENT_ANY_LOCATION_OPTION') });
                }
              });
            }
          } else {
            generic.successObject = {};
            $scope.isPhysicianPresent = _.find($scope.controller.patientPhysicians, function (physician) {
              return physician.FindADoctorId === (+row.FindADoctorId || +row.Id);
            });

            if (!$scope.isPhysicianPresent && row.DoctorFullName !== 'Any Physician') {
              $scope.selectedDifferentPhysicianId = $scope.controller.selectedPhysicianId;
              $scope.selectedDifferentPhysicianFirstName = row.FirstName;
              $scope.selectedDifferentPhysicianLastName = row.LastName;
              $scope.controller.physicianNotInProfileMsg = "The Physician you selected is not linked to the patients's profile. If you continue with this selection, the Physician will automatically be linked to the patient's profile.";
            }
          }
        };

        /* method for get patients locations */
        $scope.getPatientsLocations = function () {
          var patient = JSON.parse(session.get('patient'));
          PatientInfoInWizardService.getPatientsLocations(patient.patientId, !$scope.routingOrderOneRequired).then(function (response) {
            $scope.controller.locations = response;
            $scope.controller.patientLocations = response;
          });
        };

        /* method for get physician by location */
        $scope.getPhysiciansByLocation = function (row) {
          $scope.showDifferentPhyLink = false;
          $scope.controller.physicianNotInProfileMsg = '';
          $scope.controller.locationNotInProfileMsg = '';
          myHealthInformation.actionForm.$dirty = true;
          $scope.controller.selectedLocationName = row.LocationName;
          $scope.controller.selectedLocationId = +row.LocationId || +row.Id;

          if ($scope.routingOrderOne === 'Location') {
            if (+row.LocationId === 0) {
              $scope.controller.selectedLocationName = '';
              $scope.controller.selectedLocationId = 0;
              $scope.controller.selectedPhysicianName = '';
              $scope.controller.selectedPhysicianId = 0;
              $scope.showDifferentPhyLink = true;
              var patient = JSON.parse(session.get('patient'));
              PatientInfoInWizardService.getPatientsPhysicians(patient.patientId, !$scope.routingOrderTwoRequired).then(function (response) {
                $scope.controller.physicians = response;
                $scope.controller.patientPhysicians = response;
              });
            } else {
              var data = { moduleInstanceId: myHealthInformation.controllerData.requestType[0].RequestFormData.ModuleInstanceId, entityTypeId: 'Physician', criteriaList: [{ CriteriaType: 'RelatedTo', EntityTypeId: 'Location', EntityId: row.LocationId || +row.Id }], useParticipantFiltering: true };
              PatientInfoInWizardService.postDataRelationsByCriteria(data, 'Physician').then(function (response) {
                response.results.Retval.forEach(function (result) {
                  result.DoctorFullName = result.Name;
                  result.FindADoctorId = result.Id;
                  var findPhysicianData = _.find($scope.controller.physiciansData, { FindADoctorId: result.Id });
                  if (findPhysicianData) {
                    result.SpecialtyName = findPhysicianData.SpecialtyName;
                  }
                });

                $scope.controller.physicians = response.results.Retval;
                if (!$scope.routingOrderTwoRequired) {
                  $scope.controller.physicians.push({ FindADoctorId: 0, DoctorFullName: 'Any Physician' });
                }
              });
            }
          } else {
            generic.successObject = {};
            $scope.isLocationPresent = _.find($scope.controller.patientLocations, function (location) {
              return location.LocationId === (+row.LocationId || +row.Id);
            });

            if (!$scope.isLocationPresent && row.LocationName !== 'Any Location') {
              $scope.selectedDifferentLocationId = $scope.controller.selectedLocationId;
              $scope.selectedDifferentLocationName = $scope.controller.selectedLocationName;
              $scope.controller.locationNotInProfileMsg = $translate.instant('LOCATION_NOT_IN_PROFILE');
            }
          }
        };

        $scope.$on('PharmacyChanged', function (event, item) {
          myHealthInformation.controllerData.dataModelRXRN.PharmacyPhone = '';
          angular.forEach(myHealthInformation.controllerData.pharmacyData, function (phone) {
            if (phone.Id === +item.id) {
              myHealthInformation.controllerData.dataModelRXRN.PharmacyPhone = phone.Phone;
            }
          });
        });

        $scope.physicianSearchClosePopup = function (className) {
          $scope.searchText = '';
          $(className).modal('hide');
        };

        $scope.locationSearchClosePopup = function (className) {
          $(className).modal('hide');
        };

        $scope.getPatientPhysicians = function (selectedPhysician) {
          if (selectedPhysician) {
            $scope.selectedDifferentPhysicianId = selectedPhysician.Id;
            $scope.selectedDifferentPhysicianFirstName = selectedPhysician.FirstName;
            $scope.selectedDifferentPhysicianLastName = selectedPhysician.LastName;
            $scope.controller.isAddPhysicianSuccess = true;
            if (!$scope.controller.requireApprovalForPhysicians) {
              $('.physicianSearch').modal('hide');
              if ($scope.routingOrderTwo !== 'Physician') {
                $scope.getPatientsPhysicians();
                $scope.menuStepIndex += 1;
              }
              if ($scope.routingOrderOne === 'Location' && ($scope.controller.selectedPhysicianId === undefined || $scope.controller.selectedPhysicianId === 0)) {
                $scope.getPatientsPhysicians();
                $scope.menuStepIndex += 1;
              } else if ($scope.routingOrderOne === 'Location' && ($scope.controller.selectedLocationId === undefined || $scope.controller.selectedLocationId === 0)) {
                $scope.getPatientsPhysicians();
                $scope.menuStepIndex += 1;
              } else if ($scope.routingOrderTwo === 'Location') {
                var data = {
                  'FindADoctorId': $scope.selectedDifferentPhysicianId,
                  'FirstName': $scope.selectedDifferentPhysicianFirstName,
                  'LastName': $scope.selectedDifferentPhysicianLastName
                };
                $scope.getPhysiciansLocations(data);
              }

              if ($scope.controller.physicianNotInProfileMsg === '') {
                $scope.nextStep();
              }
            }
          }
        };

        $scope.getPatientLocations = function (selectedLocation) {
          $scope.selectedDifferentLocationId = selectedLocation.Id;
          $scope.selectedDifferentLocationName = selectedLocation.LocationName;

          $('.locationSearch').modal('hide');
          $scope.controller.isAddLocationSuccess = true;
          if ($scope.routingOrderTwo !== 'Location') {
            $scope.getPatientsLocations();
            $scope.menuStepIndex += 1;
          }

          if ($scope.routingOrderOne === 'Physician' && ($scope.controller.selectedPhysicianId === undefined || $scope.controller.selectedPhysicianId === 0)) {
            $scope.getPatientsLocations();
            $scope.menuStepIndex += 1;
          } else if ($scope.routingOrderOne === 'Physician' && ($scope.controller.selectedLocationId === undefined || $scope.controller.selectedLocationId === 0)) {
            $scope.getPatientsPhysicians();
            $scope.menuStepIndex += 1;
          } else if ($scope.routingOrderTwo === 'Physician') {
            var data = {
              'LocationId': $scope.selectedDifferentLocationId,
              'LocationName': $scope.selectedDifferentLocationName
            };
            $scope.getPhysiciansByLocation(data);
          }

          if ($scope.controller.locationNotInProfileMsg === '') {
            $scope.nextStep();
          }
        };

        $scope.okClick = function (className) {
          $(className).modal('hide');
          if (className === '.physicianSearch') {
            if ($scope.controller.requireApprovalForPhysicians) {
              $scope.searchText = '';
              $scope.closePopup(className);
              $scope.closePopup('.my-heath-information-view');
            } else {
              $scope.getPatientsPhysicians();
            }
          }
          if (className === '.locationSearch') {
            $scope.getPatientsLocations();
          }
        };

        $scope.successOkClick = function () {
          myHealthInformation.controllerData.dataModelRXRN = {};
          $scope.closePopup('.my-heath-information-view');
        };

        $scope.getSelectedPhysician = function (physician) {
          $scope.selectedDifferentPhysicianId = physician.Id;
          $scope.selectedDifferentPhysicianFirstName = physician.FirstName;
          $scope.selectedDifferentPhysicianLastName = physician.LastName;
        };

        $scope.getSelectedLocation = function (location) {
          $scope.selectedDifferentLocationId = location.id;
          $scope.selectedDifferentLocationName = location.locationName;
        };

        /* method for get all physicians data */
        $scope.getAllPhysiciansData = function () {
          PatientInfoInWizardService.getDifferentPhysician().then(function (response) {
            $scope.controller.physiciansData = response;
          });
        };

        /* method for get all locations data */
        $scope.getAllLocationsData = function () {
          PatientInfoInWizardService.getDifferentLocation().then(function (response) {
            $scope.controller.locationsData = response;
          });
        };

        $scope.closePopup = function (className) {
          $(className).modal(generic.closePopupModalClassName);
          myHealthInformation.clearErrorMessage();
        };

        /* method for add physician */
        $scope.addPhysician = function (className) {
          var patient = JSON.parse(session.get('patient'));
          PatientInfoInWizardService.addPhysician(patient.patientId, +$scope.selectedDifferentPhysicianId).then(function (response) {
            if (!$scope.controller.requireApprovalForPhysicians) {
              $(className).modal('hide');
            }
            $scope.controller.isAddPhysicianSuccess = true;
          });
        };

        /* method for add location */
        $scope.addLocation = function (className) {
          var patient = JSON.parse(session.get('patient'));
          PatientInfoInWizardService.addLocation(patient.patientId, +$scope.selectedDifferentLocationId).then(function (response) {
            $(className).modal('hide');
            $scope.controller.isAddLocationSuccess = true;
          });
        };

        $scope.closePopups = function () {
          $('.add-location').modal('hide');
          $('.locationSearch').modal('hide');
          $('.physician').modal('hide');
          $('.physicianSearch').modal('hide');
        };

        $scope.closeDialog = function () {
          $scope.closePopups();
        };

        $scope.showPhysicianSuccessMessage = function (successMessage) {
          alertService.add('success', successMessage);
        };

      }
    };
  }]);

}(window.app));
