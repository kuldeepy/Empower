(function (app) {
  'use strict';

  /* directive for blue button popup */
  app.directive('msLocationSearchPopup', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/my-health-information/templates/location-search-popup.html'
    };
  }]);

}(window.app));
