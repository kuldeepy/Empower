(function (app) {
  'use strict';

  /* directive for deleting grid record */
  app.directive('msDeletePopup', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/delete-popup.html'
    };
  }]);

}(window.app));
