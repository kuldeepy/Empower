(function (app) {
  'use strict';

  /* directive for health information priority menus */
  app.directive('msTaskCenterPriorityMenus', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/task-center-priority-menus.html'
    };
  }]);

}(window.app));
