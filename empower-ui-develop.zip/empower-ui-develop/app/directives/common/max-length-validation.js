(function (app) {
  'use strict';

  app.directive('myMaxlength', function () {
    return {
      require: 'ngModel',
      scope: {
        myMaxlength: '=',
        field: '='
      },
      link: function (scope, element, attrs, ngModelCtrl) {
        var maxlength = 0;

        scope.$watch('field', function (oldValue, newValue) {
          maxlength = scope.myMaxlength;
          if (scope.field && (scope.field.length >= maxlength)) {
            var transformedInput = scope.field.substring(0, maxlength);
            scope.field = (transformedInput);
          }
        });
      }
    };
  });

})(window.app);
