(function (app) {
  'use strict';

  /* directive for pushing respective detailed view */
  app.directive('msHealthTrackerView', ['$location', 'patientMhr', function (location, patientMhr) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/healthTracker-detailed-view.html',
      link: function (scope) {
        var locationStack = location.path().split('/');
        var showDetailOf = locationStack.pop();

        if (showDetailOf.length === 0) {
          showDetailOf = locationStack.pop();
        }
        if (patientMhr.healthRecords.length) {
          scope.showDetail(showDetailOf);
          scope.type = showDetailOf;
        } else {
          scope.type = showDetailOf;
        }
      }
    };
  }]);

}(window.app));
