(function (app) {
  'use strict';
  app.directive('patientEnrollmentStatus', [function () {
    return {
      restrict: 'E',
      replace: true,
      template: '<button class="no-btn"><span class="sr-only">({{tip}})</span><span><span ng-show="showLabel">({{tip}})</span><image class="patient-enrollment-status" ng-src="/themes/default/images/user-management-icons/{{status}}.svg" alt="s.stat" tooltip="{{tip}}" tooltip-placement="left {{status}}" /></span></button>',
      scope: {
        stat: '=status',
        showLabel: '='
      },
      link: function (s) {
        s.$watch('stat', render);
        render();
        function render () {
          switch (s.stat) {
            case 'Invited':
              s.status = 'icon_invited';
              s.tip = 'Invited';
              break;
            case 'Enrolled':
              s.status = 'icon_enrolled';
              s.tip = 'Enrolled';
              break;
            case 'NoLongerEnrolled':
              s.status = 'icon_no_longer_enrolled';
              s.tip = 'No Longer Enrolled';
              break;
            case 'Refused':
              s.status = 'icon_refused';
              s.tip = 'Refused Enrollment';
              break;
            default:
              s.status = 'icon_not_invited';
              s.tip = 'Not Invited';
              break;
          }
        }
      }
    };
  }]);
})(window.app);
