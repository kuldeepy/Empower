(function (app, angular) {
  'use strict';

  app.controller('EditPermissionsCtrl', ['AccessLevelSvc', '$log', '$scope', '_', '$timeout', '$q', '$dialogFactory', 'alertService', 'accessLevel', 'dynamicText', 'session', 'accessLevels', '$translate', function (accessLevelSvc, log, scope, _, timeout, q, dialog, alertSvc, accessLevel, dynamicText, session, accessLevels, translate) {
    this.isCommunityOpen = this.isMembersOpen = true;
    scope.heading = 'Edit Permissions';
    scope.relationshipId = app.routing.routeParams.relationshipId;
    scope.uniqueId = app.routing.routeParams.mrn;
    scope.accessLevels = accessLevels;
    scope.originalAccessLevel = angular.copy(accessLevel);
    scope.originalAccessLevels = angular.copy(accessLevels);
    scope.accessLevel = _.find(accessLevels, {id: accessLevel.id});
    scope.$watch('accessLevel', function (newVal, oldVal) {
      if (!newVal || !Object.keys(newVal).length || newVal.isCustom || !oldVal || newVal.permissions.length === oldVal.permissions.length) {
        if (newVal && newVal.isCustom) {
          scope.hasChanges = true;
        }
        return;
      }
      scope.hasChanges = true;
      if (newVal.id == oldVal.id) {
        resetOriginalLevels();
        delete newVal.id;
        delete newVal.dateModified;
        newVal.isCustom = true;
        newVal.name = 'Custom';
        scope.accessLevels.unshift(newVal);
        scope.accessLevel = newVal;
      }
    }, true);

    if (session.get('portal') === 'patient') {
      dynamicText.getDynamicText('profile', 'AccessLevelDialogInstructions', '', '', true).then(function (response) {
        scope.instructionsText = response;
      });

      var patient = JSON.parse(session.get('patient'));
      accessLevelSvc.getPatientAccessLevelDefinition(patient.patientId).then(function (d) {
        _.forEach(d.results.accessTypes, function (accessType) {
          switch (accessType.componentKey) {
            case 'health-information':
              accessType.label = translate.instant('MHR_HEALTH_INFORMATION');
              break;
            case 'appointments':
              accessType.label = translate.instant('APPOINTMENTS');
              break;
            case 'evisits':
              accessType.label = translate.instant('eVisit');
              break;
            case 'patient-management':
              accessType.label = translate.instant('Patu_Management');
              break;
            case 'request-center':
              accessType.label = translate.instant('REQUEST_CENTER');
              break;
          }
        });
        
        scope.accessLevelDefinition = d.results;
      });
    } else {
      accessLevelSvc.getAccessLevelDefinition().then(function (d) {
        scope.accessLevelDefinition = d;
      });
    }

    function resetOriginalLevels () {
      scope.accessLevels = angular.copy(scope.originalAccessLevels);
    }

    scope.updateAccessLevel = function (accessLevel) {
      log.debug('UmEditPermissionsCtrl| updating accessLevel', accessLevel);

      scope.accessLevel = accessLevel;
    };

    scope.save = function () {
      if (scope.accessLevel.permissions.length) {
        if (scope.customLevel) {
          scope.accessLevel.id = scope.customLevel.id;
        }
        return scope.$close(scope.accessLevel);
      }
    };

    scope.close = function (skipConfirm) {
      if (scope.hasChanges && !skipConfirm) {
          return dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), 'All changes will be lost. Are you sure you want to cancel?').result.then(function () {
          scope.$close(scope.originalAccessLevel);
        });
      }
      scope.$close(scope.originalAccessLevel);
    };
  }]);
  app.directive('permissionsEditorModal', ['$modal', 'alertService', function (modal, alertSvc) {
    return {
      restrict: 'A',
      scope: {
        accessLevel: '=',
        accessLevels: '='
      },
      link: function (scope, element) {
        element.click(function () {
          if (element[0].disabled) {
            return;
          }
          var modalInstance = modal.open({
            templateUrl: '/directives/common/permissions-editor-popup/permissions-editor-modal.html',
            controller: 'EditPermissionsCtrl',
            resolve: {
              accessLevel: function () {
                return angular.copy(scope.accessLevel || {});
              },
              accessLevels: function () {
                return angular.copy(scope.accessLevels || []);
              }
            },
            backdrop: 'static',
            keyboard: false,
            windowClass: 'edit-permissions-modal'
          });

          return modalInstance.result.then(function (accessLevel) {
            scope.$emit('Custom-Access-Level', accessLevel);
          });
        });
      }
    };
  }]);
})(window.app, window.angular);
