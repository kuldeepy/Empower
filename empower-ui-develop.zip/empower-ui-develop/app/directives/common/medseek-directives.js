(function (app) {
  'use strict';

  angular.isUndefinedOrNull = function (val) {
    return angular.isUndefined(val) || val === null;
  };

  /* compile the contents */
  app.directive('compile', ['$compile', function (compile) {
    return function (scope, element, attrs) {
      scope.$watch(
        function (scope) {
          return scope.$eval(attrs.compile);
        },
        function (value) {
          element.html(value);
          compile(element.contents())(scope);
        }
      );
    };
  }]);

  /* */
  app.directive('angularHtmlBind', function ($compile) {
    return function (scope, elm, attrs) {
      scope.$watch(attrs.angularHtmlBind, function (newValue) {
        elm.html(newValue);
        $compile(elm.contents())(scope);
      });
    };
  });

  /* directive for task center dispute */
  app.directive('msTaskCenterDispute', function () {
    return {
      restrict: 'E',
      // templateUrl: app.root + 'templates/tc-dispute.html',
      templateUrl: app.root + 'modules/task-center/views/approveDisputeTask.html',
      // template: '<div><b>WELCOME</b></div>',
      link: function (scope, element, attrs, ctrl) {}
    };
  });

  /* directive for ngclick */
  app.directive('ngClick', ['$compile', '$dialogFactory', '$translate', 'generic', function ($compile, $dialogFactory, $translate, generic) {
    return {
      restrict: 'A',
      priority: 0,
      link: function (scope, element, attr) {
        element.bind('click', function (e) {
          var formTag = $(this).parents('form');
          if (e.target.textContent.trim().length > 0 && e.target.textContent !== 'Skip the rest of the tour') {
            if ((formTag === undefined || formTag.length === 0) && generic.isDirtyForm === false && e.target.textContent.trim() !== 'Yes' && e.target.textContent.trim() !== 'No' && e.target.textContent.trim() !== 'Ok') {
              if (scope.view === undefined && scope.item === undefined) {
                return;
              }
              var route = (scope.item !== undefined) ? scope.item.route : '';
              generic.navigationUrl = (scope.view !== undefined) ? '/user-settings' + scope.view.route : route;
              var dialogCallback = $dialogFactory.confirm('confirmDialog', $translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), $translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
              dialogCallback.result.then(function () {
                generic.isDirtyForm = true;
                scope.changeTabUrl(generic.navigationUrl);
              });
            }
          }
        });
      }
    };
  }]);

  /* directive for ngBlur */
  app.directive('ngBlur', ['$parse', function ($parse) {
    return function (scope, element, attr) {
      var fn = $parse(attr.ngBlur);
      element.on('blur', function (event) {
        scope.$apply(function () {
          fn(scope, { $event: event });
        });
      });
    };
  }]);

  /* alert message container */
  app.directive('msAlertMessageContainer', function () {
    return {
      restrict: 'E',
      template: '<span ng-bind-html="messageData"></span>'
    // templateUrl: app.root + 'templates/memo.html',
    };
  });

  /* directive for message container */
  app.directive('msMessageContainer', ['generic', function (generic) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/alert-message.html',
      link: function (scope, element, attrs, ctrl) {
        generic.resetErrorMessages();
      }
    };
  }]);

  /* directive for enrollment error message container */
  app.directive('msEnrollmentErrorMessage', function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/enrollment-error-message.html',
      link: function (scope, element, attrs, ctrl) {
        scope.controller.error = '';
      }
    };
  });

  /* directive for success message container */
  app.directive('msSuccessMessageContainer', ['generic',function (generic) {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/alert-success-message.html',
      link: function (scope, element, attrs, ctrl) {
        generic.resetErrorMessages();
      }
    };
  }]);

  /* directive for skip tour popup */
  app.directive('msSkipTourPopup', function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'templates/skip-tour.html'
    };
  });

  /* directive for left navigation menu */
  app.directive('navList', function () {
    return {
      restrict: 'E',
      replace: true,
      templateUrl: app.root + 'templates/navigation-list.html',
      link: function ($scope) {
        var key;
        $scope.data = [];
        for (key in app.routes) {
          if (app.routes.hasOwnProperty(key)) {
            $scope.data.push({
              'name': app.routes[key].title,
              'route': key,
              'img': 'chevron-right'
            });
          }
        }
      }
    };
  });

  app.directive('step', function () {
    return {
      require: '^wizard',
      restrict: 'E',
      transclude: true,
      replace: true,
      scope: {
        header: '@',
        info: '@',
        data: '='
      },
      template: '<div>' +
        '<div class="wstep" ng-show="currentStep">' +
        '<h3 class="wheader" ng-if="header" ng-bind-html="header"></h3>' +
        '<p class="wheader-info" ng-if="info" ng-bind-html="info"></p>' +
        '<div ng-transclude></div>' +
        '</div>' +
        '</div>',
      link: function (scope, element, attrs, requireController) {
        requireController.registerStep(scope);
      }

    };
  });

  app.directive('wizard', function () {
    return {
      restrict: 'E',
      replace: true,
      transclude: true,
      template: '<div> <div ng-transclude></div> </div>',
      link: function (scope) {
        scope.currentStepIndex = 0;
        scope.steps[scope.currentStepIndex].currentStep = true;
      },

      controller: function ($scope) {
        $scope.steps = [];

        this.registerStep = function (step) {
          $scope.steps.push(step);
        };

        var toggle = function (index) {
          $scope.steps[$scope.currentStepIndex].currentStep = false;
          $scope.currentStepIndex = index;
          $scope.steps[$scope.currentStepIndex].currentStep = true;
        };

        $scope.setStep = function (index) {
          toggle(index);
        };

        $scope.nextStep = function () {
          toggle($scope.currentStepIndex + 1);
        };

        $scope.goToStep = function (index, stepNumber) {
          var currentIndex = $scope.currentStepIndex + index;

          for (var step = 0; step < currentIndex; step++) {
            $scope.steps[step].currentStep = false;
          }

          $scope.steps[currentIndex].currentStep = true;
          $scope.currentStepIndex = stepNumber;
        };

        $scope.previousStep = function () {
          toggle($scope.currentStepIndex - 1);
        };

        $scope.hasNext = function () {
          return $scope.currentStepIndex < ($scope.steps.length - 1);
        };

        $scope.showConfirm = function () {
          return $scope.currentStepIndex === ($scope.steps.length - 1);
        };

        $scope.hasPrevious = function () {
          return $scope.currentStepIndex > 0;
        };

      }
    };
  });

  /* directive for wizard */
  app.directive('msWizard', ['generic', 'myHealthInformation', function (generic, myHealthInformation) {
    return {
      restrict: 'E',
      replace: true,
      scope: true,
      transclude: true,
      templateUrl: app.root + 'templates/wizard.html',
      link: function (scope) {
        scope.currentStepIndex = 0;
        scope.steps[scope.currentStepIndex].currentStep = true;
      },
      controller: function ($scope, $http, $location, $compile) {
        $scope.steps = [];

        this.registerStep = function (step) {
          $scope.steps.push(step);
        };

        var applyStyles = function (currentIndex) {
          var previous = $scope.currentStepIndex + 1;
          var current = currentIndex + 1;

          $scope.steps[$scope.currentStepIndex].currentStep = false;
          $scope.currentStepIndex = currentIndex;
          $scope.steps[$scope.currentStepIndex].currentStep = true;

          if (previous < current) {
            $('.glyphicon-' + previous).removeClass('glyphicon-pencil');
            $('.glyphicon-' + previous).addClass('glyphicon-ok-sign');
            $('.wizard-' + previous).addClass('wizard-ok');
            $('.glyphicon-' + current).addClass('glyphicon-pencil');

            if ($('.wizard-' + previous).attr('class') === 'wizard-' + previous + ' wizard-ok wizard-active') {
              $('.wizard-' + previous).removeClass('wizard-active');
              $('.glyphicon-' + previous).removeClass('glyphicon-pencil');
            }

            if ($('.glyphicon-' + current).attr('class') !== 'pull-right glyphicon glyphicon-' + current + ' glyphicon-pencil') {
              $('.wizard-' + current).addClass('wizard-active');
            }

          } else {
            if ($('.wizard-' + current).attr('class') === 'wizard-' + current + ' wizard-ok') {
              $('.wizard-' + current).addClass('wizard-active');

            }
            if ($('.wizard-' + previous).attr('class') === 'wizard-' + previous + ' wizard-ok wizard-active') {
              $('.wizard-' + previous).removeClass('wizard-active');
            }
          }
        };

        /* validate user name */
        $scope.validateGetData = function (methodType, url, headers, data, goToStep, currentStepData, errorMessage, customValidation, customFilter) {
          $http({
            method: methodType,
            url: url,
            headers: headers,
            data: data
          }).success(function (response) {
            if (customValidation) {
              $scope.customFilterValidation(response, customFilter, goToStep, errorMessage);

            } else {
              if (Object.getOwnPropertyNames(response.results).length > 0) {
                generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
                generic.errorMessages.push(errorMessage);
              }

              if (generic.errorMessages.length === 0) {
                applyStyles(goToStep);
              }
            }

          }).error(function (data, status, header, config) {
            generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
            generic.errorMessages.push(data.developerMessage);
          });
        };

        /* method for calling custom filter validation*/
        $scope.customFilterValidation = function (response, customFilter, goToStep, errorMessage) {
          generic.count += 1;
          if (customFilter === 'username') {
            if (Object.getOwnPropertyNames(response.results).length > 0) {
              generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
              generic.errorMessages.push(errorMessage);
            }
          }
          else if (customFilter === 'password') {
            if (response.results.LessThanConfiguredMinLength) {
              generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
              generic.errorMessages.push(errorMessage);
            }
          }

          if (generic.count === 2) {
            if (generic.errorMessages.length === 0) {
              applyStyles(goToStep);
            }
          }
        };

        /* validate post data */
        $scope.validatePostData = function (methodType, url, headers, data, goToStep, currentStepData, errorMessage) {
          var validateObject;
          $http({
            method: methodType,
            url: url,
            headers: headers,
            data: data
          }).success(function (response) {
            for (var currentdata in currentStepData) {
              validateObject = currentStepData[currentdata];
              if (validateObject.postAndValidate === undefined) {
                $scope.checkForError(validateObject, currentdata, goToStep);
              }
            }

            for (var data2 in currentStepData) {
              validateObject = currentStepData[data2];
              if (validateObject.checkfor !== undefined) {
                $scope.checkPostResponse(response.results, validateObject.checkfor);
              }
            }

            if (generic.errorMessages.length === 0) {
              $scope.setModelFormResponse(response.results);
              applyStyles(goToStep);
            }

          }).error(function (data, status, header, config) {
            generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
            generic.errorMessages.push(data.developerMessage);
          });
        };

        /* validate wizard data based on the step number */
        $scope.wizardData = function (stepNumber, dynamicSteps, goToStep) {
          generic.errorMessages = [];
          var currentStepData = generic.dataModel[stepNumber];
          generic.count = 0;
          var isPostDataCheck = false;
          var validateObject;

          angular.forEach(dynamicSteps, function (step) {
            if (step.step === stepNumber) {
              for (var data in currentStepData) {
                validateObject = currentStepData[data];
                generic.errorMessages = [];
                generic.alertObject.message = [];

                if (validate.dynamicData[step.step].fields !== undefined) {
                  /* jshint ignore:start */
                  angular.forEach(validate.dynamicData[step.step].fields, function (field) {
                    // if (field.visible && field.required && (field.$value === undefined || field.$value.trim().length === 0)) {
                    if (field.visible && field.required && (field.$value === undefined || field.$value.length === 0)) {
                      generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
                      generic.errorMessages.push(field.label + ' should be entered');
                    }
                  });
                /* jshint ignore:end */
                }
              }

              if (generic.errorMessages.length === 0 && isPostDataCheck === false) {
                applyStyles(goToStep);
              }
            }
          });

          for (var data in currentStepData) {
            validateObject = currentStepData[data];
            if (validateObject.length > 0) {
              /* jshint ignore:start */
              angular.forEach(validateObject, function (object) {
                $scope.checkForError(object, object.data, goToStep);
              });
            /* jshint ignore:end */
            } else {
              $scope.checkForError(validateObject, data, goToStep);
            }
          }

          if (generic.errorMessages.length === 0) {
            for (var res in currentStepData) {
              validateObject = currentStepData[res];
              if (validateObject.postAndValidate !== undefined) {
                isPostDataCheck = true;
                break;
              }
            }
          }

          if (!isPostDataCheck) {
            if (generic.errorMessages.length === 0) {
              applyStyles(goToStep);
            }
          } else {
            for (var index in currentStepData) {
              validateObject = currentStepData[index];
              if (validateObject.postAndValidate !== undefined) {
                var url = validateObject.url;
                if (validateObject.isQueryString) {
                  url = validateObject.url + ((validateObject.value === undefined) ? '' : validateObject.value);
                }

                if (validateObject.methodType === 'POST') {
                  $scope.buildJsonForRequest(validate.dynamicData, stepNumber, validateObject);
                  $scope.validatePostData(validateObject.methodType, url, validateObject.headers, generic.jsonData, goToStep, currentStepData, validateObject.errorMessage);

                } else {
                  $scope.validateGetData(validateObject.methodType, url, validateObject.headers, validateObject.data, goToStep, currentStepData, validateObject.errorMessage, validateObject.customValidation, validateObject.customFilter);
                }
              }
            }
          }
        };

        /* check for error in object */
        $scope.checkForError = function (validateObject, data, goToStep) {
          if (validateObject.isRequired && typeof validateObject.value === 'object' && (validateObject.value === undefined || validateObject.value.length === 0)) {
            generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
            generic.errorMessages.push(data + ' is required');
          }
          if (validateObject.isRequired && typeof validateObject.value === 'string' && (validateObject.value === undefined || validateObject.value.trim().length === 0)) {
            generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
            generic.errorMessages.push(data + ' should be entered');
          }

          if (validateObject.compareTo !== undefined && validateObject.compareTo.trim().length > 0) {
            $scope.setCompareObject(validateObject.compareTo, validateObject.value);
          }

          if (validate.compareObject.value !== null && data === validate.compareObject.compare && validateObject.value !== validate.compareObject.value) {
            generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
            generic.errorMessages.push(validateObject.comparedWith + ' does not match');
          }

          if (myHealthInformation.data.selectedClass !== undefined && generic.errorMessages.length > 0) {
            generic.errorMessages = [];
            generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
            generic.errorMessages.push('Please fill out all of the required information and try again.');
          }

        };

        /* set compare object */
        $scope.setCompareObject = function (compareTo, compareValue) {
          validate.compareObject = { compare: compareTo, value: compareValue };
        };

        $scope.nextStep = function () {
          generic.alertObject.message = [];
          generic.errorMessages = [];
          if ($scope.isClinicalInformation) {
            $scope.selectionClinical = 0;
          }
          // for grid
          if ($scope.isGrid) {
            $scope.bindDataObject($scope.steps[$scope.currentStepIndex], $scope.steps[$scope.currentStepIndex + 1]);
          }

          $scope.wizardData($scope.currentStepIndex, $scope.isDynamic, $scope.currentStepIndex + 1);
        };

        $scope.previousStep = function () {
          // for grid
          if ($scope.isGrid) {
            $scope.bindDataObject($scope.steps[$scope.currentStepIndex], $scope.steps[$scope.currentStepIndex - 1]);
          }
          // generic.isDirtyForm = true;
          applyStyles($scope.currentStepIndex - 1);

          if ($scope.isClinicalInformation) {
            $scope.selectionClinical = 0;
          }
        };

        $scope.saveData = function () {
          generic.alertObject.message = [];
          generic.errorMessages = [];
          $scope.wizardData($scope.currentStepIndex, $scope.isDynamic, $scope.currentStepIndex + 1);
          if (generic.errorMessages.length === 0) {
            $scope.saveUserProfileData();
          }
        // $scope.saveUserProfileData();
        };

        $scope.hasNext = function () {
          if ($scope.currentStepIndex === 0) {
            $('.glyphicon-' + ($scope.currentStepIndex + 1)).addClass('glyphicon-pencil');
          }

          return ($scope.currentStepIndex < ($scope.steps.length - 1) && $scope.steps[$scope.currentStepIndex].final === undefined);
        };

        $scope.showConfirm = function () {
          if ($scope.isSignUpUsingPIN) {
            return false;
          } else {
            if ($scope.currentStepIndex === 0 || $scope.steps[$scope.currentStepIndex - 1].final === 'true') {
              return false;
            } else {
              return ($scope.currentStepIndex === ($scope.steps.length - 1) || $scope.steps[$scope.currentStepIndex].final === 'true');
            }
          }
        };

        $scope.hasPrevious = function () {
          if ($scope.isSignUpUsingPIN || ($scope.currentStepIndex > 0 && $scope.steps[$scope.currentStepIndex - 1].final === 'true')) {
            return false;
          } else {
            return $scope.currentStepIndex > 0;
          }
        };

        $scope.leftMenu = function (status) {
          if ($scope.isSignUpUsingPIN) {
            return;
          }

          if ($scope.currentStepIndex === (parseInt(status) - 1)) {
            return;
          }
          // for grid
          if ($scope.isGrid) {
            $scope.bindDataObject($scope.steps[$scope.currentStepIndex], $scope.steps[parseInt(status) - 1]);
          }
          if ($('.glyphicon-' + parseInt(status)).attr('class') !== 'pull-right glyphicon glyphicon-' + parseInt(status)) {
            applyStyles(parseInt(status) - 1);
          }
        };

        $scope.skipStep = function () {
          generic.alertObject.message = [];
          generic.errorMessages = [];
          applyStyles($scope.currentStepIndex + 1);
        };

      }
    };
  }]);

  /* directive for wizard-step */
  app.directive('msWizardStep', function () {
    return {
      require: '^msWizard',
      restrict: 'E',
      transclude: true,
      replace: true,
      scope: {
        title: '@',
        info: '@',
        final: '@'
      },
      template: '<div>' +
        '<div class="wizard-step" ng-show="currentStep">' +
        '<span class="wizard-header" ng-bind-html="title"></span>' +
        '<span class="wizard-header-info" ng-bind-html="info"></span>' +
        '<div ng-transclude></div>' +
        '</div>' +
        '</div>',
      link: function (scope, element, attrs, requireController) {
        requireController.registerStep(scope);
      }
    };
  });

  /*Navigation menu  for wizard */
  app.directive('msWizardNavList', function () {
    return {
      restrict: 'E',
      replace: true,
      templateUrl: app.root + 'templates/WizardMenu.html'
    };
  });

  /* directive for popup */
  app.directive('msGenericPopUp', function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'templates/popup-window.html'
    };
  });

  /* directive for dynamically generating fields for change/reset password */
  app.directive('msChangePassword', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/change-password.html'
    };
  }]);

  app.directive('msChangePasswordWithoutPermission', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/change-password-without-permission.html'
    };
  }]);

  /* directive for dynamically generating fields for security questions */
  app.directive('msSecurityQuestion', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/security-question.html'
    };
  }]);

  /* directive for dynamically generating fields for security questions */
  app.directive('msSecurityQuestionWithoutPermission', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/security-question-without-permission.html'
    };
  }]);

  /* directive for security answer masking */
  app.directive('securityAnswersMask', function () {
    return {
      restrict: 'A',
      template: '<input type="text" directiveIsExecuting="test" ng-focus="starToCharacter()" ng-blur="changeToStar()">',
      replace: true,
      link: function (scope, element, attrs) {
        scope.changeToStar = function () {
          element.attr('type', 'password');
        };
        scope.starToCharacter = function () {
          element.attr('type', 'text');
        };
      }
    };
  });

  /* directive for text box control */
  app.directive('heightEditor', ['$compile', function (compile) {
    return {
      restrict: 'E',
      replace: true,
      template: '<div ng-show="{{context.visible}}">' +
        '<span>' +
        '<field-base></field-base>' +
        '<input ' +
        'id="{{context | field_id}}" ' +
        'type="text"  ' +
        'tooltip="{{context.tooltip}}" ' +
        'tooltip-placement="{{context.tooltipDirection}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'" ' +
        'ng-required="false" ' +
        'ng-pattern="{{context.pattern}}" ' +
        'ng-model="context.$value" ng-change="setDirty()" ng-focus="showFeetBoxes()" />' +
        '</span>' +
        '</div>',
      link: function (scope, element, attributes) {
        scope.splitHeight = function () {
          if (scope.context.$value) {
            scope.heightFeet = Math.floor(scope.context.$value / 12);
            scope.heightInches = (scope.context.$value % 12);
          }
        };
        scope.showFeetBoxes = function () {
          scope.splitHeight();
          var inputElememt = angular.element(element.find('input')[0]);
          var inputclass = inputElememt.attr('ng-class');
          var pattern = inputElememt.attr('ng-pattern');
          var heightTextBoxes = compile(angular.element('<div class="row"><div class="col-sm-6"><div class="input-group"><input type="text" class="form-control" ng-class="' + inputclass + '"' + 'ng-required="' + scope.context.required + '"' + 'ng-model="heightFeet" id="field_feet" ng-change="change()"' + /*'ng-pattern="' + pattern + '"*/'><label class="input-group-addon" for="field_feet" translate="FEET_LBL"></label></div></div><div class="col-sm-6"><div class="input-group"><input id="field_inches" class="form-control" type="text" ng-class="' + inputclass + '"' + 'ng-model="heightInches" ng-change="change()"><label class="input-group-addon" for="field_inches" translate="INCHES_LBL"></label></div></div></div>'))(scope);
          inputElememt.replaceWith(heightTextBoxes);
        };
        scope.change = function () {
          scope.setDirty();
          scope.heightFeet = +scope.heightFeet === 0 || isNaN(scope.heightFeet) ? undefined : scope.heightFeet; // jshint ignore:line
          scope.heightInches = +scope.heightInches === 0 || isNaN(scope.heightInches) ? undefined : scope.heightInches; // jshint ignore:line
          scope.context.$value = (+(scope.heightFeet || 0) * 12 + +(scope.heightInches || 0)) === 0 ? undefined : (+(scope.heightFeet || 0) * 12 + +(scope.heightInches || 0)); // jshint ignore:line
        };
      }
    };
  }]);

  // resets date field when faulty data gets entered
  app.directive('resetDateField', function () {
    return {
      require: 'ngModel',
      scope: {
        resetDateViewValue: '=resetDateField'
      },
      link: function (scope, element, attrs, modelCtrl) {
        scope.resetDateViewValue = function () {
          if (modelCtrl.$modelValue === undefined) {
            modelCtrl.$setViewValue('');
            modelCtrl.$render();
          }
        };
      }
    };
  });

  /* directive for dropdown control */
  app.directive('dropDown', [function () {
    return {
      restrict: 'E',
      replace: true,
      template: '<div ng-show="{{context.visible}}"><field-base></field-base> ' +
        '<select ' +
        // 'ng-init="loadInitialData(context.$value)" ' +
        'id="{{context | field_id}}" ' +
        'ng-change="loadInitialData(selectedvalue, context.data)" ' +
        'ng-options="v  for (k,v) in context.data" ' +
        'ng-model="selectedvalue"' +
        'ng-required="{{context.required}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'"  ' +
        'tooltip="{{context.tooltip}}"  ' +
        'tooltip-placement="{{context.tooltipDirection}}"  ' +
        '</select> ' +
        '</div>',
      link: function (scope, element, attributes) {
        scope.$watch('context.$value', function () {
          angular.forEach(scope.context.data, function (v, k) {
            if (k === scope.context.$value) {
              scope.selectedvalue = v;
            }
          });
        });

        scope.loadInitialData = function (selectedValue, data) {
          // scope.buttonModifier();
          angular.forEach(data, function (k, v) {
            if (k === selectedValue) {
              scope.context.$value = v;
            }
          });
          scope.setDirty();
        };
      }
    };
  }]);

  /* directive for mhr dropdown control */
  app.directive('mhrDropDown', [function () {
    return {
      restrict: 'E',
      replace: true,
      template: '<div ng-show="{{context.visible}}"><field-base></field-base> ' +
        '<select ' +
        // 'ng-init="loadInitialData(context.$value)" ' +
        'id="{{context | field_id}}" ' +
        'ng-change="loadInitialData(selectedvalue, context.data)" ' +
        'ng-options="v  for (k,v) in context.data" ' +
        'ng-model="selectedvalue"' +
        'ng-required="{{context.required}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'"  ' +
        'tooltip="{{context.tooltip}}"  ' +
        'tooltip-placement="{{context.tooltipDirection}}"  ' +
        '</select> ' +
        '</div>',
      link: function (scope, element, attributes) {
        scope.$watch('context.$value', function () {
          angular.forEach(scope.context.data, function (v, k) {
            if (v === scope.context.$value) {
              scope.selectedvalue = v;
            }
          });
        });

        scope.loadInitialData = function (selectedValue, data) {
          // scope.buttonModifier();
          angular.forEach(data, function (k, v) {
            if (k === selectedValue) {
              scope.context.$value = k;
            }
          });
          scope.setDirty();
        };
      }
    };
  }]);

  /* number only directive */
  app.directive('acceptNumberOnly', [function () {
    return {
      restrict: 'A',
      require: 'ngModel',
      link: function (scope, element, attrs, modelCtrl) {
        modelCtrl.$parsers.push(function (inputValue) {
          if (inputValue === undefined) {
            return '';
          }
          var transformedInput = inputValue.replace(/[^0-9]/g, '');
          if (transformedInput !== inputValue) {
            modelCtrl.$setViewValue(transformedInput);
            modelCtrl.$render();
          }
          return transformedInput;
        });
      }
    };
  }]);

  /* directive for field base control */
  app.directive('fieldBase', [function () {
    return {
      restrict: 'E',
      transclude: true,
      replace: true,
      template: '<div class="clearfix" ng-show="{{context.visible}}"><label for="{{context | field_id}}" class="label-text" ng-class="{\'required-field\': context.filters.Required}">{{context.label}}</label><span class="field-item" ng-transclude></span></div>'
    };
  }]);

  /* directive for paragraph control */
  app.directive('paragraph', [function () {
    return {
      restrict: 'E',
      transclude: true,
      replace: true,
      template: '<div ng-show="{{context.visible}}" class="panel panel-default"><div class="panel-heading background-light-shade">{{context.label}}</div><div>{{context.description}}</div></div>'
    };
  }]);

  /* directive for email control */
  app.directive('email', [function () {
    return {
      restrict: 'E',
      replace: true,
      template: '<div><span><field-base><input type="email" tooltip="{{context.tooltip}}" tooltip-placement="{{context.tooltipDirection}}" ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'" required ng-model="context.$value" ng-change="setDirty()"" id="{{context | field_id}}"></field-base></span></div>'
    };
  }]);

  /* directive for checkbox control */
  app.directive('checkBox', [function () {
    return {
      restrict: 'E',
      replace: true,
      template: '<div><div class="checkbox-container"><input type="checkbox" ng-model="context.$value" ng-change="setDirty()" id="{{context | field_id}}"></div><field-base></field-base></div>'
    };
  }]);

  /* directive for date dropdown control */
  app.directive('dateDropdown', [function () {
    return {
      restrict: 'E',
      replace: true,
      scope: true,
      template: '<div class="date-picker" ng-show="{{context.visible}}">' +
        '<span>' +
        '<form name="dateForm"><field-base></field-base>' +
        '<input ' +
        'type="text" id="{{context | field_id}}" ' +
        'tooltip="{{context.tooltip}}" ' +
        'tooltip-placement="{{context.tooltipDirection}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'" ' +
        'ng-required="{{context.required}}" ' +
        'ng-pattern="{{context.pattern}}" maxlength="10" ' +
        'ng-model="context.$value" ng-change="setDirty()" ' +
        'datepicker-popup="{{dateObject.format}}" show-weeks="false" is-open="dateObject.opened" readonly>' +
        '<div class="date"><button class="btn btn-default date-icon" ng-click="open($event)"><i class="glyphicon glyphicon-calendar"></i><span class="sr-only" translate="SR_OPEN_CALENDAR_WIDGET"></span></button></div>' +
        '</form></span>' +
        ' </div>',
      link: function (scope, element, attributes) {
        scope.minDate = (scope.minDate) ? null : new Date();
        scope.formats = ['MM-dd-yyyy', 'dd-MM-yyyy', 'dd-MMMM-yyyy', 'yyyy/MM/dd', 'shortDate'];
        scope.dateObject = {
          minDate: new Date(),
          opened: false,
          format: scope.formats[0]
        };

        scope.open = function ($event) {
          $event.preventDefault();
          $event.stopPropagation();
          scope.dateObject.opened = true;
        };

      }
    };
  }]);

  /* directive for date dropdown control */
  app.directive('datePicker', ['PopupManager', '$filter', 'myHealthInformation', function (PopupManager, $filter, myHealthInformation) {
    return {
      restrict: 'E',
      replace: true,
      scope: true,
      template: '<div class="date-picker" ng-show="{{context.visible}}">' +
        '<field-base></field-base>' +
        '<div class="input-group"><input ' +
        'type="text"  id="{{context | field_id}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'" ' +
        'ng-required="{{context.required}}" placeholder="{{dateObject.placeHolder}}" ' +
        'ng-model="context.$value" ng-change="setDirty()" ng-blur="validateDate()" maxlength="10" ng-readonly="true"' +
        'datepicker-popup="{{dateObject.format}}" is-open="dateObject.opened" min-date="dateObject.minDate" max-date="dateObject.maxdate" show-weeks="false" show-button-bar="false">' +
        '<span class="input-group-btn"><button class="btn btn-default" ng-click="open($event)" type="button" role="button"><i class="glyphicon glyphicon-calendar"></i><span class="sr-only" translate="SR_OPEN_CALENDAR_WIDGET"></span></button></span></div>' +
        ' </div>',

      link: function (scope, element, attributes, ctrl) {
        var newDate = myHealthInformation.convertToPreferredTimeZoneDateTime(null);
        scope.minDate = (scope.MinDate) ? null : newDate;
        scope.formats = ['MM/dd/yyyy', 'dd-MM-yyyy', 'dd-MMMM-yyyy', 'yyyy/MM/dd', 'shortDate'];
        scope.placeHolders = ['MM/DD/YYYY'];
        var minDate = (scope.$parent.context.filters) ? ((scope.$parent.context.filters.MinDate === undefined || scope.$parent.context.filters.MinDate === '') ? null : myHealthInformation.convertToPreferredTimeZoneDateTime(scope.$parent.context.filters.MinDate)) : null;
        var formatDate = (scope.$parent.context.pattern === undefined || scope.$parent.context.pattern === '') ? scope.formats[0] : scope.$parent.context.pattern.format;
        var placeHolderDate = (scope.$parent.context.pattern === undefined || scope.$parent.context.pattern === '') ? scope.placeHolders[0] : scope.$parent.context.pattern.placeHolder;

        var dateObject = {
          minDate: minDate,
          opened: false,
          format: formatDate,
          placeHolder: placeHolderDate,
          maxdate: newDate
        };
        var id = $filter('field_id')(scope.context);
        scope.dateObject = PopupManager.registerPopup(id, dateObject);
        scope.validateDate = function (context) {
          scope.validdate = false;
          var c = ctrl;
          if (element.find('input').val() !== '') {
            var comp = element.find('input').val().split('/');
            var currentDate = myHealthInformation.convertToPreferredTimeZoneDateTime(null);

            if (comp.length === 3) {
              var m = parseInt(comp[0], 10);
              var d = parseInt(comp[1], 10);
              var y = parseInt(comp[2], 10);
              var date = myHealthInformation.convertToPreferredTimeZoneDateTime(moment().subtract(1, 'month').format());
              var month = (date.getMonth() + 1);
              var day = date.getDate();
              var value = ((month < 10) ? ('0' + month) : month) + '/' + ((day < 10) ? ('0' + day) : day) + '/' + date.getFullYear();

              if (date.getFullYear() === y && date.getMonth() + 1 === m && date.getDate() === d && date < myHealthInformation.convertToPreferredTimeZoneDateTime(null)) {
                element.find('input').val(value);
              }
            }
          }
        };

        scope.open = function ($event) {
          $event.preventDefault();
          $event.stopPropagation();
          PopupManager.togglePopup(id);
        };
      }
    };
  }]);

  app.directive('dateTimePicker', ['myHealthInformation', function (myHealthInformation) {
    return {
      restrict: 'E',
      replace: true,
      scope: true,
      template: '<div class="date-picker" ng-show="{{context.visible}}">' +
        '<field-base></field-base>' +
        '<div class="row">' +
        '<div class="col-sm-6 dateinput">' +
        '<div class="input-group"><input ' +
        'type="text"  id="{{context | field_id}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'" ' +
        'ng-required="{{context.required}}" placeholder="{{dateObject.placeHolder}}" ' +
        'ng-model="context.$value" ng-change="setDirty()" ng-blur="validateDate()" maxlength="10" ' +
        'datepicker-popup="{{dateObject.format}}" is-open="dateObject.opened" min-date="dateObject.minDate" max-date="dateObject.maxdate" show-weeks="false" show-button-bar="false">' +
        '<span class="input-group-btn"><button class="btn btn-default" ng-click="open($event)"><i class="glyphicon glyphicon-calendar"></i><span class="sr-only" translate="SR_OPEN_CALENDAR_WIDGET"></span></button></span></div></div>' +
        '<div class="col-sm-6 timeinput"><timepicker class="timepicker-inline" ng-model="context.time" readonly-input="true" ng-change="changed()"  show-meridian="ismeridian"></timepicker></div>' +
        ' </div>' +
        ' </div>',
      link: function (scope, element, attributes) {
        scope.ismeridian = true;
        var newDate = myHealthInformation.convertToPreferredTimeZoneDateTime(null);
        scope.context.$value = newDate;
        scope.context.time = newDate;
        scope.changed = function () {
          /* case, when model is filled for edit and have UTC or string date format  */
          scope.context.$value = scope.context.$value ? new Date(scope.context.$value) : newDate;
          /* changing time of date choosen by user */
          scope.context.$value.setHours(scope.context.time.getHours());
          scope.context.$value.setMinutes(scope.context.time.getMinutes());
          scope.context.$value.setSeconds(scope.context.time.getSeconds());
          scope.setDirty();
        };
        scope.minDate = (scope.minDate) ? null : newDate;
        scope.formats = ['MM-dd-yyyy', 'dd-MM-yyyy', 'dd-MMMM-yyyy', 'yyyy/MM/dd', 'shortDate'];
        var formatDate = (scope.$parent.context.dateTimePickerPattern === undefined || scope.$parent.context.dateTimePickerPattern === '') ? scope.formats[0] : scope.$parent.context.dateTimePickerPattern.format;

        scope.dateObject = {
          minDate: '',
          opened: false,
          format: formatDate,
          maxdate: newDate
        };

        scope.open = function ($event) {
          $event.preventDefault();
          $event.stopPropagation();
          scope.dateObject.opened = true;
        };

      }
    };
  }]);

  /* directive for phone text box control */
  app.directive('phoneTextBox', [function () {
    return {
      restrict: 'E',
      replace: true,
      template: '<div ng-show="{{context.visible}}">' +
        '<span>' +
        '<field-base></field-base>' +
        '<input ' +
        'type="text" id="{{context | field_id}}" ' +
        'tooltip="{{context.tooltip}}" ' +
        'tooltip-placement="{{context.tooltipDirection}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'" ' +
        'ng-required="{{context.required}}" ' +
        'ng-pattern="{{context.pattern}}" ' +
        'ng-model="context.$value" ng-change="setDirty()">' +
        '</span>' +
        '</div>'
    };
  }]);

  /* directive for wizard left menu navigation control */
  app.directive('wizardLeftMenuNavigation', [function () {
    return {
      restrict: 'E',
      replace: true,
      template: ' <div class="navigation">' +
        '<ul class="nav nav-stacked">' +
        '<li ng-repeat="item in leftMenus"  ng-class="{\'wizard-ok\': ($index<currentStepIndex)}">' +
        '<a href="#">' +
        '<span class="wicon" ng-bind="item.startIcon"></span>' +
        '<span class="nav-text" ng-bind="item.menu"></span>' +
        '<span class="pull-right" ng-show="($index == currentStepIndex)" ng-class="{\'glyphicon glyphicon-chevron-right\':$index==currentStepIndex}" ng-bind="item.count"></span>' +
        '<span class="pull-right" ng-show="($index < currentStepIndex)" ng-class="{\'glyphicon glyphicon-ok\':$index<currentStepIndex}" ng-bind="item.count"></span>' +
        '</a>' +
        '</li>' +
        '</ul>' +
        '</div>'
    };
  }]);

  /* directive for text box control */
  app.directive('textBox', ['$translate', function (translate) {
    return {
      restrict: 'E',
      replace: true,
      template: '<form name="myForm">' +
        '<div ng-show="{{context.visible}}">' +
        '<span>' +
        '<field-base></field-base>' +
        '<input ' +
        'type="text" name="textbox" id="{{context | field_id}}" ' +
        'tooltip="{{context.tooltip}}" ' +
        'tooltip-placement="{{context.tooltipDirection}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}}\' : \'{{context.className}}\'" ' +
        'ng-required="{{context.required}}" ' +
        'ng-disabled="{{context.disabled}}" ' +
        'ng-pattern="{{context.pattern}}" ' +
        'ng-model="context.$value" ng-change="setDirty()">' +

        '<p class="help-block error" ng-show="!myForm.textbox.$error.required && myForm.textbox.$error.pattern">' +
        translate.instant('INVALID_DATA') +
        '</p>' +
        '</span>' +
        '</div>' +
        '</form>'
    };
  }]);

  /* directive for text box control */
  app.directive('textArea', [function () {
    return {
      restrict: 'E',
      replace: true,
      template: '<div ng-show="{{context.visible}}">' +
        '<span>' +
        '<field-base></field-base>' +
        '<textarea ' +
        'id="{{context | field_id}}" ' +
        'tooltip="{{context.tooltip}}" ' +
        'tooltip-placement="{{context.tooltipDirection}}" ' +
        'ng-class="{{context.required}} ? \'{{context.className}} ng-invalid-required\' : \'{{context.className}}\'" ' +
        'ng-required="{{context.required}}" ' +
        'ng-pattern="{{context.pattern}}" ' +
        'ng-model="context.$value" ng-change="setDirty()"></textarea>' +
        '</span>' +
        '</div>'
    };
  }]);

  app.directive('msButton', ['$compile', '$document', function (compile, document) {
    return {
      restrict: 'E',
      template: '<div class="pull-right margin-top" ng-disabled="formDirty">' +
        ' <input />' +
        '</div>',
      link: function (scope, element, attrs) {
        var elemOld = angular.element(element.find('input'));
        var ngForm = document.find('ng-form')[0];
        var elem = '';
        if (ngForm !== undefined) {
          elem = compile('<input type="{{context.buttonType}}" value="{{context.label}}" ng-click="' + scope.event + '" class="{{context.className}}" />')(scope);
        } else {
          elem = compile('<input type="{{context.buttonType}}" value="{{context.label}}"  ng-click="' + scope.event + '" class="{{context.className}}" />')(scope);
        }
        elemOld.replaceWith(elem);
      }
    };
  }]);

  /* directive for dynamic form definition */
  app.directive('dynamicFormDefinition', [function () {
    return {
      restrict: 'A',
      templateUrl: app.root + 'templates/dynamic-form-definition.html',
      scope: {
        defFn: '&dynamicFormDefinition', // one-way binding
        dataModel: '=formData' // two-way binding
      },
      link: function (scope, element, attributes) {
        scope.buildForm = function () {
          scope.rows = groupByRows(scope.def.fields);
          scope.rowLength = [];
          scope.rows.forEach(function (f) {
            scope.rowLength.push(f.length);
          });
          scope.rowLength.sort(function (a, b) { return a - b; });
          scope.maxColumnLength = (scope.rowLength.length > 0) ? scope.rowLength[scope.rowLength.length - 1] : 0;
          scope.buttons = groupButtons(scope.def.fields);

          // ensure data model
          if (!scope.dataModel) {
            scope.dataModel = {};
          }

          if (!scope.def.fields) {
            return;
          }
          scope.def.fields.forEach(function (f) {
            scope.$watch('dataModel', function () {
              if (Object.getOwnPropertyNames(scope.dataModel).length > 0) {
                f.$value = scope.dataModel[f.name];
                // sync data model to field values
                scope.$watch(function () {
                  return f.$value;
                }, function (val) {
                  if (val !== undefined) {
                    scope.dataModel[f.name] = val;
                  }
                });
              }
            });
          });

        };

        // get sync form definition data from http
        scope.$watch(function () {
          scope.def = scope.defFn();

          // enter only when fields are changed
          if (scope.def !== undefined && scope.def.changed === true) {
            scope.buildForm();
            scope.def.changed = false;
          }
          // enter only once if fields are having value
          else if (scope.rows === undefined && scope.def !== undefined && scope.def.fields !== undefined) {
            scope.buildForm();
          }

        });

        function groupButtons (fields) {
          if (!fields || !fields.length) {
            return []; // no fields
          }
          return [fields[fields.length - 2], fields[fields.length - 1]];
        }

        /* helper function to order fields */
        function groupByRows (fields) {
          if (!fields || !fields.length) {
            return []; // no fields
          }

          var rows = [],
            current = 0;

          while (true) {
            // filter by current row
            /* jshint ignore:start */
            rows[current] = fields.filter(function (f) {
              return f.layout.row === current;
            });
            /* jshint ignore:end */

            // if there are no more rows, break
            if (!rows[current].length) {
              break;
            }

            // sort the rows by column

            /* jshint ignore:start */
            rows[current].sort(function (a, b) {
              return a.layout.column > b.layout.column;
            });
            /* jshint ignore:end */

            // increment the current row
            current++;
          }

          return rows;
        }
      }
    };
  }]);

  /* directive for dynamic form definition */
  app.directive('formDefinition', ['generic', function (generic) {
    return {
      restrict: 'A',
      templateUrl: app.root + 'templates/form-definition.html',
      scope: {
        defFn: '&formDefinition', // one-way binding
        dataModel: '=formData' // two-way binding
      },
      link: function (scope, element, attributes) {
        generic.dynamicFields = [];
        scope.buildForm = function () {
          scope.rows = groupByRows(scope.def.fields);
          scope.rowLength = [];
          scope.rows.forEach(function (f) {
            scope.rowLength.push(f.length);
          });
          scope.rowLength.sort(function (a, b) { return a - b; });
          scope.maxColumnLength = (scope.rowLength.length > 0) ? scope.rowLength[scope.rowLength.length - 1] : 0;
          scope.buttons = groupButtons(scope.def.fields);

          // ensure data model
          if (!scope.dataModel) {
            scope.dataModel = {};
          }

          if (!scope.def.fields) {
            return;
          }
          scope.def.fields.forEach(function (f) {
            scope.$watch('dataModel', function () {
              if (Object.getOwnPropertyNames(scope.dataModel).length > 0) {
                f.$value = scope.dataModel[f.name];
                // sync data model to field values
                scope.$watch(function () {
                  return f.$value;
                }, function (val) {
                  if (val !== undefined) {
                    scope.dataModel[f.name] = val;
                  }
                });
              }
            });
          });

        };

        // get sync form definition data from http
        scope.$watch(function () {
          scope.def = scope.defFn();

          // enter only when fields are changed
          if (scope.def !== undefined && scope.def.changed === true) {
            scope.buildForm();
            scope.def.changed = false;
          }
          // enter only once if fields are having value
          else if (scope.rows === undefined && scope.def !== undefined && scope.def.fields !== undefined) {
            scope.buildForm();
          }

        });

        function groupButtons (fields) {
          if (!fields || !fields.length) {
            return []; // no fields
          }
          return [fields[fields.length - 2], fields[fields.length - 1]];
        }

        /* helper function to order fields */
        function groupByRows (fields) {
          if (!fields || !fields.length) {
            return []; // no fields
          }
          var groupedFields = [];
          fields.forEach(function (field) {
            var row = field.layout.row;
            groupedFields[row] = groupedFields[row] || [];
            groupedFields[row].push(field);
          });

          groupedFields.forEach(function (group) {
            group.sort(function (itemA, itemB) {
              return itemA.layout.column > itemB.layout.column;
            });
          });
          return groupedFields;
        }
      }
    };
  }]);

  /* directive for dynamic form field */
  app.directive('formField', ['$compile', '$http', '$location', '$document', '$dialogFactory','$translate', 'generic', function (compile, http, location, $document, dialog, translate, generic) {
    return {
      restrict: 'EA',
      scope: {
        ctxFn: '&context'
      },

      link: function (scope, element, attributes) {
        var field;

        scope.dynamicFields = [];
        // get the form field definition
        scope.context = scope.ctxFn();

        // ensure field filters
        if (!scope.context.filters) {
          scope.context.filters = {};
        }

        // lookup the field by type
        field = generic.tagCase(scope.context.type);

        // inject the specific type
        switch (field) {
          case 'ms-button':
            scope.event = scope.context.event + 'Event()';
            element.append(compile('<' + field + '>' + '</' + field + '>')(scope));
            break;
          case 'auto-complete':
            field = 'mf-auto-complete';

            // dynamically create control type
            var markup = '<' + field + ' ';
            for (var key in scope.context.filters) {
              if (key === 'Required')
                markup += ('ng-required="' + scope.context.filters[key] + '" ');
              else
                markup += (key + '="' + scope.context.filters[key] + '" ');
            }
            markup += 'ng-model="context.$value" field="context" form="form" ></' + field + '>';

            markup = '<div ng-show="{{context.visible}}">' +
              '<span>' +
              '<field-base></field-base>' +
              markup +
              '</span>' +
              '</div>';

            element.append(compile(markup)(scope));
            if (generic.dynamicFields.indexOf(scope.context) < 0) {
              generic.dynamicFields.push(scope.context);
            }
            break;
          default:
            element.append(compile('<' + field + '>' + '</' + field + '>')(scope));
            if (generic.dynamicFields.indexOf(scope.context) < 0) {
              generic.dynamicFields.push(scope.context);
            }
            break;
        }

        /* to remove ng-disable(to enable button) from button created by above if condition */
        scope.setDirtyForDate = function () {
          if (!generic.isWizard) {
            generic.isDirtyForm = false;
          }
        };

        /* to remove ng-disable(to enable button) from button created by above if condition */
        scope.setDirty = function () {
          if (!generic.isWizard) {
            generic.isDirtyForm = false;
          }
        };

        /* submit event clicked */
        scope.onSubmitEvent = function () {
          scope.context.data = { 'user': generic.dataModel };
          scope.context.data.user.PhoneNumbers = [];

          var reg = /[^\d]/g;
          if (scope.context.data.user.DaytimePhone) {
            scope.context.data.user.PhoneNumbers.push({
              PhoneNumber: scope.context.data.user.DaytimePhone.replace(reg, ''),
              Id: scope.context.data.user.DaytimePhoneId,
              Extension: (scope.context.data.user.DaytimePhoneExt || '').replace(reg, ''),
              PhoneType: 4002
            });
          }
          if (scope.context.data.user.EveningPhone) {
            scope.context.data.user.PhoneNumbers.push({
              PhoneNumber: scope.context.data.user.EveningPhone.replace(reg, ''),
              Id: scope.context.data.user.EveningPhoneId,
              Extension: (scope.context.data.user.EveningPhoneExt || '').replace(reg, ''),
              PhoneType: 4001
            });
          }
          if (scope.context.data.user.MobilePhone) {
            scope.context.data.user.PhoneNumbers.push({
              PhoneNumber: scope.context.data.user.MobilePhone.replace(reg, ''),
              Id: scope.context.data.user.MobilePhoneId,
              PhoneType: 4003
            });
          }
          // to do: pass the below parameters from the context object for submit/cancel/reset events
          scope.performAction(scope.context.methodType, scope.context.url, scope.context.headers, scope.context.data);
        };

        /* cancel event clicked */
        scope.onCancelEvent = function () {
          if (!generic.isDirtyForm) {
              var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
            dialogCallback.result.then(function () {
              scope.$parent.$emit('yesClickMyEvent');
            });
          }
        };

        /* cancel event clicked */
        scope.onSkipEvent = function () {
          location.path(scope.context.skipUrl);
        };

        /* cancel event clicked */
        scope.onNextEvent = function () {
          if (!scope.validate()) {
            location.path(scope.context.nextUrl);
          }
        };

        /* validate form fields */
        scope.validate = function () {
          var errorMessage = '';
          generic.resetErrorMessages();
          angular.forEach(generic.dynamicFields, function (dataControl) {
            if ((dataControl.visible === true) && (dataControl.required === true) && (dataControl.$value === undefined)) {
              errorMessage += (dataControl.label) + ' is mandatory <br/>';
            }
          });

          scope.showAlert('danger', 'glyphicon glyphicon-remove-sign', errorMessage);
          return (errorMessage.trim().length > 0);
        };

        /* perform http operations */
        scope.performAction = function (method, url, headers, data) {
          if (!scope.validate()) {
            // scope.showAlert('warning', null, 'No Errors');
            http({
              method: method,
              url: url,
              headers: headers,
              data: data
            }).success(function (response, status, header, config) {
              scope.showAlert('success', 'glyphicon glyphicon-ok-sign', scope.context.successMessage);
              generic.isDirtyForm = true;
            }).error(function (msg, status, header, config) {
              scope.showAlert('danger', 'glyphicon glyphicon-remove-sign', msg.developerMessage);
            });
          }
        };

        /* show alert message */
        scope.showAlert = function (event, icon, message) {
          generic.resetErrorMessages();
          generic.setMessageContent(event, icon);
          generic.errorMessages.push(message);
        };
      }
    };
  }]);

  /* directive for bind html content */
  app.directive('bindHtmlUnsafe', function ($compile) {
    return function ($scope, $element, $attrs) {
      var compile = function (newHTML) {
        newHTML = $compile('<span>' + newHTML + '</span>')($scope);
        $element.html('').append(newHTML);
      };

      var htmlName = $attrs.bindHtmlUnsafe;

      $scope.$watch(htmlName, function (newHTML) {
        if (!newHTML) {
          return;
        }
        compile(newHTML);
      });
    };
  });

  /* directive for password masking */
  app.directive('passwordMask', ['$timeout', function (timer) {
    return {
      restrict: 'A',
      transclude: true,
      template: '<input type="text" ng-cut="stopEvent($event)" ng-copy="stopEvent($event)" ng-paste="stopEvent($event)" ng-change="onNgModelChange()" ng-keypress="onKeypress($event)" directiveIsExecuting="true" ng-blur="changeToStar()">',
      replace: true,
      scope: true,
      link: function (scope, element, attrs) {
        var ngmodelArray = [], passwordScope = [];
        function deactivateDirective (message) {
          element.attr('directiveIsExecuting', 'false');
          return false;
        }
        if (!attrs.passwordMask || attrs.passwordMask === '') {
          return deactivateDirective(); // please add passwordScope with some value. That will have your password actually, if you use this directive
        }

        ngmodelArray = attrs.ngModel.split('.');
        passwordScope = attrs.passwordMask.split('.');

        if (ngmodelArray.length !== 2 || passwordScope.length !== 2) {
          return deactivateDirective(); // please give ngModel and passwordScope in format of Object.Object Ex: 'model.password'
        } else {
          scope[ngmodelArray[0]][ngmodelArray[1]] = '';
          scope[passwordScope[0]][passwordScope[1]] = '';
        }
        scope.unBindWatcher = scope.$watch(attrs.ngModel, function () {
          switch (ngmodelArray.length) {
            case 2:
              if (scope[ngmodelArray[0]][ngmodelArray[1]] === '') {
                scope[passwordScope[0]][passwordScope[1]] = '';
              }
              break;
          }
        });

        scope.stopEvent = function (event) {
          event.preventDefault();
        };

        scope.onNgModelChange = function () {
          switch (ngmodelArray.length) {
            case 2:
              if (scope[passwordScope[0]][passwordScope[1]].length - scope[ngmodelArray[0]][ngmodelArray[1]].length === 1) {
                var newly = scope[passwordScope[0]][passwordScope[1]].substring(0, scope[passwordScope[0]][passwordScope[1]].length - 1);
                scope[passwordScope[0]][passwordScope[1]] = '';
                scope[passwordScope[0]][passwordScope[1]] = newly;
              }
              if (scope[passwordScope[0]][passwordScope[1]].length - scope[ngmodelArray[0]][ngmodelArray[1]].length > 1) {
                scope[passwordScope[0]][passwordScope[1]] = '';
                scope[passwordScope[0]][passwordScope[1]] = scope[ngmodelArray[0]][ngmodelArray[1]];
              }
              break;
          }
        };
        scope.onKeypress = function (event) {
          ngmodelArray = attrs.ngModel.split('.');
          passwordScope = attrs.passwordMask.split('.');
          if ((attrs.type === 'text text') || (attrs.type === 'text')) {
            scope[passwordScope[0]][passwordScope[1]] = String.fromCharCode(event.which);
          }
          else if ( (attrs.type === 'password text')) {
            timer(function () {
              scope.$apply(scope.changeToStar());
            }, 2500);

            if (!attrs.ngMaxlength) {
              scope.maxLength = 100;
            } else {
              scope.maxLength = attrs.ngMaxlength;
            }
            if (scope[ngmodelArray[0]][ngmodelArray[1]].length < scope.maxLength) {
              scope.putInput(event);
            } else {
              event.preventDefault();
            }
          }
        };

        scope.putInput = function (event) {
          ngmodelArray = attrs.ngModel.split('.');
          var inputChar = String.fromCharCode(event.which);
          switch (ngmodelArray.length) {
            case 2:
              scope.insertStarToTextBox(inputChar);
              break;
          }
        };

        scope.insertStarToTextBox = function (inputChar) {
          var currentStarsAndACharacter = scope[ngmodelArray[0]][ngmodelArray[1]];
          if (currentStarsAndACharacter.length > 0) {
            scope.currentStars = scope.generateStars(currentStarsAndACharacter);
            scope[ngmodelArray[0]][ngmodelArray[1]] = scope.currentStars;
          }
          // get actual character
          scope[passwordScope[0]][passwordScope[1]] += inputChar;
        };

        scope.generateStars = function (currentStarsAndACharacter) {
          var length = currentStarsAndACharacter.length;
          var stars = '';
          for (var index = 1; index <= length; index++) {
            stars += '\u25CF';
          }
          return stars;
        };

        scope.changeToStar = function () {
          if ( (attrs.type === 'password text')) {
            scope.stars = '';
            for (var index = 1; index <= scope[passwordScope[0]][passwordScope[1]].length; index++) {
              scope.stars += '\u25CF';
            }
            scope[ngmodelArray[0]][ngmodelArray[1]] = scope.stars;
          }
          else if ((attrs.type === 'text text') || (attrs.type === 'text')) {
            scope[passwordScope[0]][passwordScope[1]] = scope[ngmodelArray[0]][ngmodelArray[1]];
          }
        };
      }
    };
  }]);

  /* directive for topMenuNavigation */
  app.directive('msTopMenuNavigation', function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/ms-top-menu-navigation.html',
      scope: {
        items: '=data'
      },
      link: function (scope) {
        scope.currentMenuIndex = 0;
      },
      controller: function ($scope, $http, $location, $compile) {
        var applyStylesMenu = function (selectedIndex) {
          $('.wizard-menu-step-' + (selectedIndex - 1)).removeClass('wtab-selected');
          $('.wizard-menu-step-' + (selectedIndex - 1)).addClass('wizard-ok');
          $('.wizard-menu-step-' + (selectedIndex - 1)).addClass('wborder-right');
          $('.wizard-menu-step-' + selectedIndex).addClass('wtab-selected');
        };
      }
    };
  });

  /* filter for displaying two digit after decimal point*/
  app.filter('decimalFilter', function () {
    return function (val) {
      return val.toFixed(2) + '%';
    };
  });

  /* directive to focus the control */
  app.directive('focusMe', function ($timeout, $parse) {
    return {
      link: function (scope, element, attrs) {
        var model = $parse(attrs.focusMe);
        scope.$watch(model, function (value) {
          console.log('value=', value);
          if (value === true) {
            $timeout(function () {
              element[0].focus();
            });
          }
        });
        // to address @blesh's comment, set attribute value to 'false'
        // on blur event:
        element.bind('blur', function () {
          console.log('blur');
          scope.$apply(model.assign(scope, false));
        });
      }
    };
  });

  /* */
  app.directive('msTextBox', ['$translate', function (translate) {
    return {
      restrict: 'E',
      scope: {
        texttype: '=',
        model: '=',
        pattern: '=',
        info: '=',
        maxlength: '=',
        trim: '=',
        inputId: '@'
      },
      template: '<ng-form name="myForm">' +
        '<div class="input-with-indicator">' +
        '<input id="{{inputId}}" type={{texttype}} ng-model="model" ng-trim={{trim}} name="textbox" maxlength={{maxlength}} class="form-control verification-text-box" required ng-pattern="{{pattern}}">' +
        '<span">' +
        '<i class="wizard-information" ng-bind="info">' +
        '</i>' +
        '</span>' +
        '<span id="{{inputId}}_Error1" ng-if="!myForm.textbox.$error.required && myForm.textbox.$error.pattern"><span class="visually-hidden">'+translate.instant('INVALID_DATA')+'</span></span>' +

        '</ng-form>',
      link: function (scope) {
        if (scope.texttype === 'password') {
          scope.$watch('model', function () {
            if (scope.model) {
              scope.model = scope.model.replace(/\s+/g, '');
            }
          });
        }
      }
    };
  }]);

  app.directive('msTextBoxConfirmPassword', function () {
    return {
      restrict: 'E',
      scope: {
        texttype: '=',
        model: '=',
        pattern: '=',
        info: '=',
        maxlength: '=',
        trim: '=',
        passwordModel: '=',
        matchMethod: '&',
        isMatch: '=',
        inputId: '@'
      },
      template: '<ng-form name="myForm">' +
        '<div class="row">' +
        '<div class="col-sm-10">' +
        '<input id="{{inputId}}" type={{texttype}} ng-model="model" ng-trim={{trim}} name="textbox" ng-change="matchMethod(model)" maxlength={{maxlength}} class="form-control verification-text-box" required >' +
        '</div>' +
        '<span id="{{inputId}}_Error1" ng-if="!isMatch"><span class="visually-hidden">does not match pattern</span></span>' +
        '</div>' +
        '</ng-form>',
      link: function (scope) {
        if (scope.texttype === 'password') {
          scope.$watch('model', function () {
            if (scope.model) {
              scope.model = scope.model.replace(/ /g, '');
              scope.matchMethod(scope.model);
            }
          });

        }
      }
    };
  });

  /* */
  app.directive('msTextBoxWithCallBack', function () {
    return {
      restrict: 'E',
      replace: false,
      scope: {
        texttype: '=',
        model: '=',
        pattern: '=',
        info: '=',
        isValid: '=',
        callBackModelCheck: '&',
        toolTipSuccessInfo: '=',
        toolTipErrorInfo: '=',
        toolTipInvalidInfo: '=',
        inputId: '@'
      },
      template: '<ng-form name="myForm">' +
        '<div class="col-sm-10 trim-left">' +
        '<input id={{inputId}} type="{{scope.texttype}}" ng-model="model" ng-change="matchRegex()" ng-blur="callBackModelCheck()" name="textbox" class="form-control  verification-text-box" required ng-pattern="{{pattern}}" maxLength="35" aria-invalid="{{isInvalid()}}" aria-describedby="{{inputId}}_Error1 {{inputId}}_Error2">' +
        '</div> ' +
        '<div class="col-md-2" ng-show="isValid && !myForm.textbox.$error.required && !myForm.textbox.$error.pattern">' +
        '<div class="pull-left error-tooltip"><img src="../../../themes/default/images/icon_check.png" class="cursor-pointer" tooltip-html-unsafe="{{toolTipSuccessInfo}}" tooltip-placement="top check" alt=""></div>' +
        '</div>' +
        '<div class="col-md-2" ng-show="!isValid && isValid !== undefined && model.trim().length > 0">' +
        '<div class="pull-left error-tooltip"><img src="../../../themes/default/images/icon_close.png" class="cursor-pointer" tooltip-html-unsafe="{{toolTipErrorInfo}}" tooltip-placement="top invalid" alt=""></div>' +
        '</div>' +
        '<div class="col-md-2" ng-show="myForm.textbox.$error.pattern">' +
        '<div class="pull-left error-tooltip"><img src="../../../themes/default/images/icon_alert_1.png" class="cursor-pointer" tooltip-html-unsafe="{{toolTipInvalidInfo}}" tooltip-placement="top invalid" alt=""></div>' +
        '</div>' +
        '<span id="{{inputId}}_Error1" ng-if="myForm.textbox.$error.pattern""><span class="visually-hidden" ng-bind-html="toolTipInvalidInfo"></span></span>' +
        '<span id="{{inputId}}_Error2" ng-if="!isValid && isValid !== undefined && model.trim().length > 0"><span class="visually-hidden" ng-bind-html="toolTipErrorInfo"></span></span>' +
        '</ng-form>',
      link: function (scope, element, attr) {
        var inputField = element.find('input');
        scope.matchRegex = function () {
          if (scope.model) {
            scope.model = scope.model.replace(/ /g, '');
          }
        };
        scope.isInvalid = function () { return (!scope.isValid && inputField.hasClass('ng-dirty')) ? 'true' : 'false';};
        /*scope.$watch('model',function(){
          scope.callBackModelCheck();
        });*/

      // var fn = $parse(attr['ngBlur']);
      // element.on('blur', function (event) {
      //  scope.$apply(function () {
      //    fn(scope, { $event: event });
      //  });
      // });
      }
    };
  });

  app.directive('triStateCheckbox', function () {
    return {
      replace: true,
      restrict: 'E',
      scope: { checkboxes: '=' },
      template: '<div class="col-md-12 padding-reset"><input type="checkbox" ng-model="master" ng-change="masterChange()">Select All' + '<div class="col-md-12" ng-repeat="cb in checkboxes">' + '<input type="checkbox" ng-model="cb.isSelected" ng-change="cbChange()">{{cb.desc}}' + '</div>' + '</div>',
      controller: function ($scope, $element) {
        $scope.masterChange = function () {
          if ($scope.master) {
            angular.forEach($scope.checkboxes, function (cb, index) {
              cb.isSelected = true;
            });
          } else {
            angular.forEach($scope.checkboxes, function (cb, index) {
              cb.isSelected = false;
            });
          }
        };
        var masterCb = $element.children()[0];
        $scope.cbChange = function () {
          var allSet = true, allClear = true;
          angular.forEach($scope.checkboxes, function (cb, index) {
            if (cb.isSelected) {
              allClear = false;
            } else {
              allSet = false;
            }
          });
          if (allSet) {
            $scope.master = true;
            masterCb.indeterminate = false;
          }
          else if (allClear) {
            $scope.master = false;
            masterCb.indeterminate = false;
          } else {
            $scope.master = false;
            masterCb.indeterminate = true;
          }
        };
        $scope.cbChange(); // initialize
      },
    };
  });

  /* directive for set tab index */
  app.directive('setTabIndex', function () {
    return function (scope, element, attr) {
      element.bind('keydown', function (event) {
        $('.' + attr.setTabIndex).focus();
      });
    };
  });

}(window.app));
