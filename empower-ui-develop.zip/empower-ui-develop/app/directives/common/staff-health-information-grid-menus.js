(function (app) {
  'use strict';

  /* directive for health information grid menus */
  app.directive('msStaffHealthInformationGridMenus', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'templates/staff-health-information-grid-menus.html'
    };
  }]);

}(window.app));
