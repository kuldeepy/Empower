(function (app) {
  'use strict';

  /* directive for health information popup */
  app.directive('msHealthInformationPopup', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/my-health-information/templates/my-health-information-popup.html'
    };
  }]);

}(window.app));
