(function (app) {
  'use strict';
  app.directive('externalIdentifiers', [function () {
    return {
      restrict: 'EA',
      replace: true,
      scope: {
        ids: '='
      },
      link: function (scope, element) {
        scope.$watch('ids', function (newVal) {
          if (!Array.isArray(newVal)) {
            return;
          }
          var identifiers = _.compact(_.map(newVal, function (val) {
            if (val.SourceAssigningFacility && val.SourceId) {
              return val.SourceAssigningFacility + ':' + val.SourceId;
            } else if (val.SourceId) {
              return val.SourceId;
            } else {
              return null;
            }
          })).join(', ');
          element.append(identifiers);
        });
      }
    };
  }]);
})(window.app);
