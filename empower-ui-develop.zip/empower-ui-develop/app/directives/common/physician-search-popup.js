(function (app) {
  'use strict';

  /* directive for blue button popup */
  app.directive('msPhysicianSearchPopup', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/my-health-information/templates/physician-search-popup.html'
    };
  }]);

}(window.app));
