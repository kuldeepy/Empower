(function (app) {
  'use strict';

  /* directive for task center edit discussion */
  app.directive('msTaskCenterEditDiscussion', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/tc-edit-discussion.html'
    };
  }]);

}(window.app));
