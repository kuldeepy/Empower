(function (app) {
  'use strict';

  /* directive for displaying alert */
  app.directive('msAlert', ['$sce', 'alertService', function (sce, alertService) {
    var alertId = 'alert_app-top';
    return {
      restrict: 'E',

      transclude: true,

      templateUrl: app.root + 'templates/common/ms-alert.html',

      link: function (scope) {
        alertService.addPlacement(alertId);
        scope.alerts = alertService.getCurrent(alertId);
      },

      controller: function ($scope, alertService) {
        $scope.getTrustedhtml = function (message) {
          return sce.trustAsHtml(message);
        };

        /* close the alert container */
        $scope.close = function () {
          alertService.closeAlert(alertId);
        };
      }

    };
  }]);

}(window.app));
