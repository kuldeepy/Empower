(function (app) {
  'use strict';
  app.directive('warnLoseChanges', ['$parse', '$dialogFactory', '$location', '$document', '_', 'alertService', '$translate', function (parse, dialog, location, document, _, alert,translate) {
    var parser = document[0].createElement('a');
    return {
      restrict: 'A',
      scope: {
        changeObj: '=warnLoseChanges'
      },
      link: function (scope, element, attrs) {
        parse(attrs.warnLoseChanges)(scope);
        scope.$watch('changeObj', function (newVal, oldVal) {
          if (newVal !== oldVal && newVal.hasChanges !== false) {
            scope.changeObj.hasChanges = true;
          }
        }, true);
        scope.$on('$locationChangeStart', function (event, next, current) {
          if (scope.confirmed) {
            return;
          }

          if (scope.changeObj.hasChanges) {
            event.preventDefault();

            var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), 'You have unsaved changes. Do you want to continue?');
            dialogCallback.result.then(function () {
              scope.changeObj.hasChanges = false;
              alert.clear();
              scope.confirmed = true;
              parser.href = next;
              location.path(parser.pathname.substr(1));
              _.forEach((parser.search || '').substr(1).split('='), function (query) {
                var parts = query.split('=');
                if (parts.length > 1) {
                  location.search(parts[0], parts[1]);
                }
              });
            });
          }
        });
      }
    };
  }]);
})(window.app);
