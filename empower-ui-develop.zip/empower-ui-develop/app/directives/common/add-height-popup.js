(function (app) {
  'use strict';

  /* directive for addig new height */
  app.directive('addHeightPopup', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/my-health-information/templates/add-height-popup.html'
    };
  }]);

}(window.app));
