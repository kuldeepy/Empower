(function (app) {
  'use strict';
  /* directive for cancel confirm */
  app.directive('msConfirmCancel', ['$location', function (location) {
    return {
      restrict: 'E',
      scope: {
        confirmCancel: '=',
        callBackOnYes: '&',
        containerObj: '&',
        model: '@'
      },
      replace: true,
      templateUrl: app.root + 'templates/confirm-cancel.html',
      link: function (scope, element, attrs) {
        scope.showModal = function () {
          element.modal('show');
        };

        scope.confirmCancel = function () {
          if (location.path() !== '/user-settings') {
            if (_.filter(scope.containerObj(), function (obj) { return obj[scope.model]; }).length && (location.path().split('/').pop() !== 'security-settings')) {
              scope.showModal();
            } else {
              scope.callBackOnYes();
            }
          } else {
            scope.callBackOnYes();
          }
        };
      }
    };
  }]);
}(window.app));
