(function (app) {
  'use strict';
  /* directive for topMenuNavigation */
  app.directive('msSideMenuNavigation', function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/ms-side-menu-navigation.html',
      scope: {
        steps: '=data'
      },
      require: '^msStepFlowNavigation',
      link: function (scope, element, attrs, navCtrl) {
        scope.$watch('steps', function (val) {
          angular.forEach(val, function (step, idx) {
            step.status = idx === scope.currentStepIndex ? '' /*'active'*/ : (idx > scope.currentStepIndex ? '' : 'ok');
          });
        });
        navCtrl.scope.$watch('stepIndex', function (newVal, oldVal) {
          scope.currentStepIndex = newVal;
          angular.forEach(scope.steps, function (step, idx) {
            step.status = idx === newVal ? '' /*'active'*/ : (idx > newVal ? '' : 'ok');
          });
        });
      },
      controller: ['$scope', function (scope) {
        scope.letter = function (idx) {
          return String.fromCharCode(idx + 65).toLocaleLowerCase();
        };
      }]
    };
  });

})(window.app);
