(function (app) {
  'use strict';

  /* directive to bring popup for search */
  app.directive('msTaskCenterAdvanceSearch', function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/task-center-advance-search.html'
    };
  });
}(window.app));
