(function (app) {
  'use strict';

  /* directive for health information popup print */
  app.directive('msHealthInformationPopupPrint', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/my-health-information/templates/my-health-information-popup-print.html'
    };
  }]);

}(window.app));
