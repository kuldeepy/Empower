(function (app) {
  'use strict';

  app.directive('iuiShouldShow', ['$location', 'session', function (location, session) {
    return {
      restrict: 'A',
      scope: false,
      link: function (scope, element, attrs) {
        if (!attrs.iuiShouldShow) {
          return;
        }

        var sessionValue = session.get(attrs.iuiShouldShow);
        var shouldShow = sessionValue === null ? true : sessionValue === 'true';
        var queryParam = location.search()[attrs.iuiShouldShow];

        // query param will always take precedence if present
        if (queryParam != undefined) {
          shouldShow = queryParam.toLowerCase() === 'true';
        }

        session.set(attrs.iuiShouldShow, shouldShow);
        scope[attrs.iuiShouldShow] = shouldShow;

        if (shouldShow) {
          return element.show();
        } else {
          element.removeClass('hidden-xs');
          return element.hide();
        }
      }
    };
  }]);
}(window.app));
