(function (app) {
  'use strict';

  /* directive for deleting grid record */
  app.directive('msTransmitPopup', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/transmit-popup.html'
    };
  }]);

}(window.app));
