(function (app) {
  'use strict';

  /* directive for health information popup menus */
  app.directive('msHealthInformationPopupMenus', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/my-health-information/templates/my-health-information-popup-menus.html'
    };
  }]);

}(window.app));
