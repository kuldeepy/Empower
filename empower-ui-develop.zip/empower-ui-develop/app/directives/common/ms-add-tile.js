(function (app) {
  'use strict';

  /* directive for displaying tiles */
  app.directive('msTile', function ($compile) {
    return {
      restrict: 'E',
      transclude: true,
      link: function (scope, element, attrs) {
        attrs.$observe('tile', function (value) {
          if (angular.isDefined(value)) {
            var e = $compile(value)(scope);
            element.html(e);

          // element.parent().append(element.contents());
          }
        });
      },

      controller: function ($scope) {}

    };
  });

}(window.app));
