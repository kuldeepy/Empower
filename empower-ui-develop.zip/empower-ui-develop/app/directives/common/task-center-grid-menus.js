(function (app) {
  'use strict';

  /* directive for health information grid menus */
  app.directive('msTaskCenterGridMenus', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/task-center-grid-menus.html'
    };
  }]);

}(window.app));
