(function (app) {
  'use strict';

  /* directive for health information popup */
  app.directive('msTaskCenterPopup', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/task-center-popup.html'
    };
  }]);

}(window.app));
