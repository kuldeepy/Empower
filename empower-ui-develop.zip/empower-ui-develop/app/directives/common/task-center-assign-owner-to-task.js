(function (app) {
  'use strict';

  /* directive for task center assign owner to task */
  app.directive('msTaskCenterAssignOwnerToTask', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/tc-assign-owner-to-task.html'
    };
  }]);

}(window.app));
