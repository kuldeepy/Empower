(function (app) {
  'use strict';

  /* directive for health information popup add */
  app.directive('msHealthInformationPopupAdd', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/my-health-information/templates/my-health-information-popup-add.html'
    };
  }]);

}(window.app));
