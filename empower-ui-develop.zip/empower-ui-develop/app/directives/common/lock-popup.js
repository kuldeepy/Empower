(function (app) {
  'use strict';

  /* directive for Mark record as private and Not private */
  app.directive('msLockPopup', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/lock-popup.html'
    };
  }]);

}(window.app));
