(function (app) {
  'use strict';

  app.directive('scriptInjector', function () {
    var update = function (element) {
      return function (scope) {
        element.empty();

        angular.forEach(scope.scripts, function (_script, _key) {
          var _tag = angular.element(document.createElement('script'));
          _script = '//@ sourceURL=' + _key + '\n' + _script;
          _tag.text(_script);
          element.append(_tag);
        });
      };
    };

    return {
      restrict: 'EA',
      scope: { scripts: '=', test: '=' },
      link: function (s, e) {
        s.$watch(update(e));
      }
    };

  });

}(window.app));
