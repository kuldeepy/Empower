(function (app) {
  'use strict';
  /* directive for topMenuNavigation */
  app.directive('msStepFlowTop', function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/ms-top-menu-navigation.html',
      scope: {
        items: '=data',
        currentMenuIndex: '=currentIndex',
        complete: '='
      },
      link: function (scope, element, attrs) {
        var config = function () {
          var index = scope.currentMenuIndex;
          angular.forEach(scope.items, function (item, idx) {
            item.active = idx === index ? 'wtab-selected' : (idx > index ? 'wtab-next' : 'wtab-passed');
            item.isComplete = idx < index;
          });
        };
        scope.isComplete = function (item, idx) {
          return idx < scope.currentMenuIndex;
        };
        scope.getState = function (item, index) {
          item.active = scope.currentMenuIndex === index ? 'wtab-selected' : (scope.currentMenuIndex < index ? 'wtab-next' : 'wtab-passed');
        };
        scope.$watch('currentMenuIndex', function (newVal) {
          config();
        });
        scope.$watch('complete', function () {
          angular.forEach(scope.items, function (item, idx) {
            if (scope.isComplete(item, idx)) {
              item.active = 'wtab-passed';
              item.isComplete = true;
            }
          });
        });
      }
    };
  });
})(window.app);
