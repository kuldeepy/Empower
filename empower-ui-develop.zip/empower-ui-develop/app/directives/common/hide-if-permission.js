(function (app) {
  'use strict';
  app.directive('iuiHideIfPermission', ['$log', 'userPermissionsSvc', function (log, userPermissionsSvc) {
    return {
      scope: false,
      restrict: 'A',
      link: function (scope, element, attrs) {
        if (!attrs.iuiHideIfPermission) {
          return;
        }
        var array = JSON.parse(attrs.iuiHideIfPermission);
        if (userPermissionsSvc.userHasPermission(array)) {
          element.hide();
        }
      }
    };
  }]);
}(window.app));
