(function (app) {
  'use strict';

  app.directive('iuiStaffLoginHeader', [function () {
    return {
      restrict: 'E',
      scope: {
        hideLoginHeader: '='
      },
      templateUrl: app.root + 'templates/common/iui-staff-login-header.html'
    };
  }]);
}(window.app));
