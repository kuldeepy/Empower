(function (app) {
  'use strict';

  /* directive for task center new discussion */
  app.directive('msTaskCenterNewDiscussion', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/tc-new-discussion.html'
    };
  }]);

}(window.app));
