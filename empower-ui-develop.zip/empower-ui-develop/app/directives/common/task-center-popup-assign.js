(function (app) {
  'use strict';

  /* directive for health information grid menus */
  app.directive('msTaskCenterPopupAssign', [function () {
    return {
      restrict: 'C',
      scope: true,
      templateUrl: app.root + 'modules/task-center/templates/task-center-popup-assign-task.html',
      link: function (scope) {
        scope.taskAssignee = [
          { label: 'Staff 1', value: 1 },
          { label: 'Staff 2', value: 2 }
        ];

        scope.taskPriority = [
          { label: 'High', value: 1 },
          { label: 'Moderate', value: 2 },
          { label: 'Routine', value: 3 }
        ];

      },
      controller: function ($scope, $http, $location, $compile) {}
    };
  }]);

}(window.app));
