(function (app) {
  'use strict';

  /* directive for task center edit discussion */
  app.directive('msTaskCenterDiscardCommentDiscussion', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/tc-discard-comment-discussion.html'
    };
  }]);

}(window.app));
