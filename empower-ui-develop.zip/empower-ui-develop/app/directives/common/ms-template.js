(function (app) {
  'use strict';

  /* directive for displaying template */
  app.directive('msTemplate', function ($compile) {
    return {
      restrict: 'E',
      transclude: true,
      link: function (scope, element, attrs) {
        attrs.$observe('tilecontent', function (value) {
          var e = $compile(attrs.tilecontent)(scope);
          element.html(e);
        });
      },

      controller: function ($scope) {}

    };
  });

}(window.app));
