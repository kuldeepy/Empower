(function (app) {
  'use strict';
  app.directive('ihAddress', ['medseekApi', function (api) {
    var promise = api.allStates.get().$promise;
    return {
      restrict: 'E',
      template: '<div>{{address}}<br>{{city}}{{comma}} {{secondPart}}</div>',
      replace: true,
      scope: {
        profile: '='
      },
      link: function (scope) {
        var state;
        if ((scope.profile.city) && (scope.profile.zipCode || scope.profile.state || scope.profile.stateName)) {
          scope.comma = ',';
        }
        scope.address = scope.profile.addressLine1;
        scope.city = scope.profile.city;

        if (scope.profile.stateName) {
          scope.secondPart = (scope.profile.stateName + ' ' + (scope.profile.zipCode || '')).trim();
        } else if (scope.profile.state) {
          promise.then(function (data) {
            state = _.find(data.embedded.states, {
              id: scope.profile.state.toString()
            });
            var stateName;
            if (state) {
              stateName = state.name;
            } else {
              stateName = '';
            }
            scope.secondPart = (stateName + ' ' + (scope.profile.zipCode || '')).trim();
          });
        } else {
          scope.secondPart = scope.profile.zipCode;
        }
      }
    };
  }]);
})(window.app);
