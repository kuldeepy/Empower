(function (app) {
  'use strict';

  /* directive for health information popup dispute */
  app.directive('msHealthInformationPopupDispute', ['generic', 'myHealthInformation', function (generic, myHealthInformation) {
    return {
      restrict: 'C',
      transclude: true,
      scope: true,
      templateUrl: app.root + 'modules/my-health-information/templates/my-health-information-popup-dispute.html',
      link: function (scope) {
        scope.totalIndex = 0;
        scope.signUpData = { leftMenus: [] };
        scope.controller = {
          confirmMessage: 'Thank you. The dispute health record request has been submitted.<br/> You will receive a response within 1-3 business days. You may check on the status of this request in the View Pending section of the request Center.'
        };

      },
      controller: function ($scope, $http, $location, $compile, session, $dialogFactory, $translate) {
        /**/
        $scope.setDirty = function () {
          generic.isDirtyForm = false;
        };
        $scope.healthInformation = {};
        $scope.controllerData = {};

          /**/
        $scope.cancel = function (form) {
          if (form.$dirty) {
              var confirmDialog = $dialogFactory.confirm('confirmDialog', $translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), $translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
            confirmDialog.result.then(function () {
              myHealthInformation.controllerData.dataModel = {};
              $scope.closePopup('.my-heath-information-view');
              myHealthInformation.actionForm.$setPristine();
            });
            return;
          }
          myHealthInformation.closeClick('.my-heath-information-view');
        };

        /* watch method for load the controls data */
        $scope.$watch('myHealthInformation.controllerData.requestType[0]', function () {
          // EMPO-8048 myHealthInformation.currentView was getting as undefined on first load
          // $scope.healthInformation.currentView = myHealthInformation.viewRecord();
          // if (myHealthInformation.currentView && myHealthInformation.currentView.length === 0) {
          //  myHealthInformation.currentView = $scope.healthInformation.currentView;
          // }

          
          if (myHealthInformation.controllerData.requestType.length !== 0 && myHealthInformation.controllerData.requestType[0].IdPrefix === 'DIS') {
            $scope.signUpData.leftMenus = [];
            myHealthInformation.controllerData.dataModel = {};
            $scope.menuStepIndex = 0;
            $scope.currentStepIndex = 0;
            if (myHealthInformation.controllerData.requestType[0].EnableTermsAndConditions && myHealthInformation.controllerData.requestType[0].IdPrefix === 'DIS') {
              $scope.signUpData.leftMenus.push(generic.getMenuData($translate.instant('TERMS_AND_CONDITIONS_MENU'), 1, ''));
            } else {
              $scope.resetErrorAndSetStep($scope.currentStepIndex + 1);
            }

            if (myHealthInformation.clinicalDocument) {
              $scope.signUpData.leftMenus.push(generic.getMenuData($translate.instant('CONFIRM_CLINICAL_DOCUMENT_DISPUTE_MENU'), $scope.signUpData.leftMenus.length + 1, '', ''));
            } else {
              $scope.signUpData.leftMenus.push(generic.getMenuData($translate.instant('CONFIRM_RECORD_DISPUTE_MENU'), $scope.signUpData.leftMenus.length + 1, '', ''));
            }
            $scope.signUpData.leftMenus.push(generic.getMenuData($translate.instant('ENTER_DISPUTE_DETAIL_MENU'), $scope.signUpData.leftMenus.length + 1, '', ''));
          }
        });

        /* reset error message and set the previous step */
        $scope.resetErrorAndGotoPreviousStep = function (stepNumber) {
          $scope.controller.error = '';
          $scope.menuStepIndex -= 1;
          $scope.previousStep();
        };

        /* reset error message and set the next step */
        $scope.resetErrorAndSetStep = function (stepNumber) {
          $scope.controller.error = '';
          $scope.nextStep();
        };

        /* reset error message and set the next step */
        $scope.confirmNextClick = function (stepNumber) {
          $scope.controller.error = '';
          $scope.menuStepIndex += 1;
          $scope.nextStep();
        };

        /* reset error message and set the next step */
        $scope.enterDisputeDetailsNextClick = function (stepNumber) {
          myHealthInformation.actionForm.$setPristine();
          $scope.controller.error = '';
          generic.errorMessages = [];

          $scope.saveUserProfileData();
        };

        /* Ok click at the final step*/
        $scope.okClick = function () {
          if (myHealthInformation.data.Key === 'testResults' || myHealthInformation.data.Key === 'ImportedRecords' && (myHealthInformation.data.selectedRow.read !== true || myHealthInformation.data.selectedRow.markAsPrivate !== true)) {
            generic.scope.$emit(myHealthInformation.controllerData.updateParentMethodName, myHealthInformation.controllerData.updatedMessage);
          }
          $scope.closePopup('.my-heath-information-view');
        };

        var sessionId = session.get('sessionId');
        var patient = JSON.parse(session.get('patient'));

        /* Save dispute for a health record*/
        $scope.saveUserProfileData = function () {
          if (myHealthInformation.controllerData.dataModel !== '') {
            $scope.isDisputeSuccess = false;
            $scope.showOk = true;
            generic.patientId = 1;
            var doc = '';
            var associatedDocuments = '';

            var key = myHealthInformation.getHealthInformationViewKey(myHealthInformation.data.Key);

            var disputePath = 'empower/patients/' + patient.patientId + '/health-info/' + key + '/' + generic.dataModel[0].selectedData.id + '/dispute';

            if (myHealthInformation.data.Key === 'ImportedRecords' || myHealthInformation.data.Key === 'clinical-documents') {
              associatedDocuments = generic.dataModel[0].selectedData.id;
              disputePath = 'empower/patients/' + patient.patientId + '/documents/' + generic.dataModel[0].selectedData.id + '/dispute';
            } else {
              doc = JSON.parse(generic.dataModel[0].selectedData.documents);
              $.each(doc, function (i, item) {
                associatedDocuments += doc[i].id + ',';
              });
            }
            var requestEntity = {};
            requestEntity.RequestPrefix = myHealthInformation.controllerData.requestType[0].IdPrefix;
            requestEntity.RequestType = myHealthInformation.controllerData.requestType[0].Name;
            requestEntity.RequestTypeName = myHealthInformation.data.Key;
            requestEntity.PatientId = patient.patientId;
            requestEntity.PatientName = patient.patientName;
            requestEntity.CompletionMode = myHealthInformation.controllerData.requestType[0].CompletionType;
            requestEntity.Detail = JSON.stringify($scope.getDetails());
            var disputeRequestData = {};
            disputeRequestData.Question = myHealthInformation.controllerData.dataModel.DisputeDetails;
            disputeRequestData.MhrHealthRecord = JSON.stringify($scope.healthInformation.currentView);
            disputeRequestData.RequestEntity = requestEntity;
            disputeRequestData.MedseekRecordId = generic.dataModel[0].selectedData.medseekRecordId;
            disputeRequestData.documentIds = associatedDocuments;
            var reqObject = {
              'documentIds': associatedDocuments,
              'messageBody': JSON.stringify(disputeRequestData)
            };
            if (($scope.healthInformation.currentView === null) || ($scope.healthInformation.currentView === undefined))
              $scope.healthInformation.currentView = '[]';

            if (generic.errorMessages.length === 0) {
              $http({
                method: 'POST',
                url: app.api.root + disputePath,
                headers: {
                  'Authorization': 'bearer ' + sessionId,
                  'Content-Type': 'application/json;charset=utf-8'
                },
                data: reqObject
              }).success(function (response, status, header, config) {
                myHealthInformation.controllerData.dataModel = {};
                $scope.controllerData.requestId = response.results.Retval;
                $scope.isDisputeSuccess = true;
                generic.isDirtyForm = generic.trueValue;
                $scope.menuStepIndex += 1;
                $scope.nextStep();
              }).error(function (response, status, header, config) {
                generic.errorMessages.push($translate.instant('UNABLE_TO_SUBMIT_REQUEST_TEXT'));
                generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
              });
            }
          }
        };

        /*get the request details*/
        $scope.getDetails = function () {
          var details = [
            { type: 'DIS', key: 'Question', value: myHealthInformation.controllerData.dataModel.DisputeDetails }
          ];
          if (myHealthInformation.controllerData.dataModel.Df && myHealthInformation.controllerData.dataModel.Df.Custom) {
            for (var skey in myHealthInformation.controllerData.dataModel.Df.Custom) {
              details.push({ type: 'Custom', key: skey, value: myHealthInformation.controllerData.dataModel.Df.Custom[skey]});
            }
          }
          return details;
        };

        $scope.closePopup = function (className) {
          $(className).modal(generic.closePopupModalClassName);
          myHealthInformation.clearErrorMessage();
        };
      }
    };

  }]);

}(window.app));
