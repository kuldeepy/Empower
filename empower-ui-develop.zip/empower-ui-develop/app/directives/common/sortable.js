(function (app) {
  'use strict';

  app.directive('sortable', [function () {
    return {
      restrict: 'A',
      link: function (scope, element, attrs) {
        var sortHandler = (attrs.onSort) ? scope[attrs.onSort] : angular.noop;

        element.sortable({
          update: function (jqEv, data) {
            sortHandler($(jqEv.target), $(data.item));
          }
        });
        element.disableSelection();
      }
    };
  }]);

}(window.app));
