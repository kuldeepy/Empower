(function (app) {
  'use strict';

  /* directive for printing grid record */
  app.directive('msPrintPopup', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/print-popup.html'
    };
  }]);

}(window.app));
