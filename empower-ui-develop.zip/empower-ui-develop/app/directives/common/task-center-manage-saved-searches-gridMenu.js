(function (app) {
  'use strict';

  /* directive for health information grid menus */
  app.directive('msTaskCenterSavedSearchesGrid', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/task-center/templates/task-center-manage-saved-searches-gridMenu.html'
    };
  }]);

}(window.app));
