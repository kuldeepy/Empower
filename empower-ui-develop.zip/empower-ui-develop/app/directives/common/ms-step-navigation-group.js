(function (app) {
  'use strict';
  /* directive for topMenuNavigation */
  app.directive('msStepNavigationGroup', ['$translate', 'session','localStorageSvc', function (translate, session, localStorageSvc) {
    return {
      restrict: 'E',
      scope: {
        title: '@'
      },
      require: '^msStepFlowNavigation',
      link: function (scope, element, attrs, stepFlow) {
        var sessionCulture = localStorageSvc.get('cultureName');
        translate.use(sessionCulture || translate.preferredLanguage()).then(function (translation) {
          scope.$parent.title = translate.instant(scope.title);
          stepFlow.addStep(scope.$parent);
          translate.use(sessionCulture);
        });
      }
    };
  }]);
})(window.app);
