(function (app) {
  'use strict';

  /* directive for date field control */
  app.directive('msDatePicker', [function () {
    var open = function (scope, $event) {
      $event.preventDefault();
      $event.stopPropagation();
      scope.dateObject.opened = true;
    };

    return {
      restrict: 'E',
      replace: true,
      scope: true,
      template: '<div>' +
        '<span>' +
        '<input ' +
        'type="text"  ' +
        'class="form-control"  ' +
        'tooltip="" ' +
        'tooltip-placement="" ' +
        'ng-required="" ' +
        'ng-model="dateVal" ng-change="setDirty()" ' +
        'datepicker-popup="{{dateObject.format}}" is-open="dateObject.opened" readonly/>' + // ng-keypress="buttonModifier()" ng-change="buttonModifier()"   />' +
        '<button class="btn btn-default" ng-click="open($event)"><i class="glyphicon glyphicon-calendar"></i><span class="sr-only" translate="SR_OPEN_CALENDAR_WIDGET"></span></button>' +
        '</span>' +
        ' </div>',
      link: function (scope, element, attributes) {
        scope.minDate = (scope.minDate) ? null : new Date();
        scope.formats = ['MM-dd-yyyy', 'dd-MM-yyyy', 'dd-MMMM-yyyy', 'yyyy/MM/dd', 'shortDate'];

        scope.dateObject = {
          minDate: new Date(),
          opened: false,
          format: scope.formats[0]
        };

        /* function to open datepicker icon when clicked on it */
        scope.open = open.bind(null, scope);
      }
    };
  }]);

}(window.app));
