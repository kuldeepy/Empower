(function (app) {
  'use strict';

  /* directive for health information popup delete */
  app.directive('msHealthInformationPopupDelete', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/my-health-information/templates/my-health-information-popup-delete.html'
    };
  }]);

}(window.app));
