﻿(function (app) {
  'use strict';

  app.filter('ihiDateFormat', ['$filter', 'localStorageSvc', function (filter, localStorageSvc) {
    function ihiDateFormatFilter(value, displayDateOnly) {
      var cultureName = localStorageSvc.get('cultureName') || 'en-US';
      var isSpanishCulture = (cultureName.indexOf('es') === 0);
      var format = isSpanishCulture ? 'DD MMMM, YYYY' : 'MMMM DD, YYYY';
      if (!displayDateOnly) {
        format += ' HH:MM a';
      }

      var formattedDate = filter('amDateFormat')(value, format);
      return formattedDate;
    }
    return ihiDateFormatFilter;
  }]);
})(window.app);
