(function (app) {
  'use strict';

  /* directive for task center new discussion */
  app.directive('msTaskCenterDetailedView', ['generic', function (generic) {
    return {
      restrict: 'E',
      scope: true,
      templateUrl: app.root + 'modules/task-center/templates/task-center-detailed-view-popup.html',
      controller: ['$scope', 'api', '$q', 'medseekApi', 'session', 'DiscussionData', function (scope, api, q, medseekApi, session, DiscussionData) {
        scope.taskView = {};

        scope.$watch(function () {
          return scope.model.taskId;
        }, function (taskId) {
          if (taskId) {
            scope.taskView = {};
            scope.openTaskDetailedView(taskId);
          }
        });


        /* function to view detailed view of the tasks */
        scope.openTaskDetailedView = function (taskId) {
          var roleId = JSON.parse(session.get('userObject')).RoleIds[0].Id;
          medseekApi.task_center.getTask.get({ taskId: +taskId, roleId: roleId }).$promise.then(function (response) {
            scope.taskView.selectedTaskInformation = response.results.Retval;

            if (!angular.isUndefinedOrNull(scope.taskView.selectedTaskInformation.TaskPayload) && scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData === '') {
              scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData = JSON.parse(scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData);
              scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData.MhrHealthRecord = JSON.parse(scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData.MhrHealthRecord);
            }
            if (!angular.isUndefined(scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData.RequestEntity)) {
              scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData.RequestEntity = JSON.parse(scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData.RequestEntity);
              scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData.RequestEntity.Detail = JSON.parse(scope.taskView.selectedTaskInformation.TaskPayload.PayLoadData.RequestEntity.Detail);
            }
            scope.bindDiscussions();

          }, function (response) {
            generic.errorMessages.push(response.data.developerMessage);
            generic.setMessageContent('danger', 'glyphicon glyphicon-remove-sign');
          });

        };

        scope.bindDiscussions = function () {
          var isMemberPermission = new DiscussionData(scope, api, q);
          medseekApi.task_center.getDiscussions.get({ taskId: +scope.model.taskId, userId: session.get('userId') || 0 }, null).$promise.then(function (response) {
            scope.taskView.discussionData = [];
            response.results.Retval.forEach(function (data) {
              if (isMemberPermission.isMemberExist(data.MemberList, session.get('userId'))) {
                scope.taskView.discussionData.push(data);
              }
            });
          });
        };

      }]
    };
  }]);

}(window.app));
