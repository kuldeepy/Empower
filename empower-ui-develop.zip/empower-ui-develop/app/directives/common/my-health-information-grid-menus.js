(function (app) {
  'use strict';

  /* directive for health information grid menus */
  app.directive('msHealthInformationGridMenus', [function () {
    return {
      restrict: 'C',
      templateUrl: app.root + 'modules/my-health-information/templates/my-health-information-grid-menus.html'
    };
  }]);

}(window.app));
