(function (app) {
  'use strict';
  app.directive('dateViewFormatter', function ($window) {
    return {
      require: '^ngModel',
      restrict: 'A',
      link: function (scope, elm, attrs, ctrl) {
        var moment = $window.moment;
        var dateFormat = attrs.dateViewFormatter;

        ctrl.$formatters.unshift(function (modelValue) {
          if (!dateFormat || !modelValue) {
            return '';
          }
          var retVal = moment(modelValue).format(dateFormat);
          return retVal;
        });

      }
    };
  });
}(window.app));
