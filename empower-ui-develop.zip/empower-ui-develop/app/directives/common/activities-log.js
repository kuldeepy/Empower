(function (app) {
  'use strict';
  app.directive('activitiesLog', ['medseekApi', '$q', 'session', '$window', 'alertService', 'NotificationsService', 'UserResolverService', 'DynamicTextFormatterSvc', '$translate',
    function (msApi, q, session, window, alertService, notificationsService, userService, dynamicTextFormatterSvc, translate) {
      return {
        restrict: 'E',
        scope: {
          userId: '=',
          patientId: '=',
          showInstructions: '=',
          breadcrumb: '='
        },
        templateUrl: '/templates/activities-log.html',
        link: function (scope) {
          /* get activity log */
          scope.getActivityLog = function (jsonData) {
            jsonData.dataAccessAction = ["'User account accessed'"];
            notificationsService.patientActivityLogWithOffSet(jsonData, msApi, q).then(function (result) {
              scope.currentPortal = session.get('portal');
              scope.activityResults = (scope.patientId && scope.currentPortal == 'staff') ? scope.mapPatientActivityLog(result.results.Retval) : scope.mapUserActivityLog(result.results.Retval);

              if (result.results.Retval.length > 0) {
                scope.pagingOption.totalItems = result.results.Retval[0].TotalRecords;
              }
            }, function () {
              scope.errorMessage = translate.instant('ACTIVITY_LOG_UNABLE_TO GET_ERROR_MESSAGE');
            });
          };

          /* variable declarations */
          scope.toDate = '';
          scope.fromDate = '';
          scope.isFilter = false;
          scope.reverseSort = false;
          scope.isFilterOpen = false;
          scope.orderByField = 'ActionDateTime';
          scope.controllerData = [];
          scope.activityResults = [];
          scope.minDate = '01-01-1900';
          scope.currentDate = new Date();
          scope.sortOptions = {
            fields: ['ActionDateTime'],
            directions: ['Descending']
          };
          scope.pagingOption = {
            currentPage: 1,
            pageOption: []
          };
          scope.noFilterNotification = 'No results found';

          /* get module settings */
          function getModuleSettings() {
            return notificationsService.getNotificationSettings(scope, msApi, q, 'NotificationCenter').then(function (data) {
              scope.notificationSettings = data.results.Retval;
              if (data.results.Retval !== null) {
                scope.pagingOption.pageSize = data.results.Retval.ActivityLogPageSize;
                scope.pagingOption.pageOption.push(data.results.Retval.ActivityLogPageSize);
                scope.setNumberOfPages = scope.pagingOption.pageOption[0];
              } else {
                scope.pagingOption.pageOption.push(10);
                scope.pagingOption.pageSize = 10;
                scope.setNumberOfPages = scope.pagingOption.pageOption[0];
              }
            });
          }

          /* load initial data */
          function init() {
            scope.headingText = translate.instant('ACTIVITY_LOG');

            // get the ProfilePatientId based on the MedseekId
            if (scope.patientId && isNaN(scope.patientId)) {
              msApi.staff.userManagement.patients.get({ uniqueId: scope.patientId }).$promise.then(function (data) {
                scope.patientId = data.Id;
                var patientName = data.FirstName + ' ' + data.LastName;
                scope.headingText = patientName + "'s " + scope.headingText;
                if (scope.showInstructions) {
                  msApi.getDynamicTexts.get({ moduleName: 'usermanagement', key: 'UserManagement.PatientActivityLog' }, null).$promise.then(function (res) {
                    var model = dynamicTextFormatterSvc.createModel(patientName, data.FirstName);
                    scope.instructions = dynamicTextFormatterSvc.format(res.results.Retval, model);
                  });
                }
                initOffsetAndActivityLog();
              });
            } else if (scope.userId) {
              userService.getDetails(scope).then(function () {
                var userName = userService.details.FirstName + ' ' + userService.details.LastName;
                scope.headingText = userName + "'s " + scope.headingText;
                if (scope.showInstructions) {
                  msApi.getDynamicTexts.get({ moduleName: 'usermanagement', key: 'UserManagement.UserActivityLog' }, null).$promise.then(function (res) {
                    var model = dynamicTextFormatterSvc.createModel(null, null, userName, userService.details.FirstName);
                    scope.instructions = dynamicTextFormatterSvc.format(res.results.Retval, model);
                  });
                }
                initOffsetAndActivityLog();
              });
            }

            function initOffsetAndActivityLog() {
              // get the offset value based on the user timezone and load the activity log
              msApi.user.timeZone.get({
                userId: session.get('userId') // the current user
              }).$promise.then(function (response) {
                var offSet = response.results.ActualUtcOffset || response.results.BaseUtcOffset;
                var offSetData = offSet.split(':');
                if (offSet.indexOf('-') > -1) {
                  scope.offSet = (parseInt(offSetData[0] * 60) - parseInt(offSetData[1]));
                } else {
                  scope.offSet = (parseInt(offSetData[0] * 60) + parseInt(offSetData[1]));
                }
                scope.getActivityLog(scope.buildJson(scope.pagingOption.pageSize, scope.pagingOption.currentPage));
              });
            }
          }

          function modifyDataAccessAction(dataAccessAction) {
            if (dataAccessAction.indexOf('Clinical Documents Viewed') > -1) {
              return 'Opened ' + dataAccessAction.replace('Viewed', '');
            } else if (dataAccessAction.indexOf('Downloaded') > -1) {
              return 'Downloaded ' + dataAccessAction.replace('Downloaded', '');
            } else if (dataAccessAction.indexOf('Transmitted') > -1) {
              return 'Transmitted ' + dataAccessAction.replace('Transmitted', '');
            } else if (dataAccessAction.indexOf('My Data') > -1) {
              return 'Downloaded Clinical Data';
            } else if (dataAccessAction.indexOf('Viewed') > -1) {
              return 'Viewed ' + dataAccessAction.replace('Viewed', '');
            } else if ((dataAccessAction.indexOf('Edited') > -1) || (dataAccessAction.indexOf('Modified') > -1)) {
              return 'Modified ' + dataAccessAction.replace('Edited', '').replace('Modified', '');

            } else if (dataAccessAction.indexOf('Added') > -1) {
              return 'Added ' + dataAccessAction.replace('Added', '');
            } else if (dataAccessAction.indexOf('Deleted') > -1) {
              return 'Deleted ' + dataAccessAction.replace('Deleted', '');
            } else if (dataAccessAction.indexOf('Copied') > -1) {
              return 'Copied ' + dataAccessAction.replace('Copied', '');
            } else if (dataAccessAction.indexOf('Request Patient Access') > -1) {
              return 'Submitted a request to connect with patient record';
            } else {
              return dataAccessAction;
            }
          }

          /* map user activity log */
          scope.mapUserActivityLog = function (activityLog) {
            var mappedActivityLogs = [];
            var mappedActivityLog = {};
            for (var activityIndex = 0; activityIndex < activityLog.length; activityIndex++) {
              mappedActivityLog = {
                activityDataAccessAction: modifyDataAccessAction(activityLog[activityIndex].DataAccessAction) +
                  '<br/>',
                activityActionDateTime: activityLog[activityIndex].ActionDateTime,
                activityPatientName: activityLog[activityIndex].PatientName,
                displayIcon: this.bindActivityItems(activityLog[activityIndex].DataAccessAction, 'icon')
              };
              mappedActivityLogs.push(mappedActivityLog);
            }
            return mappedActivityLogs;
          };

          /* map patient activity log */
          scope.mapPatientActivityLog = function (activityLog) {
            var mappedActivityLogs = [];
            var mappedActivityLog = {};
            for (var activityIndex = 0; activityIndex < activityLog.length; activityIndex++) {
              var patientName = activityLog[activityIndex].PatientName;
              var patientFullName;
              if (patientName === 'System') {
                patientName = ['', '', ''];
                patientFullName = '';
              } else {
                patientName = (patientName) ? patientName.split(',') : '';
                patientName = [patientName[0], patientName[1], ','];
                patientFullName = patientName[1] + ' ' + patientName[0];
              }
              mappedActivityLog = {
                activityDataAccessAction: modifyDataAccessAction(activityLog[activityIndex].DataAccessAction) +
                  '<br/>',
                activityActionDateTime: activityLog[activityIndex].ActionDateTime,
                activityDisplayActionDateTime: activityLog[activityIndex].ActionDateTime,
                activityPatientName: patientFullName,
                displayIcon: this.bindActivityItems(activityLog[activityIndex].DataAccessAction, 'icon')
              };
              mappedActivityLogs.push(mappedActivityLog);
            }
            return mappedActivityLogs;
          };

          /* open date filter */
          scope.open = function (event, isOpenFrom, isOpenTo) {
            scope.discardClick(event);
            scope.isDateFilterFrom = isOpenFrom;
            scope.isDateFilterTo = isOpenTo;
          };

          /* show filter */
          scope.showFilter = function () {
            scope.filterFromDate = scope.displayFromDate;
            scope.filterToDate = scope.displayToDate;

            if (!scope.isFilter) {
              scope.clearFilter();
            }
            scope.isSetting = true;
          };

          /* close filter */
          scope.closeFilter = function () {
            $('.fly-out-footer').trigger('click');
          };

          /* clear filter */
          scope.clearFilter = function () {
            scope.filterFromDate = scope.filterToDate = scope.fromDate = scope.toDate = scope.displayToDate = scope.displayFromDate = '';
            scope.isFilterOpen = false;
            scope.filterNotificationsForm.$setPristine();
          };

          /* clear activity filter log */
          scope.clearActivityFilteredLog = function () {
            scope.reverseSort = false;
            scope.orderByField = 'ActionDateTime';
            scope.sortOptions.directions[0] = 'Descending';
            scope.isFilter = false;
            scope.pagingOption.currentPage = 1;
            scope.pagingOption.totalItems = 0;
            scope.clearFilter();
            scope.getActivityLog(scope.buildJson(scope.pagingOption.pageSize, scope.pagingOption.currentPage));
          };

          scope.clearErrorMessage = function () {
            alertService.clear();
            scope.filterFromDate = (scope.displayFromDate) ? scope.displayFromDate : '';
            scope.filterToDate = (scope.displayToDate) ? scope.displayToDate : '';
          };

          /* apply filter */
          scope.applyFilter = function (form, event) {
            alertService.clear();
            form.$setPristine();
            scope.sortOptions.directions[0] = 'Descending';
            scope.fromDate = (scope.filterFromDate !== '' && scope.filterFromDate !== null && scope.filterFromDate) ? (scope.filterFromDate.getMonth() + 1) + '/' + scope.filterFromDate.getDate() + '/' + (scope.filterFromDate.getYear() + 1900) : '';
            scope.toDate = (scope.filterToDate !== '' && scope.filterToDate !== null && scope.filterToDate) ? (scope.filterToDate.getMonth() + 1) + '/' + scope.filterToDate.getDate() + '/' + (scope.filterToDate.getYear() + 1900) : '';

            scope.fromDateFilter = (scope.filterFromDate !== '' && scope.filterFromDate) ? scope.filterFromDate : '';
            scope.toDateFilter = (scope.filterToDate !== '' && scope.filterToDate) ? scope.filterToDate : '';
            if ((scope.fromDateFilter === '' || scope.fromDateFilter === null) && (scope.toDateFilter === null || scope.toDateFilter === '')) {
              scope.errorMessage = translate.instant('PATIENT_MANAGEMENT_ACTIVITY_LOG_VALID_DATE_ERR_MSG');
              alertService.add('danger', scope.errorMessage, 0, '', 'alert_wizard-filter');
              event.preventDefault();
              event.stopPropagation();
              return;
            }
            if (scope.fromDateFilter > scope.toDateFilter && scope.toDate !== '' && scope.fromDateFilter !== '' || (scope.fromDate === '' && scope.toDate === '')) {
              scope.errorMessage = translate.instant('PATIENT_MANAGEMENT_ACTIVITY_LOG_DATE_ERR_MSG');
              alertService.add('danger', scope.errorMessage, 0, '', 'alert_wizard-filter');
              event.preventDefault();
              event.stopPropagation();
              return;
            }

            scope.displayFromDate = scope.fromDateFilter;
            scope.displayToDate = scope.toDateFilter;
            scope.pagingOption.currentPage = 1;
            scope.getActivityLog(scope.buildJson(scope.pagingOption.pageSize, scope.pagingOption.currentPage));
            scope.isFilter = true;
            scope.reverseSort = false;
            scope.orderByField = 'ActionDateTime';
            $('.fly-out-footer').trigger('click');
          };

          /* construct activity log request object */
          scope.buildJson = function (pageSize, currentPage) {
            return {
              'patientId': scope.patientId,
              'userId': scope.userId,
              'pageSize': pageSize,
              'pageIndex': currentPage,
              'sortField': scope.sortOptions.fields[0],
              'sortDirection': scope.sortOptions.directions[0],
              'StartDateTime': scope.fromDate,
              'EndDateTime': scope.toDate,
              'offSet': scope.offSet
            };
          };

          /* sort activity log */
          scope.sortActivityLog = function (type) {
            var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
            if (scope.pagingOption.currentPage > total) {
              return;
            }

            scope.sortOrder = scope.sortOption.reverse ? 'Ascending' : 'Descending';
            scope.reverseSort = scope.sortOrder === 'Ascending' ? true : false;
            scope.sortOptions.directions[0] = scope.sortOrder;
            scope.sortOptions.fields[0] = scope.orderByField = scope.sortOption.sortBy;
            scope.getActivityLog({
              'patientId': scope.patientId,
              'userId': scope.userId,
              'pageSize': scope.pagingOption.pageSize,
              'pageIndex': scope.pagingOption.currentPage,
              'sortField': scope.sortOptions.fields[0],
              'sortDirection': scope.sortOptions.directions[0],
              'StartDateTime': scope.fromDate,
              'EndDateTime': scope.toDate,
              'offSet': scope.offSet
            });
          };

          /* discard click */
          scope.discardClick = function (event) {
            event.preventDefault();
            event.stopPropagation();
          };

          function addWatches() {
            /* watch function for pagination - current page */
            scope.$watch('pagingOption.currentPage', function (newVal, oldVal) {
              alertService.clear();
              var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
              if (oldVal !== newVal && newVal !== '' && parseInt(newVal) > 0 && total >= newVal) {
                scope.getActivityLog(scope.buildJson(scope.pagingOption.pageSize, scope.pagingOption.currentPage));
              } else if (isNaN(newVal) || parseInt(newVal) >= total || parseInt(newVal) <= 0 || isNaN(parseInt(newVal))) {
                scope.errorMessage = 'Please enter the valid page number.';
              }
            });
            /* watch function for pagination - page size */
            scope.$watch('pagingOption.pageSize', function (oldVal, newVal) {
              if (oldVal !== newVal) {
                scope.pagingOption.currentPage = 1;
                var json = scope.buildJson(scope.pagingOption.pageSize, scope.pagingOption.currentPage);
                scope.getActivityLog(json);
              }
            });

            scope.$watch('sortOption.sortBy', function (newVal, oldVal) {
              if (oldVal !== newVal) {
                scope.sortActivityLog(scope.sortOption.sortBy);
              }
            });

            scope.$watch('sortOption.reverse', function (newVal, oldVal) {
              if (oldVal !== newVal) {
                scope.sortActivityLog(scope.sortOption.sortBy);
              }
            });
          }

          /* bind activity items */
          scope.bindActivityItems = function (activityType, property) {
            var template = '';

            switch (activityType) {
              case 'MHR Accessed':
                if (property === 'icon') {
                  template = 'icon-clinical-doc';
                }
                break;
              case 'Synchronized Profile with HIS Data':
                if (property === 'icon') {
                  template = 'icon-name';
                }
                break;
              case 'Profile':
                if (property === 'icon') {
                  template = 'icon-name';
                }
                break;
              case 'NewSecureMessage':
                if (property === 'icon') {
                  template = 'icon-message';
                } else {
                  template = 'task-center';
                }
                break;
              case 'AllergyChanges':
                if (property === 'icon') {
                  template = 'icon-cholesterol';
                }
                break;
              case 'BloodGlucoseChanges':
                if (property === 'icon') {
                  template = 'icon-blood';
                } else {
                  template = 'my-health-information/health-tracker/blood-glucose';
                }
                break;
              case 'BloodPressureChanges':
                if (property === 'icon') {
                  template = 'icon-blood-pressure';
                } else {
                  template = 'my-health-information/health-tracker/blood-pressure';
                }
                break;
              case 'CholesterolChanges':
                if (property === 'icon') {
                  template = 'icon-cholesterol';
                } else {
                  template = 'my-health-information/health-tracker/cholesterol';
                }
                break;
              case 'FamilyHistoryChanges':
                if (property === 'icon') {
                  template = 'icon-cholesterol';
                } else {
                  template = 'my-health-information/medical-history';
                }
                break;
              case 'ImmunizationChanges':
                if (property === 'icon') {
                  template = 'icon-immunizations';
                } else {
                  template = 'my-health-information/medical-history';
                }
                break;
              case 'MedicationChanges':
                if (property === 'icon') {
                  template = 'icon-cholesterol';
                } else {
                  template = 'my-health-information/treatment?type=medications';
                }
                break;
              case 'ProblemChanges':
                if (property === 'icon') {
                  template = 'icon-cholesterol';
                } else {
                  template = 'my-health-information/treatment?type=problems';
                }
                break;
              case 'GrowthChartChanges':
                if (property === 'icon') {
                  template = 'icon-cholesterol';
                } else {
                  template = 'my-health-information/health-tracker/weight-bmi';
                }
                break;
              case 'ProcedureChanges':
                if (property === 'icon') {
                  template = 'icon-cholesterol';
                } else {
                  template = 'my-health-information/medical-history';
                }
                break;
              case 'SocialHistoryChanges':
                if (property === 'icon') {
                  template = 'icon-social-history';
                } else {
                  template = 'my-health-information/medical-history';
                }
                break;
              case 'TestResultChanges':
                if (property === 'icon') {
                  template = 'icon-test-results';
                } else {
                  template = 'my-health-information/test-results?type=Test%20Results';
                }
                break;
              case 'WeightChanges':
                if (property === 'icon') {
                  template = 'icon-weight';
                } else {
                  template = 'my-health-information/health-tracker/weight-bmi';
                }
                break;

                /*patient management*/
              case 'BusinessPhoneNumber':
                if (property === 'icon') {
                  template = 'icon-phone';
                } else {
                  template = '';
                }
                break;
              case 'EmergencyContact':
                if (property === 'icon') {
                  template = 'icon-emergency-contacts';
                } else {
                  template = '';
                }
                break;
              case 'Guarantor':
                if (property === 'icon') {
                  template = 'icon_Guarantors';
                } else {
                  template = '';
                }
                break;
              case 'HomePhoneNumber':
                if (property === 'icon') {
                  template = 'icon_phone';
                } else {
                  template = '';
                }
                break;
              case 'Location':
                if (property === 'icon') {
                  template = 'icon-location';
                } else {
                  template = '';
                }
                break;
              case 'PatientAddress':
                if (property === 'icon') {
                  template = 'icon-address-home';
                } else {
                  template = '';
                }
                break;
              case 'PatientDateOfBirth':
                if (property === 'icon') {
                  template = 'icon-gender';
                } else {
                  template = '';
                }
                break;
              case 'PatientEthnicGroup':
                if (property === 'icon') {
                  template = 'icon-weight';
                } else {
                  template = '';
                }
                break;
              case 'PatientGender':
                if (property === 'icon') {
                  template = 'icon-gender';
                } else {
                  template = '';
                }
                break;
              case 'PatientMaritalStatus':
                if (property === 'icon') {
                  template = 'icon-marriage';
                } else {
                  template = '';
                }
                break;
              case 'PatientName':
                if (property === 'icon') {
                  template = 'icon-name';
                } else {
                  template = '';
                }
                break;
              case 'PatientRace':
                if (property === 'icon') {
                  template = 'icon-race';
                } else {
                  template = '';
                }
                break;
              case 'PatientLanguage':
                if (property === 'icon') {
                  template = 'icon-language';
                } else {
                  template = '';
                }
                break;
              case 'PatientReligion':
                if (property === 'icon') {
                  template = 'icon-language';
                } else {
                  template = '';
                }
                break;
              case 'PatientSsn':
                if (property === 'icon') {
                  template = 'icon-ssn';
                } else {
                  template = '';
                }
                break;
              case 'Pharmacy':
                if (property === 'icon') {
                  template = 'icon-pharmacy';
                } else {
                  template = '';
                }
                break;
              case 'Physician':
                if (property === 'icon') {
                  template = 'icon-physician';
                } else {
                  template = '';
                }
                break;

                // request center type
              case 'Notification.RequestCompleted':
                if (property === 'icon') {
                  template = 'icon-message';
                } else {
                  template = '';
                }
                break;
              case 'Notification.RequestApproved':
                if (property === 'icon') {
                  template = 'icon-message';
                } else {
                  template = '';
                }
                break;
              case 'Notification.RequestDenied':
                if (property === 'icon') {
                  template = 'icon-message';
                } else {
                  template = '';
                }
                break;
              case 'Notification.NewDiscussionAdded':
                if (property === 'icon') {
                  template = 'icon_Manage_Discussions';
                } else {
                  template = '';
                }
                break;
              case 'Notification.NewCommentOnDiscussion':
                if (property === 'icon') {
                  template = 'icon_Manage_Discussions';
                } else {
                  template = 'task-center';
                }
                break;
              default:
                if (property === 'icon') {
                  template = 'icon-invalid';
                } else {
                  template = '';
                }
                break;
            }

            return template;
          };

          getModuleSettings()
            .then(init)
            .then(addWatches);
        }
      };
    }
  ]);
})(window.app);
