(function (app) {
  'use strict';

  /* directive for get event when pres enter key in texbox */
  app.directive('ngEnter', function () {
    return function (scope, element, attrs) {
      element.bind('keydown keypress', function (event) {
        if (event.which === 13) {
          scope.$apply(function () {
            var handler = attrs.ngEnter || attrs.ngClick;
            scope.$eval(handler);
          });
          event.preventDefault();
        }
      });
    };
  });

}(window.app));
