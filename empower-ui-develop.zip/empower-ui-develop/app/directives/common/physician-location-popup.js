(function (app) {
  'use strict';

  app.directive('msPhysicianLocationPopup', [function () {
    return {
      restrict: 'E',
      scope: true,
      templateUrl: app.root + 'templates/physician-location-popup.html',
      link: function (scope) {
        /* hide popup and make selected physician array null*/
        scope.setLocation = function () {
          scope.controller.physicianLocationData = [];
          scope.controller.physicianLocationColumns = [];
          scope.showLocationPopUp = false;

        };
      }
    };
  }]);
}(window.app));
