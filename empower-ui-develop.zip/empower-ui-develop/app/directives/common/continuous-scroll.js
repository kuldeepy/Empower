(function (app) {
  'use strict';
  app.directive('continuousScroll', [function () {
    return {
      restrict: 'A',
      link: function (scope, element, attr) {
        var container = element[0];

        element.bind('scroll', function () {
          if (container.scrollTop + container.offsetHeight >= container.scrollHeight) {
            scope.$apply(attr.continuousScroll);
          }
        });
      }
    };
  }]);
})(window.app);
