(function (app, angular) {
  'use strict';
  app.directive('permissionsEditor', ['$timeout','$translate', function (timeout,translate) {
    return {
      template: '' +
        '   <div class="container-fluid edit-permissions-directive">' +
        '       <div class="row">' +
        '       <div class="col-xs-12 container">' +
        '         <div class="row">' +
        '           <div class="col-xs-4"></div>' +
        '           <div class="col-xs-4" ng-show="readonly"></div>' +
        '           <div class="col-xs-2">' +
        '             <span ng-click="expandAll()" class="cursor-pointer link-hover"><span class="toggler glyphicon-chevron-down glyphicon link"></span> <label class="cursor-pointer link-hover">' + translate.instant('Expand_All') + '</label></span>' +
        '           </div>' +
        '           <div class="col-xs-2">' +
        '             <span ng-click="closeAll()" class="cursor-pointer link-hover"><span class="toggler glyphicon-chevron-right glyphicon link"></span> <label class="cursor-pointer link-hover">' + translate.instant('Close_All') + '</label></span>' +
        '           </div>' +
        '           <div class="col-xs-2" ng-show="!readonly" >' +
        '             <input type="checkbox" iui-disable-permission=\'["user-management.community.access-level.customize"]\' id="permissions-editor-check-all" ng-model="checkall" ng-click="checkAll()" class="custom-checkbox" ><label for="permissions-editor-check-all">' + translate.instant('Check_All') + '</label>' +
        '           </div>' +
        '           <div class="col-xs-2 trim-right"  ng-show="!readonly" >' +
        '             <input type="checkbox" iui-disable-permission=\'["user-management.community.access-level.customize"]\' id="permissions-editor-uncheck-all" ng-model="uncheckall" ng-click="uncheckAll()" class="custom-checkbox" ><label for="permissions-editor-uncheck-all">' + translate.instant('UNCHECK_ALL') + '</label>' +
        '           </div>' +
        '         </div> ' +
        '       </div> ' +
        '       <div class="row">' +
        '         <div class="col-xs-12 container ">' +
        '           <permissions-tree-node model="model" show="show" permissions="permissions" ng-if="model" readonly="readonly" enabled="true" branch-enabled="true"></permissions-tree-node>' +
        '         </div>' +
        '       </div> ' +
        '   </div>',
      replace: true,
      restrict: 'E',
      scope: {
        model: '=ngModel',
        show: '=',
        permissions: '=',
        readonly: '='
      },
      link: function (scope) {
        scope.checkall = true;
        scope.uncheckall = false;
        scope.checkAll = function () {
          scope.$broadcast('check.all.nodes');
          timeout(function () {scope.checkall = true;});
        };
        scope.uncheckAll = function () {
          scope.permissions = [];
          scope.$broadcast('uncheck.all.nodes');
          timeout(function () {scope.uncheckall = false;});
        };
        scope.expandAll = function () {
          scope.$broadcast('expand.all.nodes');
        };
        scope.closeAll = function () {
          scope.$broadcast('close.all.nodes');
        };
      }
    };
  }])
    .directive('permissionsTreeNode', [function () {
      return {
        template: '<ul ng-show="show" class="permissions-tree-node list-unstyled" ><li ng-repeat="choice in model.accessTypes | bindPermissionsChoice : model.components"><permissions-choice  readonly="readonly" enabled="enabled" branch-enabled="branchEnabled" current="choice" permissions="permissions"></permissions-choice></li></ul>',
        replace: true,
        restrict: 'E',
        scope: {
          model: '=model',
          show: '=',
          permissions: '=',
          branchEnabled: '=',
          enabled: '=',
          readonly: '='
        }
      };
    }])
    .directive('permissionsChoice', ['$compile', '$timeout', '_', '$log', 'userPermissionsSvc', function ($compile, timeout, _, log, userPermissionsSvc) {
      return {
        restrict: 'E',
        replace: true,
        template: '<div class="container" >' +
          '    <div class="row">' +
          '      <div class="col-xs-1 permission-toggle" >' +
          '        <permissions-tree-closer open="expanded" show="show"></permissions-tree-closer>' +
          '      </div>' +
          '      <div class="col-xs-6" >' +
          '         <div>' +
          '           <input class="custom-checkbox" type="checkbox" id="choice-input-{{choice.permission}}" ng-model="permission" ng-change="permissionChange()" >' +
          '           <label for="choice-input-{{choice.permission}}">{{choice.label}}</label>' +
          '         </div>' +
          '      </div>' +
          '    </div>' +
          '  </div>',
        scope: {
          choice: '=current',
          permissions: '=',
          branchEnabled: '=',
          enabled: '=',
          readonly: '='
        },
        link: function (scope, elm) {
          if (!scope.enabled && !scope.readonly) {
            _.remove(scope.permissions, function (perm) {
              return scope.choice.permission === perm;
            });
          }
          log.debug('branch name', scope.choice.permission, 'branch enabled', scope.enabled);
          log.debug('branch branchEnabled', scope.branchEnabled);
          log.debug();
          scope.expanded = false;
          scope.children = true;
          scope.permission = scope.permissions && scope.permissions.indexOf(scope.choice.permission) > -1;
          scope.show = scope.choice.components !== undefined;
          if (scope.choice.components) {
            var childChoice = $compile('<permissions-tree-node show="expanded" model="choice.components" readonly="readonly" enabled="permission" branch-enabled="permission" permissions="permissions"></permissions-tree-node>')(scope);
            elm.append(childChoice);
          }
          if (scope.readonly || !userPermissionsSvc.userHasPermission('user-management.community.access-level.customize')) {
            elm.find('.custom-checkbox').attr('disabled', 'disabled');
          }
          scope.$on('permissions-choice-changed', function (evt, val) {
            if (!val) {
              scope.permission = false;
            }
          });
          scope.permissionChange = function () {
            scope.$emit('permissions-editor-dirty');
            scope.$broadcast('permissions-choice-changed', scope.permission);
          };
          var enableBoxes = function (newVal, oldVal) {
            if (newVal === oldVal) {
              return;
            }
            if (newVal) {
              if (scope.permissions && scope.permissions.indexOf(scope.choice.permission) === -1) {
                scope.permissions.push(scope.choice.permission);
              }
              scope.childrenEnabled = true;
            } else {
              _.remove(scope.permissions, function (perm) {
                return scope.choice.permission === perm;
              });
              scope.childrenEnabled = false;
            }
          };
          scope.$watch('permissions', function () {
            scope.permission = scope.permissions && scope.permissions.indexOf(scope.choice.permission) > -1;
          });
          scope.$watch('permission', enableBoxes);
          scope.$on('check.all.nodes', function () {
            scope.enabled = scope.permission = true;
          });
          scope.$on('uncheck.all.nodes', function () {
            scope.enabled = scope.permission = false;
          });
          scope.$on('disable.all.permissions', function () {
            elm.find('ul input').attr('disabled', 'disabled');
          });
        }
      };
    }])
    .directive('permissionsTreeCloser', function () {
      return {
        restrict: 'E',
        scope: {
          open: '=',
          show: '='
        },
        replace: false,
        template: '<a class="glyphicon link" ng-show="show" ng-class="{\'glyphicon-chevron-right\': !open, \'glyphicon-chevron-down\': open}" ng-click="open = !open"></a>',
        link: function (scope) {
          scope.$on('expand.all.nodes', function () {
            scope.open = true;
          });
          scope.$on('close.all.nodes', function () {
            scope.open = false;
          });
        }
      };
    })
    .filter('bindPermissionsChoice', ['_', function (_) {
      return function (accessTypes, components) {
        angular.forEach(accessTypes, function (type) {
          type.components = _.find(components, { id: type.componentKey });
        });
        return accessTypes;
      };
    }]);
})(window.app, window.angular);
