(function (app) {
  'use strict';

  app.directive('msDialog', function ($compile) {
    var uniqueId = 1;
    return {
      restrict: 'E',

      transclude: true,

      link: function (scope, element, attrs) {
        var myId;
        uniqueId = uniqueId + 1;
        scope.myId = 'ihi_dialog' + uniqueId;
        attrs.$observe('template', function (value) {
          element.html(attrs.template);
          $compile(element.contents())(scope);
          element.parent().append(element.contents());

        });

      },

      controller: function ($scope, dialogService) {
        $scope.close = function () {
          if ($scope.closeDirectionDialog) {
            $scope.closeDirectionDialog();
          }
          else if ($scope.closePopups) {
            $scope.closePopups();
          } else {
            dialogService.close();
          }
        };

        $scope.closeDialogBox = function (dialog) {
          //dialog and no parent.closeDialog function then go inside if  statement
          if (dialog && !$scope.$parent.closeDialog) {
            dialogService.close(dialog);
          }
          else if ($scope.$parent.closeDialog) {
            $scope.$parent.closeDialog()
          }
          else if (dialog) {
            dialogService.close(dialog);
          }
          else {
            dialogService.close();
          }
        }
      }

    };
  });

}(window.app));
