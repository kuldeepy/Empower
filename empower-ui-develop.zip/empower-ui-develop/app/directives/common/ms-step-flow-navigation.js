(function (app) {
  'use strict';

  var currentScope = function (scope) {
    return scope['tabGroup:' + scope.index];
  };

  var changeControl = function (scope) {
    scope.side = scope.steps[scope.index];
    var sc = currentScope(scope);
    if (!sc) {
      return;
    }
    sc.onFocus(scope.groupControls[scope.index], scope.stepIndex);
  };

  var FlowControl = function (idx, scope, tim) {
    this.idx = idx;
    var setButtonState = function (key, state) {
      var buttonState = scope.buttonStates[idx] || {};
      buttonState[key] = state;
      scope.buttonStates[idx] = buttonState;
    };
    this.showCancel = function (show) {
      setButtonState('showCancel', show);
    };
    this.showNext = function (show) {
      setButtonState('showNext', show);
    };
    this.showPrevious = function (show) {
      setButtonState('showPrevious', show);
    };
    this.enableCancel = function (show) {
      setButtonState('disableCancel', !show);
    };
    this.enableNext = function (show) {
      setButtonState('disableNext', !show);
    };
    this.enablePrevious = function (show) {
      setButtonState('disablePrevious', !show);
    };
    this.next = function () {
      scope.stepIndex += 1;
      scope['tabGroup:' + scope.index].stepIndex = scope.stepIndex;
      scope.$emit('stepFlowStepIndexChanged', scope.stepIndex);
    };
    this.previous = function () {
      scope.stepIndex -= 1;
      scope['tabGroup:' + scope.index].stepIndex = scope.stepIndex;
      scope.$emit('stepFlowStepIndexChanged', scope.stepIndex);
    };
    this.tabComplete = function () {
      scope.index++;
      scope.stepIndex = 0;
      scope.$emit('stepFlowStepIndexChanged', scope.stepIndex);
      changeControl(scope);
    };
    this.previousTab = function () {
      scope.index--;
      scope.side = scope.steps[scope.index];
      scope.stepIndex = scope.side.length - 1;
      scope.$emit('stepFlowStepIndexChanged', scope.stepIndex);
      changeControl(scope);
    };
    this.setIndex = function (idx, stepIdx) {
      scope.index = idx || 0;
      scope.stepIndex = stepIdx || 0;
      changeControl(scope);
    };
    this.wizardComplete = function () {
      scope.complete = true;
    };
    this.changeSteps = function (index, stepsData) {
      scope.steps[index] = stepsData;
    };
    this.changeFlowControl = function () {
      changeControl(scope);
    };
    this.addSteps = function (steps) {
      scope.steps = steps;
      scope.side = scope.steps;
    };
  };

  /* directive for topMenuNavigation */
  app.directive('msStepFlowNavigation', ['$timeout', '$window', '$translate', function (tim, $window,translate) {
    return {
      restrict: 'E',
      transclude: true,
      templateUrl: app.root + 'templates/ms-step-flow-navigation.html',
      scope: {
        index: '=',
        stepIndex: '=',
        nextButtonText: '='
      },
      controller: ['$scope', function (scope) {
        var scp = {
          side: [],
          top: [],
          keys: [],
          showCancel: true,
          showPrevious: true,
          showNext: true,
          nextEnabled: true,
          previousEnabled: true,
          cancelEnabled: true,
          onCancel: function () {
            scope.$emit('stepFlowOnCancel', scope.keys[scope.index]);
          },
          onPrevious: function () {
            currentScope(scope).onPrevious(scope.groupControls[scope.index]);
          },
          onNext: function () {
            currentScope(scope).onNext(scope.groupControls[scope.index]);
            $window.scrollTo(0, 0);
          },
          routes: [],
          steps: [],
          buttonStates: [],
          groupControls: [],
          complete: false
        };
        angular.extend(scope, scp);

        var control = new FlowControl(undefined, scope, tim);

        /*for use of topMenuNavigation */
        this.scope = scope;

        scope.$watch('index', function (newVal, oldVal) {
          if (newVal !== oldVal) {
            changeControl(scope);
          }
          scope.$emit('stepFlowIndexChange', newVal);
        });
        this.addStep = function (step) {
          var index = scope.top.length;
          scope['tabGroup:' + index] = step;
          scope.groupControls.push(new FlowControl(index, scope, tim));
          scope.$emit('msStepFlowControlsAdded', control);
          _.forEach(step.steps, function (step) {
            step.menu = translate.instant(step.menu);
          })
          scope.steps.push(step.steps);
          scope[step.route.name] = step;
          step.idx = index;
          scope.keys[index] = step.route.name;
          scope.top.push({ index: index, step: step.title, name: index + 1 });
          scope.routes.push(step.route);
          if (scope.top.length === 1) {
            scope.side = step.steps;
          }
        };

      }]
    };
  }]);
})(window.app);
