(function (app) {
  'use strict';

  app.directive('msAddEditMedicalPopup', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/add-edit-medical-popup.html'
    };
  }]);
}(window.app));
