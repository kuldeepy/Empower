(function (app) {
  'use strict';

  app.directive('iuiRouteAuth', ['$rootScope', '$location', 'userPermissionsSvc', '$interpolate', function (rootScope, location, userPermissionsSvc, interpolate) {
    return {
      restrict: 'A',
      link: function (scope, element, attrs) {
        rootScope.$watch('app.routing', function () {
          if (scope.app.routing.data.permissions) {
            var interpolatedPerms = [];

            _.forEach(scope.app.routing.data.permissions, function (permission) {
              interpolatedPerms.push(interpolate(permission)(scope));
            });

            if (!userPermissionsSvc.userHasPermission(interpolatedPerms)) {
              location.path('/');
            }
          }
        });
      }
    };
  }]);
}(window.app));
