(function (app) {
  'use strict';
  app.directive('iuiRequiredPermission', ['$log', 'userPermissionsSvc', 'session', function (log, userPermissionsSvc, session) {
    return {
      scope: false,
      restrict: 'A',
      link: function (scope, element, attrs) {
        if (!attrs.iuiRequiredPermission) {
          return;
        }
        element.attr('style', 'display: none !important');
        var array = JSON.parse(attrs.iuiRequiredPermission);
        if (userPermissionsSvc.userHasPermission(array)) {
          element.attr('style', 'display: block');
        }
        attrs.$observe('iuiRequiredPermission', function (value) {
          var permission = JSON.parse(value);
          if (session.get('currentPermissionSet') === null || session.get('currentPermissionSet') === undefined) {
            userPermissionsSvc.updatePermissions().then(function (data) {
              if (userPermissionsSvc.userHasPermission(permission)) {
                element.attr('style', 'display: block');
              }
            });
          } else if (userPermissionsSvc.userHasPermission(permission)) {
            element.attr('style', 'display: block');
          } else {
            element.attr('style', 'display: none !important');
          }
        });
      }
    };
  }]);

  app.directive('iuiDisablePermission', ['$log', 'userPermissionsSvc', function (log, userPermissionsSvc) {
    return {
      scope: false,
      restrict: 'A',
      link: function (scope, element, attrs) {
        if (!attrs.iuiDisablePermission) {
          return;
        }
        element.prop('disabled', true);
        var array = JSON.parse(attrs.iuiDisablePermission);
        if (userPermissionsSvc.userHasPermission(array)) {
          element.prop('disabled', false);
        }
        attrs.$observe('iuiDisablePermission', function (value) {
          var permission = JSON.parse(value);
          if (userPermissionsSvc.userHasPermission(permission)) {
            element.prop('disabled', false);
          }
        });
      }
    };
  }]);
}(window.app));
