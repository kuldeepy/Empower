(function (app) {
  'use strict';

  /* directive for blue button popup */
  app.directive('msBlueButtonPopup', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/blue-button-popup.html'
    };
  }]);

}(window.app));
