(function (app) {
  'use strict';

  // this directive should allow a user to switch the language
  app.directive('iuiCultureSwitcher', ['cultureService', '$window', function (cultureService, window) {
    return {
      restrict: 'E',
      scope: {
        reload: '@'
      },
      templateUrl: app.root + 'templates/basic/iui-culture-switcher.html',
      link: function (scope) {
        scope.cultureSwitcher = {
          supportedCultures: cultureService.getSupportedCultures(),
          currentCulture: cultureService.getCurrentCulture(),

          // Used by the Angular orderBy filter to start with the active culture first
          orderByCurrentCulture: function(culture) {
           return !(culture.key === scope.cultureSwitcher.currentCulture.key);
          },

          // Method to switch the culture
          switchCulture: function (selectedCulture) {
            if (scope.cultureSwitcher.currentCulture.key !== selectedCulture.key) {
              scope.cultureSwitcher.currentCulture = selectedCulture;
              cultureService.setCulture(selectedCulture);
            }
          }
        };
      }
    };
  }]);
}(window.app));
