(function (app) {
  'use strict';
  app.directive('iuiBasicModal', function () {
    return {
      restrict: 'E',
      scope: {
        modalTitle: '@',
        primaryBtnLabel: '@',
        secondaryBtnLabel: '@',
        dismiss: '&',
        close: '&'
      },
      transclude: true,
      templateUrl: app.root + 'templates/basic/iui-basic-modal.html'
    };
  });
}(window.app));
