(function (app) {
  'use strict';

  app.directive('iuiAriaTabControl', ['$window', 'messagingService', 'messageCenterMailBoxService', function (window, messageSvc, mailboxSvc) {
    return {
      restrict: 'A',
      link: function (scope, element) {
        var tabList = [],
          tabListCount = 0,
          currentItem = 0,
          tab;
        element.on('focus', function (e) {
          tabList = element.find(">[role^='tab']");
          tabListCount = tabList.length;
          tab = tabList[currentItem];
          tab.focus();
          tab.click();
        });
        element.keyup(function (e) {
          switch (e.which) {
            case 40 :
              currentItem = currentItem + 1;
              if (currentItem === tabListCount) {
                currentItem = 0;
              }
              tabList[currentItem].focus();
              $(tabList[currentItem]).click();

              if (tab === currentItem) {
                scope.selected = true;
              } else {
                scope.selected = false;
              }
              break;

            case 38 :
              currentItem = currentItem - 1;
              if (currentItem === -1) {
                currentItem = tabListCount - 1;
              }
              tabList[currentItem].focus();
              $(tabList[currentItem]).click();

              if (tab === currentItem) {
                scope.selected = true;
              } else {
                scope.selected = false;
              }
              break;
          }
        });
      }
    };
  }]);
}(window.app));
