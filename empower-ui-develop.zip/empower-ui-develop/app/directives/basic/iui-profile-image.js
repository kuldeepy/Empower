(function (app) {
  'use strict';

  app.directive('iuiProfileImage', [function (genderFilter) {
    return {
      restrict: 'E',
      scope: {
        iuiImage: '=',
        iuiGender: '=',
        iuiIsThumb: '=',
        iuiIsSquare: '='
      },
      templateUrl: '/templates/basic/iui-profile-image.html',
      controller: function ($scope, genderFilter) {
        $scope.$watch('iuiGender', function (newVal) {
          $scope.profileGender = genderFilter(newVal);
        });
      }
    };
  }]);
}(window.app));
