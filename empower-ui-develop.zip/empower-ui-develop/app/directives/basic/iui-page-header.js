(function (app) {
  'use strict';

  app.directive('iuiPageHeader', ['$location', '$window', function (location, window) {
    return {
      restrict: 'E',
      scope: {
        headingText: '=',
        href: '@',
        backText: '@',
        breadcrumb: '=',
        goBack: '=',
        backClick: '&',
        leftMenuNavs: '=',
        moduleId: '@',
        moduleInstanceId: '@'
      },
      templateUrl: '/templates/basic/iui-page-heading.html',
      link: function (scope, element, attrs) {
        element.on('click', 'a', function (e) {
          if (scope.goBack /*treat like a back button*/) {
            window.history.back();
            e.preventDefault();
            return false;
          }
        });
        /*Changes the page header according to the menu names*/
        scope.$watch('moduleId', function () {
          scope.headingText = _.result(_.find(scope.leftMenuNavs.navigation, function (item) {
            return item.ModuleId === scope.moduleId;
          }), 'Name');
        });

        scope.$watch('moduleInstanceId', function (newValue) {
          if (!newValue)
            return;
          scope.headingText = _.result(_.find(scope.leftMenuNavs.navigation, function (item) {
            return item.ModuleId === scope.moduleId && item.ModuleInstanceId == newValue;
          }), 'Name');
        });

        scope.backLinkClicked = function () {
          if (typeof scope.backClick === 'function') {
            scope.backClick();
          }
        };
      }
    };
  }]);
}(window.app));
