(function (app) {
  'use strict';

  app.directive('iuiHealthTrackerStat', [function (genderFilter) {
    return {
      restrict: 'E',
      scope: {
        iuiMeasurement: '@',
        iuiReading: '@',
        iuiDate: '@',
        iuiIsDiff: '=',
        iuiIsCurrent: '='
      },
      templateUrl: '/templates/basic/iui-health-tracker-stat.html'
    };
  }]);
}(window.app));
