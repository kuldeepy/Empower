(function (app) {
  'use strict';

  // directive that sets a min-height on the page-wrapper based on the window height

  app.directive('iuiEqualizer', ['$window', function ($window) {
    return {
      restrict: 'A',
      link: function (scope, element) {
        var w = angular.element($window);
        var header = element.find('#masterLayout_header');
        var footer = element.find('#masterLayout_contentinfo_footer');
        var pageWrapper = element.find('.page-wrapper');
        var theWindow = {};
        var pageSizes = {
          pageWrapperMargin: 20 // page-wrapper top & bottom margin
        };

        scope.monitorWindowHeight = function () {
          theWindow = {
            width: w.width(),
            height: w.height()
          };
          return theWindow;
        };

        var resizePageWrapper = function () {
          pageSizes.header = header.outerHeight();
          pageSizes.footer = footer.outerHeight();

          var newHeight = pageSizes.windowHeight - pageSizes.header - pageSizes.footer - pageSizes.pageWrapperMargin;
          pageWrapper.css('min-height', newHeight);
        };

        // / Single page app problems...you gotta continually monitor what happens in pages
        scope.$watch(scope.monitorWindowHeight, function (newWindowSize) {
          pageSizes.windowHeight = newWindowSize.height;
          resizePageWrapper();
        }, true);

        // / Watches when the page resizes;
        w.on('resize', function (newWindowSize) {
          pageSizes.windowHeight = w.height();
          resizePageWrapper();
        });
      }
    };
  }]);
}(window.app));
