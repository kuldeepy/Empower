(function (app) {
  'use strict';

  // This directive, iui-input-field-highlight, looks for the focus state
  // on various input types, and applies a bg color change to keep the
  // user's attention on the section. It also separates each section without
  // the use of borders.

  app.directive('iuiInputFieldHighlight', function () {
    return {
      restrict: 'A',
      scope: {},
      link: function (scope, element) {
        var sectionWrapper = element;
        var inputSearchTypes = 'input, textarea, select, div, button, a, table';
        scope.$watch(function () {
          scope.allInputsSize = sectionWrapper.find(inputSearchTypes).size();
        });
        scope.$watch('allInputsSize', function (newVal) {
          var allInputs = sectionWrapper.find(inputSearchTypes);
          allInputs.on('focus', function () {
            sectionWrapper.addClass('is-highlighted');
          });
          allInputs.on('blur', function () {
            sectionWrapper.removeClass('is-highlighted');
          });
        });
      }
    };
  });
}(window.app));
