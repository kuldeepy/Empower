(function (app) {
  'use strict';

  app.directive('iuiConfirmPassword', [function () {
    return {
      restrict: 'E',
      scope: {
        iuiPasswordPattern: '=',
        iuiPasswordOne: '=',
        iuiPasswordTwo: '=',
        iuiPasswordMinlength: '='
      },
      templateUrl: '/templates/basic/iui-confirm-password.html'
    };
  }]);
}(window.app));
