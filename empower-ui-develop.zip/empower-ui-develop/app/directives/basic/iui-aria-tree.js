(function (app) {
  'use strict';

  app.directive('iuiAriaTree', ['$window', '_', function (window, _) {
    return {
      restrict: 'A',
      link: function (scope, element) {
        var treeitems = [],
          treeitemCount = 0,
          currentItem = 0,
          treeitem,
          hasSubtree = false,
          subtree = {},
          done = false,
          parent,
          treeitemType;
        element.on('focus', function (e) {
          treeitems = element.find("[role='group'][aria-expanded='true']>[role^='treeitem']");
          treeitemCount = treeitems.length;

          if (treeitems.length) {
            treeitems[currentItem].focus();
          }
        });

        element.on('keyup', function (e) {
          var jqItem, temptreeitems, subtreeitems, items;
          switch (e.which) {
            case 9 :
              done = true;
              break;
            case 35 :
              currentItem = treeitem.length;
              treeitems[currentItem].focus();
              break;
            case 36 :
              currentItem = 0;
              treeitems[currentItem].focus();
              break;
            case 38: // up
              if (currentItem > 0) {
                currentItem = currentItem - 1;

              }
              treeitems[currentItem].focus();
              break;
            case 40 : // down
              if (currentItem < treeitemCount - 1) {
                currentItem = currentItem + 1;
              }
              treeitems[currentItem].focus();
              break;
            case 13 :
            case 32 :
              break;
            case 39 :
              treeitem = treeitems[currentItem];
              jqItem = $(treeitem);
              hasSubtree = (jqItem.attr('aria-haspopup') === 'true');
              if (hasSubtree) {
                subtree = jqItem.find(">[role='group']");
                subtree.attr({'aria-hidden': 'false', 'aria-expanded': 'true'}).find('a').first().trigger('click');
                subtreeitems = subtree.find(">[role^='treeitem']");

                temptreeitems = $('').add(treeitems.slice(0, currentItem)).add(subtreeitems).add(treeitems.slice(currentItem));
                treeitems = temptreeitems;

                currentItem = currentItem + 1;
                treeitems[currentItem].focus();
              } else {
                treeitemType = jqItem.attr('role');
                switch (treeitemType) {
                  case 'treeitem':
                    jqItem.find('a').first().click();
                    break;
                }

              }
              break;
            case 37 :
              treeitem = treeitems[currentItem];
              jqItem = $(treeitem);
              parent = jqItem.parent("[role='group']");
              if (parent.attr('aria-expanded') === 'true') {
                parent.attr({'aria-hidden': 'true', 'aria-expanded': 'false'});
                parent.prev().find('a').first().click();
                items = parent.find(">[role^='treeitem']").length;
                temptreeitems = $('').add(treeitems.slice(0, currentItem + items)).add(subtreeitems).add(treeitems.slice(currentItem + items));
                currentItem = currentItem - items;
                parent.closest('[role="treeitem"]').focus();
              } else {
                currentItem = currentItem - 1;
              }
              treeitems[currentItem].focus();
              break;

          }
          e.stopPropagation();

        });
      }
    };
  }]);
}(window.app));
