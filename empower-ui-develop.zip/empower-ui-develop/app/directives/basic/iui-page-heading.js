(function (app) {
  'use strict';

  app.directive('iuiPageHeading', ['$location', '$window', function (location, window) {
    return {
      restrict: 'E',
      scope: {
        headingText: '@',
        href: '@',
        backText: '@',
        breadcrumb: '=',
        goBack: '=',
        backClick: '&'
      },
      templateUrl: '/templates/basic/iui-page-heading.html',
      link: function (scope, element) {
        element.on('click', 'a', function (e) {
          if (scope.goBack /*treat like a back button*/) {
            window.history.back();
            e.preventDefault();
            return false;
          }
        });

        scope.backLinkClicked = function () {
          if (typeof scope.backClick === 'function') {
            scope.backClick();
          }
        };
      }
    };
  }]);
}(window.app));
