(function (app) {
  'use strict';
  app.directive('iuiFooter', function (session) {
    return {
      restrict: 'EA',
      scope: {
        reload: '@'
      },
      replace: true,
      templateUrl: app.root + 'templates/basic/iui-footer.html',
      link: function (scope) {
        scope.portalName = session.get('portal');
        scope.currentDate = new Date();
      }
    };
  });
}(window.app));
