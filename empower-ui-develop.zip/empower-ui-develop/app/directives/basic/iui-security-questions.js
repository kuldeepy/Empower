(function (app) {
  'use strict';

  app.directive('iuiSecurityQuestions', [function () {
    return {
      restrict: 'E',
      scope: {
        questionsAndAnswers: '=',
        userSecurityQuestions: '=',
        permissions: '@'
      },
      templateUrl: app.root + 'templates/basic/iui-security-questions.html',
      link: function (scope) {
        scope.setQuestion = function (temp, selectedSecurityQuestion, form) {
          if (temp.QuestionId !== selectedSecurityQuestion.QuestionId) {
            temp.Answer = '';
            _.each(scope.userSecurityQuestions, function (question) {
              if (temp.QuestionId === question.QuestionId) {
                question.used = false;
              }
            });
            form.$setPristine();
          }
          temp.QuestionId = selectedSecurityQuestion.QuestionId;
          temp.Question = selectedSecurityQuestion.Question;
          temp.modify = true;
          selectedSecurityQuestion.used = true;
        };
      }
    };
  }]);
}(window.app));
