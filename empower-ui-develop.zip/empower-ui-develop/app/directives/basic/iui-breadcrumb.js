(function (app) {
  'use strict';

  app.directive('iuiBreadcrumb', [function () {
    return {
      restrict: 'E',
      scope: {
        breadcrumb: '='
      },
      templateUrl: '/templates/basic/iui-breadcrumb.html'
    };
  }]);
}(window.app));
