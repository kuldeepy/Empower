(function (app) {
  'use strict';

  app.directive('iuiModalManager', [function () {
    return {
      restrict: 'A',
      link: function (scope) {
        var numberOfModals;
        scope.$watch(function () {
          numberOfModals = $('.modal:visible').size();
          if (numberOfModals) {
            $('body').addClass('modal-open');
          } else {
            $('body').removeClass('modal-open');
          }

        });
      }
    };
  }]);
}(window.app));
