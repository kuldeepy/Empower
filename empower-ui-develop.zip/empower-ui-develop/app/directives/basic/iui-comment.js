(function (app) {
  'use strict';

  // iuiComment encompasses the commenting feature as a whole. Includes both the iuiProfileImage and
  // iuiCommenetField directive. You can also pass true to edit-mode to allow the user to edit an existing
  // comment, as well as delete it. 

  app.directive('iuiComment', [function () {
    return {
      restrict: 'E',
      scope: {
        commentData: '=',
        commentUserName: '=',
        commentPostedDate: '=',
        commentMessageText: '=',
        editMode: '=',
        commentPattern: '=',
        commentAllowSpecialCharacters: '=',
        commentTotalCharacters: '=',
        commentFieldId: '@'
      },
      templateUrl: '/templates/basic/iui-comment.html'
    };
  }]);
}(window.app));
