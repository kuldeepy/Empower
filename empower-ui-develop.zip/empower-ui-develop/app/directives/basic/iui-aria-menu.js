(function (app) {
  'use strict';

  app.directive('iuiAriaMenu', ['$window', function (window) {
    return {
      restrict: 'A',
      link: function (scope, element) {
        var menuitems = [],
          menuitemCount = 0,
          currentItem = 0,
          menuitem,
          hasSubMenu = false,
          subMenu = {},
          done = false,
          parent,
          menuitemType;
        element.on('focus', function (e) {
          menuitems = element.find(">[role^='menuitem'], >[role='presentation']>[role^='menuitem']");
          menuitemCount = menuitems.length;
          if (menuitems.length) {
            menuitems[currentItem].focus();
          }
        });

        element.on('keyup', function (e) {
          var jqItem;
          switch (e.which) {
            case 9 :
              done = true;
              break;
            case 35 : // end
              currentItem = menuitemCount - 1;
              menuitems[currentItem].focus();
              break;
            case 36 : // Home
              currentItem = 0;
              menuitems[currentItem].focus();
              break;
            case 38: // up
              if (currentItem === 0) {
                currentItem = menuitemCount - 1;
              } else {
                currentItem = currentItem - 1;
              }
              menuitems[currentItem].focus();

              break;
            case 40 : // down
              if (currentItem < menuitemCount - 1) {
                currentItem = currentItem + 1;
              } else {
                currentItem = 0;
              }
              menuitems[currentItem].focus();
              break;
            case 13 :
            case 32 :
            case 39 :
              menuitem = menuitems[currentItem];
              jqItem = $(menuitem);
              hasSubMenu = (jqItem.attr('aria-haspopup') === 'true');
              if (hasSubMenu) {
                subMenu = jqItem.trigger('click').next("[role='menu']:first");
                subMenu.attr({'aria-hidden': 'false', 'aria-expanded': 'true'}).focus();
              } else {
                menuitemType = jqItem.attr('role');
                switch (menuitemType) {
                  case 'menuitem':
                    jqItem.click();
                    break;
                  case 'menuitemradio':
                    jqItem.attr({ 'aria-checked': 'true'}).click();
                    break;
                  case 'menuitemcheckbox':
                    jqItem.attr({ 'aria-checked': 'true'}).click();
                    break;
                }

              }
              break;
            case 37 :
              menuitem = menuitems[currentItem];
              jqItem = $(menuitem);
              parent = jqItem.closest("[role='menu']").prev('[aria-haspopup]');
              if (parent.length > 0) {
                jqItem.closest("[role='menu']").attr({'aria-hidden': 'true', 'aria-expanded': 'false'}).trigger('mouseout');
                parent.focus();
              }
              break;

          }
          e.stopPropagation();

        });
      }
    };
  }]);
}(window.app));
