(function (app) {
  'use strict';

  app.directive('iuiAttachmentList', [function () {
    return {
      restrict: 'EA',
      scope: {
        fileList: '=',
        fileName: '@'
      },
      templateUrl: '/templates/basic/iui-attachment-list.html',
      link: function (scope) {
        scope.removeAttachment = function (item) {
          scope.fileList = _.reject(scope.fileList, item);
        };
      }
    };
  }]);
}(window.app));
