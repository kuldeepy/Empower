(function (app) {
  'use strict';
  // Angular's minlength directive does not $observe or $eval
  // the value of ngMinlength in Angular 1.2
  app.directive('iuiMinlength', function () {
    return {
      require: 'ngModel',
      link: function (scope, elm, attr, ngModel) {
        var minlength = 0;

        var minLengthValidator = function (value) {
          var validity = ngModel.$isEmpty(value) || value.length >= minlength;
          ngModel.$setValidity('minlength', validity);
          return validity ? value : undefined;
        };

        attr.$observe('iuiMinlength', function (val) {
          minlength = parseInt(val, 10);
          minLengthValidator(ngModel.$viewValue);
        });

        ngModel.$parsers.push(minLengthValidator);
        ngModel.$formatters.push(minLengthValidator);
      }
    };
  });
}(window.app));
