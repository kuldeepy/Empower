(function (app) {
  'use strict';

  app.directive('iuiSecurityAnswer', [function () {
    return {
      scope: {
        question: '=',
        permissions: '@',
        iuiId: '@',
        iuiIndex: '=',
        iuiPlaceholder: '@'
      },
      templateUrl: app.root + 'templates/basic/iui-security-answer.html'
    };
  }]);
}(window.app));
