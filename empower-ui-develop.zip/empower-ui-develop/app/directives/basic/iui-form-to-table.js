(function (app) {
  'use strict';

  app.directive('iuiFormToTable', ['$filter', 'profileLookUpsFactory', function ($filter, lookupSvc) {
    return {
      restrict: 'E',
      scope: {
        iuiModel: '=',
        iuiFields: '=',
        iuiXmlData: '='
      },
      link: function (scope) {
        // Angular identity used for sorting
        scope.identity = angular.identity;
        scope.custom = {};

        // Determines a list of columns used for output
        var determineColumns = function (fields) {
          var columns = _.chain(fields)
            .map(function (field) {
              return field.layout.column;
            }, {})
            .uniq()
            .value();
          return columns;
        };
        // Determines a list of rows used for output
        var determineRows = function (fields) {
          var rows = _.chain(fields)
            .map(function (field) {
              return field.layout.row;
            }, {})
            .uniq()
            .value();
          return rows;
        };

        // Applying filters to unique field types
        var parseFormData = function (model, fields) {
          if (scope.iuiXmlData) {
            $.each($($.parseXML(scope.iuiXmlData)).find('value[key^="Df.Custom"]'), function (k, v) {
              var key = _.last($(this).attr('key').split('.'));
              scope.custom['Df.Custom.' + key] = $(this)[0].textContent;
            });
          }

          _.each(fields, function (field) {
            /*// Test to see if data was already added to a field
            if (field.data === undefined) {*/
            var fieldValue = model[field.name];
            if (!fieldValue && field.name.indexOf('Df.Custom') === 0) {
              fieldValue = scope.custom[field.name];
            }
            switch (field.type) {
              case 'DropDown':
                if (field.name === 'LanguagesKey') {
                  field.name = 'PreferredLanguage';
                  if (!fieldValue) {
                    fieldValue = model[field.name];
                  }
                }
                field.data = field.listItems[fieldValue] || fieldValue;
                if (field.name === 'State' && angular.isUndefinedOrNull(field.listItems[fieldValue])) {
                  field.data = getLookupItemById('State', (field.data) ? field.data : '');
                }
                break;
              case 'DateDropdown':
                field.data = $filter('date')(fieldValue, 'MM/dd/yyyy');
                break;
              case 'PhoneTextBox':
                field.data = $filter('phone')(fieldValue);
                break;
              case 'CheckBoxList':
                if (field.name === 'RaceKey') // racekey not present in model , hence extracting the data from model.RaceDisplay
                  field.data = model.RaceDisplay.replace(/,/g, '<br>');
                else
                  field.data = fieldValue;
                break;
              default:
                field.data = fieldValue;

            }
            switch (field.name) {
              case 'SocialSecurityNumber':
                field.data = $filter('ssn')(fieldValue);
                break;
            }

          /*}*/
          });
        };

        var getLookupItemById = function (lookupType, lookupId) {
          var lookupItem;
          if (lookupType && lookupId) {
            var lookupItems = lookupSvc.getLookupItems();
            if (lookupItems && lookupItems.length >= 1) {
              lookupItem = _.find(lookupItems, function (item) {
                if (item.LookupType.toLowerCase() === lookupType.toLowerCase() && item.UniqueId === lookupId.toString()) {
                  return item.Name = item.Name;
                }
              });
            }
          }
          return (lookupItem) ? lookupItem.Name : '';
        };

        scope.isInRow = function (currentRowIndex) {
          return function (field) {
            return (field.layout.row === currentRowIndex) && field.label;
          };
        };

        scope.$watchCollection('[iuiModel, iuiFields]', function () {
          scope.columns = determineColumns(scope.iuiFields);
          scope.rows = determineRows(scope.iuiFields);
          parseFormData(scope.iuiModel, scope.iuiFields, scope.iuiXmlData);
        });
      },
      templateUrl: '/templates/basic/iui-form-to-table.html'
    };
  }]);
}(window.app));
