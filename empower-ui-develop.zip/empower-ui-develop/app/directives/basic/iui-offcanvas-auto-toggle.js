(function (app) {
  'use strict';

  app.directive('iuiOffcanvasAutoToggle', ['$window', function ($window) {
    return {
      restrict: 'A',
      scope: {
        iuiToggle: '='
      },
      link: function (scope, element) {
        var w = angular.element($window);
        var closeMenu = function () {
          if (w.width() < 768 && scope.iuiToggle === true) {
            scope.iuiToggle = false;
            element.find('.auto-toggle').unbind('click', closeMenu);
          }
        };

        var watchForClicks = function () {
          element.find('.auto-toggle').bind('click', closeMenu);
        };

        scope.$watch('iuiToggle', function () {
          if (w.width() < 768 && scope.iuiToggle === true) {
            watchForClicks();
          }
        });
      }
    };
  }]);
}(window.app));
