(function (app) {
  'use strict';

  app.directive('iuiErrorMessage', ['$sce', function ($sce) {
    return {
      restrict: 'E',
      scope: {
          errorMessage: '=',
          alertType: '='
      },
      templateUrl: app.root + 'templates/basic/iui-error-message.html',
      controller: function ($scope, $sce) {
        $scope.getTrustedHtml = function (message) {
          if (message) {
            return $sce.trustAsHtml(message);
          }
        };
      }
    };
  }]);
}(window.app));
