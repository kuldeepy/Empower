(function (app) {
  'use strict';

  app.directive('iuiMustMatch', [function () {
    return {
      restrict: 'A',
      require: 'ngModel',
      link: function (scope, elem, attr, ngModel) {
        var comparison;
        var checkValidation = function (comparisonModel, currentModel) {
          ngModel.$setValidity('mustMatch', comparisonModel === currentModel);
        };

        scope.$watch(attr.iuiMustMatch, function (newVal) {
          comparison = newVal;
          checkValidation(comparison, ngModel.$modelValue);
        });

        // For DOM -> model validation
        ngModel.$parsers.unshift(function (value) {
          checkValidation(comparison, value);
          return value;
        });

        // For model -> DOM validation
        ngModel.$formatters.unshift(function (value) {
          checkValidation(comparison, value);
          return value;
        });
      }
    };
  }]);
}(window.app));
