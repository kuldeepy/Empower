(function (app) {
  'use strict';

  app.directive('iuiSearchNameOrZip', [function () {
    return {
      restrict: 'E',
      templateUrl: '/templates/basic/iui-search-name-or-zip.html',
      link: function (scope, element, attrs) {
        scope.iuiId = attrs.iuiId;
      }
    };
  }]);
}(window.app));
