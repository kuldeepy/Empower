(function (app) {
  'use strict';

  /* dialog controller for confirm */
  app.controller('transmitAgreePopupDialogCtrl', ['$scope', '$modalInstance', 'header', 'session', 'api', '$dialogFactory', function (scope, modalInstance, header, session, api, dialog) {
    scope.header = header;

    scope.controllerData = {
    };

    scope.no = function () {
      modalInstance.dismiss();
    };

    scope.clinicalDocumentsTransmitAggreeButtonClick = function () {
      modalInstance.close();
    };

  }]);

}(window.app));
