(function (app) {
  'use strict';

  /* dialog controller for confirm */
  app.controller('transmitPopupDialogCtrl', ['$scope', '$modalInstance', 'header', 'session', '$dialogFactory', 'alertService', 'medseekApi', '$translate', 'generic', function (scope, modalInstance, header, session, dialog, alertService, medseekApi, translate, generic) {
    scope.header = header;
    alertService.clear();

    var patient = JSON.parse(session.get('patient'));

    scope.controllerData = {
      EmailPattern: /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/,
      tranmitMessageTextBoxPattern: /^(a-z|A-Z|0-9)*[^#$%^&*()']*$/,
      transmitClinicalDocumentcssClassName: 'transmitClinicalDocument',
      transmitClinicalDocumentEmailcssClassName: 'transmitEmail'
    };

    /* close popup */
    scope.no = function (form) {
      if (form) {
        if (!form.$dirty) {
          modalInstance.dismiss();
          return;
        }
        var dialogCallback = dialog.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
        dialogCallback.result.then(function () {
          modalInstance.dismiss();
        });
      } else {
        modalInstance.dismiss();
      }
    };

    /* transmit clinical document button click*/
    scope.sendClinicalDocumentButtonClick = function (form) {
      alertService.clear();
      if ($('.ng-invalid-pattern').length > 0) {
        alertService.add('danger', translate.instant('HL_INVALID_EMAIL_FORMAT_FOR_TRANSMIT_DOCUMENT'), 0, '', 'alert_transmitmessage-popup');
        return;
      }
      if (scope.checkIsEmailAvailable()) {
        if (form.$dirty) {
          if (scope.validateMessage(form)) {
            scope.transmitClinicalDocument(generic.selectedRow);
          }
        } else {
          modalInstance.dismiss();
        }
      }
    };

    /* validate transmit email id */
    scope.validateEmail = function (form) {
      if (!(scope.controllerData.EmailPattern.test(scope.controllerData.toEmailAddress))) {
        scope.controllerData.focusEmail = generic.trueValue;
        alertService.add('danger', translate.instant('HL_INVALID_EMAIL_FORMAT_FOR_TRANSMIT_DOCUMENT'));
        return;
      } else {
        generic.errorMessages = [];
        scope.transmitEmailClass = '';
      }
    };

    scope.transmitEmailClass = '';
    /* validate transmit email id */
    scope.checkIsEmailAvailable = function (form) {
      if (!scope.controllerData.toEmailAddress) {
        scope.controllerData.focusEmail = generic.trueValue;
        scope.transmitEmailClass = scope.controllerData.transmitClinicalDocumentEmailcssClassName;
        alertService.add('danger', translate.instant('HL_INVALID_EMAIL_FORMAT_FOR_TRANSMIT_DOCUMENT'), 0, '', 'alert_transmitmessage-popup');
        return;
      } else {
        generic.errorMessages = [];
      }

      return (generic.errorMessages.length <= 0);
    };

    /* validate transmit message against special characters */
    scope.validateMessage = function (form) {
      if (!(scope.controllerData.tranmitMessageTextBoxPattern.test(scope.controllerData.message))) {
        scope.transmitClass = scope.controllerData.transmitClinicalDocumentcssClassName;
        scope.controllerData.focusMessage = generic.trueValue;
        alertService.add('danger', translate.instant('HL_INVALID_CHARACTERS_USED_IN_TRANSMIT_MESSAGE'), 0, '', 'alert_transmitmessage-popup');
        return;
      } else {
        generic.errorMessages = [];
      }

      return (generic.errorMessages.length <= 0);
    };

    /*reset transmit popup messages*/
    scope.clearMesage = function () {
      generic.errorMessages = [];
      scope.controllerData.toEmailAddress = '';
      scope.controllerData.message = '';
    };

    scope.okClick = function () {
      modalInstance.close();
    };

    /*transmit the clinical document*/
    scope.transmitClinicalDocument = function (selectedRow) {
      var request = {
        'request': {
          'medseekId': patient.mrn,
          'fileName': selectedRow.name,
          'recipient': scope.controllerData.toEmailAddress,
          'message': scope.controllerData.message || '',
          'fileId': selectedRow.fileId,
        }
      };

      medseekApi.healthInformation.transmitClinicalDocument.save({ patientId: patient.patientId, documentId: selectedRow.id }, request).$promise.then(function (response) {
        if (!response.results.success) {
          alertService.add('danger', translate.instant('HL_INVALID_DIRECT_EMAIL_ADDRESS_FOR_TRANSMIT_DOCUMENT') , 0, '', 'alert_transmitmessage-popup');
          return;
        }
        modalInstance.close();
        alertService.add('success', translate.instant('HL_SUCCESSFULLY_TRANSMITTED_DOCUMENT'));
        medseekApi.patient.patientAuditLog.save({ patientId: patient.patientId }, {typeOfDataAccessed: selectedRow.displayName, dataAccessActionValue: 'Clinical Document Transmitted', details: 'Document Type =' + selectedRow.type + '; Document Source=' + selectedRow.source + '; Document Id=' + selectedRow.fileId + ';Recipient Address=' + scope.controllerData.toEmailAddress + ';', auditedBy: 'Health Information'});
      }, function (data) {
        generic.errorMessages = [];
        var dialogCallback = dialog.alert('alertDialog', translate.instant('ALERT_INFO'), translate.instant('HL_UNABLE_TO_TRANSMIT_DOCUMENT'));
        dialogCallback.result.then(function () {
          scope.okClick();
        });

      });
    };

  }]);

}(window.app));
