(function (app) {
  'use strict';

  /* directive for upload image */
  app.directive('uploadImage', ['profileImage', '$rootScope', function (profileImage, rootScope) {
    return {
      restrict: 'E',
      require: '?ngModel',
      templateUrl: app.root + 'templates/image-upload.html',
      /*scope: {
        readOnly: '='
      },*/
      link: function (scope, elem, attrs, ngModel) {
        rootScope.$on('GenderChanged', function (s, gender) {
          ngModel.$render();
        });
        ngModel.$render = function () {
          scope.image = profileImage.source();
        };
      }
    };
  }]);

})(window.app);
