(function (app) {
  'use strict';

  /* directive for upload click */
  app.directive('msUploadClick', ['profileImage', 'alertService', '$translate', function (profileImage, alertService, translate) {
    return {
      restrict: 'A',
      link: function (scope, elem, attrs) {
        var oReader = new FileReader();
        oReader.onload = function (e) {
          profileImage.imageSrc = e.target.result;
          $('.imageAppend').children().remove();
          scope.$apply();
          $('.imageAppend').append(null);
          $('.imageAppend').append('<img class="imageControl" alt="">');
          $('.imageControl').attr('src', e.target.result);
          $('.imageControl').Jcrop({
            trackDocument: true,
            onSelect: function (x) {
              scope.$apply(function () {
                scope.selected({ cords: x });
                if (attrs.msUploadClick === 'profile') {
                  if (scope.stepIndex !== 1) {
                    scope.next();
                  }
                }
              });
            },
            aspectRatio: 1,
            keySupport: false,
            boxWidth: 200,
            boxHeight: 200,
            setSelect: [0, 0, 0, 0],
          });
        };

        elem.on('click', function () {
          alertService.clear();
          var imageUploadFailureMessage = translate.instant('USER_SETTINGS_IMAGE_UPLOAD_ERROR');
          if (profileImage.imageData.length === 0) {
            alertService.add('danger', translate.instant('USER_SETTINGS_INVALID_FILE_LOCATION_ERROR'), 0, '', 'alert_wizard-step');
            scope.$apply();
            return;
          }
          // get selected file
          var oFile = profileImage.imageData[0];
          $('.imageError').html('');
          // check for image type (jpg and png are allowed)
          var rFilter = /^(image\/jpeg|image\/png|image\/gif)$/i;
          if (!rFilter.test(oFile.type)) {
            alertService.add('danger', imageUploadFailureMessage, 0, '', 'alert_wizard-step');
            scope.$apply();
            return;
          }

          // check for file size
          if (oFile.size > 4 * 1024 * 1024) {
            alertService.add('danger', imageUploadFailureMessage, 0, '', 'alert_wizard-step');
            scope.$apply();
            return;
          }

          var file, img;
          var _URL = window.URL || window.webkitURL;
          if ( (file = oFile)) {
            img = new Image();
            img.onload = function () {
              if (this.width < 200 || this.height < 200) {
                alertService.add('danger', imageUploadFailureMessage, 0, '', 'alert_wizard-step');
                scope.$apply();
                return;
              } else {
                oReader.readAsDataURL(oFile);
                $('.inActive').addClass('uploadActive');
                profileImage.isOpenUpload = false;
              }
            };
            img.onerror = function () {};
            img.src = _URL.createObjectURL(file);
          }

        /*oReader.readAsDataURL(oFile);
        $('.inActive').addClass('uploadActive');
        profileImage.isOpenUpload = false;*/
        });
      // scope.$on('$destroy', clear);
      }
    };
  }]);

})(window.app);
