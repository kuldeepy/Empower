(function (app) {
  'use strict';

  /* directive for image upload */
  app.directive('msImageUpload', ['profileImage', function (profileImage) {
    return {
      restrict: 'A',
      link: function (scope, elem, attrs) {
        profileImage.imageData = [];
        elem.on('change', function () {
          profileImage.imageData = elem[0].files;
          angular.element(this).scope().fileNameChanged(this);
        });
      }
    };
  }]);
})(window.app);
