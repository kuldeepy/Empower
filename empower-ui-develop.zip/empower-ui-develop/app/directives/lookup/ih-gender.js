(function (app) {
  'use strict';
  app.directive('ihGender', ['medseekApi', function (api) {
    var promise = api.genders.get().$promise;
    return {
      template: '<span ng-if="loaded">{{gender.name || "Unknown"}}</span>',
      restrict: 'E',
      scope: {
        value: '@'
      },
      link: function (scope) {
        promise.then(function (data) {
          scope.loaded = true;
          scope.gender = _.find(data.results, { id: scope.value });
        });
      }
    };
  }]);
})(window.app);
