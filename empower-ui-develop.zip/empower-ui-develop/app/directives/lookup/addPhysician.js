(function (app) {
  'use strict';

  /* directive for task center new discussion */
  app.directive('msAddPhysician', [function () {
    return {
      restrict: 'E',
      scope: true,
      templateUrl: app.root + 'modules/Add-patient/templates/addPhysician.html',

      controller: ['$scope', 'medseekApi', 'session', '$q', '$location', '$timeout', 'alertService', 'dialogService', 'moduleSettingsFactory', '$dialogFactory', 'dynamicText', '$translate', 'localStorageSvc', 'patientProfileInfo', 'PatientInfoInWizardService', 'patientProfileService', 
        function (scope, api, session, q, loc, timeout, alertService, diag, moduleSettingsFactory, dialogFactory, dynamicText,translate, localStorageSvc, patientProfileInfo, PatientInfoInWizardService, patientProfileService) {
        /* variable declarations */
        var patient = {};

        scope.isPrimaryAlready = false;
        scope.isSearch = false;
        scope.error = 'danger';
        scope.linkedPhysicians = [];
        scope.selectedPhysicianErrorMessage = translate.instant('PATIENT_MANAGEMENT_FILL_REQUIRED_INFO_PROMPT');
        scope.savePhysicianErrorMessage = translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SAVE_COMPONENT');
        scope.fillPhysicianDetailErrorMessage = translate.instant('PATIENT_MANAGEMENT_FILL_MANAGEMENT_PHYSICIAN_DETAILS');
        scope.searchTypePhysician = true;
        scope.sortOptions = { fields: ['LastName'], directions: ['asc'] };
        scope.pagingOption = { pageSize: 3, totalItems: 100, currentPage: 1, pageOption: [] };
        scope.setNumberOfPages = scope.pagingOption.pageOption[0];
        scope.searchByName = '';
        scope.selectedPhysician = {};
        scope.selectedPhysician.isPrimary = false;
        scope.iuiId = scope.$parent.iuiId || 0;

        scope.getAllAdminSettingsDynamicTexts = function () {
          var culture = localStorageSvc.get('cultureName') || 'en-US';
          var deferred = q.defer();
          api.getAllAdminSettingsDynamicTexts.get({ culture: culture }, null).$promise.then(function (response) {
            deferred.resolve(response);
          }, function (error) {
            deferred.reject(error);
          });
          return deferred.promise;
        };
        scope.filterDynamicText = function (msgKey, data) {
          var dynamicTextWelcomeMsg = _.where(data.results, function (value, key) { return key === msgKey; });
          if (dynamicTextWelcomeMsg) {
            return dynamicTextWelcomeMsg[0];
          }
          return 'n/a';
        };

        scope.getPatientPhysicians = function () {
          var patient = scope.patient = scope.currentPatient = JSON.parse(session.get('patient'));
          if (!scope.patient) {
            return;
          }
          var patient = JSON.parse(session.get('patient'));

          PatientInfoInWizardService.getPatientsPhysicians(patient.patientId).then(function (response) {
            scope.patintPhysicians = response;
            scope.selectedPhysician.isPrimary = (scope.patintPhysicians.length == 0);
          });
        };

        /* watch function for pagination - page size */
        scope.searchPhysicians = function (searchByName) {
          scope.searchByName = searchByName;
          scope.physicianName = '';
          scope.physicians = [];
          scope.isSearch = true;
          scope.showGrid = true;
          var body = {};
          if (scope.searchByName !== undefined && scope.searchByName.trim().length > 0) {
            scope.physicianName = scope.searchByName;
          } else {
            scope.physicianName = '';
          }
          scope.pagingOption.currentPage = 1;
          scope.isSelected = false;
          scope.getAllPhysicians();
          scope.getPatientPhysicians();
        };

        /* get sort direction */
        scope.getSortDirection = function (direction) {
          var mapedDirection = '';
          switch (direction.toLowerCase()) {
            case 'asc':
              mapedDirection = 'Ascending';
              break;
            case 'desc':
              mapedDirection = 'Descending';
              break;
            default:
              mapedDirection = 'Ascending';
              break;
          }
          return mapedDirection;
        };

        /* construct search criteria */
        scope.constructSearchPhysiciansReqObject = function (reqObject) {
          if (scope.isSearch && scope.searchByName) {
            return {
              'fullName': scope.searchByName,
              'sortField': typeof scope.orderByField === 'undefined' ? scope.sortOptions.fields[0] : scope.orderByField,
              'sortDirection': typeof scope.sortOrder === 'undefined' ? scope.getSortDirection(scope.sortOptions.directions[0]) : scope.getSortDirection(scope.sortOrder),
              'pageSize': scope.pagingOption.pageSize,
              'currentPageNumber': scope.pagingOption.currentPage,
              'patientId': patient.patientId

            };
          } else {
            return {
              'sortField': typeof scope.orderByField === 'undefined' ? scope.sortOptions.fields[0] : scope.orderByField,
              'sortDirection': typeof scope.sortOrder === 'undefined' ? scope.getSortDirection(scope.sortOptions.directions[0]) : scope.getSortDirection(scope.sortOrder),
              'pageSize': scope.pagingOption.pageSize,
              'currentPageNumber': scope.pagingOption.currentPage,
              'patientId': patient.patientId
            };
          }
        };

        /* get all physicians or physicians search result */
        scope.getAllPhysicians = function () {
          patient = scope.patient = scope.currentPatient = JSON.parse(session.get('patient'));
          if (!scope.patient) {
            return;
          }
          scope.selectedPhysician = {};
          scope.selectedPhysician.isPrimary = (scope.patintPhysicians && scope.patintPhysicians.length == 0);
          var reqObject = scope.constructSearchPhysiciansReqObject();
          scope.physicians = [];
          api.getPhysicians.get(reqObject).$promise.then(function (response) {
            scope.physicians = response.results.Retval;
            scope.pagingOption.totalItems = response.results.totalItemCount;
          }, function (error) {
            alertService.add(scope.error, translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_GET_PHYSICIANS'), 0, '', 'alert_physicians-popup');
          });
        };

        /* sort physicians search results */
        scope.sortSearchPhysicians = function (type) {
          var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
          if (scope.pagingOption.currentPage > total) {
            return;
          }
          scope.sortOrder = scope.sortOptions.directions[0] === 'desc' ? 'asc' : 'desc';
          scope.reverseSort = scope.sortOrder === 'asc' ? true : false;
          scope.sortOptions.directions[0] = scope.sortOrder;
          scope.isSearch = true;
          scope.orderByField = type;
          scope.pagingOption.currentPage = 1;
          scope.getAllPhysicians();
        };

        /* watch function for pagination - current page */
        scope.$watch('pagingOption.currentPage', function (newVal, oldVal) {
          alertService.clear();
          var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
          if (oldVal !== newVal && newVal !== '' && parseInt(newVal) > 0 && total >= newVal) {
            scope.getAllPhysicians();
          }
          else if (isNaN(newVal) || parseInt(newVal) >= total || parseInt(newVal) <= 0 || isNaN(parseInt(newVal))) {
            alertService.add('danger', translate.instant('PLEASE_ENTER_VALID_PAGE_NUMBER'), 0, '', 'alert_add-physcian-popup');
          }
        });

        /* watch function for pagination - page size */
        scope.$watch('pagingOption.pageSize', function (oldVal, newVal) {
          if (oldVal !== newVal) {
            scope.pagingOption.currentPage = 1;
            scope.getAllPhysicians();
          }
        });

        /* checked physician */
        scope.checkedPhysician = function (physician) {
          scope.selectedPhysician = physician;
          scope.isSelected = true;
          scope.selectedPhysician.isPrimary = (scope.patintPhysicians.length == 0);
          scope.searchPhysicianForm.$dirty = true;
        };

        /* save physician to patient profile */
        scope.savePhysicianToProfile = function (flowControl) {
          alertService.clear();
          if (!scope.selectedPhysician || !scope.selectedPhysician.Id) {
            alertService.add(scope.error, translate.instant('ADD_PHYSICIAN_SELECT_PHYSICIAN_ERROR'), 0, '', 'alert_add-physcian-popup');
            return;
          }
          patient = scope.patient = scope.currentPatient = JSON.parse(session.get('patient'));
          if (!scope.patient) {
            return;
          }

          var promise;
          if (scope.isAddPhysicianApprovalNotRequired) {
            scope.selectedPhysician.isApprovalRequired = false;
            promise = api.patients.savePhysician.save({ patientId: patient.patientId, physicianId: scope.selectedPhysician.Id }, { isDefault: false }).$promise.then(function (response) {
              scope.physicianName = '';
              scope.searchByName = '';
              scope.physicians = [];
              scope.isSearch = false;
              scope.isSelected = false;
              diag.hide('addPhysician');
              scope.PhysicianSuccessMessage = translate.instant('PATIENT_MANAGEMENT_PHYSICIAN_SAVED_TO_PROFILE', { patientName: patient.patientName });
              alertService.add('success', scope.PhysicianSuccessMessage);
              patientProfileService.updateProfileInfo('physicians');
              return response;
            }, function (error) {
              alertService.add(scope.error, translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SAVE_PHYSICIANS'), 0, '', 'alert_add-physcian-popup');
            });

            promise.then(function (response) {
              if (response.results.Retval && scope.selectedPhysician.isPrimary === true) {
                api.patients.primaryPhysician.update({ patientId: patient.patientId, physicianId: response.results.Retval }, null).$promise.then(function (primaryResponse) {
                  scope.getPhysiciansAndProceed(response.results.Retval);
                });
              } else {
                scope.getPhysiciansAndProceed(response.results.Retval);
              }
            });
          } else {
            moduleSettingsFactory.getModuleSettings('profile').then(function (settings) {
              var promise = api.patients.savePhysician.save({ patientId: patient.patientId, physicianId: scope.selectedPhysician.Id }, { isDefault: !settings.RequireApprovalForPhysicians }).$promise.then(function (response) {
                scope.selectedPhysician.isApprovalRequired = settings.RequireApprovalForPhysicians;

                scope.physicianName = '';
                scope.searchByName = '';
                scope.physicians = [];
                scope.isSearch = false;
                scope.isSelected = false;
                diag.hide('addPhysician');
                scope.$parent.closePopups();

                /* commented success messages (have to remove from here and move to controller)*/

                if (settings.RequireApprovalForPhysicians) {
                  scope.getAllAdminSettingsDynamicTexts().then(function (data) {
                    scope.PhysicianSuccessMessage = scope.filterDynamicText('Profile_PhysiciansApprovalRequiredMessage', data).replace('{{patientName}}', patient.patientName);
                    if (scope.$parent.showPhysicianSuccessMessage) {
                      scope.$parent.showPhysicianSuccessMessage(scope.PhysicianSuccessMessage).replace('{{patientName}}', patient.patientName);
                    }
                    alertService.add('success', scope.PhysicianSuccessMessage);
                  });
                } else {
                  scope.PhysicianSuccessMessage = translate.instant('PATIENT_MANAGEMENT_PHYSICIAN_SAVED_TO_PROFILE', { patientName: patient.patientName })
                  if (scope.$parent.showPhysicianSuccessMessage) {
                    scope.$parent.showPhysicianSuccessMessage(scope.PhysicianSuccessMessage);
                  }
                  alertService.add('success', scope.PhysicianSuccessMessage);
                }
                patientProfileService.updateProfileInfo('physicians');
                return response;
              }, function (error) {
                alertService.add(scope.error, translate.instant('PATIENT_MANAGEMENT_UNABLE_TO_SAVE_PHYSICIANS'), 0, '', 'alert_add-physcian-popup');
              });

              promise.then(function (response) {
                if (response.results.Retval && scope.selectedPhysician.isPrimary === true) {
                  api.patients.primaryPhysician.update({ patientId: patient.patientId, physicianId: response.results.Retval }, null).$promise.then(function (primaryResponse) {
                    scope.getPhysiciansAndProceed(response.results.Retval);
                  });
                } else {
                  scope.getPhysiciansAndProceed(response.results.Retval);
                }
              });
            });
          }
        };

        scope.getPhysiciansAndProceed = function (currentProfilePhyID) {
          timeout(function () {
            scope.$parent.getPatientPhysicians(scope.selectedPhysician, currentProfilePhyID, scope.PhysicianSuccessMessage);
            scope.getPatientPhysicians();
          }, 200);

          scope.physicianName = '';
          scope.physicians = [];
          scope.isSearch = false;
        };

        scope.$on('closeDialog', function () {
          scope.closePopups();
        });

        scope.closePopups = function () {
          if (scope.searchPhysicianForm.$dirty === false) {
            scope.physicians = [];
            scope.physicianName = '';
            scope.searchByName = '';
            scope.isSearch = false;
            scope.isSelected = false;
            diag.hide('addPhysician');
            scope.searchPhysicianForm.$setPristine();
            scope.$parent.closePopups();
          } else {
              var dialogCallback = dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
            dialogCallback.result.then(function () {
              scope.physicianName = '';
              scope.searchByName = '';
              scope.physicians = [];
              scope.isSearch = false;
              scope.isSelected = false;
              diag.hide('addPhysician');
              scope.searchPhysicianForm.$setPristine();
              scope.$parent.closePopups();
            });

          }

        };

        scope.$on('addPhysiciancloseDialog', function () {
          scope.closePopups();
        });

      }]
    };
  }]);

}(window.app));
