(function (app) {
  'use strict';

  /* directive for task center new discussion */
  app.directive('msAddLocation', [function () {
    return {
      restrict: 'E',
      scope: true,
      templateUrl: app.root + 'modules/Add-patient/templates/addLocation.html',

      controller: ['$scope', 'medseekApi', 'session', '$q', '$location', '$timeout', 'alertService', 'dialogService', '$dialogFactory','$translate', 'PatientInfoInWizardService', 'patientProfileService',
        function (scope, api, session, q, loc, timeout, alertService, diag, dialogFactory,translate, PatientInfoInWizardService, patientProfileService) {
        /* variable declarations */
        scope.isSearch = false;
        scope.reverseSort = true;
        scope.error = 'danger';
        scope.saveErrorMessage = 'Unable to save';
        scope.orderByField = 'locationName';
        scope.selectedLocation = {};
        scope.selectedLocationErrorMessage = 'Please select a location and try again.';
        scope.searchType = true;
        scope.isSelected = false;
        scope.selectedLocation.isPrimary = false;
        scope.sortOptions = {
          fields: ['locationName'],
          directions: ['ascending']
        };

        scope.iuiId = scope.$parent.iuiId || 0;

        /* checked location */
        scope.getPatientLocations = function (location) {
          scope.patient = JSON.parse(session.get('patient'));
          if (!scope.patient) {
            return;
          }

          PatientInfoInWizardService.getPatientsLocations({ patientId: scope.patient.patientId }).then(function (response) {
            scope.patientLocations = response;
            scope.selectedLocation.isPrimary = (scope.patientLocations.length === 0);
          }, function (error) {});
        };

        /* checked location */
        scope.checkedLocation = function (location) {
          scope.selectedLocation = location;
          scope.isSelected = true;
          scope.selectedLocation.isPrimary = (scope.patientLocations && scope.patientLocations.length === 0);
        };

        /* search click function */
        scope.searchClick = function (isByName) {
          scope.isSearch = false;
          scope.selectedLocation = scope.selectedLocation = {};
          if (scope.pagingOption.currentPage === 1)
            scope.getLocations();
          else
            scope.pagingOption.currentPage = 1;
          scope.getPatientLocations();
        };

        /* sort the records */
        scope.sortColumnClick = function (columnName) {
          var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
          if (scope.pagingOption.currentPage > total) {
            return;
          }
          scope.sortOrder = scope.sortOptions.directions[0] === 'descending' ? 'ascending' : 'descending';
          scope.reverseSort = scope.sortOrder === 'ascending' ? true : false;
          scope.sortOptions.directions[0] = scope.sortOrder;
          scope.isSearch = true;
          scope.sortOptions.fields[0] = columnName;
          scope.pagingOption.currentPage = 1;
          scope.getLocations();
        };

        /* build the search body */
        scope.buildSearchBody = function () {
          var body = {};
          if (scope.searchType) {
            body.locationName = scope.searchByName;
          } else {
            body.zip = scope.searchByZip;
            body.radius = (scope.locationDistance !== null) ? parseInt(scope.locationDistance) : 10;
          }
          body.patientId = scope.patient.patientId;
          body.pageSize = scope.pagingOption.pageSize;
          body.pageNumber = scope.pagingOption.currentPage;
          body.sortField = scope.sortOptions.fields[0];
          body.sortDirection = scope.sortOptions.directions[0];
          return body;
        };

        /* get all the locations */
        scope.getLocations = function () {
          scope.patient = JSON.parse(session.get('patient'));

          api.location.locationsList.save(null, scope.buildSearchBody()).$promise.then(function (response) {
            scope.locations = [];
            scope.locations = response.results.locations;
            scope.pagingOption.totalItems = response.results.count;
            scope.isSearch = true;
            scope.isSelected = false;
          }, function (error) {});
        };

        scope.savePatientLocation = function () {
          if (!scope.selectedLocation || !scope.selectedLocation.Id) {
            alertService.add(scope.error, 'Please select Location.', 0, '', 'alert_add-location-popup');
            return;
          }

          scope.patient = JSON.parse(session.get('patient'));
          if (!scope.patient) {
            return;
          }

          if (scope.selectedLocation && scope.selectedLocation.Id && scope.patient && scope.patient.patientId) {
            api.patient_management.locations.save({ patientId: scope.patient.patientId }, { isDefault: scope.selectedLocation.isPrimary, locationId: scope.selectedLocation.Id, isCopy: false }).$promise.then(function (response) {
              if (response.results.Retval) {
                alertService.add('success', translate.instant('PATIENT_MANAGEMENT_LOCATION_SAVED_TO_PROFILE', {patientFirstName: scope.patient.patientName}), 5000);
                patientProfileService.updateProfileInfo('locations');
                timeout(function () {
                  scope.getPatientLocations();
                  scope.$parent.getPatientLocations(scope.selectedLocation, response.results.Retval);
                }, 200);

                scope.locations = [];
                scope.searchByName = '';
                scope.searchByName = '';
                scope.isSearch = false;
                scope.isSelected = false;
                diag.hide('addLocations');
                scope.$parent.closePopups();
              }
            }, function (error) {});
          }
        };

        scope.pagingOption = {
          // content in one page
          pageSize: 3,
          // total number of items in box
          totalItems: 100,
          currentPage: 1,
          pageOption: []
        };

        /*Search by Zip Validation*/
        scope.validateZip = function () {
          scope.locationDistance = scope.locationDistance ? scope.locationDistance : 10;
          scope.searchByZip = (scope.searchByZip) ? scope.searchByZip.replace(/[^a-z0-9]/gi, '') : '';
        };

        scope.setNumberOfPages = scope.pagingOption.pageOption[0];

        scope.$watch('pagingOption.currentPage', function (newVal, oldVal) {
          // call api for next page
          alertService.clear();
          var total = (Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) >= scope.pagingOption.totalItems / scope.pagingOption.pageSize) ? Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) : Math.floor(scope.pagingOption.totalItems / scope.pagingOption.pageSize) + 1;
          if (oldVal !== newVal && newVal !== '' && parseInt(newVal) > 0 && total >= newVal) {
            if ((scope.searchPagingData) && (scope.searchPagingData.length > 0)) {
              scope.setPagingData(scope.searchPagingData, scope.pagingOption.currentPage, scope.pagingOption.pageSize);
            } else {
              scope.getLocations();
            }
          }
          else if (isNaN(newVal) || parseInt(newVal) >= total || parseInt(newVal) <= 0 || isNaN(parseInt(newVal))) {
            alertService.add('danger', 'Please enter the valid page no', 0, '', 'alert_add-location-popup');
          }
        });

        /* set pagination data */
        scope.setPagingData = function (data, page, pageSize) {
          if (data !== undefined) {
            scope.pagingOption.totalItems = data.length;
            scope.locations = data.slice((page - 1) * pageSize, page * pageSize);
          }
        };

        scope.searchTypeChange = function () {
          scope.isSearch = false;
          scope.selectedLocation = scope.selectedLocation = {};
          scope.pagingOption.currentPage = 1;
          scope.searchPagingData = [];
          scope.locations = [];
        };

        scope.$on('closeDialog', function () {
          scope.closePopups();
        });

        scope.closePopups = function () {
          if (scope.form.$dirty === false) {
            scope.locations = [];
            scope.searchByName = '';
            scope.isSearch = false;
            scope.isSelected = false;
            diag.hide('addLocations');
            scope.form.$setPristine();
            scope.$parent.closePopups();
          } else {
            var dialogCallback = dialogFactory.confirm('confirmDialog', translate.instant('CONFIRM_CANCEL_DIALOG_NAME'), translate.instant('CONFIRM_CANCEL_DIALOG_MSG'));
            dialogCallback.result.then(function () {
              scope.searchByZip = '';
              scope.locations = [];
              scope.searchByName = '';
              scope.isSearch = false;
              scope.isSelected = false;
              diag.hide('addLocations');
              scope.form.$setPristine();
              scope.$parent.closePopups();
            });
          }
        };
      }]
    };
  }]);

}(window.app));
