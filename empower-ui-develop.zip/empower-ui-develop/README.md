# empower-ui
This project contains the source code of the MEDSEEK Empower web user interface.

# build & run
1.) Get the source
```
$> git clone https://github.com/medseek-empower/empower-ui.git
```
2.) Install dependencies
````
$> cd empower-ui
````
````
$> npm install
$> npm install -g grunt
````
3.) Run the server
````
$> grunt compass:dist
$> node app.js
````

You should see output similar to: **UI, listening on port 4000**  
Browse to "http://localhost:4000/"

# testing
You may execute unit tests by running the command:
````
$> grunt test
````

# wcag information
This website has a lot of good information on accessibility
[http://webaim.org/intro/](http://webaim.org/intro/)

The Official documentation : [http://www.w3.org/TR/WCAG20/](http://www.w3.org/TR/WCAG20/) Very dry reading use the quick ref below unless you need more detail.

WCAG Quick Reference

[http://www.w3.org/WAI/WCAG20/quickref/](http://www.w3.org/WAI/WCAG20/quickref/)

Save settings : Check only for Level A.  Using HTML, CSS, Client Scripting and WAI-ARIA techniques.  This will cause the page to link to the more detailed information about each guideline.

WAI-ARIA

+ [http://www.w3.org/TR/wai-aria-primer/](http://www.w3.org/TR/wai-aria-primer/)
+ [http://www.w3.org/TR/wai-aria-practices/](http://www.w3.org/TR/wai-aria-practices/)

Testing Tools

+ [http://wave.webaim.org/](http://wave.webaim.org/)
+ Firefox plugin - [http://wave.webaim.org/toolbar/](http://wave.webaim.org/toolbar/)
+ Chrome Extention - [https://chrome.google.com/webstore/detail/accessibility-developer-t/fpkknkljclfencbdbgkenhalefipecmb](https://chrome.google.com/webstore/detail/accessibility-developer-t/fpkknkljclfencbdbgkenhalefipecmb)

Screen Reader

[http://www.nvaccess.org/](http://www.nvaccess.org/)
