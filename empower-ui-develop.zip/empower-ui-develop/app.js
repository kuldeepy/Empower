'use strict';

// require dependencies
var ui = require('ui-core')();
// apply ui extensions
ui.use(require('./resources/body-parser'));
ui.use(require('./resources/samlRequestResource.js'))
ui.use(require('input-validation'));
ui.use(require('ui-dynamic-forms'));
ui.use(require('iui-table'));
ui.use(require('./mocks'));
ui.use(require('./resources/saml-service-provider'));
ui.use(require('./resources/translation-overrides-files'));
ui.use(require('./resources/iframe-parent-policy'));

// start the UI server
ui.start();