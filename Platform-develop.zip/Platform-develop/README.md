Platform
========

Medseek Platform level code for services/etc.


Setup
=====

1. Download and install ERLANG (http://www.erlang.org/download.html). Make sure to choose a version that is appropriate for your OS (64 bit or 32 bit).
2. Download and install Rabbit MQ (https://www.rabbitmq.com/download.html) that is appropriate for your OS and version of that OS. The version that we are currently using is 3.3.0, though I  don’t think it matters.
  2. Check all items in the “Choose Components” dialog.
  2. Once installed, open the RabbitMq Command Prompt and run the following command: `rabbitmq-plugins enable rabbitmq_management`
3. Optional: download and install Handle.exe from technet. (http://download.sysinternals.com/files/Handle.zip)
  3. Install this by unzipping the Handle.zip file, and copying the Handle.exe inside of it to your c:\windows directory.
  3. This is optional, it’s a tool used by the rabbit mq management console to help show some information, but it will work without out.
4. Setup an account for github (https://github.com/).
  4. Once you have an account created, you will need to be given access to the repositories. Dominic can do this, he will need your username to do so.
5. Download and install Git. (https://help.github.com/articles/set-up-git), follow the guide.
6. At this point you will need to also have your teamcity and octopus accounts created and setup (given proper access).
7. Setup the NUGET feed for our teamcity server in visual studio
  7. Tools -> NuGet Package Manager -> Nuget Package Manager Settings.
  7. Package Sources
  7. Type in the name and URL
    7. Name: Doesn’t realy matter, I used “MEDSEEK VM-DEV-01@Teamcity”
    7. Url: https://vm-dev-01.medseek.com/nuget-dev/nuget
    7. Click the “+” sign near the top to add this nuget feed source.

You should now be able to create a new microservice project in Visual Studio

Visual Studio NuGet Package Manager forgets my password!
=========================================================
Follow these steps to get it to actually remember your password:

1.	Open a command prompt and change directory to: [Platform Directory]\tools\nuget
2.	Run the following: NuGet.exe Sources
3.	You should see a list of sources printed to your screen. 
4.	Run the following command, substituting the name of your source, your username and your password based on the information printed in #3:

  •	NuGet.exe sources Update -Name "[Name of the source from Step 3]" -Source https://vm-dev-01.medseek.com/nuget-dev/nuget -UserName [Your vm-dev-01 Username] -Password [Your vm-dev-01 Password]
  
  •	After substituting the values the command should look something like this (the highlighted values are substituted based on the information you gathered in step #3:
  
    o	NuGet.exe sources Update -Name "Medseek VM-DEV-01@Teamcity" -Source https://vm-dev-01.medseek.com/nuget-dev/nuget -UserName myUsername -Password myPassword
    
•	If successful, it should print something similar to “Package source "Medseek VM-DEV-01@Teamcity" was successfully updated.” To the screen.

What this does is update your %APPDATA%\NuGet\NuGet.config file with your username and password. The password information is encrypted. Once you complete this, next time you open visual studio and update your nuget packages, it should no longer prompt you to login to vm-dev-01. 

Note: if you change your password to vm-dev-01, you will have to do this again to update the password information.

