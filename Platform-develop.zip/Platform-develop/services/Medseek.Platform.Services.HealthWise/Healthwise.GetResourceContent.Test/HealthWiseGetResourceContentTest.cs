﻿namespace Healthwise.GetResourceContent.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.HealthWise.GetResourceContent;
    using Medseek.Platform.Services.HealthWise.GetResourceContent.Entities;
    using Medseek.Platform.Services.HealthWise.GetResourceContent.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class HealthWiseGetResourceContentTest : TestFixture<HealthWiseGetResourceContentService>
    {
        private const string BaseUrl = "https://ixbapi.healthwise.net";

        private const string ResponseFromHealthWiseApi = "Some Response from HealthWiseAPI";
        private const string ResponseBase64String = "U29tZSBSZXNwb25zZSBmcm9tIEhlYWx0aFdpc2VBUEk=";

        private Mock<IWebClient> webClient;

        private HealthWiseGetResourceContentService service;

        private GetResourceContentRequest request;

        /// <summary>
        /// Sets up before each test executed 
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = new Mock<IWebClient>();
            service = new HealthWiseGetResourceContentService(webClient.Object);

            request = new GetResourceContentRequest
                      {
                          DocumentPath = "10.1/inc/control/healthwise.js",
                          LanguageCode = "en-us",
                          TenantInfo =
                              new Tenant
                              {
                                  Name = "TenantName",
                                  Id = "TenantId",
                                  Settings =
                                      new List<KeySettingsPair>
                                      {
                                          new KeySettingsPair
                                          {
                                              Key
                                                  =
                                                  "healthwise",
                                              Settings
                                                  =
                                                  new Settings
                                                  {
                                                      LicenseKey
                                                          =
                                                          "A4M7EY3QIZRTJNPGLDNF2HR4YEHYK64YR4YCUXLNZ56WCEQE7KXMA2P62VGYN63NZAGOSQ5KHI2N3KE4LHVZU7J34PEAM6AV5DFYDZMY#3.1",
                                                      BaseUrl
                                                          =
                                                          "https://ixbapi.healthwise.net"
                                                  }
                                          }
                                      }
                              },
                      };
        }

        /// <summary>
        /// Test if default constructor executes successfully
        /// </summary>
        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<HealthWiseGetResourceContentService>(service);
        }

        /// <summary>
        /// Test for parameterized constructor throws error when IWebClient object is null
        /// </summary>
        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new HealthWiseGetResourceContentService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for IWebClient called successfully
        /// </summary>
        [Test]
        public void GetResourceContentWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            this.service.GetResourceContent(this.request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for no TenantInfo  throws application exception
        /// </summary>
        [Test]
        public void GetResourceContentNoTenantInformationThrowsApplicationException()
        {
            const string ExceptionMessage = "Tenant '' is not configured for healthwise functionality";
            TestDelegate action = () => service.GetResourceContent(new GetResourceContentRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(ExceptionMessage));
        }

        /// <summary>
        /// Test for application error with correct message if HealthWise Tenant Info is not supplied
        /// </summary>
        [Test]
        public void GetResourceContentNoHealthWiseTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string ExceptionMessage = "Tenant 'TenantId' is not configured for healthwise functionality";

            TestDelegate action =
                () =>
                    service.GetResourceContent(
                        new GetResourceContentRequest
                        {
                            TenantInfo =
                                new Tenant
                                {
                                    Name = "TenantName",
                                    Id = "TenantId",
                                    Settings = new List<KeySettingsPair>()
                                }
                        });

            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(ExceptionMessage));
        }

        /// <summary>
        /// Test for GetResourceContent method should throw an exception if Args not supplied i.e. GetResourceContentRequest
        /// </summary>
        [Test]
        public void GetResourceContentNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetResourceContent(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for Valid web client baseUrl
        /// </summary>
        [Test]
        public void GetResourceContentValidRequestWebClientBaseUrlIsExpected()
        {
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("/resource/10.1/inc/control/healthwise.js")))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetResourceContent(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Request returns Response
        /// </summary>
        [Test]
        public void GetResourceContentRequestReturnsGetResourceContentResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.GetResourceContent(request);
            Assert.IsInstanceOf<GetResourceContentResponse>(response);
        }

        /// <summary>
        /// Test for DocumentPath property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetResourceContentDocumentPathSpecifiedInRequestWebClientQueryStringContainsValue()
        {
            request.DocumentPath = "media/medical/hw/h9991278_001_pi.jpg";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("media/medical/hw/h9991278_001_pi.jpg")))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetResourceContent(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for LanguageCode property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetResourceContentLanguageCodeSpecifiedInRequestWebClientQueryStringContainsValue()
        {
            request.LanguageCode = "es-us";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("lang=es-us")))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetResourceContent(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for LanguageCode property is not supplied in InRequest XML should not contains in Query String Value
        /// </summary>
        [Test]
        public void GetResourceContentLanguageCodeNotSpecifiedInRequestWebClientQueryStringNotContainsValue()
        {
            request.LanguageCode = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains("lang=es-us")))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetResourceContent(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for web client return empty response if <DocumentPath></DocumentPath> is null in request XML
        /// </summary>
        [Test]
        public void GetResourceContentReturnsEmptyResponseIfDocumentPathPropertyIsNull()
        {
            request.DocumentPath = null;
            var response = service.GetResourceContent(request);
            Assert.IsNotNull(response);
            Assert.IsNull(response.ContentItems);
        }

        /// <summary>
        /// Test for web client return empty response if <DocumentPath></DocumentPath> is not present in request XML
        /// </summary>
        [Test]
        public void GetResourceContentReturnsEmptyResponseIfKeywordPropertyIsEmpty()
        {
            request.DocumentPath = string.Empty;
            var response = service.GetResourceContent(request);
            Assert.IsNotNull(response);
            Assert.IsNull(response.ContentItems);
        }

        /// <summary>
        /// Test for Request returns all Response objects with correct values
        /// </summary>
        [Test]
        public void GetResourceContentResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.GetResourceContent(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentType);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.AreEqual(ResponseBase64String, response.ContentItems[0].Content);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

    #region Private Helpers
        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(ResponseFromHealthWiseApi));
            return stream;
           }
        #endregion
    }
}
