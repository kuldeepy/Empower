﻿namespace Healthwise.GetContentListByAlphabet.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.HealthWise.GetContentListByAlphabet;
    using Medseek.Platform.Services.HealthWise.GetContentListByAlphabet.Entities;
    using Medseek.Platform.Services.HealthWise.GetContentListByAlphabet.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    public class HealthwiseGetContentListByAlphabetTest : TestFixture<HealthwiseGetContentListByAlphabetService>
    {
        private const string BaseUrl = "https://ixbapi.healthwise.net";
        private const string XmlString = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                            "<entry>" +
                                                "<title>C Syndrome</title>" +
                                                "<summary/>" +
                                                "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"DocumentLink11\" hreflang=\"en-us\" hw:document-href=\"hn-11\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink12\" hreflang=\"en-us\" hw:document-href=\"hn-12\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink13\" hreflang=\"en-us\" hw:document-href=\"hn-13\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                 "<id>tag:healthwise.org1</id>" +
                                                "<updated>1111-01-01T12:00:00Z</updated>" +
                                            "</entry>" +
                                            "<entry>" +
                                                "<title>C Vitamin</title>" +
                                                "<summary/>" +
                                                "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"DocumentLink21\" hreflang=\"en-us\" hw:document-href=\"hn-21\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink22\" hreflang=\"en-us\" hw:document-href=\"hn-22\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink23\" hreflang=\"en-us\" hw:document-href=\"hn-23\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<id>tag:healthwise.org2</id>" +
                                                "<updated>1111-01-01T12:00:00Z</updated>" +
                                            "</entry>" +
                                         "</feed>";

        private Mock<IWebClient> webClient;
        private HealthwiseGetContentListByAlphabetService service;
        private GetContentListByAlphabetRequest request;

        /// <summary>
        /// Sets up before each test executed 
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = new Mock<IWebClient>();
            service = new HealthwiseGetContentListByAlphabetService(webClient.Object);

            request = new GetContentListByAlphabetRequest()
            {
                ByLetter = "C",
                TenantInfo =
                    new Tenant()
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>()
                                                  {
                                                      new KeySettingsPair()
                                                          {
                                                              Key = "healthwise",
                                                              Settings = new Settings()
                                                                        {
                                                                          LicenseKey = "A4M7EY3QIZRTJNPGLDNF2HR4YEHYK64YR4YCUXLNZ56WCEQE7KXMA2P62VGYN63NZAGOSQ5KHI2N3KE4LHVZU7J34PEAM6AV5DFYDZMY#3",
                                                                          BaseUrl = "https://ixbapi.healthwise.net"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        /// <summary>
        /// Test if default constructor executes successfully
        /// </summary>
        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<HealthwiseGetContentListByAlphabetService>(service);
        }

        /// <summary>
        /// Test for parameterized constructor throws error when IWebClient object is null
        /// </summary>
        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new HealthwiseGetContentListByAlphabetService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for Request returns Response
        /// </summary>
        [Test]
        public void GetContentListByAlphabetRequestReturnsGetContentListByAlphabetResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.GetContentListByAlphabet(request);
            Assert.IsInstanceOf<GetContentListByAlphabetResponse>(response);
        }

        /// <summary>
        /// Test for Request returns all Response objects
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_AllObjectsReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.GetContentListByAlphabet(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
        }

        /// <summary>
        /// Test for Request returns all Response objects with correct values
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_ResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.GetContentListByAlphabet(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual("hn-11", response.ContentItems[0].ContentId);
            Assert.AreEqual("C Syndrome", response.ContentItems[0].Title);
            Assert.AreEqual(string.Empty, response.ContentItems[0].Description);
            Assert.AreEqual("DocumentLink11", response.ContentItems[0].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", response.ContentItems[0].PostingDate);
            Assert.AreEqual("en-us", response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);

            Assert.AreEqual("hn-21", response.ContentItems[1].ContentId);
            Assert.AreEqual("C Vitamin", response.ContentItems[1].Title);
            Assert.AreEqual(string.Empty, response.ContentItems[1].Description);
            Assert.AreEqual("DocumentLink21", response.ContentItems[1].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", response.ContentItems[1].PostingDate);
            Assert.AreEqual("en-us", response.ContentItems[1].Language);
            Assert.AreEqual("healthwise", response.ContentItems[1].Source);
        }

        /// <summary>
        /// Test for IWebClient called successfully
        /// </summary>
        [Test]
        public void GetContentListByAlphabetWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            var response = service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentListByAlphabetNoTenantInformationThrowsApplicationException()
        {
            const string exceptionMessage = "Tenant '' is not configured for Healthwise functionality";
            TestDelegate action = () => service.GetContentListByAlphabet(new GetContentListByAlphabetRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetContentListByAlphabetNoHealthWiseTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string ExceptionMessage = "Tenant 'TenantId' is not configured for Healthwise functionality";

            TestDelegate action = () => service.GetContentListByAlphabet(new GetContentListByAlphabetRequest
            {
                TenantInfo = new Tenant
                {
                    Name = "TenantName",
                    Id = "TenantId",
                    Settings = new List<KeySettingsPair>()
                }
            });

            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(ExceptionMessage));
        }

        /// <summary>
        /// Test for GetContentListByAlphabet method should throw an exception if Args not supplied i.e. GetContentListByAlphabetRequest
        /// </summary>
        [Test]
        public void GetContentListByAlphabetNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetContentListByAlphabet(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for application error if Tenant Info is not supplied or null
        /// </summary>
        [Test]
        public void GetContentListByAlphabetNoHealthWiseTenantInformationThrowsApplicationException()
        {
            TestDelegate action = () => service.GetContentListByAlphabet(new GetContentListByAlphabetRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        /// <summary>
        /// Test for Valid web client baseUrl
        /// </summary>
        [Test]
        public void GetContentListByAlphabetValidRequestWebClientBaseUrlIsExpected()
        {
            var expectedUrl = string.Format(BaseUrl + "{0}", "/Metadata");
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Substring(0, a.IndexOf('?')) == expectedUrl))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for null values for attribute missing in response XML element
        /// </summary>
        [Test]
        public void GetContentListByAlphabetResponseContainsNullValueForAttributesMissingInElement()
        {
            string res = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                            "<entry>" +
                                                "<title>C Syndrome</title>" +
                                                "<summary/>" +
                                                "<link rel=\"alternate\" type=\"application/atom+xml\"  hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                 "<id>tag:healthwise.org1</id>" +
                                                "<updated>1111-01-01T12:00:00Z</updated>" +
                                            "</entry>" +
                                            "</feed>";
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(res)));
            var response = service.GetContentListByAlphabet(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].Link);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        /// <summary>
        /// Test for web client return empty response element
        /// </summary>
        [Test]
        public void GetContentListByAlphabetResponseContainsNullValueIfAttribitesInResponseElementContainsNullValue()
        {
            string res = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                            "<entry>" +
                                            "</entry>" +
                                            "</feed>";
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(res)));
            var response = service.GetContentListByAlphabet(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }
        
        /// <summary>
        /// Test for web client return empty response if <ByLetter></ByLetter> is null in request XML
        /// </summary>
        [Test]
        public void GetContentListByAlphabetReturnsEmptyResponseIfByLetterPropertyIsNull()
        {
            request.ByLetter = null; 
            var response = service.GetContentListByAlphabet(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        /// <summary>
        /// Test for web client return empty response if ByLetter is not present in request XML
        /// </summary>
        [Test]
        public void GetContentListByAlphabetReturnsEmptyResponseIfByLetterPropertyIsEmpty()
        {
            request.ByLetter = string.Empty;
            var response = service.GetContentListByAlphabet(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        /// <summary>
        /// Test for ByLetter property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_ByLetterSpecifiedInRequest_WebClientQueryStringContainsValue()
        {
            request.ByLetter = "a";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("mainsearchcriteria.v.c0=a")))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for EffectiveTime property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_EffectiveTimeSpecifiedInRequest_WebClientQueryStringContainsValue()
        {
            request.EffectiveTime = "20081010";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("knowledgeRequestNotification.effectiveTime.v=20081010")))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for EffectiveTime property is not supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_EffectiveTimeNotSpecifiedInRequest_WebClientQueryStringContainsDefaultValue()
        {
            request.EffectiveTime = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("knowledgeRequestNotification.effectiveTime.v=00010101")))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        #region Private Helpers
        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
        #endregion
    }
}
