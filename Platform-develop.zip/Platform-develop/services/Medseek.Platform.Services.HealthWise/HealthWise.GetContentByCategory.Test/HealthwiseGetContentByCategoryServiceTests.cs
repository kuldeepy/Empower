﻿namespace HealthWise.GetContentByCategory.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.HealthWise.GetContentByCategory;
    using Medseek.Platform.Services.HealthWise.GetContentByCategory.Entities;
    using Medseek.Platform.Services.HealthWise.GetContentByCategory.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;
    
    public class HealthwiseGetContentByCategoryServiceTests : TestFixture<HealthwiseGetContentByCategoryService>
    {
        private const string HealthwiseApplicationKey = "A4M7EY3QIZRTJNPGLDNF2HR4YEHYK64YR4YCUXLNZ56WCEQE7KXMA2P62VGYN63NZAGOSQ5KHI2N3KE4LHVZU7J34PEAM6AV5DFYDZMY";
        private const string GetContentByCategoryUrl = "https://ixbapi.healthwise.net/Metadata?{0}&hw.key={1}";
        private const string XmlString = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                           "<entry>" +
                                               "<title>Allergic Reaction</title>" +
                                               "<summary/>" +
                                               "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"DocumentLink11\" hreflang=\"en-us\" hw:document-href=\"hn-11\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink12\" hreflang=\"en-us\" hw:document-href=\"hn-12\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink13\" hreflang=\"en-us\" hw:document-href=\"hn-13\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<id>tag:healthwise.org1</id>" +
                                               "<updated>1111-01-01T12:00:00Z</updated>" +
                                           "</entry>" +
                                           "<entry>" +
                                               "<title>Allergic Rhinitis</title>" +
                                               "<summary/>" +
                                               "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"DocumentLink21\" hreflang=\"en-us\" hw:document-href=\"hn-21\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink22\" hreflang=\"en-us\" hw:document-href=\"hn-22\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink23\" hreflang=\"en-us\" hw:document-href=\"hn-23\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<id>tag:healthwise.org2</id>" +
                                               "<updated>1111-01-01T12:00:00Z</updated>" +
                                           "</entry>" +
                                        "</feed>";

        private Mock<IWebClient> webClient;
        private HealthwiseGetContentByCategoryService service;
        private GetContentByCategoryRequest request;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            service = new HealthwiseGetContentByCategoryService(webClient.Object);
            request = new GetContentByCategoryRequest
            {
                Category = new Category
                {
                    Id = "CategoryId",
                    Name = "Allergies",
                    Source = "healthwise"
                },
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                                                  {
                                                      new KeySettingsPair
                                                          {
                                                              Key = "healthwise",
                                                              Settings = new Settings
                                                                        {
                                                                          LicenseKey = HealthwiseApplicationKey,
                                                                          BaseUrl = "https://ixbapi.healthwise.net"
                                                                        }
                                                          }
                                                  }
                    }
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            service = new HealthwiseGetContentByCategoryService(webClient.Object);

            Assert.IsNotNull(service);
            Assert.IsInstanceOf<HealthwiseGetContentByCategoryService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new HealthwiseGetContentByCategoryService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: webClient"));
        }

        [Test]
        public void GetContentByCategoryNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetContentByCategory(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: inRequest"));
        }

        [Test]
        public void GetContentByCategoryNoCategoryThrowsArgumentException()
        {
            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>().And.Message.Contains("Request must contain Category."));
        }

        [Test]
        public void GetContentByCategoryCategoryNameEmptyThrowsArgumentException()
        {
            request.Category.Name = string.Empty;
            TestDelegate action = () => service.GetContentByCategory(request);
            Assert.That(action, Throws.InstanceOf<ArgumentException>().And.Message.Contains("Request must contain Category."));
        }

        [Test]
        public void GetContentByCategoryCategoryNameNotSpecifiedInRequestThrowsArgumentException()
        {
            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest
            {
                Category = new Category
                {
                    Id = "100",
                    Source = "healthwise"
                }
            });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetContentByCategoryNoTenantInformationThrowsApplicationException()
        {
            const string exceptionMessage = "Tenant '' is not configured for HealthWise functionality";

            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest
            {
                Category = new Category
                {
                    Id = "CategoryId",
                    Name = "Allergies",
                    Source = "healthwise"
                }
            });
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetContentByCategoryNoHealthWiseTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string exceptionMessage = "Tenant 'TenantId' is not configured for HealthWise functionality";

            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest
            {
                Category = new Category
                {
                    Id = "CategoryId",
                    Name = "Allergies",
                    Source = "healthwise"
                },
                TenantInfo = new Tenant
                {
                    Name = "TenantName",
                    Id = "TenantId",
                    Settings = new List<KeySettingsPair>()
                }
            });

            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetContentByCategoryReturnsGetContentByCategoryResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.GetContentByCategory(request);
            Assert.IsInstanceOf<GetContentByCategoryResponse>(response);
        }

        [Test]
        public void GetContentByCategoryWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategoryValidRequestWebClientUrlIsCorrect()
        {
            var expectedUrl = string.Format(GetContentByCategoryUrl, "mainsearchcriteria.v.cs0=2.16.840.1.113883.3.342.1.101&mainsearchcriteria.v.c0=Allergies", HealthwiseApplicationKey);
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategoryCategoryNameSpecifiedInRequestWebClientQueryStringContainsCategoryName()
        {
            request.Category.Name = "Allergies";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("mainsearchcriteria.v.c0=Allergies")))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategoryAllObjectsReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.GetContentByCategory(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
        }

        [Test]
        public void GetContentByCategoryResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.GetContentByCategory(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual("hn-11", response.ContentItems[0].ContentId);
            Assert.AreEqual("Allergic Reaction", response.ContentItems[0].Title);
            Assert.AreEqual(string.Empty, response.ContentItems[0].Description);
            Assert.AreEqual("DocumentLink11", response.ContentItems[0].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", response.ContentItems[0].PostingDate);
            Assert.AreEqual("en-us", response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);

            Assert.AreEqual("hn-21", response.ContentItems[1].ContentId);
            Assert.AreEqual("Allergic Rhinitis", response.ContentItems[1].Title);
            Assert.AreEqual(string.Empty, response.ContentItems[1].Description);
            Assert.AreEqual("DocumentLink21", response.ContentItems[1].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", response.ContentItems[1].PostingDate);
            Assert.AreEqual("en-us", response.ContentItems[1].Language);
            Assert.AreEqual("healthwise", response.ContentItems[1].Source);
        }

        [Test]
        public void GetContentByCategoryResponseContainsNullValueForAttributesMissingInElement()
        {
            const string result = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                  "<entry>" +
                                  "<title>Allergies</title>" +
                                  "<summary/>" +
                                  "<link rel=\"alternate\" type=\"application/atom+xml\"  hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                  "<id>tag:healthwise.org1</id>" +
                                  "<updated>1111-01-01T12:00:00Z</updated>" +
                                  "</entry>" +
                                  "</feed>";

            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(result)));
            var response = service.GetContentByCategory(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].Link);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        [Test]
        public void GetContentByCategoryResponseContainsNullValueIfAttribitesInResponseElementContainsNullValue()
        {
            const string result = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                  "<entry>" +
                                  "</entry>" +
                                  "</feed>";
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(result)));
            var response = service.GetContentByCategory(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        private static Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
    }
}
