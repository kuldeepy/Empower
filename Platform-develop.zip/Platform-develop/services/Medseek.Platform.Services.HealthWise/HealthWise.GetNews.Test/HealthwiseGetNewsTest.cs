﻿namespace HealthWise.GetNews.Test
{
    using System;

    using Medseek.Platform.Services.HealthWise.GetNews;
    using Medseek.Platform.Services.HealthWise.GetNews.Entities;
    using Medseek.Util.Testing;

    using NUnit.Framework;

    [TestFixture]
    public sealed class HealthwiseGetNewsTest : TestFixture<HealthwiseGetNewsService>
    {
        private GetNewsRequest request;
        private HealthwiseGetNewsService service;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            service = new HealthwiseGetNewsService();

            request = new GetNewsRequest();
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<HealthwiseGetNewsService>(service);
        }

        [Test]
        public void GetNewsReturnsGetNewsResponse()
        {
            var response = service.GetNews(request);
            Assert.IsInstanceOf<GetNewsResponse>(response);
        }

        [Test]
        public void GetNewsNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetNews(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }
        
        [Test]
        public void GetNewsEmptyResponse()
        {
            var response = service.GetNews(request);
            Assert.IsNotNull(response);
        }
    }
}
