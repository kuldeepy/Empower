﻿namespace HealthWise.GetCategories.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.HealthWise.GetCategories;
    using Medseek.Platform.Services.HealthWise.GetCategories.Entities;
    using Medseek.Platform.Services.HealthWise.GetCategories.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class HealthwiseGetCategoriesTests : TestFixture<HealthwiseGetCategoriesService>
    {
        private const string GetCategoriesUrl = "https://ixbapi.healthwise.net/{0}/Category?{1}&hw.key={2}";
        private const string HealthwiseApplicationKey = "A4M7EY3QIZRTJNPGLDNF2HR4YEHYK64YR4YCUXLNZ56WCEQE7KXMA2P62VGYN63NZAGOSQ5KHI2N3KE4LHVZU7J34PEAM6AV5DFYDZMY";
        private const string ResponseXml =
            @"<items><item categoryId='cat1001' centerId='center1001'>Allergies</item><item categoryId='cat1042' centerId='center1042'>Asthma</item><item categoryId='cat1002' centerId='center1002'>Back and Neck Pain</item></items>";
        private Mock<IWebClient> webClient;
        private HealthwiseGetCategoriesService service;
        private GetCategoriesRequest request;

         //<summary>
         //Sets up before each test is executed.
         //</summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            service = new HealthwiseGetCategoriesService(webClient.Object);
            request = new GetCategoriesRequest
                {
                    TenantInfo =
                                  new Tenant
                                  {
                                      Name = "TenantName",
                                      Id = "TenantId",
                                      Settings =
                                          new List<KeySettingsPair>
                                                  {
                                                      new KeySettingsPair
                                                          {
                                                              Key = "healthwise",
                                                              Settings = new Settings
                                                                        {
                                                                          LicenseKey = HealthwiseApplicationKey,
                                                                          BaseUrl = "https://ixbapi.healthwise.net"
                                                                        }
                                                          }
                                                  }
                                  }
                };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            service = new HealthwiseGetCategoriesService(webClient.Object);

            Assert.IsNotNull(service);
            Assert.IsInstanceOf<HealthwiseGetCategoriesService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new HealthwiseGetCategoriesService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: webClient"));
        }

        [Test]
        public void GetCategoriesNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetCategories(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: inRequest"));
        }

        [Test]
        public void GetCategoriesNoTenantInformationThrowsApplicationException()
        {
            const string exceptionMessage = "Tenant '' is not configured for HealthWise functionality";

            TestDelegate action = () => service.GetCategories(new GetCategoriesRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetCategoriesNoHealthwiseTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string exceptionMessage = "Tenant 'TenantId' is not configured for HealthWise functionality";

            TestDelegate action = () => service.GetCategories(new GetCategoriesRequest
                {
                    TenantInfo = new Tenant
                            {
                                Name = "TenantName",
                                Id = "TenantId",
                                Settings = new List<KeySettingsPair>()
                            }
                });

            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetCategoriesWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream()).Verifiable();
            service.GetCategories(request);
            webClient.Verify();
        }

        [Test]
        public void GetCategoriesValidRequestWebClientUrlIsCorrect()
        {
            var expectedUrl = string.Format(GetCategoriesUrl, "healthwise", string.Empty, HealthwiseApplicationKey);
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.GetCategories(request);
            webClient.Verify();
        }

        [Test]
        public void GetCategoriesWithLanguageValidRequestWebClientUrlIsCorrect()
        {
            var expectedUrl = string.Format(GetCategoriesUrl, "healthwise", "lang=en-us", HealthwiseApplicationKey);
            request.LanguageCode = "en-us";
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.GetCategories(request);
            webClient.Verify();
        }

        [Test]
        public void GetCategoriesAllCategoriesReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.GetCategories(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Categories);
            Assert.AreEqual(3, response.Categories.Count);
        }

        [Test]
        public void GetCategoriesResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            
            var response = service.GetCategories(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Categories);
            Assert.AreEqual("cat1001", response.Categories[0].Id);
            Assert.AreEqual("Allergies", response.Categories[0].Name);
            Assert.AreEqual("healthwise", response.Categories[0].Source);

            Assert.AreEqual("cat1042", response.Categories[1].Id);
            Assert.AreEqual("Asthma", response.Categories[1].Name);
            Assert.AreEqual("healthwise", response.Categories[1].Source);

            Assert.AreEqual("cat1002", response.Categories[2].Id);
            Assert.AreEqual("Back and Neck Pain", response.Categories[2].Name);
            Assert.AreEqual("healthwise", response.Categories[2].Source);             
        }

        [Test]
        public void GetCategoriesWithLanguageResponseObjectPopulatedCorrectly()
        {
            request.LanguageCode = "es-us";
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());

            var response = service.GetCategories(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Categories);
            Assert.AreEqual("cat1001", response.Categories[0].Id);
            Assert.AreEqual("Allergies", response.Categories[0].Name);
            Assert.AreEqual("healthwise", response.Categories[0].Source);

            Assert.AreEqual("cat1042", response.Categories[1].Id);
            Assert.AreEqual("Asthma", response.Categories[1].Name);
            Assert.AreEqual("healthwise", response.Categories[1].Source);

            Assert.AreEqual("cat1002", response.Categories[2].Id);
            Assert.AreEqual("Back and Neck Pain", response.Categories[2].Name);
            Assert.AreEqual("healthwise", response.Categories[2].Source);
        }

        [Test]
        public void GetCategoriesReturnsGetCategoriesResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.GetCategories(request);
            Assert.IsInstanceOf<GetCategoriesResponse>(response);
        }

        private static Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(ResponseXml));
            return stream;
        }
    }
}
