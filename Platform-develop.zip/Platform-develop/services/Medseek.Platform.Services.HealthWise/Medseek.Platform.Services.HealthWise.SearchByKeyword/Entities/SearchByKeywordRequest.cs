﻿namespace Medseek.Platform.Services.HealthWise.SearchByKeyword.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class SearchByKeywordRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string Keyword { get; set; }

        [DataMember]
        public Age Age { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
