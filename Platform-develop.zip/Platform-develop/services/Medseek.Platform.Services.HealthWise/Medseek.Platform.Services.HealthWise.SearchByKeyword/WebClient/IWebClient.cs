﻿namespace Medseek.Platform.Services.HealthWise.SearchByKeyword.WebClient
{
    using System.IO;

    /// <summary>
    /// Interface for types that provide the ability to interact with web 
    /// resources.
    /// </summary>
    public interface IWebClient
    {
        /// <summary>
        /// Opens a web resource.
        /// </summary>
        /// <param name="uri">
        /// The location of the web resource.
        /// </param>
        /// <returns>
        /// A stream that can be used to read from the resource.
        /// </returns>
        Stream OpenRead(string uri);
    }
}