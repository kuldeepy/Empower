﻿namespace Medseek.Platform.Services.HealthWise.SearchByCode
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Web;
    using System.Xml.Linq;
    using Medseek.Platform.Services.HealthWise.SearchByCode.Entities;
    using Medseek.Platform.Services.HealthWise.SearchByCode.WebClient;
    using Medseek.Util.MicroServices;
    using ConfigurationManager = System.Configuration.ConfigurationManager;

    [RegisterMicroService]
    public class SearchByCodeService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.SearchByCode.HealthWise";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.searchbycode.healthwise";

        private const string HealthwiseSettingsKey = "healthwise";
        private const string SearchContentUrl = "{0}/Metadata?{1}&hw.key={2}";
        private const string Xmlns = "http://www.w3.org/2005/Atom";
        private const string XmlnsHw = "http://www.healthwise.org/2009/DocumentInfo";
        private const string PageSize = "PageSize";

        private readonly IWebClient webClient;
        private static string pageSize;
        

        /// <summary>
        /// Initializes a new instance of the <see cref="SearchByCodeService"/> class.
        /// </summary>
        /// <param name="webClient">An instance of <see cref="IWebClient"/>.</param>
        /// <exception cref="System.ArgumentNullException">web Client</exception>
        public SearchByCodeService(IWebClient webClient)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }
            
            this.webClient = webClient;
            pageSize = ConfigurationManager.AppSettings.Get(PageSize);
        }

        /// <summary>
        /// SearchByCode (ICD9,CPT etc)
        /// </summary>
        /// <param name="inRequest">The <see cref="SearchByCodeRequest"/>.</param>
        /// <returns>The <see cref="SearchByCodeResponse"/>.</returns>
        /// <exception cref="System.ArgumentNullException">The inRequest</exception>
        /// <exception cref="System.ApplicationException">Tenant is not configured for HealthWise functionality</exception>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public SearchByCodeResponse SearchByCode(SearchByCodeRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var hwsettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any()) ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == HealthwiseSettingsKey) : null;

            if (hwsettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for HealthWise functionality", tenantId));
            }

            var xmlRequest = HttpUtility.UrlEncode(BuildSearchByCodeRequest(inRequest));

            var url = string.Format(SearchContentUrl, hwsettings.Settings.BaseUrl, xmlRequest, hwsettings.Settings.LicenseKey);

            using (var response = webClient.OpenRead(HttpUtility.UrlDecode(url)))
            {
                return BuildSearchByCodeResponse(response);
            }
        }

        #region private methods

        private static string BuildSearchByCodeRequest(SearchByCodeRequest inRequest)
        {
            var sb = new StringBuilder();

            int maxCount;
            maxCount = Int32.TryParse(pageSize, out maxCount) ? Int32.Parse(pageSize) : 150;
            sb.Append(String.Format("mainsearchcriteria.v.cs0={0}", inRequest.CodeSystemId));

            sb.Append(string.Format("&mainsearchcriteria.v.c0={0}", inRequest.Code));
            
            if (!string.IsNullOrEmpty(inRequest.Gender))
            {
                sb.Append(string.Format("&patientPerson.administrativegendercode.dn={0}", inRequest.Gender));
            }
            if (!string.IsNullOrEmpty(inRequest.LanguageCode))
            {
                sb.Append(string.Format("&lang={0}", inRequest.LanguageCode));
            }
            if (inRequest.Age != null)
            {
                sb.Append(string.Format("&age.v.v={0}", inRequest.Age.Years));
            }

            sb.Append(string.Format("&hw.results.max={0}", maxCount));

            return sb.ToString();
        }

        private static SearchByCodeResponse BuildSearchByCodeResponse(Stream response)
        {
            var codeResponse = new SearchByCodeResponse { ContentItems = new List<ContentItem>() };
            var xmlDoc = XElement.Load(response);

            codeResponse.ContentItems = xmlDoc.Descendants((XNamespace)Xmlns + "entry").Select(BuildContentItem).ToList();

            return codeResponse;
        }

        private static ContentItem BuildContentItem(XElement entry)
        {
            return new ContentItem
            {
                Title = GetValue(entry, "title"),
                Description = GetValue(entry, "summary"),
                PostingDate = GetValue(entry, "updated"),
                Link = GetValue(entry, "link", "href"),
                ContentId = GetValue(entry, "link", "document-href"),
                Language = GetValue(entry, "link", "hreflang"),
                Source = "healthwise"
            };
        }

        private static string GetValue(XElement xmlElement, string elementName, string attributeName = null)
        {
            var element = xmlElement;


            if (!string.IsNullOrWhiteSpace(elementName))
            {
                element = xmlElement.Element((XNamespace)Xmlns + elementName);
                if (element == null)
                {
                    return null;
                }
            }

            if (string.IsNullOrWhiteSpace(attributeName))
            {
                return element.Value;
            }

            var attribute = element.Attribute(attributeName) ?? element.Attribute((XNamespace)XmlnsHw + attributeName);

            return attribute != null ? attribute.Value : null;
        }

        #endregion
    }
}
