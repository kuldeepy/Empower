﻿namespace HealthWise.SearchByKeyword.Test
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.HealthWise.SearchByKeyword;
    using Medseek.Platform.Services.HealthWise.SearchByKeyword.Entities;
    using Medseek.Platform.Services.HealthWise.SearchByKeyword.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class HealthWiseSearchByKeywordTests : TestFixture<HealthWiseSearchByKeywordService>
    {
        private const string BaseUrl = "https://ixbapi.healthwise.net";
        private const string XmlString = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                            "<entry>" +
                                                "<title>Asthma</title>" +
                                                "<summary>Provides links to how-to information about asthma.</summary>" +
                                                "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"Link1\" hreflang=\"en-us\" hw:document-href=\"center1042\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink12\" hreflang=\"en-us\" hw:document-href=\"hn-12\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink13\" hreflang=\"en-us\" hw:document-href=\"hn-13\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                 "<id>tag:healthwise.org1</id>" +
                                                "<updated>1111-01-01T12:00:00Z</updated>" +
                                            "</entry>" +
                                            "<entry>" +
                                                "<title>Asthma and Wheezing</title>" +
                                                "<summary>Wheezing is often present in asthma</summary>" +
                                                "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"Link2\" hreflang=\"en-us\" hw:document-href=\"aa126708\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink22\" hreflang=\"en-us\" hw:document-href=\"hn-22\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink23\" hreflang=\"en-us\" hw:document-href=\"hn-23\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<id>tag:healthwise.org2</id>" +
                                                "<updated>1111-01-01T12:00:00Z</updated>" +
                                            "</entry>" +
                                         "</feed>";

        private Mock<IWebClient> webClient;
        private HealthWiseSearchByKeywordService service;
        private SearchByKeywordRequest request;
       
        /// <summary>
        /// Sets up before each test executed 
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = new Mock<IWebClient>();
            service = new HealthWiseSearchByKeywordService(webClient.Object);

            request = new SearchByKeywordRequest
            {
                Keyword = "asthma",
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair> 
                            {
                                                      new KeySettingsPair 
                                                      {
                                                              Key = "healthwise",
                                                              Settings = new Settings 
                                                              {
                                                                          LicenseKey = "A4M7EY3QIZRTJNPGLDNF2HR4YEHYK64YR4YCUXLNZ56WCEQE7KXMA2P62VGYN63NZAGOSQ5KHI2N3KE4LHVZU7J34PEAM6AV5DFYDZMY#3.1",
                                                                          BaseUrl = "https://ixbapi.healthwise.net"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        /// <summary>
        /// Test if default constructor executes successfully
        /// </summary>
        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<HealthWiseSearchByKeywordService>(service);
        }

        /// <summary>
        /// Test for parameterized constructor throws error when IWebClient object is null
        /// </summary>
        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new HealthWiseSearchByKeywordService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for IWebClient called successfully
        /// </summary>
        [Test]
        public void SearchByKeywordWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            this.service.SearchByKeyword(this.request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for no TenantInfo  throws application exception
        /// </summary>
        [Test]
        public void SearchByKeywordNoTenantInformationThrowsApplicationException()
        {
            const string ExceptionMessage = "Tenant '' is not configured for HealthWise functionality";
            TestDelegate action = () => service.SearchByKeyword(new SearchByKeywordRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(ExceptionMessage));
        }

        /// <summary>
        /// Test for application error with correct message if HealthWise Tenant Info is not supplied
        /// </summary>
        [Test]
        public void SearchByKeywordNoHealthWiseTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string ExceptionMessage = "Tenant 'TenantId' is not configured for HealthWise functionality";

            TestDelegate action = () => service.SearchByKeyword(new SearchByKeywordRequest
            {
                TenantInfo = new Tenant
                {
                    Name = "TenantName",
                    Id = "TenantId",
                    Settings = new List<KeySettingsPair>()
                }
            });

            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(ExceptionMessage));
        }

        /// <summary>
        /// Test for SearchByKeyword method should throw an exception if Args not supplied i.e. SearchByKeywordRequest
        /// </summary>
        [Test]
        public void SearchByKeywordNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.SearchByKeyword(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for Valid web client baseUrl
        /// </summary>
        [Test]
        public void SearchByKeywordValidRequestWebClientBaseUrlIsExpected()
        {
            var expectedUrl = string.Format(BaseUrl + "{0}", "/Metadata");
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Substring(0, a.IndexOf('?')) == expectedUrl))).Returns(this.BuildResponseStream()).Verifiable();
            service.SearchByKeyword(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Request returns Response
        /// </summary>
        [Test]
        public void SearchByKeywordRequestReturnsSearchByKeywordResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.IsInstanceOf<SearchByKeywordResponse>(response);
        }

        /// <summary>
        /// Test for Request returns all Response objects
        /// </summary>
        [Test]
        public void SearchByKeywordAllObjectsReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
        }

        /// <summary>
        /// Test for Request returns all Response objects with correct values
        /// </summary>
        [Test]
        public void SearchByKeywordResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentType);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].Content);
            Assert.AreEqual("center1042", response.ContentItems[0].ContentId);
            Assert.AreEqual("Asthma", response.ContentItems[0].Title);
            Assert.AreEqual("Provides links to how-to information about asthma.", response.ContentItems[0].Description);
            Assert.AreEqual("Link1", response.ContentItems[0].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", response.ContentItems[0].PostingDate);
            Assert.AreEqual("en-us", response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);

            Assert.IsNullOrEmpty(response.ContentItems[1].ContentType);
            Assert.IsNullOrEmpty(response.ContentItems[1].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[1].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[1].Content);
            Assert.AreEqual("aa126708", response.ContentItems[1].ContentId);
            Assert.AreEqual("Asthma and Wheezing", response.ContentItems[1].Title);
            Assert.AreEqual("Wheezing is often present in asthma", response.ContentItems[1].Description);
            Assert.AreEqual("Link2", response.ContentItems[1].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", response.ContentItems[1].PostingDate);
            Assert.AreEqual("en-us", response.ContentItems[1].Language);
            Assert.AreEqual("healthwise", response.ContentItems[1].Source);
        }

        /// <summary>
        /// Test for null values for attribute missing in response XML element
        /// </summary>
        [Test]
        public void SearchByKeywordResponseContainsNullValueForAttributesMissingInElement()
        {
            const string ResponseXml = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                            "<entry>" +
                                                "<title>Asthma</title>" +
                                                "<summary>Provides links to how-to information about asthma.</summary>" +
                                                "<link rel=\"alternate\" type=\"application/atom+xml\"  hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                 "<id>tag:healthwise.org1</id>" +
                                                "<updated>1111-01-01T12:00:00Z</updated>" +
                                            "</entry>" +
                                            "</feed>";
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(ResponseXml)));
            var response = service.SearchByKeyword(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].Link);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        /// <summary>
        /// Test for web client return empty response element
        /// </summary>
        [Test]
        public void SearchByKeywordResponseContainsNullValueIfResponseElementIsEmpty()
        {
            const string ResponseXml = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                               "<entry>" +
                               "</entry>" +
                               "</feed>";
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(ResponseXml)));
            var response = service.SearchByKeyword(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        /// <summary>
        /// Test for web client return empty response if <Keyword></Keyword> is null in request XML
        /// </summary>
        [Test]
        public void SearchByKeywordReturnsEmptyResponseIfKeywordPropertyIsNull()
        {
            request.Keyword = null;
            var response = service.SearchByKeyword(request);
            Assert.IsNotNull(response);
            Assert.IsNull(response.ContentItems);
        }

        /// <summary>
        /// Test for web client return empty response if Keyword is not present in request XML
        /// </summary>
        [Test]
        public void SearchByKeywordReturnsEmptyResponseIfKeywordPropertyIsEmpty()
        {
            request.Keyword = string.Empty;
            var response = service.SearchByKeyword(request);
            Assert.IsNotNull(response);
            Assert.IsNull(response.ContentItems);
        }

        /// <summary>
        /// Test for Keyword property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void SearchByKeywordKeywordSpecifiedInRequestWebClientQueryStringContainsValue()
        {
            request.Keyword = "asthma";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("mainsearchcriteria.v.dn0=asthma")))).Returns(this.BuildResponseStream()).Verifiable();
            service.SearchByKeyword(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for LanguageCode property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void SearchByKeywordLanguageCodeSpecifiedInRequestWebClientQueryStringContainsValue()
        {
            request.LanguageCode = "en-us";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("lang=en-us")))).Returns(this.BuildResponseStream()).Verifiable();
            service.SearchByKeyword(request);
            webClient.Verify();
        }

       [Test]
        public void SearchByKeywordPageSizeNotSpecifiedInRequestWebClientQueryStringContainDefaultPageSize()
        {
            ConfigurationManager.AppSettings.Set("PageSize", "");
            service = new HealthWiseSearchByKeywordService(webClient.Object);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("&hw.results.max=150")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByKeyword(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByKeywordPageSizeSpecifiedInRequestWebClientQueryStringContainSpecifiedPageSize()
        {
            ConfigurationManager.AppSettings.Set("PageSize", "100");
            service = new HealthWiseSearchByKeywordService(webClient.Object);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("&hw.results.max=100")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByKeyword(request);
            webClient.Verify();
        }

        #region Private Helpers
        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
        #endregion
    }
}
