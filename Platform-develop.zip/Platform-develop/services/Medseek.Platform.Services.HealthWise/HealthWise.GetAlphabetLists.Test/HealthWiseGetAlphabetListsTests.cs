﻿namespace HealthWise.GetAlphabetLists.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.HealthWise.GetAlphabetLists;
    using Medseek.Platform.Services.HealthWise.GetAlphabetLists.Entities;
    using Medseek.Platform.Services.HealthWise.GetAlphabetLists.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class HealthWiseGetAlphabetListsTests : TestFixture<HealthwiseGetAlphabetListsService>
    {
        private const string HealthwiseApplicationKey = "A4M7EY3QIZRTJNPGLDNF2HR4YEHYK64YR4YCUXLNZ56WCEQE7KXMA2P62VGYN63NZAGOSQ5KHI2N3KE4LHVZU7J34PEAM6AV5DFYDZMY";
        private const string GetAlphabetListsUrl = "https://ixbapi.healthwise.net/healthwise/list?hw.key={0}";
        private const string ResponseXml =
        "<items><item letter='_'/><item letter='a'/><item letter='b'/><item letter='c'/><item letter='d'/><item letter='e'/><item letter='f'/><item letter='g'/><item letter='h'/><item letter='i'/><item letter='j'/><item letter='k'/><item letter='l'/><item letter='m'/><item letter='n'/><item letter='o'/><item letter='p'/><item letter='q'/><item letter='r'/><item letter='s'/><item letter='t'/><item letter='u'/><item letter='v'/><item letter='w'/><item letter='x'/><item letter='y'/><item letter='z'/></items>";
        
        private GetAlphabetListsRequest request;
        private HealthwiseGetAlphabetListsService service;
        private Mock<IWebClient> webClient;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            service = new HealthwiseGetAlphabetListsService(webClient.Object);
            request = new GetAlphabetListsRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                            {
                                                      new KeySettingsPair
                                                      {
                                                              Key = "healthwise",
                                                              Settings = new Settings
                                                              {
                                                                          LicenseKey = HealthwiseApplicationKey,
                                                                          BaseUrl = "https://ixbapi.healthwise.net"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            service = new HealthwiseGetAlphabetListsService(webClient.Object);

            Assert.IsNotNull(service);
            Assert.IsInstanceOf<HealthwiseGetAlphabetListsService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new HealthwiseGetAlphabetListsService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: webClient"));
        }

        [Test]
        public void GetAlphabetListsNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetAlphabetLists(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: inRequest"));
        }

        [Test]
        public void GetAlphabetListsNoTenantInformationThrowsApplicationException()
        {
            const string exceptionMessage = "Tenant '' is not configured for HealthWise functionality";

            TestDelegate action = () => service.GetAlphabetLists(new GetAlphabetListsRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetAlphabetListNoHealthWiseTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string exceptionMessage = "Tenant 'TenantId' is not configured for HealthWise functionality";

            TestDelegate action = () => service.GetAlphabetLists(new GetAlphabetListsRequest
            {
                TenantInfo = new Tenant
                {
                    Name = "TenantName",
                    Id = "TenantId",
                    Settings = new List<KeySettingsPair>()
                }
            });

            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetAlphabetListWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream(ResponseXml)).Verifiable();
            service.GetAlphabetLists(request);
            webClient.Verify();
        }

        [Test]
        public void GetAlphabetListValidRequestWebClientUrlIsCorrect()
        {
            var expectedUrl = string.Format(GetAlphabetListsUrl, HealthwiseApplicationKey);
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream(ResponseXml)).Verifiable();
            service.GetAlphabetLists(request);
            webClient.Verify();
        }

        [Test]
        public void GetAlphabetListAllAlphabetsReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream(ResponseXml));
            var response = service.GetAlphabetLists(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Alphabets);
            Assert.AreEqual(27, response.Alphabets.Count);
        }

        [Test]
        public void GetAlphabetListNoAlphabetsReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream("<items><item /></items>"));
            var response = service.GetAlphabetLists(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Alphabets);
            Assert.AreEqual(0, response.Alphabets.Count);
        }

        [Test]
        public void GetAlphabetListResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream(ResponseXml));

            var response = service.GetAlphabetLists(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Alphabets);
            Assert.AreEqual("_", response.Alphabets[0].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[0].Source);
            Assert.AreEqual("a", response.Alphabets[1].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[1].Source);
            Assert.AreEqual("b", response.Alphabets[2].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[2].Source);
            Assert.AreEqual("c", response.Alphabets[3].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[3].Source);
            Assert.AreEqual("d", response.Alphabets[4].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[4].Source);
            Assert.AreEqual("e", response.Alphabets[5].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[5].Source);
            Assert.AreEqual("f", response.Alphabets[6].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[6].Source);
            Assert.AreEqual("g", response.Alphabets[7].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[7].Source);
            Assert.AreEqual("h", response.Alphabets[8].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[8].Source);
            Assert.AreEqual("i", response.Alphabets[9].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[9].Source);
            Assert.AreEqual("j", response.Alphabets[10].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[10].Source);
            Assert.AreEqual("k", response.Alphabets[11].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[11].Source);
            Assert.AreEqual("l", response.Alphabets[12].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[12].Source);
            Assert.AreEqual("m", response.Alphabets[13].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[13].Source);
            Assert.AreEqual("n", response.Alphabets[14].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[14].Source);
            Assert.AreEqual("o", response.Alphabets[15].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[15].Source);
            Assert.AreEqual("p", response.Alphabets[16].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[16].Source);
            Assert.AreEqual("q", response.Alphabets[17].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[17].Source);
            Assert.AreEqual("r", response.Alphabets[18].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[18].Source);
            Assert.AreEqual("s", response.Alphabets[19].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[19].Source);
            Assert.AreEqual("t", response.Alphabets[20].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[20].Source);
            Assert.AreEqual("u", response.Alphabets[21].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[21].Source);
            Assert.AreEqual("v", response.Alphabets[22].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[22].Source);
            Assert.AreEqual("w", response.Alphabets[23].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[23].Source);
            Assert.AreEqual("x", response.Alphabets[24].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[24].Source);
            Assert.AreEqual("y", response.Alphabets[25].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[25].Source);
            Assert.AreEqual("z", response.Alphabets[26].Letter);
            Assert.AreEqual("healthwise", response.Alphabets[26].Source);
        }

        [Test]
        public void GetCategoriesReturnsGetCategoriesResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream(ResponseXml));
            var response = service.GetAlphabetLists(request);
            Assert.IsInstanceOf<GetAlphabetListsResponse>(response);
        }

        private static Stream BuildResponseStream(string xml)
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(xml));
            return stream;
        }
    }
}
