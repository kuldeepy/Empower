﻿namespace HealthWise.GetAlphabetLists.Test.Entities
{
    using Medseek.Platform.Services.HealthWise.GetAlphabetLists.Entities;

    using NUnit.Framework;

    [TestFixture]
    public sealed class AlphabetTests
    {
        [Test]
        public void CanCreateAlphabetWithDefaultConstructor()
        {
            Assert.IsNotNull(new Alphabet());
        }

        [Test]
        public void CanCreateWithParameterConstructor()
        {
            var alphabet = new Alphabet("letter");
            var expectedLetterValue = "letter";
            var expectedSourceValue = "healthwise";

            Assert.IsNotNull(alphabet);
            Assert.AreEqual(alphabet.Letter, expectedLetterValue);
            Assert.AreEqual(alphabet.Source, expectedSourceValue);
        }
    }
}
