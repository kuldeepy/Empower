﻿namespace HealthWise.SearchByCode.Test
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.HealthWise.SearchByCode;
    using Medseek.Platform.Services.HealthWise.SearchByCode.Entities;
    using Medseek.Platform.Services.HealthWise.SearchByCode.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class SearchByCodeServiceTests : TestFixture<SearchByCodeService>
    {
        private const string HealthwiseApplicationKey = "A4M7EY3QIZRTJNPGLDNF2HR4YEHYK64YR4YCUXLNZ56WCEQE7KXMA2P62VGYN63NZAGOSQ5KHI2N3KE4LHVZU7J34PEAM6AV5DFYDZMY";
        private const string SearchByCodeUrl = "https://ixbapi.healthwise.net/Metadata?{0}&hw.key={1}";
        private const string XmlString = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                           "<entry>" +
                                               "<title>Allergic Reaction</title>" +
                                               "<summary/>" +
                                               "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"DocumentLink11\" hreflang=\"en-us\" hw:document-href=\"hn-11\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink12\" hreflang=\"en-us\" hw:document-href=\"hn-12\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink13\" hreflang=\"en-us\" hw:document-href=\"hn-13\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                                "<id>tag:healthwise.org1</id>" +
                                               "<updated>1111-01-01T12:00:00Z</updated>" +
                                           "</entry>" +
                                           "<entry>" +
                                               "<title>Allergic Rhinitis</title>" +
                                               "<summary/>" +
                                               "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"DocumentLink21\" hreflang=\"en-us\" hw:document-href=\"hn-21\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink22\" hreflang=\"en-us\" hw:document-href=\"hn-22\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink23\" hreflang=\"en-us\" hw:document-href=\"hn-23\" hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                               "<id>tag:healthwise.org2</id>" +
                                               "<updated>1111-01-01T12:00:00Z</updated>" +
                                           "</entry>" +
                                        "</feed>";

        private Mock<IWebClient> webClient;
        private SearchByCodeService service;
        private SearchByCodeRequest request;
       
        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            service = new SearchByCodeService(webClient.Object);
            request = new SearchByCodeRequest
            {
                Age = new Age
                {
                 Days = 1,
                 Months = 1,
                 Years = 30
                },
                Code = "CodeValue",
                CodeSystemId = "CodeSystemId",
                Gender = "Male",
                LanguageCode = "en-us",
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                                                  {
                                                      new KeySettingsPair
                                                          {
                                                              Key = "healthwise",
                                                              Settings = new Settings
                                                                        {
                                                                          LicenseKey = HealthwiseApplicationKey,
                                                                          BaseUrl = "https://ixbapi.healthwise.net"
                                                                        }
                                                          }
                                                  }
                    }
            };


        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<SearchByCodeService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new SearchByCodeService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchByCodeNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.SearchByCode(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: inRequest"));
        }

        [Test]
        public void SearchByCodeNoTenantInformationThrowsApplicationException()
        {
            const string exceptionMessage = "Tenant '' is not configured for HealthWise functionality";

            TestDelegate action = () => service.SearchByCode(new SearchByCodeRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void SearchByCodeNoHealthWiseTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string exceptionMessage = "Tenant 'TenantId' is not configured for HealthWise functionality";

            TestDelegate action = () => service.SearchByCode(new SearchByCodeRequest
            {
                TenantInfo = new Tenant
                {
                    Name = "TenantName",
                    Id = "TenantId",
                    Settings = new List<KeySettingsPair>()
                }
            });

            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void SearchByCodeReturnsSearchByCodeResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.IsInstanceOf<SearchByCodeResponse>(response);
        }

        [Test]
        public void SearchByCodeWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodeAllObjectsReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
        }

        [Test]
        public void SearchByCodeValidRequestWebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings.Set("PageSize", "25");
            service = new SearchByCodeService(webClient.Object);
            var expectedUrl = string.Format(SearchByCodeUrl, "mainsearchcriteria.v.cs0=CodeSystemId&mainsearchcriteria.v.c0=CodeValue&patientPerson.administrativegendercode.dn=Male&lang=en-us&age.v.v=30&hw.results.max=25", HealthwiseApplicationKey);
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodeCodeAndCodeSystemIdArePopulated()
        {
            request.Code = "CodeValue";
            request.CodeSystemId = "CodeSystemId";

            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("mainsearchcriteria.v.cs0=CodeSystemId")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodeGenderSpecifiedInRequestWebClientQueryStringContainsGender()
        {
            request.Gender = "Male";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("patientPerson.administrativegendercode.dn=Male")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodeGenderNotSpecifiedInRequestWebClientQueryStringDoesNotContainGender()
        {
            request.Gender = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains("patientPerson.administrativegendercode.dn")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodeLanguageNotSpecifiedInRequestWebClientQueryStringDoesNotContainLanguage()
        {
            request.LanguageCode = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains("lang=")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodeAgeSpecifiedInRequestWebClientQueryStringContainsAge()
        {
            request.Age.Years = 25;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("age.v.v=25")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodePageSizeNotSpecifiedInRequestWebClientQueryStringContainDefaultPageSize()
        {
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("&hw.results.max=150")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }
        
        [Test]
        public void SearchByCodePageSizeSpecifiedInRequestWebClientQueryStringContainSpecifiedPageSize()
        {
            ConfigurationManager.AppSettings.Set("PageSize", "25");
            service = new SearchByCodeService(webClient.Object);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("&hw.results.max=25")))).Returns(BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }
     
        [Test]
        public void SearchByCodeResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.SearchByCode(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual("hn-11", response.ContentItems[0].ContentId);
            Assert.AreEqual("Allergic Reaction", response.ContentItems[0].Title);
            Assert.AreEqual(string.Empty, response.ContentItems[0].Description);
            Assert.AreEqual("DocumentLink11", response.ContentItems[0].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", response.ContentItems[0].PostingDate);
            Assert.AreEqual("en-us", response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);

            Assert.AreEqual("hn-21", response.ContentItems[1].ContentId);
            Assert.AreEqual("Allergic Rhinitis", response.ContentItems[1].Title);
            Assert.AreEqual(string.Empty, response.ContentItems[1].Description);
            Assert.AreEqual("DocumentLink21", response.ContentItems[1].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", response.ContentItems[1].PostingDate);
            Assert.AreEqual("en-us", response.ContentItems[1].Language);
            Assert.AreEqual("healthwise", response.ContentItems[1].Source);
        }

        [Test]
        public void SearchByCodeResponseContainsNullValueForAttributesMissingInElement()
        {
            const string result = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                  "<entry>" +
                                  "<title>Allergies</title>" +
                                  "<summary/>" +
                                  "<link rel=\"alternate\" type=\"application/atom+xml\"  hw:document-type=\"nord\" hw:rank=\"1\" hw:document-family=\"kb\"/>" +
                                  "<id>tag:healthwise.org1</id>" +
                                  "<updated>1111-01-01T12:00:00Z</updated>" +
                                  "</entry>" +
                                  "</feed>";

            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(result)));
            var response = service.SearchByCode(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].Link);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        [Test]
        public void GetContentByCategoryResponseContainsNullValueIfAttribitesInResponseElementContainsNullValue()
        {
            const string result = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                  "<entry>" +
                                  "</entry>" +
                                  "</feed>";
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(result)));
            var response = service.SearchByCode(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
    }
}
