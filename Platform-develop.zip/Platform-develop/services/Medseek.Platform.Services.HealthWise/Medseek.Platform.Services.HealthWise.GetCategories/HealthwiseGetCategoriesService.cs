﻿namespace Medseek.Platform.Services.HealthWise.GetCategories
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;
    using System.Web;
    using System.Xml.Linq;
    using HealthWise.GetCategories.Entities;
    using HealthWise.GetCategories.WebClient;
    using Medseek.Util.Interactive;
    using Medseek.Util.Logging;
    using Medseek.Util.MicroServices;       
    
    [RegisterMicroService]
    public class HealthwiseGetCategoriesService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetCategories.HealthWise";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getcategories.healthwise";
        private const string HealthwiseSettingsKey = "healthwise";
        private const string GetCategoriesUrl = "{0}/{1}/Category?{2}&hw.key={3}";
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IWebClient webClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="HealthwiseGetCategoriesService"/> class.
        /// </summary>
        /// <param name="webClient">An instance of <see cref="IWebClient"/>.</param>
        /// <exception cref="System.ArgumentNullException">web Client</exception>        
        public HealthwiseGetCategoriesService(IWebClient webClient)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }

            this.webClient = webClient;
        }

        /// <summary>
        /// The service call the Health wise GetCategory service to read all categories 
        /// </summary>
        /// <param name="inRequest">The GetCategoriesRequest request</param>
        /// <exception cref="System.ArgumentNullException">The inRequest is null</exception>
        /// <exception cref="System.ApplicationException">Tenant is not configured for HealthWise functionality</exception>
        /// <returns>Returns list of categories</returns>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, AutoDelete = false)]
        public GetCategoriesResponse GetCategories(GetCategoriesRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var hwsettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any())
                                     ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == HealthwiseSettingsKey)
                                     : null;

            if (hwsettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for HealthWise functionality",
                                                             tenantId));
            }

            string requestXml = BuildGetCategoriesRequest(inRequest);

            var uri = string.Format(GetCategoriesUrl,
                                    hwsettings.Settings.BaseUrl, 
                                    HealthwiseSettingsKey,
                                    HttpUtility.UrlEncode(requestXml),
                                    hwsettings.Settings.LicenseKey);

            using (var response = webClient.OpenRead(HttpUtility.UrlDecode(uri)))
            {
                return BuildGetCategoriesResponse(response);
            }
        } 
       
        #region Private Helpers
        private static Category BuildCategory(XElement inElement)
        {
            return new Category
            {
                Name = inElement.Value,
                Id = inElement.Attribute("categoryId").Value,
                Source = "healthwise"
            };
        }

        private static GetCategoriesResponse BuildGetCategoriesResponse(Stream response)
        {
            var xmlDoc = XElement.Load(response);
            List<Category> categories = xmlDoc.Elements("item").Select(BuildCategory).Do(x => Log.DebugFormat("Category Id = {0}, Category Name = {1}", x.Id, x.Name)).ToList();
            return new GetCategoriesResponse { Categories = categories };
        }

        private string BuildGetCategoriesRequest(GetCategoriesRequest inRequest)
        {
            var sb = new StringBuilder();
            if (inRequest.LanguageCode != null)
            {
                sb.Append(string.Format("lang={0}", inRequest.LanguageCode));
            }
            return sb.ToString();
        }

        #endregion
    }
}
