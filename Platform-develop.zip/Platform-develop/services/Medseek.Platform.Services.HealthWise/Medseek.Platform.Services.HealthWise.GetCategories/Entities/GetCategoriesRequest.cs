﻿namespace Medseek.Platform.Services.HealthWise.GetCategories.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetCategoriesRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
