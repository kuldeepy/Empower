﻿namespace Medseek.Platform.Services.HealthWise.GetCategories.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetCategoriesResponse
    {
        [DataMember]
        public List<Category> Categories { get; set; }
    }
}
