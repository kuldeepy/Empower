﻿namespace Medseek.Platform.Services.HealthWise.GetContentByCategory
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Web;
    using System.Xml.Linq;
    using HealthWise.GetContentByCategory.Entities;
    using HealthWise.GetContentByCategory.WebClient;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class HealthwiseGetContentByCategoryService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetContentByCategory.HealthWise";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getcontentbycategory.healthwise";
        private const string HealthwiseSettingsKey = "healthwise";
        private const string GetContentByCategoryUrl = "{0}/Metadata?{1}&hw.key={2}";
        private const string Xmlns = "http://www.w3.org/2005/Atom";
        private const string XmlnsHw = "http://www.healthwise.org/2009/DocumentInfo";

        private readonly IWebClient webClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="HealthwiseGetContentByCategoryService"/> class.
        /// </summary>
        /// <param name="webClient">An instance of <see cref="IWebClient"/>.</param>
        /// <exception cref="System.ArgumentNullException">web Client</exception>
        public HealthwiseGetContentByCategoryService(IWebClient webClient)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }

            this.webClient = webClient;
        }

        /// <summary>
        /// Get Content List by Category
        /// </summary>
        /// <param name="inRequest">The <see cref="GetContentByCategoryRequest"/>.</param>
        /// <returns>The <see cref="GetContentByCategoryResponse"/>.</returns>
        /// <exception cref="System.ArgumentNullException">The inRequest</exception>
        /// <exception cref="System.ApplicationException">Tenant is not configured for HealthWise functionality</exception>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, AutoDelete = false)]
        public GetContentByCategoryResponse GetContentByCategory(GetContentByCategoryRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            if (inRequest.Category == null || string.IsNullOrWhiteSpace(inRequest.Category.Name))
            {
                throw new ArgumentException("Request must contain Category.", "inRequest");
            }

            var hwsettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any())
                                     ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == HealthwiseSettingsKey)
                                     : null;

            if (hwsettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for HealthWise functionality",
                                                             tenantId));
            }

            var requestXml = BuildGetContentByCategoryRequest(inRequest);
            
            var uri = string.Format(GetContentByCategoryUrl,
                                    hwsettings.Settings.BaseUrl,
                                    HttpUtility.UrlEncode(requestXml),
                                    hwsettings.Settings.LicenseKey);

            using (var response = webClient.OpenRead(HttpUtility.UrlDecode(uri)))
            {
                return BuildGetContentByCategoryResponse(response);
            }
        }

        #region Private Helpers
        
        private static GetContentByCategoryResponse BuildGetContentByCategoryResponse(Stream response)
        {
            var categoryContentsResponse = new GetContentByCategoryResponse();

            var xmlDoc = XElement.Load(response);
            categoryContentsResponse.ContentItems =
                xmlDoc.Descendants((XNamespace)Xmlns + "entry").Select(BuildContentItem).ToList();

            return categoryContentsResponse;
        }

        private static ContentItem BuildContentItem(XElement entry)
        {
            return new ContentItem
            {
                Title = GetValue(entry, "title"),
                Description = GetValue(entry, "summary"),
                PostingDate = GetValue(entry, "updated"),
                Link = GetValue(entry, "link", "href"),
                ContentId = GetValue(entry, "link", "document-href"),
                Language = GetValue(entry, "link", "hreflang"),
                Source = "healthwise"
            };
        }

        private static string GetValue(XElement xmlElement, string elementName, string attributeName = null)
        {
            var element = xmlElement;

            if (!string.IsNullOrWhiteSpace(elementName))
            {
                element = xmlElement.Element((XNamespace)Xmlns + elementName);
                if (element == null)
                {
                    return null;
                }
            }

            if (string.IsNullOrWhiteSpace(attributeName))
            {
                return element.Value;
            }

            var attribute = element.Attribute(attributeName);

            if (attribute == null)
            {
                attribute = element.Attribute((XNamespace)XmlnsHw + attributeName);
            }

            return attribute != null ? attribute.Value : null;
        }

        private string BuildGetContentByCategoryRequest(GetContentByCategoryRequest inRequest)
        {
            var sb = new StringBuilder();

            sb.Append("mainsearchcriteria.v.cs0=2.16.840.1.113883.3.342.1.101");
            sb.Append(string.Format("&mainsearchcriteria.v.c0={0}", inRequest.Category.Name));

            return sb.ToString();
        }

        #endregion
    }
}
