﻿namespace Medseek.Platform.Services.HealthWise.GetResourceContent
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Web;
    using Medseek.Platform.Services.HealthWise.GetResourceContent.Entities;
    using Medseek.Platform.Services.HealthWise.GetResourceContent.WebClient;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class HealthWiseGetResourceContentService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetResourceContent.HealthWise";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getresourcecontent.healthwise";
        private const string HealthWiseSettingsKey = "healthwise";
        private const string GetResourceContentUrl = "{0}/resource/{1}hw.key={2}";
        private readonly IWebClient webClient;

        public HealthWiseGetResourceContentService(IWebClient webClient)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }
            this.webClient = webClient;
        }

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetResourceContentResponse GetResourceContent(GetResourceContentRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var healthwiseSettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any()) ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == HealthWiseSettingsKey) : null;

            if (healthwiseSettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for healthwise functionality", tenantId));
            }

            if (string.IsNullOrEmpty(inRequest.DocumentPath))
            {
                return new GetResourceContentResponse();
            }

            var xmlRequest = HttpUtility.UrlEncode(BuildGetResourceContentRequest(inRequest));

            var uri = string.Format(GetResourceContentUrl,
                                    healthwiseSettings.Settings.BaseUrl,
                                    xmlRequest,
                                    healthwiseSettings.Settings.LicenseKey);

            using (var response = webClient.OpenRead(HttpUtility.UrlDecode(uri)))
            {
                return BuildGetResourceContentResponse(response);
            }
        }

        #region private methods

        /// <summary>
        /// Builds response
        /// </summary>
        /// <param name="response">The <see cref="Stream"/>.</param>
        /// <returns>The <see cref="GetResourceContentResponse"/>.</returns>
        private static GetResourceContentResponse BuildGetResourceContentResponse(Stream response)
        {
            var resourceContentResponse = new GetResourceContentResponse
            {
                ContentItems = new List<ContentItem>
                               {
                                   new ContentItem
                                   {
                                       Content = StreamToString(response),
                                       Source = HealthWiseSettingsKey
                                   }
                               }
            };
            return resourceContentResponse;
        }

        /// <summary>
        /// Builds request
        /// </summary>
        /// <param name="inRequest">The <see cref="GetResourceContentRequest"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        private static string BuildGetResourceContentRequest(GetResourceContentRequest inRequest)
        {
            var sb = new StringBuilder();
            if (!string.IsNullOrEmpty(inRequest.DocumentPath))
            {
                sb.Append(string.Format("{0}?", inRequest.DocumentPath));
            }
            if (!string.IsNullOrEmpty(inRequest.LanguageCode))
            {
                sb.Append(string.Format("lang={0}&", inRequest.LanguageCode));
            }
            return sb.ToString();
        }

        /// <summary>
        /// Converts Response Stream to String
        /// </summary>
        /// <param name="stream">The <see cref="Stream"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        private static string StreamToString(Stream stream)
        {
            using (var reader = new StreamReader(stream))
            {
                var bytes = Encoding.UTF8.GetBytes(reader.ReadToEnd());
                return Convert.ToBase64String(bytes, 0, bytes.Length);
            }
        }

        #endregion
    }
}
