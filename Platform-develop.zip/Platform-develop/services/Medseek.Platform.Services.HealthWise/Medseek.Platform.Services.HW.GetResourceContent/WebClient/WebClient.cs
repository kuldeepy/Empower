﻿namespace Medseek.Platform.Services.HealthWise.GetResourceContent.WebClient
{
    using Medseek.Util.Ioc;

    /// <summary>
    /// Provides a web client implementation by wrapping <see 
    /// cref="System.Net.WebClient" />.
    /// </summary>
    [Register(typeof(IWebClient), Lifestyle = Lifestyle.Transient)]
    public class WebClient : System.Net.WebClient, IWebClient
    {
    }
}