﻿namespace Medseek.Platform.Services.HealthWise.GetResourceContent.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetResourceContentRequest
    {
        [DataMember]
        public string DocumentPath { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }

        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }
    }
}
