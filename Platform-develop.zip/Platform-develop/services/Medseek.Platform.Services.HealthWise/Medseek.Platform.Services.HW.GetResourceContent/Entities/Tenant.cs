﻿namespace Medseek.Platform.Services.HealthWise.GetResourceContent.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class Tenant
    {
        [DataMember]
        public string Id { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public List<KeySettingsPair> Settings { get; set; }
    }
}
