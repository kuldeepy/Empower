﻿namespace Medseek.Platform.Services.HealthWise.GetNews.Entities
{
    public enum Gender
    {
        /// <summary>
        /// The all.
        /// </summary>
        All,

        /// <summary>
        /// The male.
        /// </summary>
        Male,

        /// <summary>
        /// The female.
        /// </summary>
        Female
    }
}