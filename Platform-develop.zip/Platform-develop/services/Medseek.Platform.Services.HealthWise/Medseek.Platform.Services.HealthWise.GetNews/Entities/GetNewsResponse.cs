﻿namespace Medseek.Platform.Services.HealthWise.GetNews.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetNewsResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
