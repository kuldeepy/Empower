﻿namespace Medseek.Platform.Services.HealthWise.GetNews
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using HealthWise.GetNews.Entities;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class HealthwiseGetNewsService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetNews.Healthwise";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getnews.healthwise";
        private const string HealthwiseSettingsKey = "healthwise";

        /// <summary>
        /// This method calls the GetNews functionality of Health wise service provider.
        /// </summary>
        /// <param name="inRequest">The <see cref="GetNewsRequest"/> object.</param>
        /// <exception cref="ArgumentNullException">The request parameter is null.</exception>
        /// <returns>Returns GetNewsResponse</returns>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetNewsResponse GetNews(GetNewsRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            return new GetNewsResponse();
        }
    }
}
