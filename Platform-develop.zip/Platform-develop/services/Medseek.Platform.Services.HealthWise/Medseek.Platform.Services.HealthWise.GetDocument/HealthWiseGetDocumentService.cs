﻿namespace Medseek.Platform.Services.HealthWise.GetDocument
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Web;
    using System.Xml.Linq;
    using Medseek.Platform.Services.HealthWise.GetDocument.Entities;
    using Medseek.Platform.Services.HealthWise.GetDocument.WebClient;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class HealthWiseGetDocumentService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetDocument.HealthWise";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getdocument.healthwise";
        private const string HealthWiseSettingsKey = "healthwise";
        private const string GetDocumentUrl = "{0}/KnowledgeContent/{1}hw.key={2}";
        private const string Xmlns = "http://www.w3.org/2005/Atom";
        private readonly IWebClient webClient;

        public HealthWiseGetDocumentService(IWebClient webClient)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }
            this.webClient = webClient;
        }

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetDocumentResponse GetDocument(GetDocumentRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var healthwiseSettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any()) ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == HealthWiseSettingsKey) : null;

            if (healthwiseSettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for HealthWise functionality", tenantId));
            }

            if (string.IsNullOrEmpty(inRequest.ContentId))
            {
                var emptyResponse = new GetDocumentResponse();
                var item = new ContentItem { Source = "healthwise" };
                emptyResponse.ContentItems = new List<ContentItem> { item };
                return emptyResponse;
            }

            var xmlRequest = HttpUtility.UrlEncode(BuildGetDocumentRequest(inRequest));

            var uri = string.Format(GetDocumentUrl,
                                    healthwiseSettings.Settings.BaseUrl,
                                    xmlRequest,
                                    healthwiseSettings.Settings.LicenseKey);

            using (var response = webClient.OpenRead(HttpUtility.UrlDecode(uri)))
            {
                return BuildGetDocumentResponse(response, inRequest);
            }
        }

        #region private methods

        /// <summary>
        /// Builds response
        /// </summary>
        /// <param name="response">The <see cref="Stream"/>.</param>
        /// <returns>The <see cref="GetDocumentResponse"/>.</returns>
        private static GetDocumentResponse BuildGetDocumentResponse(Stream response, GetDocumentRequest inRequest)
        {
            GetDocumentResponse getDocumentResponse;

            var documentFormat = inRequest.ContentId.Contains(".") ? inRequest.ContentId.Split('.')[1] : "xml";
            var format = inRequest.DocumentFormat;
            var contentId = inRequest.ContentId;

            if (documentFormat.ToUpper() == "PDF")
            {
                getDocumentResponse = BuildGetPdfDocumentRhtmlResponse(response);
            }
            else if (string.IsNullOrEmpty(format) && !contentId.Contains("."))
            {
                getDocumentResponse = BuildGetDocumentHwxmlResponse(response);
            }
            else
            {
                getDocumentResponse = BuildGetDocumentRhtmlResponse(response);
            }
            return getDocumentResponse;
        }

        #region Healthwise XML format with prebuilt XHTML

        private static GetDocumentResponse BuildGetDocumentHwxmlResponse(Stream response)
        {
            var getDocumentResponse = new GetDocumentResponse();

            if (response != null)
            {
                var xmlDoc = XDocument.Load(response);
                getDocumentResponse.ContentItems = xmlDoc.Descendants((XNamespace)Xmlns + "entry").Select(BuildContentItem).ToList();
            }
            return getDocumentResponse;
        }

        /// <summary>
        /// Method builds the response ContentItem by fetching the values from XElement supplied to the method.
        /// </summary>
        /// <param name="entry">The XML element <see cref="XElement"/>.</param>
        /// <returns>The <see cref="ContentItem"/>.</returns>
        private static ContentItem BuildContentItem(XElement entry)
        {
            return new ContentItem
            {
                Title = GetValue(entry, "title"),
                Description = GetValue(entry, "summary"),
                PostingDate = GetValue(entry, "updated"),
                ContentId = GetValue(entry, "id"),
                Content = GetValue(entry, "content"),
                Source = HealthWiseSettingsKey,
                ContentType = "application/xml"
            };
        }

        /// <summary>
        /// Gets Value for supplied attribute of ContentItem from the supplied XElement
        /// </summary>
        /// <param name="xmlElement">The XML element<see cref="XElement"/>.</param>
        /// <param name="elementName">The element name<see cref="string"/>.</param>
        /// <returns>Value of the attribute from XML Element</returns>
        private static string GetValue(XElement xmlElement, string elementName)
        {
            var element = xmlElement;

            if (!string.IsNullOrWhiteSpace(elementName))
            {
                element = xmlElement.Element((XNamespace)Xmlns + elementName);
                if (element == null)
                {
                    return null;
                }
            }

            return element.Value;
        }

        #endregion

        #region Healthwise Document or Responsive XHTML
        private static GetDocumentResponse BuildGetDocumentRhtmlResponse(Stream response)
        {
            var getDocumentResponse = new GetDocumentResponse();

            if (response != null)
            {
                getDocumentResponse.ContentItems = new List<ContentItem>
                                                   {
                                                       new ContentItem
                                                       {
                                                           Content =
                                                               StreamToString(
                                                                   response),
                                                           Source =
                                                               HealthWiseSettingsKey,
                                                           ContentType = "text/html"
                                                       }
                                                   };
            }
            return getDocumentResponse;
        }
        private static string StreamToString(Stream stream)
        {
            using (var reader = new StreamReader(stream, Encoding.UTF8))
            {
                return reader.ReadToEnd();
            }
        }
        #endregion

        #region Healthwise pdf Document

        private static GetDocumentResponse BuildGetPdfDocumentRhtmlResponse(Stream response)
        {
            var getDocumentResponse = new GetDocumentResponse();
            if (response != null)
            {
                getDocumentResponse.ContentItems = new List<ContentItem>
                                                   {
                                                       new ContentItem
                                                       {
                                                           Content =
                                                               PdfStreamToString(
                                                                   response),
                                                           Source =
                                                               HealthWiseSettingsKey,
                                                           ContentType = "application/pdf"
                                                       }
                                                   };
            }
            return getDocumentResponse;
        }

        /// <summary>
        /// Converts Response Stream to String
        /// </summary>
        /// <param name="stream">The <see cref="Stream"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        private static string PdfStreamToString(Stream stream)
        {
            var streamReadBytes = new byte[1024];
            byte[] streamWriteBytes;

            using (var ms = new MemoryStream())
            {
                // Copy the response stream to the memory stream.
                stream.CopyTo(ms);
                streamWriteBytes = new byte[ms.Length * 8];

                int read;
                int i = 0;
                ms.Position = 0;
                while ((read = ms.Read(streamReadBytes, 0, streamReadBytes.Length)) > 0)
                {
                    Array.Copy(streamReadBytes, 0, streamWriteBytes, i, read);
                    i = i + read;
                }
            }
            return Convert.ToBase64String(streamWriteBytes.ToArray(), 0, streamWriteBytes.Length);
        }

        #endregion

        /// <summary>
        /// Builds request
        /// </summary>
        /// <param name="inRequest">The <see cref="GetDocumentRequest"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        private static string BuildGetDocumentRequest(GetDocumentRequest inRequest)
        {
            var sb = new StringBuilder();
            if (!string.IsNullOrEmpty(inRequest.ContentId))
            {
                sb.Append(string.Format("{0}?", inRequest.ContentId));
            }

            if (!string.IsNullOrEmpty(inRequest.DocumentFormat))
            {
                sb.Append(string.Format("hw.format={0}&", inRequest.DocumentFormat));
            }
            if (!string.IsNullOrEmpty(inRequest.LanguageCode))
            {
                sb.Append(string.Format("lang={0}&", inRequest.LanguageCode));
            }
            return sb.ToString();
        }

        #endregion
    }
}
