﻿namespace Medseek.Platform.Services.HealthWise.GetDocument.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetDocumentRequest
    {
        [DataMember]
        public string ContentId { get; set; }

        [DataMember]
        public string ContentTypeId { get; set; }

        [DataMember]
        public string DocumentFormat { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }

        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }
    }
}
