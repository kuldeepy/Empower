﻿namespace Medseek.Platform.Services.HealthWise.GetDocument.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetDocumentResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
