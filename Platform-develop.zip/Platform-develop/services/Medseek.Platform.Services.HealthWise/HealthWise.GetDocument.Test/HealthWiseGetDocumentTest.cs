﻿namespace HealthWise.GetDocument.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.HealthWise.GetDocument;
    using Medseek.Platform.Services.HealthWise.GetDocument.Entities;
    using Medseek.Platform.Services.HealthWise.GetDocument.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class HealthWiseGetDocumentTest : TestFixture<HealthWiseGetDocumentService>
    {
        private const string BaseUrl = "https://ixbapi.healthwise.net";

        private const string HealthwiseXmlResponse = "<feed xmlns=\"http://www.w3.org/2005/Atom\" xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\">" +
                                             "<entry hw:document-href='cpain' hw:lang='en-us' hw:document-type='Major' hw:document-rank='1' hw:document-family='kb' hw:release-quarter='10.2'>" +
                                                "<updated>2014-03-12</updated>" +
                                                "<id>id</id>" +
                                                "<rights>rights</rights>" +
                                                "<title>Chronic Pain</title>" +
                                                "<content type='xhtml'>" +
                                                      "<div>My Document Content</div>" +
                                                " </content>" +
                                            "</entry>" +
                                        "</feed>";

        private const string HealthwiseFormatedHtmlResponse = "HTML Response Stream";
        private const string HealthWisePdfResponse = "HealthWise PDF Response";
        private const string HealthWisePdfResponseConvertedToBase64String = "SGVhbHRoV2lzZSBQREYgUmVzcG9uc2UAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==";

        private GetDocumentRequest request;
        private HealthWiseGetDocumentService healthwiseservice;
        private Mock<IWebClient> mockwebClient;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            mockwebClient = Mock<IWebClient>();
            healthwiseservice = new HealthWiseGetDocumentService(mockwebClient.Object);
            request = new GetDocumentRequest
            {
                ContentId = "cspain",
                DocumentFormat = "hwxml",
                LanguageCode = "en-us",
                TenantInfo = new Tenant
                {
                    Id = "TenantId",
                    Name = "TenanatName",
                    Settings =
                        new List<KeySettingsPair>
                        {
                            new KeySettingsPair
                            {
                                Key = "healthwise",
                                Settings = new Settings
                                {
                                    LicenseKey = "A4M7EY3QIZRTJNPGLDNF2HR4YEHYK64YR4YCUXLNZ56WCEQE7KXMA2P62VGYN63NZAGOSQ5KHI2N3KE4LHVZU7J34PEAM6AV5DFYDZMY#3.1",
                                    BaseUrl = "https://ixbapi.healthwise.net"
                                }
                             }
                        }
                }
            };
        }

        #region Constructor Tests
        /// <summary>
        /// To check if default constructor executed successfully
        /// </summary>
        [Test]
        public void CtorValidParamsCanConstruct()
        {
            healthwiseservice = new HealthWiseGetDocumentService(mockwebClient.Object);
            Assert.IsNotNull(healthwiseservice);
            Assert.IsInstanceOf<HealthWiseGetDocumentService>(healthwiseservice);
        }

        /// <summary>
        /// Test for parameterized constructor throws error when IWebClient object is null 
        /// </summary>
        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new HealthWiseGetDocumentService(null);
            Assert.That(action,
                Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: webClient"));
        }
        #endregion

        #region Validation Tests
        /// <summary>
        /// To check if method throw null exception if request is null
        /// </summary>
        [Test]
        public void GetDocumentNullRequestThrowsArgumentNullExceptionWithCorrectMessage()
        {
            TestDelegate action = () => healthwiseservice.GetDocument(null);
            Assert.That(action,
            Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: inRequest"));
        }

        /// <summary>
        /// To test if exception is thrown when Tenant information is null
        /// </summary>
        [Test]
        public void GetDocumentNoTenantInformationThrowsApplicationException()
        {
            const string ExceptionMessage = "Tenant '' is not configured for HealthWise functionality";
            request.TenantInfo = null;
            TestDelegate action = () => healthwiseservice.GetDocument(request);
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(ExceptionMessage));
        }

        /// <summary>
        /// To test if proper exception is thrown if setting for tenant information is passed empty
        /// </summary>
        [Test]
        public void GetDocumentNoHealthWiseTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string ExceptionMessage = "Tenant 'TenantId' is not configured for HealthWise functionality";

            TestDelegate action = () => healthwiseservice.GetDocument(new GetDocumentRequest
            {
                TenantInfo = new Tenant
                {
                    Name = "TenantName",
                    Id = "TenantId",
                    Settings = new List<KeySettingsPair>()
                }
            });
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(ExceptionMessage));
        }

        /// <summary>
        /// To verify WebClient 
        /// </summary>
        [Test]
        public void GetDocumentWebClientIsCalled()
        {
            mockwebClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream(HealthwiseXmlResponse)).Verifiable();
            healthwiseservice.GetDocument(request);
            mockwebClient.Verify();
        }

        /// <summary>
        /// Test for web client return empty response if ContentId parameter is null in request XML
        /// </summary>
        [Test]
        public void GetDocumentReturnsEmptyResponseIfContentIdPropertyIsNull()
        {
            request.ContentId = null;
            var response = healthwiseservice.GetDocument(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }

        /// <summary>
        /// Test for web client return empty response if ContentId parameter is not present in request XML
        /// </summary>
        [Test]
        public void GetDocumentReturnsEmptyResponseIfContentIdPropertyIsEmpty()
        {
            request.ContentId = string.Empty;
            var response = healthwiseservice.GetDocument(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
        }
        #endregion

        #region Query String Test Cases

        /// <summary>
        /// Test for Valid web client baseUrl
        /// </summary>
        [Test]
        public void GetDocumentValidRequestWebClientBaseUrlIsExpected()
        {
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains(string.Format("{0}/KnowledgeContent/", BaseUrl))))).Returns(BuildResponseStream(HealthwiseXmlResponse)).Verifiable();
            healthwiseservice.GetDocument(request);
            mockwebClient.Verify();
        }

        /// <summary>
        /// Test for ContentId property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetDocumentContentIdSpecifiedInRequestWebClientQueryStringContainsValue()
        {
            request.ContentId = "cspain";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("cspain?")))).Returns(BuildResponseStream(HealthwiseXmlResponse)).Verifiable();
            healthwiseservice.GetDocument(request);
            mockwebClient.Verify();
        }

        /// <summary>
        /// Test for DocumentFormat property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetDocumentDocumentFormatSpecifiedInRequestWebClientQueryStringContainsValue()
        {
            request.DocumentFormat = "rhtml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=rhtml")))).Returns(BuildResponseStream(HealthwiseXmlResponse)).Verifiable();
            healthwiseservice.GetDocument(request);
            mockwebClient.Verify();
        }

        /// <summary>
        /// Test for DocumentFormat property is not supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetDocumentDocumentFormatNotSpecifiedInRequestWebClientQueryStringNotContainsValue()
        {
            request.DocumentFormat = null;
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains("hw.format")))).Returns(BuildResponseStream(HealthwiseXmlResponse)).Verifiable();
            healthwiseservice.GetDocument(request);
            mockwebClient.Verify();
        }

        /// <summary>
        /// Test for LanguageCode property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetDocumentLanguageCodeSpecifiedInRequestWebClientQueryStringContainsValue()
        {
            request.LanguageCode = "fr-fr";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("lang=fr-fr")))).Returns(BuildResponseStream(HealthwiseXmlResponse)).Verifiable();
            healthwiseservice.GetDocument(request);
            mockwebClient.Verify();
        }

        /// <summary>
        /// Test for LanguageCode property is not supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetDocumentLanguageCodeNotSpecifiedInRequestWebClientQueryStringNotContainsValue()
        {
            request.LanguageCode = null;
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains("lang")))).Returns(BuildResponseStream(HealthwiseXmlResponse)).Verifiable();
            healthwiseservice.GetDocument(request);
            mockwebClient.Verify();
        }

        #endregion

        #region Response Tests
        /// <summary>
        /// To check if proper response is being  generated 
        /// </summary>
        [Test]
        public void GetDocumentRequestReturnsGetDocumentResponse()
        {
            mockwebClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream(HealthwiseXmlResponse));
            var response = healthwiseservice.GetDocument(request);
            Assert.IsInstanceOf<GetDocumentResponse>(response);
        }

        /// <summary>
        /// Response populated correctly for xml format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForHwxmlFormatResponse()
        {
            request.ContentId = "cspain";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "hwxml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=hwxml"))))
                .Returns(BuildResponseStream(HealthwiseFormatedHtmlResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);

            Assert.AreEqual(StreamToString(BuildResponseStream(HealthwiseFormatedHtmlResponse)), response.ContentItems[0].Content);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("text/html", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Response populated correctly for formatted html format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForRhtmlFormatResponse()
        {
            request.ContentId = "cspain";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "rhtml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=rhtml"))))
                .Returns(BuildResponseStream(HealthwiseFormatedHtmlResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);

            Assert.AreEqual(StreamToString(BuildResponseStream(HealthwiseFormatedHtmlResponse)), response.ContentItems[0].Content);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("text/html", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Response populated correctly for html document request in xml format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForHtmlDocumentInHwxmlFormatResponse()
        {
            request.ContentId = "cspain.html";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "hwxml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=hwxml"))))
                .Returns(BuildResponseStream(HealthwiseFormatedHtmlResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);

            Assert.AreEqual(StreamToString(BuildResponseStream(HealthwiseFormatedHtmlResponse)), response.ContentItems[0].Content);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("text/html", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Response populated correctly for html document request in formatted html format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForHtmlDocumentInRhtmlFormatResponse()
        {
            request.ContentId = "cspain.html";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "rhtml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=rhtml"))))
                .Returns(BuildResponseStream(HealthwiseFormatedHtmlResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);

            Assert.AreEqual(StreamToString(BuildResponseStream(HealthwiseFormatedHtmlResponse)), response.ContentItems[0].Content);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("text/html", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Response populated correctly for html document request in xml format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForXmlDocumentInHwxmlFormatResponse()
        {
            request.ContentId = "cspain.xml";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "hwxml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=hwxml"))))
                .Returns(BuildResponseStream(HealthwiseFormatedHtmlResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);

            Assert.AreEqual(StreamToString(BuildResponseStream(HealthwiseFormatedHtmlResponse)), response.ContentItems[0].Content);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("text/html", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Response populated correctly for xml document request in formatted html format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForxmlDocumentInRhtmlFormatResponse()
        {
            request.ContentId = "cspain.xml";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "rhtml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=rhtml"))))
                .Returns(BuildResponseStream(HealthwiseFormatedHtmlResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);

            Assert.AreEqual(StreamToString(BuildResponseStream(HealthwiseFormatedHtmlResponse)), response.ContentItems[0].Content);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("text/html", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Response populated correctly for html document request in xml format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForHwxmlDocumentResponse()
        {
            request.ContentId = "cspain";
            request.LanguageCode = null;
            request.DocumentFormat = null;

            mockwebClient.Setup(w => w.OpenRead(It.IsAny<string>()))
                .Returns(BuildResponseStream(HealthwiseXmlResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.AreEqual("id", response.ContentItems[0].ContentId);
            Assert.AreEqual("My Document Content", response.ContentItems[0].Content);
            Assert.AreEqual("Chronic Pain", response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Link);
            Assert.AreEqual("2014-03-12", response.ContentItems[0].PostingDate);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("application/xml", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Response populated correctly for html document request in xml format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseContainsNullValueIfAttribitesInResponseElementContainsNullValue()
        {
            const string Result = "<feed xmlns:hw=\"http://www.healthwise.org/2009/DocumentInfo\" xmlns=\"http://www.w3.org/2005/Atom\" hw:match-type=\"None\" xml:lang=\"en-us\" hw:recipient-lang=\"en-us\">" +
                                             "</feed>";
            request.ContentId = "cspain";
            request.LanguageCode = null;
            request.DocumentFormat = null;

            mockwebClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes(Result)));
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }

        /// <summary>
        /// Response populated correctly for PDF document request in xml format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForPdfDocumentInhwxmlFormatResponse()
        {
            request.ContentId = "cspain.pdf";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "hwxml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=hwxml"))))
                .Returns(BuildResponseStream(HealthWisePdfResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);

            Assert.AreEqual(HealthWisePdfResponseConvertedToBase64String, response.ContentItems[0].Content);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("application/pdf", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Response populated correctly for PDF document request in formatted html format response 
        /// </summary>
        [Test]
        public void GetDocumentResponseObjectPopulatedCorrectlyForPdfDocumentInRhtmlFormatResponse()
        {
            request.ContentId = "cspain.pdf";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "rhtml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=rhtml"))))
                .Returns(BuildResponseStream(HealthWisePdfResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);

            Assert.IsNullOrEmpty(response.ContentItems[0].ContentTypeId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Gender);
            Assert.IsNullOrEmpty(response.ContentItems[0].ContentId);
            Assert.IsNullOrEmpty(response.ContentItems[0].Title);
            Assert.IsNullOrEmpty(response.ContentItems[0].Description);
            Assert.IsNullOrEmpty(response.ContentItems[0].Link);
            Assert.IsNullOrEmpty(response.ContentItems[0].PostingDate);
            Assert.IsNullOrEmpty(response.ContentItems[0].Language);

            Assert.AreEqual(HealthWisePdfResponseConvertedToBase64String, response.ContentItems[0].Content);
            Assert.AreEqual("healthwise", response.ContentItems[0].Source);
            Assert.AreEqual("application/pdf", response.ContentItems[0].ContentType);
        }

        /// <summary>
        /// Test to check converted Base64String is properly reconstructed  to PDF response stream.
        /// </summary>
        [Test]
        public void GetDocumentConvertedBase64StringToPdfStreamCorrectly()
        {
            request.ContentId = "cspain.pdf";
            request.LanguageCode = "en-us";
            request.DocumentFormat = "hwxml";
            mockwebClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains("hw.format=hwxml"))))
                .Returns(BuildResponseStream(HealthWisePdfResponse))
                .Verifiable();
            var response = healthwiseservice.GetDocument(request);
            byte[] byteArray = Convert.FromBase64String(response.ContentItems[0].Content);
            Assert.AreEqual(GetPdfResponseStringFromPdfResponse(byteArray), HealthWisePdfResponse);
        }

        #endregion

        #region Private Helpers
        private static string StreamToString(Stream stream)
        {
            using (var reader = new StreamReader(stream, Encoding.UTF8))
            {
                return reader.ReadToEnd();
            }
        }

        private Stream BuildResponseStream(string responsestring)
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(responsestring));
            return stream;
        }

        private string GetPdfResponseStringFromPdfResponse(byte[] byteArray)
        {
            var length = byteArray.Length / 8;
            var buffer = new byte[length];
            Array.Copy(byteArray, buffer, length);
            Stream stream = new MemoryStream(buffer);
            var reader = new StreamReader(stream);
            string responsestring = reader.ReadToEnd();
            return responsestring;
        }

        #endregion
    }
}
