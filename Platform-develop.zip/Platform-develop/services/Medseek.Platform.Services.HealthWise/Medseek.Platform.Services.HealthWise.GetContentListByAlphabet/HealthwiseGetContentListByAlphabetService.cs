﻿namespace Medseek.Platform.Services.HealthWise.GetContentListByAlphabet
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Web;
    using System.Xml.Linq;
    using Medseek.Platform.Services.HealthWise.GetContentListByAlphabet.Entities;
    using Medseek.Platform.Services.HealthWise.GetContentListByAlphabet.WebClient;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class HealthwiseGetContentListByAlphabetService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetContentListByAlphabet.Healthwise";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getcontentlistbyalphabet.healthwise";
        private const string HealthwiseSettingsKey = "healthwise";
        private const string GetContentListByAlphabetUrl = "{0}/Metadata?{1}&hw.key={2}";
        private const string xmlns = "http://www.w3.org/2005/Atom";
        private const string xmlnsHW = "http://www.healthwise.org/2009/DocumentInfo";

        private readonly IWebClient webClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="HealthwiseGetContentListByAlphabetService"/> class.
        /// </summary>
        /// <param name="webClient">An instance of <see cref="IWebClient"/>.</param>
        /// <exception cref="System.ArgumentNullException">web Client</exception>
        public HealthwiseGetContentListByAlphabetService(IWebClient webClient)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }

            this.webClient = webClient;
        }

        /// <summary>
        /// Gets all the content by alphabet and some optional search criteria
        /// </summary>
        /// <param name="inRequest">The <see cref="GetContentListByAlphabetRequest"/>.</param>
        /// <returns>The <see cref="GetContentListByAlphabetResponse"/>.</returns>
        /// <exception cref="System.ArgumentNullException">input Request</exception>
        /// <exception cref="System.ApplicationException">Tenant not configured for Healthwise functionality.</exception>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetContentListByAlphabetResponse GetContentListByAlphabet(GetContentListByAlphabetRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var healthwiseSettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any())
                                     ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == HealthwiseSettingsKey)
                                     : null;

            if (healthwiseSettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for Healthwise functionality",
                                                             tenantId));
            }

            if (string.IsNullOrEmpty(inRequest.ByLetter))
            {
                GetContentListByAlphabetResponse emptyResponse = new GetContentListByAlphabetResponse();
                ContentItem item = new ContentItem { Source = "healthwise" };
                emptyResponse.ContentItems = new System.Collections.Generic.List<ContentItem>();
                emptyResponse.ContentItems.Add(item);
                return emptyResponse;
            }

            var xmlRequest = HttpUtility.UrlEncode(BuildGetContentListByAlphabetRequest(inRequest));

            var uri = string.Format(GetContentListByAlphabetUrl,
                                    healthwiseSettings.Settings.BaseUrl,
                                    xmlRequest,
                                    healthwiseSettings.Settings.LicenseKey);

            using (var response = webClient.OpenRead(HttpUtility.UrlDecode(uri)))
            {
                return BuildGetContentListByAlphabetResponse(response);
            }
        }

        #region Private Helpers

        /// <summary>
        /// Builds response
        /// </summary>
        /// <param name="response">The <see cref="Stream"/>.</param>
        /// <returns>The <see cref="GetContentListByAlphabetResponse"/>.</returns>
        private static GetContentListByAlphabetResponse BuildGetContentListByAlphabetResponse(Stream response)
        {
            var alphabetContentsListResponse = new GetContentListByAlphabetResponse();

            if (response != null)
            {
                var xmlDoc = XDocument.Load(response);
                alphabetContentsListResponse.ContentItems = xmlDoc.Descendants((XNamespace)xmlns + "entry").Select(BuildContentItem).ToList();
            }
            return alphabetContentsListResponse;
        }

        /// <summary>
        /// Method builds the response ContentItem by fetching the values from XElement supplied to the method.
        /// </summary>
        /// <param name="entry">The XML element <see cref="XElement"/>.</param>
        /// <returns>The <see cref="ContentItem"/>.</returns>
        private static ContentItem BuildContentItem(XElement entry)
        {
            return new ContentItem
            {
                Title = GetValue(entry, "title"),
                Description = GetValue(entry, "summary"),
                PostingDate = GetValue(entry, "updated"),
                Link = GetValue(entry, "link", "href"),
                ContentId = GetValue(entry, "link", "document-href"),
                Language = GetValue(entry, "link", "hreflang"),
                Source = "healthwise"
            };
        }

        /// <summary>
        /// Gets Value for supplied attribute of ContentItem from the supplied XElement
        /// </summary>
        /// <param name="xmlElement">The XML element<see cref="XElement"/>.</param>
        /// <param name="elementName">The element name<see cref="string"/>.</param>
        /// <param name="attributeName">The attribute <see cref="string"/>.</param>
        /// <returns>Value of the attribute from XML Element</returns>
        private static string GetValue(XElement xmlElement, string elementName, string attributeName = null)
        {
            var element = xmlElement;

            if (!string.IsNullOrWhiteSpace(elementName))
            {
                element = xmlElement.Element((XNamespace)xmlns + elementName);
                if (element == null)
                {
                    return null;
                }
            }

            if (string.IsNullOrWhiteSpace(attributeName))
            {
                return element.Value;
            }

            var attribute = element.Attribute(attributeName);

            if (attribute == null)
            {
                attribute = element.Attribute((XNamespace)xmlnsHW + attributeName);
            }

            return attribute != null ? attribute.Value : null;
        }

        /// <summary>
        /// Method builds the RequestXML based on the request comes form RabbitMQ
        /// </summary>
        /// <param name="inRequest">The request supplied by RabbitMQ<see cref="GetContentListByAlphabetRequest"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        private string BuildGetContentListByAlphabetRequest(GetContentListByAlphabetRequest inRequest)
        {
            var sb = new StringBuilder();

            sb.Append(string.Format("knowledgeRequestNotification.effectiveTime.v={0}", string.IsNullOrEmpty(inRequest.EffectiveTime) ? "00010101" : inRequest.EffectiveTime));
            sb.Append("mainsearchcriteria.v.cs0=2.16.840.1.113883.3.342.1.100");
            if (!string.IsNullOrEmpty(inRequest.ByLetter))
            {
                sb.Append(string.Format("&mainsearchcriteria.v.c0={0}", inRequest.ByLetter));
            }

            return sb.ToString();
        }

        #endregion
    }
}
