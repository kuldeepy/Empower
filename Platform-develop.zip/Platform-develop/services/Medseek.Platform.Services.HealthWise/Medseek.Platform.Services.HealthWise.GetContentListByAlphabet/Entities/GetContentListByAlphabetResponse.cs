﻿namespace Medseek.Platform.Services.HealthWise.GetContentListByAlphabet.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetContentListByAlphabetResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
