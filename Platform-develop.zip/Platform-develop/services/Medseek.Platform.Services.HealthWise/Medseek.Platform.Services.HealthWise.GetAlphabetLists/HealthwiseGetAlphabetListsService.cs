﻿namespace Medseek.Platform.Services.HealthWise.GetAlphabetLists
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Xml.Linq;
    using Medseek.Platform.Services.HealthWise.GetAlphabetLists.Entities;
    using Medseek.Platform.Services.HealthWise.GetAlphabetLists.WebClient;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class HealthwiseGetAlphabetListsService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetAlphabetLists.HealthWise";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getalphabetlists.healthwise";

        private const string GetAlphabetListsUrl = "{0}/{1}/list?hw.key={2}";
        private const string HealthwiseSettingsKey = "healthwise";

        private readonly IWebClient webClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="HealthwiseGetAlphabetListsService"/> class.
        /// </summary>
        /// <param name="webClient">An instance of <see cref="IWebClient"/>.</param>
        /// <exception cref="System.ArgumentNullException">web Client</exception>
        public HealthwiseGetAlphabetListsService(IWebClient webClient)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }

            this.webClient = webClient;
        }

        /// <summary>
        /// Gets Alphabet Lists
        /// </summary>
        /// <param name="inRequest">The <see cref="GetAlphabetListsRequest"/>.</param>
        /// <returns>The <see cref="GetAlphabetListsResponse"/>.</returns>
        /// <exception cref="System.ArgumentNullException">The inRequest</exception>
        /// <exception cref="System.ApplicationException">Tenant is not configured for HealthWise functionality</exception>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetAlphabetListsResponse GetAlphabetLists(GetAlphabetListsRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var hwsettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any()) ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == HealthwiseSettingsKey) : null;

            if (hwsettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for HealthWise functionality", tenantId));
            }

            var uri = string.Format(GetAlphabetListsUrl,
                                    hwsettings.Settings.BaseUrl,
                                    HealthwiseSettingsKey,
                                    hwsettings.Settings.LicenseKey);

            using (var response = webClient.OpenRead(uri))
            {
                return BuildGetAlphabetListsResponse(response);
            }
        }

        #region private methods

        private static Item BuildItem(XElement inElement)
        {
            return new Item
            {
                Letter = GetValue(inElement)
            };
        }

        private static string GetValue(XElement inElement)
        {
            var element = inElement.FirstAttribute;
            return element == null ? null : element.Value;
        }

        private GetAlphabetListsResponse BuildGetAlphabetListsResponse(Stream response)
        {
            var keywordResponse = new GetAlphabetListsResponse
            {
                Alphabets = new List<Alphabet>()
            };
           
            var xmlDoc = XElement.Load(response);

            var items = xmlDoc.Descendants("item").Select(BuildItem).ToList();

            foreach (var alphabet in items.Select(row => new Alphabet(row.Letter)).Where(row => row.Letter != null))
            {
                keywordResponse.Alphabets.Add(alphabet);
            }

            return keywordResponse;
        }

        #endregion
    }
}
