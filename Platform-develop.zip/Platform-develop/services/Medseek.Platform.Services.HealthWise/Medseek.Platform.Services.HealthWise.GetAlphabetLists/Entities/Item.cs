﻿namespace Medseek.Platform.Services.HealthWise.GetAlphabetLists.Entities
{
    using System.Runtime.Serialization;
    
    [DataContract(Namespace = "")]
    public class Item
    {
        [DataMember]
        public string Letter { get; set; }
    }
}
