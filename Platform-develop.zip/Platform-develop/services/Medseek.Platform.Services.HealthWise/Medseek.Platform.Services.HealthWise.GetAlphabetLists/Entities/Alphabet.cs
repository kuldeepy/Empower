﻿namespace Medseek.Platform.Services.HealthWise.GetAlphabetLists.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class Alphabet
    {
        public Alphabet()
        {
        }

        public Alphabet(string letter)
        {
            Letter = letter;
            Source = "healthwise";
        }

        [DataMember]
        public string Letter { get; set; }

        [DataMember]
        public string Source { get; set; }
    }
}
