﻿namespace GeocodeService.Test
{
    using System;
    using System.Collections.Generic;

    using Medseek.Platform.Services.Geocode.GeocodeService;
    using Medseek.Platform.Services.Geocode.GeocodeService.Entities;
    using Medseek.Util.Messaging;
    using Medseek.Util.MicroServices;

    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class GeoCodeServiceTests
    {
        private const string Zip9 = "123456789";
        private const string Zip5 = "12345";
        private const string ZipInvalid = "1234567";
        private const string LatitudeOne = "latone";
        private const string LatitudeTwo = "lattwo";
        private const string LongitudeOne = "longone";
        private const string LongitudeTwo = "longtwo";
        private const string RoutingKey = "medseek.platform.services.geocode.geocodeservice.getgeocodes";
        private const string ReplyToAddress = "topic://medseek-api/ReplyToAddress";

        private GeocodeService service;
        private Mock<IMicroServiceDispatcher> dispatcher;
        private Mock<IMessageContextAccess> messageContext;
        private Mock<IDatabaseQueryHelper> queryHelper;
        private Mock<IRemoteMicroServiceInvoker> invoker;
        private GeocodeRequest request;
        private LocationCode locationOne;
        private LocationCode locationTwo;

        [SetUp]
        public void Setup()
        {
            request = new GeocodeRequest() { ZipCodes = new List<string>() { Zip5, Zip9 } };
            dispatcher = new Mock<IMicroServiceDispatcher>();
            messageContext = new Mock<IMessageContextAccess>();
            queryHelper = new Mock<IDatabaseQueryHelper>();
            invoker = new Mock<IRemoteMicroServiceInvoker>();

            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, RoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            dispatcher.SetupGet(c => c.RemoteMicroServiceInvoker).Returns(invoker.Object);

            service = new GeocodeService(queryHelper.Object, messageContext.Object, dispatcher.Object);

            locationOne = new LocationCode() { Latitude = LatitudeOne, Longitude = LongitudeOne };
            locationTwo = new LocationCode() { Latitude = LatitudeTwo, Longitude = LongitudeTwo };
        }

        [Test]
        public void Ctor_CanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<GeocodeService>(service);
        }

        [Test]
        public void Ctor_NullQueryHelper_ExceptionIsThrown()
        {
            TestDelegate action = () => new GeocodeService(null, messageContext.Object, dispatcher.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullDispatcher_ExceptionIsThrown()
        {
            TestDelegate action = () => new GeocodeService(queryHelper.Object, messageContext.Object, null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullContext_ExceptionIsThrown()
        {
            TestDelegate action = () => new GeocodeService(queryHelper.Object, null, dispatcher.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetGeocode_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetGeocodes(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetGeocodes_ValidRequest_QueryHelperIsCalledForEachValidZip()
        {
            queryHelper.Setup(q => q.GetLocationCode(It.Is<string>(s => s == Zip5))).Returns(new LocationCode()).Verifiable();
            queryHelper.Setup(q => q.GetLocationCode(It.Is<string>(s => s == Zip9))).Returns(new LocationCode()).Verifiable();

            service.GetGeocodes(request);
            queryHelper.VerifyAll();
        }

        [Test]
        public void GetGeocodes_ValidRequest_InvalidZip_QueryHelperIsNotCalled()
        {
            queryHelper = new Mock<IDatabaseQueryHelper>(MockBehavior.Strict);
            service = new GeocodeService(queryHelper.Object, messageContext.Object, dispatcher.Object);
            request = new GeocodeRequest() { ZipCodes = new List<string>() { ZipInvalid } };
            service.GetGeocodes(request);
            queryHelper.VerifyAll();
        }

        [Test]
        public void GetGeocodes_ValidRequest_InvokerIsCalledWithExpected()
        {
            object actualObj = null;
            MqAddress actualAddress = null;
            Type actualType = null;

            queryHelper.Setup(q => q.GetLocationCode(It.Is<string>(s => s == Zip5))).Returns(locationOne);
            queryHelper.Setup(q => q.GetLocationCode(It.Is<string>(s => s == Zip9))).Returns(locationTwo);

            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) =>
                           {
                               actualAddress = address;
                               actualType = type;
                               actualObj = data;
                           }).Verifiable();

            service.GetGeocodes(request);
            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<GeocodeResponse>(actualObj);
            Assert.AreEqual(actualType, typeof(GeocodeResponse));
            Assert.AreEqual(actualAddress.ToString(), ReplyToAddress);

            var geoResponse = (GeocodeResponse)actualObj;
            Assert.IsNotNull(geoResponse.GeocodeMappings);
            Assert.AreEqual(2, geoResponse.GeocodeMappings.Count);
            Assert.IsNotNull(geoResponse.GeocodeMappings[Zip5]);
            Assert.AreEqual(geoResponse.GeocodeMappings[Zip5].Latitude, LatitudeOne);
            Assert.AreEqual(geoResponse.GeocodeMappings[Zip5].Longitude, LongitudeOne);
            Assert.IsNotNull(geoResponse.GeocodeMappings[Zip9]);
            Assert.AreEqual(geoResponse.GeocodeMappings[Zip9].Latitude, LatitudeTwo);
            Assert.AreEqual(geoResponse.GeocodeMappings[Zip9].Longitude, LongitudeTwo);
        }

        [Test]
        public void GetGeocodes_ValidRequest_QueryHelperThrowsException_NullValueForZipReturned()
        {
            object actualObj = null;
            request = new GeocodeRequest() { ZipCodes = new List<string>() { Zip5 } };
            queryHelper.Setup(q => q.GetLocationCode(It.IsAny<string>())).Throws(new Exception()).Verifiable();
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) =>
                       {
                           actualObj = data;
                       }).Verifiable();


            service.GetGeocodes(request);
            queryHelper.Verify();
            var geoResponse = (GeocodeResponse)actualObj;
            Assert.IsNotNull(geoResponse.GeocodeMappings);
            Assert.AreEqual(1, geoResponse.GeocodeMappings.Count);
            Assert.IsNull(geoResponse.GeocodeMappings[Zip5]);

        }
    }
}
