﻿namespace GeocodeService.Test
{
    using Medseek.Platform.Services.Geocode.GeocodeService;
    using NUnit.Framework;

    [TestFixture]
    class MelissaDatabaseQueryHelperTests
    {
       [Test]
        public void Ctor_CanConstruct()
        {
            var melissaDbQueryHelper = new MelissaDatabaseQueryHelper();
            Assert.IsNotNull(melissaDbQueryHelper);
            Assert.IsInstanceOf<IDatabaseQueryHelper>(melissaDbQueryHelper);
        }
    }
}
