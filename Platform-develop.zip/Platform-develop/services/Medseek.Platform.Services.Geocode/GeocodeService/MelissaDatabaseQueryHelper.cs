﻿namespace Medseek.Platform.Services.Geocode.GeocodeService
{
    using System.Data.SqlClient;
    using Medseek.Platform.Services.Geocode.GeocodeService.Entities;
    using Medseek.Util.Ioc;

    [Register(typeof(IDatabaseQueryHelper), Lifestyle = Lifestyle.Transient)]
    public class MelissaDatabaseQueryHelper : IDatabaseQueryHelper
    {
        private const string ConnectionStringName = "GeocodeDataConnectionString";
        private const string ZipQuery = "select lat, lon from {0} where {1} = @zipcodevalue";
        private const string ZipFiveTable = "zip5_coding";
        private const string ZipNineTable = "zip9_coding";
        private const string ZipFiveColumn = "zip5";
        private const string ZipNineColumn = "zip9";

        private readonly string connectionString;

        public MelissaDatabaseQueryHelper()
        {
            connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[ConnectionStringName].ConnectionString;            
        }

        public LocationCode GetLocationCode(string inZip)
        {
            var tableName = GetTableName(inZip);
            var columnName = GetColumnName(inZip);
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand(string.Format(ZipQuery, tableName, columnName), connection))
                {
                    var zipParam = new SqlParameter("@zipcodeValue", inZip);
                    command.Parameters.Add(zipParam);
                    using (var reader = command.ExecuteReader())
                    {
                        reader.Read();
                        var locationCode = new LocationCode() { Latitude = reader["lat"].ToString(), Longitude = reader["lon"].ToString() };
                        return locationCode;
                    }
                }
            }
        }

        private string GetTableName(string inZip)
        {
            if (inZip.Length == 9)
            {
                return ZipNineTable;
            }

            return ZipFiveTable;
        }

        private string GetColumnName(string inZip)
        {
            if (inZip.Length == 9)
            {
                return ZipNineColumn;
            }

            return ZipFiveColumn;
        }
    }
}
