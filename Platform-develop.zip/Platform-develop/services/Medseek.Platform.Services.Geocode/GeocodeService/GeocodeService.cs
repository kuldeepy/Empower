﻿namespace Medseek.Platform.Services.Geocode.GeocodeService
{
    using System;
    using System.Collections.Generic;
    using Medseek.Platform.Services.Geocode.GeocodeService.Entities;
    using Medseek.Util.MicroServices;

    using NLog;

    [RegisterMicroService]
    public class GeocodeService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Geocode.GeocodeService";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.geocode.geocodeservice.getgeocodes";

        private readonly IDatabaseQueryHelper queryHelper;
        private readonly IMessageContextAccess messageContext;
        private readonly IMicroServiceDispatcher microServiceDispatcher;

        private readonly Logger logger;

        public GeocodeService(IDatabaseQueryHelper queryHelper, IMessageContextAccess messageContext, IMicroServiceDispatcher dispatcher)
        {
            if (queryHelper == null)
            {
                throw new ArgumentNullException("queryHelper");
            }

            if (messageContext == null)
            {
                throw new ArgumentNullException("messageContext");
            }

            if (dispatcher == null)
            {
                throw new ArgumentNullException("dispatcher");
            }

            this.queryHelper = queryHelper;
            this.messageContext = messageContext;
            this.microServiceDispatcher = dispatcher;
            this.logger = LogManager.GetCurrentClassLogger();
        }

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = true, AutoDelete = false)]
        public void GetGeocodes(GeocodeRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var response = new GeocodeResponse() { GeocodeMappings = new Dictionary<string, LocationCode>() };
            foreach (var zip in inRequest.ZipCodes)
            {
                var zipLength = zip.Length;

                // validate the length of the input
                LocationCode loc = null;
                if (zipLength == 5 || zipLength == 9)
                {
                    try
                    {
                        loc = queryHelper.GetLocationCode(zip);
                    }
                    catch (Exception ex)
                    {
                        logger.Error("Exception caught while querying geocode database: ", ex);
                        loc = null;
                    }
                }

                response.GeocodeMappings.Add(zip, loc);
            }

            this.SendResult(response);
        }

        private void SendResult(GeocodeResponse response)
        {
            var invoker = microServiceDispatcher.RemoteMicroServiceInvoker;
            var originalProperties = messageContext.Current.Properties.Clone();
            var replyTo = originalProperties.ReplyTo;

            invoker.Send(replyTo, typeof(GeocodeResponse), response, originalProperties);
        }
    }
}
