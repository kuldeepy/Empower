﻿namespace Medseek.Platform.Services.Geocode.GeocodeService
{
    using Medseek.Platform.Services.Geocode.GeocodeService.Entities;

    public interface IDatabaseQueryHelper
    {
        LocationCode GetLocationCode(string inZip);
    }
}
