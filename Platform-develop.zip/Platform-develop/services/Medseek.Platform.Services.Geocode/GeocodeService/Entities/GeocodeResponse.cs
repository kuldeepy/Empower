﻿namespace Medseek.Platform.Services.Geocode.GeocodeService.Entities
{
    using System.Collections.Generic;

    public class GeocodeResponse
    {
        public Dictionary<string, LocationCode> GeocodeMappings { get; set; }
    }
}
