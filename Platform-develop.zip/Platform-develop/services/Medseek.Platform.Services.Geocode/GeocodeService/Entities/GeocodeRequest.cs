﻿namespace Medseek.Platform.Services.Geocode.GeocodeService.Entities
{
    using System.Collections.Generic;

    public class GeocodeRequest
    {
        public List<string> ZipCodes { get; set; }
    }
}
