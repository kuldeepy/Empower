﻿namespace Medseek.Platform.Services.Geocode.GeocodeService.Entities
{
    public class LocationCode
    {
        public string Latitude { get; set; }

        public string Longitude { get; set; }
    }
}
