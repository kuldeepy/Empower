﻿namespace Medseek.Platform.Services.ContentService.Serializer
{
    using System.IO;

    public interface IContentSerializer
    {
        byte[] Serialize<T>(string contentType, T data);

        T Deserialize<T>(string contentType, Stream data);
    }
}
