﻿namespace Medseek.Platform.Services.ContentService.Serializer
{
    using System.Diagnostics.CodeAnalysis;
    using System.IO;

    using Medseek.Util.Ioc;
    using Medseek.Util.MicroServices;

    [ExcludeFromCodeCoverage]
    [Register(typeof(IContentSerializer))]
    public class ContentSerializer : IContentSerializer
    {
        private readonly IMicroServiceSerializer serializer;

        public ContentSerializer(IMicroServiceSerializer serializer)
        {
            this.serializer = serializer;
        }

        public byte[] Serialize<T>(string contentType, T data)
        {
            return serializer.Serialize(contentType, data);
        }

        public T Deserialize<T>(string contentType, Stream data)
        {
            return serializer.Deserialize<T>(contentType, data);
        }
    }
}
