﻿namespace Medseek.Platform.Services.ContentService.ServiceEntities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities;

    [DataContract(Namespace = "")]
    public class GetResourceContentResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
