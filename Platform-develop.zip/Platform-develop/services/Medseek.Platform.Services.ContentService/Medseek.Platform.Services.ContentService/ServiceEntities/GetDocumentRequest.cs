﻿namespace Medseek.Platform.Services.ContentService.ServiceEntities
{
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;

    [DataContract(Namespace = "")]
    public class GetDocumentRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember(IsRequired = true)]
        public string Source { get; set; }

        [DataMember]
        public string ContentTypeId { get; set; }

        [DataMember]
        public string ContentId { get; set; }

        [DataMember]
        public string ProductId { get; set; }

        [DataMember]
        public string DocumentFormat { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
