﻿namespace Medseek.Platform.Services.ContentService.ServiceEntities
{
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;

    [DataContract(Namespace = "")]
    public class GetCategoriesRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
