﻿namespace Medseek.Platform.Services.ContentService.ServiceEntities
{
    using System.Runtime.Serialization;
    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;

    [DataContract(Namespace = "")]
    public class SearchByKeywordRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string Keyword { get; set; }

        [DataMember]
        public string BirthDate { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
