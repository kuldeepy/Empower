﻿namespace Medseek.Platform.Services.ContentService.ServiceEntities
{
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;

    [DataContract(Namespace = "")]
    public class GetNewsRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string SearchPhrase { get; set; }

        [DataMember]
        public string MaxDocuments { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
