﻿namespace Medseek.Platform.Services.ContentService.ServiceEntities
{
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;

    [DataContract(Namespace = "")]
    public class GetResourceContentRequest
    {
        [DataMember]
        public string DocumentPath { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }

        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }
    }
}
