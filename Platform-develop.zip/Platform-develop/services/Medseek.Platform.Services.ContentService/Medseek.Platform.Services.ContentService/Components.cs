﻿namespace Medseek.Platform.Services.ContentService
{
    public static class Components
    {
        /// <summary>
        /// The XML namespace used by the components that implement the micro-service.
        /// </summary>
        public const string Xmlns = "";

        internal const string RoutingKeyPrefix = "medseek.platform.services.contentservice";
        internal const string ConsumeQueue = "Medseek.Platform.Services.Content";
        internal const string Exchange = "medseek-api";
        internal const string OriginalRequestKey = "contentservice.originalrequest";
        internal const string OriginalRoutingKey = "contentservice.originalroutingkey";
        internal const string AddressOfTenantGet = "topic://medseek-api/medseek.platform.services.tenantservice.get";
    }
}
