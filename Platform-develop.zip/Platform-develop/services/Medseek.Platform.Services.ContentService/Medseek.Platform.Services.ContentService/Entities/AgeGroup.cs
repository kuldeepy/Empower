﻿namespace Medseek.Platform.Services.ContentService.Entities
{
    public enum AgeGroup
    {
        /// <summary>
        /// Infant (0 - 11 mo)
        /// </summary>
        Infant,

        /// <summary>
        /// Childhood (11 mo - 12 years)
        /// </summary>
        Childhood,

        /// <summary>
        /// Teen (12 - 18 years)
        /// </summary>
        Teen,

        /// <summary>
        /// Adult (18+)
        /// </summary>
        Adult,

        /// <summary>
        /// Senior ?
        /// </summary>
        Senior
    }
}