﻿namespace Medseek.Platform.Services.ContentService.Entities.GetContentByCategory
{
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;

    [DataContract(Namespace = "")]
    public class GetContentByCategoryRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public Category Category { get; set; }

        [DataMember]
        public Age Age { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
