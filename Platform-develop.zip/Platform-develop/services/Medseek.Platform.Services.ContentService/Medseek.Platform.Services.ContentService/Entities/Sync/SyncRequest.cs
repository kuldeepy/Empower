﻿namespace Medseek.Platform.Services.ContentService.Entities.Sync
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    /// <summary>
    /// Describes a Sync operation request.
    /// </summary>
    [DataContract(Name = "sync-request", Namespace = "")]
    public class SyncRequest
    {
        /// <summary>
        /// Gets or sets an object describing the context of the Sync 
        /// operation.
        /// </summary>
        [DataMember(Name = "context", IsRequired = false, EmitDefaultValue = false)]
        public OperationRequest Context
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the operations to be performed during a Sync 
        /// service operation.
        /// </summary>
        [DataMember(Name = "operations", IsRequired = true)]
        public List<OperationRequest> Operations
        {
            get;
            set;
        }
    }
}
