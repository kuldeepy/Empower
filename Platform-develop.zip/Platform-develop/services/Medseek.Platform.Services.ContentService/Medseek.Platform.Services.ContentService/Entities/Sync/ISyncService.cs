﻿namespace Medseek.Platform.Services.ContentService.Entities.Sync
{
    using Medseek.Util.MicroServices;

    [RegisterMicroServiceProxy]
    public interface ISyncService
    {
        [MicroServiceBinding("medseek-api", "medseek.platform.syncservice.request", "", IsOneWay = true)]
        void Request(SyncRequest request);
    }
}
