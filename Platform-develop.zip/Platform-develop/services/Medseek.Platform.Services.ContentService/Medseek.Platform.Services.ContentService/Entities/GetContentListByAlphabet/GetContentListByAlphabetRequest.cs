﻿namespace Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet
{
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;

    [DataContract(Namespace = "")]
    public class GetContentListByAlphabetRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string ByLetter { get; set; }

        [DataMember]
        public string EffectiveTime { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }

        [DataMember]
        public Age Age { get; set; }
    }
}
