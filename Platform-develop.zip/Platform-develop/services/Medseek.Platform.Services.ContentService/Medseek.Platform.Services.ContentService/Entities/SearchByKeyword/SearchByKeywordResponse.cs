﻿namespace Medseek.Platform.Services.ContentService.Entities.SearchByKeyword
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class SearchByKeywordResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
