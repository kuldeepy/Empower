﻿namespace Medseek.Platform.Services.ContentService.Entities.GetNews
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities;

    [DataContract(Namespace = "")]
    public class GetNewsResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
