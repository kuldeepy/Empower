﻿namespace Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetAlphabetListsResponse
    {
        [DataMember]
        public List<Alphabet> Alphabets { get; set; }
    }
}
