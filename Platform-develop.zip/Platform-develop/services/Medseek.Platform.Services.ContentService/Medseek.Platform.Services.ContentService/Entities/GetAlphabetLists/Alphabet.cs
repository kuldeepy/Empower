﻿namespace Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class Alphabet
    {
        [DataMember]
        public string Letter { get; set; }

        [DataMember]
        public string Source { get; set; }
    }
}
