﻿namespace Medseek.Platform.Services.ContentService.Entities.GetDocument
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.ContentService.Entities;

    [DataContract(Namespace = "")]
    public class GetDocumentResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
