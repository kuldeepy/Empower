﻿namespace Medseek.Platform.Services.ContentService.Entities.GetCategories
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetCategoriesResponse
    {
        [DataMember]
        public List<Category> Categories { get; set; }
    }
}
