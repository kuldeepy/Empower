﻿namespace Medseek.Platform.Services.ContentService.AgeCalculator
{
    using System;

    using Medseek.Platform.Services.ContentService.Entities;
    using Medseek.Util.Ioc;

    [Register(typeof(IAgeCalculator), Lifestyle = Lifestyle.Transient)]
    public class AgeCalculator : IAgeCalculator
    {
        public Age CalculateAge(DateTime referenceDate, DateTime birthdate)
        {
            if (birthdate > referenceDate) return null;

            int years = 0;
            int months = 0;
            int days = 0;

            // compute difference in total months
            months = (12 * (referenceDate.Year - birthdate.Year)) + (referenceDate.Month - birthdate.Month);

            // based upon the 'days',
            // adjust months & compute actual days difference
            if (referenceDate.Day < birthdate.Day)
            {
                months--;
                days = DateTime.DaysInMonth(birthdate.Year, birthdate.Month) - birthdate.Day + referenceDate.Day;
            }
            else
            {
                days = referenceDate.Day - birthdate.Day;
            }

            // compute years & actual months
            years = months / 12;
            months -= years * 12;

            return new Age() { Days = days, Months = months, Years = years };
        }
    }
}
