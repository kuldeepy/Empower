﻿namespace Medseek.Platform.Services.ContentService.AgeCalculator
{
    using System;
    using Medseek.Platform.Services.ContentService.Entities;

    public interface IAgeCalculator
    {
        Age CalculateAge(DateTime referenceDate, DateTime birthdate);
    }
}
