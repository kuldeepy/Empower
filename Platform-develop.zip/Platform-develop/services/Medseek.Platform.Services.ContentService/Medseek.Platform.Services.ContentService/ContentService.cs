﻿namespace Medseek.Platform.Services.ContentService
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    using Medseek.Platform.Services.ContentService.AgeCalculator;
    using Medseek.Platform.Services.ContentService.Entities;
    using Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists;
    using Medseek.Platform.Services.ContentService.Entities.Sync;
    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;
    using Medseek.Platform.Services.ContentService.Serializer;
    using Medseek.Platform.Services.ContentService.ServiceEntities;
    using Medseek.Util.Messaging;
    using Medseek.Util.MicroServices;

    using Newtonsoft.Json;

    using GetAlphabetListsRequest = Medseek.Platform.Services.ContentService.ServiceEntities.GetAlphabetListsRequest;
    using GetAlphabetListsResponse = Medseek.Platform.Services.ContentService.ServiceEntities.GetAlphabetListsResponse;

    [RegisterMicroService]
    public class ContentService
    {
        private readonly IMicroServiceDispatcher dispatcher;
        private readonly IMessageContextAccess messageContext;
        private readonly IContentSerializer serializer;
        private readonly ISyncService syncService;
        private readonly IAgeCalculator ageCalculator;
        
        public ContentService(IMicroServiceDispatcher dispatcher, IMessageContextAccess messageContext, IContentSerializer serializer, ISyncService syncService, IAgeCalculator ageCalculator)
        {
            if (dispatcher == null)
                throw new ArgumentNullException("dispatcher");
            if (messageContext == null)
                throw new ArgumentNullException("messageContext");
            if (serializer == null)
                throw new ArgumentNullException("serializer");
            if (syncService == null)
                throw new ArgumentNullException("syncService");
            if (ageCalculator == null)
                throw new ArgumentNullException("ageCalculator");
            this.dispatcher = dispatcher;
            this.messageContext = messageContext;
            this.serializer = serializer;
            this.syncService = syncService;
            this.ageCalculator = ageCalculator;
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".searchbykeyword", Components.ConsumeQueue + ".SearchByKeyword", IsOneWay = true, AutoDelete = false)]
        public void SearchByKeyword(SearchByKeywordRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".searchbycode", Components.ConsumeQueue + ".SearchByCode", IsOneWay = true, AutoDelete = false)]
        public void SearchByCode(SearchByCodeRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".getdocument", Components.ConsumeQueue + ".GetDocument", IsOneWay = true, AutoDelete = false)]
        public void GetDocument(GetDocumentRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".getnews", Components.ConsumeQueue + ".GetNews", IsOneWay = true, AutoDelete = false)]
        public void GetNews(GetNewsRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".getcategories", Components.ConsumeQueue + ".GetCategories", IsOneWay = true, AutoDelete = false)]
        public void GetCategories(GetCategoriesRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".getcontentbycategory", Components.ConsumeQueue + ".GetContentByCategory", IsOneWay = true, AutoDelete = false)]
        public void GetContentByCategory(GetContentByCategoryRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".getalphabetlists", Components.ConsumeQueue + ".GetAlphabetLists", IsOneWay = true, AutoDelete = false)]
        public void GetAlphabetLists(GetAlphabetListsRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".getcontentlistbyalphabet", Components.ConsumeQueue + ".getcontentlistbyalphabet", IsOneWay = true, AutoDelete = false)]
        public void GetContentListByAlphabet(GetContentListByAlphabetRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".getresourcecontent", Components.ConsumeQueue + ".getresourcecontent", IsOneWay = true, AutoDelete = false)]
        public void GetResourceContent(GetResourceContentRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            this.SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".#.syncresult", Components.ConsumeQueue, AutoDelete = false)]
        public void ProcessSyncResult(SyncResult syncResult)
        {
            if (messageContext.Current.RoutingKey.EndsWith(".tenant.syncresult"))
            {
                ProcessTenantSyncResult(syncResult);
            }
            else
            {
                var invoker = dispatcher.RemoteMicroServiceInvoker;
                var originalProperties = syncResult.Context.Properties.Clone();
                var replyTo = originalProperties.ReplyTo;
                var contentType = originalProperties.ContentType;
                var originalRoutingKey = originalProperties[Components.OriginalRoutingKey] as string;
                object response = null;
                Type type = null;
                
                var operation = this.ExtractOperation(originalRoutingKey);
                switch (operation)
                {
                    case "searchbykeyword":
                        type = typeof(SearchByKeywordResponse);
                        response = this.ExtractSearchByKeywordResponse(syncResult, contentType);
                        break;
                    case "searchbycode":
                        type = typeof(SearchByCodeResponse);
                        response = this.ExtractSearchByCodeResponse(syncResult, contentType);
                        break;
                    case "getdocument":
                        type = typeof(GetDocumentResponse);
                        response = this.ExtractGetDocumentResponse(syncResult, contentType);
                        break;
                    case "getnews":
                        type = typeof(GetNewsResponse);
                        response = this.ExtractGetNewsResponse(syncResult, contentType);
                        break;
                    case "getcategories":
                        type = typeof(GetCategoriesResponse);
                        response = this.ExtractGetCategoriesResponse(syncResult, contentType);
                        break;
                    case "getcontentbycategory":
                        type = typeof(GetContentByCategoryResponse);
                        response = this.ExtractGetContentByCategoryResponse(syncResult, contentType);
                        break;
                    case "getalphabetlists":
                        type = typeof(GetAlphabetListsResponse);
                        response = this.ExtractGetAlphabetListsResponse(syncResult, contentType);
                        break;
                    case "getcontentlistbyalphabet":
                        type = typeof(GetContentListByAlphabetResponse);
                        response = this.ExtractGetContentListByAlphabetResponse(syncResult, contentType);
                        break;
                    case "getresourcecontent":
                        type = typeof(GetResourceContentResponse);
                        response = this.ExtractGetResourceContentResponse(syncResult, contentType);
                        break;
                }

                // send response to original reply to address
                invoker.Send(replyTo, type, response, originalProperties);
            }
        }

        #region Private Methods

        private void ProcessTenantSyncResult(SyncResult syncResult)
        {
            var originalProperties = syncResult.Context.Properties;
            var originalRoutingKey = originalProperties[Components.OriginalRoutingKey] as string;
            var properties = originalProperties.Clone();
            properties.ReplyTo = null;

            var contentType = messageContext.Current.Properties.ContentType;
            var response = serializer.Deserialize<Tenant>(contentType, new MemoryStream(syncResult.Results[0].Body));

            if (response == null || string.IsNullOrWhiteSpace(response.Id) || response.Settings == null || response.Settings.Count == 0)
                throw new ApplicationException("Unable to find the tenant information.");

            var originalRequestObj = originalProperties.Get(Components.OriginalRequestKey);

            if (originalRequestObj == null)
                throw new ApplicationException("Unable to access the original request from sync service response.");

            var operationRequests = new List<OperationRequest>();

            var endLoop = false;
            foreach (var setting in response.Settings)
            {
                // append the system to the end
                var targetedRoutingAddress = string.Format("topic://{0}/{1}.{2}", Components.Exchange, originalRoutingKey, setting.Key);
                byte[] requestBody = null;

                var operation = this.ExtractOperation(originalRoutingKey);
                switch (operation)
                {
                    case "searchbykeyword":
                        requestBody = CreateSearchByKeywordBody(response, contentType, originalRequestObj);
                        break;
                    case "searchbycode":
                        requestBody = CreateSearchByCodeBody(response, contentType, originalRequestObj);
                        break;
                    case "getdocument":
                        // we dont want to use the source from the tenant info, since this request originates after a list-type call, we want to use the
                        // source from the request property to properly target the request
                        var deserializedOriginalRequest = JsonConvert.DeserializeObject<GetDocumentRequest>(originalRequestObj as string);
                        var source = deserializedOriginalRequest.Source; 
                        targetedRoutingAddress = string.Format("topic://{0}/{1}.{2}", Components.Exchange, originalRoutingKey, source);
                        requestBody = CreateGetDocumentBody(response, contentType, originalRequestObj);
                        endLoop = true;
                        break;
                    case "getnews":
                        requestBody = CreateGetNewsBody(response, contentType, originalRequestObj);
                        break;
                    case "getcategories":
                        requestBody = CreateGetCategoriesBody(response, contentType, originalRequestObj);
                        break;
                    case "getcontentbycategory":
                        // we dont want to use the source from the tenant info, since this request originates after a list-type call, we want to use the
                        // source from the request property to properly target the request
                        var deserializedGetContentByCategoryRequest = JsonConvert.DeserializeObject<GetContentByCategoryRequest>(originalRequestObj as string);
                        targetedRoutingAddress = string.Format("topic://{0}/{1}.{2}", Components.Exchange, originalRoutingKey, deserializedGetContentByCategoryRequest.Category.Source);
                        requestBody = CreateGetContentByCategoryBody(response, contentType, originalRequestObj);
                        endLoop = true;
                        break;
                    case "getalphabetlists":
                        requestBody = this.CreateGetAlphabetListsBody(response, contentType);
                        break;
                    case "getcontentlistbyalphabet":
                        requestBody = this.CreateGetContentListByAlphabetBody(response, contentType, originalRequestObj);
                        break;
                    case "getresourcecontent":
                        requestBody = this.CreateGetResourceContentBody(response, contentType, originalRequestObj);
                        break;
                }

                operationRequests.Add(new OperationRequest { Address = targetedRoutingAddress, Body = requestBody, Properties = properties });

                // need a way to stop the loop for single target requests such as GetDocument
                if (endLoop) break;
            }

            // send the sync request
            var contentServiceReplyToAddress = string.Format("topic://{0}/{1}.syncresult", Components.Exchange, originalRoutingKey);

            this.SubmitSyncRequest(operationRequests, originalProperties, contentServiceReplyToAddress);
        }

        private string ExtractOperation(string originalRoutingKey)
        {
            return originalRoutingKey.Substring(originalRoutingKey.IndexOf(Components.RoutingKeyPrefix, StringComparison.InvariantCulture) + Components.RoutingKeyPrefix.Length + 1);
        }

        private byte[] CreateSearchByKeywordBody(Tenant tenant, string contentType, object originalRequestObj)
        {
            var deserializedOriginalRequest = JsonConvert.DeserializeObject<SearchByKeywordRequest>(originalRequestObj as string);
            var request = new Entities.SearchByKeyword.SearchByKeywordRequest()
            {
                Keyword = deserializedOriginalRequest.Keyword,
                Age = deserializedOriginalRequest.BirthDate != null ? ageCalculator.CalculateAge(DateTime.Today, Convert.ToDateTime(deserializedOriginalRequest.BirthDate)) : null,
                Gender = deserializedOriginalRequest.Gender,
                LanguageCode = deserializedOriginalRequest.LanguageCode,
                TenantInfo = tenant,
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractSearchByKeywordResponse(SyncResult syncResult, string contentType)
        {
            var searchByKeywordResponse = new SearchByKeywordResponse() { ContentItems = new List<ContentItem>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.SearchByKeyword.SearchByKeywordResponse>(contentType, ms);
                    if (item.ContentItems != null)
                    {
                        searchByKeywordResponse.ContentItems.AddRange(item.ContentItems);    
                    }
                }
            }

            return searchByKeywordResponse;
        }

        private byte[] CreateSearchByCodeBody(Tenant tenant, string contentType, object originalRequestObj)
        {
            var deserializedOriginalRequest = JsonConvert.DeserializeObject<SearchByCodeRequest>(originalRequestObj as string);
            var request = new Entities.SearchByCode.SearchByCodeRequest()
            {
                Code = deserializedOriginalRequest.Code,
                CodeSystemId = deserializedOriginalRequest.CodeSystemId,
                Age = deserializedOriginalRequest.BirthDate != null ? ageCalculator.CalculateAge(DateTime.Today, Convert.ToDateTime(deserializedOriginalRequest.BirthDate)) : null,
                Gender = deserializedOriginalRequest.Gender,
                LanguageCode = deserializedOriginalRequest.LanguageCode,
                TenantInfo = tenant,
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractSearchByCodeResponse(SyncResult syncResult, string contentType)
        {
            var searchByCodeResponse = new SearchByCodeResponse() { ContentItems = new List<ContentItem>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.SearchByCode.SearchByCodeResponse>(contentType, ms);
                    if (item.ContentItems != null)
                    {
                        searchByCodeResponse.ContentItems.AddRange(item.ContentItems);
                    }
                }
            }

            return searchByCodeResponse;
        }

        private byte[] CreateGetDocumentBody(Tenant tenant, string contentType, object originalRequestObj)
        {
            var deserializedOriginalRequest = JsonConvert.DeserializeObject<GetDocumentRequest>(originalRequestObj as string);
            var request = new Entities.GetDocument.GetDocumentRequest()
            {
                ContentId = deserializedOriginalRequest.ContentId,
                ContentTypeId = deserializedOriginalRequest.ContentTypeId,
                ProductId = deserializedOriginalRequest.ProductId,
                LanguageCode = deserializedOriginalRequest.LanguageCode,
                DocumentFormat = deserializedOriginalRequest.DocumentFormat,
                TenantInfo = tenant,
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractGetDocumentResponse(SyncResult syncResult, string contentType)
        {
            var getDocumentResponse = new GetDocumentResponse() { ContentItems = new List<ContentItem>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.GetDocument.GetDocumentResponse>(contentType, ms);
                    if (item.ContentItems != null)
                    {
                        getDocumentResponse.ContentItems.AddRange(item.ContentItems);
                    }
                }
            }

            return getDocumentResponse;
        }

        private byte[] CreateGetNewsBody(Tenant tenant, string contentType, object originalRequestObj)
        {
            var deserializedOriginalRequest = JsonConvert.DeserializeObject<GetNewsRequest>(originalRequestObj as string);
            var request = new Entities.GetNews.GetNewsRequest()
            {
                LanguageCode = deserializedOriginalRequest.LanguageCode,
                MaxDocuments = deserializedOriginalRequest.MaxDocuments,
                SearchPhrase = deserializedOriginalRequest.SearchPhrase,
                TenantInfo = tenant,
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractGetNewsResponse(SyncResult syncResult, string contentType)
        {
            var getNewsResponse = new GetNewsResponse() { ContentItems = new List<ContentItem>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.GetNews.GetNewsResponse>(contentType, ms);
                    if (item.ContentItems != null)
                    {
                        getNewsResponse.ContentItems.AddRange(item.ContentItems);
                    }
                }
            }

            return getNewsResponse;
        }

        private byte[] CreateGetCategoriesBody(Tenant tenant, string contentType, object originalRequestObj)
        {
            var deserializedOriginalRequest = JsonConvert.DeserializeObject<GetCategoriesRequest>(originalRequestObj as string);
            var request = new Entities.GetCategories.GetCategoriesRequest()
            {
                TenantInfo = tenant,
                LanguageCode = deserializedOriginalRequest.LanguageCode
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractGetCategoriesResponse(SyncResult syncResult, string contentType)
        {
            var response = new GetCategoriesResponse() { Categories = new List<Category>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.GetCategories.GetCategoriesResponse>(contentType, ms);
                    if (item.Categories != null)
                    {
                        response.Categories.AddRange(item.Categories);
                    }
                }
            }

            return response;
        }

        private byte[] CreateGetContentByCategoryBody(Tenant tenant, string contentType, object originalRequestObj)
        {
            var deserializedOriginalRequest = JsonConvert.DeserializeObject<GetContentByCategoryRequest>(originalRequestObj as string);
            var request = new Entities.GetContentByCategory.GetContentByCategoryRequest()
            {
                Category = deserializedOriginalRequest.Category,
                LanguageCode = deserializedOriginalRequest.LanguageCode,
                Gender = deserializedOriginalRequest.Gender,
                Age = deserializedOriginalRequest.BirthDate != null ? ageCalculator.CalculateAge(DateTime.Today, Convert.ToDateTime(deserializedOriginalRequest.BirthDate)) : null,
                TenantInfo = tenant,
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractGetContentByCategoryResponse(SyncResult syncResult, string contentType)
        {
            var response = new GetContentByCategoryResponse() { ContentItems = new List<ContentItem>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.GetContentByCategory.GetContentByCategoryResponse>(contentType, ms);
                    if (item.ContentItems != null)
                    {
                        response.ContentItems.AddRange(item.ContentItems);
                    }
                }
            }

            return response;
        }

        private byte[] CreateGetAlphabetListsBody(Tenant tenant, string contentType)
        {
            var request = new Entities.GetAlphabetLists.GetAlphabetListsRequest()
            {
                TenantInfo = tenant,
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractGetAlphabetListsResponse(SyncResult syncResult, string contentType)
        {
            var response = new GetAlphabetListsResponse() { Alphabets = new List<Alphabet>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.GetAlphabetLists.GetAlphabetListsResponse>(contentType, ms);
                    if (item.Alphabets != null)
                    {
                        response.Alphabets.AddRange(item.Alphabets);
                    }
                }
            }

            return response;
        }

        private byte[] CreateGetContentListByAlphabetBody(Tenant tenant, string contentType, object originalRequestObj)
        {
            var deserializedOriginalRequest = JsonConvert.DeserializeObject<GetContentListByAlphabetRequest>(originalRequestObj as string);
            var request = new Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest()
            {
                ByLetter = deserializedOriginalRequest.ByLetter,
                EffectiveTime = deserializedOriginalRequest.EffectiveTime,
                LanguageCode = deserializedOriginalRequest.LanguageCode,
                Gender = deserializedOriginalRequest.Gender,
                Age = deserializedOriginalRequest.BirthDate != null ? ageCalculator.CalculateAge(DateTime.Today, Convert.ToDateTime(deserializedOriginalRequest.BirthDate)) : null,
                TenantInfo = tenant,
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractGetContentListByAlphabetResponse(SyncResult syncResult, string contentType)
        {
            var response = new GetContentListByAlphabetResponse() { ContentItems = new List<ContentItem>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.GetContentListByAlphabet.GetContentListByAlphabetResponse>(contentType, ms);
                    if (item.ContentItems != null)
                    {
                        response.ContentItems.AddRange(item.ContentItems);
                    }
                }
            }

            return response;
        }

        private byte[] CreateGetResourceContentBody(Tenant tenant, string contentType, object originalRequestObj)
        {
            var deserializedOriginalRequest = JsonConvert.DeserializeObject<GetResourceContentRequest>(originalRequestObj as string);
            var request = new Entities.GetResourceContent.GetResourceContentRequest()
            {
                DocumentPath = deserializedOriginalRequest.DocumentPath,
                LanguageCode = deserializedOriginalRequest.LanguageCode, 
                TenantInfo = tenant,
            };
            return serializer.Serialize(contentType, request);
        }

        private object ExtractGetResourceContentResponse(SyncResult syncResult, string contentType)
        {
            var response = new GetResourceContentResponse() { ContentItems = new List<ContentItem>() };

            foreach (var result in syncResult.Results)
            {
                using (var ms = new MemoryStream(result.Body))
                {
                    var item = serializer.Deserialize<Entities.GetResourceContent.GetResourceContentResponse>(contentType, ms);
                    if (item.ContentItems != null)
                    {
                        response.ContentItems.AddRange(item.ContentItems);
                    }
                }
            }

            return response;
        }

        private void SubmitTenantRequest(Tenant tenant, string originalRequest)
        {
            var contentType = messageContext.Current.Properties.ContentType;
            var originalProperties = messageContext.Current.Properties.Clone();
            originalProperties.Set(Components.OriginalRequestKey, originalRequest);
            originalProperties.Set(Components.OriginalRoutingKey, messageContext.Current.RoutingKey);
            var operationProperties = originalProperties.Clone();
            operationProperties.ReplyTo = null;
            
            var registerBody = serializer.Serialize(contentType, tenant);
            var operationRequests = new List<OperationRequest>
                                 {
                                     new OperationRequest
                                         {
                                             Address = Components.AddressOfTenantGet,
                                             Body = registerBody,
                                             Properties = operationProperties
                                         }
                                 };

            var messageQueueAddress = string.Format("topic://{0}/{1}.tenant.syncresult", Components.Exchange, messageContext.Current.RoutingKey);

            this.SubmitSyncRequest(operationRequests, originalProperties, messageQueueAddress);
        }

        private void SubmitSyncRequest(List<OperationRequest> operationRequests, MessageProperties originalProperties, string replyToAddress)
        {
            var syncRequest = new SyncRequest
            {
                Context = new OperationRequest { Address = string.Format("topic://{0}/{1}", Components.Exchange, messageContext.Current.RoutingKey), Properties = originalProperties },
                Operations = operationRequests,
            };

            using (messageContext.Enter())
            {
                var properties = messageContext.Current.Properties;
                properties.ReplyTo = new MqAddress(replyToAddress);
                syncService.Request(syncRequest);
            }
        }

        #endregion
    }
}
