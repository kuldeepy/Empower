﻿namespace ContentService.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;

    using Medseek.Platform.Services.ContentService;
    using Medseek.Platform.Services.ContentService.AgeCalculator;
    using Medseek.Platform.Services.ContentService.Entities;
    using Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists;
    using Medseek.Platform.Services.ContentService.Entities.SearchByCode;
    using Medseek.Platform.Services.ContentService.Entities.Sync;
    using Medseek.Platform.Services.ContentService.Entities.TenantInfo;
    using Medseek.Platform.Services.ContentService.Serializer;
    using Medseek.Platform.Services.ContentService.ServiceEntities;
    using Medseek.Util.Messaging;
    using Medseek.Util.MicroServices;
    using Moq;
    using NUnit.Framework;

    using GetAlphabetListsRequest = Medseek.Platform.Services.ContentService.ServiceEntities.GetAlphabetListsRequest;
    using SearchByCodeRequest = Medseek.Platform.Services.ContentService.ServiceEntities.SearchByCodeRequest;
    using SearchByCodeResponse = Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeResponse;
    using SearchByKeywordRequest = Medseek.Platform.Services.ContentService.ServiceEntities.SearchByKeywordRequest;
    using SearchByKeywordResponse = Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordResponse;

    [TestFixture]
    public class ContentServiceTests
    {
        private const string TenantSearchByKeywordSyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.searchbykeyword.tenant.syncresult";
        private const string TenantSyncRoutingKey = "medseek.platform.services.contentservice.searchbykeyword.tenant.syncresult";
        private const string TenantId = "tenantId";
        private const string OriginalKeywordRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Keyword\":\"keyword\",\"BirthDate\":\"12/20/1976\",\"Gender\":\"M\",\"LanguageCode\":\"en\"}";
        private const string OriginalKeywordRequestWithoutBirthdate = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Keyword\":\"keyword\",\"BirthDate\":null,\"Gender\":\"M\",\"LanguageCode\":\"en\"}";
        private const string TenantRequestBody = "TenantRequestBody";
        private const string SearchByKeywordRequestBody = "SearchByKeywordRequestBody";
        private const string KeywordContextAddress = "topic://medseek-api/medseek.platform.services.contentservice.searchbykeyword";
        private const string ReplyToAddress = "topic://medseek-api/ReplyToAddress";
        private const string OriginalKeywordRoutingKey = "medseek.platform.services.contentservice.searchbykeyword";
        private const string TargetedKeywordAddress = "topic://medseek-api/medseek.platform.services.contentservice.searchbykeyword.krames";
        private const string AlternateTargetedKeywordAddress = "topic://medseek-api/medseek.platform.services.contentservice.searchbykeyword.healthwise";
        private const string SyncKeywordReplyRoutingKey = "medseek.platform.services.contentservice.searchbykeyword.syncresult";
        private const string TargetedKeywordReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.searchbykeyword.syncresult";
        private const string TenantGetAddress = "topic://medseek-api/medseek.platform.services.tenantservice.get";

        private const string TenantSearchByCodeSyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.searchbycode.tenant.syncresult";
        private const string OriginalCodeRoutingKey = "medseek.platform.services.contentservice.searchbycode";
        private const string OriginalCodeRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Code\":\"code\",\"CodeSystemId\":\"codeSystemId\",\"BirthDate\":\"12/20/1976\",\"Gender\":\"M\",\"LanguageCode\":\"en\"}";
        private const string OriginalCodeRequestWithoutBirthdate = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Code\":\"code\",\"CodeSystemId\":\"codeSystemId\",\"BirthDate\":null,\"Gender\":\"M\",\"LanguageCode\":\"en\"}";
        private const string SyncCodeReplyRoutingKey = "medseek.platform.services.contentservice.searchbycode.syncresult";
        private const string TargetedCodeReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.searchbycode.syncresult";

        private const string TenantGetDocumentSyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getdocument.tenant.syncresult";
        private const string TargetedGetDocumentAddress = "topic://medseek-api/medseek.platform.services.contentservice.getdocument.getdocumentsource";
        private const string OriginalGetDocumentRoutingKey = "medseek.platform.services.contentservice.getdocument";
        private const string OriginalGetDocumentRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Source\":\"getdocumentsource\",\"ContentTypeId\":\"contentTypeId\",\"ContentId\":\"contentId\",\"LanguageCode\":\"lang\",\"DocumentFormat\":\"pdf\",\"ProductId\":\"123\"}";
        private const string SyncGetDocumentReplyRoutingKey = "medseek.platform.services.contentservice.getdocument.syncresult";
        private const string TargetedGetDocumentReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getdocument.syncresult";
        private const string GetDocumentRequestBody = "GetDocumentRequestBody";

        private const string TenantGetNewsSyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getnews.tenant.syncresult";
        private const string OriginalGetNewsRoutingKey = "medseek.platform.services.contentservice.getnews";
        private const string OriginalGetNewsRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"SearchPhrase\":\"searchPhrase\",\"MaxDocuments\":\"maxDocuments\",\"LanguageCode\":\"languageCode\"}";
        private const string SyncGetNewsReplyRoutingKey = "medseek.platform.services.contentservice.getnews.syncresult";
        private const string TargetedGetNewsReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getnews.syncresult";

        private const string TenantGetCategoriesSyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getcategories.tenant.syncresult";
        private const string OriginalGetCategoriesRoutingKey = "medseek.platform.services.contentservice.getcategories";
        private const string OriginalGetCategoriesRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null}, \"LanguageCode\":\"en\"}";
        private const string SyncGetCategoriesReplyRoutingKey = "medseek.platform.services.contentservice.getcategories.syncresult";
        private const string TargetedGetCategoriesReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getcategories.syncresult";

        private const string TenantGetContentByCategorySyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getcontentbycategory.tenant.syncresult";
        private const string OriginalGetContentByCategoryRoutingKey = "medseek.platform.services.contentservice.getcontentbycategory";
        private const string OriginalGetContentByCategoryRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Category\":{\"Id\":\"id1\",\"Name\":\"name1\",\"Source\":\"source1\"},\"BirthDate\":\"12/20/1976\",\"Gender\":\"M\",\"LanguageCode\":\"en\"}";
        private const string OriginalGetContentByCategoryRequestWithoutBirthdate = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Category\":{\"Id\":\"id1\",\"Name\":\"name1\",\"Source\":\"source1\"},\"BirthDate\":null,\"Gender\":\"M\",\"LanguageCode\":\"en\"}";
        private const string SyncGetContentByCategoryReplyRoutingKey = "medseek.platform.services.contentservice.getcontentbycategory.syncresult";
        private const string TargetedGetContentByCategoryReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getcontentbycategory.syncresult";
        private const string GetContentByCategoryRequestBody = "GetContentByCategoryRequestBody";
        private const string TargetedGetContentByCategoryAddress = "topic://medseek-api/medseek.platform.services.contentservice.getcontentbycategory.source1";

        private const string TenantGetAlphabetListsSyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getalphabetlists.tenant.syncresult";
        private const string OriginalGetAlphabetListsRoutingKey = "medseek.platform.services.contentservice.getalphabetlists";
        private const string OriginalGetAlphabetListsRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null}}";
        private const string SyncGetAlphabetListsReplyRoutingKey = "medseek.platform.services.contentservice.getalphabetlists.syncresult";
        private const string TargetedGetAlphabetListsReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getalphabetlists.syncresult";

        private const string TenantGetContentListByAlphabetSyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getcontentlistbyalphabet.tenant.syncresult";
        private const string OriginalGetContentListByAlphabetRoutingKey = "medseek.platform.services.contentservice.getcontentlistbyalphabet";
        private const string OriginalGetContentListByAlphabetRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"ByLetter\":\"letter\",\"EffectiveTime\":\"20090101\",\"Gender\":\"M\",\"LanguageCode\":\"en\",\"BirthDate\":\"12/20/1976\"}";
        private const string OriginalGetContentListByAlphabetRequestWithoutBirthdate = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"ByLetter\":\"letter\",\"EffectiveTime\":\"20090101\",\"Gender\":\"M\",\"LanguageCode\":\"en\",\"BirthDate\":null}";
        private const string SyncGetContentListByAlphabetReplyRoutingKey = "medseek.platform.services.contentservice.getcontentlistbyalphabet.syncresult";
        private const string TargetedGetContentListByAlphabetReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getcontentlistbyalphabet.syncresult";

        private const string TenantGetResourceContentSyncReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getresourcecontent.tenant.syncresult";
        private const string OriginalGetResourceContentRoutingKey = "medseek.platform.services.contentservice.getresourcecontent";
        private const string OriginalGetResourceContentRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"DocumentPath\":\"media/medical/hw/h9991278_001_pi.jpg\",\"LanguageCode\":\"en-us\"}";
        private const string SyncGetResourceContentReplyRoutingKey = "medseek.platform.services.contentservice.getresourcecontent.syncresult";
        private const string TargetedGetResourceContentReplyAddress = "topic://medseek-api/medseek.platform.services.contentservice.getresourcecontent.syncresult";

        private Mock<IMicroServiceDispatcher> dispatcher;
        private Mock<IMessageContextAccess> messageContext;
        private Mock<IContentSerializer> serializer;
        private Mock<ISyncService> syncService;
        private Mock<IAgeCalculator> ageCalculator;
        private ContentService service;
        private SearchByKeywordRequest searchByKeywordRequest;
        private SearchByCodeRequest searchByCodeRequest;
        private GetDocumentRequest getDocumentRequest;
        private GetNewsRequest getNewsRequest;
        private GetCategoriesRequest getCategoriesRequest;
        private GetContentByCategoryRequest getContentByCategoryRequest;
        private GetAlphabetListsRequest getAlphabetListsRequest;
        private GetContentListByAlphabetRequest getContentListByAlphabetRequest;
        private GetResourceContentRequest getResourceContentRequest;
        private Mock<IRemoteMicroServiceInvoker> invoker;
        private ContentItem contentItemOne;
        private ContentItem contentItemTwo;
        private Category categoryOne;
        private Category categoryTwo;
        private Alphabet alphabetOne;
        private Alphabet alphabetTwo;

        [SetUp]
        public void Setup()
        {
            invoker = new Mock<IRemoteMicroServiceInvoker>();
            dispatcher = new Mock<IMicroServiceDispatcher>();
            messageContext = new Mock<IMessageContextAccess>();
            serializer = new Mock<IContentSerializer>();
            syncService = new Mock<ISyncService>();
            ageCalculator = new Mock<IAgeCalculator>();
            service = new Medseek.Platform.Services.ContentService.ContentService(dispatcher.Object, messageContext.Object, serializer.Object, syncService.Object, ageCalculator.Object);

            searchByKeywordRequest = new SearchByKeywordRequest()
                                            {
                                                Keyword = "keyword",
                                                BirthDate = "12/20/1976",
                                                Gender = "M",
                                                LanguageCode = "en",
                                                TenantInfo = new Tenant() { Id = "tenantId" }
                                            };

            searchByCodeRequest = new SearchByCodeRequest()
                                      {
                                          Code = "code",
                                          CodeSystemId = "codeSystemId",
                                          BirthDate = "12/20/1976",
                                          Gender = "M",
                                          LanguageCode = "en",
                                          TenantInfo = new Tenant() { Id = "tenantId" }
                                      };

            getDocumentRequest = new GetDocumentRequest()
                                     {
                                         ContentId = "contentId",
                                         ContentTypeId = "contentTypeId",
                                         TenantInfo = new Tenant() { Id = "tenantId" },
                                         LanguageCode = "lang",
                                         ProductId = "123",
                                         DocumentFormat = "pdf",
                                         Source = "getdocumentsource"
                                     };

            getNewsRequest = new GetNewsRequest()
                                 {
                                     LanguageCode = "languageCode",
                                     MaxDocuments = "maxDocuments",
                                     SearchPhrase = "searchPhrase",
                                     TenantInfo = new Tenant() { Id = "tenantId" }
                                 };

            getCategoriesRequest = new GetCategoriesRequest() { TenantInfo = new Tenant() { Id = "tenantId" }, LanguageCode = "en" };

            getContentByCategoryRequest = new GetContentByCategoryRequest()
                                              {
                                                  Category = new Category() { Id = "id1", Name = "name1", Source = "source1" },
                                                  BirthDate = "12/20/1976",
                                                  Gender = "M",
                                                  LanguageCode = "en",
                                                  TenantInfo = new Tenant() { Id = "tenantId" }
                                              };

            getAlphabetListsRequest = new GetAlphabetListsRequest() { TenantInfo = new Tenant() { Id = "tenantId" } };

            getContentListByAlphabetRequest = new GetContentListByAlphabetRequest()
                                                  {
                                                      ByLetter = "letter",
                                                      BirthDate = "12/20/1976",
                                                      EffectiveTime = "20090101",
                                                      Gender = "M",
                                                      LanguageCode = "en",
                                                      TenantInfo = new Tenant()
                                                              {
                                                                  Id = "tenantId"
                                                              }
                                                  };

            getResourceContentRequest = new GetResourceContentRequest()
                                            {
                                                TenantInfo = new Tenant() { Id = "tenantId" }
                                            };

            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, OriginalKeywordRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            ageCalculator.Setup(c => c.CalculateAge(It.IsAny<DateTime>(), It.IsAny<DateTime>())).Returns(new Age() { Days = 1, Months = 4, Years = 35 });
            dispatcher.SetupGet(c => c.RemoteMicroServiceInvoker).Returns(invoker.Object);

            contentItemOne = new ContentItem()
                                 {
                                     Content = "contentData",
                                     Gender = "M",
                                     Language = "en",
                                     Link = "link",
                                     Title = "title",
                                     Source = "source1",
                                     ContentType = "contentType",
                                     PostingDate = "07/25/2014",
                                     ContentId = "contentId",
                                     ContentTypeId = "contentTypeId",
                                     Description = "descriptionOne"
                                 };

            contentItemTwo = new ContentItem()
            {
                Content = "contentData2",
                Gender = "M",
                Language = "en",
                Link = "link2",
                Title = "title2",
                Source = "source2",
                ContentType = "contentType2",
                PostingDate = "07/26/2014",
                ContentId = "contentId2",
                ContentTypeId = "contentTypeId2",
                Description = "descriptionTwo"
            };

            categoryOne = new Category() { Id = "id1", Name = "name1", Source = "source1" };
            categoryTwo = new Category() { Id = "id2", Name = "name2", Source = "source2" };

            alphabetOne = new Alphabet() { Letter = "A", Source = "source1" };
            alphabetTwo = new Alphabet() { Letter = "B", Source = "source1" };
        }

        #region constructor
        [Test]
        public void Ctor_CanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ContentService>(service);
        }

        [Test]
        public void Ctor_NullDispatcher_ExceptionIsThrown()
        {
            TestDelegate action = () => new Medseek.Platform.Services.ContentService.ContentService(null, messageContext.Object, serializer.Object, syncService.Object, ageCalculator.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullContext_ExceptionIsThrown()
        {
            TestDelegate action = () => new Medseek.Platform.Services.ContentService.ContentService(dispatcher.Object, null, serializer.Object, syncService.Object, ageCalculator.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullSerializer_ExceptionIsThrown()
        {
            TestDelegate action = () => new Medseek.Platform.Services.ContentService.ContentService(dispatcher.Object, messageContext.Object, null, syncService.Object, ageCalculator.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullSyncService_ExceptionIsThrown()
        {
            TestDelegate action = () => new Medseek.Platform.Services.ContentService.ContentService(dispatcher.Object, messageContext.Object, serializer.Object, null, ageCalculator.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullAgeCalculator_ExceptionIsThrown()
        {
            TestDelegate action = () => new Medseek.Platform.Services.ContentService.ContentService(dispatcher.Object, messageContext.Object, serializer.Object, syncService.Object, null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }
        #endregion

        #region search by keyword and tenant
        [Test]
        public void SearchByKeyword_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.SearchByKeyword(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchByKeyword_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.SearchByKeyword(new SearchByKeywordRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void SearchByKeyword_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.SearchByKeyword(new SearchByKeywordRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void SearchByKeyword_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.SearchByKeyword(searchByKeywordRequest);
            syncService.Verify();
        }

        [Test]
        public void SearchByKeyword_ValidRequest_SyncServiceRequestIsCalledWithExpectedValues()
        {
            // variable to capture the request parameter for later validation
            SyncRequest actualRequest = null;

            // setup the mock to capture the parameter
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Callback<SyncRequest>((request) => { actualRequest = request; });

            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Tenant>())).Returns(Encoding.UTF8.GetBytes(TenantRequestBody));
            service.SearchByKeyword(searchByKeywordRequest);

            Assert.IsNotNull(actualRequest);
            Assert.AreEqual(KeywordContextAddress, actualRequest.Context.Address);
            Assert.IsNotNull(actualRequest.Context.Properties);
            Assert.AreEqual("application/xml", actualRequest.Context.Properties.ContentType);
            Assert.AreEqual(ReplyToAddress, actualRequest.Context.Properties.ReplyToString);
            Assert.AreEqual(OriginalKeywordRoutingKey, actualRequest.Context.Properties.AdditionalProperties["contentservice.originalroutingkey"]);
            Assert.AreEqual(OriginalKeywordRequest, actualRequest.Context.Properties.AdditionalProperties["contentservice.originalrequest"]);
            Assert.IsNotNull(actualRequest.Operations);
            Assert.AreEqual(1, actualRequest.Operations.Count);
            Assert.AreEqual(TenantGetAddress, actualRequest.Operations[0].Address);
            Assert.AreEqual(TenantRequestBody, Encoding.UTF8.GetString(actualRequest.Operations[0].Body));
            Assert.AreEqual("application/xml", actualRequest.Operations[0].Properties.ContentType);
            Assert.IsNull(actualRequest.Operations[0].Properties.ReplyToString);
            Assert.AreEqual(OriginalKeywordRoutingKey, actualRequest.Operations[0].Properties.AdditionalProperties["contentservice.originalroutingkey"]);
            Assert.AreEqual(TenantSearchByKeywordSyncReplyAddress, messageContext.Object.Current.Properties.ReplyToString);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_ResponseIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest() { Properties = new MessageProperties() { AdditionalProperties = new Dictionary<string, object>() { { "contentservice.originalroutingkey", OriginalKeywordRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByKeywordSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns((Tenant)null);

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_ResponseIdIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest() { Properties = new MessageProperties() { AdditionalProperties = new Dictionary<string, object>() { { "contentservice.originalroutingkey", OriginalKeywordRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByKeywordSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant());

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_ResponseSettingsIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest() { Properties = new MessageProperties() { AdditionalProperties = new Dictionary<string, object>() { { "contentservice.originalroutingkey", OriginalKeywordRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByKeywordSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = null });

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_ResponseSettingsIsEmpty_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest() { Properties = new MessageProperties() { AdditionalProperties = new Dictionary<string, object>() { { "contentservice.originalroutingkey", OriginalKeywordRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByKeywordSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() });

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestObjIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult()
                                 {
                                     Context =
                                         new OperationRequest()
                                             {
                                                 Properties =
                                                     new MessageProperties()
                                                         {
                                                             AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey }
                                                                     }
                                                         }
                                             },
                                     Results = new OperationResult[] 
                                             {
                                                 new OperationResult() { Body = new byte[0] } 
                                             }
                                 };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByKeywordSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsSearchByKeyword_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                            {
                                AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalKeywordRequest }
                                                                     }
                            }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByKeywordSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Age);
            Assert.AreEqual(1, actualRequest.Age.Days);
            Assert.AreEqual(4, actualRequest.Age.Months);
            Assert.AreEqual(35, actualRequest.Age.Years);
            Assert.AreEqual("M", actualRequest.Gender);
            Assert.AreEqual("keyword", actualRequest.Keyword);
            Assert.AreEqual("en", actualRequest.LanguageCode);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsSearchByKeyword_BirthDateIsNull_SerializerIsCalledWithNullAge()
        {
            Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalKeywordRequestWithoutBirthdate }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByKeywordSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNull(actualRequest.Age);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsSearchByKeyword_SyncServiceIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalKeywordRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByKeywordSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<object>())).Returns(Encoding.UTF8.GetBytes(SearchByKeywordRequestBody));
            service.ProcessSyncResult(syncResult);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsSearchByKeyword_SyncServiceIsCalledWithProperParams()
        {
            // variable to capture the request parameter for later validation
            SyncRequest actualRequest = null;

            // setup the mock to capture the parameter
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Callback<SyncRequest>((request) => { actualRequest = request; });

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalKeywordRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSyncRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest>())).Returns(Encoding.UTF8.GetBytes(SearchByKeywordRequestBody));
            service.ProcessSyncResult(syncResult);

            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Operations);
            Assert.AreEqual(1, actualRequest.Operations.Count);
            Assert.AreEqual(TargetedKeywordAddress, actualRequest.Operations[0].Address);
            Assert.AreEqual(SearchByKeywordRequestBody, Encoding.UTF8.GetString(actualRequest.Operations[0].Body));
            Assert.AreEqual(TargetedKeywordReplyAddress, messageContext.Object.Current.Properties.ReplyToString);
        }

        [Test]
        public void ProcessSyncResult_SearchByKeywordSyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalKeywordRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncKeywordReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedKeywordReplyAddress) }));
            serializer.Setup(c => c.Deserialize<SearchByKeywordResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new SearchByKeywordResponse() { ContentItems = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.SearchByKeywordResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.SearchByKeywordResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
            for (int i = 0; i < response.ContentItems.Count; i++)
            {
                Assert.AreEqual(items[i].ContentId, response.ContentItems[i].ContentId);
                Assert.AreEqual(items[i].ContentTypeId, response.ContentItems[i].ContentTypeId);
                Assert.AreEqual(items[i].ContentType, response.ContentItems[i].ContentType);
                Assert.AreEqual(items[i].Content, response.ContentItems[i].Content);
                Assert.AreEqual(items[i].Description, response.ContentItems[i].Description);
                Assert.AreEqual(items[i].Gender, response.ContentItems[i].Gender);
                Assert.AreEqual(items[i].Language, response.ContentItems[i].Language);
                Assert.AreEqual(items[i].Link, response.ContentItems[i].Link);
                Assert.AreEqual(items[i].PostingDate, response.ContentItems[i].PostingDate);
                Assert.AreEqual(items[i].Source, response.ContentItems[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_SearchByKeywordSyncResult_ContentItemCollectionInResponseIsNull_ResponseContainsNoItems()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalKeywordRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncKeywordReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedKeywordReplyAddress) }));
            serializer.Setup(c => c.Deserialize<SearchByKeywordResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new SearchByKeywordResponse() { ContentItems = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.SearchByKeywordResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.SearchByKeywordResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }
        #endregion

        #region search by code
        [Test]
        public void SearchByCode_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.SearchByCode(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchByCode_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.SearchByCode(new SearchByCodeRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void SearchByCode_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.SearchByCode(new SearchByCodeRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void SearchByCode_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.SearchByCode(searchByCodeRequest);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsSearchByCode_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalCodeRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalCodeRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByCodeSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Age);
            Assert.AreEqual(1, actualRequest.Age.Days);
            Assert.AreEqual(4, actualRequest.Age.Months);
            Assert.AreEqual(35, actualRequest.Age.Years);
            Assert.AreEqual("M", actualRequest.Gender);
            Assert.AreEqual("code", actualRequest.Code);
            Assert.AreEqual("codeSystemId", actualRequest.CodeSystemId);
            Assert.AreEqual("en", actualRequest.LanguageCode);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsSearchByCode_BirthDateIsNull_SerializerIsCalledWithNullAge()
        {
            Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalCodeRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalCodeRequestWithoutBirthdate }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSearchByCodeSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.SearchByCode.SearchByCodeRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNull(actualRequest.Age);
        }

        [Test]
        public void ProcessSyncResult_SearchByCodeSyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalCodeRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalCodeRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncCodeReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedCodeReplyAddress) }));
            serializer.Setup(c => c.Deserialize<SearchByCodeResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new SearchByCodeResponse() { ContentItems = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.SearchByCodeResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.SearchByCodeResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
            for (int i = 0; i < response.ContentItems.Count; i++)
            {
                Assert.AreEqual(items[i].ContentId, response.ContentItems[i].ContentId);
                Assert.AreEqual(items[i].ContentTypeId, response.ContentItems[i].ContentTypeId);
                Assert.AreEqual(items[i].ContentType, response.ContentItems[i].ContentType);
                Assert.AreEqual(items[i].Content, response.ContentItems[i].Content);
                Assert.AreEqual(items[i].Description, response.ContentItems[i].Description);
                Assert.AreEqual(items[i].Gender, response.ContentItems[i].Gender);
                Assert.AreEqual(items[i].Language, response.ContentItems[i].Language);
                Assert.AreEqual(items[i].Link, response.ContentItems[i].Link);
                Assert.AreEqual(items[i].PostingDate, response.ContentItems[i].PostingDate);
                Assert.AreEqual(items[i].Source, response.ContentItems[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_SearchByCodeSyncResult_ResponseContentItemCollectionIsNull_ResponseContainsNoContentItems()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalCodeRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalCodeRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncCodeReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedCodeReplyAddress) }));
            serializer.Setup(c => c.Deserialize<SearchByCodeResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new SearchByCodeResponse() { ContentItems = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.SearchByCodeResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.SearchByCodeResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }
        #endregion

        #region get document
        [Test]
        public void GetDocument_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetDocument(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetDocument_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetDocument(new GetDocumentRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetDocument_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetDocument(new GetDocumentRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetDocument_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.GetDocument(getDocumentRequest);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetDocument_SyncServiceIsCalledWithProperParams()
        {
            // variable to capture the request parameter for later validation
            SyncRequest actualRequest = null;

            // setup the mock to capture the parameter
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Callback<SyncRequest>((request) => { actualRequest = request; });

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetDocumentRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetDocumentRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSyncRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentRequest>())).Returns(Encoding.UTF8.GetBytes(GetDocumentRequestBody));
            service.ProcessSyncResult(syncResult);

            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Operations);
            Assert.AreEqual(1, actualRequest.Operations.Count);
            Assert.AreEqual(TargetedGetDocumentAddress, actualRequest.Operations[0].Address);
            Assert.AreEqual(GetDocumentRequestBody, Encoding.UTF8.GetString(actualRequest.Operations[0].Body));
            Assert.AreEqual(TargetedGetDocumentReplyAddress, messageContext.Object.Current.Properties.ReplyToString);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetDocument_MultipleSettingsReturned_SyncRequestOnlyHasOneOperationAndTargetedBasedOnSourceOfRequest()
        {
            // variable to capture the request parameter for later validation
            SyncRequest actualRequest = null;

            // setup the mock to capture the parameter
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Callback<SyncRequest>((request) => { actualRequest = request; });

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetDocumentRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetDocumentRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSyncRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } }, new KeySettingsPair() { Key = "othersettings", Settings = new Settings() { BaseUrl = "url2", LicenseKey = "key" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentRequest>())).Returns(Encoding.UTF8.GetBytes(GetDocumentRequestBody));
            service.ProcessSyncResult(syncResult);

            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Operations);
            Assert.AreEqual(1, actualRequest.Operations.Count);
            Assert.AreEqual(TargetedGetDocumentAddress, actualRequest.Operations[0].Address);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetDocument_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetDocumentRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetDocumentRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetDocumentSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual(getDocumentRequest.ContentId, actualRequest.ContentId);
            Assert.AreEqual(getDocumentRequest.ContentTypeId, actualRequest.ContentTypeId);
            Assert.AreEqual(getDocumentRequest.ProductId, actualRequest.ProductId);
            Assert.AreEqual(getDocumentRequest.DocumentFormat, actualRequest.DocumentFormat);
            Assert.AreEqual(getDocumentRequest.LanguageCode, actualRequest.LanguageCode);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
        }

        [Test]
        public void ProcessSyncResult_GetDocumentSyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetDocumentRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetDocumentRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetDocumentReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetDocumentReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentResponse() { ContentItems = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetDocumentResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetDocumentResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
            for (int i = 0; i < response.ContentItems.Count; i++)
            {
                Assert.AreEqual(items[i].ContentId, response.ContentItems[i].ContentId);
                Assert.AreEqual(items[i].ContentTypeId, response.ContentItems[i].ContentTypeId);
                Assert.AreEqual(items[i].ContentType, response.ContentItems[i].ContentType);
                Assert.AreEqual(items[i].Content, response.ContentItems[i].Content);
                Assert.AreEqual(items[i].Description, response.ContentItems[i].Description);
                Assert.AreEqual(items[i].Gender, response.ContentItems[i].Gender);
                Assert.AreEqual(items[i].Language, response.ContentItems[i].Language);
                Assert.AreEqual(items[i].Link, response.ContentItems[i].Link);
                Assert.AreEqual(items[i].PostingDate, response.ContentItems[i].PostingDate);
                Assert.AreEqual(items[i].Source, response.ContentItems[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_GetDocumentSyncResult_ContentItemCollectionInResponseIsNull_ResponseContainsNoItems()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetDocumentRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetDocumentRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetDocumentReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetDocumentReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetDocument.GetDocumentResponse() { ContentItems = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetDocumentResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetDocumentResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }

        #endregion

        #region get news
        [Test]
        public void GetNews_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetNews(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetNews_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetNews(new GetNewsRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetNews_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetNews(new GetNewsRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetNews_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.GetNews(getNewsRequest);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetNews_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.GetNews.GetNewsRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetNewsRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetNewsRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetNewsSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetNews.GetNewsRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetNews.GetNewsRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetNews.GetNewsRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.AreEqual(getNewsRequest.MaxDocuments, actualRequest.MaxDocuments);
            Assert.AreEqual(getNewsRequest.SearchPhrase, actualRequest.SearchPhrase);
            Assert.AreEqual(getNewsRequest.LanguageCode, actualRequest.LanguageCode);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
        }

        [Test]
        public void ProcessSyncResult_GetNewsSyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetNewsRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetNewsRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetNewsReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetNewsReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetNews.GetNewsResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetNews.GetNewsResponse() { ContentItems = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetNewsResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetNewsResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
            for (int i = 0; i < response.ContentItems.Count; i++)
            {
                Assert.AreEqual(items[i].ContentId, response.ContentItems[i].ContentId);
                Assert.AreEqual(items[i].ContentTypeId, response.ContentItems[i].ContentTypeId);
                Assert.AreEqual(items[i].ContentType, response.ContentItems[i].ContentType);
                Assert.AreEqual(items[i].Content, response.ContentItems[i].Content);
                Assert.AreEqual(items[i].Description, response.ContentItems[i].Description);
                Assert.AreEqual(items[i].Gender, response.ContentItems[i].Gender);
                Assert.AreEqual(items[i].Language, response.ContentItems[i].Language);
                Assert.AreEqual(items[i].Link, response.ContentItems[i].Link);
                Assert.AreEqual(items[i].PostingDate, response.ContentItems[i].PostingDate);
                Assert.AreEqual(items[i].Source, response.ContentItems[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_GetNewsSyncResult_ContentItemsInResponseIsNull_ResponseContainsNoContentItems()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetNewsRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetNewsRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetNewsReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetNewsReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetNews.GetNewsResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetNews.GetNewsResponse() { ContentItems = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetNewsResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetNewsResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }
        #endregion

        #region get categories
        [Test]
        public void GetCategories_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetCategories(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetCategories_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetCategories(new GetCategoriesRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetCategories_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetCategories(new GetCategoriesRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetCategories_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.GetCategories(getCategoriesRequest);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetCategories_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.GetCategories.GetCategoriesRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetCategoriesRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetCategoriesRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetCategoriesSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetCategories.GetCategoriesRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetCategories.GetCategoriesRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetCategories.GetCategoriesRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
            Assert.AreEqual("en", actualRequest.LanguageCode);
        }

        [Test]
        public void ProcessSyncResult_GetCategoriesSyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetCategoriesRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetCategoriesRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var items = new List<Category>() { categoryOne, categoryTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetCategoriesReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetCategoriesReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetCategories.GetCategoriesResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetCategories.GetCategoriesResponse() { Categories = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetCategoriesResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetCategoriesResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Categories);
            Assert.AreEqual(2, response.Categories.Count);
            for (int i = 0; i < response.Categories.Count; i++)
            {
                Assert.AreEqual(items[i].Id, response.Categories[i].Id);
                Assert.AreEqual(items[i].Name, response.Categories[i].Name);
                Assert.AreEqual(items[i].Source, response.Categories[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_GetCategoriesSyncResult_CategoriesInResponseIsNull_ResponseContainsNoCategories()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetCategoriesRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetCategoriesRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var items = new List<Category>() { categoryOne, categoryTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetCategoriesReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetCategoriesReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetCategories.GetCategoriesResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetCategories.GetCategoriesResponse() { Categories = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetCategoriesResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetCategoriesResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Categories);
            Assert.AreEqual(0, response.Categories.Count);
        }
        #endregion

        #region get content by category
        [Test]
        public void GetContentByCategory_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetContentByCategory(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetContentByCategory_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetContentByCategory_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetContentByCategory_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.GetContentByCategory(getContentByCategoryRequest);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetContentByCategory_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentByCategoryRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentByCategoryRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetContentByCategorySyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Age);
            Assert.AreEqual(1, actualRequest.Age.Days);
            Assert.AreEqual(4, actualRequest.Age.Months);
            Assert.AreEqual(35, actualRequest.Age.Years);
            Assert.AreEqual("M", actualRequest.Gender);
            Assert.IsNotNull(actualRequest.Category);
            Assert.AreEqual(categoryOne.Id, actualRequest.Category.Id);
            Assert.AreEqual(categoryOne.Name, actualRequest.Category.Name);
            Assert.AreEqual(categoryOne.Source, actualRequest.Category.Source);
            Assert.AreEqual("en", actualRequest.LanguageCode);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetContentByCategory_BirthDateIsNull_SerializerIsCalledWithNullAge()
        {
            Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentByCategoryRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentByCategoryRequestWithoutBirthdate }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetContentByCategorySyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNull(actualRequest.Age);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetContentByCategory_MultipleSettingsReturned_SyncRequestOnlyHasOneOperationAndTargetedBasedOnSourceOfCategoryInRequest()
        {
            // variable to capture the request parameter for later validation
            SyncRequest actualRequest = null;

            // setup the mock to capture the parameter
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Callback<SyncRequest>((request) => { actualRequest = request; });

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentByCategoryRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentByCategoryRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSyncRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } }, new KeySettingsPair() { Key = "othersettings", Settings = new Settings() { BaseUrl = "url2", LicenseKey = "key" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryRequest>())).Returns(Encoding.UTF8.GetBytes(GetContentByCategoryRequestBody));
            service.ProcessSyncResult(syncResult);

            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Operations);
            Assert.AreEqual(1, actualRequest.Operations.Count);
            Assert.AreEqual(TargetedGetContentByCategoryAddress, actualRequest.Operations[0].Address);
        }

        [Test]
        public void ProcessSyncResult_GetContentByCategorySyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentByCategoryRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentByCategoryRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetContentByCategoryReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetContentByCategoryReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryResponse() { ContentItems = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetContentByCategoryResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetContentByCategoryResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
            for (int i = 0; i < response.ContentItems.Count; i++)
            {
                Assert.AreEqual(items[i].ContentId, response.ContentItems[i].ContentId);
                Assert.AreEqual(items[i].ContentTypeId, response.ContentItems[i].ContentTypeId);
                Assert.AreEqual(items[i].ContentType, response.ContentItems[i].ContentType);
                Assert.AreEqual(items[i].Content, response.ContentItems[i].Content);
                Assert.AreEqual(items[i].Description, response.ContentItems[i].Description);
                Assert.AreEqual(items[i].Gender, response.ContentItems[i].Gender);
                Assert.AreEqual(items[i].Language, response.ContentItems[i].Language);
                Assert.AreEqual(items[i].Link, response.ContentItems[i].Link);
                Assert.AreEqual(items[i].PostingDate, response.ContentItems[i].PostingDate);
                Assert.AreEqual(items[i].Source, response.ContentItems[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_GetContentByCategorySyncResult_ContentItemsInResponseIsNull_ResponseContainsNoContentItems()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentByCategoryRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentByCategoryRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            contentItemTwo.Source = "source1";
            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetContentByCategoryReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetContentByCategoryReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetContentByCategory.GetContentByCategoryResponse() { ContentItems = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetContentByCategoryResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetContentByCategoryResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }
        #endregion

        #region get alphabet lists
        [Test]
        public void GetAlphabetLists_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetAlphabetLists(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetAlphabetLists_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetAlphabetLists(new GetAlphabetListsRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetAlphabetLists_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetAlphabetLists(new GetAlphabetListsRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetAlphabetLists_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.GetAlphabetLists(getAlphabetListsRequest);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetAlphabetLists_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists.GetAlphabetListsRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetAlphabetListsRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetAlphabetListsRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetAlphabetListsSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists.GetAlphabetListsRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists.GetAlphabetListsRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists.GetAlphabetListsRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
        }

        [Test]
        public void ProcessSyncResult_GetAlphabetListsSyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetAlphabetListsRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetAlphabetListsRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var items = new List<Alphabet>() { alphabetOne, alphabetTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetAlphabetListsReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetAlphabetListsReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists.GetAlphabetListsResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists.GetAlphabetListsResponse() { Alphabets = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetAlphabetListsResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetAlphabetListsResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Alphabets);
            Assert.AreEqual(2, response.Alphabets.Count);
            for (int i = 0; i < response.Alphabets.Count; i++)
            {
                Assert.AreEqual(items[i].Letter, response.Alphabets[i].Letter);
                Assert.AreEqual(items[i].Source, response.Alphabets[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_GetAlphabetListsSyncResult_AlphabetsListInResponseIsNull_ResponseContainsNoAlphabets()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetAlphabetListsRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetAlphabetListsRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var items = new List<Alphabet>() { alphabetOne, alphabetTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetAlphabetListsReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetAlphabetListsReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists.GetAlphabetListsResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetAlphabetLists.GetAlphabetListsResponse() { Alphabets = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetAlphabetListsResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetAlphabetListsResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Alphabets);
            Assert.AreEqual(0, response.Alphabets.Count);
        }
        #endregion

        #region get content list by alphabet
        [Test]
        public void GetContentListByAlphabet_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetContentListByAlphabet(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetContentListByAlphabet_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetContentListByAlphabet(new GetContentListByAlphabetRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetContentListByAlphabet_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetContentListByAlphabet(new GetContentListByAlphabetRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetContentListByAlphabet_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.GetContentListByAlphabet(getContentListByAlphabetRequest);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetContentListByAlphabet_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentListByAlphabetRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentListByAlphabetRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetContentListByAlphabetSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Age);
            Assert.AreEqual(1, actualRequest.Age.Days);
            Assert.AreEqual(4, actualRequest.Age.Months);
            Assert.AreEqual(35, actualRequest.Age.Years);
            Assert.AreEqual("M", actualRequest.Gender);
            Assert.AreEqual("letter", actualRequest.ByLetter);
            Assert.AreEqual("en", actualRequest.LanguageCode);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetContentListByAlphabet_BirthDateIsNull_SerializerIsCalledWithNullAge()
        {
            Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentListByAlphabetRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentListByAlphabetRequestWithoutBirthdate }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetContentListByAlphabetSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNull(actualRequest.Age);
        }

        [Test]
        public void ProcessSyncResult_GetContentListByAlphabetSyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentListByAlphabetRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentListByAlphabetRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetContentListByAlphabetReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetContentListByAlphabetReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetResponse() { ContentItems = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetContentListByAlphabetResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetContentListByAlphabetResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
            for (int i = 0; i < response.ContentItems.Count; i++)
            {
                Assert.AreEqual(items[i].ContentId, response.ContentItems[i].ContentId);
                Assert.AreEqual(items[i].ContentTypeId, response.ContentItems[i].ContentTypeId);
                Assert.AreEqual(items[i].ContentType, response.ContentItems[i].ContentType);
                Assert.AreEqual(items[i].Content, response.ContentItems[i].Content);
                Assert.AreEqual(items[i].Description, response.ContentItems[i].Description);
                Assert.AreEqual(items[i].Gender, response.ContentItems[i].Gender);
                Assert.AreEqual(items[i].Language, response.ContentItems[i].Language);
                Assert.AreEqual(items[i].Link, response.ContentItems[i].Link);
                Assert.AreEqual(items[i].PostingDate, response.ContentItems[i].PostingDate);
                Assert.AreEqual(items[i].Source, response.ContentItems[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_GetContentListByAlphabetSyncResult_ContentItemsInResponseIsNull_ResponseContainsNoContentItems()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetContentListByAlphabetRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetContentListByAlphabetRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetContentListByAlphabetReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetContentListByAlphabetReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetContentListByAlphabet.GetContentListByAlphabetResponse() { ContentItems = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetContentListByAlphabetResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetContentListByAlphabetResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }
        #endregion

        #region get resource content
        [Test]
        public void GetResourceContent_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetResourceContent(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetResourceContent_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetResourceContent(new GetResourceContentRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetResourceContent_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.GetResourceContent(new GetResourceContentRequest() { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetResourceContent_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.GetResourceContent(getResourceContentRequest);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_TenantSyncResult_OriginalRequestIsGetResourceContent_SerializerIsCalledWithCorrectEntityValues()
        {
            Medseek.Platform.Services.ContentService.Entities.GetResourceContent.GetResourceContentRequest actualRequest = null;

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetResourceContentRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetResourceContentRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantGetResourceContentSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.GetResourceContent.GetResourceContentRequest>())).Callback<string, Medseek.Platform.Services.ContentService.Entities.GetResourceContent.GetResourceContentRequest>((contentType, request) => { actualRequest = request; });
            service.ProcessSyncResult(syncResult);

            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.Entities.GetResourceContent.GetResourceContentRequest>(actualRequest);
            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.TenantInfo);
            Assert.AreEqual("media/medical/hw/h9991278_001_pi.jpg", actualRequest.DocumentPath);
            Assert.AreEqual("en-us", actualRequest.LanguageCode);
            Assert.AreEqual(TenantId, actualRequest.TenantInfo.Id);
            Assert.AreEqual("tenantName", actualRequest.TenantInfo.Name);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings);
            Assert.AreEqual(1, actualRequest.TenantInfo.Settings.Count);
            Assert.AreEqual("krames", actualRequest.TenantInfo.Settings[0].Key);
            Assert.IsNotNull(actualRequest.TenantInfo.Settings[0].Settings);
            Assert.AreEqual("baseUrl", actualRequest.TenantInfo.Settings[0].Settings.BaseUrl);
            Assert.AreEqual("MedseekWS", actualRequest.TenantInfo.Settings[0].Settings.LicenseKey);
        }

        [Test]
        public void ProcessSyncResult_GetResourceContentSyncResult_RemoteMicroServiceInvokerIsCalled_WithProperParams()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetResourceContentRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetResourceContentRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetResourceContentReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetResourceContentReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetResourceContent.GetResourceContentResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetResourceContent.GetResourceContentResponse() { ContentItems = items });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetResourceContentResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetResourceContentResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
            for (int i = 0; i < response.ContentItems.Count; i++)
            {
                Assert.AreEqual(items[i].ContentId, response.ContentItems[i].ContentId);
                Assert.AreEqual(items[i].ContentTypeId, response.ContentItems[i].ContentTypeId);
                Assert.AreEqual(items[i].ContentType, response.ContentItems[i].ContentType);
                Assert.AreEqual(items[i].Content, response.ContentItems[i].Content);
                Assert.AreEqual(items[i].Description, response.ContentItems[i].Description);
                Assert.AreEqual(items[i].Gender, response.ContentItems[i].Gender);
                Assert.AreEqual(items[i].Language, response.ContentItems[i].Language);
                Assert.AreEqual(items[i].Link, response.ContentItems[i].Link);
                Assert.AreEqual(items[i].PostingDate, response.ContentItems[i].PostingDate);
                Assert.AreEqual(items[i].Source, response.ContentItems[i].Source);
            }
        }

        [Test]
        public void ProcessSyncResult_GetResourceContentSyncResult_ContentItemsInResponseIsNull_ResponseContainsNoContentItems()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; }).Verifiable();

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalGetResourceContentRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalGetResourceContentRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var items = new List<ContentItem>() { contentItemOne, contentItemTwo };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncGetResourceContentReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedGetResourceContentReplyAddress) }));
            serializer.Setup(c => c.Deserialize<Medseek.Platform.Services.ContentService.Entities.GetResourceContent.GetResourceContentResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Medseek.Platform.Services.ContentService.Entities.GetResourceContent.GetResourceContentResponse() { ContentItems = null });
            service.ProcessSyncResult(syncResult);

            invoker.Verify();
            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.GetResourceContentResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.GetResourceContentResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }
        #endregion

        #region multiple sources
        [Test]
        public void ProcessSyncResult_TenantSyncResult_MoreThanOneConfiguredTenant_SyncServiceContainsRequestForEachTenant()
        {
            // variable to capture the request parameter for later validation
            SyncRequest actualRequest = null;

            // setup the mock to capture the parameter
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Callback<SyncRequest>((request) => { actualRequest = request; });

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalKeywordRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] } 
                            }
            };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantSyncRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Name = "tenantName", Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "krames", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "MedseekWS" } }, new KeySettingsPair() { Key = "healthwise", Settings = new Settings() { BaseUrl = "baseUrl", LicenseKey = "healthwiseLicense" } } } });
            serializer.Setup(c => c.Serialize(It.IsAny<string>(), It.IsAny<Medseek.Platform.Services.ContentService.Entities.SearchByKeyword.SearchByKeywordRequest>())).Returns(Encoding.UTF8.GetBytes(SearchByKeywordRequestBody));
            service.ProcessSyncResult(syncResult);

            Assert.IsNotNull(actualRequest);
            Assert.IsNotNull(actualRequest.Operations);
            Assert.AreEqual(2, actualRequest.Operations.Count);
            Assert.AreEqual(TargetedKeywordAddress, actualRequest.Operations[0].Address);
            Assert.AreEqual(SearchByKeywordRequestBody, Encoding.UTF8.GetString(actualRequest.Operations[0].Body));
            Assert.AreEqual(AlternateTargetedKeywordAddress, actualRequest.Operations[1].Address);
            Assert.AreEqual(SearchByKeywordRequestBody, Encoding.UTF8.GetString(actualRequest.Operations[1].Body));
            Assert.AreEqual(TargetedKeywordReplyAddress, messageContext.Object.Current.Properties.ReplyToString);
        }

        [Test]
        public void ProcessSyncResult_SearchByKeywordSyncResult_MultipleSourceResponses_ResultsAreAggregatedProperly()
        {
            // variable to capture the request parameter for later validation
            object actualObj = null;

            // setup the mock to capture the parameter
            invoker.Setup(
                c => c.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.IsAny<object>(), It.IsAny<MessageProperties>()))
                   .Callback<MqAddress, Type, object, MessageProperties>(
                       (address, type, data, props) => { actualObj = data; });

            var syncResult = new SyncResult()
            {
                Context =
                    new OperationRequest()
                    {
                        Properties = new MessageProperties()
                        {
                            ContentType = "application/xml",
                            ReplyTo = new MqAddress(ReplyToAddress),
                            AdditionalProperties = new Dictionary<string, object>() 
                                                                     {
                                                                         { "contentservice.originalroutingkey", OriginalKeywordRoutingKey },
                                                                         { "contentservice.originalrequest", OriginalKeywordRequest }
                                                                     }
                        }
                    },
                Results = new OperationResult[] 
                            {
                                new OperationResult() { Body = new byte[0] }, 
                                new OperationResult() { Body = new byte[0] } 
                            }
            };

            var responseList = new[]
                                   {
                                       new SearchByKeywordResponse()
                                           {
                                               ContentItems =
                                                   new List<ContentItem>()
                                                       {
                                                           {
                                                               contentItemOne
                                                           }
                                                       }
                                           },
                                       new SearchByKeywordResponse()
                                           {
                                               ContentItems =
                                                   new List<ContentItem>()
                                                       {
                                                           {
                                                               contentItemTwo
                                                           }
                                                       }
                                           }
                                   };

            var returnValsInOrder = new Queue<SearchByKeywordResponse>(responseList);

            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, SyncKeywordReplyRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(TargetedKeywordReplyAddress) }));

            serializer.Setup(c => c.Deserialize<SearchByKeywordResponse>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(returnValsInOrder.Dequeue);
            service.ProcessSyncResult(syncResult);

            Assert.IsNotNull(actualObj);
            Assert.IsInstanceOf<Medseek.Platform.Services.ContentService.ServiceEntities.SearchByKeywordResponse>(actualObj);
            var response = actualObj as Medseek.Platform.Services.ContentService.ServiceEntities.SearchByKeywordResponse;
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
            Assert.AreEqual(contentItemOne.ContentId, response.ContentItems[0].ContentId);
            Assert.AreEqual(contentItemOne.ContentTypeId, response.ContentItems[0].ContentTypeId);
            Assert.AreEqual(contentItemOne.ContentType, response.ContentItems[0].ContentType);
            Assert.AreEqual(contentItemOne.Content, response.ContentItems[0].Content);
            Assert.AreEqual(contentItemOne.Description, response.ContentItems[0].Description);
            Assert.AreEqual(contentItemOne.Gender, response.ContentItems[0].Gender);
            Assert.AreEqual(contentItemOne.Language, response.ContentItems[0].Language);
            Assert.AreEqual(contentItemOne.Link, response.ContentItems[0].Link);
            Assert.AreEqual(contentItemOne.PostingDate, response.ContentItems[0].PostingDate);
            Assert.AreEqual(contentItemOne.Source, response.ContentItems[0].Source);
            Assert.AreEqual(contentItemTwo.ContentId, response.ContentItems[1].ContentId);
            Assert.AreEqual(contentItemTwo.ContentTypeId, response.ContentItems[1].ContentTypeId);
            Assert.AreEqual(contentItemTwo.ContentType, response.ContentItems[1].ContentType);
            Assert.AreEqual(contentItemTwo.Content, response.ContentItems[1].Content);
            Assert.AreEqual(contentItemTwo.Description, response.ContentItems[1].Description);
            Assert.AreEqual(contentItemTwo.Gender, response.ContentItems[1].Gender);
            Assert.AreEqual(contentItemTwo.Language, response.ContentItems[1].Language);
            Assert.AreEqual(contentItemTwo.Link, response.ContentItems[1].Link);
            Assert.AreEqual(contentItemTwo.PostingDate, response.ContentItems[1].PostingDate);
            Assert.AreEqual(contentItemTwo.Source, response.ContentItems[1].Source);
        }
        #endregion
    }
}
