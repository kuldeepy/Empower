﻿namespace ContentService.Test.Serializer
{
    using Medseek.Platform.Services.ContentService.Serializer;
    using Medseek.Util.MicroServices;
    using Medseek.Util.Serialization;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public sealed class ContentSerializerTests
    {
        private Mock<IMicroServiceSerializer> microservice;
        private Mock<ISerializerFactory> invoker;
        private ContentSerializer contentSerializer;
       
        [SetUp]
        public void Setup()
        {
            this.microservice = new Mock<IMicroServiceSerializer>();
            this.invoker = new Mock<ISerializerFactory>();
            this.microservice.SetReturnsDefault(this.invoker.Object);
            this.contentSerializer = new ContentSerializer(this.microservice.Object);
        }

        [Test]
        public void ContentSerializerCanConstruct()
        {
            Assert.IsNotNull(this.contentSerializer);
            Assert.IsInstanceOf<ContentSerializer>(this.contentSerializer);
        }

    }
}
