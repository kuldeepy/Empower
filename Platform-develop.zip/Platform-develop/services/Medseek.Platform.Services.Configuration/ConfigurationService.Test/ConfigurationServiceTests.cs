﻿namespace ConfigurationService.Test
{
    using System;
    using System.Collections.Generic;
    using Medseek.Platform.Services.Configuration;
    using Medseek.Platform.Services.Configuration.Dao;
    using Medseek.Util.MicroServices;
    using Moq;
    using NUnit.Framework;
    using ConfigurationMicroService = Medseek.Platform.Services.Configuration.ConfigurationService;

    [TestFixture]
    public class ConfigurationServiceTests
    {
        private ConfigurationMicroService service;
        private Mock<IMessageContext> messageContext;
        private Mock<IConfigurationServiceDao> configurationServiceDao;
        private List<Configuration> configurations;

        private ConfigurationRequest configurationRequest;

        [SetUp]
        public void Setup()
        {
            configurations = new List<Configuration>
                {
                    new Configuration { Id = "1", Value = "Configurations 1" },
                    new Configuration { Id = "2", Value = "Configurations 2" }
                };

            messageContext = new Mock<IMessageContext>();
            configurationServiceDao = new Mock<IConfigurationServiceDao>();
            configurationServiceDao.Setup(c => c.Get()).Returns(configurations);
            configurationServiceDao.Setup(c => c.GetById("1")).Returns(configurations[0]);
            configurationServiceDao.Setup(c => c.GetById("2")).Returns(configurations[1]);

            configurationRequest = new ConfigurationRequest { Id = "1", Value = "Configuration details" };

            service = new ConfigurationMicroService(messageContext.Object, configurationServiceDao.Object);
        }

        [Test]
        public void Ctor_CanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<ConfigurationMicroService>(service);
        }

        [Test]
        public void Ctor_NullContext_ExceptionIsThrown()
        {
            TestDelegate action = () => new ConfigurationMicroService(messageContext.Object, null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullConfigurationDao_ExceptionIsThrown()
        {
            TestDelegate action = () => new ConfigurationMicroService(null, configurationServiceDao.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetConfigurations_ValidRequest_ReturnsExpectedResponseContentType()
        {
            var response = service.Get(configurationRequest);

            Assert.IsNotNull(response);
            Assert.AreEqual(response.ContentType, "application/json");
        }

        [Test]
        public void GetConfigurations_ValidRequest_ReturnsExpectedResponseJsonValue()
        {
            var response = service.Get(configurationRequest);

            Assert.IsNotNull(response);
            Assert.AreEqual("{\"Id\":\"1\",\"Value\":\"Configurations 1\"}", response.Value);
        }

        [Test]
        public void GetConfigurations_ValidRequest_DaoReturnsNullValue_ReturnsExpectedNullValue()
        {
            configurationRequest.Id = "123";
            configurationServiceDao.Setup(c => c.GetById("123")).Returns((Configuration) null);
            var response = service.Get(configurationRequest);

            Assert.IsNotNull(response);
            Assert.IsNull(response.Value);
        }

        [Test]
        public void Update_ValueIsNotNull_ConfigurationServiceDaoSaveOrUpdateIsCalledWithCorrectValues()
        {
            configurationServiceDao.Setup(dao => dao.SaveOrUpdate(It.Is<Configuration>(c => c.Id == "3" && c.Value == "value"))).Verifiable();

            service.Update(new ConfigurationRequest { Id = "3", Value = "value" });

            configurationServiceDao.Verify();
        }

        [Test]
        public void Update_ValueIsNotNull_NewConfigurationWithoutId_ConfigurationIdSetToNewGuid()
        {
            configurationServiceDao.Setup(dao => dao.SaveOrUpdate(It.IsAny<Configuration>()))
                .Callback<Configuration>(c => Assert.AreNotEqual(c.Id, string.Empty))
                .Verifiable();

            service.Update(new ConfigurationRequest { Id = string.Empty, Value = "value" });

            configurationServiceDao.Verify();
        }

        [Test]
        public void Update_ConfigurationFoundInDb_IncomingValueIsNull_ConfigurationServiceDaoDeleteIsCalled()
        {
            configurationServiceDao.Setup(dao => dao.Delete(It.Is<Configuration>(c => c.Id == "2"))).Verifiable();

            service.Update(new ConfigurationRequest { Id = "2" });

            configurationServiceDao.Verify();
        }
    }
}
