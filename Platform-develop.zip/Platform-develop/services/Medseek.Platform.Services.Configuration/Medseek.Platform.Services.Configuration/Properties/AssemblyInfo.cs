﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Medseek.Util.MicroServices.Host;

[assembly: AssemblyCompany("Medseek")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2014")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyDescription("Micro-service for accessing common configuration")]
[assembly: AssemblyProduct("Medseek.Platform.Services.Configuration")]
[assembly: AssemblyTitle("Medseek.Platform.Services.Configuration")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.*")]
[assembly: ComVisible(false)]
[assembly: Guid("17652933-9470-483b-8390-dd6cd88278ed")]
[assembly: ReferenceMicroServiceHost]