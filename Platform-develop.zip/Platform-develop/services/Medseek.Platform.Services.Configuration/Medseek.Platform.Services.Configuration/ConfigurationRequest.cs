﻿namespace Medseek.Platform.Services.Configuration
{
    using System.Runtime.Serialization;

    /// <summary>
    /// A configuration request.
    /// </summary>
    [DataContract(Namespace = Components.Xmlns)]
    public class ConfigurationRequest
    {
        /// <summary>
        /// Gets or sets the identifier of the configuration data.
        /// </summary>
        [DataMember(EmitDefaultValue = false, Order = 0)]
        public string Id
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the content type identifying the formatting of the 
        /// configuration data associated with the request.
        /// </summary>
        /// <seealso cref="Value" />
        [DataMember(EmitDefaultValue = false, Order = 1)]
        public string ContentType
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the value of the configuration data.
        /// </summary>
        /// <seealso cref="ContentType" />
        [DataMember(EmitDefaultValue = false, Order = 2)]
        public string Value
        {
            get;
            set;
        }
    }
}