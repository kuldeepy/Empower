﻿namespace Medseek.Platform.Services.Configuration
{
    using System.ServiceModel;

    /// <summary>
    /// An example micro-service service contract.
    /// </summary>
    [ServiceContract(Namespace = Components.Xmlns)]
    public interface IConfigurationService
    {
        /// <summary>
        /// An example of a micro-service operation.
        /// </summary>
        /// <param name="request">
        /// The configuration request.
        /// </param>
        /// <returns>
        /// The configuration response.
        /// </returns>
        [OperationContract]
        ConfigurationResponse Get(ConfigurationRequest request);
    }
}