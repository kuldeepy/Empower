﻿namespace Medseek.Platform.Services.Configuration
{
    using System.Runtime.Serialization;

    /// <summary>
    /// A configuration data response.
    /// </summary>
    [DataContract(Namespace = Components.Xmlns)]
    public class ConfigurationResponse
    {
        /// <summary>
        /// Gets or sets the content type identifying the formatting of the 
        /// configuration data associated with the response.
        /// </summary>
        /// <seealso cref="Value" />
        [DataMember]
        public string ContentType
        {
            get; 
            set;
        }

        /// <summary>
        /// Gets or sets the value of the configuration data associated with 
        /// the response.
        /// </summary>
        /// <seealso cref="ContentType" />
        [DataMember]
        public string Value
        {
            get;
            set;
        }
    }
}