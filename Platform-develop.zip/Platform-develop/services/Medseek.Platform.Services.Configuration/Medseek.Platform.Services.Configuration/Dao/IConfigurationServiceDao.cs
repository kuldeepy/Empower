﻿namespace Medseek.Platform.Services.Configuration.Dao
{
    using System.Collections.Generic;

    public interface IConfigurationServiceDao
    {
        string SqlConnectionString { get; set; }

        List<Configuration> Get();

        Configuration GetById(string id);

        void SaveOrUpdate(Configuration configuration);

        void Delete(Configuration configuration);
    }
}