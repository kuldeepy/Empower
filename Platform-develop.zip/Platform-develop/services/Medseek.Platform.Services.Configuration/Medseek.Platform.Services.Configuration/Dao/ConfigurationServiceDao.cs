﻿namespace Medseek.Platform.Services.Configuration.Dao
{
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using Util.Ioc;

    [Register(typeof(IConfigurationServiceDao))]
    public class ConfigurationServiceDao : IConfigurationServiceDao
    {
        private const string TableName = "Configurations";
        public string SqlConnectionString { get; set; }

        public List<Configuration> Get()
        {
            var configurations = new List<Configuration>();

            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(string.Format("SELECT Id, Value from {0}", TableName), connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            configurations.Add(new Configuration
                                {
                                    Id = reader["Id"].ToString(),
                                    Value = reader["Value"].ToString()
                                });
                        }
                    }
                }
            }

            return configurations;
        }

        public Configuration GetById(string id)
        {
            Configuration returnVal = null;
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(string.Format("SELECT Value FROM {0} WHERE Id = @idValue", TableName), connection))
                {
                    command.Parameters.Add(new SqlParameter() { ParameterName = "idValue", Value = id });
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            returnVal = new Configuration
                                            {
                                                Id = id,
                                                Value = reader["Value"].ToString()
                                            };
                        }
                    }
                }
            }

            return returnVal;
        }

        public void SaveOrUpdate(Configuration configuration)
        {

            var commandText = string.Format("MERGE {0} AS target USING (SELECT @Id, @Value) AS source (Id, Value) ON (target.Id = source.Id) WHEN MATCHED THEN UPDATE SET Value = source.Value WHEN NOT MATCHED THEN INSERT (Id, Value) Values (source.Id, Source.Value);", TableName);
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(commandText, connection))
                {
                    var parameters = new List<SqlParameter>
                        {
                            new SqlParameter("Id", configuration.Id),
                            new SqlParameter("Value", configuration.Value)
                        };

                    command.Parameters.AddRange(parameters.ToArray());
                    command.ExecuteScalar();
                }
            }
        }


        public void Delete(Configuration configuration)
        {
            var commandText = string.Format("DELETE FROM {0} WHERE [Id] = @Id", TableName);
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(commandText, connection))
                {
                    var parameters = new List<SqlParameter>
                        {
                            new SqlParameter("Id", configuration.Id)
                        };

                    command.Parameters.AddRange(parameters.ToArray());
                    command.ExecuteNonQuery();
                }
            }
        }

        private SqlConnection GetConnection()
        {
            return new SqlConnection(SqlConnectionString);
        }
    }
}
