﻿namespace Medseek.Platform.Services.Configuration
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Dao;
    using Newtonsoft.Json;
    using Util.MicroServices;

    /// <summary>
    /// Configuration micro-service
    /// </summary>
    [RegisterMicroService(typeof(IConfigurationService))]
    public class ConfigurationService : IConfigurationService
    {
        private const string ConnectionStringName = "ConfigurationConnectionString";
        private const string DefaultSqlConnectionString = "Data Source=localhost;Initial Catalog=Platform_Configurations;Integrated Security=True";

        private readonly IMessageContext messageContext;
        private readonly IConfigurationServiceDao configurationServiceDao;

        public string SqlConnectionString 
        {
            get
            {
                var connectionString = string.Empty;
                if (System.Configuration.ConfigurationManager.ConnectionStrings[ConnectionStringName] != null)
                {
                    connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[ConnectionStringName].ConnectionString;
                }
                return string.IsNullOrWhiteSpace(connectionString) ? DefaultSqlConnectionString : connectionString;
            }
        }
        
        /// <summary>
        /// Initializes a new instance of the <see cref="ConfigurationService"/> class.
        /// </summary>
        public ConfigurationService(IMessageContext messageContext, IConfigurationServiceDao configurationServiceDao)
        {
            if (messageContext == null)
                throw new ArgumentNullException("messageContext");

            if (configurationServiceDao == null)
                throw new ArgumentNullException("configurationServiceDao");

            var connectionString = GetCommandLineArgumentValue(
                Environment.GetCommandLineArgs(),
                "sqlConnectionString",
                SqlConnectionString);

            configurationServiceDao.SqlConnectionString = connectionString;
            this.configurationServiceDao = configurationServiceDao;

            this.messageContext = messageContext;
        }

        /// <summary>
        /// Get configuration details for given <see cref="ConfigurationRequest.Id"/>.
        /// </summary>
        /// <param name="request">
        /// The configuration request.
        /// </param>
        /// <returns>
        /// The configuration response.
        /// </returns>
        [MicroServiceBinding(Components.Exchange, Components.BindingKeyPrefix + ".Get.ById", Components.ConsumeQueue, AutoDelete = false)]
        public ConfigurationResponse Get(ConfigurationRequest request)
        {
            var document = configurationServiceDao.GetById(request.Id);
            return new ConfigurationResponse
                {
                    ContentType = "application/json",
                    Value = document != null ? JsonConvert.SerializeObject(document) : null,
                };
        }

        /// <summary>
        /// Updates the configuration data.
        /// </summary>
        /// <param name="request">
        /// The configuration request.
        /// </param>
        /// <returns>
        /// The configuration response.
        /// </returns>
        [MicroServiceBinding(Components.Exchange, Components.BindingKeyPrefix + ".Update.ById", Components.ConsumeQueue, AutoDelete = false)]
        public ConfigurationResponse Update(ConfigurationRequest request)
        {
            Configuration document = null;

            if (string.IsNullOrWhiteSpace(request.Value))
            {
                configurationServiceDao.Delete(new Configuration(){ Id = request.Id });
                document = null;
            }
            else
            {
                document = new Configuration() { Id = request.Id, Value = request.Value };
                if (string.IsNullOrWhiteSpace(document.Id))
                {
                    document.Id = Guid.NewGuid().ToString();
                }
                configurationServiceDao.SaveOrUpdate(document);
            }

            return new ConfigurationResponse
                {
                    ContentType = "application/json",
                    Value = document != null ? JsonConvert.SerializeObject(document) : null,
                };
        }
        
        private static string GetCommandLineArgumentValue(IEnumerable<string> args, string argument, string defaultVal)
        {
            var returnVal = defaultVal;
            foreach (var arg in args.Where(arg => arg.StartsWith("/" + argument)))
            {
                returnVal = arg.Split('=')[1];
            }

            return returnVal;
        }
    }
}