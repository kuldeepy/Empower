﻿namespace Medseek.Platform.Services.Configuration
{
    public class Configuration
    {
        public string Id
        {
            get; 
            set;
        }

        public string Value
        {
            get; 
            set;
        }
    }
}