﻿namespace Krames.GetContentByCategory.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Web;
    using System.Xml.Linq;
    using Medseek.Platform.Services.Krames.GetContentByCategory;
    using Medseek.Platform.Services.Krames.GetContentByCategory.AgeCalculator;
    using Medseek.Platform.Services.Krames.GetContentByCategory.Entities;
    using Medseek.Platform.Services.Krames.GetContentByCategory.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    public class KramesGetContentByCategoryServiceTests : TestFixture<KramesGetContentByCategoryService>
    {
        private const string BaseUrl = "http://external.ws.staywell.com/{0}/Content.svc/GetCollectionContents";
        private const string XmlString = "<Subtopic SubtopicId=\"25084\"><Name>Greystone - Adult Conditions</Name><ContentList><ContentObject ContentObjectType=\"Document\" ContentTypeId=\"12\" ContentId=\"1\" IsCustom=\"false\" Blocked=\"false\"><Language Code=\"en\"/><RegularTitle>Helping the Heart Through Cardiac Rehab</RegularTitle><Blurb><p>Detailed information on claudication</p></Blurb><GenderCode>M</GenderCode></ContentObject><ContentObject ContentObjectType=\"Document\" ContentTypeId=\"6\" ContentId=\"514918\" IsCustom=\"true\" Blocked=\"false\"><Language Code=\"en\"/><RegularTitle>New Hope for People With Heart Failure</RegularTitle><Blurb><p>Detailed information on the medical management of vascular conditions</p></Blurb><GenderCode>A</GenderCode></ContentObject></ContentList></Subtopic>";

        private Mock<IWebClient> webClient;
        private Mock<IAgeGroupCalculator> ageCalculator;
        private KramesGetContentByCategoryService service;
        private GetContentByCategoryRequest request;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            ageCalculator = Mock<IAgeGroupCalculator>();
            service = new KramesGetContentByCategoryService(webClient.Object, ageCalculator.Object);
            request = new GetContentByCategoryRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                                                  {
                                                      new KeySettingsPair
                                                          {
                                                              Key = "krames",
                                                              Settings = new Settings
                                                                        {
                                                                          LicenseKey = "KramesSiteName",
                                                                          BaseUrl = "http://external.ws.staywell.com"
                                                                        }
                                                          }
                                                  }
                    },
                Age = new Age { Years = 1, Months = 1, Days = 1 },
                Category = new Category
                    {
                        Id = "25084",
                        Name = "Greystone - Adult Conditions",
                        Source = "krames"
                    }
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<KramesGetContentByCategoryService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new KramesGetContentByCategoryService(null, ageCalculator.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: webClient"));
        }

        [Test]
        public void CtorThrowsIfNullAgeCalculator()
        {
            TestDelegate action = () => new KramesGetContentByCategoryService(webClient.Object, null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: ageCalculator"));
        }

        [Test]
        public void GetContentByCategoryNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetContentByCategory(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: inRequest"));
        }

        [Test]
        public void GetContentByCategoryNoCategoryThrowsArgumentException()
        {
            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>().And.Message.Contains("Request must contain Category."));
        }

        [Test]
        public void GetContentByCategory_CategoryIdNotSpecifiedInRequest_ThrowsArgumentException()
        {
            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest
            {
                Category = new Category
                {
                    Name = "Greystone - Adult Conditions",
                    Source = "krames"
                }
            });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetContentByCategoryNoKramesTenantInformationThrowsApplicationException()
        {
            TestDelegate action = () => service.GetContentByCategory(new GetContentByCategoryRequest
            {
                Category = new Category
                {
                    Id = "25084",
                    Name = "Greystone - Adult Conditions",
                    Source = "krames"
                }
            });
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void GetContentByCategoryReturnsGetContentByCategoryResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Adult);
            var response = service.GetContentByCategory(request);
            Assert.IsInstanceOf<GetContentByCategoryResponse>(response);
        }

        [Test]
        public void GetContentByCategory_EmptyResponse_ResponseContainsNoElement()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes("<Subtopic SubtopicId=\"25084\"><Name>Greystone - Adult Conditions</Name><ContentList/></Subtopic>")));
            var response = service.GetContentByCategory(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(0, response.ContentItems.Count);
        }

        [Test]
        public void GetContentByCategory_ContainsEmptyContentItem_ResponseContainsContentItemWithNullValues()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes("<Subtopic SubtopicId=\"25084\"><Name>Greystone - Adult Conditions</Name><ContentList><ContentObject/></ContentList></Subtopic>")));
            var response = service.GetContentByCategory(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("krames", response.ContentItems[0].Source);
        }

        [Test]
        public void GetContentByCategory_AllObjectsReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.GetContentByCategory(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
        }

        [Test]
        public void GetContentByCategory_ResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Adult);
            var response = service.GetContentByCategory(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual("1", response.ContentItems[0].ContentId);
            Assert.AreEqual("Document", response.ContentItems[0].ContentType);
            Assert.AreEqual("12", response.ContentItems[0].ContentTypeId);
            Assert.AreEqual("en", response.ContentItems[0].Language);
            Assert.AreEqual("Helping the Heart Through Cardiac Rehab", response.ContentItems[0].Title);
            Assert.AreEqual("Detailed information on claudication", response.ContentItems[0].Description);
            Assert.AreEqual("M", response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("krames", response.ContentItems[0].Source);

            Assert.AreEqual("514918", response.ContentItems[1].ContentId);
            Assert.AreEqual("Document", response.ContentItems[1].ContentType);
            Assert.AreEqual("6", response.ContentItems[1].ContentTypeId);
            Assert.AreEqual("en", response.ContentItems[1].Language);
            Assert.IsNull(response.ContentItems[1].PostingDate);
            Assert.AreEqual("New Hope for People With Heart Failure", response.ContentItems[1].Title);
            Assert.AreEqual("Detailed information on the medical management of vascular conditions", response.ContentItems[1].Description);
            Assert.AreEqual("A", response.ContentItems[1].Gender);
            Assert.AreEqual("krames", response.ContentItems[1].Source);
        }

        [Test]
        public void GetContentByCategoryWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }
        
        [Test]
        public void GetContentByCategoryValidRequestWebClientBaseUrlIsExpected()
        {
            var expectedUrl = string.Format(BaseUrl, "KramesSiteName");
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Substring(0, a.IndexOf('?')) == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_CategoryIdSpecifiedInRequest_WebClientQueryStringContainsCategoryId()
        {
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => ContainsElementValue(a, "SubtopicId", "25084", true)))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }
        
        [Test]
        public void GetContentByCategory_GenderSpecifiedInRequest_WebClientQueryStringContainsGender()
        {
            request.Gender = "M";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => ContainsElementValue(a, "GenderCode", "M", true)))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_GenderNotSpecifiedInRequest_WebClientQueryStringDoesNotContainGender()
        {
            request.Gender = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains("<GenderCode>")))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_LanguageSpecifiedInRequest_WebClientQueryStringContainsLanguage()
        {
            request.LanguageCode = "es";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => ContainsElementValue(a, "LanguageCode", "es", true)))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_LanguageNotSpecifiedInRequest_WebClientQueryStringDoesNotContainLanguage()
        {
            request.LanguageCode = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains("<LanguageCode>")))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeNotSpecifiedInRequest_CalculateAgeGroupIsNotCalled()
        {
            request.Age = null;
            ageCalculator = new Mock<IAgeGroupCalculator>(MockBehavior.Strict);
            service = new KramesGetContentByCategoryService(webClient.Object, ageCalculator.Object);
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeNotSpecifiedInRequest_WebClientQueryStringDoesNotContainsAgeGroup()
        {
            request.Age = null;
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Teen);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains("<AgeBins>")))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeSpecifiedInRequest_CalculateAgeGroupIsCalled()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Adult).Verifiable();
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            ageCalculator.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeSpecifiedInRequest_Adult_WebClientQueryStringContainsAdultAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Adult);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => ContainsElementValue(a, "AgeBin", "Adult (18+)", false)))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeSpecifiedInRequest_Teen_WebClientQueryStringContainsTeenAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Teen);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => ContainsElementValue(a, "AgeBin", "Teen (12 - 18 yrs)", false)))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeSpecifiedInRequest_Childhood_WebClientQueryStringContainsChildhoodAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Childhood);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => ContainsElementValue(a, "AgeBin", "Childhood (11 mo - 12 yrs)", false)))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeSpecifiedInRequest_Infant_WebClientQueryStringContainsInfantAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Infant);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => ContainsElementValue(a, "AgeBin", "Infant (0 - 11 mo)", false)))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeSpecifiedInRequest_Senior_WebClientQueryStringContainsSeniorAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Senior);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => ContainsElementValue(a, "AgeBin", "Senior", false)))).Returns(BuildResponseStream()).Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentByCategory_AgeSpecifiedInRequest_CalculatedAgeGroupIsNull_WebClientQueryStringDoesNotContainAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns((AgeGroup?)null);
            webClient.Setup(
                w => w.OpenRead(It.Is<string>(a => !a.Contains("<AgeBins>"))))
                     .Returns(BuildResponseStream())
                     .Verifiable();
            service.GetContentByCategory(request);
            webClient.Verify();
        }

        private static Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }

        private static bool ContainsElementValue(string uri, string elementName, string expectedValue, bool isAttribute = false)
        {
            var decodedUri = HttpUtility.UrlDecode(uri);

            if (decodedUri != null)
            {
                var queryParameter = decodedUri.Substring(decodedUri.IndexOf('=') + 1);

                var xmlRequest = XElement.Parse(queryParameter);

                if (isAttribute)
                {
                    return xmlRequest.Attribute(elementName).Value == expectedValue;
                }

                return xmlRequest.Descendants(elementName).First().Value == expectedValue;
            }

            return false;
        }
    }
}
