﻿namespace Krames.GetContentByCategory.Test
{
    using Medseek.Platform.Services.Krames.GetContentByCategory.AgeCalculator;
    using Medseek.Platform.Services.Krames.GetContentByCategory.Entities;
    using NUnit.Framework;

    [TestFixture]
    public sealed class AgeGroupCalculatorTests
    {
        [Test]
        public void CtorValidParamsCanConstruct()
        {
            var calc = new AgeGroupCalculator();
            Assert.IsNotNull(calc);
            Assert.IsInstanceOf<IAgeGroupCalculator>(calc);
        }

        [Test]
        public void CalculateAgeGroup_AgeIsNull_NullIsReturned()
        {
            var calc = new AgeGroupCalculator();
            var result = calc.CalculateAgeGroup(null);
            Assert.Null(result);
        }

        [Test]
        public void CalculateAgeGroup_Atleast18YearsOld_AdultIsReturned()
        {
            var calc = new AgeGroupCalculator();
            var result = calc.CalculateAgeGroup(new Age() { Years = 20 });
            Assert.AreEqual(AgeGroup.Adult, result);
        }

        [Test]
        public void CalculateAgeGroup_OlderThan12ButNotAdult_TeenIsReturned()
        {
            var calc = new AgeGroupCalculator();
            var result = calc.CalculateAgeGroup(new Age() { Years = 13 });
            Assert.AreEqual(AgeGroup.Teen, result);
        }

        [Test]
        public void CalculateAgeGroup_OlderThan0YearsButNotTeen_ChildhoodIsReturned()
        {
            var calc = new AgeGroupCalculator();
            var result = calc.CalculateAgeGroup(new Age() { Years = 2 });
            Assert.AreEqual(AgeGroup.Childhood, result);
        }

        [Test]
        public void CalculateAgeGroup_OlderThan11MonthsButNot1Year_ChildhoodIsReturned()
        {
            var calc = new AgeGroupCalculator();
            var result = calc.CalculateAgeGroup(new Age() { Months = 11, Years = 0 });
            Assert.AreEqual(AgeGroup.Childhood, result);
        }

        [Test]
        public void CalculateAgeGroup_LessThan11Months_InfantIsReturned()
        {
            var calc = new AgeGroupCalculator();
            var result = calc.CalculateAgeGroup(new Age() { Months = 6, Years = 0 });
            Assert.AreEqual(AgeGroup.Infant, result);
        }

        [Test]
        public void CalculateAgeGroup_NoGroupsMatch_NullIsReturned()
        {
            var calc = new AgeGroupCalculator();
            var result = calc.CalculateAgeGroup(new Age() { Years = -1 });
            Assert.IsNull(result);
        }
    }
}
