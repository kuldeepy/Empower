﻿namespace Krames.GetContentListByAlphabet
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Web;
    using System.Xml.Linq;
    using Krames.GetContentListByAlphabet.AgeCalculator;
    using Krames.GetContentListByAlphabet.Entities;
    using Krames.GetContentListByAlphabet.WebClient;
    using Medseek.Util.MicroServices;
   
    [RegisterMicroService]
    public class KramesGetContentListByAlphabetService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetContentListByAlphabet.Krames";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getcontentlistbyalphabet.krames";
        private const string KramesSettingsKey = "krames";
        private const string GetContentListByAlphabetUrl = "{0}/{1}/Content.svc/SearchContent?xmlRequest={2}";
        private readonly IWebClient webClient;
        private readonly IAgeGroupCalculator ageCalculator;

        /// <summary>
        /// Initializes a new instance of the <see cref="KramesGetContentListByAlphabetService"/> class.
        /// </summary>
        /// <param name="webClient">An instance of <see cref="IWebClient"/>.</param>
        /// <param name="ageCalculator">An instance of <see cref="IAgeGroupCalculator"/>.</param>
        /// <exception cref="System.ArgumentNullException">web Client</exception>
        /// <exception cref="System.ArgumentNullException">age Calculator</exception>
        public KramesGetContentListByAlphabetService(IWebClient webClient, IAgeGroupCalculator ageCalculator)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }
            if (ageCalculator == null)
            {
                throw new ArgumentNullException("ageCalculator");
            }

            this.webClient = webClient;
            this.ageCalculator = ageCalculator;
        }

        /// <summary>
        /// Gets all the content by alphabet and some optional search criteria
        /// </summary>
        /// <param name="inRequest">The <see cref="GetContentListByAlphabetRequest"/>.</param>
        /// <returns>The <see cref="GetContentListByAlphabetResponse"/>.</returns>
        /// <exception cref="System.ArgumentNullException">input Request</exception>
        /// <exception cref="System.ApplicationException">Tenant not configured for Krames functionality.</exception>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetContentListByAlphabetResponse GetContentListByAlphabet(GetContentListByAlphabetRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var kramesSettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any())
                                     ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == KramesSettingsKey)
                                     : null;

            if (kramesSettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for Krames functionality",
                                                             tenantId));
            }
            var xmlRequest = HttpUtility.UrlEncode(BuildGetContentListByAlphabetRequest(inRequest));

            var uri = string.Format(GetContentListByAlphabetUrl,
                                    kramesSettings.Settings.BaseUrl,
                                    kramesSettings.Settings.LicenseKey,
                                    xmlRequest);

            using (var response = webClient.OpenRead(uri))
            {
                return BuildGetContentListByAlphabetResponse(response);
            }
        }

        #region Private Helpers

        /// <summary>
        /// Builds response
        /// </summary>
        /// <param name="response">The <see cref="Stream"/>.</param>
        /// <returns>The <see cref="GetContentListByAlphabetResponse"/>.</returns>
        private static GetContentListByAlphabetResponse BuildGetContentListByAlphabetResponse(Stream response)
        {
            var alphabetContentsListResponse = new GetContentListByAlphabetResponse();

            if (response != null)
            {
                var xmlDoc = XElement.Load(response);

                alphabetContentsListResponse.ContentItems =
                    xmlDoc.Descendants("ContentObject").Select(BuildContentItem).ToList();
            }
            return alphabetContentsListResponse;
        }

        /// <summary>
        /// Method builds the response ContentItem by fetching the values from XElement supplied to the method.
        /// </summary>
        /// <param name="contentObject">The XML element <see cref="XElement"/>.</param>
        /// <returns>The <see cref="ContentItem"/>.</returns>
        private static ContentItem BuildContentItem(XElement contentObject)
        {
            return new ContentItem
            {
                ContentId = GetValue(contentObject, null, "ContentId"),
                ContentTypeId = GetValue(contentObject, null, "ContentTypeId"),
                ContentType = GetValue(contentObject, null, "ContentObjectType"),
                Language = GetValue(contentObject, "Language", "Code"),
                Title = GetValue(contentObject, "RegularTitle"),
                Gender = GetValue(contentObject, "Gender"),
                Description = GetValue(contentObject, "Blurb"),
                Source = "krames"
            };
        }

        /// <summary>
        /// Gets Value for supplied attribute of ContentItem from the supplied XElement
        /// </summary>
        /// <param name="xmlElement">The XML element<see cref="XElement"/>.</param>
        /// <param name="elementName">The element name<see cref="string"/>.</param>
        /// <param name="attributeName">The attribute <see cref="string"/>.</param>
        /// <returns>Value of the attribute from XML Element</returns>
        private static string GetValue(XElement xmlElement, string elementName, string attributeName = null)
        {
            var element = xmlElement;

            if (!string.IsNullOrWhiteSpace(elementName))
            {
                element = xmlElement.Element(elementName);
                if (element == null)
                {
                    return null;
                }
            }

            if (string.IsNullOrWhiteSpace(attributeName))
            {
                return element.Value;
            }

            var attribute = element.Attribute(attributeName);

            return attribute != null ? attribute.Value : null;
        }

        /// <summary>
        /// Method builds the RequestXML based on the request comes form RabbitMQ
        /// </summary>
        /// <param name="inRequest">The request supplied by RabbitMQ<see cref="GetContentListByAlphabetRequest"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        private string BuildGetContentListByAlphabetRequest(GetContentListByAlphabetRequest inRequest)
        {
            var getContentElement = new XElement("SearchCriteria");

            if (inRequest.ByLetter != null)
            {
                getContentElement.Add(new XElement("ByLetter", inRequest.ByLetter));
            }

            if (!string.IsNullOrWhiteSpace(inRequest.LanguageCode))
            {
                getContentElement.Add(new XElement("Language",
                                                new XAttribute("Code", inRequest.LanguageCode)));
            }

            if (!string.IsNullOrWhiteSpace(inRequest.Gender))
            {
                getContentElement.Add(new XElement("Gender", inRequest.Gender));
            }

            if (inRequest.Age != null)
            {
                getContentElement.Add(new XElement("AgeGroups",
                                                   new XElement("AgeGroup", GetAgeGroup(inRequest.Age))));
            }

            return getContentElement.ToString();
        }

        /// <summary>
        /// Gets age group
        /// </summary>
        /// <param name="age">The <see cref="Age"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        private string GetAgeGroup(Age age)
        {
            var ageGroup = "Senior";

            var group = ageCalculator.CalculateAgeGroup(age);
            if (group != null)
            {
                switch (group)
                {
                    case AgeGroup.Infant:
                        ageGroup = "Infant (0 - 11 mo)";
                        break;
                    case AgeGroup.Childhood:
                        ageGroup = "Childhood (11 mo - 12 yrs)";
                        break;
                    case AgeGroup.Teen:
                        ageGroup = "Teen (12 - 18 yrs)";
                        break;
                    case AgeGroup.Adult:
                        ageGroup = "Adult (18+)";
                        break;
                    default:
                        ageGroup = "Senior";
                        break;
                }
            }

            return ageGroup;
        }

        #endregion
    }
}
