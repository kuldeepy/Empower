﻿namespace Krames.GetContentListByAlphabet.AgeCalculator
{
    using Krames.GetContentListByAlphabet.Entities;
    using Medseek.Util.Ioc;

    [Register(typeof(IAgeGroupCalculator), Lifestyle = Lifestyle.Transient)]
    public class AgeGroupCalculator : IAgeGroupCalculator
    {
        public AgeGroup? CalculateAgeGroup(Age inAge)
        {
            if (inAge == null) return null;

            if (inAge.Years >= 18)
                return AgeGroup.Adult;
            if (inAge.Years >= 12)
                return AgeGroup.Teen;
            if (inAge.Years > 0 || (inAge.Years == 0 && inAge.Months >= 11))
                return AgeGroup.Childhood;
            if (inAge.Years == 0 && inAge.Months < 11)
                return AgeGroup.Infant;

            return null;
        }
    }
}
