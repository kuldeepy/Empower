﻿namespace Krames.GetContentListByAlphabet.AgeCalculator
{
    using Krames.GetContentListByAlphabet.Entities;

    public interface IAgeGroupCalculator
    {
        /// <summary>
        /// Calculates age group based on Age. 
        /// </summary>
        /// <param name="inAge">the age</param>
        /// <returns>an AgeGroup, null if it cannot be calculated.</returns>
        AgeGroup? CalculateAgeGroup(Age inAge);
    }
}
