﻿namespace Krames.GetAlphabetLists.Test
{
    using System;
    using System.Collections.Generic;
    using Medseek.Platform.Services.Krames.GetAlphabetLists;
    using Medseek.Platform.Services.Krames.GetAlphabetLists.Entities;
    using Medseek.Util.Testing;
    using NUnit.Framework;

    [TestFixture]
    public sealed class KramesGetAlphabetListsTests : TestFixture<KramesGetAlphabetListsService>
    {
        private GetAlphabetListsRequest request;
        private KramesGetAlphabetListsService service;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            service = new KramesGetAlphabetListsService();
            request = new GetAlphabetListsRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                            {
                                                      new KeySettingsPair
                                                      {
                                                              Key = "krames",
                                                              Settings = new Settings
                                                              {
                                                                          LicenseKey = "KramesSiteName",
                                                                          BaseUrl = "http://external.ws.staywell.com"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<KramesGetAlphabetListsService>(service);
        }

        [Test]
        public void GetAlphabetListsReturnsGetAlphabetListsResponse()
        {
            var response = service.GetAlphabetLists(request);
            Assert.IsInstanceOf<GetAlphabetListsResponse>(response);
        }

        [Test]
        public void GetAlphabetListsNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetAlphabetLists(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetAlphabetListsNoTenantInformationThrowsApplicationException()
        {
            const string exceptionMessage = "Tenant '' is not configured for Krames functionality";

            TestDelegate action = () => service.GetAlphabetLists(new GetAlphabetListsRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetAlphabetListsAllAlphabetReturnedInResponse()
        {
            var response = service.GetAlphabetLists(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Alphabets);
            Assert.AreEqual(27, response.Alphabets.Count);
        }

        [Test]
        public void GetAlphabetListsResponseObjectPopulatedCorrectly()
        {
            var response = service.GetAlphabetLists(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Alphabets);
            Assert.IsNotNull(response.Alphabets);
            Assert.AreEqual("#", response.Alphabets[0].Letter);
            Assert.AreEqual("krames", response.Alphabets[0].Source);
            Assert.AreEqual("A", response.Alphabets[1].Letter);
            Assert.AreEqual("krames", response.Alphabets[1].Source);
            Assert.AreEqual("B", response.Alphabets[2].Letter);
            Assert.AreEqual("krames", response.Alphabets[2].Source);
            Assert.AreEqual("C", response.Alphabets[3].Letter);
            Assert.AreEqual("krames", response.Alphabets[3].Source);
            Assert.AreEqual("D", response.Alphabets[4].Letter);
            Assert.AreEqual("krames", response.Alphabets[4].Source);
            Assert.AreEqual("E", response.Alphabets[5].Letter);
            Assert.AreEqual("krames", response.Alphabets[5].Source);
            Assert.AreEqual("F", response.Alphabets[6].Letter);
            Assert.AreEqual("krames", response.Alphabets[6].Source);
            Assert.AreEqual("G", response.Alphabets[7].Letter);
            Assert.AreEqual("krames", response.Alphabets[7].Source);
            Assert.AreEqual("H", response.Alphabets[8].Letter);
            Assert.AreEqual("krames", response.Alphabets[8].Source);
            Assert.AreEqual("I", response.Alphabets[9].Letter);
            Assert.AreEqual("krames", response.Alphabets[9].Source);
            Assert.AreEqual("J", response.Alphabets[10].Letter);
            Assert.AreEqual("krames", response.Alphabets[10].Source);
            Assert.AreEqual("K", response.Alphabets[11].Letter);
            Assert.AreEqual("krames", response.Alphabets[11].Source);
            Assert.AreEqual("L", response.Alphabets[12].Letter);
            Assert.AreEqual("krames", response.Alphabets[12].Source);
            Assert.AreEqual("M", response.Alphabets[13].Letter);
            Assert.AreEqual("krames", response.Alphabets[13].Source);
            Assert.AreEqual("N", response.Alphabets[14].Letter);
            Assert.AreEqual("krames", response.Alphabets[14].Source);
            Assert.AreEqual("O", response.Alphabets[15].Letter);
            Assert.AreEqual("krames", response.Alphabets[15].Source);
            Assert.AreEqual("P", response.Alphabets[16].Letter);
            Assert.AreEqual("krames", response.Alphabets[16].Source);
            Assert.AreEqual("Q", response.Alphabets[17].Letter);
            Assert.AreEqual("krames", response.Alphabets[17].Source);
            Assert.AreEqual("R", response.Alphabets[18].Letter);
            Assert.AreEqual("krames", response.Alphabets[18].Source);
            Assert.AreEqual("S", response.Alphabets[19].Letter);
            Assert.AreEqual("krames", response.Alphabets[19].Source);
            Assert.AreEqual("T", response.Alphabets[20].Letter);
            Assert.AreEqual("krames", response.Alphabets[20].Source);
            Assert.AreEqual("U", response.Alphabets[21].Letter);
            Assert.AreEqual("krames", response.Alphabets[21].Source);
            Assert.AreEqual("V", response.Alphabets[22].Letter);
            Assert.AreEqual("krames", response.Alphabets[22].Source);
            Assert.AreEqual("W", response.Alphabets[23].Letter);
            Assert.AreEqual("krames", response.Alphabets[23].Source);
            Assert.AreEqual("X", response.Alphabets[24].Letter);
            Assert.AreEqual("krames", response.Alphabets[24].Source);
            Assert.AreEqual("Y", response.Alphabets[25].Letter);
            Assert.AreEqual("krames", response.Alphabets[25].Source);
            Assert.AreEqual("Z", response.Alphabets[26].Letter);
            Assert.AreEqual("krames", response.Alphabets[26].Source);
        }
    }
}
