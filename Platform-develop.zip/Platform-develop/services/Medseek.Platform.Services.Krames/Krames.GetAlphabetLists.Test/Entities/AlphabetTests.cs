﻿using Medseek.Platform.Services.Krames.GetAlphabetLists.Entities;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Krames.GetAlphabetLists.Test.Entities
{
    [TestFixture]
    public sealed class AlphabetTests
    {
        [Test]
        public void CanCreateAlphabetWithDefaultConstructor()
        {
            Assert.IsNotNull(new Alphabet());
        }

        [Test]
        public void CanCreateWithParameterConstructor()
        {
            var alphabet = new Alphabet("testletter");
            var expectedLetterValue = "testletter";
            var expectedSourceValue = "krames";

            Assert.IsNotNull(alphabet);
            Assert.AreEqual(alphabet.Letter, expectedLetterValue);
            Assert.AreEqual(alphabet.Source, expectedSourceValue);
        }
    }
}
