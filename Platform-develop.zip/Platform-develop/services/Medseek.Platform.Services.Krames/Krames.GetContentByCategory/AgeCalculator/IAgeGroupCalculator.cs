﻿namespace Medseek.Platform.Services.Krames.GetContentByCategory.AgeCalculator
{
    using Medseek.Platform.Services.Krames.GetContentByCategory.Entities;

    public interface IAgeGroupCalculator
    {
        /// <summary>
        /// Calculates age group based on Age. 
        /// </summary>
        /// <param name="inAge">the age</param>
        /// <returns>an AgeGroup, null if it cannot be calculated.</returns>
        AgeGroup? CalculateAgeGroup(Age inAge);
    }
}
