﻿namespace Medseek.Platform.Services.Krames.GetContentByCategory.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class Settings
    {
        [DataMember]
        public string LicenseKey { get; set; }

        [DataMember]
        public string BaseUrl { get; set; }

        [DataMember]
        public string Username { get; set; }

        [DataMember]
        public string Password { get; set; }
    }
}
