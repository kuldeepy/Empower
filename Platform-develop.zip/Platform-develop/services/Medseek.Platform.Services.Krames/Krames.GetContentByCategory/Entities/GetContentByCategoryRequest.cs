﻿namespace Medseek.Platform.Services.Krames.GetContentByCategory.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetContentByCategoryRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public Category Category { get; set; }

        [DataMember]
        public Age Age { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
