﻿namespace Medseek.Platform.Services.Krames.GetContentByCategory
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Web;
    using System.Xml.Linq;
    using Medseek.Platform.Services.Krames.GetContentByCategory.AgeCalculator;
    using Medseek.Platform.Services.Krames.GetContentByCategory.Entities;
    using Medseek.Platform.Services.Krames.GetContentByCategory.WebClient;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class KramesGetContentByCategoryService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetContentByCategory.Krames";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getcontentbycategory.krames";
        private const string KramesSettingsKey = "krames";
        private const string GetContentByCategoryUrl = "{0}/{1}/Content.svc/GetCollectionContents?xmlRequest={2}";

        private readonly IWebClient webClient;
        private readonly IAgeGroupCalculator ageCalculator;

        public KramesGetContentByCategoryService(IWebClient webClient, IAgeGroupCalculator ageCalculator)
        {
            if (webClient == null)
            {
                throw new ArgumentNullException("webClient");
            }
            if (ageCalculator == null)
            {
                throw new ArgumentNullException("ageCalculator");
            }

            this.webClient = webClient;
            this.ageCalculator = ageCalculator;
        }

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, AutoDelete = false)]
        public GetContentByCategoryResponse GetContentByCategory(GetContentByCategoryRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }
            if (inRequest.Category == null || string.IsNullOrWhiteSpace(inRequest.Category.Id))
            {
                throw new ArgumentException("Request must contain Category.", "inRequest");
            }

            var kramesSettings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any())
                                     ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == KramesSettingsKey)
                                     : null;

            if (kramesSettings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for Krames functionality",
                                                             tenantId));
            }

            var requestXml = BuildGetContentByCategoryRequest(inRequest);

            var uri = string.Format(GetContentByCategoryUrl,
                                    kramesSettings.Settings.BaseUrl,
                                    kramesSettings.Settings.LicenseKey,
                                    HttpUtility.UrlEncode(requestXml));

            using (var response = webClient.OpenRead(uri))
            {
                return BuildGetContentByCategoryResponse(response);
            }
        }

        #region Private Helpers

        private static GetContentByCategoryResponse BuildGetContentByCategoryResponse(Stream response)
        {
            var categoryContentsResponse = new GetContentByCategoryResponse();

            var xmlDoc = XElement.Load(response);

            categoryContentsResponse.ContentItems =
                xmlDoc.Descendants("ContentObject").Select(BuildContentItem).ToList();

            return categoryContentsResponse;
        }

        private static ContentItem BuildContentItem(XElement contentObject)
        {
            return new ContentItem
                {
                    ContentId = GetValue(contentObject, null, "ContentId"),
                    ContentTypeId = GetValue(contentObject, null, "ContentTypeId"),
                    ContentType = GetValue(contentObject, null, "ContentObjectType"),
                    Language = GetValue(contentObject, "Language", "Code"),
                    Title = GetValue(contentObject, "RegularTitle"),
                    Gender = GetValue(contentObject, "GenderCode"), //TODO: A or All?? GetContent returns 'A' & GetContentByCategory returns 'All'
                    Description = GetValue(contentObject, "Blurb"),
                    Source = "krames"
                };
        }

        private static string GetValue(XElement xmlElement, string elementName, string attributeName = null)
        {
            var element = xmlElement;

            if (!string.IsNullOrWhiteSpace(elementName))
            {
                element = xmlElement.Element(elementName);
                if (element == null)
                {
                    return null;
                }
            }

            if (string.IsNullOrWhiteSpace(attributeName))
            {
                return element.Value;
            }

            var attribute = element.Attribute(attributeName);

            return attribute != null ? attribute.Value : null;
        }

        private string BuildGetContentByCategoryRequest(GetContentByCategoryRequest inRequest)
        {
            var getContentElement = new XElement("CollectionContents",
                                                 new XAttribute("IncludeContent", "true"),
                                                 new XAttribute("IncludeBlocked", "false"),
                                                 new XAttribute("IsRecursive", "true"),
                                                 new XAttribute("GetOriginal", "false"),
                                                 new XAttribute("SubtopicId", inRequest.Category.Id));

            if (!string.IsNullOrWhiteSpace(inRequest.LanguageCode))
            {
                getContentElement.Add(new XAttribute("LanguageCode", inRequest.LanguageCode));
            }

            if (!string.IsNullOrWhiteSpace(inRequest.Gender))
            {
                getContentElement.Add(new XAttribute("GenderCode", inRequest.Gender));
            }

            if (inRequest.Age != null)
            {
                getContentElement.Add(new XElement("AgeBins",
                                                   new XElement("AgeBin", GetAgeGroup(inRequest.Age))));
            }

            return getContentElement.ToString();
        }

        private string GetAgeGroup(Age age)
        {
            var ageGroup = "Senior";

            var group = ageCalculator.CalculateAgeGroup(age);
            if (group != null)
            {
                switch (group)
                {
                    case AgeGroup.Infant:
                        ageGroup = "Infant (0 - 11 mo)";
                        break;
                    case AgeGroup.Childhood:
                        ageGroup = "Childhood (11 mo - 12 yrs)";
                        break;
                    case AgeGroup.Teen:
                        ageGroup = "Teen (12 - 18 yrs)";
                        break;
                    case AgeGroup.Adult:
                        ageGroup = "Adult (18+)";
                        break;
                    default:
                        ageGroup = "Senior";
                        break;
                }
            }

            return ageGroup;
        }

        #endregion
    }
}
