﻿namespace Krames.GetContentListByAlphabet.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Web;
    using Krames.GetContentListByAlphabet.AgeCalculator;
    using Krames.GetContentListByAlphabet.Entities;
    using Krames.GetContentListByAlphabet.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    public class KramesGetContentListByAlphabetTests : TestFixture<KramesGetContentListByAlphabetService>
    {
        private const string BaseUrl = "http://external.ws.staywell.com/{0}/Content.svc/SearchContent";
        private const string XmlString = "<ContentList><ContentObject  ContentObjectType=\"Document\" Blocked=\"false\" IsCustom=\"false\" ContentId=\"82838\" ContentTypeId=\"3\"><Language Code=\"en\"/><RegularTitle>Title1</RegularTitle><InvertedTitle>InvertedTitle1</InvertedTitle><Blurb/><Gender>Male</Gender></ContentObject><ContentObject ContentObjectType=\"Document\" Blocked=\"false\" IsCustom=\"false\" ContentId=\"2254\" ContentTypeId=\"1\"><Language Code=\"en\"/><RegularTitle>Title2</RegularTitle><InvertedTitle>InvertedTitle2</InvertedTitle><Blurb>Description2</Blurb><Gender>Male</Gender></ContentObject></ContentList>";
        private Mock<IWebClient> webClient;
        private Mock<IAgeGroupCalculator> ageCalculator;
        private KramesGetContentListByAlphabetService service;
        private GetContentListByAlphabetRequest request;

        /// <summary>
        /// Sets up before each test executed 
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            ageCalculator = Mock<IAgeGroupCalculator>();
            service = new KramesGetContentListByAlphabetService(webClient.Object, ageCalculator.Object);

            request = new GetContentListByAlphabetRequest()
            {
                Age = new Age() { Years = 50, Months = 1, Days = 1 },
                ByLetter = "A",
                Gender = "Male",
                LanguageCode = "en",
                TenantInfo =
                    new Tenant()
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>()
                                                  {
                                                      new KeySettingsPair()
                                                          {
                                                              Key = "krames",
                                                              Settings = new Settings()
                                                                        {
                                                                          LicenseKey = "KramesSiteName",
                                                                          BaseUrl = "http://external.ws.staywell.com"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        /// <summary>
        /// Test if default constructor executes successfully
        /// </summary>
        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<KramesGetContentListByAlphabetService>(service);
        }

        /// <summary>
        /// Test for parameterized constructor throws error when IWebClient object is null
        /// </summary>
        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new KramesGetContentListByAlphabetService(null, ageCalculator.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for parameterized constructor throws error when IAgeCalculator object is null
        /// </summary>
        [Test]
        public void CtorThrowsIfNullAgeCalculator()
        {
            TestDelegate action = () => new KramesGetContentListByAlphabetService(webClient.Object, null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for Request returns Response
        /// </summary>
        [Test]
        public void GetContentListByAlphabetRequestReturnsGetContentListByAlphabetResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Adult);
            var response = service.GetContentListByAlphabet(request);
            Assert.IsInstanceOf<GetContentListByAlphabetResponse>(response);
        }

        /// <summary>
        /// Test for Request returns all Response objects
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_AllObjectsReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.GetContentListByAlphabet(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual(2, response.ContentItems.Count);
        }

        /// <summary>
        /// Test for Request returns all Response objects with correct values
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_ResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Adult);
            var response = service.GetContentListByAlphabet(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.AreEqual("82838", response.ContentItems[0].ContentId);
            Assert.AreEqual("Document", response.ContentItems[0].ContentType);
            Assert.AreEqual("3", response.ContentItems[0].ContentTypeId);
            Assert.AreEqual("en", response.ContentItems[0].Language);
            Assert.AreEqual("Title1", response.ContentItems[0].Title);
            Assert.AreEqual("Male", response.ContentItems[0].Gender);
            Assert.AreEqual("krames", response.ContentItems[0].Source);

            Assert.AreEqual("2254", response.ContentItems[1].ContentId);
            Assert.AreEqual("Document", response.ContentItems[1].ContentType);
            Assert.AreEqual("1", response.ContentItems[1].ContentTypeId);
            Assert.AreEqual("en", response.ContentItems[1].Language);
            Assert.AreEqual("Title2", response.ContentItems[1].Title);
            Assert.AreEqual("Description2", response.ContentItems[1].Description);
            Assert.AreEqual("Male", response.ContentItems[1].Gender);
            Assert.AreEqual("krames", response.ContentItems[1].Source);
        }

        /// <summary>
        /// Test for IWebClient called successfully
        /// </summary>
        [Test]
        public void GetContentListByAlphabetWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            var response = service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for GetContentListByAlphabet method should throw an exception if Args not supplied i.e. GetContentListByAlphabetRequest
        /// </summary>
        [Test]
        public void GetContentListByAlphabetNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetContentListByAlphabet(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Test for application error if Tenant Info is not supplied or null
        /// </summary>
        [Test]
        public void GetContentListByAlphabetNoKramesTenantInformationThrowsApplicationException()
        {
            TestDelegate action = () => service.GetContentListByAlphabet(new GetContentListByAlphabetRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        /// <summary>
        /// Test for Valid web client baseUrl
        /// </summary>
        [Test]
        public void GetContentListByAlphabetValidRequestWebClientBaseUrlIsExpected()
        {
            var expectedUrl = string.Format(BaseUrl, "KramesSiteName");
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Substring(0, a.IndexOf('?')) == expectedUrl))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        [Test]
        public void GetContentListByAlphabetContainsEmptyContentItemResponseContainsContentItemWithNullValues()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(new MemoryStream(Encoding.UTF8.GetBytes("<ContentList><ContentObject/></ContentList>")));
            var response = service.GetContentListByAlphabet(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.ContentItems);
            Assert.IsNull(response.ContentItems[0].ContentId);
            Assert.IsNull(response.ContentItems[0].ContentType);
            Assert.IsNull(response.ContentItems[0].ContentTypeId);
            Assert.IsNull(response.ContentItems[0].Language);
            Assert.IsNull(response.ContentItems[0].Title);
            Assert.IsNull(response.ContentItems[0].Description);
            Assert.IsNull(response.ContentItems[0].Gender);
            Assert.IsNull(response.ContentItems[0].PostingDate);
            Assert.AreEqual("krames", response.ContentItems[0].Source);
        }

        /// <summary>
        /// Test for ByLetter property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_ByLetterSpecifiedInRequest_WebClientQueryStringContainsValue()
        {
            request.ByLetter = "A";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains(HttpUtility.UrlEncode("<ByLetter>A</ByLetter>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for ByLetter property is not supplied in InRequest XML should not contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_ByLetterNotSpecifiedInRequest_WebClientQueryStringDoesNotContainKeyword()
        {
            request.ByLetter = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains(HttpUtility.UrlEncode("</ByLetter>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Gender property is supplied in InRequest XML should contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_GenderSpecifiedInRequest_WebClientQueryStringContainsValue()
        {
            request.Gender = "Male";
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains(HttpUtility.UrlEncode("<Gender>Male</Gender>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Gender property is not supplied in InRequest XML should not contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_GenderNotSpecifiedInRequest_WebClientQueryStringDoesNotContainKeyword()
        {
            request.Gender = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains(HttpUtility.UrlEncode("</Gender>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Language property is not supplied in InRequest XML should not contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet_LanguageNotSpecifiedInRequest_WebClientQueryStringDoesNotContainLanguage()
        {
            request.LanguageCode = null;
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains(HttpUtility.UrlEncode("<Language"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Age property is not supplied in InRequest XML, then CalculateAgeGroup() should not be called
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeNotSpecifiedInRequest_CalculateAgeGroupIsNotCalled()
        {
            request.Age = null;
            ageCalculator = new Mock<IAgeGroupCalculator>(MockBehavior.Strict);
            service = new KramesGetContentListByAlphabetService(webClient.Object, ageCalculator.Object);
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Age property is not supplied in InRequest XML should not contains in Query String Value
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeNotSpecifiedInRequest_WebClientQueryStringDoesNotContainsAgeGroup()
        {
            request.Age = null;
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Teen);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => !a.Contains(HttpUtility.UrlEncode("<AgeGroups>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Age property is supplied in InRequest XML, then CalculateAgeGroup() is called
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeSpecifiedInRequest_CalculateAgeGroupIsCalled()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Adult).Verifiable();
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            ageCalculator.Verify();
        }

        /// <summary>
        /// Test for Age group specified is adult then web client query string contains adult age group
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeSpecifiedInRequest_Adult_WebClientQueryStringContainsAdultAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Adult);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains(HttpUtility.UrlEncode("<AgeGroup>Adult (18+)</AgeGroup>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Age group specified is teen then web client query string contains teen age group
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeSpecifiedInRequest_Teen_WebClientQueryStringContainsTeenAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Teen);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains(HttpUtility.UrlEncode("<AgeGroup>Teen (12 - 18 yrs)</AgeGroup>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Age group specified is childhood then web client query string contains childhood age group
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeSpecifiedInRequest_Childhood_WebClientQueryStringContainsChildhoodAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Childhood);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains(HttpUtility.UrlEncode("<AgeGroup>Childhood (11 mo - 12 yrs)</AgeGroup>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Age group specified is infant then web client query string contains infant age group
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeSpecifiedInRequest_Infant_WebClientQueryStringContainsInfantAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Infant);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains(HttpUtility.UrlEncode("<AgeGroup>Infant (0 - 11 mo)</AgeGroup>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Age group specified is senior then web client query string contains senior age group
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeSpecifiedInRequest_Senior_WebClientQueryStringContainsSeniorAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns(AgeGroup.Senior);
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a.Contains(HttpUtility.UrlEncode("<AgeGroup>Senior</AgeGroup>"))))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        /// <summary>
        /// Test for Age group calculated is null then web client query string contains senior age group as default
        /// </summary>
        [Test]
        public void GetContentListByAlphabet__AgeSpecifiedInRequest_CalculatedAgeGroupIsNull_WebClientQueryStringContainsSeniorAgeGroup()
        {
            ageCalculator.Setup(c => c.CalculateAgeGroup(It.IsAny<Age>())).Returns((AgeGroup?)null);
            webClient.Setup(
                w => w.OpenRead(It.Is<string>(a => a.Contains(HttpUtility.UrlEncode("<AgeGroup>Senior</AgeGroup>")))))
                     .Returns(this.BuildResponseStream())
                     .Verifiable();
            service.GetContentListByAlphabet(request);
            webClient.Verify();
        }

        #region Private Helpers
        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
        #endregion
    }
}
