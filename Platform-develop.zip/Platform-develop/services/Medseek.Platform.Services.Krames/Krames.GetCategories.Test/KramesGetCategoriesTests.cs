﻿namespace Krames.GetCategories.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;

    using Medseek.Platform.Services.Krames.GetCategories;
    using Medseek.Platform.Services.Krames.GetCategories.Entities;
    using Medseek.Platform.Services.Krames.GetCategories.WebClient;
    using Medseek.Util.Testing;

    using Moq;

    using NUnit.Framework;

    [TestFixture]
    public class KramesGetCategoriesTests : TestFixture<KramesGetCategoriesService>
    {
        private const string GetCategoriesUrl = "http://external.ws.staywell.com/{0}/Content.svc/ListCollections";
        private const string ResponseXml =
            "<CollectionList><Collection><RootSubtopicId>34434</RootSubtopicId><CollectionName>About this Site</CollectionName></Collection><Collection><RootSubtopicId>37019</RootSubtopicId><CollectionName>Alchemy Patient Education Sheets</CollectionName></Collection></CollectionList>";

        private Mock<IWebClient> webClient;
        private KramesGetCategoriesService service;
        private GetCategoriesRequest request;

         //<summary>
         //Sets up before each test is executed.
         //</summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();

            service = new KramesGetCategoriesService(webClient.Object);

            request = new GetCategoriesRequest
                {
                    TenantInfo =
                                  new Tenant
                                  {
                                      Name = "TenantName",
                                      Id = "TenantId",
                                      Settings =
                                          new List<KeySettingsPair>
                                                  {
                                                      new KeySettingsPair
                                                          {
                                                              Key = "krames",
                                                              Settings = new Settings
                                                                        {
                                                                          LicenseKey = "KramesSiteName",
                                                                          BaseUrl = "http://external.ws.staywell.com"
                                                                        }
                                                          }
                                                  }
                                  }
                };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            service = new KramesGetCategoriesService(webClient.Object);

            Assert.IsNotNull(service);
            Assert.IsInstanceOf<KramesGetCategoriesService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new KramesGetCategoriesService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: webClient"));
        }

        [Test]
        public void GetCategoriesNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetCategories(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>().And.Message.Contains("Parameter name: inRequest"));
        }

        [Test]
        public void GetCategoriesNoTenantInformationThrowsApplicationException()
        {
            const string exceptionMessage = "Tenant '' is not configured for Krames functionality";

            TestDelegate action = () => service.GetCategories(new GetCategoriesRequest());
            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetCategoriesNoKramesTenantInformationThrowsApplicationExceptionWithCorrectMessage()
        {
            const string exceptionMessage = "Tenant 'TenantId' is not configured for Krames functionality";

            TestDelegate action = () => service.GetCategories(new GetCategoriesRequest
                {
                    TenantInfo = new Tenant
                            {
                                Name = "TenantName",
                                Id = "TenantId",
                                Settings = new List<KeySettingsPair>()
                            }
                });

            Assert.That(action, Throws.InstanceOf<ApplicationException>().And.Message.EqualTo(exceptionMessage));
        }

        [Test]
        public void GetCategoriesWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream()).Verifiable();
            service.GetCategories(request);
            webClient.Verify();
        }

        [Test]
        public void GetCategoriesValidRequestWebClientUrlIsCorrect()
        {
            var expectedUrl = string.Format(GetCategoriesUrl, "KramesSiteName");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.GetCategories(request);
            webClient.Verify();
        }

        [Test]
        public void GetCategories_AllCategoriesReturnedInResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.GetCategories(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Categories);
            Assert.AreEqual(2, response.Categories.Count);
        }

        [Test]
        public void GetCategories_ResponseObjectPopulatedCorrectly()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            
            var response = service.GetCategories(request);
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Categories);
            Assert.AreEqual("34434", response.Categories[0].Id);
            Assert.AreEqual("About this Site", response.Categories[0].Name);
            Assert.AreEqual("krames", response.Categories[0].Source);

            Assert.AreEqual("37019", response.Categories[1].Id);
            Assert.AreEqual("Alchemy Patient Education Sheets", response.Categories[1].Name);
            Assert.AreEqual("krames", response.Categories[1].Source);
        }

        [Test]
        public void GetCategoriesReturnsGetCategoriesResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());
            var response = service.GetCategories(request);
            Assert.IsInstanceOf<GetCategoriesResponse>(response);
        }

        private static Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(ResponseXml));
            return stream;
        }
    }
}
