﻿namespace Medseek.Platform.Services.Adam.GetContentByCategory
{
    using System;
    using Medseek.Platform.Services.Adam.GetContentByCategory.Entities;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class GetContentByCategoryService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetContentByCategory.Adam";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getcontentbycategory.adam";

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, AutoDelete = false)]
        public GetContentByCategoryResponse GetContentByCategory(GetContentByCategoryRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            return new GetContentByCategoryResponse();
        }
    }
}
