﻿namespace Medseek.Platform.Services.Adam.GetContentByCategory.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetContentByCategoryResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
