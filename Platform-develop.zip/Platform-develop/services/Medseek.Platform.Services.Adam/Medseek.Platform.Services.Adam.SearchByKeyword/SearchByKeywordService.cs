﻿namespace Medseek.Platform.Services.Adam.SearchByKeyword
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Web;
    using System.Xml;

    using Medseek.Platform.Services.Adam.SearchByKeyword.Entities;
    using Medseek.Platform.Services.Adam.SearchByKeyword.WebClient;
    using Medseek.Util.Logging;
    using Medseek.Util.MicroServices;

    /// <summary>
    /// Provides services for ADAM information searches.
    /// </summary>
    [RegisterMicroService]
    public class SearchByKeywordService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.SearchByKeyword.Adam";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.searchbykeyword.adam";
        private const string DefaultAdamUrlFormat = "{0}/webservices/transadam3.0/json/ContentService.svc/json/GetKeywordSearchAPI/{1}/{2}/{3}/80/%20/%20/true/en";
        private const string AdamSettingsKey = "adam";
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IWebClient webClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="SearchByKeywordService"/> 
        /// class.
        /// </summary>
        public SearchByKeywordService(IWebClient webClient)
        {
            if (webClient == null)
                throw new ArgumentNullException("webClient");

            this.webClient = webClient;
        }

        /// <summary>
        /// Searches the ADAM resources.
        /// </summary>
        /// <param name="inRequest">
        /// An object describing the search request.
        /// </param>
        /// <returns>
        /// The search results.
        /// </returns>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public SearchByKeywordResponse SearchByKeyword(SearchByKeywordRequest inRequest)
        {
            if (inRequest == null)
                throw new ArgumentNullException("inRequest");
            if (string.IsNullOrWhiteSpace(inRequest.Keyword))
                throw new ArgumentException("keyword must be specified.", "inRequest");

            var settings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any()) ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == AdamSettingsKey) : null;

            if (settings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for Adam functionality", tenantId));
            }

            var username = settings.Settings.Username;
            var password = settings.Settings.Password;
            var baseUrl = settings.Settings.BaseUrl;

            var uri = string.Format(DefaultAdamUrlFormat, baseUrl, HttpUtility.UrlEncode(username), HttpUtility.UrlEncode(password), HttpUtility.UrlEncode(inRequest.Keyword));

            Log.DebugFormat("Sending request; Uri = {0}.", uri);
            var response = new SearchByKeywordResponse() { ContentItems = new List<ContentItem>() };
            using (var stream = webClient.OpenRead(uri))
            {
                response.ContentItems.AddRange(this.BuildContentItems(stream, inRequest));
            }

            return response;
        }

        private IEnumerable<ContentItem> BuildContentItems(Stream stream, SearchByKeywordRequest inRequest)
        {
            var contentItems = new List<ContentItem>();
            using (var reader = new StreamReader(stream))
            {
                var data = reader.ReadToEnd();

                // note: the response from adam comes in a very weird xml-json hybrid format. Basically its xml escaped with json escaping...
                // the below code is to remove that so it basically is a real xml document.
                data = data.Replace("\\\"", "\"");
                data = data.Replace("\\/", "/");
                data = data.Substring(1, data.Length - 2);

                var doc = new XmlDocument();
                doc.LoadXml(data);

                var contentObjects = doc.SelectNodes("/SearchResults/SearchResult");

                if (contentObjects != null)
                {
                    foreach (XmlNode node in contentObjects)
                    {
                        var contentItem = new ContentItem();

                        if (node["productId"] != null)
                        {
                            contentItem.ProductId = node["productId"].InnerXml;
                        }

                        if (node["projectTypeID"] != null)
                        {
                            contentItem.ContentTypeId = node["projectTypeID"].InnerXml;
                        }

                        if (node["genContentID"] != null)
                        {
                            contentItem.ContentId = node["genContentID"].InnerXml;
                        }

                        if (node["articleTitle"] != null)
                        {
                            contentItem.Title = node["articleTitle"].InnerXml;
                        }

                        if (node["snippet"] != null)
                        {
                            contentItem.Description = node["snippet"].InnerXml;
                        }

                        contentItem.Source = "adam";
                        contentItem.Language = inRequest.LanguageCode;

                        contentItems.Add(contentItem);
                    }
                }
            }

            return contentItems;
        }
    }
}