﻿namespace Medseek.Platform.Services.Adam.SearchByKeyword.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Web;

    using Medseek.Platform.Services.Adam.SearchByKeyword.Entities;
    using Medseek.Platform.Services.Adam.SearchByKeyword.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public sealed class SearchByKeywordTests : TestFixture<SearchByKeywordService>
    {
        private const string BaseUrl = "{0}/webservices/transadam3.0/json/ContentService.svc/json/GetKeywordSearchAPI/{1}/{2}/{3}/80/%20/%20/true/en";
        private const string XmlString = "\"<SearchResults xmlns:ax=\"http:\\/\\/www.adam.com\" xmlns:adam=\"urn:DataProcessor\" recordcount=\"3176\"><SearchResult><articleTitle>Heart MRI<\\/articleTitle><productId productname=\"HIE Multimedia\">117<\\/productId><projectTypeID>1<\\/projectTypeID><genContentID>003795<\\/genContentID><subContent>Test<\\/subContent><weight>98<\\/weight><snippet>Heart magnetic resonance imaging (MRI) is an imaging method that uses powerful magnets and radio waves to create pictures of the heart.  It does not use radiation (x-rays). Single MRI images are called slices.  The images can be stored on a computer or printed on film.  One exam produces dozens or sometimes hundreds of images. The test may be done...<\\/snippet><medicalspecialty>Radiology<\\/medicalspecialty><\\/SearchResult><\\/SearchResults>\"";
        private const string AdamBaseUrl = "http://ws2.adam.com";
        private const string Username = "username";
        private const string Password = "password";
        private const string KeywordSearchValue = "keyWordSearchValue";

        private Mock<IWebClient> webClient;
        private SearchByKeywordService service;
        private SearchByKeywordRequest request;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            service = new SearchByKeywordService(webClient.Object);
            request = new SearchByKeywordRequest()
            {
                Keyword = KeywordSearchValue,
                LanguageCode = "en",
                TenantInfo =
                    new Tenant()
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>()
                                                  {
                                                      new KeySettingsPair()
                                                          {
                                                              Key = "adam",
                                                              Settings = new Settings()
                                                                        {
                                                                          LicenseKey = null,
                                                                          BaseUrl = AdamBaseUrl,
                                                                          Username = Username,
                                                                          Password = Password
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<SearchByKeywordService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new SearchByKeywordService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchByKeywordReturnsSearchByKeywordResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.IsInstanceOf<SearchByKeywordResponse>(response);
        }

        [Test]
        public void SearchByKeywordWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            var response = service.SearchByKeyword(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByKeywordNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.SearchByKeyword(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchByKeywordNoKeywordSpecifiedThrowsArgumentException()
        {
            TestDelegate action = () => service.SearchByKeyword(new SearchByKeywordRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void SearchByKeywordNoAdamTenantInformationThrowsApplicationException()
        {
            TestDelegate action = () => service.SearchByKeyword(new SearchByKeywordRequest() { Keyword = KeywordSearchValue });
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void SearchByKeywordNoAdamTenantInformationNotNullThrowsApplicationException()
        {
            TestDelegate action = () => service.SearchByKeyword(new SearchByKeywordRequest() { TenantInfo = new Tenant() { Settings = new List<KeySettingsPair>() }, Keyword = KeywordSearchValue });
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void SearchByKeywordValidRequestWebClientBaseUrlIsExpected()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(KeywordSearchValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream()).Verifiable();
            service.SearchByKeyword(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByKeywordResponse_ProductIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(KeywordSearchValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.AreEqual("117", response.ContentItems[0].ProductId);
        }

        [Test]
        public void SearchByKeywordResponse_ProjectTypeIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(KeywordSearchValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.AreEqual("1", response.ContentItems[0].ContentTypeId);
        }

        [Test]
        public void SearchByKeywordResponse_GenContentIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(KeywordSearchValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.AreEqual("003795", response.ContentItems[0].ContentId);
        }

        [Test]
        public void SearchByKeywordResponse_ArticleTitleIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(KeywordSearchValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.AreEqual("Heart MRI", response.ContentItems[0].Title);
        }

        [Test]
        public void SearchByKeywordResponse_SnippetIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(KeywordSearchValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.AreEqual("Heart magnetic resonance imaging (MRI) is an imaging method that uses powerful magnets and radio waves to create pictures of the heart.  It does not use radiation (x-rays). Single MRI images are called slices.  The images can be stored on a computer or printed on film.  One exam produces dozens or sometimes hundreds of images. The test may be done...", response.ContentItems[0].Description);
        }

        [Test]
        public void SearchByKeywordResponse_SourceIsCorrect()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(KeywordSearchValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.AreEqual("adam", response.ContentItems[0].Source);
        }

        [Test]
        public void SearchByKeywordResponse_LanguageCodeIsCorrect()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(KeywordSearchValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByKeyword(request);
            Assert.AreEqual(request.LanguageCode, response.ContentItems[0].Language);
        }

        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
    }
}
