﻿namespace GetAlphabetLists.Test
{
    using System;
    using System.Collections.Generic;

    using Medseek.Platform.Services.Adam.GetAlphabetLists;
    using Medseek.Platform.Services.Adam.GetAlphabetLists.Entities;
    using Medseek.Util.Testing;
    using NUnit.Framework;

    [TestFixture]
    public sealed class GetAlphabetListsServiceTests : TestFixture<GetAlphabetListsService>
    {
        private GetAlphabetListsRequest request;
        private GetAlphabetListsService service;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            service = new GetAlphabetListsService();
            request = new GetAlphabetListsRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                            {
                                                      new KeySettingsPair
                                                      {
                                                              Key = "adam",
                                                              Settings = new Settings
                                                              {
                                                                          BaseUrl = "someurl"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<GetAlphabetListsService>(service);
        }

        [Test]
        public void GetAlphabetListsReturnsGetAlphabetListsResponse()
        {
            var response = service.GetAlphabetLists(request);
            Assert.IsInstanceOf<GetAlphabetListsResponse>(response);
        }

        [Test]
        public void GetAlphabetListsNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetAlphabetLists(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }
    }
}
