﻿namespace Medseek.Platform.Services.Adam.GetNews.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;
    
    [DataContract(Namespace = "")]
    public class GetNewsRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string SearchPhrase { get; set; }

        [DataMember]
        public string MaxDocuments { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
