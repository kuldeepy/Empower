﻿namespace Medseek.Platform.Services.Adam.GetNews.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class ContentItem
    {
        [DataMember]
        public string ContentType { get; set; }

        [DataMember]
        public string ContentTypeId { get; set; }

        [DataMember]
        public string ContentId { get; set; }

        [DataMember]
        public string ProductId { get; set; }

        [DataMember]
        public string Language { get; set; }

        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public string Source { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string PostingDate { get; set; }

        [DataMember]
        public string Link { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public string Content { get; set; }
    }
}
