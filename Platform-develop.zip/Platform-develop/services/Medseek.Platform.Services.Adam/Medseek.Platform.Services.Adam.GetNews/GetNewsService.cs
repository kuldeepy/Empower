﻿namespace Medseek.Platform.Services.Adam.GetNews
{
    using System;
    using Medseek.Platform.Services.Adam.GetNews.Entities;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class GetNewsService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetNews.Adam";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getnews.adam";

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetNewsResponse GetNews(GetNewsRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            return new GetNewsResponse();
        }
    }
}
