﻿namespace Medseek.Platform.Services.Adam.GetContentListByAlphabet.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class Age
    {
        [DataMember]
        public int Days { get; set; }

        [DataMember]
        public int Months { get; set; }

        [DataMember]
        public int Years { get; set; }
    }
}
