﻿namespace Medseek.Platform.Services.Adam.GetContentListByAlphabet
{
    using System;
    using Medseek.Platform.Services.Adam.GetContentListByAlphabet.Entities;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class GetContentListByAlphabetService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetContentListByAlphabet.Adam";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getcontentlistbyalphabet.adam";

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetContentListByAlphabetResponse GetContentListByAlphabet(GetContentListByAlphabetRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            return new GetContentListByAlphabetResponse();
        }
    }
}
