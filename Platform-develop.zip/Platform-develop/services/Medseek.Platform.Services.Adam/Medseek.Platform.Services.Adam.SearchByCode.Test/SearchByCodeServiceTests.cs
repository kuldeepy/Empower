﻿namespace Medseek.Platform.Services.Adam.SearchByCode.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Web;

    using Medseek.Platform.Services.Adam.SearchByCode.Entities;
    using Medseek.Platform.Services.Adam.SearchByCode.WebClient;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public sealed class SearchByCodeTests : TestFixture<SearchByCodeService>
    {
        private const string BaseUrl = "{0}/webservices/transadam3.0/json/ContentService.svc/json/GetKeywordSearchAPI/{1}/{2}/%20/80/%20/{3}/true/en";
        private const string XmlString = "\"<SearchResults xmlns:ax=\"http:\\/\\/www.adam.com\" xmlns:adam=\"urn:DataProcessor\" recordcount=\"3176\"><SearchResult><articleTitle>Heart MRI<\\/articleTitle><productId productname=\"HIE Multimedia\">117<\\/productId><projectTypeID>1<\\/projectTypeID><genContentID>003795<\\/genContentID><subContent>Test<\\/subContent><weight>98<\\/weight><snippet>Heart magnetic resonance imaging (MRI) is an imaging method that uses powerful magnets and radio waves to create pictures of the heart.  It does not use radiation (x-rays). Single MRI images are called slices.  The images can be stored on a computer or printed on film.  One exam produces dozens or sometimes hundreds of images. The test may be done...<\\/snippet><medicalspecialty>Radiology<\\/medicalspecialty><\\/SearchResult><\\/SearchResults>\"";
        private const string AdamBaseUrl = "http://ws2.adam.com";
        private const string Username = "username";
        private const string Password = "password";
        private const string CodeValue = "codeValue";

        private Mock<IWebClient> webClient;
        private SearchByCodeService service;
        private SearchByCodeRequest request;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            service = new SearchByCodeService(webClient.Object);
            request = new SearchByCodeRequest()
            {
                Code = CodeValue,
                CodeSystemId = "codeSystemId",
                TenantInfo =
                    new Tenant()
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>()
                                                  {
                                                      new KeySettingsPair()
                                                          {
                                                              Key = "adam",
                                                              Settings = new Settings()
                                                                        {
                                                                          LicenseKey = null,
                                                                          BaseUrl = AdamBaseUrl,
                                                                          Username = Username,
                                                                          Password = Password
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<SearchByCodeService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new SearchByCodeService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchByCodeReturnsSearchByCodeResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.IsInstanceOf<SearchByCodeResponse>(response);
        }

        [Test]
        public void SearchByCodeWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            var response = service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodeNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.SearchByCode(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchByCodeNoCodeSpecifiedThrowsArgumentException()
        {
            TestDelegate action = () => service.SearchByCode(new SearchByCodeRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void SearchByCodeNoAdamTenantInformationThrowsApplicationException()
        {
            TestDelegate action = () => service.SearchByCode(new SearchByCodeRequest() { Code = CodeValue });
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void SearchByCodeNoAdamTenantInformationNotNullThrowsApplicationException()
        {
            TestDelegate action = () => service.SearchByCode(new SearchByCodeRequest() { TenantInfo = new Tenant() { Settings = new List<KeySettingsPair>() }, Code = CodeValue });
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void SearchByCodeValidRequestWebClientBaseUrlIsExpected()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(CodeValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream()).Verifiable();
            service.SearchByCode(request);
            webClient.Verify();
        }

        [Test]
        public void SearchByCodeResponse_ProductIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(CodeValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.AreEqual("117", response.ContentItems[0].ProductId);
        }

        [Test]
        public void SearchByCodeResponse_ProjectTypeIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(CodeValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.AreEqual("1", response.ContentItems[0].ContentTypeId);
        }

        [Test]
        public void SearchByCodeResponse_GenContentIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(CodeValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.AreEqual("003795", response.ContentItems[0].ContentId);
        }

        [Test]
        public void SearchByCodeResponse_ArticleTitleIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(CodeValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.AreEqual("Heart MRI", response.ContentItems[0].Title);
        }

        [Test]
        public void SearchByCodeResponse_SnippetIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(CodeValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.AreEqual("Heart magnetic resonance imaging (MRI) is an imaging method that uses powerful magnets and radio waves to create pictures of the heart.  It does not use radiation (x-rays). Single MRI images are called slices.  The images can be stored on a computer or printed on film.  One exam produces dozens or sometimes hundreds of images. The test may be done...", response.ContentItems[0].Description);
        }

        [Test]
        public void SearchByCodeResponse_SourceIsCorrect()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(CodeValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.AreEqual("adam", response.ContentItems[0].Source);
        }

        [Test]
        public void SearchByCodeResponse_LanguageCodeIsCorrect()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password), HttpUtility.UrlEncode(CodeValue));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.SearchByCode(request);
            Assert.AreEqual(request.LanguageCode, response.ContentItems[0].Language);
        }

        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
    }
}
