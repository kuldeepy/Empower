﻿namespace GetNews.Test
{
    using System;
    using System.Collections.Generic;

    using Medseek.Platform.Services.Adam.GetNews;
    using Medseek.Platform.Services.Adam.GetNews.Entities;
    using Medseek.Util.Testing;
    using NUnit.Framework;

    [TestFixture]
    public sealed class GetNewsServiceTests : TestFixture<GetNewsService>
    {
        private GetNewsRequest request;
        private GetNewsService service;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            service = new GetNewsService();
            request = new GetNewsRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                            {
                                                      new KeySettingsPair
                                                      {
                                                              Key = "adam",
                                                              Settings = new Settings
                                                              {
                                                                          BaseUrl = "someurl"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<GetNewsService>(service);
        }

        [Test]
        public void GetNewsReturnsGetNewsResponse()
        {
            var response = service.GetNews(request);
            Assert.IsInstanceOf<GetNewsResponse>(response);
        }

        [Test]
        public void GetNewsNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetNews(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }
    }
}
