﻿namespace Medseek.Platform.Services.Adam.GetResourceContent
{
    using System;
    using System.Linq;

    using Medseek.Platform.Services.Adam.GetResourceContent.Entities;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class GetResourceContentService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetResourceContent.Adam";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getresourcecontent.adam";

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetResourceContentResponse GetResourceContent(GetResourceContentRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            return new GetResourceContentResponse();
        }
    }
}
