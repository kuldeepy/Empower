﻿namespace GetContentByCategory.Test
{
    using System;
    using System.Collections.Generic;

    using Medseek.Platform.Services.Adam.GetContentByCategory;
    using Medseek.Platform.Services.Adam.GetContentByCategory.Entities;
    using Medseek.Util.Testing;
    using NUnit.Framework;

    [TestFixture]
    public sealed class GetContentByCategoryServiceTests : TestFixture<GetContentByCategoryService>
    {
        private GetContentByCategoryRequest request;
        private GetContentByCategoryService service;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            service = new GetContentByCategoryService();
            request = new GetContentByCategoryRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                            {
                                                      new KeySettingsPair
                                                      {
                                                              Key = "adam",
                                                              Settings = new Settings
                                                              {
                                                                          BaseUrl = "someurl"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<GetContentByCategoryService>(service);
        }

        [Test]
        public void GetContentByCategoryReturnsGetContentByCategoryResponse()
        {
            var response = service.GetContentByCategory(request);
            Assert.IsInstanceOf<GetContentByCategoryResponse>(response);
        }

        [Test]
        public void GetContentByCategoryullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetContentByCategory(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }
    }
}
