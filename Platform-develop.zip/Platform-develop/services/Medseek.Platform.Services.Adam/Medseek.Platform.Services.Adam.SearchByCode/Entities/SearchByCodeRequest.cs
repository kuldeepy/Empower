﻿namespace Medseek.Platform.Services.Adam.SearchByCode.Entities
{
    using System.Runtime.Serialization;

    using Medseek.Platform.Services.Adam.SearchByCode.Entities;

    [DataContract(Namespace = "")]
    public class SearchByCodeRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember(IsRequired = true)]
        public string Code { get; set; }

        [DataMember(IsRequired = true)]
        public string CodeSystemId { get; set; }

        [DataMember]
        public Age Age { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
