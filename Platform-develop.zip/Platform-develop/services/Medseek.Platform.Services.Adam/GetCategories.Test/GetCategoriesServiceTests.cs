﻿namespace GetCategories.Test
{
    using System;
    using System.Collections.Generic;

    using Medseek.Platform.Services.Adam.GetCategories;
    using Medseek.Platform.Services.Adam.GetCategories.Entities;
    using Medseek.Util.Testing;
    using NUnit.Framework;

    [TestFixture]
    public sealed class GetCategoriesServiceTests : TestFixture<GetCategoriesService>
    {
        private GetCategoriesRequest request;
        private GetCategoriesService service;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            service = new GetCategoriesService();
            request = new GetCategoriesRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                            {
                                                      new KeySettingsPair
                                                      {
                                                              Key = "adam",
                                                              Settings = new Settings
                                                              {
                                                                          BaseUrl = "someurl"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<GetCategoriesService>(service);
        }

        [Test]
        public void GetCategoriesReturnsGetCategoriesResponse()
        {
            var response = service.GetCategories(request);
            Assert.IsInstanceOf<GetCategoriesResponse>(response);
        }

        [Test]
        public void GetCategoriesNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetCategories(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }
    }
}
