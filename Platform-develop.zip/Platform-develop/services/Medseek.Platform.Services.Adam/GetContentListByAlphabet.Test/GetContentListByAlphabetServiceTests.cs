﻿namespace GetContentListByAlphabet.Test
{
    using System;
    using System.Collections.Generic;

    using Medseek.Platform.Services.Adam.GetContentListByAlphabet;
    using Medseek.Platform.Services.Adam.GetContentListByAlphabet.Entities;
    using Medseek.Util.Testing;
    using NUnit.Framework;

    [TestFixture]
    public sealed class GetContentListByAlphabetServiceTests : TestFixture<GetContentListByAlphabetService>
    {
        private GetContentListByAlphabetRequest request;
        private GetContentListByAlphabetService service;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            service = new GetContentListByAlphabetService();
            request = new GetContentListByAlphabetRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                            {
                                                      new KeySettingsPair
                                                      {
                                                              Key = "adam",
                                                              Settings = new Settings
                                                              {
                                                                          BaseUrl = "someurl"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<GetContentListByAlphabetService>(service);
        }

        [Test]
        public void GetContentListByAlphabetReturnsGetContentListByAlphabetResponse()
        {
            var response = service.GetContentListByAlphabet(request);
            Assert.IsInstanceOf<GetContentListByAlphabetResponse>(response);
        }

        [Test]
        public void GetContentListByAlphabetNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetContentListByAlphabet(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }
    }
}
