﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Medseek")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright © 2014")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyDescription("Micro-service for performing ADAM information searches.")]
[assembly: AssemblyProduct("Medseek Platform")]
[assembly: AssemblyTitle("Medseek Platform - ADAM Service")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.*")]
[assembly: ComVisible(false)]
[assembly: Guid("b57f0493-0fc3-41eb-a61f-4f08a5e489fa")]
