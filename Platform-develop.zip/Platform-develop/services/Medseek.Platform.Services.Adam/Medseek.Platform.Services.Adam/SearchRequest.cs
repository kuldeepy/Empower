﻿namespace Medseek.Platform.Services.Adam
{
    using System.Runtime.Serialization;

    /// <summary>
    /// Describes a search request.
    /// </summary>
    [DataContract(Namespace = "")]
    public class SearchRequest
    {
        /// <summary>
        /// Gets or sets the search terms associated with the request.
        /// </summary>
        [DataMember]
        public string SearchTerms
        {
            get;
            set;
        }
    }
}