﻿namespace Medseek.Platform.Services.Adam
{
    using System.Runtime.Serialization;

    /// <summary>
    /// Patient education class.
    /// </summary>
    [DataContract(Namespace = "")]
    public class SearchResult
    {
        /// <summary>
        /// Gets or sets the title of the resource.
        /// </summary>
        [DataMember]
        public string Title
        {
            get; 
            set;
        }

        /// <summary>
        /// Gets or sets the link to the resource.
        /// </summary>
        [DataMember]
        public string Link
        {
            get; 
            set;
        }

        /// <summary>
        /// Gets or sets the description of the resource.
        /// </summary>
        [DataMember]
        public string Description
        {
            get; 
            set;
        }

        /// <summary>
        /// Gets or sets the source.
        /// </summary>
        /// <value>
        /// The source.
        /// </value>
        [DataMember]
        public SearchSource Source
        {
            get; 
            set;
        }
    }
}