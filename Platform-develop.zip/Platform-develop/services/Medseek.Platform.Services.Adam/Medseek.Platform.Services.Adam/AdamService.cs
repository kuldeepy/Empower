﻿namespace Medseek.Platform.Services.Adam
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Web;
    using System.Xml.Linq;
    using Medseek.Util.Interactive;
    using Medseek.Util.Logging;
    using Medseek.Util.MicroServices;

    /// <summary>
    /// Provides services for ADAM information searches.
    /// </summary>
    [RegisterMicroService]
    public class AdamService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Adam.AdamService";
        private const string DefaultAdamUrlFormat = "http://coldstone.adam.com/content.aspx?productid=26&keyword={0}";
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IWebClient webClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="AdamService"/> 
        /// class.
        /// </summary>
        public AdamService(IWebClient webClient)
        {
            if (webClient == null)
                throw new ArgumentNullException("webClient");

            this.webClient = webClient;
        }

        /// <summary>
        /// Searches the ADAM resources.
        /// </summary>
        /// <param name="request">
        /// An object describing the search request.
        /// </param>
        /// <returns>
        /// The search results.
        /// </returns>
        [MicroServiceBinding("medseek-api", "medseek.platform.adam.search", ConsumeQueue, AutoDelete = false)]
        public IEnumerable<SearchResult> Search(SearchRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (string.IsNullOrWhiteSpace(request.SearchTerms))
                throw new ArgumentException("Request search terms must be specified.", "request");

            var uri = string.Format(DefaultAdamUrlFormat, HttpUtility.UrlEncode(request.SearchTerms));
            Log.DebugFormat("Sending request; Uri = {0}.", uri);
            using (var stream = webClient.OpenRead(uri))
            {
                return XElement.Load(stream)
                    .Elements("searchResult")
                    .Select(x => new SearchResult
                    {
                        Title = x.Element("articleTitle").Value,
                        Description = x.Element("snippet").Value,
                        Link = x.Element("articleURL").Value,                        
                    })
                    .Do(x => Log.DebugFormat("Title = {0}, Link = {1}, Description = {2}", x.Title, x.Link, x.Description))
                    .ToArray();
            }
        }
    }
}