﻿namespace Medseek.Platform.Services.Adam
{
    using System.Runtime.Serialization;

    /// <summary>
    /// Education Search Source
    /// </summary>
    [DataContract(Namespace = "")]
    public enum SearchSource
    {
        /// <summary>
        /// Manual search for ADAM content
        /// </summary>
        [EnumMember]
        AdamManual,

        /// <summary>
        /// Automated search for ADAM content
        /// </summary>
        [EnumMember]
        AdamAutomated,

        /// <summary>
        /// Info Button search
        /// </summary>
        [EnumMember]
        InfoButton,
    }
}