﻿namespace Medseek.Platform.Services.Adam.GetDocument.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetDocumentRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string ContentTypeId { get; set; }

        [DataMember]
        public string ContentId { get; set; }

        [DataMember]
        public string ProductId { get; set; }

        [DataMember]
        public string DocumentFormat { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
