﻿namespace Medseek.Platform.Services.Adam.GetDocument
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Web;
    using System.Xml;
    using Medseek.Platform.Services.Adam.GetDocument.Entities;
    using Medseek.Platform.Services.Adam.GetDocument.WebClient;
    using Medseek.Util.Logging;
    using Medseek.Util.MicroServices;

    /// <summary>
    /// Provides services for ADAM information searches.
    /// </summary>
    [RegisterMicroService]
    public class GetDocumentService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetDocument.Adam";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getdocument.adam";
        private const string DefaultAdamUrlFormat = "{0}/webservices/transadam3.0/json/ContentService.svc/json/GetContentString/{1}/{2}/{3}/%20/{4}/{5}";
        private const string AdamSettingsKey = "adam";
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IWebClient webClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="GetDocumentService"/> 
        /// class.
        /// </summary>
        public GetDocumentService(IWebClient webClient)
        {
            if (webClient == null)
                throw new ArgumentNullException("webClient");

            this.webClient = webClient;
        }

        /// <summary>
        /// Searches the ADAM resources.
        /// </summary>
        /// <param name="inRequest">
        /// An object describing the search request.
        /// </param>
        /// <returns>
        /// The search results.
        /// </returns>
        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetDocumentResponse GetDocument(GetDocumentRequest inRequest)
        {
            if (inRequest == null)
                throw new ArgumentNullException("inRequest");

            if (string.IsNullOrEmpty(inRequest.ContentId))
                throw new ArgumentException("inRequest.ContentId");

            if (string.IsNullOrEmpty(inRequest.ProductId))
                throw new ArgumentException("inRequest.ProductId");

            if (string.IsNullOrEmpty(inRequest.ContentTypeId))
                throw new ArgumentException("inRequest.ContentTypeId");

            var settings = (inRequest.TenantInfo != null && inRequest.TenantInfo.Settings.Any()) ? inRequest.TenantInfo.Settings.FirstOrDefault(i => i.Key == AdamSettingsKey) : null;

            if (settings == null)
            {
                var tenantId = inRequest.TenantInfo != null ? inRequest.TenantInfo.Id : null;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for Adam functionality", tenantId));
            }

            var username = settings.Settings.Username;
            var password = settings.Settings.Password;
            var baseUrl = settings.Settings.BaseUrl;

            var uri = string.Format(DefaultAdamUrlFormat, baseUrl, HttpUtility.UrlEncode(inRequest.ProductId), HttpUtility.UrlEncode(inRequest.ContentTypeId), HttpUtility.UrlEncode(inRequest.ContentId), HttpUtility.UrlEncode(username), HttpUtility.UrlEncode(password));

            Log.DebugFormat("Sending request; Uri = {0}.", uri);
            var response = new GetDocumentResponse() { ContentItems = new List<ContentItem>() };
            using (var stream = webClient.OpenRead(uri))
            {
                response.ContentItems.AddRange(this.BuildContentItems(stream, inRequest));
            }

            return response;
        }

        private IEnumerable<ContentItem> BuildContentItems(Stream stream, GetDocumentRequest inRequest)
        {
            var contentItems = new List<ContentItem>();
            using (var reader = new StreamReader(stream))
            {
                var data = reader.ReadToEnd();

                // note: the response from adam comes in a very weird xml-json hybrid format. Basically its xml escaped with json escaping...
                // the below code is to remove that so it basically is a real xml document.
                data = data.Replace("\\\"", "\"");
                data = data.Replace("\\/", "/");
                data = data.Substring(1, data.Length - 2);

                var doc = new XmlDocument();
                doc.LoadXml(data);

                var contentObject = doc.DocumentElement;

                if (contentObject != null)
                {
                    var contentItem = new ContentItem()
                                            {
                                                ContentId = inRequest.ContentId,
                                                ContentTypeId = inRequest.ContentTypeId,
                                                ProductId = inRequest.ProductId,
                                                Content = data,
                                            };

                    if (contentObject.Attributes["title"] != null)
                    {
                        contentItem.Title = contentObject.Attributes["title"].Value;
                    }

                    contentItem.Source = "adam";
                    contentItem.Language = inRequest.LanguageCode;

                    contentItems.Add(contentItem);
                }
            }

            return contentItems;
        }
    }
}