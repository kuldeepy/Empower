﻿namespace GetResourceContent.Test
{
    using System;
    using System.Collections.Generic;

    using Medseek.Platform.Services.Adam.GetResourceContent;
    using Medseek.Platform.Services.Adam.GetResourceContent.Entities;
    using Medseek.Util.Testing;
    using NUnit.Framework;

    [TestFixture]
    public sealed class GetResourceContentServiceTests : TestFixture<GetResourceContentService>
    {
        private GetResourceContentRequest request;
        private GetResourceContentService service;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            service = new GetResourceContentService();
            request = new GetResourceContentRequest
            {
                TenantInfo =
                    new Tenant
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>
                            {
                                                      new KeySettingsPair
                                                      {
                                                              Key = "adam",
                                                              Settings = new Settings
                                                              {
                                                                          BaseUrl = "someurl"
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<GetResourceContentService>(service);
        }

        [Test]
        public void GetResourceContentReturnsGetResourceContentResponse()
        {
            var response = service.GetResourceContent(request);
            Assert.IsInstanceOf<GetResourceContentResponse>(response);
        }

        [Test]
        public void GetResourceContentNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetResourceContent(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }
    }
}
