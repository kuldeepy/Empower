﻿namespace Medseek.Platform.Services.Adam.GetCategories.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class KeySettingsPair
    {
        [DataMember]
        public string Key { get; set; }

        [DataMember]
        public Settings Settings { get; set; }
    }
}
