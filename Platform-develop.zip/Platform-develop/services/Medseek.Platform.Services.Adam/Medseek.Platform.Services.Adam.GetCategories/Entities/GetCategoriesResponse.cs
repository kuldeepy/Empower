﻿namespace Medseek.Platform.Services.Adam.GetCategories.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetCategoriesResponse
    {
        [DataMember]
        public List<Category> Categories { get; set; }
    }
}
