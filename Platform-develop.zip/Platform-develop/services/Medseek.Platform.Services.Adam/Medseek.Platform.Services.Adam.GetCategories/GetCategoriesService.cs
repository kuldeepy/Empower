﻿namespace Medseek.Platform.Services.Adam.GetCategories
{
    using System;
    using Medseek.Platform.Services.Adam.GetCategories.Entities;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class GetCategoriesService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetCategories.Adam";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getcategories.adam";

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetCategoriesResponse GetCategories(GetCategoriesRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            return new GetCategoriesResponse();
        }
    }
}
