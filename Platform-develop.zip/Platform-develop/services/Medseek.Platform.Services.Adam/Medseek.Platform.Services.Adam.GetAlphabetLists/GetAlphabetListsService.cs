﻿namespace Medseek.Platform.Services.Adam.GetAlphabetLists
{
    using System;
    using Medseek.Platform.Services.Adam.GetAlphabetLists.Entities;
    using Medseek.Util.MicroServices;

    [RegisterMicroService]
    public class GetAlphabetListsService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Content.GetAlphabetLists.Adam";
        private const string Exchange = "medseek-api";
        private const string RoutingKey = "medseek.platform.services.contentservice.getalphabetlists.adam";

        [MicroServiceBinding(Exchange, RoutingKey, ConsumeQueue, IsOneWay = false, AutoDelete = false)]
        public GetAlphabetListsResponse GetAlphabetLists(GetAlphabetListsRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            return new GetAlphabetListsResponse();
        }
    }
}
