﻿namespace Medseek.Platform.Services.Adam.GetAlphabetLists.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class Alphabet 
    {
        public Alphabet()
        {
        }

        public Alphabet(string letter)
        {
            Letter = letter;
            Source = "adam";
        }

        [DataMember]
        public string Letter { get; set; }

        [DataMember]
        public string Source { get; set; }
    }
}
