﻿namespace Medseek.Platform.Services.Adam.GetAlphabetLists.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetAlphabetListsResponse
    {
        [DataMember]
        public List<Alphabet> Alphabets { get; set; }
    }
}
