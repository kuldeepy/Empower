﻿namespace Medseek.Platform.Services.Adam.GetAlphabetLists.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class GetAlphabetListsRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }
    }
}
