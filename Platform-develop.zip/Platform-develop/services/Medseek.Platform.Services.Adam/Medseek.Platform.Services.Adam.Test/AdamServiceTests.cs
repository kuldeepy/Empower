﻿namespace Medseek.Platform.Services.Adam.Test
{
    using System;
    using System.IO;
    using System.Text;
    using Medseek.Util.Testing;
    using Moq;
    using NUnit.Framework;

    /// <summary>
    /// Tests for the <see cref="AdamService"/> class.
    /// </summary>
    [TestFixture]
    public sealed class AdamServiceTests : TestFixture<AdamService>
    {
        private Mock<IWebClient> webClient;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
        }

        /// <summary>
        /// Verifies that an exception is thrown if webClient is null.
        /// </summary>
        [Test]
        public void ThrowsArgumentNullExceptionIfWebClientIsNull()
        {
            Assert.Throws<ArgumentNullException>(() => new AdamService(null));
        }

        /// <summary>
        /// Verifies that an exception is thrown for bad arguments.
        /// </summary>
        [Test]
        public void SearchThrowsIfNullRequest()
        {
            TestDelegate action = () => Obj.Search(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        /// <summary>
        /// Verifies that an exception is thrown for bad arguments.
        /// </summary>
        [Test]
        public void SearchThrowsIfNullSearchTerms()
        {
            TestDelegate action = () => Obj.Search(new SearchRequest { SearchTerms = null });
            Assert.That(action, Throws.ArgumentException);
        }

        /// <summary>
        /// Verifies that the search results are returned.
        /// </summary>
        [Test]
        public void SearchReturnsResults()
        {
            webClient.Setup(x => 
                x.OpenRead(It.Is<string>(a => a.EndsWith("abcd"))))
                .Returns(new MemoryStream(Encoding.Default.GetBytes(@"
<results>
    <searchResult>
        <articleTitle>Title 1</articleTitle>
        <snippet>Snippet 1</snippet>
        <articleURL>Link 1</articleURL>
    </searchResult>
    <searchResult>
        <articleTitle>Title 2</articleTitle>
        <snippet>Snippet 2</snippet>
        <articleURL>Link 2</articleURL>
    </searchResult>
</results>
")));

            var results = Obj.Search(new SearchRequest { SearchTerms = "abcd" });
            
            Assert.That(results, Has
                .Some.Matches<SearchResult>(x => 
                    x.Title == "Title 1" && 
                    x.Description == "Snippet 1" &&
                    x.Link == "Link 1")
                 .And
                 .Some.Matches<SearchResult>(x =>
                    x.Title == "Title 2" &&
                    x.Description == "Snippet 2" &&
                    x.Link == "Link 2"));
        }
    }
}