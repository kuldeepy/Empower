﻿namespace Medseek.Platform.Services.Adam.GetDocument.Test
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Web;

    using Medseek.Platform.Services.Adam.GetDocument;
    using Medseek.Platform.Services.Adam.GetDocument.Entities;
    using Medseek.Platform.Services.Adam.GetDocument.WebClient;
    using Medseek.Util.Testing;

    using Moq;

    using NUnit.Framework;

    [TestFixture]
    public sealed class GetDocumentTests : TestFixture<GetDocumentService>
    {
        private const string BaseUrl = "{0}/webservices/transadam3.0/json/ContentService.svc/json/GetContentString/{1}/{2}/{3}/%20/{4}/{5}";
        private const string XmlString = "\"<?xml version=\\\"1.0\\\" encoding=\\\"UTF-8\\\"?><adamContent xmlns=\\\"http:\\/\\/www.adam.com\\\" projectTypeID=\\\"1\\\" genContentID=\\\"003795\\\" language=\\\"en\\\" title=\\\"Heart MRI\\\" subContent=\\\"Test\\\"><versionInfo version=\\\"\\\" reviewDate=\\\"5\\/13\\/2014\\\" reviewedBy=\\\"Michael A. Chen, MD, PhD, Associate Professor of Medicine, Division of Cardiology, Harborview Medical Center, University of Washington Medical School, Seattle, WA. Also reviewed by David Zieve, MD, MHA, Isla Ogilvie, PhD, and the A.D.A.M. Editorial team.  \\\" \\/><textContent title=\\\"Definition\\\" delta=\\\"false\\\" ordinal=\\\"0\\\" group=\\\"1\\\" association=\\\"\\\" guid=\\\"27412\\\"><p>Heart <textLink genContentID=\\\"003335\\\" projectTypeID=\\\"1\\\" linkType=\\\"int\\\">magnetic resonance imaging<\\/textLink> (MRI) is an imaging method that uses powerful magnets and radio waves to create pictures of the heart. It does not use radiation (x-rays).<\\/p><p>Single MRI images are called slices. The images can be stored on a computer or printed on film. One exam produces dozens or sometimes hundreds of images.<\\/p><p>The test may be done as part of a <textLink genContentID=\\\"003794\\\" projectTypeID=\\\"1\\\" linkType=\\\"int\\\">chest MRI<\\/textLink>.<\\/p><\\/textContent><\\/adamContent>\"";
        private const string AdamBaseUrl = "http://ws2.adam.com";
        private const string Username = "username";
        private const string Password = "password";
        private const string ContentIdValue = "idValue";
        private const string ContentTypeIdValue = "contentTypeIdValue";
        private const string ProductIdValue = "productIdValue";
        private const string LangaugeCodeValue = "languageCodeValue";

        private Mock<IWebClient> webClient;
        private GetDocumentService service;
        private GetDocumentRequest request;

        /// <summary>
        /// Sets up before each test is executed.
        /// </summary>
        [SetUp]
        public void Setup()
        {
            webClient = Mock<IWebClient>();
            service = new GetDocumentService(webClient.Object);
            request = new GetDocumentRequest()
            {
                ContentId = ContentIdValue,
                ContentTypeId = ContentTypeIdValue,
                ProductId = ProductIdValue,
                LanguageCode = LangaugeCodeValue,
                TenantInfo =
                    new Tenant()
                    {
                        Name = "TenantName",
                        Id = "TenantId",
                        Settings =
                            new List<KeySettingsPair>()
                                                  {
                                                      new KeySettingsPair()
                                                          {
                                                              Key = "adam",
                                                              Settings = new Settings()
                                                                        {
                                                                          LicenseKey = null,
                                                                          BaseUrl = AdamBaseUrl,
                                                                          Username = Username,
                                                                          Password = Password
                                                                        }
                                                          }
                                                  }
                    },
            };
        }

        [Test]
        public void CtorValidParamsCanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<GetDocumentService>(service);
        }

        [Test]
        public void CtorThrowsIfNullWebClient()
        {
            TestDelegate action = () => new GetDocumentService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetDocumentReturnsGetDocumentResponse()
        {
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream());
            var response = service.GetDocument(request);
            Assert.IsInstanceOf<GetDocumentResponse>(response);
        }

        [Test]
        public void GetDocumentWebClientIsCalled()
        {
            webClient.Setup(w => w.OpenRead(It.IsAny<string>())).Returns(this.BuildResponseStream()).Verifiable();
            var response = service.GetDocument(request);
            webClient.Verify();
        }

        [Test]
        public void GetDocumentNullRequestThrowsArgumentNullException()
        {
            TestDelegate action = () => service.GetDocument(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void GetDocumentNoContentIdSpecifiedThrowsArgumentException()
        {
            TestDelegate action = () => service.GetDocument(new GetDocumentRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetDocumentNoProductIdSpecifiedThrowsArgumentException()
        {
            TestDelegate action = () => service.GetDocument(new GetDocumentRequest() { ContentId = "blah" });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetDocumentNoContentTypeIdSpecifiedThrowsArgumentException()
        {
            TestDelegate action = () => service.GetDocument(new GetDocumentRequest() { ProductId = "blah", ContentId = "blah" });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void GetDocumentNoAdamTenantInformationThrowsApplicationException()
        {
            TestDelegate action = () => service.GetDocument(new GetDocumentRequest() { ContentId = ContentIdValue, ProductId = ProductIdValue, ContentTypeId = ContentTypeIdValue });
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void GetDocumentNoAdamTenantInformationNotNullThrowsApplicationException()
        {
            TestDelegate action = () => service.GetDocument(new GetDocumentRequest() { TenantInfo = new Tenant() { Settings = new List<KeySettingsPair>() }, ContentId = ContentIdValue, ProductId = ProductIdValue, ContentTypeId = ContentTypeIdValue });
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void GetDocumentValidRequestWebClientBaseUrlIsExpected()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(ProductIdValue), HttpUtility.UrlEncode(ContentTypeIdValue), HttpUtility.UrlEncode(ContentIdValue), HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream()).Verifiable();
            service.GetDocument(request);
            webClient.Verify();
        }

        [Test]
        public void GetDocumentResponse_ProductIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(ProductIdValue), HttpUtility.UrlEncode(ContentTypeIdValue), HttpUtility.UrlEncode(ContentIdValue), HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.GetDocument(request);
            Assert.AreEqual(ProductIdValue, response.ContentItems[0].ProductId);
        }

        [Test]
        public void GetDocumentResponse_ProjectTypeIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(ProductIdValue), HttpUtility.UrlEncode(ContentTypeIdValue), HttpUtility.UrlEncode(ContentIdValue), HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.GetDocument(request);
            Assert.AreEqual(ContentTypeIdValue, response.ContentItems[0].ContentTypeId);
        }

        [Test]
        public void GetDocumentResponse_GenContentIdIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(ProductIdValue), HttpUtility.UrlEncode(ContentTypeIdValue), HttpUtility.UrlEncode(ContentIdValue), HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.GetDocument(request);
            Assert.AreEqual(ContentIdValue, response.ContentItems[0].ContentId);
        }

        [Test]
        public void GetDocumentResponse_ArticleTitleIsParsedAndReturnedCorrectly()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(ProductIdValue), HttpUtility.UrlEncode(ContentTypeIdValue), HttpUtility.UrlEncode(ContentIdValue), HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.GetDocument(request);
            Assert.AreEqual("Heart MRI", response.ContentItems[0].Title);
        }

        [Test]
        public void GetDocumentResponse_SourceIsCorrect()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(ProductIdValue), HttpUtility.UrlEncode(ContentTypeIdValue), HttpUtility.UrlEncode(ContentIdValue), HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.GetDocument(request);
            Assert.AreEqual("adam", response.ContentItems[0].Source);
        }

        [Test]
        public void GetDocumentResponse_LanguageCodeIsCorrect()
        {
            var expectedUrl = string.Format(BaseUrl, AdamBaseUrl, HttpUtility.UrlEncode(ProductIdValue), HttpUtility.UrlEncode(ContentTypeIdValue), HttpUtility.UrlEncode(ContentIdValue), HttpUtility.UrlEncode(Username), HttpUtility.UrlEncode(Password));
            webClient.Setup(w => w.OpenRead(It.Is<string>(a => a == expectedUrl))).Returns(this.BuildResponseStream());
            var response = service.GetDocument(request);
            Assert.AreEqual(request.LanguageCode, response.ContentItems[0].Language);
        }

        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
    }
}
