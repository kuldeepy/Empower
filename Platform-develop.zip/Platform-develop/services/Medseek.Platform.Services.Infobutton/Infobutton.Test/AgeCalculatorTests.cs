﻿namespace Infobutton.Test
{
    using System;
    using Medseek.Platform.Services.Infobutton.AgeCalculator;
    using Medseek.Platform.Services.Infobutton.Entities;
    using NUnit.Framework;

    [TestFixture]
    public sealed class AgeCalculatorTests
    {
        [Test]
        public void CtorValidParamsCanConstruct()
        {
            var calc = new AgeCalculator();
            Assert.IsNotNull(calc);
            Assert.IsInstanceOf<IAgeCalculator>(calc);
        }

        [Test]
        public void CalculateAge_BirthdateAfterReferenceDate_NullIsReturned()
        {
            var calc = new AgeCalculator();
            var result = calc.CalculateAge(Convert.ToDateTime("12/20/1976"), Convert.ToDateTime("12/21/1976"));
            Assert.Null(result);
        }

        [Test]
        public void CalculateAge_ResponseIsNotNullAndOfTypeAge()
        {
            var calc = new AgeCalculator();
            var result = calc.CalculateAge(Convert.ToDateTime("06/25/2014"), Convert.ToDateTime("12/21/1976"));
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<Age>(result);
        }

        [Test]
        public void CalculateAge_ReferenceDayAfterBirthdateDate_AgeValuesAreExpected()
        {
            var calc = new AgeCalculator();
            var result = calc.CalculateAge(Convert.ToDateTime("06/25/2014"), Convert.ToDateTime("12/21/1976"));
            Assert.AreEqual(4, result.Days);
            Assert.AreEqual(6, result.Months);
            Assert.AreEqual(37, result.Years);
        }

        [Test]
        public void CalculateAge_ReferenceDayBeforeBirthdateDate_AgeValuesAreExpected()
        {
            var calc = new AgeCalculator();
            var result = calc.CalculateAge(Convert.ToDateTime("06/01/2014"), Convert.ToDateTime("12/21/1976"));
            Assert.AreEqual(11, result.Days);
            Assert.AreEqual(5, result.Months);
            Assert.AreEqual(37, result.Years);
        }

        [Test]
        public void CalculateAge_LeapYear_AgeValuesAreExpected()
        {
            var calc = new AgeCalculator();
            var result = calc.CalculateAge(Convert.ToDateTime("03/01/2004"), Convert.ToDateTime("02/27/2004"));
            Assert.AreEqual(3, result.Days);
            Assert.AreEqual(0, result.Months);
            Assert.AreEqual(0, result.Years);
        }

        [Test]
        public void CalculateAge_NonLeapYear_AgeValuesAreExpected()
        {
            var calc = new AgeCalculator();
            var result = calc.CalculateAge(Convert.ToDateTime("03/01/2005"), Convert.ToDateTime("02/27/2005"));
            Assert.AreEqual(2, result.Days);
            Assert.AreEqual(0, result.Months);
            Assert.AreEqual(0, result.Years);
        }
    }
}
