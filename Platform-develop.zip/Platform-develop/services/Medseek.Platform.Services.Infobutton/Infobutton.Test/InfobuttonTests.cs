﻿namespace Infobutton.Test
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Text;
    using Medseek.Platform.Services.Infobutton;
    using Medseek.Platform.Services.Infobutton.AgeCalculator;
    using Medseek.Platform.Services.Infobutton.Entities;
    using Medseek.Platform.Services.Infobutton.Entities.Sync;
    using Medseek.Platform.Services.Infobutton.Entities.TenantInfo;
    using Medseek.Platform.Services.Infobutton.Serializer;
    using Medseek.Platform.Services.Infobutton.WebClient;
    using Medseek.Util.Messaging;
    using Medseek.Util.MicroServices;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class InfobuttonTests
    {
        private const string OriginalInfobuttonRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Code\":\"code\",\"CodeSystemId\":\"2.16.840.1.113883.6.103\",\"Description\":\"infection\",\"BirthDate\":\"12/20/1976\",\"Gender\":\"M\",\"LanguageCode\":\"en\"}";
        private const string OriginalInfobuttonRoutingKey = "medseek.platform.services.infobuttonservice.infobutton";
        private const string ReplyToAddress = "topic://medseek-api/ReplyToAddress";
        private const string TenantInfobuttonSyncReplyAddress = "topic://medseek-api/medseek.platform.services.infobuttonservice.infobutton.tenant.syncresult";
        private const string TenantId = "tenantId";
        private const string BaseUrl = "http://infobuttonserver/educationdata";
        private const string InfobuttonUrl = BaseUrl + "?{0}";

        private const string XmlString = "<feed xmlns=\"http://www.w3.org/2005/Atom\" xml:lang=\"en-us\">" +
                                           "<entry>" +
                                               "<title>Allergic Reaction</title>" +
                                               "<summary>Allergy 1</summary>" +
                                               "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"DocumentLink11\" hreflang=\"en-us\"/>" +
                                               "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink12\" hreflang=\"en-us\"/>" +
                                               "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink13\" hreflang=\"en-us\"/>" +
                                                "<id>tag:healthwise.org1</id>" +
                                               "<updated>1111-01-01T12:00:00Z</updated>" +
                                           "</entry>" +
                                           "<entry>" +
                                               "<title>Allergic Rhinitis</title>" +
                                               "<summary>Allergy 2</summary>" +
                                               "<link rel=\"alternate\" type=\"application/atom+xml\" href=\"DocumentLink21\" hreflang=\"en-us\"/>" +
                                               "<link rel=\"alternate\" type=\"text/xml\" href=\"DocumentLink22\" hreflang=\"en-us\" />" +
                                               "<link rel=\"alternate\" type=\"application/pdf\" href=\"DocumentLink23\" hreflang=\"en-us\"/>" +
                                               "<id>tag:healthwise.org2</id>" +
                                               "<updated>1111-01-01T12:00:00Z</updated>" +
                                           "</entry>" +
                                        "</feed>";

        private Mock<IRemoteMicroServiceInvoker> invoker;
        private Mock<IMicroServiceDispatcher> dispatcher;
        private Mock<IMessageContextAccess> messageContext;
        private Mock<IContentSerializer> serializer;
        private Mock<ISyncService> syncService;
        private Mock<IAgeCalculator> ageCalculator;
        private Mock<IWebClient> webClient;
        
        private InfobuttonService service;
        private InfobuttonRequest request;

        [SetUp]
        public void Setup()
        {
            invoker = new Mock<IRemoteMicroServiceInvoker>();
            dispatcher = new Mock<IMicroServiceDispatcher>();
            messageContext = new Mock<IMessageContextAccess>();
            serializer = new Mock<IContentSerializer>();
            syncService = new Mock<ISyncService>();
            ageCalculator = new Mock<IAgeCalculator>();
            webClient = new Mock<IWebClient>();
            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object, 
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            request = new InfobuttonRequest
                {
                    Code = "code",
                    CodeSystemId = "2.16.840.1.113883.6.103",
                    Description = "infection",
                    BirthDate = "12/20/1976",
                    Gender = "M",
                    LanguageCode = "en",
                    TenantInfo = new Tenant { Id = "tenantId" }
                };

            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, OriginalInfobuttonRoutingKey, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            ageCalculator.Setup(c => c.CalculateAge(It.IsAny<DateTime>(), It.IsAny<DateTime>())).Returns(new Age() { Days = 1, Months = 4, Years = 35 });
            dispatcher.SetupGet(c => c.RemoteMicroServiceInvoker).Returns(invoker.Object);

            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "true";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";
        }

        #region constructor

        [Test]
        public void Ctor_CanConstruct()
        {
            Assert.IsNotNull(service);
            Assert.IsInstanceOf<InfobuttonService>(service);
        }

        [Test]
        public void Ctor_NullDispatcher_ExceptionIsThrown()
        {
            TestDelegate action = () => new InfobuttonService(null, messageContext.Object, serializer.Object, syncService.Object, ageCalculator.Object, webClient.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullContext_ExceptionIsThrown()
        {
            TestDelegate action = () => new InfobuttonService(dispatcher.Object, null, serializer.Object, syncService.Object, ageCalculator.Object, webClient.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullSerializer_ExceptionIsThrown()
        {
            TestDelegate action = () => new InfobuttonService(dispatcher.Object, messageContext.Object, null, syncService.Object, ageCalculator.Object, webClient.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullSyncService_ExceptionIsThrown()
        {
            TestDelegate action = () => new InfobuttonService(dispatcher.Object, messageContext.Object, serializer.Object, null, ageCalculator.Object, webClient.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullAgeCalculator_ExceptionIsThrown()
        {
            TestDelegate action = () => new InfobuttonService(dispatcher.Object, messageContext.Object, serializer.Object, syncService.Object, null, webClient.Object);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void Ctor_NullWebCLient_ExceptionIsThrown()
        {
            TestDelegate action = () => new InfobuttonService(dispatcher.Object, messageContext.Object, serializer.Object, syncService.Object, ageCalculator.Object, null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        #endregion

        [Test]
        public void ProcessInfobuttonRequest_NullRequest_ExceptionIsThrown()
        {
            TestDelegate action = () => service.ProcessInfobuttonRequest(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void ProcessInfobuttonRequest_TenantInfoNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.ProcessInfobuttonRequest(new InfobuttonRequest());
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void ProcessInfobuttonRequest_TenantIdNull_ExceptionIsThrown()
        {
            TestDelegate action = () => service.ProcessInfobuttonRequest(new InfobuttonRequest { TenantInfo = new Tenant() });
            Assert.That(action, Throws.InstanceOf<ArgumentException>());
        }

        [Test]
        public void ProcessInfobuttonRequest_NoSearchCriteria_ApplicationExceptionIsThrown()
        {
            request.Code = string.Empty;
            request.CodeSystemId = string.Empty;
            request.Description = string.Empty;

            TestDelegate action = () => service.ProcessInfobuttonRequest(request);
            Assert.IsTrue(Assert.Throws<ApplicationException>(action).Message.Equals("Request should content either Code and CodeSystemId, or Description."));
        }

        [Test]
        public void ProcessInfobuttonRequest_CodePresentWithoutCodeSystemId_NoDescription_ApplicationExceptionIsThrown()
        {
            request.CodeSystemId = string.Empty;
            request.Description = string.Empty;
            
            TestDelegate action = () => service.ProcessInfobuttonRequest(request);
            Assert.IsTrue(Assert.Throws<ApplicationException>(action).Message.Equals("Request should content either Code and CodeSystemId, or Description."));
        }

        [Test]
        public void ProcessInfobuttonRequest_CodeSystemIdPresentWithoutCode_NoDescription_ApplicationExceptionIsThrown()
        {
            request.Code = string.Empty;
            request.Description = string.Empty;

            TestDelegate action = () => service.ProcessInfobuttonRequest(request);
            Assert.IsTrue(Assert.Throws<ApplicationException>(action).Message.Equals("Request should content either Code and CodeSystemId, or Description."));
        }

        [Test]
        public void ProcessInfobuttonRequest_ValidRequest_SyncServiceRequestIsCalled()
        {
            syncService.Setup(c => c.Request(It.IsAny<SyncRequest>())).Verifiable();
            service.ProcessInfobuttonRequest(request);
            syncService.Verify();
        }

        [Test]
        public void ProcessSyncResult_ResponseIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns((Tenant)null);

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_ResponseIdIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant());

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_ResponseSettingsIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant { Id = TenantId, Settings = null });

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_InfoButtonSettingsIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "notinfobutton", Settings = new Settings() }} });

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test]
        public void ProcessSyncResult_OriginalRequestObjIsNull_ExceptionIsThrown()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });

            TestDelegate action = () => service.ProcessSyncResult(syncResult);
            Assert.That(action, Throws.InstanceOf<ApplicationException>());
        }

        [Test] 
        public void ProcessSyncResult_GetInfobuttonResponse_ValidRequest_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "true";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&patientPerson.administrativeGenderCode.c=M&age.v.v=35&representedOrganization.id.root=MedseekWS");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test] 
        public void ProcessSyncResult_GetInfobuttonResponse_ValidRequest_BirthDateEmpty_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "true";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            const string infobuttonRequest = "{\"TenantInfo\":{\"Id\":\"tenantId\",\"Name\":null,\"Settings\":null},\"Code\":\"code\",\"CodeSystemId\":\"2.16.840.1.113883.6.103\",\"Description\":\"infection\",\"BirthDate\":\"\",\"Gender\":\"M\",\"LanguageCode\":\"en\"}";

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", infobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&patientPerson.administrativeGenderCode.c=M&representedOrganization.id.root=MedseekWS");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test] 
        public void ProcessSyncResult_GetInfobuttonResponse_TenantUserNamePasswordPresent_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "true";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS", Username = "hw.key", Password = "LicenseKey" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&patientPerson.administrativeGenderCode.c=M&age.v.v=35&hw.key=LicenseKey&representedOrganization.id.root=MedseekWS");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test] 
        public void ProcessSyncResult_GetInfobuttonResponse_TenantLicenseKeyNotProvided_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "true";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, Username = "hw.key", Password = "LicenseKey" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&patientPerson.administrativeGenderCode.c=M&age.v.v=35&hw.key=LicenseKey");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test]
        public void ProcessSyncResult_GetInfobuttonResponse_CustomQueryParametersPresentOnTenantSettings_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "true";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, Username = "hw.key", Password = "LicenseKey", CustomQueryParameters = "customParams=1234" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&patientPerson.administrativeGenderCode.c=M&age.v.v=35&hw.key=LicenseKey&customParams=1234");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test]
        public void ProcessSyncResult_GetInfobuttonResponse_InfobuttonResponseObjectPopulatedCorrectlyInInvokerCall()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStream());

            invoker.Setup(i => i.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.Is<object>(res => ValidateResponse(res)), It.IsAny<MessageProperties>())).Verifiable(); //  (It.IsAny<MicroServiceBinding>(),It.IsAny<Type>(),It.Is<object>(res => ValidateResponse(res)),It.IsAny<MessageProperties>())).Verifiable();

            service.ProcessSyncResult(syncResult);
            invoker.Verify();
        }

        [Test]
        public void ProcessSyncResult_GetInfobuttonResponse_InfobuttonResponseObjectPopulatedCorrectlyWithNUllValuesIfElementNotPresent()
        {
            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });
            webClient.Setup(a => a.OpenRead(It.IsAny<string>())).Returns(BuildResponseStreamMissingTitleElement());

            invoker.Setup(i => i.Send(It.IsAny<MqAddress>(), It.IsAny<Type>(), It.Is<object>(res => ValidateResponseEmptyTitle(res)), It.IsAny<MessageProperties>())).Verifiable(); 
            service.ProcessSyncResult(syncResult);
            invoker.Verify();
        }

        [Test] 
        public void ProcessSyncResult_GetInfobuttonResponse_ValidRequest_GenderDisabled_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "false";
            ConfigurationManager.AppSettings["EnableAge"] = "true";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&age.v.v=35&representedOrganization.id.root=MedseekWS");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test]
        public void ProcessSyncResult_GetInfobuttonResponse_ValidRequest_AgeDisabled_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "false";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&patientPerson.administrativeGenderCode.c=M&representedOrganization.id.root=MedseekWS");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test]
        public void ProcessSyncResult_GetInfobuttonResponse_ValidRequest_LanguageDisabled_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "true";
            ConfigurationManager.AppSettings["EnableLanguage"] = "false";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&patientPerson.administrativeGenderCode.c=M&age.v.v=35&representedOrganization.id.root=MedseekWS");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test]
        public void ProcessSyncResult_GetInfobuttonResponse_ValidRequest_InvalidBooleanSettingForAge_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = "blah";
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&patientPerson.administrativeGenderCode.c=M&age.v.v=35&representedOrganization.id.root=MedseekWS");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        [Test]
        public void ProcessSyncResult_GetInfobuttonResponse_ValidRequest_NullBooleanSettingForAge_WebClientUrlIsCorrect()
        {
            ConfigurationManager.AppSettings["EnableGender"] = "true";
            ConfigurationManager.AppSettings["EnableAge"] = null;
            ConfigurationManager.AppSettings["EnableLanguage"] = "true";

            service = new InfobuttonService(dispatcher.Object,
                messageContext.Object,
                serializer.Object,
                syncService.Object,
                ageCalculator.Object,
                webClient.Object);

            var syncResult = new SyncResult() { Context = new OperationRequest { Properties = new MessageProperties { AdditionalProperties = new Dictionary<string, object> { { "infobuttonservice.originalroutingkey", OriginalInfobuttonRoutingKey }, { "infobuttonservice.originalrequest", OriginalInfobuttonRequest } } } }, Results = new OperationResult[] { new OperationResult() { Body = new byte[0] } } };
            messageContext.SetupGet(c => c.Current).Returns(new MessageContext(null, TenantInfobuttonSyncReplyAddress, new MessageProperties() { ContentType = "application/xml", ReplyTo = new MqAddress(ReplyToAddress) }));
            serializer.Setup(c => c.Deserialize<Tenant>(It.IsAny<string>(), It.IsAny<Stream>())).Returns(new Tenant() { Id = TenantId, Settings = new List<KeySettingsPair>() { new KeySettingsPair() { Key = "infobutton", Settings = new Settings() { BaseUrl = BaseUrl, LicenseKey = "MedseekWS" } } } });

            var expectedUrl = string.Format(InfobuttonUrl, "mainSearchCriteria.v.c=code&mainSearchCriteria.v.cs=2.16.840.1.113883.6.103&mainSearchCriteria.v.dn=infection&informationRecipient.languageCode.c=en&patientPerson.administrativeGenderCode.c=M&age.v.v=35&representedOrganization.id.root=MedseekWS");
            webClient.Setup(w => w.OpenRead(It.Is<string>(url => url == expectedUrl))).Returns(BuildResponseStream()).Verifiable();
            service.ProcessSyncResult(syncResult);
            webClient.Verify();
        }

        private bool ValidateResponse(object res)
        {
            var infobuttonResponse = (InfobuttonResponse)res;

            Assert.IsNotNull(infobuttonResponse);
            Assert.IsNotNull(infobuttonResponse.ContentItems);
            Assert.AreEqual("Allergic Reaction", infobuttonResponse.ContentItems[0].Title);
            Assert.AreEqual("Allergy 1", infobuttonResponse.ContentItems[0].Description);
            Assert.AreEqual("DocumentLink11", infobuttonResponse.ContentItems[0].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", infobuttonResponse.ContentItems[0].PostingDate);
            Assert.AreEqual("en-us", infobuttonResponse.ContentItems[0].Language);
            
            Assert.AreEqual("Allergic Rhinitis", infobuttonResponse.ContentItems[1].Title);
            Assert.AreEqual("Allergy 2", infobuttonResponse.ContentItems[1].Description);
            Assert.AreEqual("DocumentLink21", infobuttonResponse.ContentItems[1].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", infobuttonResponse.ContentItems[1].PostingDate);
            Assert.AreEqual("en-us", infobuttonResponse.ContentItems[1].Language);

            return true;
        }

        private bool ValidateResponseEmptyTitle(object res)
        {
            var infobuttonResponse = (InfobuttonResponse)res;

            Assert.IsNotNull(infobuttonResponse);
            Assert.IsNotNull(infobuttonResponse.ContentItems);
            Assert.AreEqual(null, infobuttonResponse.ContentItems[0].Title);
            Assert.AreEqual("Allergy 1", infobuttonResponse.ContentItems[0].Description);
            Assert.AreEqual("DocumentLink11", infobuttonResponse.ContentItems[0].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", infobuttonResponse.ContentItems[0].PostingDate);
            Assert.AreEqual("en-us", infobuttonResponse.ContentItems[0].Language);

            Assert.AreEqual(null, infobuttonResponse.ContentItems[1].Title);
            Assert.AreEqual("Allergy 2", infobuttonResponse.ContentItems[1].Description);
            Assert.AreEqual("DocumentLink21", infobuttonResponse.ContentItems[1].Link);
            Assert.AreEqual("1111-01-01T12:00:00Z", infobuttonResponse.ContentItems[1].PostingDate);
            Assert.AreEqual("en-us", infobuttonResponse.ContentItems[1].Language);

            return true;
        }

        private Stream BuildResponseStream()
        {
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(XmlString));
            return stream;
        }
        private Stream BuildResponseStreamMissingTitleElement()
        {
            var xmlStr = XmlString.Replace("title", "test");
            var stream = new MemoryStream(Encoding.UTF8.GetBytes(xmlStr));
           return stream;
        }
    }
}
