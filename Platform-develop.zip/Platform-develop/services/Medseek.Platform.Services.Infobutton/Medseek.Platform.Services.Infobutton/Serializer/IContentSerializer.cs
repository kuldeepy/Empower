﻿namespace Medseek.Platform.Services.Infobutton.Serializer
{
    using System.IO;

    public interface IContentSerializer
    {
        byte[] Serialize<T>(string contentType, T data);

        T Deserialize<T>(string contentType, Stream data);
    }
}
