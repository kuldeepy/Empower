﻿namespace Medseek.Platform.Services.Infobutton
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Linq;
    using AgeCalculator;
    using Entities;
    using Entities.Sync;
    using Entities.TenantInfo;
    using Newtonsoft.Json;
    using Serializer;
    using Util.Messaging;
    using Util.MicroServices;
    using WebClient;

    [RegisterMicroService]
    public class InfobuttonService
    {
        private readonly IWebClient webClient;
        private readonly IMicroServiceDispatcher dispatcher;
        private readonly IMessageContextAccess messageContext;
        private readonly IContentSerializer serializer;
        private readonly ISyncService syncService;
        private readonly IAgeCalculator ageCalculator;
        private readonly bool enableAge;
        private readonly bool enableLanguage;
        private readonly bool enableGender;

        public InfobuttonService(IMicroServiceDispatcher dispatcher, IMessageContextAccess messageContext, IContentSerializer serializer, ISyncService syncService, IAgeCalculator ageCalculator, IWebClient webClient)
        {
            if (dispatcher == null)
                throw new ArgumentNullException("dispatcher");
            if (messageContext == null)
                throw new ArgumentNullException("messageContext");
            if (serializer == null)
                throw new ArgumentNullException("serializer");
            if (syncService == null)
                throw new ArgumentNullException("syncService");
            if (ageCalculator == null)
                throw new ArgumentNullException("ageCalculator");
            if (webClient == null)
                throw new ArgumentNullException("webClient");

            this.dispatcher = dispatcher;
            this.messageContext = messageContext;
            this.serializer = serializer;
            this.syncService = syncService;
            this.ageCalculator = ageCalculator;
            this.webClient = webClient;

            this.enableGender = ParseBooleanSetting(ConfigurationManager.AppSettings["EnableGender"]);
            this.enableAge = ParseBooleanSetting(ConfigurationManager.AppSettings["EnableAge"]);
            this.enableLanguage = ParseBooleanSetting(ConfigurationManager.AppSettings["EnableLanguage"]);
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".infobutton", Components.ConsumeQueue + ".Infobutton", IsOneWay = true, AutoDelete = false)]
        public void ProcessInfobuttonRequest(InfobuttonRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.TenantInfo == null || string.IsNullOrWhiteSpace(request.TenantInfo.Id))
                throw new ArgumentException("Request tenantId must be specified.", "request");

            if ((string.IsNullOrWhiteSpace(request.Code) || string.IsNullOrWhiteSpace(request.CodeSystemId)) &&
                string.IsNullOrWhiteSpace(request.Description))
            {
                throw new ApplicationException("Request should content either Code and CodeSystemId, or Description.");
            }

            SubmitTenantRequest(request.TenantInfo, JsonConvert.SerializeObject(request));
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyPrefix + ".#.syncresult", Components.ConsumeQueue, AutoDelete = false)]
        public void ProcessSyncResult(SyncResult syncResult)
        {
            var contentType = messageContext.Current.Properties.ContentType;
            var response = serializer.Deserialize<Tenant>(contentType, new MemoryStream(syncResult.Results[0].Body));

            if (response == null || string.IsNullOrWhiteSpace(response.Id) || response.Settings == null || response.Settings.Count == 0)
                throw new ApplicationException("Unable to find the tenant information.");

            var infobuttonSettings = response.Settings.FirstOrDefault(i => i.Key == Components.InfobuttonSettingsKey);

            if (infobuttonSettings == null)
            {
                var tenantId = response.Id;
                throw new ApplicationException(string.Format("Tenant '{0}' is not configured for Infobutton functionality", tenantId));
            }

            var originalProperties = syncResult.Context.Properties;
            var originalRequestObj = originalProperties.Get(Components.OriginalRequestKey);

            if (originalRequestObj == null)
                throw new ApplicationException("Unable to access the original request from sync service response.");

            var infobuttonRequest = JsonConvert.DeserializeObject<InfobuttonRequest>(originalRequestObj as string);
            var infobuttonResponse = GetInfobuttonResponse(infobuttonRequest, infobuttonSettings);

            var invoker = dispatcher.RemoteMicroServiceInvoker;
            var replyTo = originalProperties.ReplyTo;

            // send response to original reply to address
            invoker.Send(replyTo, typeof(InfobuttonResponse), infobuttonResponse, originalProperties);
        }

        #region Private Methods
        
        private static InfobuttonResponse BuildInfobuttonResponse(Stream response)
        {
            var codeResponse = new InfobuttonResponse { ContentItems = new List<ContentItem>() };
            var xmlDoc = XElement.Load(response);

            codeResponse.ContentItems = xmlDoc.Descendants((XNamespace)Components.AtomXmlns + "entry").Select(BuildContentItem).ToList();

            return codeResponse;
        }

        private static ContentItem BuildContentItem(XElement entry)
        {
            return new ContentItem
            {
                Title = GetValue(entry, "title"),
                Description = GetValue(entry, "summary"),
                PostingDate = GetValue(entry, "updated"),
                Link = GetValue(entry, "link", "href"),
                Language = GetValue(entry, "link", "hreflang")
            };
        }

        private static string GetValue(XElement xmlElement, string elementName, string attributeName = null)
        {
            var element = xmlElement;

            if (!string.IsNullOrWhiteSpace(elementName))
            {
                element = xmlElement.Element((XNamespace)Components.AtomXmlns + elementName);
                if (element == null)
                {
                    return null;
                }
            }

            if (string.IsNullOrWhiteSpace(attributeName))
            {
                return element.Value;
            }

            var attribute = element.Attribute(attributeName) ?? element.Attribute(attributeName);

            return attribute != null ? attribute.Value : null;
        }

        private InfobuttonResponse GetInfobuttonResponse(InfobuttonRequest infobuttonRequest, KeySettingsPair infobuttonSettings)
        {
            var requestParameters = BuildInfobuttonRequestParameters(infobuttonRequest);

            var url = string.Format("{0}?{1}", infobuttonSettings.Settings.BaseUrl, requestParameters);

            if (!string.IsNullOrWhiteSpace(infobuttonSettings.Settings.Username) &&
                !string.IsNullOrWhiteSpace(infobuttonSettings.Settings.Password))
            {
                url = string.Format("{0}&{1}={2}",
                                    url,
                                    infobuttonSettings.Settings.Username,
                                    infobuttonSettings.Settings.Password);
            }

            if (!string.IsNullOrWhiteSpace(infobuttonSettings.Settings.LicenseKey))
            {
                url = string.Format("{0}&{1}={2}",
                                    url,
                                    "representedOrganization.id.root",
                                    infobuttonSettings.Settings.LicenseKey);
            }

            if (!string.IsNullOrEmpty(infobuttonSettings.Settings.CustomQueryParameters))
            {
                url = string.Format("{0}&{1}",
                                    url,
                                    infobuttonSettings.Settings.CustomQueryParameters);
            }

            InfobuttonResponse infobuttonResponse;
            using (var webResponse = webClient.OpenRead(url))
            {
                infobuttonResponse = BuildInfobuttonResponse(webResponse);
            }
            return infobuttonResponse;
        }

        private string BuildInfobuttonRequestParameters(InfobuttonRequest inRequest)
        {
            var sb = new StringBuilder();

            if (!string.IsNullOrWhiteSpace(inRequest.Code))
            {
                sb.Append(string.Format("&mainSearchCriteria.v.c={0}", inRequest.Code));
            }

            if (!string.IsNullOrWhiteSpace(inRequest.CodeSystemId))
            {
                sb.Append(string.Format("&mainSearchCriteria.v.cs={0}", inRequest.CodeSystemId));
            }

            if (!string.IsNullOrWhiteSpace(inRequest.Description))
            {
                sb.Append(string.Format("&mainSearchCriteria.v.dn={0}", inRequest.Description));
            }
            if (enableLanguage && !string.IsNullOrEmpty(inRequest.LanguageCode))
            {
                sb.Append(string.Format("&informationRecipient.languageCode.c={0}", inRequest.LanguageCode));
            }
            if (enableGender && !string.IsNullOrEmpty(inRequest.Gender))
            {
                sb.Append(string.Format("&patientPerson.administrativeGenderCode.c={0}", inRequest.Gender));
            }
            if (enableAge && !string.IsNullOrEmpty(inRequest.BirthDate))
            {
                var age = ageCalculator.CalculateAge(DateTime.Today, Convert.ToDateTime(inRequest.BirthDate));
                if (age != null)
                {
                    sb.Append(string.Format("&age.v.v={0}", age.Years));
                }
            }
            return sb.ToString().Substring(1);
        }
        
        private void SubmitTenantRequest(Tenant tenant, string originalRequest)
        {
            var contentType = messageContext.Current.Properties.ContentType;
            var originalProperties = messageContext.Current.Properties.Clone();
            originalProperties.Set(Components.OriginalRequestKey, originalRequest);
            originalProperties.Set(Components.OriginalRoutingKey, messageContext.Current.RoutingKey);
            var operationProperties = originalProperties.Clone();
            operationProperties.ReplyTo = null;

            var registerBody = serializer.Serialize(contentType, tenant);
            var operationRequests = new List<OperationRequest>
                                 {
                                     new OperationRequest
                                         {
                                             Address = Components.AddressOfTenantGet,
                                             Body = registerBody,
                                             Properties = operationProperties
                                         }
                                 };

            var messageQueueAddress = string.Format("topic://{0}/{1}.tenant.syncresult", Components.Exchange, messageContext.Current.RoutingKey);

            SubmitSyncRequest(operationRequests, originalProperties, messageQueueAddress);
        }

        private void SubmitSyncRequest(List<OperationRequest> operationRequests, MessageProperties originalProperties, string replyToAddress)
        {
            var syncRequest = new SyncRequest
            {
                Context = new OperationRequest { Address = string.Format("topic://{0}/{1}", Components.Exchange, messageContext.Current.RoutingKey), Properties = originalProperties },
                Operations = operationRequests,
            };

            using (messageContext.Enter())
            {
                var properties = messageContext.Current.Properties;
                properties.ReplyTo = new MqAddress(replyToAddress);
                syncService.Request(syncRequest);
            }
        }

        /// <summary>
        /// attempts to parse the input string as a boolean. 
        /// </summary>
        /// <param name="input">string representation of a boolean</param>
        /// <returns>the parsed value if successfully parsed, otherwise true by default</returns>
        private bool ParseBooleanSetting(string input)
        {
            if (string.IsNullOrEmpty(input))
                return true;

            var outVal = true;
            var conversionSucceeded = Boolean.TryParse(input, out outVal);
            if (conversionSucceeded)
                return outVal;

            return true; // default
        }

        #endregion
    }
}
