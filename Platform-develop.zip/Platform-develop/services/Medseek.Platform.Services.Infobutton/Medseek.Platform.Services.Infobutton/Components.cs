﻿namespace Medseek.Platform.Services.Infobutton
{
    public static class Components
    {
        internal const string RoutingKeyPrefix = "medseek.platform.services.infobuttonservice";
        internal const string ConsumeQueue = "Medseek.Platform.Services.Infobutton";
        internal const string Exchange = "medseek-api";
        internal const string OriginalRequestKey = "infobuttonservice.originalrequest";
        internal const string OriginalRoutingKey = "infobuttonservice.originalroutingkey";
        internal const string AddressOfTenantGet = "topic://medseek-api/medseek.platform.services.tenantservice.get";

        internal const string InfobuttonSettingsKey = "infobutton";
        internal const string AtomXmlns = "http://www.w3.org/2005/Atom";
    }
}
