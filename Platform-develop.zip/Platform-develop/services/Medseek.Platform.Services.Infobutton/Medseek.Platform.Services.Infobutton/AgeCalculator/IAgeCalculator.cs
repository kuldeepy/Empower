﻿namespace Medseek.Platform.Services.Infobutton.AgeCalculator
{
    using System;
    using Entities;

    public interface IAgeCalculator
    {
        Age CalculateAge(DateTime referenceDate, DateTime birthdate);
    }
}
