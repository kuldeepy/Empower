﻿namespace Medseek.Platform.Services.Infobutton.Entities.Sync
{
    using Util.MicroServices;

    [RegisterMicroServiceProxy]
    public interface ISyncService
    {
        [MicroServiceBinding("medseek-api", "medseek.platform.syncservice.request", "", IsOneWay = true)]
        void Request(SyncRequest request);
    }
}
