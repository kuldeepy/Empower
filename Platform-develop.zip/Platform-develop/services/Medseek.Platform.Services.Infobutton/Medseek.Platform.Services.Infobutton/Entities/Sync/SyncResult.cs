﻿namespace Medseek.Platform.Services.Infobutton.Entities.Sync
{
    using System.Runtime.Serialization;

    /// <summary>
    /// Describes a Sync operation result.
    /// </summary>
    [DataContract(Name = "sync-result", Namespace = "")]
    public class SyncResult
    {
        /// <summary>
        /// Gets or sets an object describing the context of the Sync 
        /// operation.
        /// </summary>
        [DataMember(Name = "context", IsRequired = false, EmitDefaultValue = false)]
        public OperationRequest Context
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the operations to be performed during a Sync 
        /// service operation.
        /// </summary>
        [DataMember(Name = "results", EmitDefaultValue = false)]
        public OperationResult[] Results
        {
            get;
            set;
        }
    }
}
