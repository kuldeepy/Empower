﻿namespace Medseek.Platform.Services.Infobutton.Entities
{
    using System.Runtime.Serialization;
    using TenantInfo;

    [DataContract(Namespace = "")]
    public class InfobuttonRequest
    {
        [DataMember(IsRequired = true)]
        public Tenant TenantInfo { get; set; }

        [DataMember]
        public string Code { get; set; }

        [DataMember]
        public string CodeSystemId { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public string BirthDate { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string LanguageCode { get; set; }
    }
}
