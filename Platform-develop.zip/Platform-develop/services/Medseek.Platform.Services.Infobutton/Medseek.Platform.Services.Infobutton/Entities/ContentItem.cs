﻿namespace Medseek.Platform.Services.Infobutton.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class ContentItem
    {
        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public string Link { get; set; }

        [DataMember]
        public string Description { get; set; }

        [DataMember]
        public string Language { get; set; }
 
        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string PostingDate { get; set; }
    }
}
