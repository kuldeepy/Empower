﻿namespace Medseek.Platform.Services.Infobutton.Entities
{
    using System.Collections.Generic;
    using System.Runtime.Serialization;

    [DataContract(Namespace = "")]
    public class InfobuttonResponse
    {
        [DataMember]
        public List<ContentItem> ContentItems { get; set; }
    }
}
