# Codeset Service Documentation

This service is a wrapper around the HLI codeset service. 


## Search Operation:

  * Exchange: medseek-api
  * RoutingKey: medseek.platform.codesetservice.search
  * Consume Queue: Medseek.Platform.Services.Codeset.CodesetService

  **Example Request**: This is a serialized version of the class Medseek.Platform.Services.Codesets.Entities.CodesetRequest

    ```
  {
	"SearchSpecs" : ["SNOMED_ALL"],
	"SearchText" : "42343007",
	"Targets" : [ "ICD10CM_ALL" ],
	"MaxRecords" : 10,
	"Locale" : "en-US"
  }
    ```
    
  **Request Details**:
  
  - Options: These are the opt keys and values to pass to the HLI. They will be serialized to text in the form of "key=value" before being given to the HLI api.
  - Search Specs: The search specifications as outlined by HLI. This is the domain of the search terms (i.e what sets of data will be searched).
  - Search Text: The string value you are searching on.
  - Targets: The target systems of your results. 
  - MaxRecords: The maximum number of records to return
  - Locale: the locale string to pass to HLI
  - UseCase: the custom query.xml configuration to use if set up. This query.xml file must be setup manually on the server.
  
  **Example Response**: This is a serialized version of the class Medseek.Platform.Services.Codesets.Entities.CodesetResponse
  
    ```
  {
	"OriginalRequest":
		{
			"SearchText":"42343007",
			"SearchSpecs":["SNOMED_ALL"],
			"Targets":["ICD10CM"],
			"Options":null,
			"MaxRecords":10,
			"Locale":"en-US",
			"UseCase":null,
			"BypassCache":false
		},
	"Codes":[
				{
					"CodeValue":"I50.9",
					"CodeSystem":"ICD10CM","Description":"Heart failure, unspecified",
					"ConsumerFriendlyTerm":null,
					"ProviderFriendlyTerm":null,
					"RelatedCodes":null,
					"ParentCodes":null,
					"ChildCodes":null
				},
				{
					"CodeValue":"P29.0",
					"CodeSystem":"ICD10CM",
					"Description":"Neonatal cardiac failure",
					"ConsumerFriendlyTerm":null,
					"ProviderFriendlyTerm":null,
					"RelatedCodes":null,
					"ParentCodes":null,
					"ChildCodes":null
				}
			],
	"ErrorInformation":null,
	"CacheHit":false
}
    ```
    
  **Response Details**:
  
  * OriginalRequest: this is the original request included back in the response
  * Codes: Array of Medseek.Platform.Services.Codesets.Entities.Code entities.
      * CodeValue: the code assicatied with this entity (eg 250.0)
      * CodeSystem: the code system associted with this code value
      * Description: the professional description of this code
      * ConsumerFriendlyTerm: the consumer-friendly description (if available) for this code.
  * ErrorInformation: a string description of any error that occured.

## Predictive Search Operation:

  * Exchange: medseek-api
  * RoutingKey: medseek.platform.codesetservice.predictivesearch
  * Consume Queue: Medseek.Platform.Services.Codeset.CodesetService

  **Example Request**: This is a serialized version of the class Medseek.Platform.Services.Codesets.Entities.CodesetPredictiveSearchRequest

    ```
 {
	"SearchText":"hea",
	"SearchSpecs":["SNOMED_ALL"],
	"MaxRecords":10,
	"Locale":"en-US",
	"BypassCache":true
}
    ```
    
  **Request Details**:
  
  - Search Specs: The search specifications as outlined by HLI. This is the domain of the search terms (i.e what sets of data will be searched).
  - Search Text: The string value you are searching on.
  - MaxRecords: The maximum number of records to return
  - Locale: the locale string to pass to HLI
  
  **Example Response**: This is a serialized version of the class Medseek.Platform.Services.Codesets.Entities.CodesetPredictiveSearchResponse
  
    ```
 {
 	"OriginalRequest":
 		{
 			"SearchText":"hea",
 			"SearchSpecs":["SNOMED_ALL"],
 			"MaxRecords":10,
 			"Locale":"en-US",
 			"BypassCache":true
 		},
 	"Suggestions":["HEA","Head","Heat","Heart","Very heavy","Head CT","Health","Heater","Healed","Heart Tx"],
 	"ErrorInformation":null,
 	"CacheHit":false
}
    ```
    
  **Response Details**:
  
  * Original Request: this is the original request included back in the response
  * Suggestions: Array of strings containing suggestions that matched the search
  * ErrorInformation: a string description of any error that occured.


  
