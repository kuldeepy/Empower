﻿using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with the SQLCLR assembly.
[assembly: AssemblyTitle("Medseek.Platform.Services.Codesets.CacheDatabase")]
[assembly: AssemblyDescription("Micro-service for clinical code set resolution")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Medseek")]
[assembly: AssemblyProduct("Medseek.Platform.Services.Codesets.CacheDatabase")]
[assembly: AssemblyCopyright("Copyright ©  2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.0.*")]

