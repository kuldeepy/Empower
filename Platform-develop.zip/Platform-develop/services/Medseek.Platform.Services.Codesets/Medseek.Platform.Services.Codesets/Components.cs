﻿namespace Medseek.Platform.Services.Codesets
{
    public class Components
    {
        public const string Xmlns = "";

        public const string Exchange = "medseek-api";

        public const string RoutingKeyBase = "medseek.platform.codesetservice";

        public const string UnableToRecieveResponseError =
            "An error was encountered while making the call to the external system.";
    }
}
