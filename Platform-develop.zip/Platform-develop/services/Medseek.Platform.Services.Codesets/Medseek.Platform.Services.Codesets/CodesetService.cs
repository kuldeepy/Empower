﻿namespace Medseek.Platform.Services.Codesets
{
    using System;
    using System.Linq;

    using Medseek.Platform.Services.Codesets.Cache;
    using Medseek.Platform.Services.Codesets.Entities;
    using Medseek.Platform.Services.Codesets.Proxy;
    using Medseek.Util.MicroServices;

    using SearchOption = Medseek.Platform.Services.Codesets.Proxy.SearchOption;

    [RegisterMicroService]
    public class CodesetService
    {
        private const string ConsumeQueue = "Medseek.Platform.Services.Codeset.CodesetService";

        private readonly ICodesetQueryService queryService;

        private readonly ICacheProvider cacheProvider;

        public CodesetService(ICodesetQueryService queryService, ICacheProvider cacheProvider)
        {
            if (queryService == null)
            {
                throw new ArgumentNullException("queryService");
            }

            this.queryService = queryService;
            this.cacheProvider = cacheProvider;
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyBase + ".search", ConsumeQueue + ".Search", AutoDelete = false)]
        public CodesetResponse Search(CodesetRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            if (!inRequest.BypassCache)
            {
                var cachedResponse = cacheProvider.Get<CodesetResponse>(inRequest);
                if (cachedResponse != null)
                {
                    cachedResponse.CacheHit = true;
                    return cachedResponse;
                }
            }

            var request = this.BuildSearchRequest(inRequest);
            var results = queryService.Search(request);
            var response = this.BuildResponse(inRequest, results);

            if (string.IsNullOrEmpty(response.ErrorInformation))
            {
                cacheProvider.Put(inRequest, response);
            }
            response.CacheHit = false;
            return response;
        }

        [MicroServiceBinding(Components.Exchange, Components.RoutingKeyBase + ".predictivesearch", ConsumeQueue + ".Predictivesearch", AutoDelete = false)]
        public CodesetPredictiveSearchResponse PredictiveSearch(CodesetPredictiveSearchRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            if (!inRequest.BypassCache)
            {
                var cachedResponse = cacheProvider.Get<CodesetPredictiveSearchResponse>(inRequest);
                if (cachedResponse != null)
                {
                    cachedResponse.CacheHit = true;
                    return cachedResponse;
                }
            }

            var request = new PredictiveSearchRequest()
                              {
                                  SearchText = inRequest.SearchText,
                                  SearchSpecs = inRequest.SearchSpecs,
                                  MaxRecords = inRequest.MaxRecords,
                                  Locale = inRequest.Locale
                              };
            var results = queryService.PredictiveSearch(request);

            var response = new CodesetPredictiveSearchResponse()
                               {
                                   OriginalRequest = inRequest,
                                   Suggestions = results.Suggestions,
                                   ErrorInformation = results.ErrorInformation
                               };

            if (string.IsNullOrEmpty(response.ErrorInformation))
            {
                cacheProvider.Put(inRequest, response);
            }

            response.CacheHit = false;
            return response;
        }

        #region private methods
        private CodesetResponse BuildResponse(CodesetRequest inRequest, SearchResults results)
        {
            var response = new CodesetResponse() { OriginalRequest = inRequest };
            if (results != null)
            {
                response.ErrorInformation = results.ErrorInformation;

                if (results.SearchResultCodes != null && results.SearchResultCodes.Length > 0)
                {
                    response.Codes = results.SearchResultCodes.ToList().Select(this.BuildCode).ToArray();
                }
            }
            return response;
        }

        private SearchRequest BuildSearchRequest(CodesetRequest inRequest)
        {
            var request = new SearchRequest()
            {
                Options = inRequest.Options != null ? inRequest.Options.Select(m => new SearchOption() { Name = m.Name, Value = m.Value }).ToArray() : null,
                SearchSpecs = inRequest.SearchSpecs,
                SearchText = inRequest.SearchText,
                Targets = inRequest.Targets,
                MaxRecords = inRequest.MaxRecords,
                Locale = inRequest.Locale,
                UseCase = inRequest.UseCase
            };
            return request;
        }

        private Code BuildCode(SearchResultCode searchResultCode)
        {
            var code = new Code()
            {
                CodeSystem = searchResultCode.CodeSystem,
                CodeValue = searchResultCode.Code,
                Description = searchResultCode.Description,
                ConsumerFriendlyTerm = searchResultCode.ConsumerFriendlyTerm,
            };
            return code;
        }
        #endregion
    }
}