﻿namespace Medseek.Platform.Services.Codesets.Dao
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Text;

    using Medseek.Platform.Services.Codesets.DataMappers;
    using Medseek.Util.Ioc;

    [Register(typeof(ICacheDao))]
    public class CacheDao : DaoBase, ICacheDao
    {
        private const string TableName = "Cache";

        public DataMapperBase<Entities.Cache> Mapper { get; set; }

        public CacheDao(DataMapperBase<Entities.Cache> mapper) : base("CacheContext")
        {
            Mapper = mapper;
        }

        #region IAllergyReaction implementation

        public void Put(Entities.Cache cache)
        {
            var commandText = new StringBuilder();
            commandText.Append("MERGE {0} AS CT ");
            commandText.Append("USING (SELECT @Key as [Key]) AS CS ON (CT.[Key] = CS.[Key]) ");
            commandText.Append("WHEN MATCHED THEN ");
            commandText.Append("UPDATE SET Value = @Value, ExpiryDateTime = @ExpiryDateTime ");
            commandText.Append("WHEN NOT MATCHED THEN ");
            commandText.Append("INSERT ([Key], Value, ExpiryDateTime) VALUES (@Key, @Value, @ExpiryDateTime);");

            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(string.Format(commandText.ToString(), TableName), connection))
                {
                    var parameters = new List<SqlParameter>
                                         {
                                             new SqlParameter("Key", cache.Key),
                                             new SqlParameter("Value", cache.Value),
                                             new SqlParameter("ExpiryDateTime", cache.ExpiryDateTime)
                                         };

                    command.Parameters.AddRange(parameters.ToArray());
                    command.ExecuteScalar();
                }
            }
        }




        public Entities.Cache Get(string key)
        {
            Entities.Cache cache;
            var commandText = String.Format("SELECT * FROM {0} WHERE [Key] = @key", TableName);
            using (var connection = GetConnection())
            {
                connection.Open();
                using (var command = new SqlCommand(commandText, connection))
                {
                    var parameters = new List<SqlParameter> { new SqlParameter("key", key) };

                    command.Parameters.AddRange(parameters.ToArray());
                    using (var reader = command.ExecuteReader())
                    {
                        cache = Mapper.Map(reader);
                    }
                }
            }

            return cache;
        }






        #endregion
    }
}
