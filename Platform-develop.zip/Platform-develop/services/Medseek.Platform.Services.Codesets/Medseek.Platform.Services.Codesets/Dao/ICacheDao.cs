﻿namespace Medseek.Platform.Services.Codesets.Dao
{
    public interface ICacheDao
    {
        void Put(Entities.Cache cache);

        Entities.Cache Get(string key);
    }
}
