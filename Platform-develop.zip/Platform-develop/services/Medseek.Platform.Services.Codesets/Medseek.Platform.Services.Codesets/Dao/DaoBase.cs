﻿namespace Medseek.Platform.Services.Codesets.Dao
{
    using System;
    using System.Configuration;
    using System.Data.SqlClient;

    public abstract class DaoBase
    {
        #region Private members

        private readonly string connectionString;

        #endregion

        #region Constructors

        protected DaoBase(string connectionStringName)
        {
            this.connectionString = ConfigurationManager.ConnectionStrings[connectionStringName].ToString();
        }

        #endregion

        #region Public methods

        public SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }

        public object GetDataValue(object value)
        {
            return value ?? DBNull.Value;
        }

        #endregion

    }
}
