﻿namespace Medseek.Platform.Services.Codesets.DataMappers
{
    using System;
    using System.Collections.ObjectModel;
    using System.Data;

    public abstract class DataMapperBase<T> : IDataMapper<T>
    {
        public abstract T MapRecord(IDataReader reader);

        public T Map(IDataReader reader)
        {
            return reader.Read() ? MapRecord(reader) : default(T);
        }

        public Collection<T> MapAll(IDataReader reader)
        {
            var collection = new Collection<T>();

            while (reader.Read())
            {
                collection.Add(MapRecord(reader));
            }
            return collection;
        }

        public DateTime? GetDateTimeValue(object value)
        {
            if (value != DBNull.Value && !string.IsNullOrWhiteSpace(value.ToString()))
            {
                return DateTime.Parse(value.ToString());
            }
            return null;
        }
    }
}
