﻿namespace Medseek.Platform.Services.Codesets.DataMappers
{
    using System.Collections.ObjectModel;
    using System.Data;

    public interface IDataMapper<T>
    {
        Collection<T> MapAll(IDataReader reader);
    }
}
