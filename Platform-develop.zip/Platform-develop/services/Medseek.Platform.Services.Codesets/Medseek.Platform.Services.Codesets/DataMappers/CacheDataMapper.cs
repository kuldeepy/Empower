﻿namespace Medseek.Platform.Services.Codesets.DataMappers
{
    using System.Data;

    using Medseek.Platform.Services.Codesets.Entities;

    public class CacheDataMapper : DataMapperBase<Cache>
    {
        public override Cache MapRecord(IDataReader reader)
        {
            return new Cache()
            {
                Id = long.Parse(reader[0].ToString()),
                Key = reader[1].ToString(),
                Value = reader[2].ToString(),
                ExpiryDateTime = GetDateTimeValue(reader[3]).Value
            };
        }
    }
}
