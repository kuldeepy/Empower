﻿namespace Medseek.Platform.Services.Codesets.Cache
{
    using System;

    using Medseek.Platform.Services.Codesets.Dao;
    using Medseek.Platform.Services.Codesets.DataMappers;
    using Medseek.Util.Ioc;

    using Newtonsoft.Json;

    [Register(typeof(ICacheProvider))]
    public class DatabaseCacheProvider : ICacheProvider
    {
        public long ExpiryInSeconds { get; set; }

        public ICacheDao CacheDao { get; set; }

        public DatabaseCacheProvider() : this(120, new CacheDao(new CacheDataMapper())) { }

        public DatabaseCacheProvider(long expiryTimeInSeconds, ICacheDao cacheDao)
        {
            ExpiryInSeconds = expiryTimeInSeconds;
            CacheDao = cacheDao;
        }

        public T Get<T>(object inRequest)
        {
            var cacheKey = inRequest.GetSHA1Hash();
            var cache = CacheDao.Get(cacheKey);

            if (cache != null && DateTime.UtcNow <= cache.ExpiryDateTime)
            {
                return JsonConvert.DeserializeObject<T>(cache.Value);
            }
            return default(T);
        }

        public void Put<T>(object inRequest, T inResponse)
        {
            var cache = new Entities.Cache()
                            {
                                Key = inRequest.GetSHA1Hash(),
                                Value = JsonConvert.SerializeObject(inResponse),
                                ExpiryDateTime = DateTime.UtcNow.AddSeconds(ExpiryInSeconds)
                            };

            CacheDao.Put(cache);
        }
    }
}
