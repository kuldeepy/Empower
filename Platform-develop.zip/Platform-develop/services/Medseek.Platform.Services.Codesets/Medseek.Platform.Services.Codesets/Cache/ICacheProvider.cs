﻿namespace Medseek.Platform.Services.Codesets.Cache
{
    public interface ICacheProvider
    {
        T Get<T>(object inRequest);

        void Put<T>(object inRequest, T inResponse);

        long ExpiryInSeconds { get; set; }
    }
}
