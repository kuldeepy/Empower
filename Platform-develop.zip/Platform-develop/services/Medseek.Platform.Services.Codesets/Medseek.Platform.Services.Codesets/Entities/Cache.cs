﻿namespace Medseek.Platform.Services.Codesets.Entities
{
    using System;

    public class Cache
    {
        public long Id { get; set; }

        public string Key { get; set; }

        public string Value { get; set; }

        public DateTime ExpiryDateTime { get; set; }
    }
}
