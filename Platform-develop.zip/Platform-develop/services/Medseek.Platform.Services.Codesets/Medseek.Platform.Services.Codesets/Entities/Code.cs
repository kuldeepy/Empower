﻿namespace Medseek.Platform.Services.Codesets.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = Components.Xmlns)]
    public class Code
    {
        [DataMember(IsRequired = true)]
        public string CodeValue { get; set; }

        [DataMember(IsRequired = true)]
        public string CodeSystem { get; set; }

        [DataMember(IsRequired = true)]
        public string Description { get; set; }

        [DataMember]
        public string ConsumerFriendlyTerm { get; set; }

        [DataMember]
        public string ProviderFriendlyTerm { get; set; }

        [DataMember]
        public Code[] RelatedCodes { get; set; }

        [DataMember]
        public Code[] ParentCodes { get; set; }

        [DataMember]
        public Code[] ChildCodes { get; set; }
    }
}
