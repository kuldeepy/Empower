﻿namespace Medseek.Platform.Services.Codesets.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = Components.Xmlns)]
    public class CodesetRequest
    {
        public CodesetRequest()
        {
            MaxRecords = 10;
            Locale = "en-US";
        }

        [DataMember]
        public string SearchText { get; set; }

        [DataMember]
        public string[] SearchSpecs { get; set; }

        [DataMember]
        public string[] Targets { get; set; }

        [DataMember]
        public CodesetRequestOption[] Options { get; set; }

        [DataMember]
        public int MaxRecords { get; set; }

        [DataMember]
        public string Locale { get; set; }

        [DataMember]
        public string UseCase { get; set; }

        [DataMember]
        public bool BypassCache { get; set; }
    }
}
