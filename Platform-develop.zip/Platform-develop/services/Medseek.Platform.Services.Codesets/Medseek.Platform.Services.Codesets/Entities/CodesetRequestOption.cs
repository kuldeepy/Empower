﻿namespace Medseek.Platform.Services.Codesets.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = Components.Xmlns)]
    public class CodesetRequestOption 
    {
        [DataMember(IsRequired = true)]
        public string Name { get; set; }

        [DataMember(IsRequired = true)]
        public string Value { get; set; }

        public override string ToString()
        {
            return string.Format("{0}={1}", Name, Value);
        }
    }
}
