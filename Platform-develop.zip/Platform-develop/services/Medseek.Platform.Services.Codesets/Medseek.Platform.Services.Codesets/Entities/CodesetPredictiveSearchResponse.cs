﻿namespace Medseek.Platform.Services.Codesets.Entities
{
    using System.Runtime.Serialization;

    [DataContract(Namespace = Components.Xmlns)]
    public class CodesetPredictiveSearchResponse
    {
        [DataMember]
        public CodesetPredictiveSearchRequest OriginalRequest { get; set; }

        [DataMember]
        public string[] Suggestions { get; set; }

        [DataMember]
        public string ErrorInformation { get; set; }

        [DataMember]
        public bool CacheHit { get; set; }
    }
}
