﻿namespace Medseek.Platform.Services.Codesets.Proxy
{
    public class SearchOption
    {
        public string Name { get; set; }

        public string Value { get; set; }

        public override string ToString()
        {
            return string.Format("{0}={1}", Name, Value);
        }
    }
}
