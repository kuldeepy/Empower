﻿namespace Medseek.Platform.Services.Codesets.Proxy
{
    public interface ICodesetQueryService
    {
        SearchResults Search(SearchRequest inRequest);

        PredictiveSearchResult PredictiveSearch(PredictiveSearchRequest inRequest);
    }
}
