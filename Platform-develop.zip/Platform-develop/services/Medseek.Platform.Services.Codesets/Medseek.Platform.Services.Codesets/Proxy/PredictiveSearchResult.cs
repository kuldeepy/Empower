﻿namespace Medseek.Platform.Services.Codesets.Proxy
{
    public class PredictiveSearchResult
    {
        public string[] Suggestions { get; set; }
        public string ErrorInformation { get; set; }
    }
}
