﻿namespace Medseek.Platform.Services.Codesets.Proxy
{
    public class PredictiveSearchRequest
    {
        public string SearchText { get; set; }
        public string[] SearchSpecs { get; set; }
        public int MaxRecords { get; set; }
        public string Locale { get; set; }
    }
}
