﻿namespace Medseek.Platform.Services.Codesets.Proxy
{
    public class SearchResultCode
    {
        public string CodeSystem { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        public string ConsumerFriendlyTerm { get; set; }
    }
}
