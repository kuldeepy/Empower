﻿namespace Medseek.Platform.Services.Codesets.Proxy
{
    public class SearchRequest
    {
        public string SearchText { get; set; }
        public string[] SearchSpecs { get; set; }
        public string[] Targets { get; set; }
        public SearchOption[] Options { get; set; } 
        public string Strategy { get; set; }
        public int MaxRecords { get; set; }
        public string Locale { get; set; }
        public string UseCase { get; set; }
    }
}
