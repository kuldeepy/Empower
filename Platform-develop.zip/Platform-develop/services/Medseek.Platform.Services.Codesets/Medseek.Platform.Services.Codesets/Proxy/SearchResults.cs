﻿namespace Medseek.Platform.Services.Codesets.Proxy
{
    public class SearchResults
    {
        public SearchResultCode[] SearchResultCodes { get; set; }
        public string ErrorInformation { get; set; }
    }
}
