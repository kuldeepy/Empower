﻿namespace Medseek.Platform.Services.Codesets.Proxy
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;

    using Medseek.Platform.Services.Codesets.ClientFactory;
    using Medseek.Util.Ioc;
    using Medseek.Util.Logging;

    [Register(typeof(ICodesetQueryService), Lifestyle = Lifestyle.Transient)]
    public class CodesetQueryService : ICodesetQueryService
    {
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        private readonly IServiceClientFactory<LEQuery> clientFactory;

        public CodesetQueryService(IServiceClientFactory<LEQuery> clientFactory)
        {
            if (clientFactory == null)
            {
                throw new ArgumentNullException("clientFactory");
            }
            this.clientFactory = clientFactory;
        }

        public PredictiveSearchResult PredictiveSearch(PredictiveSearchRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var queryService = clientFactory.CreateClient();

            suggestResponse suggestResponse;
            try
            {
                suggestResponse = queryService.suggest(new suggestRequest1(new suggestRequest()
                {
                    searchText = inRequest.SearchText,
                    maxRecords = inRequest.MaxRecords,
                    locale = inRequest.Locale,
                    searchSpecifications = inRequest.SearchSpecs
                }));
            }
            catch (Exception ex)
            {
                Log.WarnFormat("Exception caught while making external call to LEQueryService\nMessage: {0}\nStackTrace: {1}", ex.Message, ex.StackTrace);
                return new PredictiveSearchResult() { ErrorInformation = Components.UnableToRecieveResponseError };
            }

            var result = suggestResponse.suggestResult;

            var results = new PredictiveSearchResult()
            {
                ErrorInformation = null,
            };

            if (result != null && result.suggestions != null)
            {
                results.Suggestions = result.suggestions;
            }
            return results;
        }

        public SearchResults Search(SearchRequest inRequest)
        {
            if (inRequest == null)
            {
                throw new ArgumentNullException("inRequest");
            }

            var client = clientFactory.CreateClient(inRequest.UseCase);

            searchResponse searchResponse;
            try
            {
                

                searchResponse = client.search(new searchRequest1(new searchRequest()
                {
                    searchText = inRequest.SearchText,
                    maxRecords = inRequest.MaxRecords,
                    locale = inRequest.Locale,
                    searchSpecifications = inRequest.SearchSpecs,
                    targetCodeSystems = inRequest.Targets,
                    options = BuildOptions(inRequest.Options)
                }));
            }
            catch (Exception ex) 
            {
                Log.WarnFormat("Exception caught while making external call to LEQueryService\nMessage: {0}\nStackTrace: {1}", ex.Message, ex.StackTrace);
                return new SearchResults() { ErrorInformation = Components.UnableToRecieveResponseError };
            }

            var result = searchResponse.searchResult;
            var results = new SearchResults()
                              {
                                  ErrorInformation = null,
                              };
            var codeList = new List<SearchResultCode>();
            if (result != null && result.matches != null)
            {
                result.matches.ToList().ForEach(m => m.codeSystemResults.ToList().ForEach(csr => csr.concepts.ToList().ForEach(c =>
                {
                    // TODO build child, parent, related codes
                    var searchResult = new SearchResultCode()
                    {
                        CodeSystem = csr.codeSystem,
                        Code = c.code,
                        Description = c.description,
                        ConsumerFriendlyTerm = GetConsumerFriendlyTerm(c.terms)
                    };
                    codeList.Add(searchResult);
                })));               
            }
            results.SearchResultCodes = codeList.ToArray();
            return results;
        }

        #region private methods
        private string GetConsumerFriendlyTerm(term1[] terms)
        {
            string cft = null;
            if (terms != null)
            {
                terms.ToList().ForEach(t =>
                {
                    if (t.type == "Consumer Term")
                    {
                        cft = t.text;
                    }
                });
            }

            return cft;
        }

        private option[] BuildOptions(IEnumerable<SearchOption> options)
        {
            if (options == null) return null;

            var opts = (from o in options
                        where o != null
                        select new option { name = o.Name, value = o.Value }).ToArray();
            return opts.Any() ? opts : null;
        }
        #endregion
    }
}
