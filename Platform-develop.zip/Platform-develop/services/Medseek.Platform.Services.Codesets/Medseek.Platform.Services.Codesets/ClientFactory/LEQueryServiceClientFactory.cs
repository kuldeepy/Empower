﻿namespace Medseek.Platform.Services.Codesets.ClientFactory
{
    using System.Configuration;
    using Proxy;
    using Util.Ioc;

    [Register(typeof(IServiceClientFactory<LEQuery>), Lifestyle = Lifestyle.Transient)]
    public class LEQueryServiceClientFactory : IServiceClientFactory<LEQuery>
    {
        public LEQuery CreateClient(string endpointName = "")
        {
            var client = string.IsNullOrEmpty(endpointName) ? new LEQueryClient("LEQueryService") : new LEQueryClient(endpointName);
            client.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"];
            client.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"];
            return client;
        }
    }
}
