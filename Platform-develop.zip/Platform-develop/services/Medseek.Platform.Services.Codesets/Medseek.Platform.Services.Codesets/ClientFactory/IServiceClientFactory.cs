﻿namespace Medseek.Platform.Services.Codesets.ClientFactory
{
    public interface IServiceClientFactory<out T>
    {
        T CreateClient(string endpointName = "");
    }
}
