﻿namespace CodesetService.Test
{
    using System;

    using Medseek.Platform.Services.Codesets;
    using Medseek.Platform.Services.Codesets.Cache;
    using Medseek.Platform.Services.Codesets.Entities;
    using Medseek.Platform.Services.Codesets.Proxy;

    using Moq;

    using NUnit.Framework;

    [TestFixture]
    public class CodesetServiceTests
    {
        private const string SearchText = "searchText";
        private const string CodeResult = "codeResult";
        private const string CodeSystemResult = "codeSystemResult";
        private const string CodeDescriptionResult = "codeDescriptionResult";
        private const string UseCase = "useCaseId";
        private const string ErrorText = "Test Error Text";
        private const string ConsumerFriendlyTerm = "ConsumerFriendlyTerm";
        private const int MaxRecords = 10;
        private const string Locale = "en-US";
        private const string PredictiveSuggestion = "PredictiveSuggestion";

        private readonly string[] searchSpecs = new[] { "searchSpec1", "searchSpec2" };
        private readonly string[] targets = new[] { "target1", "target2" };

        private Mock<ICodesetQueryService> mockQueryService;
        private CodesetService service;
        private SearchResults searchResults;
        private CodesetRequest request;

        private SearchResultCode code;

        private CodesetRequestOption[] codesetRequestOptions;

        private SearchOption[] proxySearchOptions;

        private PredictiveSearchResult predictiveSearchResult;
        private CodesetPredictiveSearchRequest predictiveSearchRequest;

        private Mock<ICacheProvider> cacheProvider;

        [SetUp]
        public void Setup()
        {
            mockQueryService = new Mock<ICodesetQueryService>();
            cacheProvider = new Mock<ICacheProvider>();

            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);

            codesetRequestOptions = new[]
                                {
                                    new CodesetRequestOption() { Name = "opt1", Value = "val1" },
                                    new CodesetRequestOption() { Name = "opt2", Value = "val2" },
                                };
            proxySearchOptions = new[]
                                {
                                    new SearchOption() { Name = "opt1", Value = "val1" },
                                    new SearchOption() { Name = "opt2", Value = "val2" },
                                };

            request = new CodesetRequest()
            {
                Options = codesetRequestOptions,
                SearchSpecs = searchSpecs,
                SearchText = SearchText,
                Targets = targets,
                MaxRecords = MaxRecords,
                Locale = Locale,
                UseCase = UseCase
            };
            code = new SearchResultCode()
                           {
                               Code = CodeResult,
                               CodeSystem = CodeSystemResult,
                               Description = CodeDescriptionResult,
                               ConsumerFriendlyTerm = ConsumerFriendlyTerm,
                           };

            searchResults = new SearchResults() { ErrorInformation = null, SearchResultCodes = new SearchResultCode[] { code } };

            predictiveSearchRequest = new CodesetPredictiveSearchRequest()
                                          {
                                              SearchSpecs = searchSpecs,
                                              SearchText = SearchText,
                                              MaxRecords = MaxRecords,
                                              Locale = Locale
                                          };
            predictiveSearchResult = new PredictiveSearchResult()
                                         {
                                             ErrorInformation = null,
                                             Suggestions = new string[] { PredictiveSuggestion }
                                         };
        }

        [Test]
        public void CallCtorWithNullParamThrowsException()
        {
            TestDelegate action = () => new CodesetService(null, null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        #region search
        [Test]
        public void SeachCalledWithNullRequestThrowsException()
        {
            TestDelegate action = () => service.Search(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchCalledQueryServiceSearchIsInvoked()
        {
            mockQueryService.Setup(m => m.Search(It.IsAny<SearchRequest>())).Returns(searchResults).Verifiable();

            service.Search(request);

            mockQueryService.Verify();
        }

        [Test]
        public void SearchCalledQueryServiceSearchInvokedWithProperParams()
        {
            mockQueryService.Setup(c => c.Search(It.Is<SearchRequest>(a => VerifySearchOptions(a.Options, proxySearchOptions) && a.SearchSpecs == searchSpecs && a.SearchText == SearchText && a.Targets == targets && a.UseCase == UseCase))).Returns(searchResults).Verifiable();

            service.Search(request);

            mockQueryService.Verify();
        }

        [Test]
        public void SearchCalled_OptionsNull_QueryServiceSearchInvokedWithProperParams()
        {
            request.Options = null;

            mockQueryService.Setup(c => c.Search(It.Is<SearchRequest>(a => a.Options == null && a.SearchSpecs == searchSpecs && a.SearchText == SearchText && a.Targets == targets && a.MaxRecords == MaxRecords && a.Locale == Locale && a.UseCase == UseCase))).Returns(searchResults).Verifiable();

            service.Search(request);

            mockQueryService.Verify();
        }

        [Test]
        public void SearchCalledReturnTypeIsCodeSetResponse()
        {
            mockQueryService.Setup(c => c.Search(It.Is<SearchRequest>(a => a.Options == proxySearchOptions && a.SearchSpecs == searchSpecs && a.SearchText == SearchText && a.Targets == targets && a.MaxRecords == MaxRecords && a.Locale == Locale && a.UseCase == UseCase))).Returns(searchResults).Verifiable();

            var response = service.Search(request);

            Assert.That(response, Is.TypeOf<CodesetResponse>());
        }

        [Test]
        public void SearchQueryReturnsExpectedValuesQueryServiceReturnsSingleResult()
        {
            mockQueryService.Setup(c => c.Search(It.IsAny<SearchRequest>())).Returns(searchResults);

            var response = service.Search(request);
            Assert.That(response.OriginalRequest, Is.EqualTo(request));
            Assert.That(response.Codes, Is.Not.Null);
            Assert.That(response.Codes.Length, Is.EqualTo(1));
            Assert.That(response.Codes[0].CodeValue, Is.EqualTo(CodeResult));
            Assert.That(response.Codes[0].CodeSystem, Is.EqualTo(CodeSystemResult));
            Assert.That(response.Codes[0].Description, Is.EqualTo(CodeDescriptionResult));
            Assert.That(response.Codes[0].ConsumerFriendlyTerm, Is.EqualTo(ConsumerFriendlyTerm));
        }

        [Test]
        public void SearchQueryReturnsNullSearchResultCodesReturnsExpectedResult()
        {
            searchResults = new SearchResults() { ErrorInformation = null, SearchResultCodes = null };
            mockQueryService.Setup(c => c.Search(It.IsAny<SearchRequest>())).Returns(searchResults);

            var response = service.Search(request);
            Assert.That(response.OriginalRequest, Is.EqualTo(request));
            Assert.That(response.Codes, Is.Null);
            Assert.That(response.ErrorInformation, Is.Null);
        }

        [Test]
        public void SearchQueryNoResultsFoundReturnsExpectedResult()
        {
            searchResults = new SearchResults() { ErrorInformation = null, SearchResultCodes = new SearchResultCode[0] };
            mockQueryService.Setup(c => c.Search(It.IsAny<SearchRequest>())).Returns(searchResults);

            var response = service.Search(request);
            Assert.That(response.OriginalRequest, Is.EqualTo(request));
            Assert.That(response.Codes, Is.Null);
            Assert.That(response.ErrorInformation, Is.Null);
        }

        [Test]
        public void SearchQueryServiceReturnsErrorInformationErrorInformationIsIncludedInResponse()
        {
            searchResults = new SearchResults() { ErrorInformation = ErrorText };
            mockQueryService.Setup(c => c.Search(It.IsAny<SearchRequest>())).Returns(searchResults);

            var response = service.Search(request);
            Assert.That(response.ErrorInformation, Is.EqualTo(ErrorText));
        }

        [Test]
        public void SearchQueryServiceReturnsErrorInformationCacheProviderPutNotCalled()
        {
            request.BypassCache = true;
            cacheProvider = new Mock<ICacheProvider>(MockBehavior.Strict); // will cause an exception to be thrown since Get is not defined
            searchResults = new SearchResults() { ErrorInformation = ErrorText };
            mockQueryService.Setup(c => c.Search(It.IsAny<SearchRequest>())).Returns(searchResults);
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            var response = service.Search(request);
            Assert.That(response.ErrorInformation, Is.EqualTo(ErrorText));
        }

        [Test]
        public void SearchCalledByPassCacheTrueCacheProviderGetNotCalled()
        {
            cacheProvider = new Mock<ICacheProvider>(MockBehavior.Strict); // will cause an exception to be thrown since Get is not defined
            cacheProvider.Setup(
                cp => cp.Put(It.IsAny<CodesetRequest>(), It.IsAny<CodesetResponse>()));
            request.BypassCache = true;
            mockQueryService.Setup(c => c.Search(It.IsAny<SearchRequest>())).Returns(searchResults).Verifiable();
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            var response = service.Search(request);
            Assert.That(response, Is.TypeOf<CodesetResponse>());
        }

        [Test]
        public void SearchCalledByPassCacheTrueCacheProviderResponseNullQueryServiceIsCalled()
        {
            CodesetResponse nullResponse = null;
            request.BypassCache = false;
            cacheProvider.Setup(
                cp => cp.Get<CodesetResponse>(It.IsAny<CodesetRequest>())).Returns(nullResponse);
            mockQueryService.Setup(c => c.Search(It.IsAny<SearchRequest>())).Returns(searchResults).Verifiable();
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            var response = service.Search(request);
            mockQueryService.Verify();
            Assert.That(response, Is.TypeOf<CodesetResponse>());
            Assert.IsFalse(response.CacheHit);
        }

        [Test]
        public void SearchCalledByPassCacheFalseCacheProviderResponseNotNullQueryServiceIsNotCalled()
        {
            request.BypassCache = false;
            mockQueryService = new Mock<ICodesetQueryService>(MockBehavior.Strict);
            cacheProvider.Setup(
                cp => cp.Get<CodesetResponse>(It.IsAny<CodesetRequest>())).Returns(new CodesetResponse());
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            var response = service.Search(request);
            Assert.That(response, Is.TypeOf<CodesetResponse>());
            Assert.IsTrue(response.CacheHit);
        }

        [Test]
        public void SearchQueryReturnsExpectedValuesErrorInformationNullCacheProviderPutIsCalled()
        {
            request.BypassCache = false;
            cacheProvider.Setup(
                cp => cp.Put(It.IsAny<CodesetRequest>(), It.IsAny<CodesetResponse>())).Verifiable();
            mockQueryService.Setup(c => c.Search(It.IsAny<SearchRequest>())).Returns(searchResults);
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            service.Search(request);
            cacheProvider.VerifyAll();
        }

        #endregion

        #region Predictive Search
        [Test]
        public void PredictiveSearchCalledWithNullRequestThrowsException()
        {
            TestDelegate action = () => service.PredictiveSearch(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void PredictiveSearchCalledQueryServicePredictiveSearchIsInvoked()
        {
            mockQueryService.Setup(m => m.PredictiveSearch(It.IsAny<PredictiveSearchRequest>())).Returns(predictiveSearchResult).Verifiable();

            service.PredictiveSearch(predictiveSearchRequest);

            mockQueryService.Verify();
        }

        [Test]
        public void PredictiveSearchCalledQueryServicePredictiveSearchInvokedWithProperParams()
        {
            mockQueryService.Setup(c => c.PredictiveSearch(It.Is<PredictiveSearchRequest>(a => a.SearchSpecs == searchSpecs && a.SearchText == SearchText && a.MaxRecords == MaxRecords && a.Locale == Locale))).Returns(predictiveSearchResult).Verifiable();

            service.PredictiveSearch(predictiveSearchRequest);

            mockQueryService.Verify();
        }

        [Test]
        public void PredictiveSearchCalledReturnTypeIsCodesetPredictiveSearchResponse()
        {
            mockQueryService.Setup(c => c.PredictiveSearch(It.Is<PredictiveSearchRequest>(a => a.SearchSpecs == searchSpecs && a.SearchText == SearchText && a.MaxRecords == MaxRecords && a.Locale == Locale))).Returns(predictiveSearchResult).Verifiable();

            var response = service.PredictiveSearch(predictiveSearchRequest);

            Assert.That(response, Is.TypeOf<CodesetPredictiveSearchResponse>());
        }

        [Test]
        public void PredictiveSearchQueryReturnsExpectedValuesQueryServiceReturnsSingleResult()
        {
            mockQueryService.Setup(c => c.PredictiveSearch(It.IsAny<PredictiveSearchRequest>())).Returns(predictiveSearchResult);

            var response = service.PredictiveSearch(predictiveSearchRequest);
            Assert.That(response.OriginalRequest, Is.EqualTo(predictiveSearchRequest));
            Assert.That(response.Suggestions, Is.Not.Null);
            Assert.That(response.Suggestions.Length, Is.EqualTo(1));
            Assert.That(response.Suggestions[0], Is.EqualTo(PredictiveSuggestion));
        }

        [Test]
        public void PredictiveSearchQueryReturnsNullSearchResultCodesReturnsExpectedResult()
        {
            predictiveSearchResult = new PredictiveSearchResult() { ErrorInformation = null, Suggestions = null };
            mockQueryService.Setup(c => c.PredictiveSearch(It.IsAny<PredictiveSearchRequest>())).Returns(predictiveSearchResult);

            var response = service.PredictiveSearch(predictiveSearchRequest);
            Assert.That(response.OriginalRequest, Is.EqualTo(predictiveSearchRequest));
            Assert.That(response.Suggestions, Is.Null);
            Assert.That(response.ErrorInformation, Is.Null);
        }

        [Test]
        public void PredictiveSearchQueryNoResultsFoundReturnsExpectedResult()
        {
            predictiveSearchResult = new PredictiveSearchResult() { ErrorInformation = null, Suggestions = new string[0] };
            mockQueryService.Setup(c => c.PredictiveSearch(It.IsAny<PredictiveSearchRequest>())).Returns(predictiveSearchResult);

            var response = service.PredictiveSearch(predictiveSearchRequest);
            Assert.That(response.OriginalRequest, Is.EqualTo(predictiveSearchRequest));
            Assert.That(response.Suggestions, Is.Not.Null);
            Assert.That(response.Suggestions, Is.Empty);
            Assert.That(response.ErrorInformation, Is.Null);
        }

        [Test]
        public void PredictiveSearchQueryServiceReturnsErrorInformationErrorInformationIsIncludedInResponse()
        {
            predictiveSearchResult = new PredictiveSearchResult() { ErrorInformation = ErrorText };
            mockQueryService.Setup(c => c.PredictiveSearch(It.IsAny<PredictiveSearchRequest>())).Returns(predictiveSearchResult);

            var response = service.PredictiveSearch(predictiveSearchRequest);
            Assert.That(response.ErrorInformation, Is.EqualTo(ErrorText));
        }

        [Test]
        public void PredictiveSearchQueryServiceReturnsErrorInformationCacheProviderPutNotCalled()
        {
            predictiveSearchRequest.BypassCache = true;
            cacheProvider = new Mock<ICacheProvider>(MockBehavior.Strict); // will cause an exception to be thrown since Get is not defined
            predictiveSearchResult = new PredictiveSearchResult() { ErrorInformation = ErrorText };
            mockQueryService.Setup(c => c.PredictiveSearch(It.IsAny<PredictiveSearchRequest>())).Returns(predictiveSearchResult);
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            var response = service.PredictiveSearch(predictiveSearchRequest);
            Assert.That(response.ErrorInformation, Is.EqualTo(ErrorText));
        }

        [Test]
        public void PredictiveSearchCalledByPassCacheTrueCacheProviderGetNotCalled()
        {
            cacheProvider = new Mock<ICacheProvider>(MockBehavior.Strict); // will cause an exception to be thrown since Get is not defined
            cacheProvider.Setup(
                cp => cp.Put(It.IsAny<CodesetPredictiveSearchRequest>(), It.IsAny<CodesetPredictiveSearchResponse>()));
            predictiveSearchRequest.BypassCache = true;
            mockQueryService.Setup(c => c.PredictiveSearch(It.Is<PredictiveSearchRequest>(a => a.SearchSpecs == searchSpecs && a.SearchText == SearchText && a.MaxRecords == MaxRecords && a.Locale == Locale))).Returns(predictiveSearchResult).Verifiable();
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            var response = service.PredictiveSearch(predictiveSearchRequest);
            Assert.That(response, Is.TypeOf<CodesetPredictiveSearchResponse>());
        }

        [Test]
        public void PredictiveSearchCalledByPassCacheTrueCacheProviderResponseNullQueryServiceIsCalled()
        {
            CodesetPredictiveSearchResponse nullResponse = null;
            predictiveSearchRequest.BypassCache = false;
            cacheProvider.Setup(
                cp => cp.Get<CodesetPredictiveSearchResponse>(It.IsAny<CodesetPredictiveSearchRequest>())).Returns(nullResponse);
            mockQueryService.Setup(c => c.PredictiveSearch(It.Is<PredictiveSearchRequest>(a => a.SearchSpecs == searchSpecs && a.SearchText == SearchText && a.MaxRecords == MaxRecords && a.Locale == Locale))).Returns(predictiveSearchResult).Verifiable();
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            var response = service.PredictiveSearch(predictiveSearchRequest);
            mockQueryService.Verify();
            Assert.That(response, Is.TypeOf<CodesetPredictiveSearchResponse>());
            Assert.IsFalse(response.CacheHit);
        }

        [Test]
        public void PredictiveSearchCalledByPassCacheFalseCacheProviderResponseNotNullQueryServiceIsNotCalled()
        {
            var predictiveSearchResponse = new CodesetPredictiveSearchResponse();
            predictiveSearchRequest.BypassCache = false;
            mockQueryService = new Mock<ICodesetQueryService>(MockBehavior.Strict);
            cacheProvider.Setup(
                cp => cp.Get<CodesetPredictiveSearchResponse>(It.IsAny<CodesetPredictiveSearchRequest>())).Returns(predictiveSearchResponse);
            service = new CodesetService(mockQueryService.Object, cacheProvider.Object);
            var response = service.PredictiveSearch(predictiveSearchRequest);
            Assert.That(response, Is.TypeOf<CodesetPredictiveSearchResponse>());
            Assert.IsTrue(response.CacheHit);
        }

        [Test]
        public void PredictiveSearchQueryReturnsExpectedValuesErrorInformationNullCacheProviderPutCalled()
        {
            predictiveSearchRequest.BypassCache = false;
            cacheProvider.Setup(
                cp => cp.Put(It.IsAny<CodesetPredictiveSearchRequest>(), It.IsAny<CodesetPredictiveSearchResponse>())).Verifiable();
            mockQueryService.Setup(c => c.PredictiveSearch(It.IsAny<PredictiveSearchRequest>())).Returns(predictiveSearchResult);

            service.PredictiveSearch(predictiveSearchRequest);
            cacheProvider.VerifyAll();
        }

        #endregion

        #region Private Methods
        private bool VerifySearchOptions(Medseek.Platform.Services.Codesets.Proxy.SearchOption[] opts1, Medseek.Platform.Services.Codesets.Proxy.SearchOption[] opts2)
        {
            var retValue = true;

            if (opts1.Length != opts2.Length)
            {
                retValue = false;
                return retValue;
            }

            for (int i = 0; i < opts1.Length; i++)
            {
                if (opts1[i].ToString() != opts2[i].ToString())
                {
                    retValue = false;
                    break;
                }
            }
            return retValue;
        }

        #endregion
    }
}