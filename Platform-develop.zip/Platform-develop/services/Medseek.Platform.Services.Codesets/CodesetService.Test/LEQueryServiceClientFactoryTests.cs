﻿namespace CodesetService.Test
{
    using Medseek.Platform.Services.Codesets.ClientFactory;
    using NUnit.Framework;

    public class LEQueryServiceClientFactoryTests
    {
        [Test]
        public void CanConstruct()
        {
            var client = new LEQueryServiceClientFactory();
            Assert.IsNotNull(client);
        }

        [Test]
        public void CreateClientNullEndpointClientIsCreated()
        {
            var client = new LEQueryServiceClientFactory();
            var serviceClient = client.CreateClient(null);
            Assert.IsNotNull(serviceClient);
        }

        [Test]
        public void CreateClientSpecifiedEndpointClientIsCreated()
        {
            var client = new LEQueryServiceClientFactory();
            var serviceClient = client.CreateClient("LEQueryServicePFT");
            Assert.IsNotNull(serviceClient);
        }
    }
}
