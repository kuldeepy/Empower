﻿using Medseek.Platform.Services.Codesets.Dao;
using Medseek.Platform.Services.Codesets.Entities;
using System;
using System.Data;
using Medseek.Platform.Services.Codesets.Cache;
using Moq;
using NUnit.Framework;

namespace CodesetService.Test
{
    [TestFixture]
    public class DatabaseCacheProviderTests
    {
        private Mock<ICacheDao> cacheDao;
        private long expiryInSeconds;
        private DatabaseCacheProvider dbCacheProvider;

        [SetUp]
        public void Setup()
        {
            expiryInSeconds = 100;
            cacheDao = new Mock<ICacheDao>();

            dbCacheProvider = new DatabaseCacheProvider(expiryInSeconds, cacheDao.Object);
        }

        [Test]
        public void CanConstruct()
        {
            Assert.IsNotNull(dbCacheProvider);
        }

        [Test]
        public void DefaultConstructor_DefaultSettingsUsed()
        {
            dbCacheProvider = new DatabaseCacheProvider();
            Assert.AreEqual(120, dbCacheProvider.ExpiryInSeconds);
        }

        [Test]
        public void Construct_PropertiesSetProperly()
        {
            Assert.AreEqual(100, dbCacheProvider.ExpiryInSeconds);
            Assert.AreSame(cacheDao.Object, dbCacheProvider.CacheDao);
        }

        [Test]
        public void GetCalled_CacheDaoGetCalled()
        {
            cacheDao.Setup(d => d.Get(It.IsAny<string>())).Verifiable();
            var result = dbCacheProvider.Get<string>(new object());
            cacheDao.VerifyAll();
        }

        [Test]
        public void GetCalled_ReturnValueIsExpected()
        {
            cacheDao.Setup(d => d.Get(It.IsAny<string>())).Returns(new Cache() { Value = "123", ExpiryDateTime = DateTime.MaxValue}); 
            var result = dbCacheProvider.Get<string>(new object());
            Assert.IsInstanceOf<string>(result);
            Assert.AreEqual("123", result);
        }

        [Test]
        public void GetCalled_ExpiryTimePassed_DefaultValueReturned()
        {
            cacheDao.Setup(d => d.Get(It.IsAny<string>())).Returns(new Cache() { Value = "123", ExpiryDateTime = DateTime.MinValue });
            var result = dbCacheProvider.Get<string>(new object());
            Assert.IsNull(result);
        }

        [Test]
        public void PutCalled_CacheDaoPutCalled()
        {
            var putRequest = "123";
            var putResponse = "456";
            cacheDao.Setup(d => d.Put(It.Is<Cache>(c => c.Key == putRequest.GetSHA1Hash() && c.Value == string.Format("\"{0}\"",putResponse)))).Verifiable();
            dbCacheProvider.Put(putRequest,putResponse);
            cacheDao.VerifyAll();
        }
    }
}