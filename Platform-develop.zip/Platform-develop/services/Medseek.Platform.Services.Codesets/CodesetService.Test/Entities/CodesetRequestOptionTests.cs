﻿namespace CodesetService.Test.Entities
{
    using Medseek.Platform.Services.Codesets.Entities;

    using NUnit.Framework;

    [TestFixture]
    public class CodesetRequestOptionTests
    {
        [Test]
        public void ToString_ReturnsCorrectValue()
        {
            var codesetRequestOption = new CodesetRequestOption { Name = "abc", Value = "123" };

            var returnValue = codesetRequestOption.ToString();

            Assert.AreEqual("abc=123", returnValue);
        }
    }
}
