﻿namespace CodesetService.Test.Entities
{
    using Medseek.Platform.Services.Codesets.Entities;

    using NUnit.Framework;

    [TestFixture]
    public class CodesetPredictiveSearchRequestTests
    {
        [Test]
        public void CanConstruct_SetsDefaultValues()
        {
            var request = new CodesetPredictiveSearchRequest();
            Assert.AreEqual(10, request.MaxRecords);
            Assert.AreEqual("en-US", request.Locale);
        }
    }
}
