﻿using System;
using System.Data;
using Medseek.Platform.Services.Codesets.DataMappers;
using Medseek.Platform.Services.Codesets.Entities;
using Moq;
using NUnit.Framework;

namespace CodesetService.Test
{
    [TestFixture]
    public class CacheDataMapperTests
    {
        private const string Id = "1";
        private const string Key = "key";
        private const string Value = "value";
        private string expiry;
        private Cache cacheEntry;
        private Mock<IDataReader> dataReader;
        private CacheDataMapper mapper;

        [SetUp]
        public void Setup()
        {
            expiry = DateTime.UtcNow.ToLongDateString();
            dataReader = new Mock<IDataReader>();
            dataReader.Setup(d => d[0]).Returns(Id);
            dataReader.Setup(d => d[1]).Returns(Key);
            dataReader.Setup(d => d[2]).Returns(Value);
            dataReader.Setup(d => d[3]).Returns(expiry);
            dataReader.Setup(d => d.Read()).Returns(true);
            mapper = new CacheDataMapper();
            cacheEntry = new Cache() { ExpiryDateTime = DateTime.Parse(expiry), Id = long.Parse(Id), Key = Key, Value = Value };
        }

        [Test]
        public void CanConstruct()
        {
            Assert.IsNotNull(mapper);
        }

        [Test]
        public void MapRecord_ReturnsExpected()
        {
            var result = mapper.MapRecord(dataReader.Object);
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<Cache>(result);
            Assert.AreEqual(long.Parse(Id), result.Id);
            Assert.AreEqual(Key, result.Key);
            Assert.AreEqual(Value, result.Value);
            Assert.AreEqual(DateTime.Parse(expiry), result.ExpiryDateTime);
        }

        [Test]
        public void GetDateTimeValue_DbNull_NullIsReturned()
        {
            var result = mapper.GetDateTimeValue(DBNull.Value);
            Assert.IsNull(result);
        }

        [Test]
        public void GetDateTimeValue_EmptyString_NullIsReturned()
        {
            var result = mapper.GetDateTimeValue(string.Empty);
            Assert.IsNull(result);
        }

        [Test]
        public void Map_ReturnsExpected()
        {
            var result = mapper.Map(dataReader.Object);
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<Cache>(result);
        }

        [Test]
        public void Map_DBNullReturned_NullIsExpected()
        {
            dataReader.Setup(d => d.Read()).Returns(false);
            var result = mapper.Map(dataReader.Object);
            Assert.IsNull(result);
        }

        [Test]
        public void MapAll_ReturnsExpected()
        {
            dataReader.SetupSequence(d => d.Read()).Returns(true).Returns(true).Returns(false);
            var result = mapper.MapAll(dataReader.Object);
            Assert.IsNotNull(result);
            Assert.IsInstanceOf<System.Collections.ObjectModel.Collection<Cache>>(result);
        }
    }
}