﻿using Medseek.Platform.Services.Codesets.Cache;
using NUnit.Framework;

namespace CodesetService.Test
{
    [TestFixture]
    public class HashHelperTests
    {
        private const string Value = "value";

        [Test]
        public void MD5HashTest()
        {
            var result = Value.GetMD5Hash();
            Assert.IsNotNull(result);
        }

        [Test]
        public void SHA1HashTest()
        {
            var result = Value.GetSHA1Hash();
            Assert.IsNotNull(result);
        }
    }
}