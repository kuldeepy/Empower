﻿namespace CodesetService.Test
{
    using System;
    using Medseek.Platform.Services.Codesets;
    using Medseek.Platform.Services.Codesets.ClientFactory;
    using Medseek.Platform.Services.Codesets.Proxy;
    using Moq;
    using NUnit.Framework;

    [TestFixture]
    public class CodesetQueryServiceTests
    {
        private const string SearchText = "searchText";
        private const string CodeResult = "codeResult";
        private const string CodeSystemResult = "codeSystemResult";
        private const string CodeDescriptionResult = "codeDescriptionResult";
        private const string Strategy = "strategy";
        private const string PredictiveSuggestion = "PredictiveSuggestion";
        private const int MaxRecords = 10;
        private const string Locale = "en-US";
        private const string ConsumerTermText = "consumer friendly term value";

        private readonly SearchOption[] options = new[] { new SearchOption() { Name = "opt1", Value = "opt1val" } };
        private readonly string[] searchSpecs = new[] { "searchSpec1", "searchSpec2" };
        private readonly string[] targets = new[] { "target1", "target2" };

        private Mock<LEQuery> mockQueryService;
        private CodesetQueryService service;
        private SearchRequest searchRequest;
        private Mock<IServiceClientFactory<LEQuery>> mockClientFactory;
        private PredictiveSearchRequest predictiveSearchRequest;

        [SetUp]
        public void Setup()
        {
            mockClientFactory = new Mock<IServiceClientFactory<LEQuery>>();
            mockQueryService = new Mock<LEQuery>();
            mockClientFactory.Setup(f => f.CreateClient(It.IsAny<string>())).Returns(mockQueryService.Object);
            service = new CodesetQueryService(mockClientFactory.Object);
            searchRequest = new SearchRequest()
                                {
                                    Options = options, 
                                    SearchSpecs = searchSpecs, 
                                    SearchText = SearchText, 
                                    Strategy = Strategy, 
                                    Targets = targets,
                                    MaxRecords = MaxRecords,
                                    Locale = Locale
                                };

            predictiveSearchRequest = new PredictiveSearchRequest()
                                          {
                                              SearchSpecs = searchSpecs,
                                              SearchText = SearchText,
                                              MaxRecords = MaxRecords,
                                              Locale = Locale
                                          };
        }

        [Test]
        public void CallCtorWithNullClientFactoryParamThrowsException()
        {
            TestDelegate action = () => new CodesetQueryService(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        #region search
        [Test]
        public void SeachCalledWithNullRequestThrowsException()
        {
            TestDelegate action = () => service.Search(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void SearchCalledQueryServiceThrowsExceptionExpectedValueReturned()
        {
            mockQueryService.Setup(m => m.search(It.IsAny<searchRequest1>()))
                            .Throws(new Exception("Something was wrong"));

            var response = service.Search(new SearchRequest());

            Assert.That(response, Is.Not.Null);
            Assert.That(response.SearchResultCodes, Is.Null);
            Assert.That(response.ErrorInformation, Is.EqualTo(Components.UnableToRecieveResponseError));
        }


        [Test]
        public void SearchCalled_ClientFactoryCreateClientIsCalledWithProperParameters()
        {
            mockQueryService.Setup(m => m.search(It.IsAny<searchRequest1>())).Returns(new searchResponse());
            mockClientFactory.Setup(f => f.CreateClient(It.Is<string>(a => a == searchRequest.UseCase))).Returns(mockQueryService.Object).Verifiable();
            searchRequest.UseCase = "LEQueryServicePFT";
            service.Search(searchRequest);

            mockQueryService.Verify();
        }

        [Test]
        public void SearchCalledQueryServiceCalledWithExpectedValues()
        {
            mockQueryService.Setup(
                m =>
                m.search(
                    It.Is<searchRequest1>(
                        a =>
                        a.request.searchText == searchRequest.SearchText
                        && a.request.searchSpecifications == searchRequest.SearchSpecs && a.request.maxRecords == searchRequest.MaxRecords
                        && a.request.locale == searchRequest.Locale && a.request.targetCodeSystems == searchRequest.Targets
                        && a.request.options[0].name == "opt1" && a.request.options[0].value == "opt1val")))
                            .Returns(new searchResponse())
                            .Verifiable();

            service.Search(searchRequest);

            mockQueryService.Verify();
        }

        [Test]
        public void SearchCalledWithNullOptionsQueryServiceCalledWithNullOptions()
        {
            searchRequest.Options = null;

            mockQueryService.Setup(m => m.search(It.Is<searchRequest1>(a => a.request.options == null)))
                            .Returns(new searchResponse())
                            .Verifiable();

            service.Search(searchRequest);

            mockQueryService.Verify();
        }

        [Test]
        public void SearchCalledWithNullOptionsValueQueryServiceCalledWithNullOptions()
        {
            searchRequest.Options = new SearchOption[] { null };

            mockQueryService.Setup(m => m.search(It.Is<searchRequest1>(a => a.request.options == null)))
                            .Returns(new searchResponse() { searchResult = new searchResult1() })
                            .Verifiable();

            service.Search(searchRequest);

            mockQueryService.Verify();
        }

        [Test]
        public void SearchCalledQueryServiceReturnsNullReturnValuesAreExpected()
        {
            mockQueryService.Setup(m => m.search(It.IsAny<searchRequest1>()))
                            .Returns(new searchResponse() { searchResult = null });

            var response = service.Search(searchRequest);

            Assert.That(response.ErrorInformation, Is.Null);
            Assert.That(response.SearchResultCodes, Is.Not.Null);
            Assert.That(response.SearchResultCodes, Is.Empty);
        }

        [Test]
        public void SearchCalledQueryServiceReturnsNullMatchesReturnValuesAreExpected()
        {
            mockQueryService.Setup(m => m.search(It.IsAny<searchRequest1>()))
                            .Returns(new searchResponse() { searchResult = new searchResult1() { matches = null } });

            var response = service.Search(searchRequest);

            Assert.That(response.ErrorInformation, Is.Null);
            Assert.That(response.SearchResultCodes, Is.Not.Null);
            Assert.That(response.SearchResultCodes, Is.Empty);
        }

        [Test]
        public void SearchCalledQueryServiceReturnsMatchesReturnValuesAreExpected()
        {
            mockQueryService.Setup(m => m.search(It.IsAny<searchRequest1>()))
                            .Returns(
                                new searchResponse()
                                    {
                                        searchResult = new searchResult1()
                                                {
                                                    matches = new[]
                                                            {
                                                                new match1()
                                                                    {
                                                                        codeSystemResults = new[]
                                                                                {
                                                                                    new codeSystemResult1()
                                                                                        {
                                                                                            codeSystem = CodeSystemResult, 
                                                                                            concepts = new[]
                                                                                                    {
                                                                                                        new concept1()
                                                                                                            {
                                                                                                                code = CodeResult, 
                                                                                                                description = CodeDescriptionResult,
                                                                                                                terms = new term1[] { new term1() { text = ConsumerTermText, type = "Consumer Term" } }
                                                                                                            }
                                                                                                    }
                                                                                        }
                                                                                }
                                                                    }
                                                            }
                                                }
                                    });

            var response = service.Search(searchRequest);

            Assert.That(response.ErrorInformation, Is.Null);
            Assert.That(response.SearchResultCodes, Is.Not.Null);
            Assert.That(response.SearchResultCodes, Is.Not.Empty);
            Assert.That(response.SearchResultCodes[0].Code, Is.EqualTo(CodeResult));
            Assert.That(response.SearchResultCodes[0].Description, Is.EqualTo(CodeDescriptionResult));
            Assert.That(response.SearchResultCodes[0].CodeSystem, Is.EqualTo(CodeSystemResult));
            Assert.That(response.SearchResultCodes[0].ConsumerFriendlyTerm, Is.EqualTo(ConsumerTermText));
        }

        [Test]
        public void SearchCalledQueryServiceReturnsMatchesReturnValuesAreExpected_NoConsumerTerm_COnsumerTermIsNull()
        {
            mockQueryService.Setup(m => m.search(It.IsAny<searchRequest1>()))
                            .Returns(
                                new searchResponse()
                                {
                                    searchResult = new searchResult1()
                                    {
                                        matches = new[]
                                                            {
                                                                new match1()
                                                                    {
                                                                        codeSystemResults = new[]
                                                                                {
                                                                                    new codeSystemResult1()
                                                                                        {
                                                                                            codeSystem = CodeSystemResult, 
                                                                                            concepts = new[]
                                                                                                    {
                                                                                                        new concept1()
                                                                                                            {
                                                                                                                code = CodeResult, 
                                                                                                                description = CodeDescriptionResult,
                                                                                                                terms = new term1[] { new term1() { text = "Not A COnsumer Term", type = "Somekind Term" } }
                                                                                                            }
                                                                                                    }
                                                                                        }
                                                                                }
                                                                    }
                                                            }
                                    }
                                });

            var response = service.Search(searchRequest);

            Assert.That(response.ErrorInformation, Is.Null);
            Assert.That(response.SearchResultCodes, Is.Not.Null);
            Assert.That(response.SearchResultCodes, Is.Not.Empty);
            Assert.That(response.SearchResultCodes[0].Code, Is.EqualTo(CodeResult));
            Assert.That(response.SearchResultCodes[0].Description, Is.EqualTo(CodeDescriptionResult));
            Assert.That(response.SearchResultCodes[0].CodeSystem, Is.EqualTo(CodeSystemResult));
            Assert.That(response.SearchResultCodes[0].ConsumerFriendlyTerm, Is.Null);
        }
        #endregion

        #region Predictive Search tests
        [Test]
        public void PredictiveSearchCalledWithNullRequestThrowsException()
        {
            TestDelegate action = () => service.PredictiveSearch(null);
            Assert.That(action, Throws.InstanceOf<ArgumentNullException>());
        }

        [Test]
        public void PredictiveSearchCalledQueryServiceThrowsExceptionExpectedValueReturned()
        {
            mockQueryService.Setup(m => m.suggest(It.IsAny<suggestRequest1>()))
                            .Throws(new Exception("Something was wrong"));

            var response = service.PredictiveSearch(new PredictiveSearchRequest());

            Assert.That(response, Is.Not.Null);
            Assert.That(response.Suggestions, Is.Null);
            Assert.That(response.ErrorInformation, Is.EqualTo(Components.UnableToRecieveResponseError));
        }

        [Test]
        public void PredictiveSearchCalledQueryServiceCalledWithExpectedValues()
        {
            mockQueryService.Setup(
                m =>
                m.suggest(
                    It.Is<suggestRequest1>(
                        a =>
                        a.request.searchText == predictiveSearchRequest.SearchText
                        && a.request.searchSpecifications == predictiveSearchRequest.SearchSpecs && a.request.maxRecords == predictiveSearchRequest.MaxRecords
                        && a.request.locale == predictiveSearchRequest.Locale)))
                            .Returns(new suggestResponse())
                            .Verifiable();

            service.PredictiveSearch(predictiveSearchRequest);

            mockQueryService.Verify();
        }

        [Test]
        public void PredictiveSearchCalledQueryServiceReturnsNullReturnValuesAreExpected()
        {
            mockQueryService.Setup(m => m.suggest(It.IsAny<suggestRequest1>()))
                            .Returns(new suggestResponse() { suggestResult = null });

            var response = service.PredictiveSearch(predictiveSearchRequest);

            Assert.That(response.ErrorInformation, Is.Null);
            Assert.That(response.Suggestions, Is.Null);
        }

        [Test]
        public void PredictiveSearchCalledQueryServiceReturnsNullSuggestionsReturnValuesAreExpected()
        {
            mockQueryService.Setup(m => m.suggest(It.IsAny<suggestRequest1>()))
                            .Returns(new suggestResponse() { suggestResult = new suggestResult() { suggestions = null } });

            var response = service.PredictiveSearch(predictiveSearchRequest);

            Assert.That(response.ErrorInformation, Is.Null);
            Assert.That(response.Suggestions, Is.Null);
        }

        [Test]
        public void PredictiveSearchCalledQueryServiceReturnsMatchesReturnValuesAreExpected()
        {
            mockQueryService.Setup(m => m.suggest(It.IsAny<suggestRequest1>()))
                            .Returns(
                                new suggestResponse()
                                {
                                    suggestResult = new suggestResult()
                                    {
                                        suggestions = new[] { PredictiveSuggestion }
                                    }
                                });

            var response = service.PredictiveSearch(predictiveSearchRequest);

            Assert.That(response.ErrorInformation, Is.Null);
            Assert.That(response.Suggestions, Is.Not.Null);
            Assert.That(response.Suggestions, Is.Not.Empty);
            Assert.That(response.Suggestions[0], Is.EqualTo(PredictiveSuggestion));
        }

        #endregion
    }
}