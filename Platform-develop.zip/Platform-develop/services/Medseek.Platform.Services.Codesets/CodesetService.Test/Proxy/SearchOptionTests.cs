﻿namespace CodesetService.Test
{
    using Medseek.Platform.Services.Codesets.Proxy;

    using NUnit.Framework;

    [TestFixture]
    public class SearchOptionTests
    {
        [Test]
        public void ToString_ReturnsCorrectValue()
        {
            var searchOption = new SearchOption();
            searchOption.Name = "abc";
            searchOption.Value = "123";

            var returnValue = searchOption.ToString();

            Assert.AreEqual("abc=123", returnValue);
        }
    }
}
