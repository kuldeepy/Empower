﻿using Medseek.Util.MicroServices.Host;
using Medseek.Util.Serialization.Newtonsoft.Json;

[assembly: ReferenceMicroServiceHost]
[assembly: ReferencePluginNewtonsoftJson]