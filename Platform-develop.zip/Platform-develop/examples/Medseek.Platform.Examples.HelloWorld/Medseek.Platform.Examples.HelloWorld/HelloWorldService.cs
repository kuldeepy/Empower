﻿namespace Medseek.Platform.Examples.HelloWorld
{
    using System;
    using System.Reflection;
    using Medseek.Util.Logging;
    using Medseek.Util.MicroServices;

    /// <summary>
    /// Provides a hello world example micro-service.
    /// </summary>
    [RegisterMicroService]
    public class HelloWorldService
    {
        private const string ConsumeQueue = "Medseek.Platform.Examples.HelloWorld.HelloWorldService";
        private const string Exchange = "medseek-api";
        private const string RoutingKeyPrefix = "medseek.platform.examples.helloworld";
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// Says hello.
        /// </summary>
        [MicroServiceBinding(Exchange, RoutingKeyPrefix + ".sayhello", ConsumeQueue)]
        public HelloResponse SayHello(HelloRequest request)
        {
            if (request == null)
                throw new ArgumentNullException("request");

            var text = string.Format("Hello, {0}!", string.IsNullOrWhiteSpace(request.Name) ? "world" : request.Name);
            Log.Info(text);
            
            return new HelloResponse { Text = text };
        }
    }
}