﻿namespace Medseek.Platform.Examples.SyncService.Sleep
{
    using System.Runtime.Serialization;

    /// <summary>
    /// A sleep reply.
    /// </summary>
    [DataContract(Namespace = "")]
    public class SleepReply
    {
    }
}