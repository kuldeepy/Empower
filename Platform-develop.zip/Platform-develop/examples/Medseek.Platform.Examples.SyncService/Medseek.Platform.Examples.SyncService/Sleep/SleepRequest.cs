﻿namespace Medseek.Platform.Examples.SyncService.Sleep
{
    using System.Runtime.Serialization;

    /// <summary>
    /// A sleep request.
    /// </summary>
    [DataContract(Namespace = "")]
    public class SleepRequest
    {
        /// <summary>
        /// Gets or sets the number of milliseconds to sleep.
        /// </summary>
        [DataMember]
        public int Ms
        {
            get;
            set;
        }
    }
}