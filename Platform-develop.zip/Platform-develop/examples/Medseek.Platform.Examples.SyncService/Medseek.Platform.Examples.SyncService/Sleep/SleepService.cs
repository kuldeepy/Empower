﻿namespace Medseek.Platform.Examples.SyncService.Sleep
{
    using System.Threading;
    using Medseek.Util.MicroServices;

    /// <summary>
    /// A service that sleeps when called before sending a reply.
    /// </summary>
    [RegisterMicroService]
    public class SleepService
    {
        private const string ConsumeQueue = "Medseek.Platform.Examples.Sleep.SleepService";
        private const string Exchange = "medseek-api";
        private const string RoutingKeyBase = "medseek.platform.examples.sleep";

        /// <summary>
        /// Causes the service to sleep before sending a reply.
        /// </summary>
        [MicroServiceBinding(Exchange, RoutingKeyBase, ConsumeQueue)]
        public SleepReply Sleep(SleepRequest request)
        {
            var ms = request != null 
                ? request.Ms 
                : 1000;

            Thread.Sleep(ms);

            var reply = new SleepReply();
            return reply;
        }
    }
}