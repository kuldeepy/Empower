﻿namespace Medseek.Platform.Examples.SyncService.Sync
{
    using System.Runtime.Serialization;
    using Medseek.Util.Messaging;

    /// <summary>
    /// Describes the result of an operation performed during a Sync operation.
    /// </summary>
    [DataContract(Name = "result", Namespace = "")]
    public class OperationResult
    {
        /// <summary>
        /// Gets or sets the messaging system address associated with the 
        /// operation.
        /// </summary>
        [DataMember(Name = "address", IsRequired = true)]
        public string Address
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the content of the message body.
        /// </summary>
        [DataMember(Name = "body", EmitDefaultValue = false, IsRequired = false)]
        public byte[] Body
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the message properties associated with the operation.
        /// </summary>
        [DataMember(Name = "properties", IsRequired = true)]
        public MessageProperties Properties
        {
            get;
            set;
        }
    }
}