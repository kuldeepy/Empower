﻿namespace Medseek.Platform.Examples.SyncService.HelloWorld
{
    using System.Runtime.Serialization;

    /// <summary>
    /// A request for use with the hello world services.
    /// </summary>
    [DataContract(Namespace = "")]
    public class HelloRequest
    {
        /// <summary>
        /// Gets or sets the name of the requesting user.
        /// </summary>
        [DataMember]
        public string Name
        {
            get;
            set;
        }
    }
}