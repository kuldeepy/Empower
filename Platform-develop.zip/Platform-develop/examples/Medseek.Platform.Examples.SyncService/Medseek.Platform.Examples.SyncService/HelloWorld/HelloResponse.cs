﻿namespace Medseek.Platform.Examples.SyncService.HelloWorld
{
    using System.Runtime.Serialization;

    /// <summary>
    /// A response for use with the hello world services.
    /// </summary>
    [DataContract(Namespace = "")]
    public class HelloResponse
    {
        /// <summary>
        /// Gets or sets the text of the hello world response.
        /// </summary>
        [DataMember]
        public string Text
        {
            get;
            set;
        }
    }
}