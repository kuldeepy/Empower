﻿namespace Medseek.Platform.Examples.SyncService
{
    using System.Runtime.Serialization;

    /// <summary>
    /// A request for use with the example service.
    /// </summary>
    [DataContract(Namespace = "")]
    public class Request
    {
        /// <summary>
        /// Gets or sets the name of the requesting user.
        /// </summary>
        [DataMember]
        public string Name
        {
            get;
            set;
        }
    }
}