﻿namespace Medseek.Platform.Examples.SyncService
{
    using System.Runtime.Serialization;

    /// <summary>
    /// A response for use with the example service.
    /// </summary>
    [DataContract(Namespace = "")]
    public class Response
    {
        /// <summary>
        /// Gets or sets the text of the response.
        /// </summary>
        [DataMember]
        public string Text
        {
            get;
            set;
        }
    }
}