﻿namespace Medseek.Platform.Examples.SyncService
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;
    using Medseek.Platform.Examples.SyncService.HelloWorld;
    using Medseek.Platform.Examples.SyncService.Sleep;
    using Medseek.Platform.Examples.SyncService.Sync;
    using Medseek.Util.Logging;
    using Medseek.Util.Messaging;
    using Medseek.Util.MicroServices;

    /// <summary>
    /// Provides an example of a micro-service that uses the Sync Service to 
    /// asynchronously use request/reply patterned operations provided by 
    /// other micro-services.
    /// </summary>
    [RegisterMicroService]
    public class ExampleService
    {
        private const string AddressOfHello = "topic://medseek-api/medseek.platform.examples.helloworld.sayhello";
        private const string AddressOfSleep = "topic://medseek-api/medseek.platform.examples.sleep";
        private const string ConsumeQueue = "Medseek.Platform.Examples.Sync.ExampleService";
        private const string Exchange = "medseek-api";
        private const string RoutingKeyPrefix = "medseek.platform.examples.syncservice";
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private readonly IMicroServiceDispatcher dispatcher;
        private readonly IMessageContextAccess messageContext;
        private readonly IMicroServiceSerializer serializer;
        private readonly ISyncService syncService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExampleService"/> class.
        /// </summary>
        public ExampleService(
            IMicroServiceDispatcher dispatcher, 
            IMessageContextAccess messageContext, 
            IMicroServiceSerializer serializer, 
            ISyncService syncService)
        {
            if (dispatcher == null)
                throw new ArgumentNullException("dispatcher");
            if (messageContext == null)
                throw new ArgumentNullException("messageContext");
            if (serializer == null)
                throw new ArgumentNullException("serializer");
            if (syncService == null)
                throw new ArgumentNullException("syncService");

            this.dispatcher = dispatcher;
            this.messageContext = messageContext;
            this.serializer = serializer;
            this.syncService = syncService;
        }

        /// <summary>
        /// Uses the Sync Service to begin performing an operation against the 
        /// Hello World Service.
        /// </summary>
        [MicroServiceBinding(Exchange, RoutingKeyPrefix + ".sayhello", ConsumeQueue, IsOneWay = true)]
        public void SayHello(Request request)
        {
            var contentType = messageContext.Current.Properties.ContentType;
            var originalProperties = messageContext.Current.Properties.Clone();

            var operationProperties = originalProperties.Clone();
            operationProperties.ReplyTo = null;

            var syncRequest = new SyncRequest
            {
                Context = new OperationRequest { Address = string.Format("topic://{0}/{1}", Exchange, messageContext.Current.RoutingKey), Properties = originalProperties },
                Operations = new List<OperationRequest>(),
            };

            using (var ms = new MemoryStream())
            {
                var sleepRequest = new SleepRequest { Ms = 1000 };
                var sleepBody = serializer.Serialize(contentType, sleepRequest);
                syncRequest.Operations.Add(new OperationRequest { Address = AddressOfSleep, Body = sleepBody, Properties = operationProperties });
                ms.SetLength(0);

                var helloRequest = new HelloRequest { Name = request.Name };
                var helloBody = serializer.Serialize(contentType, helloRequest);
                syncRequest.Operations.Add(new OperationRequest { Address = AddressOfHello, Body = helloBody, Properties = operationProperties });
            }

            using (messageContext.Enter())
            {
                var properties = messageContext.Current.Properties;
                properties.ReplyTo = new MqAddress(string.Format("topic://{0}/{1}.sayhello.syncresult", Exchange, RoutingKeyPrefix));

                Log.InfoFormat("Sending sync-request; ContentType = {0}, CorrelationId = {1}, ReplyTo = {2}.", properties.ContentType, properties.CorrelationId, properties.ReplyTo);
                syncService.Request(syncRequest);
            }
        }

        /// <summary>
        /// Receives the sync-result and sends the response to the original 
        /// request.
        /// </summary>
        [MicroServiceBinding(Exchange, RoutingKeyPrefix + ".sayhello.syncresult", ConsumeQueue)]
        public void SayHelloReply(SyncResult syncResult)
        {
            Log.InfoFormat("Received sync-result; Results.Length = {0}.", syncResult.Results.Length);

            var contentType = messageContext.Current.Properties.ContentType;
            var sleepReply = serializer.Deserialize<SleepReply>(contentType, new MemoryStream(syncResult.Results[0].Body));
            Log.InfoFormat("SyncResult.Results[0]: {0}", sleepReply.GetType().Name);

            var helloResponse = serializer.Deserialize<HelloResponse>(contentType, new MemoryStream(syncResult.Results[1].Body));
            Log.InfoFormat("SyncResult.Results[1]: {0}, Text = {1}", helloResponse.GetType().Name, helloResponse.Text);

            var invoker = dispatcher.RemoteMicroServiceInvoker;
            var originalProperties = syncResult.Context.Properties;
            var replyTo = originalProperties.ReplyTo;
            var properties = originalProperties.Clone();
            properties.ReplyTo = null;

            var response = new Response { Text = helloResponse.Text };
            Log.Info("Sending response to original request.");
            invoker.Send(replyTo, typeof(Response), response, properties);
        }
    }
}