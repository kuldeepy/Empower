(function (app) {
  'use strict';

  /* module root controller */
  app.controller('HomeCtrl', ['$scope','navMenuService', '$location', function (scope, navMenu, $location) {
    scope.model = {
      routeParams: {}
    };
    scope.menu = navMenu.menu;
    scope.rootPath = $location.path('/');
  }]);

}(window.app));