(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('UserCtrl', ['$scope', '$http', '$window', '$location', 'authSvc', '$modal', '$timeout', 'navigatorSvc',
      function ($scope, $http, $window, $location, authSvc, $modal, timeout, navigatorSvc) {
        $scope.auth = authSvc;
        $scope.user = {username: '', password: ''};
        $scope.state = null;
        $scope.country = null;
        $scope.results = null;
        $scope.isLoginError = false;
        $scope.loginTable = {
          columns : ['Role', 'Provider Name', 'Select']
        };
        $scope.isCollapsed = true;
        $scope.forgotPasswordUsername = {username: ''};
        $scope.enterUsernameMessage = 'Please enter your username to receive your password.';
        $scope.receiveEmailMessage = 'Please check your email to reset your password.';
        $scope.passwordChangedText = 'Your password has been updated successfully.\nPlease login.';
        var resetPasswordForLockedUserMessage = 'The user account has been locked.Password retrieval is not allowed for this user.Please contact the system administrator to unlock the account';
        $scope.model = {};
        $scope.sentEmail = false;
        var showRoles;

        $scope.clearLoginFields = function(){
          $scope.loginForm.$setPristine();
          $scope.isLoginError = false;
          $scope.isForgotPasswordError = false;
          $scope.setErrorNotification = '';
          $scope.user = {username: '', password: ''};
        };

        var showPopUp = function(action){
          
          if(!action){
            action = 'show';
          }
          showRoles = $modal.open({
            templateUrl: 'rolePopUp.html',
            scope: $scope,
            backdrop : 'static',
            keyboard : false,
            action : action
          });

        };

        $scope.submit = function() {
          $scope.spin = true;
          $scope.model = {};
          $scope.results = null;
          $scope.isCorrect = false;
          $scope.message = '';
          $scope.alertBox = false;
          $scope.isLoginError = false;
          $scope.isForgotPasswordError = false;
          $scope.setErrorNotification = '';
          $scope.isCollapsed = true;
          //Clear user session details just to be sure
          authSvc.clearUserSessionDetails();
          authSvc.login($scope.user.username, $scope.user.password)
            .then(function(loginResult) {
                if(!loginResult.success){
                  $scope.isLoginError = true;
                  $scope.isForgotPasswordError = false;
                  $scope.loginError = loginResult.response.message;
                  $scope.spin = false;
                  $scope.isCorrect = false;
                  delete $window.sessionStorage.token;
                  return;
                }

                var response = loginResult.response;
                $scope.model = { selected: response.results.roles[0] };
                $scope.validateExpiredPassword(response);

                
                localStorage.setItem('isSwitchRoleVisible', response.results.roles.length > 1);
                $scope.results = response.results;
                $scope.spin = false;
                $scope.welcome = 'Welcome, ' + $scope.user.username + '!';
                if ($scope.results.roles.length > 1 && parseInt($scope.daysLeft) >= 0) {
                  showPopUp();
                }

                $scope.login = function() {
                  var authRoute = '';
                  $scope.validateExpiredPassword(response);
                  // Need to add redirects for each role
                  switch ($scope.user.role.toLowerCase()){
                    case 'administrator':
                      authRoute = '/admin';
                      break;
                    case 'analyst':
                      authRoute = '/analyst';
                      break;
                    case 'care manager' :
                      authRoute = '/caremanager';
                      break;
                    case 'marketing analyst':
                      authRoute = '/marketing';
                      break;
                    case 'physician' :
                      authRoute = '/physicians';
                      break;
                    case 'clinic administrator' :
                      authRoute = '/clinicAdmin';
                      break;
                    case 'insurance group provider' :
                      authRoute = '/insurance';
                      break;
                    default :
                      authRoute = '/';
                      break;
                  }
                  if ($scope.user.role) {
                    //$window.location.href = authRoute;
                    navigatorSvc.Navigate(authRoute);
                  }
                };
                $scope.clearFields = function() {
                  authSvc.logout();
                  $scope.user = {username: '', password: ''};
                  
                };
                if($scope.results.roles.length === 1){
                  $scope.login();
                }

              },function(){
                $scope.isLoginError = true;
                $scope.spin = false;
              });
        };

        $scope.validateExpiredPassword = function (response) {
              authSvc.user({
                  id: response.results.userId,
                  sessionId: response.results.sessionId,
                  token: $scope.model.selected.token,
                  role: $scope.model.selected.roleName,
                  providerId: $scope.model.selected.providerId,
                  providerName: $scope.model.selected.providerName,
                  username: $scope.user.username,
                  isAuthenticated: true,
                  lastPasswordChangedDate: response.results.lastPasswordChangedDate,
                  sessionExpireMinutes: response.results.expireMinutes
                });
              $scope.user = authSvc.user();
              $scope.user.password = 'InputFiller';

              $scope.daysLeft = authSvc.getLastChangedPasswordDays();

              if (parseInt($scope.daysLeft) < 0) {
                //$window.location.href = '/password-expired';
                navigatorSvc.Navigate('/password-expired');
                return;
              }

              $scope.alertBox = false;
              if (response) {
                $scope.isCorrect = true;
              } else {
                $scope.isLoginError = true;
                $scope.isForgotPasswordError = false;
                $scope.loginError = response.message;
                $scope.spin = false;
                $scope.isCorrect = false;
                delete $window.sessionStorage.token;
              }
            };
        $scope.resetNamePassword = function() {
          showRoles.close();
          $scope.results = null;
          $scope.user.password = '';
          $scope.loginForm.$setPristine();
        };
        $scope.forgotPassword = function() {
          $http
            .post(app.api.root + 'reset-password', $scope.forgotPasswordUsername)
            .then(
              // SUCCESS
              function () {
                $scope.sentEmail = true;
              },
              // ERROR
              function (error) {
               
                // Erase the token if user fails to login
                $scope.forgotPasswordUsername = {username: ''};
                $scope.isLoginError = false;
                $scope.isForgotPasswordError = true;
                if(error.data.code === 422)
                {
                  $scope.setErrorNotification = 'Username not found. Please enter a valid username.';
                }
                if(error.data.code === 423)
                {
                  $scope.setErrorNotification = resetPasswordForLockedUserMessage;
                }
              });
        };


        if(sessionStorage.getItem('PasswordChanged')){
          $scope.isPasswordChanged = sessionStorage.getItem('PasswordChanged');
          sessionStorage.removeItem('PasswordChanged');
        }

        timeout(function () {
          $scope.isPasswordChanged = false;
        }, 6000);

      }]);

  }(window.app)
  );
