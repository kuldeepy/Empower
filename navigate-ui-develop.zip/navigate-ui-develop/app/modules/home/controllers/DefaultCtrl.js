﻿(function (app) {
  'use strict';

  app.controller('HomeDefaultCtrl', ['$scope', function (scope) {
    scope.welcomeText = 'Welcome to MEDSEEK Navigate';
    scope.moreText = 'More Text';

  }]);

}(window.app));