﻿(function (app) {
  'use strict';

  app.controller('LoginWrapperCtrl', ['$scope', function (scope) {
    scope.welcomeText = 'Welcome to MEDSEEK Navigate';
    scope.year = new Date().getFullYear();

  }]);

}(window.app));