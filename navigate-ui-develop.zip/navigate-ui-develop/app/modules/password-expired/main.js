(function (app) {
  'use strict';

  /* module root controller */
  app.controller('ExpiredPasswordModuleCtrl', ['$scope', function (scope) {
    scope.model = {
      routeParams: {}
    };
  }]);

}(window.app));