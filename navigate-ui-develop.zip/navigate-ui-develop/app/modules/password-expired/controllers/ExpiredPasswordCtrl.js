(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('ExpiredPasswordCtrl', ['$scope', '$http', '$location', '$timeout','httpRequestSvc', 'authSvc',
      function (scope, http, location, timeout,httpRequestSvc,authSvc) {
        var resetPasswordToken = location.search();
        
        scope.year = new Date().getFullYear();
        scope.user = {
          username: '',
          token: resetPasswordToken.token,
          password: ''
        };
        scope.confirmPassword = '';
        scope.passwordChanged = false;
        scope.passwordPattern = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[(_)<>#?!@$%^&*-]).{6,}$/;
        scope.successMessage = 'Your password has been updated successfully.';
        scope.errorMessageForUsername = 'Username does not exist in the Database.';
        scope.errorMessageForLinkExpired = 'Reset Password link has expired, Please go back to login screen to generate a new reset password link.';
        scope.isPasswordExpired = false;
        this.currentUser = authSvc.user();
        

            //PUT Method for savePasswordInformation
        scope.updatedPasswordInformation = function () {

          sessionStorage.setItem('PasswordChanged', false);
          this.currentUser = authSvc.user();

          var passwordVerify = {
            currentPassword: scope.user.oldPassword,
            newPassword: scope.user.password
          },
          requestpath = 'user/' + this.currentUser.id + '/reset-password';

          httpRequestSvc.putRequest(requestpath, passwordVerify).then(function (response) {
            if (response.data.results.success === true) {
              sessionStorage.setItem('PasswordChanged', true);
              window.location.href = '/';
              scope.currentPasswordPlaceholder = 'Current Password';
            }
            else {
              scope.errorMessageForPassword = 'Old Password does not match. Re-enter old password.';
              scope.showNotifications(scope.errorMessageForPassword, 'alert-error', true);
              scope.currentPasswordPlaceholder = 'Re-enter Password';
            }
          });
        };

        scope.cancelPassword = function () {
            window.location.href = '/';
          };

          // display error message if failed the api 
        scope.showNotifications = function (errorMsg, style) {
            window.scrollTo(0, 0);
            scope.alertMessageStyle = style;
            scope.alertMessage = errorMsg;
            scope.isError = true;
            timeout(function () {
                scope.isError = false;
              }, 6000);
          };

      }]);
  }(window.app)
);