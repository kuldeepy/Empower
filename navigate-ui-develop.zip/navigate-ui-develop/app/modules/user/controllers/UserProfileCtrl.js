﻿(
  function (app) {
      // @fmt:off
      'use strict';
      // @fmt:on

      /* module root controller */
      app.controller('UserProfileCtrl', ['$scope', '$http', '$timeout', '$location', 'httpRequestSvc', 'authSvc', '$modal', '$window',
        function (scope, http, timeout, location, httpRequestSvc, authSvc, $modal, window) {
            var modalInstance = {};
            scope.isCancelAlertVisible = false;
            scope.form1 = true;
            scope.form2 = true;
            scope.emailAddressCopy = '';
            scope.isUserEmailUnique = true;

            scope.daysLeftChangePassword = authSvc.getLastChangedPasswordDays();
            scope.daysLeftChangePassword = scope.daysLeftChangePassword.toString();
            scope.visible = authSvc.getChangePasswordReminderDays(scope.daysLeftChangePassword);
            scope.msg = 'Your password will expire';
            if (parseInt(scope.daysLeftChangePassword) === 0) {
              scope.msg = scope.msg + ' today.';
            } else if (parseInt(scope.daysLeftChangePassword) === 1) {
              scope.msg = scope.msg + ' in ' + scope.daysLeftChangePassword + ' day.';
            } else {
              scope.msg = scope.msg + ' in ' + scope.daysLeftChangePassword + ' days.';
            }

            scope.data = authSvc.getChangePasswordReminderDays(scope.daysLeftChangePassword);

            
            //Clear the error Message
            scope.errorClearMessage = function () {
                scope.isError = false;
              };

            localStorage.setItem('isChanged', false);

            scope.accordionStatus = {
                openFirst: true,
                openSecond: false
              };
            scope.viaMyProfile = true;
            scope.changePassword = function () {

                scope.accordionStatus = {
                    openFirst: false,
                    openSecond: true
                  };
                scope.viaMyProfile = false;
                scope.myProfilePopup();
              };
            //open my profile popup
            scope.myProfilePopup = function () {
                if (!scope.viaMyProfile) {
                  scope.viaMyProfile = true;
                }

                scope.getProfileData();
                scope.getStateData();
                scope.getCountryData();

                modalInstance = $modal.open({
                    templateUrl: 'user_Profile.html',
                    size: 'lg',
                    scope: scope,
                    backdrop: 'static'
                  });

                scope.currentPasswordPlaceholder = 'Current Password';
              };

            //accordionStatus
            scope.oneAtATime = true;


            scope.loginUser = authSvc.user();
            scope.disable = (scope.loginUser.role === 'Care Manager' || scope.loginUser.role === 'Administrator' || scope.loginUser.role === 'Analyst' || scope.loginUser.role === 'Marketing Analyst') ? false : true;
            scope.emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
            scope.pattern = /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
            scope.passwordPattern = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[(_)<>#?{+}!@$%^&*-/]).{6,}$/;
            scope.errorMessage = 'Unfortunately, we are not able to process your request at this time. Please try again later or contact your system administrator if this continues.';
            scope.successMessage = 'Your password has been updated successfully.';
            scope.updateSuccessMessage = 'Your profile information has been updated successfully.';
            scope.errorMessageForPassword = 'Current Password does not match. Re-enter current password.';

            //initialize profile data
            scope.profileData = {
                gender: 'F',
                firstName: '',
                lastName: '',
                emailAddress: '',
                primaryAddress: {
                    addressType: '',
                    addressLine1: '',
                    addressLine2: '',
                    city: '',
                    stateCode: '',
                    countryCode: '',
                    postalCode: ''
                  }
                };

            //initialize user data
            scope.user = {
              currentPassword: '',
              newPassword: '',
              confirmPassword: ''
            };

            // Reset field value for Profile Information
            scope.clearProfileData = function () {
              scope.profileData.gender = 'F';
              scope.profileData.firstName = '';
              scope.profileData.lastName = '';
              scope.profileData.emailAddress = '';
              scope.profileData.phoneNumber = '';
              scope.profileData.primaryAddress.city = '';
              scope.profileData.primaryAddress.addressLine1 = '';
              scope.profileData.primaryAddress.postalCode = '';
              scope.profileData.primaryAddress.stateCode = '';
              scope.profileData.primaryAddress.countryCode = '';
            };

            scope.phoneInput = function (profileForm) {
              if (scope.profileData.phoneNumber === '') {
                profileForm.phone.$setPristine();
                scope.profileData.phoneNumber = undefined;
              }
            };

            // Reset field value for Password Information
            scope.clearPasswordData = function () {
              scope.user.newPassword = '';
              scope.user.confirmPassword = '';
              scope.user.currentPassword = '';
            };

            //PUT Method for saveInformation
            scope.updatedUserInformation = function (updatedInformation, form, parentForm) {
              var requestpath = 'user-profile';
              httpRequestSvc.putRequest(requestpath, updatedInformation).then(function (response) {
                if (response.data.results) {
                  if (response.data.results === 'Failure') {
                    scope.showNotifications('Email ID already exists.', 'alert-error', false);
                  } else {
                    scope.clearProfileData();
                    scope.getProfileData();
                    scope.showNotifications(scope.updateSuccessMessage, 'alert-success', false);
                    form.$setPristine();
                    parentForm.$setPristine();
                  }
                }
                else {
                  scope.showNotifications(scope.errorMessage, 'alert-error', false);
                }
              });
            };

            //PUT Method for savePasswordInformation
            scope.updatedPasswordInformation = function (updatedPassword, form, parentForm) {
              var passwordVerify = {
                currentPassword: updatedPassword.currentPassword,
                newPassword: updatedPassword.confirmPassword
              },
              requestpath = 'user-profile/password';

              scope.hidePasswordNotify = false;

              httpRequestSvc.putRequest(requestpath, passwordVerify).then(function (response) {
                if (response.data.results.success === true) {
                  scope.showNotifications(scope.successMessage, 'alert-success', true);
                  scope.currentPasswordPlaceholder = 'Current Password';
                  scope.daysLeftChangePassword = 90;
                  scope.hidePasswordNotify = true;
                  scope.loginUser = authSvc.user();
                  localStorage.setItem('isChanged', true);
                  sessionStorage.setItem('Navigate.user.session.user.lastPasswordChangedDate', new Date());
                  scope.daysLeftChangePassword = authSvc.getLastChangedPasswordDays();
                  scope.data = false;
                  form.$setPristine();
                }
                else {
                  scope.showNotifications(scope.errorMessageForPassword, 'alert-error', true);
                  scope.currentPasswordPlaceholder = 'Re-enter Password';
                  form.$setPristine();
                }
                parentForm.$setPristine();
                scope.clearPasswordData();
              });
            };

            // GET Method ProfileData
            scope.getProfileData = function () {
              var requestpath = 'user/' + scope.loginUser.id + '/user-profile';
              scope.isUserEmailUnique = true;
              httpRequestSvc.getRequest(requestpath).then(function (response) {
                scope.profileData = response.data.results;
                scope.emailAddressCopy = angular.copy(scope.profileData.emailAddress);
              }, function () {
                scope.showNotifications(scope.errorMessage, 'alert-error', false);
              });
            };

            // GET Method states
            scope.getStateData = function () {
              var requestpath = 'states';
              httpRequestSvc.getRequest(requestpath).then(function (response) {
                scope.stateData = response.data.results;
              }, function () {
                scope.showNotifications(scope.errorMessage, 'alert-error', false);
              });
            };

            // GET Method countries
            scope.getCountryData = function () {
              var requestpath = 'countries?userId=' + scope.loginUser.id;
              httpRequestSvc.getRequest(requestpath).then(function (response) {
                scope.countriesData = response.data.results;
              }, function () {
                scope.showNotifications(scope.errorMessage, 'alert-error', false);
              });
            };

            // display error message if failed to get the data from api
            scope.showNotifications = function (errorMsg, style, isPassword) {
              if (isPassword) {
                scope.alertMessageStylePassword = style;
                scope.alertMessagePassword = errorMsg;
              }
              else {
                scope.alertMessageStyle = style;
                scope.alertMessage = errorMsg;
              }
              scope.isError = true;
              scope.isSuccessMsg = style === 'alert-success' ? true : false;
              timeout(function () {
                scope.isError = false;
              }, 6000);
            };

            //Close Profile Pop-Up
            scope.showCancelAlertPopup = function () {
              modalInstance.close(true);
              scope.isCancelAlertVisible = false;
              scope.accordionStatus = {
                openFirst: true,
                openSecond: false
              };
              scope.clearPasswordData();
              scope.clearProfileData();
              scope.isPasswordChange = localStorage.getItem('isChanged');
              if (scope.isPasswordChange === 'true' && scope.visible) {
                window.location.reload();
                localStorage.removeItem('isChanged');
              }
            };

            //close Profile button
            scope.closeProfilePopup = function (show, myForm) {
              if (myForm.$pristine) {
                scope.isCancelAlertVisible = false;
                scope.showCancelAlertPopup();
              } else {
                scope.isCancelAlertVisible = show;
              }
              scope.errorClearMessage();
              scope.isPasswordChange = localStorage.getItem('isChanged');
              if (scope.isPasswordChange === 'true' && scope.visible) {
                window.location.reload();
                localStorage.removeItem('isChanged');
              }
            };

            //show Cancel Alert
            scope.showCancelAlert = function (show) {
              scope.isCancelAlertVisible = show;
            };

          }]);
    }(window.app));