/**
 * @author michael.ash
 */
(
  function (app) {
    // @fmt:off
  'use strict';
  // @fmt:on
  app.controller('AuthUserCtrl', ['$scope', '$http', '$location', 'authSvc', 'createUserSvc', 'adtNotificationSvc','_', '$modal', '$window', 'navConstantsSvc', '$filter','$timeout', 'userConcurrentLockSvc', 'Idle', 'Keepalive', '$log', 'iuiAlertService','$rootScope',
    function (scope, http, location, authSvc, createUserSvc, adtNotificationSvc,_, $modal, $window, navConstantsSvc, $filter,timeout, userConcurrentLockSvc, idle, keepAlive, log, alertSvc,rootScope) {
      var bannerReports,
          bannerCMTasks,
          bannerCMPatients,
          bannerMessages,
          bannerNotifications,
          bannerAnalystReports;
      scope.isManager = false;
      scope.user = authSvc.user();
      scope.canAccessSwitchRole = localStorage.getItem('isSwitchRoleVisible');

      scope.logout = function() {
        idle.unwatch();
        keepAlive.stop();
        scope.data = {
          'lockType': 'Notifications'
        };
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function() {
          authSvc.logout();
          alertSvc.add('alert_login', {
            type: 'info',
            message: 'You have been logged out.'
          });
          window.onbeforeunload = null;
          location.path('/');
        });
      };

      scope.logoutUser = function () {
        scope.carePlanLocationCtrl.isLogout = true;

        if(scope.carePlanLocationCtrl.isFormDirty){
          rootScope.$broadcast('showCarePlanChangePopup');
          return;
        }else{
          scope.logout();
        }
      };

      rootScope.$on('switchAuthUser', function() {
        scope.switchUserPopup();
      });
      
      rootScope.$on('logoutAuthUser', function() {
        scope.logout();
      });

      scope.switchUserPopup = function(){
        scope.showRolesPopup = $modal.open({
          templateUrl: 'rolePopUp.html',
          scope: scope,
          backdrop : 'static',
          keyboard : false,
          action : 'show'
        });

        // get user roles
        createUserSvc.getUserRoles(scope.user.id)
          .then(function(roles) {
            // remove currently logged in role from the list
            roles = _.without(roles, _.findWhere(roles, {roleName: scope.user.role, providerId: parseInt(scope.user.providerId)}));
            scope.model = { selected: roles[0] };
            scope.results = roles;

            scope.switchRole = function() {
              // post session-token with role
              authSvc.switchRole(scope.model.selected.roleName, scope.model.selected.providerId)
                .then(function(loginResult) {
                  var response = loginResult.response;
                  if(response.results.roles.length === 1)
                  {
                    var currentRole = response.results.roles[0];
                    var authRoute = '';

                    authSvc.user({
                      id: response.results.userId,
                      sessionId: scope.user.sessionId,
                      token: currentRole.token,
                      role: currentRole.roleName,
                      providerId: currentRole.providerId,
                      providerName: currentRole.providerName,
                      username: scope.user.username,
                      isAuthenticated: true,
                      lastPasswordChangedDate: response.results.lastPasswordChangedDate,
                      sessionExpireMinutes: response.results.expireMinutes
                    });

                    scope.user = authSvc.user();
                    scope.user.password = 'InputFiller';
                    // Need to add redirects for each role
                    switch (scope.user.role.toLowerCase()){
                      case 'administrator':
                        authRoute = '/admin';
                        break;
                      case 'analyst':
                        authRoute = '/analyst';
                        break;
                      case 'care manager' :
                        authRoute = '/caremanager';
                        break;
                      case 'marketing analyst':
                        authRoute = '/marketing';
                        break;
                      case 'physician' :
                        authRoute = '/physicians';
                        break;
                      case 'clinic administrator' :
                        authRoute = '/clinicAdmin';
                        break;
                      case 'insurance group provider' :
                        authRoute = '/insurance';
                        break;
                      default :
                        authRoute = '/';
                        break;
                    }
                    if (scope.user.role) {
                      window.onbeforeunload = null;
                      $window.location.href = authRoute;
                    }
                  }
                });
            };
          });

      };
      scope.switchUser = function () {
        scope.carePlanLocationCtrl.isSwitchRole = true;
        if(scope.carePlanLocationCtrl.isFormDirty){
          rootScope.$broadcast('showCarePlanChangePopup');
          return;
        }else{
          scope.switchUserPopup();
        }
      };

      scope.closeSwitchUserPopup = function() {
        scope.showRolesPopup.close();
      };
 
      bannerMessages = {
        id : 'messages',
        text : 'Messages',
        link : '/message',
        icon: { 'TopNav-top_nav_icon_messages_40x40': true }
        // not working angular dirty check
        //badge: { 'badge-header': scope.inboxMessage.unreadMsgCount ? true : false },
        //count: scope.inboxMessage.unreadMsgCount
      };

      bannerReports = {
        id : 'reports',
        text : 'Reports',
        link : '/reports',
        icon : {'TopNav-top_nav_icon_reports_40x40' : true}
      };
      bannerCMTasks = {
        id : 'cmTask',
        text : 'Tasks',
        link : '/caremanager',
        icon : {'TopNav-top_nav_icon_tasks_40x40' : true}
      };
      bannerCMPatients = {
        id : 'cmPatients',
        text : 'Patients',
        link : '/search',
        icon : {'TopNav-top_nav_icon_patients_40x40' : true}
      };
      bannerNotifications ={
        id :'notifications',
        text :'Notifications',
        icon : {'TopNav-top_nav_icon_notifications_40x40' : true}
      };
      bannerAnalystReports = {
        id : 'reports',
        text : 'Reports',
        link : '/analyst',
        icon : {'TopNav-top_nav_icon_reports_40x40' : true}
      };
      /* variable declarations */
      scope.controllerData = {
        searchText : '',
        results : [],
        patientData : []
      };
      scope.hasAdvancedSearch = false;
      scope.showAdvancedSearch = function(){
        return scope.hasAdvancedSearch;
      };
      scope.bannerLinks = [{
        id : 'home',
        text : 'Home',
        icon : {'TopNav-top_nav_icon_home_40x40' : true}

      }];
      if(scope.user && scope.user.role){
        switch (scope.user.role.toLowerCase()) {
          case 'administrator':
            scope.bannerLinks[0].link = '/admin';
            scope.bannerLinks.push(bannerMessages);
            scope.bannerLinks.push(bannerReports);
            scope.hasAdvancedSearch = true;
            break;
          case 'analyst':
            scope.bannerLinks[0].link = '/analyst';
            scope.bannerLinks.push(bannerMessages);
            scope.bannerLinks.push(bannerAnalystReports);
            break;
          case 'marketing analyst':
            scope.bannerLinks[0].link = '/marketing';
            break;
          case 'care manager' :
            scope.bannerLinks[0].link = '/caremanager';
            scope.bannerLinks.push(bannerMessages);
            scope.bannerLinks.push(bannerCMTasks);
            scope.bannerLinks.push(bannerCMPatients);
            scope.bannerLinks.push(bannerReports);
            scope.bannerLinks.push(bannerNotifications);
            scope.hasAdvancedSearch = true;
            break;
          case 'care team member':
            scope.bannerLinks[0].link = '/caremanager';
            scope.bannerLinks.push(bannerNotifications);
            break;
          case 'clinic administrator':
            scope.bannerLinks[0].link = '/clinicAdmin';
            scope.bannerLinks.push(bannerMessages);
            scope.bannerLinks.push(bannerReports);
            scope.bannerLinks.push(bannerNotifications);
            scope.hasAdvancedSearch = true;
            break;
          case 'physician':
            scope.bannerLinks[0].link = '/physicians';
            scope.bannerLinks.push(bannerMessages);
            scope.bannerLinks.push(bannerReports);
            scope.bannerLinks.push(bannerNotifications);
            scope.hasAdvancedSearch = true;
            break;
          case 'insurance group provider':
            scope.bannerLinks[0].link = '/insurance';
            scope.bannerLinks.push(bannerMessages);
            scope.bannerLinks.push(bannerReports);
            scope.bannerLinks.push(bannerNotifications);
            scope.hasAdvancedSearch = true;
            break;
          default :
            scope.bannerLinks.push(bannerReports);
            break;
        }
      }
      scope.isFlag=false;
      scope.hover = function(flag){
        scope.isFlag = flag;
        if(angular.equals(scope.adtNotification.dataChunkIndex,0)){
          scope.getUnreadNotificationCount();
        }
        
      };
      scope.getPatientData = function (searchParam) {
        return http.get(app.api.root + 'patients-search', {
          params : {
            searchtext : searchParam
          }
        }).then(function (response) {
          scope.controllerData.patientData = [];
          angular.forEach(response.data.results, function (item) {
            scope.controllerData.patientData.push(item);
          });
          if (scope.controllerData.patientData.length === 0) {
            response.data.results = [{
              'FullName' : 'No records to display',
              'PatientId' : '0'
            }];
            return response.data.results;
          }
          return scope.controllerData.patientData;
        });
      };

      /* showPatientData method which is called when patient is selected from suggestion list. */
      scope.showPatientData = function (selectedPatient) {
        if (selectedPatient.PatientId === '0') {
          return;
        }
        scope.controllerData.searchText = '';
        $window.location.href = '/patients/' + selectedPatient.PatientId;
      };

      /* initial load function */
      scope.initialize = function () {
        scope.getUnreadCount();
        scope.getNotificationUnreadCount();
      };

      /* function to get unread message count */
      scope.getUnreadCount = function () {
        var user = authSvc.user();
        var getUrl = app.api.root + 'providers/' + user.providerId + '/messages-count?messageState=N';
        http({
          method: 'GET',
          url: getUrl
        }).success(function (data) {
          // scope.inboxMessage has defined in Layout scope
          scope.inboxMessage.unreadMsgCount = parseInt(data.results);
        }).error(function () {
          scope.inboxMessage.unreadMsgCount = 0;
        });
      };
      scope.getNotificationUnreadCount = function(){
        var filters = {'processType':'C'};
        adtNotificationSvc.getNotificationsRequest(filters,scope.user.providerId).then(function(response){
          scope.adtNotification.unreadCount = response.data.results.count;
          scope.adtNotification.totalElements = response.data.results.count;
          if(location.path().split('/')[1] !== 'patients'){
            scope.unlockConcurrentTask();
          }
        });
      };
      scope.getUnreadNotificationCount = function (status) {
        if (scope.adtNotification.dataChunkSize * scope.adtNotification.dataChunkIndex <= scope.adtNotification.totalElements) {
          scope.adtNotification.dataChunkIndex += 1;
          var filters = {'status':'Pending','pageSize': scope.adtNotification.dataChunkSize,'pageIndex': scope.adtNotification.dataChunkIndex,'processType':'F'};
          adtNotificationSvc.getNotificationsRequest(filters,scope.user.providerId).then(function(response){
            response.data.results.notification=_.forEach(response.data.results.notification,function(item){
              item.color='info';
              item.img = 'General-icon_check_cccccc_30x30';
              item.eventDate = moment(item.eventDate).fromNow();
            });
            if(status){
              scope.adtNotification.adtNotificationData = response.data.results.notification;
            }
            else{
              scope.adtNotification.adtNotificationData =scope.adtNotification.adtNotificationData.concat(response.data.results.notification);
            }
            scope.adtNotification.unreadCount = response.data.results.count;
            scope.adtNotification.totalElements = response.data.results.count;
          }).catch(function(){
            scope.adtNotification.unreadCount = 0;
          });
        }
      };
      scope.UpdateNotificationStatus=function(item,index){
        scope.adtNotification.adtNotificationData[index].img='General-icon_check_666666_30x30';
        scope.adtNotification.adtNotificationData[index].color='';
        var data={'PatientEventNotificationId':item.patientEventNotificationId};
        adtNotificationSvc.putAdtNotificationRequest(data,scope.user.providerId).then(function(){
          scope.resetNotification();
          scope.getUnreadNotificationCount('update');
        }).catch(function(){
          scope.getUnreadNotificationCount();
        });
        scope.isFlag=true;
      };
      scope.resetNotification = function(){
        scope.adtNotification.totalElements=0;
        scope.adtNotification.dataChunkSize=5;
        scope.adtNotification.dataChunkIndex=0;
      };
      scope.markallCompleted=function(){
        adtNotificationSvc.putAdtNotificationRequest(null,scope.user.providerId).then(function(){
            scope.resetNotification();
            scope.getUnreadNotificationCount('update');
          }).catch(function(){
          scope.getUnreadNotificationCount();
        });
        scope.isFlag=true;
      };
      scope.redirectToPatientDashBoard = function (item){
        var data={'PatientEventNotificationId':item.patientEventNotificationId};
        adtNotificationSvc.putAdtNotificationRequest(data,scope.user.providerId).then(function(){
          scope.resetNotification();
          scope.getUnreadNotificationCount('update');

          timeout(function () {
            $window.location.href = '/patients/' + item.patientId;
          }, 1000);

        }).catch(function(){
          scope.getUnreadNotificationCount();
        });
      };
      scope.redirectToNotificationPage=function(){
        $window.location.href = '/notifications';
      };

      scope.redirectToPatientMergePage=function(item){
        adtNotificationSvc.checkMergeNotificationDependencies(item.patientEventId).then(function(response){
          if(response.data.results.length > 0){
            var patientNames = _.pluck(response.data.results,'patientName').join(',');
            scope.lockedText = navConstantsSvc.mergeDependenceMessage.replace('UserName', $filter('isNull')(patientNames));
            scope.isLocked = true;
          }
          else{
            scope.putLockConcurrentTask(item);
          }
        });
      };

      scope.putLockConcurrentTask = function(item){
        scope.data={'patientEventId':item.patientEventId,'lockType':'Notifications'};
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
          localStorage.setItem('islockFlag',true);
          scope.status=response.data.results.status;
          if(scope.status === true){
            scope.isLocked = false;
            scope.lockedText = '';
            $window.location.href = '/merge/' + item.patientId + '/' + item.patientEventNotificationId;
          }
          else {
            scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName', $filter('isNull')(response.data.results.name));
            scope.isLocked = true;
          }
        });
      };
      
      scope.unlockConcurrentTask = function() {
        if(location.path().split('/')[1] !== 'merge'){
          scope.data={'lockType':'Notifications'};
          userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(){
            scope.isLocked = false;
            scope.lockedText = '';
          });
        }
      };
      scope.bannerUnlockConcurrentTask = function(bannerLink){
        if(bannerLink.text !== 'Notifications'){
          scope.data={'lockType':'Notifications'};
          userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(){
            scope.isLocked = false;
            scope.lockedText = '';
          });
        }
      };
      scope.resetToolTipText=function(){
        scope.isLocked = false;
      };

      scope.redirectToEnrollmentPage = function(item){
        var enrollmentData ={'patientEventId':item.patientEventId,'patientId':item.patientId,'patientProgramID':item.patientProgramID,'programName':item.programName,'programId':item.programId};
        localStorage.setItem('enrollmentData' , JSON.stringify(enrollmentData));
        $window.location.href = '/enrollments';
      };

      (function startIdleWatch() {
        if (scope.user) {
          var idleSeconds = (scope.user.sessionExpireMinutes * 60) - app.sessionTimeoutWarningSeconds;
          idle.setIdle(idleSeconds);

          // keepAliveInterval: ping to renew session 3/4 of way to expiration.
          // this should give a good safety buffer without too many requests.
          var keepAliveInterval = (idleSeconds / 4) * 3;
          keepAlive.setInterval(keepAliveInterval);

          idle.setTimeout(app.sessionTimeoutWarningSeconds);
          idle.watch();

          scope.$on('IdleStart', function() {
            log.info('Idle state detected');
            scope.sessionCountdown = getCountdown(app.sessionTimeoutWarningSeconds);
            scope.sessionTimeoutModal = $modal.open({
              templateUrl: 'sessionPopUp.html',
              scope: scope,
              backdrop: 'static',
              keyboard: false,
              action: 'show'
            });
          });

          scope.$on('IdleWarn', function(e, countdown) {
            scope.sessionCountdown = getCountdown(countdown);
          });

          scope.$on('IdleEnd', function() {
            log.info('User activity resumed');
          });

          scope.$on('IdleTimeout', function() {
            log.info('Logging out due to inactivity');
            scope.logout();
          });

          scope.$on('Keepalive', function() {
            authSvc.renewToken().then(function(){
              log.info('Auth token renewed');
            });
          });

          scope.continueSession = function() {
            idle.watch();
            // Keepalive event will be fired now, and authtoken renewed.
            scope.sessionTimeoutModal.close();
          };
        }

        function getCountdown(seconds){
          if (seconds <= 60) {
            return seconds + ' second' + (seconds === 1 ? '' : 's');
          }
          var minutes = '0' + Math.floor(seconds / 60);
          var remainingSeconds = '0' + (seconds - minutes * 60);
          return minutes.substr(-2) + ':' + remainingSeconds.substr(-2);
        }
      })();

    }]);
}(window.app));
