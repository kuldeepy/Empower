(function (app) {
    'use strict';
    app.controller('PatientmergeCntrl', ['$scope','$state','_','$location','mergeSvc','authSvc',
      function (scope,state,_,location,mergeSvc,authSvc) {
        scope.scheduledPage = 1;
        scope.adhocPage = 1;
        scope.mangaedPopulationPage = 1;
        scope.scheduledPageSize = 5;
        scope.adhocPageSize = 5;
        scope.mangaedPopulationPageSize = 5;
        scope.patientmergeHeader = 'Merge';
        scope.generalHeader = 'General Information';
        scope.mergeStatement= 'Merge has been initatiated for the Following patient Records';
        scope.patientId = app.routing.routeParams.patientId;
        scope.notificationId = app.routing.routeParams.patientEventNotificationId;
        var providerID = authSvc.user().providerId;
        scope.columns = {
          generalInfoColumns : ['Patient Name', 'Identifier #', 'DOB (age)','Gender'],
          tasksColumns :['Task Name', 'Task Type', 'Due Date','Close'],
          managedPopulationColumn :['Managed Population', 'Task Bundle', 'Tasks','Care Team','Disenroll']
        };
        scope.wizardWorkflow = [
          { 'id': 1, 'name': 'mapGeneralInformation' },
          { 'id': 2, 'name': 'mapManagedPopulation' },
          { 'id': 3, 'name': 'mapscheduletasks' },
          { 'id': 4, 'name': 'mapAdhoc' },
          { 'id': 5, 'name': 'mapSummary' }
        ];
        scope.tabDefinitions = [
          { name: 'mapGeneralInformation', number: '1', title: 'General Information', selectionCss: 'first active', completed: false, clickable:false, isTabCompleted:false },
          { name: 'mapManagedPopulation', number: '2', title: 'Managed Population', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false },
          { name: 'mapscheduletasks', number: '3', title: 'Open Tasks', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false },
          { name: 'mapSummary', number: '4', title: 'Summary', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false }
        ];

        scope.stepDefinitions = [
            [
              { name: 'mapGeneralInformation', letter: 'a', title: 'General Information', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false  }
            ],
            [
              { name: 'mapManagedPopulation', letter: 'a', title: 'Managed Population', selectionCss: 'active', completed: false }
            ],
            [
              { name: 'mapscheduletasks', letter: 'a', title: 'Scheduled Tasks', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false  },
              { name: 'mapAdhoc', letter: 'b', title: 'Ad-hoc Tasks', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false  }
            ],
            [
              { name: 'mapSummary', letter: 'a', title: 'Summary', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false  }
            ]
          ];

        scope.pageload = function() {
          mergeSvc.getPatientGeneralInformation(scope.notificationId).then(function (response) {
            scope.general = response.data.results;
            scope.patientData = _.where(scope.general, {patientId : parseInt(scope.patientId)});
            var mergePatientData = _.without(scope.general,scope.patientData[0]);
            getTasks(scope.patientId,mergePatientData[0].patientId);
          });
        };

        var getTasks = function(patientId,mergePatientId){
          mergeSvc.getManagedPopulation(patientId,mergePatientId).then(function (response) {
            scope.managedPopulation = response.data.results;
          });

          mergeSvc.getScheduleTasks(patientId,mergePatientId).then(function (response) {
            scope.scheduled = removeDuplicateTasks(response.data.results);
          });
    
          mergeSvc.getAdhocTasks(patientId,mergePatientId).then(function (response) {
            scope.adhoc = removeDuplicateTasks(response.data.results);
          });
        };

        _.each(scope.stepDefinitions,function(item){
          _.each(item,function(newitem)
          {
            if(state.current.name === newitem.name)
            {
              scope.Currentpage = newitem.name;
            }
          });
        });

        var removeDuplicateTasks = function(data){
          var filtedData = [];
          for (var i = 0; i < data.length; i = i+1) {
            filtedData.push({taskID : data[i].taskID,
              programID : data[i].programID,
              typeName : data[i].typeName,
              taskTypeName : data[i].taskTypeName,
              taskDueDate : data[i].taskDueDate,
              status : data[i].status,
              isDuplicate : 0});

            var result = _.where(filtedData,{programID : data[i].programID,
              typeName : data[i].typeName,
              taskTypeName : data[i].taskTypeName,
              taskDueDate : data[i].taskDueDate});
            if(result.length > 1){ filtedData[i].isDuplicate = 1; }
          }
          return filtedData;
        };

        if (scope.initializeStep) {
          if (state.current.name === scope.Currentpage) {
            scope.initializeStep(state.current.name,state.current.name === ('mapSummary') ? true : false, 'Merge');
          }else{
            scope.initializeStep(state.current.name,false,'Merge');
          }
        }

        if (state.current.name === scope.Currentpage) {
          scope.completeStep(true, scope.Currentpage);
        }

        scope.Closeandrestore = function(row,taskType){
          row.status = row.status === false ? true : false;
          if(taskType === 'scheduledTasks')
          {
            scope.scheduled = deleteTasks(scope.scheduled,row);
          }
          else if(taskType === 'adhocTasks')
          {
            scope.adhoc = deleteTasks(scope.adhoc,row);
          }
          localStorage.setItem('isWizardFormDirty',true);
        };

        var deleteTasks = function (tasksData,row){
          var result = _.where(tasksData,{programID : row.programID,
              typeName : row.typeName,
              taskTypeName : row.taskTypeName,
              taskDueDate : row.taskDueDate});
          for (var j = 0; j < tasksData.length; j = j+1) {
            for (var i = 0; i < result.length; i = i+1) {
              if (result[i].taskID === tasksData[j].taskID) {
                tasksData[j].status = row.status;
              }
            }
          }
          return tasksData;
        };

        if(mergeSvc.status === 0){
          mergeSvc.status = 1;
          scope.pageload();
        }

        scope.$on('wizardOnClose', function() {
          location.path('/notifications');
        });

        scope.$on('wizardOnsaveAndClose',function(){
          var tasks = _.where(scope.scheduled, {status : false});
          var adhocTasks = _.where(scope.adhoc, {status : false});
          tasks = tasks.length > 0 ? (adhocTasks.length > 0 ? tasks.concat(adhocTasks): tasks) : tasks;
          var managedPopulation = _.where(scope.managedPopulation, {status : false});
          mergeSvc.updatePatientMerge(scope.patientId, providerID, {notificationId : scope.notificationId,'tasks' : tasks, 'managedPopulation' : managedPopulation}).then(function () {
            window.location.href = '/notifications';
          });
        });
      }]);
  }(window.app));