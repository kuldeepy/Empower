(function (app) {
  'use strict';

  /* module root controller */
  app.controller('marketingAnalystMainCtrl', ['$scope', function (scope) {
    scope.model = {
      routeParams: {}
    };

    scope.campaignDetails = {
        'campaign': {
            'id': 0,
            'name': null,
            'description': null,
            'productionStatus': null,
          },
          'populationDefinitions': []
        };

    scope.totalPatientsDetails = {
        'totalPatients': []
      };

    scope.exportToExcelDetails = {
        'exportToExcel': []
      };

    scope.summaryState = {
        state: 1
      };

    scope.listPopulationDefinition = [];

    scope.editCampaignDetails = {
        'isEditStatus': false,
        'isSaveAsDraft':false
      };
  }]);
}(window.app));