﻿(function (app) {
  'use strict';

  app.controller('CampaignInformationCtrl', ['$scope','$state','$location','marketingSvc','populationDefinitionSvc',
     function (scope, state, location, marketingSvc, populationDefinitionSvc) {

        scope.listPopulationDefinitionSelcted = [];
        scope.isEditInformation = false;
        scope.getPopulationDefinition = function () {
          var populationDefinitionSearch = { populationDefinitionId: '', status: 'Active', populationDefinitionName: '', description: '', productionStatus: 'Final', refresh: '' };
          populationDefinitionSvc.populationDefinitionGetData('population-definition?populationDefinitionSearch=' + JSON.stringify(populationDefinitionSearch)).then(function (response) {
              if (response.data.results) {
                scope.listPopulationDefinition = response.data.results;
              }
            });
        };

        scope.init = function () {
          scope.getPopulationDefinition();
          if (scope.initializeStep) {
            scope.initializeStep('CampaignInformation', false);
          }
          if (scope.campaignDetails.populationDefinitions.length > 0) {
            scope.completeStep(true, 'CampaignInformation');
          }
          if (marketingSvc.isSaveFinal === true) {
            scope.isEditInformation = true;
          }

        };

        scope.$watch('campaignInformation', function (val) {
          if (state.current.name === 'CampaignInformation' && scope.campaignDetails.populationDefinitions === '') {
            scope.completeStep(val, 'CampaignInformation');
          }
        });

        scope.$on('wizardOnClose', function () {
          if (app !== undefined && app.currentRoute !== undefined) {
            location.url(app.currentRoute);
          }
          else {
            location.url(app.currentRoute);
          }
        });


         //add Population Definition
        scope.addPopulationDefinition = function () {
          localStorage.setItem('isWizardFormDirty', true);
          var selectedVal = scope.populationDefinition;
          if(selectedVal === '0'){
            return;
          }
          var filteredVal = scope.listPopulationDefinition.filter(function (value) {
            if(selectedVal.toString() === value.populationDefinitionId.toString()){
              return  true;
            }
          });
          if (filteredVal.length > 0) {
            scope.completeStep(true, 'CampaignInformation');
          }
          var dataPopulationDefinitionList = { 'id': 0, 'populationDefinitionId': filteredVal[0].populationDefinitionId, 'populationDefinitionName': filteredVal[0].populationDefinitionName, 'statusCode': filteredVal[0].statusCode };
          var pushState = true;
          
          if (scope.campaignDetails.populationDefinitions.length === 0) {
            scope.campaignDetails.populationDefinitions.push(dataPopulationDefinitionList);
          } else if (scope.campaignDetails.populationDefinitions.length > 0) {
            angular.forEach(scope.campaignDetails.populationDefinitions, function (element) {
              if(dataPopulationDefinitionList.populationDefinitionId === element.populationDefinitionId){
                pushState = false;
              }
            });
            if (pushState) {
              scope.campaignDetails.populationDefinitions.push(dataPopulationDefinitionList);
            }
          }
          return scope.campaignDetails.populationDefinitions;
        };

         //Remove Population Definition
        scope.deletePopulationDefinition = function () {
          var datapopulationDefinitionListSelected = scope.campaignDetails.populationDefinitionSelected;
          var pushState =false;
          scope.campaignDetails.populationDefinitionDescription1 = scope.campaignDetails.populationDefinitions.map(function (optionItem) {
            pushState = false;
            angular.forEach(datapopulationDefinitionListSelected, function (element) {
              if(optionItem.populationDefinitionId === element.populationDefinitionId){
                pushState = true;
                localStorage.setItem('isWizardFormDirty', true);
              }
            });
            return (pushState) ? null : optionItem;
          });

          scope.campaignDetails.populationDefinitions = scope.campaignDetails.populationDefinitionDescription1.filter(function (optionItem) {
            return (optionItem === null) ? false : true;
          });

          if (scope.campaignDetails.populationDefinitions.length === 1) {
            scope.campaignDetails.populationDefinitionDescription1 = null;
          }
          if (scope.campaignDetails.populationDefinitions.length === 0) {
            scope.completeStep(false, 'CampaignInformation');
          }
        };

      }]);
})(window.app);

