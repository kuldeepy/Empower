﻿(function (app) {
  'use strict';

  app.controller('CampaignGeneralInformationCtrl', ['$scope','$state','$location','marketingSvc',
     function (scope, state, location, marketingSvc) {

        scope.isEdit = false;
        scope.init = function () {
          if (scope.initializeStep) {
            if (scope.editCampaignDetails.isEditStatus === true) {
              scope.editCampaignDetails.isEditStatus = false;
              state.go('CampaignSummary');
            } else {
              scope.initializeStep(state.current.name, false);
            }
          }
          if (marketingSvc.isSaveFinal === true) {
            scope.isEdit = true;
          }

        };

        scope.$watch('campaignGeneralInformation.$valid', function (val) {
          if (state.current.name === 'campaignGeneralInformation' && scope.checkCampaignNameExist !==  true) {
            scope.completeStep(val, 'campaignGeneralInformation');
          }
        });
         
        scope.$watch('campaignGeneralInformation.$pristine', function () {
          if (scope.campaignGeneralInformation && !scope.campaignGeneralInformation.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$on('wizardOnClose', function () {
          if (app !== undefined && app.currentRoute !== undefined) {
            location.url(app.currentRoute);
          }
          else {
            location.url(app.currentRoute);
          }
        });

         //Check Campaing Name Exist
        scope.checkCampaignNameExist = function () {
          scope.isCampaignNameExist = false;
          var id = localStorage.getItem('campaignId');
          if (scope.campaignDetails.campaign.name) {
            scope.urlData = '?name=' + scope.campaignDetails.campaign.name;
            marketingSvc.getCampaigns(scope.urlData).then(function (response) {
              response.data.results.forEach(function (campaignName) {
                if (campaignName.name.toLowerCase() === scope.campaignDetails.campaign.name.toLowerCase() && parseInt(campaignName.id) !== parseInt(id)) {
                  scope.isCampaignNameExist = true;
                  scope.campaignGeneralInformation.campaignName.$setValidity('required', false);
                }
              });
              if (!scope.isCampaignNameExist) {
                scope.completeStep(!scope.isCampaignNameExist, 'CampaignInformation');
              }
            });
          }
          return scope.isCampaignNameExist;
        };

      }]);
})(window.app);

