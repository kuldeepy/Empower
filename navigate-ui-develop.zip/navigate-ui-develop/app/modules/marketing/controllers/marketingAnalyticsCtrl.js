(function (app) {
  'use strict';

  app.controller('marketingAnalystCtrl', ['$scope','$timeout', 'assessmentBuilderSvc', '$location', '$window','marketingSvc','$state','populationDefinitionSvc','navConstantsSvc','authSvc',
    function (scope, timeout, assessmentBuilderSvc, location, window, marketingSvc, state, populationDefinitionSvc, navConstantsSvc,authSvc) {

        scope.pageTitle = 'Export Patient List';
        scope.accordionStatus = true;
        scope.accordionTitle = 'Search Data';
        scope.page = 1;
        scope.pageSize = 10;
        
        scope.ShowNotifications = function (errorMsg, style) {
            scope.alertSuccessMessageStyle = style;
            scope.alertSuccessMessage = errorMsg;
            scope.isError = true;
            scope.isSuccessMsg = style === 'alert-success' ? true : false;
            timeout(function () {
                scope.isError = false;
              }, 6000);
          };

        if (marketingSvc.saveNotificationMsg) {
          scope.ShowNotifications(marketingSvc.saveNotificationMsg, 'alert-success');
          marketingSvc.saveNotificationMsg = null;
        }

        scope.daysLeftChangePassword =  authSvc.getLastChangedPasswordDays();
        scope.daysLeftChangePassword = scope.daysLeftChangePassword.toString();

        //filter data
        scope.search = {
            campaignName: '',
            populationDefinition: '',
            pageIndex: 1,
            pageSize:10,
            dateFrom: {
                opened: false,
                value: null,
                maxDate: new Date(),
                format: 'MM/dd/yyyy'
              },
              dateTo: {
                  opened: false,
                  value: null,
                  maxDate: new Date(),
                  format: 'MM/dd/yyyy'
                }
              };

        //Date Picker DateFrom
        scope.openDateFromPopout = function ($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateFrom.opened = !scope.search.dateFrom.opened;
        };

        //Date Picker DateTo
        scope.openDateToPopout = function ($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateTo.opened = !scope.search.dateTo.opened;
        };

        // Clear all the Filter values
        scope.clearCampaign = function () {
          scope.search.campaignName = null;
          scope.search.populationDefinition = null;
          scope.search.dateFrom.value = null;
          scope.search.dateTo.value = null;
          scope.searchCampaign();
        };
       
        // init call on-load
        scope.init = function() {
          scope.searchCampaign();
          scope.getPopulationDefinition();
        };


        scope.getPopulationDefinition = function () {
          var populationDefinitionSearch = { populationDefinitionId: '', status: 'Active', populationDefinitionName: '', description: '', productionStatus: 'Final', refresh: '' };
          populationDefinitionSvc.populationDefinitionGetData('population-definition?populationDefinitionSearch=' + JSON.stringify(populationDefinitionSearch)).then(function (response) {
              if (response.data.results) {
                scope.listPopulationDefinition = response.data.results;
              }
            });
        };

        scope.getCampaignFilterData = function() {
          return {
            userName: scope.search.campaignName ? scope.search.campaignName : null,
            populationDefinition: scope.search.populationDefinition ? scope.search.populationDefinition : 0,
            startDate: scope.search.dateFrom.value ? window.moment(scope.search.dateFrom.value).format('YYYY-MM-DD') : null,
            endDate:scope.search.dateTo.value ? window.moment(scope.search.dateTo.value).format('YYYY-MM-DD'): null
          };
        };

        
        //Search Campaing Grid
        scope.searchCampaign = function () {
          scope.getCampaignFilter = scope.getCampaignFilterData();
          if (scope.getCampaignFilter.userName === null && scope.getCampaignFilter.populationDefinition === 0 && scope.getCampaignFilter.startDate === null && scope.getCampaignFilter.endDate === null) {
            scope.urlData = '';
          } else {
            scope.urlData = '?name=' + (scope.getCampaignFilter.userName ? scope.getCampaignFilter.userName : '') + '&populationDefinitionId=' + scope.getCampaignFilter.populationDefinition + '&dateFrom=' + (scope.getCampaignFilter.startDate ? scope.getCampaignFilter.startDate : '') + '&dateTo=' + (scope.getCampaignFilter.endDate ? scope.getCampaignFilter.endDate : '');
          }
          marketingSvc.getCampaigns(scope.urlData).then(function (response) {
              if (response.data.results) {
                scope.campaignData = response.data.results;
                scope.campaigns = angular.forEach(scope.campaignData, function (filterObj, filterIndex) {
                  scope.gridPopulationDefinition = '';
                  angular.forEach(filterObj.populationDefinitions, function (gridPopulationDefinitions) {
                    if (scope.gridPopulationDefinition === '') {
                      scope.gridPopulationDefinition = gridPopulationDefinitions.populationDefinitionName;
                    } else {
                      scope.gridPopulationDefinition = scope.gridPopulationDefinition + ',  ' + gridPopulationDefinitions.populationDefinitionName ;
                    }
                    scope.campaignData[filterIndex].gridPopulationDefinition = scope.gridPopulationDefinition;
                  });
                });
              }
            });
        };

        //Table field for Campaign
        scope.columnsSelected = [{ field: 'name', displayName: 'Campaign Name', columnClass: 'table-column-name' }, { field: 'description', displayName: 'Description', columnClass: 'table-column-description' }, { field: 'gridPopulationDefinition', displayName: 'Population Definition', columnClass: 'table-column-description', sortable: false }, { field: 'createdDate', displayName: 'Date Created', columnClass: 'table-column-name' }, { field: 'productionStatus', displayName: 'Status', columnClass: 'table-column-date' }, { field: 'action', displayName: 'Action', sortable: false, columnClass: 'table-column-action' }];
        

        //clear Campaign Data
        scope.clearCampaignData = function () {
          scope.campaignDetails.campaign.id = null;
          scope.campaignDetails.campaign.name = null;
          scope.campaignDetails.campaign.description = null;
          scope.campaignDetails.campaign.productionStatus = null;
        };

        //add Campaign Wizards
        scope.addNewCampaign = function (value, status) {
          localStorage.setItem('campaignId', value ? value : 0);
          localStorage.setItem('isWizardFormDirty', true);
          scope.clearCampaignData();
          scope.campaignDetails.populationDefinitions = [];
          marketingSvc.isSaveFinal = false;
          marketingSvc.isSpinner = false;
          var id = value;
          if (id > 0) {
            marketingSvc.isSaveFinal = status === 'F' ? true : false;
            marketingSvc.isSpinner = true;
            scope.summaryState.state = 1;
            scope.editCampaignDetails.isEditStatus = true;
            state.go('CampaignSummary');
          }
          location.url(app.currentRoute + '/add');
          scope.campaignDetails = {
            'campaign': {
              'id': 0,
              'name': null,
              'description': null,
              'productionStatus': null,
            },
            'populationDefinition': []
          };
            
        };


      }]);

}(window.app));
