﻿(function (app) {
  'use strict';

  app.controller('CampaignSummaryCtrl', ['$scope', '$state', '$location', 'marketingSvc','navConstantsSvc',
     function (scope, state, location, marketingSvc, navConstantsSvc) {
        scope.message = '';
        scope.campaignSummaryDetails = [];
        scope.init = function () {
          scope.getPatientsCount();
          if (scope.initializeStep) {
            scope.initializeStep('CampaignSummary', true);
          }
          if (scope.editCampaignDetails.isEditStatus === true && scope.summaryState.state === 1) {
            scope.campaignHeader = 'Edit Campaign';
            var campaignId = localStorage.getItem('campaignId');
            scope.searchCampaign(campaignId);
          }
          scope.campaignSummaryDetails = scope.campaignDetails.populationDefinitions;
        };
        
        scope.getPopulationDefinitionId = function (url) {
          scope.values = url.split('/');
          scope.value1 = scope.values[3];
          return scope.value1;
        };

        scope.getPatientsCount = function () {
          scope.totalPatientsDetails.totalPatients = [];
          scope.campaigns = angular.forEach(scope.campaignDetails.populationDefinitions, function (filterObj) {
            scope.selectPopulationDefinitionId = filterObj.populationDefinitionId;
            marketingSvc.getPatientCount(scope.selectPopulationDefinitionId).then(function (response) {
              if (response.data.results) {
                scope.id = scope.getPopulationDefinitionId(response.data.href);
                scope.TotalPatients = { 'patientsCount': response.data.results.TotalPatients ,'id': parseInt(scope.value1)};
                scope.totalPatientsDetails.totalPatients.push(scope.TotalPatients);
                if (scope.campaignDetails.populationDefinitions.length === scope.totalPatientsDetails.totalPatients.length) {
                  angular.forEach(scope.campaignDetails.populationDefinitions, function (filterObj, filterIndex1) {
                    angular.forEach(scope.totalPatientsDetails.totalPatients, function (filterObj1, filterIndex2) {
                      if (scope.campaignDetails.populationDefinitions[filterIndex1].populationDefinitionId === filterObj1.id) {
                        scope.campaignDetails.populationDefinitions[filterIndex1].patientsCount = scope.totalPatientsDetails.totalPatients[filterIndex2].patientsCount;
                      }
                    });
                  });
                }
              }
            });
          });
        };

        scope.searchCampaign = function (ampaignId) {
          marketingSvc.getCampaignsDetailsById(ampaignId).then(function (response) {
            if (response.data.results) {
              scope.campaignData = response.data.results;
              scope.campaignDetails.campaign.name = scope.campaignData.name;
              scope.campaignDetails.campaign.id = scope.campaignData.id;
              scope.campaignDetails.campaign.productionStatus = scope.campaignData.productionStatus;
              scope.campaignDetails.campaign.description = scope.campaignData.description;
              scope.campaignDetails.populationDefinitions = scope.campaignData.populationDefinitions;
              scope.getPatientsCount();
            }
          });
        };

         //Table field for Campaign
        scope.resultsTable = navConstantsSvc.populationDefinitionTable;
        
        scope.$on('wizardOnClose', function () {
          if (app !== undefined && app.currentRoute !== undefined) {
            location.url(app.currentRoute);
            scope.campaignDetails.populationDefinitions = [];
          }
          else {
            location.url(app.currentRoute);
          }
        });

        scope.$on('wizardOnsaveAndClose', function () {
          if (scope.campaignDetails.campaign.id > 0) {
            scope.updateCampaign('Final');
          } else {
            scope.saveCampaign('Final');
          }
        });

        scope.$on('wizardOnsaveDraftAndClose', function () {
          if (scope.campaignDetails.campaign.id > 0) {
            scope.updateCampaign('Draft');
          } else {
            scope.saveCampaign('Draft');
          }
        });
         
        scope.saveCampaign = function (prodStatus) {
          if (prodStatus === 'Final') {
            scope.campaignDetails.campaign.productionStatus = 'F';
            scope.message = 'Your patient list was saved and exported successfully.';
          }
          if (prodStatus === 'Draft') {
            scope.campaignDetails.campaign.productionStatus = 'D';
            scope.message = 'Your patient list was saved successfully.';
          }
          var newNode = {
            'id': scope.campaignDetails.campaign.id,
            'name': scope.campaignDetails.campaign.name,
            'description': scope.campaignDetails.campaign.description,
            'productionStatus':scope.campaignDetails.campaign.productionStatus,
            'populationDefinitions': scope.campaignDetails.populationDefinitions
          };
          marketingSvc.postCampaign(newNode).then(function (response) {
            if (response.data.results) {
              marketingSvc.saveNotificationMsg = scope.message;
              location.url(app.currentRoute);
              scope.campaignDetails.populationDefinitions = [];
            }
          });
        };

        scope.updateCampaign = function (prodStatus) {
          if (prodStatus === 'Final') {
            scope.campaignDetails.campaign.productionStatus = 'F';
            scope.updateMessage = 'Your patient list was saved and exported successfully.';
          }
          if (prodStatus === 'Draft') {
            scope.campaignDetails.campaign.productionStatus = 'D';
            scope.updateMessage = 'Your patient list was updated successfully.';
          }
          var newNode = {
            'id': scope.campaignDetails.campaign.id,
            'name': scope.campaignDetails.campaign.name,
            'description': scope.campaignDetails.campaign.description,
            'productionStatus':scope.campaignDetails.campaign.productionStatus,
            'populationDefinitions': scope.campaignDetails.populationDefinitions
          };
          marketingSvc.putCampaignByID(newNode).then(function (response) {
            if (response.data.results) {
              marketingSvc.saveNotificationMsg = scope.updateMessage;
              scope.campaignDetails.populationDefinitions = [];
              location.url(app.currentRoute);
            }
          });
        };
         

        scope.exportToExcelRow = function (row) {
          var node = {
            'populationDefinitionId': row.populationDefinitionId,
            'pageIndex': 1,
            'pageSize': row.patientsCount
          };
          marketingSvc.getExportToExcel(node).then(function (response) {
            if (response.data.results) {
              var fileName = 'Patients_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
              var csvResult = 'Patients' + '\n' + navConstantsSvc.myPatientsHeader.toString() + '\n';
              angular.forEach(response.data.results.Patients, function (patients) {
                var myPatient = [patients.UserName.indexOf(',') === -1?patients.UserName:'"'+patients.UserName+'"', (patients.IdentificationDate !== null) ? moment(patients.IdentificationDate).format('L') : patients.IdentificationDate, (patients.EnrollmentStartDate !== null) ? moment(patients.EnrollmentStartDate).format('L') : patients.EnrollmentStartDate, patients.StatusDescription];
                csvResult = csvResult + myPatient.toString() + '\n';
              });
              var blob = new Blob([csvResult], {type:'data:text/csv'});
              window.saveAs(blob, fileName);
            }
          });
        };

        scope.exportToExcel = function () {
          scope.totalPatientsDetails.totalPatients = [];
          

          var exportList = _.filter(scope.campaignDetails.populationDefinitions,function(item){ return item.patientsCount > 0; });

          scope.campaigns = angular.forEach(exportList, function (filterObj) {

            if(filterObj.patientsCount > 0){

              var node = {
                'populationDefinitionId': filterObj.populationDefinitionId,
                'pageIndex': 1,
                'pageSize': filterObj.patientsCount
              };

              marketingSvc.getExportToExcel(node).then(function (response) {
                if (response.data.results) {
                  scope.exportToExcelData = { 'exportToExcel': response.data.results };
                  scope.totalPatientsDetails.totalPatients.push(scope.exportToExcelData);

                  var totalPD = _.filter(scope.campaignDetails.populationDefinitions,function(item){ return item.patientsCount !== 0; }).length ;
                  var fileName = 'Patients_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
                  var csvResult = 'Patients' + '\n' + navConstantsSvc.myPatientsHeader.toString() + '\n';
                  if (totalPD === scope.totalPatientsDetails.totalPatients.length) {
                    angular.forEach(scope.totalPatientsDetails.totalPatients, function (filterObj1) {
                      scope.exportToExcelDetails.exportToExcel.push(filterObj1);
                      angular.forEach(filterObj1.exportToExcel.Patients, function (patients) {
                        var myPatient = [patients.UserName.indexOf(',') === -1?patients.UserName:'"'+patients.UserName+'"', (patients.IdentificationDate !== null) ? moment(patients.IdentificationDate).format('L') : patients.IdentificationDate, (patients.EnrollmentStartDate !== null) ? moment(patients.EnrollmentStartDate).format('L') : patients.EnrollmentStartDate, patients.StatusDescription];
                        csvResult = csvResult + myPatient.toString() + '\n';
                      });
                      if (scope.exportToExcelDetails.exportToExcel.length === scope.totalPatientsDetails.totalPatients.length) {
                        var blob = new Blob([csvResult], {type:'data:text/csv'});
                        window.saveAs(blob, fileName);
                        scope.exportToExcelDetails.exportToExcel = [];
                        scope.totalPatientsDetails.totalPatients =[];
                      }
                    });
                  }
                }
              });
            }
          });
        };
      }]);
})(window.app);

