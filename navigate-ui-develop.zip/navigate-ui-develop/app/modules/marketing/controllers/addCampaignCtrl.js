﻿(function (app) {
  'use strict';

  app.controller('addCampaignCtrl', ['$scope','marketingSvc',
     function (scope, marketingSvc) {

        scope.init = function() {
          if (scope.campaignDetails.campaign.id > 0 || scope.editCampaignDetails.isEditStatus === true) {
            scope.campaignHeader = 'Edit Campaign';
          } else {
            scope.campaignHeader = 'Add New Campaign';
          }
        };

        if (marketingSvc.isSaveFinal === true) {
          scope.isSaveAsDraftDisabled = true;
          scope.hideSaveAsDraft = false;
          scope.isSaveDisabled = true;
          scope.showSaveAndCloseButton = false;
        }else{
          scope.isSaveAsDraftDisabled = false;
          scope.hideSaveAsDraft = false;
          scope.showSaveAndCloseButton = false;
          scope.isSaveDisabled = false;
        }

       

         //Wizard Work Flow Steps
        scope.wizardWorkflow = [
          { 'id': 1, 'name': 'campaignGeneralInformation' },
          { 'id': 2, 'name': 'CampaignInformation' },
          { 'id': 3, 'name': 'CampaignSummary' }
        ];

         //Wizard tab Definitions for Top
        scope.tabDefinitions = [
          { name: 'campaignGeneralInformation', number: '1', title: 'Campaign Information', selectionCss: 'first active', completed: false, clickable: false, isTabCompleted: false },
          { name: 'CampaignInformation', number: '2', title: 'Population Definition', selectionCss: 'inactive', completed: false, clickable: false, isTabCompleted: false },
          { name: 'CampaignSummary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false, clickable: false, isTabCompleted: false }
        ];

         //Wizard tab Definitions for Side
        scope.stepDefinitions = [
          [
            { name: 'campaignGeneralInformation', letter: 'a', title: 'Campaign Information', selectionCss: 'active', completed: false, clickable: false, isTabCompleted: false }
          ],
           //Select Ideal Target task type Tab
          [
            { name: 'CampaignInformation', letter: 'a', title: 'Population Definition', selectionCss: 'active', completed: false, clickable: false, isTabCompleted: false },
          ],
          [
            { name: 'CampaignSummary', letter: 'a', title: 'Summary', selectionCss: 'active', completed: false, clickable: false, isTabCompleted: false }
          ]
        ];
      }]);
})(window.app);

