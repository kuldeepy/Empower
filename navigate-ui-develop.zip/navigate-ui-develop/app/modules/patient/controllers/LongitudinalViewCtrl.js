(function (app) {
    'use strict';
    app.controller('lvctrl', ['$scope','$timeout','reminderScheduleSvc','_','$location','httpRequestSvc','PatientData',
        function (scope, $timeout,reminderScheduleSvc,_,location,httpRequestSvc,PatientData) {

            scope.pageTitle = 'Longitudinal View';
            scope.currentDate = moment(new Date ()).format('YYYY-MM-DD');
            scope.date = moment(new Date ()).format('MM/DD/YYYY');
            scope.patientId = PatientData.id;
            scope.isopen = true;
            scope.checkData = null;
            scope.from = -12;
            scope.to = 12;
            scope.measuresSelectedData = [];
            scope.encounterResultSet = [];
            scope.medicationResultSet = [];

            scope.sliders = [];
            scope.ResultData = [];
            scope.searchData={ 'fromDate': moment(scope.currentDate).add('years', -1).format('YYYY-MM-DD'), 'toDate': moment(scope.currentDate).add('years', 1).format('YYYY-MM-DD')};
            scope.clinicalResultColors = [{'id':1,'color':'#6fa8dc'},{'id':2,'color':'#e06666'},{'id':3,'color':'#6aa84f'},{'id':4,'color':'#08e6be'}];
            var d1 = moment(scope.searchData.fromDate);
            var d2 = moment(scope.searchData.toDate);
            scope.endRange = moment.duration(d2.diff(d1)).asDays();
            scope.sliders = [0,scope.endRange];
            scope.boundaries = scope.sliders;
            scope.sliderDates = {from:moment(scope.currentDate).add('years', -1).format('MM/DD/YYYY'),to:moment(scope.currentDate).add('years', 1).format('MM/DD/YYYY')};
            scope.clinicalResultsTrendGraph=function(data,xaxisdata,id,index,name){
                var parser = d3.time.format('%Y-%m-%d');
                var dateReader = function (d) {
                  return parser.parse(d.date);
                };
                var start = d3.time.day.offset(d3.min(xaxisdata, dateReader), 0);
                var end = d3.time.day.offset(d3.max(xaxisdata, dateReader), 0);
                $('#chartContainer').empty();
                var svg = dimple.newSvg('#chartContainer', 700, 900);
                var metricsTrendChart = new dimple.chart(svg, data);
                if(scope.ResultData.length>12){
                  metricsTrendChart.setBounds('7%', '5%', '90%', '70%');
                }
                else{
                  metricsTrendChart.setBounds('7%', '5%', '90%', '85%');
                }
                scope.legendData = [];
                scope.selectedMeasures.forEach(function(item){
                  scope.legendData.push(item.measureName);
                  metricsTrendChart.assignColor(item.measureName, scope.clinicalResultColors[scope.selectedMeasures.indexOf(item)].color, scope.clinicalResultColors[scope.selectedMeasures.indexOf(item)].color, 5);
                });

                var x = metricsTrendChart.addTimeAxis('x', 'date', '%m/%d/%Y','%m/%d/%Y');
                x.addGroupOrderRule(scope.legendData);
                x.overrideMin = start;
                x.overrideMax = end;

                var y= metricsTrendChart.addMeasureAxis('y', 'measureValue');
                var seriesMetricTrend = metricsTrendChart.addSeries('measureName', dimple.plot.line);
                seriesMetricTrend.lineMarkers = true;
                x.showGridlines = true;
                y.showGridlines = true;
                x.timePeriod = d3.time.months;
                var popup;
                function onHover(e) {
                  var tooltip;
                  tooltip = [(e.seriesValue),'Value Date :' + moment(e.xValue).format('MM/DD/YYYY'), 'Value :' + e.yValue.toString()];
                  var cx = parseFloat(e.selectedShape.attr('cx')),
                      cy = parseFloat(e.selectedShape.attr('cy'));
                  var width = 150,
                      height = 90;
                  x = (cx + width + 10 < svg.attr('width') ?
                         cx + 10 :
                         cx - width - 20);
                  y = (cy - height / 2 < 0 ?
                        15 :
                        cy - height / 2);
                  popup = svg.append('g');
                  popup
                        .append('rect')
                        .attr('x', x + 5)
                        .attr('y', y - 5)
                        .attr('width', 160)
                        .attr('height', height)
                        .attr('rx', 5)
                        .attr('ry', 5)
                        .style('fill', 'white')
                        .style('stroke', '#6fa8dc')
                        .style('fill-opacity', '0.8')
                        .style('stroke-opacity', '0.1')
                        .style('stroke-width', 3);
                  popup
                        .append('line')
                        .attr('x1', x + 5)
                        .attr('x2', x + 5+160)
                        .attr('y1', y - 5)
                        .attr('y2', y - 5)
                        .attr('width', 160)
                        .attr('rx', 5)
                        .attr('ry', 5)
                        .style('fill', 'white')
                        .style('stroke', e.selectedShape[0][0].attributes.stroke.value)
                        .style('stroke-width', 5)
                        .style('stroke-linecap','round');

                  popup
                        .append('text')
                        .attr('x', x + 10)
                        .attr('y', y + 10)
                        .append('tspan')
                        .attr('x', x + 10)
                        .attr('y', y + 20)
                        .text(tooltip[0])
                        .style('font-family', 'sans-serif')
                        .style('font-size', 10)
                        .append('tspan')
                        .attr('x', x + 10)
                        .attr('y', y + 40)
                        .text(tooltip[1])
                        .style('font-family', 'sans-serif')
                        .style('font-size', 10)
                        .append('tspan')
                        .attr('x', x + 10)
                        .attr('y', y + 60)
                        .text(tooltip[2])
                        .style('font-family', 'sans-serif')
                        .style('font-size', 10);
                }
                function onLeave() {
                  if (popup !== null) {
                    popup.remove();
                  }
                }
                seriesMetricTrend.addEventHandler('mouseover', onHover);
                seriesMetricTrend.addEventHandler('mouseleave', onLeave);
                metricsTrendChart.draw();

                if (x.overrideMin > 0) {
                  x._origin = metricsTrendChart._xPixels();
                }
                if(id === 0){
                  y.shapes.selectAll('.tick').style('opacity', '0');
                  y.titleShape.text('');
                }
                else{
                  y.titleShape.text(name).style('fill', scope.clinicalResultColors[index].color);
                  y.shapes.selectAll('.tick').style('fill', scope.clinicalResultColors[index].color);
                }
                x.titleShape.text('Dates');
              };
            scope.isRangeFromSelected= function(x){
              return (x === scope.from);
            };
            scope.isRangeToSelected= function(x){
              return (x === scope.to);
            };
            scope.change=function(data){
                scope.splitLine = false;
                scope.dataset = [];
                scope.graphData = [];
                var startValue = new Date(d1);
                startValue = moment(startValue.setDate(startValue.getDate() + Number(data[0].toString().split('.')[0]))).format('YYYY-MM-DD');
                var endValue = new Date(d2);
                endValue = moment(endValue.setDate(endValue.getDate()- (scope.endRange - Number(data[1].toString().split('.')[0])))).format('YYYY-MM-DD');
                scope.firstValue=moment(startValue).format('MM/DD/YYYY');
                scope.secondVale=moment(endValue).format('MM/DD/YYYY');
                scope.sliderDates={from:scope.firstValue,to:scope.secondVale};
                scope.searchData = {'fromDate': moment(scope.firstValue).format('YYYY-MM-DD'), 'toDate': moment(scope.secondVale).format('YYYY-MM-DD')};
                scope.graphData = _.filter(scope.clinicalResultsData, function (item) {
                    return (item.datetaken >= startValue &&  item.datetaken <= endValue);
                  });
                scope.rebind(2);
                $('#chartContainer').empty();
                scope.clinicalResultsTrendGraph(scope.graphData,scope.graphxaxisData,0);
              };

            scope.hoverOut=function(){
                $('#chartContainer').empty();
                scope.clinicalResultsTrendGraph(scope.graphData,scope.graphxaxisData,0);
              };
            scope.hoverIn=function(name,index){
                $('#chartContainer').empty();
                scope.graphdummyData = _.filter(scope.graphData, function (item) {
                    return (item.measureName === name);
                  });
                scope.clinicalResultsTrendGraph(scope.graphdummyData,scope.graphxaxisData,1,index,name);
              };
            scope.bindData=function(data,id){
                scope.hideEncounter = 'Hide Encounters';
                scope.hideMedication = 'Hide Medications';
                scope.dataset = [];
                scope.ResultData = [];
                httpRequestSvc.getRequest('patients/'+PatientData.id+'/longitudinal-view',data).then(function(response){
                  if(angular.equals(id,0) || angular.equals(id,2)){
                    scope.measueres = response.data.results.measureName;
                    var clinicalResultcount = 0;
                    scope.measueres.forEach(function(item){
                      if(clinicalResultcount <= 3){
                        item.selected = true;
                      }
                      else{
                        item.selected = false;
                      }
                      clinicalResultcount = clinicalResultcount + 1;
                    });
                    scope.selectedMeasures = scope.measueres.slice(0,4);
                    scope.selectedClinicalResultscount = scope.selectedMeasures.length;
                  }
                  else{
                    scope.isVisible = true;
                  }
                  scope.measuresSelectedData = scope.selectedMeasures;
                  scope.medicationsData = _.sortBy(response.data.results.patientDrugs,'dateTaken');
                  scope.encounterData = _.sortBy(response.data.results.patientEncounters,'dateTaken');
                  scope.encounterData = _.filter(scope.encounterData, function (item) {
                    var from=(moment(scope.searchData.fromDate).format('YYYY-MM-DD'));
                    var to=(moment(scope.searchData.toDate).format('YYYY-MM-DD'));
                    return(moment(item.encounterDate).format('YYYY-MM-DD') >= from && moment(item.encounterDate).format('YYYY-MM-DD') <= to );
                  });
                  scope.patientTasks = _.sortBy(response.data.results.patientTasks,'dateTaken');
                  scope.patientTasksLv = response.data.results.patientTasksLv;
                  response.data.results.measureDetails.forEach(function(item){
                      item.date = moment(item.datetaken.split('T')[0]).format('MM/DD/YYYY');
                    });
                  scope.clinicalResultsData = response.data.results.measureDetails;
                  scope.graphData = response.data.results.measureDetails;
                  scope.boundaries = [0,scope.endRange];
                  scope.sliders = scope.boundaries;
                  scope.rebind(1);
                  scope.graphxaxisData = [];
                  scope.graphxaxisData.push({'date':scope.searchData.fromDate},{'date':scope.searchData.toDate});
                  scope.clinicalResultsTrendGraph(scope.clinicalResultsData,scope.graphxaxisData,0);
                  scope.change(scope.sliders);
                });
                scope.sliderDateValues = [];
                for(var i = 0; i <= scope.endRange ; i= i+1){
                  scope.sliderDateValues.push({date:moment(scope.searchData.fromDate).add('days',i).format('MM/DD/YYYY')});
                }
              };
            scope.fromcount = 0;
            scope.tocount = 0;
            scope.ChartWidth = function(data,date,index){
              scope.medicationWidthCount = 0;
              scope.enconterWidthCount = 0;
              scope.opentasksWidthCount = 0;
              scope.scheduleTaskssWidthcount = 0;
              scope.completetaskWidthCount = 0;
              scope.missedOpportunitiesWidthCount = 0;
              var width;
              scope.months = [{id:'31',name:'01'},{id:moment(date.split('-')[0] + '-' + '02').endOf('month').format('DD'),name:'02'},{id:'31',name:'03'},{id:'30',name:'04'},{id:'31',name:'05'},{id:'30',name:'06'},{id:'31',name:'07'},{id:'31',name:'08'},{id:'30',name:'09'},{id:'31',name:'10'},{id:'30',name:'11'},{id:'31',name:'12'}];

              if(angular.equals(index,0)&& !angular.equals(scope.ResultData.length,1)){
                var count;
                scope.months.forEach(function(item){
                  if(item.name === date.split('-')[1]){
                    count = item.id;
                  }
                });
                if(Number(date.split('-')[2]) > 1){
                  width= (100/data.length);
                  width = (width * (Number(date.split('-')[2])))/(Number(count));
                  scope.mainWidth = width;
                  width = width + '%';
                }
                else{
                  width = (100/data.length) + '%';
                  scope.mainWidth = (100/data.length);
                }
              }
              else{
                width = (100/data.length) + '%';
                scope.mainWidth = (100/data.length);
              }
              return {'width':width};
            };
            scope.rebind=function(id){
              scope.ResultData = [];
              scope.dataset=[];
              var length = moment(scope.searchData.toDate).diff(scope.searchData.fromDate,'months',true);
              var d1;
              for(var i = 0;i <= length; i = i+1){
                scope.changedDate = moment(scope.searchData.fromDate).add('months',i).format('YYYY-MM-DD');
                if(i === 0){
                  scope.datasetChangedDate = Number(scope.searchData.fromDate.split('-')[2])>1 ? '':scope.searchData.fromDate;
                }
                else{
                  scope.datasetChangedDate = moment(scope.searchData.fromDate).add('months',i).format('YYYY-MM-DD');
                  d1 = scope.datasetChangedDate.split('-');
                  scope.datasetChangedDate = d1[0] + '-' + d1[1] +'-' + '01';
                }
                scope.dataset.push({date:scope.datasetChangedDate!== ''? moment(scope.datasetChangedDate).format('MM/DD/YYYY'):scope.datasetChangedDate});
                scope.ResultData.push({'rowindex':i ,'MedicationId':[],'drugName':[],'dateFilled':[],'dosageName':[],'daysSupply':[],'medicationProviderName':[],'specialityName':[],'medicationdateTaken':[],'medicationdate':[],'endateTaken':[],'endate':[],'cldateTaken':[],'cldate':[],'scdateTaken':[],'scdate':[],'opdateTaken':[],'opdate':[],'midateTaken':[],'midate':[],'isMedication':false,'medicationCount':[],'isEncounters':false,'isOpenTasks':false,'isscheduleTasks':false,'isCompleteTask':false,'isMissedOpportunity':false,'enCounterId':[],'encounter':[],'encounterProviderName':[],'enproviderSpeciality':[],'encounterCount':[],'closedTaskId':[],'closedName':[],'closedTaskStatus':[],'closedNoofAttempts':[],'closedTaskCount':[],'scheduledTaskId':[],'scheduledName':[],'scheduledTaskStatus':[],'scheduledNoofAttempts':[],'scheduledTaskCount':[],'openTaskId':[],'openName':[],'openTaskStatus':[],'openNoofAttempts':[],'openTaskCount':[],'missTaskId':[],'missName':[],'missTaskStatus':[],'missNoofAttempts':[],'missTaskCount':[],'medicationTooltipCount':[],'encounterTooltipCount':[],'openTooltipCount':[],'completeTooltipCount':[],'scheduledTooltipCount':[],'missedTooltipCount':[],'closedTaskCompletionDate':[],'datePeriod':scope.changedDate,'strengthUnit':[],'opclass':[],'mdclass':[],'edclass':[],'seclass':[],'cmclass':[],'miclass':[], 'openManagedPopulation':[], 'scheduledManagedPopulation':[], 'closedManagedPopulation':[], 'missedManagedPopulation':[], 'dataSource':[], 'quantityDispensed':[], 'prescribedDate':[]});
              }
              if(!angular.equals(moment(scope.dataset[scope.dataset.length-1].date).format('YYYY-MM'),moment(scope.searchData.toDate).format('YYYY-MM')) && ( moment(scope.searchData.fromDate).format('MM') !== moment(scope.searchData.toDate).format('MM') ) ){
                d1=moment(scope.searchData.toDate).format('MM/DD/YYYY').split('/');
                scope.dataset.push({date:d1[0] + '/' + '01' + '/' + d1[2]});
                scope.ResultData.push({'rowindex':scope.ResultData[scope.ResultData.length-1].rowindex+1 ,'MedicationId':[],'drugName':[],'dateFilled':[],'dosageName':[],'daysSupply':[],'medicationProviderName':[],'specialityName':[],'medicationdateTaken':[],'medicationdate':[],'endateTaken':[],'endate':[],'cldateTaken':[],'cldate':[],'scdateTaken':[],'scdate':[],'opdateTaken':[],'opdate':[],'midateTaken':[],'midate':[],'isMedication':false,'medicationCount':[],'isEncounters':false,'isOpenTasks':false,'isscheduleTasks':false,'isCompleteTask':false,'isMissedOpportunity':false,'enCounterId':[],'encounter':[],'encounterProviderName':[],'enproviderSpeciality':[],'encounterCount':[],'closedTaskId':[],'closedName':[],'closedTaskStatus':[],'closedNoofAttempts':[],'closedTaskCount':[],'scheduledTaskId':[],'scheduledName':[],'scheduledTaskStatus':[],'scheduledNoofAttempts':[],'scheduledTaskCount':[],'openTaskId':[],'openName':[],'openTaskStatus':[],'openNoofAttempts':[],'openTaskCount':[],'missTaskId':[],'missName':[],'missTaskStatus':[],'missNoofAttempts':[],'missTaskCount':[],'medicationTooltipCount':[],'encounterTooltipCount':[],'openTooltipCount':[],'completeTooltipCount':[],'scheduledTooltipCount':[],'missedTooltipCount':[],'closedTaskCompletionDate':[],'datePeriod':d1[2]+'-'+d1[0]+'-'+scope.date.split('/')[1],'strengthUnit':[],'opclass':[],'mdclass':[],'edclass':[],'seclass':[],'cmclass':[],'miclass':[], 'openManagedPopulation':[], 'scheduledManagedPopulation':[], 'closedManagedPopulation':[], 'missedManagedPopulation':[], 'dataSource':[], 'quantityDispensed':[], 'prescribedDate':[]});
              }
              var medication;
              var encounterData;
              var patientTasks;
              if(id !== 1){
                var from = (moment(scope.searchData.fromDate).format('YYYY-MM-DD'));
                var to = (moment(scope.searchData.toDate).format('YYYY-MM-DD'));
                medication = _.filter(scope.medicationsData,function(node){
                  return(moment(node.dateTaken).format('YYYY-MM-DD') >= from && moment(node.dateTaken).format('YYYY-MM-DD') <= to );
                });
                encounterData = _.filter(scope.encounterData,function(node){
                  return(moment(node.dateTaken).format('YYYY-MM-DD') >= from && moment(node.dateTaken).format('YYYY-MM-DD') <= to );
                });
                patientTasks = _.filter(scope.patientTasks,function(node){
                  return(moment(node.dateTaken).format('YYYY-MM-DD') >= from && moment(node.dateTaken).format('YYYY-MM-DD') <= to );
                });
              }
              else{
                medication = scope.medicationsData;
                encounterData = scope.encounterData;
                patientTasks = scope.patientTasks;
              }
              var md = 0,op = 0,mi = 0,sc = 0,cl = 0,ed = 0;
              scope.currentDateLine = 0;
              medication.forEach(function(item){
                var index = _.filter(scope.ResultData,function(node){
                  return (moment(node.datePeriod).format('MMM YYYY') === item.datePeriod);
                });
                index = scope.ResultData.indexOf(index[0]);
                if(item.drugDate === scope.date && op === 0  && mi === 0  && sc === 0  && cl === 0  && md === 0  && ed === 0){
                  md = 1;
                  scope.currentDateLine = 1;
                  scope.ResultData[index].mdclass.push('current-date-l');
                }
                else{
                  scope.ResultData[index].mdclass.push('');
                }
                scope.ResultData[index].MedicationId.push({date:item.dateTaken, name: item.userDrugId});
                scope.ResultData[index].medicationdateTaken.push(item.dateTaken);
                scope.ResultData[index].medicationdate.push({date:item.dateTaken, name: item.drugDate});
                scope.ResultData[index].drugName.push({date:item.dateTaken, name: item.drugName});
                scope.ResultData[index].dosageName.push({date:item.dateTaken, name: item.dosageName});
                scope.ResultData[index].daysSupply.push({date:item.dateTaken, name: item.daysSupply});
                scope.ResultData[index].medicationProviderName.push({date:item.dateTaken, name: item.providerName});
                scope.ResultData[index].dateFilled.push({date:item.dateTaken, name: item.dateFilled});
                scope.ResultData[index].specialityName.push({date:item.dateTaken, name: item.specialityName});
                scope.ResultData[index].strengthUnit.push({date:item.dateTaken, name: item.strengthUnit});
                scope.ResultData[index].dataSource.push({date:item.dateTaken, name: item.dataSource});
                scope.ResultData[index].prescribedDate.push({date:item.dateTaken, name: item.prescribedDate});
                scope.ResultData[index].quantityDispensed.push({date:item.dateTaken, name: item.quantityDispensed});
                scope.ResultData[index].isMedication = true;
                scope.ResultData[index].medicationCount.push({date:item.dateTaken, name: scope.ResultData[index].medicationCount.length+1});
              });
              encounterData.forEach(function(item){

                var index = _.filter(scope.ResultData,function(node){
                  return (moment(node.datePeriod).format('MMM YYYY') === item.datePeriod);
                });
                index = scope.ResultData.indexOf(index[0]);
                if(item.encounterDate === scope.date && op === 0  && mi === 0  && sc === 0  && cl === 0  && md === 0  && ed === 0){
                  ed = 1;
                  scope.currentDateLine = 1;
                  scope.ResultData[index].edclass.push('current-date-l');
                }
                else{
                  scope.ResultData[index].edclass.push('');
                }
                scope.ResultData[index].enCounterId.push({date:item.dateTaken, name: item.userEncounterId});
                scope.ResultData[index].endate.push({date:item.dateTaken, name: item.encounterDate});
                scope.ResultData[index].endateTaken.push(item.dateTaken);
                scope.ResultData[index].encounter.push({date:item.dateTaken, name: item.encounter});
                scope.ResultData[index].encounterProviderName.push({date:item.dateTaken, name: item.providerName});
                scope.ResultData[index].enproviderSpeciality.push({date:item.dateTaken, name: item.providerSpeciality});
                scope.ResultData[index].encounterCount.push({date:item.dateTaken, name: scope.ResultData[index].encounterCount.length+1});
                scope.ResultData[index].isEncounters = true;
              });

              patientTasks.forEach(function(item){
                var taskProviderName = _.filter(scope.patientTasksLv, function (node) {
                  return (node.taskId === item.taskId);
                });
                if(taskProviderName.length > 0){
                  item.name = angular.equals(taskProviderName[0].providerName,null)? item.name : ( taskProviderName[0].providerName + ':' + item.name);
                }
                var index = _.filter(scope.ResultData,function(node){
                  return (moment(node.datePeriod).format('MMM YYYY') === item.datePeriod);
                });
                index = scope.ResultData.indexOf(index[0]);
                switch(item.status){
                  case 'Closed Complete':
                    if(item.taskDate === scope.date && op === 0  && mi === 0  && sc === 0  && cl === 0  && md === 0  && ed === 0){
                      cl = 1;
                      scope.currentDateLine = 1;
                      scope.ResultData[index].cmclass.push('current-date-l');
                    }
                    else{
                      scope.ResultData[index].cmclass.push('');
                    }
                    scope.ResultData[index].closedTaskId.push({date:item.dateTaken, name: item.taskId});
                    scope.ResultData[index].closedName.push({date:item.dateTaken, name: item.name});
                    scope.ResultData[index].cldateTaken.push(item.dateTaken);
                    scope.ResultData[index].cldate.push({date:item.dateTaken, name: item.taskDate});
                    scope.ResultData[index].closedTaskStatus.push({date:item.dateTaken, name: item.taskStatus});
                    scope.ResultData[index].closedNoofAttempts.push({date:item.dateTaken, name: item.noofAttempts});
                    scope.ResultData[index].closedTaskCount.push({date:item.dateTaken, name: scope.ResultData[index].closedTaskCount.length+1});
                    scope.ResultData[index].isCompleteTask = true;
                    scope.ResultData[index].closedTaskCompletionDate.push({date:item.dateTaken, name: item.taskCompletionDate});
                    scope.ResultData[index].closedManagedPopulation.push({date:item.dateTaken, name: item.programName});
                    break;
                  case 'Scheduled' :
                    if(item.taskDate === scope.date && op === 0  && mi === 0  && sc === 0  && cl === 0  && md === 0  && ed === 0){
                      sc=1;
                      scope.currentDateLine = 1;
                      scope.ResultData[index].seclass.push('current-date-l');
                    }
                    else{
                      scope.ResultData[index].seclass.push('');
                    }
                    scope.ResultData[index].scheduledTaskId.push({date:item.dateTaken, name: item.taskId});
                    scope.ResultData[index].scheduledName.push({date:item.dateTaken, name: item.name});
                    scope.ResultData[index].scdateTaken.push(item.dateTaken);
                    scope.ResultData[index].scdate.push({date:item.dateTaken, name: item.taskDate});
                    scope.ResultData[index].scheduledTaskStatus.push({date:item.dateTaken, name: item.taskStatus});
                    scope.ResultData[index].scheduledNoofAttempts.push({date:item.dateTaken, name: item.noofAttempts});
                    scope.ResultData[index].scheduledTaskCount.push({date:item.dateTaken, name: scope.ResultData[index].scheduledTaskCount.length+1});
                    scope.ResultData[index].isscheduleTasks = true;
                    scope.ResultData[index].scheduledManagedPopulation.push({date:item.dateTaken, name: item.programName});
                    break;
                  case 'Open' :
                    if(item.taskDate === scope.date && op === 0  && mi === 0  && sc === 0  && cl === 0  && md === 0  && ed === 0){
                      op=1;
                      scope.currentDateLine = 1;
                      scope.ResultData[index].opclass.push('current-date-l');
                    }
                    else{
                      scope.ResultData[index].opclass.push('');
                    }
                    scope.ResultData[index].openTaskId.push({date:item.dateTaken, name: item.taskId});
                    scope.ResultData[index].openName.push({date:item.dateTaken, name: item.name});
                    scope.ResultData[index].opdateTaken.push(item.dateTaken);
                    scope.ResultData[index].opdate.push({date:item.dateTaken, name: item.taskDate});
                    scope.ResultData[index].openTaskStatus.push({date:item.dateTaken, name: item.taskStatus});
                    scope.ResultData[index].openNoofAttempts.push({date:item.dateTaken, name:item.noofAttempts});
                    scope.ResultData[index].openTaskCount.push({date:item.dateTaken, name:scope.ResultData[index].openTaskCount.length+1});
                    scope.ResultData[index].isOpenTasks = true;
                    scope.ResultData[index].openManagedPopulation.push({date:item.dateTaken, name: item.programName});
                    break;
                  case 'Care Gap' :
                    if(item.taskDate === scope.date && op === 0  && mi === 0  && sc === 0  && cl === 0  && md === 0  && ed === 0){
                      mi=1;
                      scope.currentDateLine = 1;
                      scope.ResultData[index].miclass.push('current-date-l');
                    }
                    else{
                      scope.ResultData[index].miclass.push('');
                    }
                    scope.ResultData[index].missTaskId.push({date:item.dateTaken, name:item.taskId});
                    scope.ResultData[index].missName.push({date:item.dateTaken, name:item.name});
                    scope.ResultData[index].midateTaken.push(item.dateTaken);
                    scope.ResultData[index].midate.push({date:item.dateTaken, name:item.taskDate});
                    scope.ResultData[index].missTaskStatus.push({date:item.dateTaken, name:item.taskStatus});
                    scope.ResultData[index].missNoofAttempts.push({date:item.dateTaken, name:item.noofAttempts});
                    scope.ResultData[index].missTaskCount.push({date:item.dateTaken, name:scope.ResultData[index].missTaskCount.length+1});
                    scope.ResultData[index].isMissedOpportunity = true;
                    scope.ResultData[index].missedManagedPopulation.push({date:item.dateTaken, name: item.programName});
                    break;
                }
              });
              scope.ResultData = _.sortBy(scope.ResultData,'datePeriod');

              scope.graphxaxisData = [];
              scope.graphxaxisData.push({'date':scope.searchData.fromDate},{'date':scope.searchData.toDate});
              if(scope.hideEncounter === 'Show Encounters'){
                scope.hideEncounter = 'Hide Encounters';
                scope.hideEncounters();
              }
              if(scope.hideMedication === 'Show Medications'){
                scope.hideMedication = 'Hide Medications';
                scope.hidemedications();
              }
            };
            scope.ChartWidthsliderDates = function(data){
              var width = data.length;
              width = (100/width) + '%';
              return {'width' : width,'left' : (100/data.length)*10 + '%'};
            };

            scope.ChartWidthxaxis = function(data,index){
              var width;
              scope.months = [{id:'31',name:'01'},{id:moment(scope.ResultData[index].datePeriod.split('-')[0]+'-'+'02').endOf('month').format('DD'),name:'02'},{id:'31',name:'03'},{id:'30',name:'04'},{id:'31',name:'05'},{id:'30',name:'06'},{id:'31',name:'07'},{id:'31',name:'08'},{id:'30',name:'09'},{id:'31',name:'10'},{id:'30',name:'11'},{id:'31',name:'12'}];

              if(angular.equals(index,0) && !angular.equals(scope.ResultData.length,1) ){
                var count;
                scope.months.forEach(function(item){
                  if(item.name === scope.ResultData[index].datePeriod.split('-')[1]){
                    count = item.id;
                  }
                });
                width = (100/data.length);
                width = (width*(Number(scope.ResultData[index].datePeriod.split('-')[2])))/(Number(count)) + '%';
              }
              else{
                width = (100/data.length) + '%';
              }
              return {'width':width};
            };

            scope.medicationChartWidth = function(count){
              scope.medicationWidthCount = scope.medicationWidthCount+1;
              var width = (scope.mainWidth/count.length) + '%';
              return {'width':width,'position': 'absolute', 'top':'1px', 'left': (scope.medicationWidthCount*(scope.mainWidth/count.length))+'%'};
            };

            scope.encountersChartWidth = function(count){
              scope.enconterWidthCount = scope.enconterWidthCount + 1;
              var width = (scope.mainWidth/count.length) + '%';
              return {'width':width,'position': 'absolute', 'top':'1px', 'left':  (scope.enconterWidthCount*(scope.mainWidth/count.length))+'%'};
            };

            scope.opentasksChartWidth = function(count){
              scope.opentasksWidthCount = scope.opentasksWidthCount + 1;
              var width = (scope.mainWidth/count.length) + '%';
              return {'width':width,'position': 'absolute', 'top':'1px', 'left':  (scope.opentasksWidthCount*(scope.mainWidth/count.length))+'%'};
            };

            scope.scheduleTasksChartWidth = function(count){
              scope.scheduleTaskssWidthcount = scope.scheduleTaskssWidthcount+1;
              var width = (scope.mainWidth/count.length) + '%';
              return {'width':width,'position': 'absolute', 'top':'1px', 'left': (scope.scheduleTaskssWidthcount*(scope.mainWidth/count.length))+'%'};
            };

            scope.completeTasksChartWidth = function(count){
              scope.completetaskWidthCount = scope.completetaskWidthCount + 1;
              var width = (scope.mainWidth/count.length)+'%';
              return {'width':width,'position': 'absolute', 'top':'1px', 'left': (scope.completetaskWidthCount*(scope.mainWidth/count.length))+'%'};
            };

            scope.missedOpertunitiesChartWidth=function(count){
              scope.missedOpportunitiesWidthCount=scope.missedOpportunitiesWidthCount+1;
              var width=(scope.mainWidth/count.length)+'%';
              return {'width':width,'position': 'absolute', 'top':'1px', 'left': (scope.missedOpportunitiesWidthCount*(scope.mainWidth/count.length))+'%'};
            };
            scope.selectedMeasures = [];
            scope.isVisible = false;
            scope.toggleSelect = function(){
              scope.isVisible = (scope.isVisible===true?false:true);
            };

            scope.isChecked = function(item){
              if(scope.selectedMeasures.indexOf(item) !== -1){
                return true;
              }
              return false;
            };

            scope.toggleCheck = function(data,id){
              scope.isVisible = true;
              if(!angular.equals(id,1)){
                if(!scope.isChecked(data)){
                  scope.selectedMeasures.push(data);
                  scope.measueres[scope.measueres.indexOf(data)].selected = true;
                }else{
                  scope.selectedMeasures.splice(scope.selectedMeasures.indexOf(data), 1);
                  scope.measueres[scope.measueres.indexOf(data)].selected = false;

                }
              }
              scope.selectedClinicalResultscount = scope.selectedMeasures.length;
              scope.measureNames = null;
              scope.selectedMeasures.forEach(function(item){
                scope.measureNames=scope.measureNames === null?item.measureName:scope.measureNames + ',' + item.measureName;
              });
              if(!angular.equals(scope.firstValue,null) &&  !(angular.equals(scope.secondVale))){
                scope.searchData = scope.selectedMeasures.length>0?{'fromDate': scope.firstValue, 'toDate':angular.equals(moment(d2).format('YYYY-MM-DD'),scope.secondVale)?moment(scope.currentDate).add('months', scope.to).format('YYYY-MM-DD'):scope.secondVale,'measureName':scope.measureNames}:{'fromDate': moment(scope.currentDate).add('months', scope.from).format('YYYY-MM-DD'), 'toDate':angular.equals(moment(d2).format('YYYY-MM-DD'),scope.secondValue)?moment(scope.currentDate).add('months', scope.to).format('YYYY-MM-DD'):scope.secondValue,'measureName':[{'name':''}]};
              }
              else
              {
                scope.searchData = scope.selectedMeasures.length>0?{'fromDate': moment(scope.currentDate).add('months', scope.from).format('YYYY-MM-DD'), 'toDate': moment(scope.currentDate).add('months', scope.to).format('YYYY-MM-DD'),'measureName':scope.measureNames}:{'fromDate': moment(scope.currentDate).add('months', scope.from).format('YYYY-MM-DD'), 'toDate': moment(scope.currentDate).add('months', scope.to).format('YYYY-MM-DD'),'measureName':[{'name':''}]};
              }
              d1 = moment(scope.searchData.fromDate);
              d2 = moment(scope.searchData.toDate);
              scope.endRange = moment.duration(d2.diff(d1)).asDays();
              scope.bindData(scope.searchData,1);

            };

            scope.fromData = function(name){
              scope.from = name;
              scope.measureNames = null;
              scope.selectedMeasures.forEach(function(item){
                scope.measureNames = scope.measureNames === null?item.measureName:scope.measureNames + ',' + item.measureName;
              });
              scope.searchData=scope.selectedMeasures.length > 0 ?{'fromDate': moment(scope.currentDate).add('months', scope.from).format('YYYY-MM-DD'), 'toDate': moment(scope.currentDate).add('months', scope.to).format('YYYY-MM-DD'),'measureName':scope.measureNames}:{'fromDate': moment(scope.currentDate).add('months', scope.from).format('YYYY-MM-DD'), 'toDate': moment(scope.currentDate).add('months', scope.to).format('YYYY-MM-DD')};
              d1 = moment(scope.searchData.fromDate);
              d2 = moment(scope.searchData.toDate);
              scope.endRange = moment.duration(d2.diff(d1)).asDays();
              scope.sliderDates = {from:moment(scope.searchData.fromDate).format('MM/DD/YYYY'),to:moment(scope.searchData.toDate).format('MM/DD/YYYY')};
              scope.bindData(scope.searchData,2);
            };

            scope.toData = function(name){
              scope.to = name;
              scope.measureNames = null;
              scope.selectedMeasures.forEach(function(item){
                scope.measureNames = scope.measureNames === null?item.measureName:scope.measureNames + ',' + item.measureName;
              });
              scope.searchData = scope.selectedMeasures.length > 0?{'fromDate': moment(scope.currentDate).add('months', scope.from).format('YYYY-MM-DD'), 'toDate': moment(scope.currentDate).add('months', scope.to).format('YYYY-MM-DD'),'measureName':scope.measureNames}:{'fromDate': moment(scope.currentDate).add('months', scope.from).format('YYYY-MM-DD'), 'toDate': moment(scope.currentDate).add('months', scope.to).format('YYYY-MM-DD')};
              d1 = moment(scope.searchData.fromDate);
              d2 = moment(scope.searchData.toDate);
              scope.sliderDates = {from:moment(scope.searchData.fromDate).format('MM/DD/YYYY'),to:moment(scope.searchData.toDate).format('MM/DD/YYYY')};
              scope.endRange = moment.duration(d2.diff(d1)).asDays();
              scope.bindData(scope.searchData,2);
            };

            scope.hideEncounter = 'Hide Encounters';
            scope.hideMedication = 'Hide Medications';
            scope.hideEncounters = function(){
              if(scope.hideEncounter === 'Hide Encounters'){
                scope.ResultData.forEach(function(item){
                  if(item.isEncounters === true){
                    scope.encounterResultSet.push(scope.ResultData.indexOf(item));
                  }
                  item.isEncounters = false;
                });
              }
              else{
                scope.encounterResultSet.forEach(function(item){
                  scope.ResultData[item].isEncounters = true;
                });
              }
              scope.hideEncounter = scope.hideEncounter === 'Hide Encounters'?'Show Encounters':'Hide Encounters';
            };

            scope.hidemedications = function(){
              if(scope.hideMedication === 'Hide Medications'){
                scope.medicationResultSet=[];
                scope.ResultData.forEach(function(item){
                  if(item.isMedication === true){
                    scope.medicationResultSet.push(scope.ResultData.indexOf(item));
                  }
                  item.isMedication = false;
                });
              }
              else{
                scope.medicationResultSet.forEach(function(item){
                  scope.ResultData[item].isMedication = true;
                });
              }
              scope.hideMedication = scope.hideMedication === 'Hide Medications'?'Show Medications':'Hide Medications';
            };

            scope.heightCurrentDate = function(){
              return scope.ResultData.length > 3 ?{'left':'-'+(scope.mainWidth+70) + '%'}:scope.ResultData.length === 3?{'left':'-'+(scope.mainWidth+63)+'%'}:scope.ResultData.length === 2?{'left' : '-' + (scope.mainWidth+48)+'%'}:{'left' : '-' + (scope.mainWidth-2)+'%'};
            };
            scope.hideclinics = function(){
              scope.isVisible = false;
            };
            scope.showclinics = function(){
              scope.isVisible = true;
            };
            scope.lineWidthxaxis = function(data){
              var width = (100/data.length);
              return (data.length === 1)? {'left':(1) + '%'} : (data.length >= 2 && data.length <= 4 )?{'left':(7) + '%'}: (data.length >= 5 && data.length <= 7 )?{'left' : (width) + '%'} : (data.length > 7 && data.length <= 14)?{'left' : (width) + 30 + '%'}:(data.length > 14 && data.length <= 25)?{'left' : (width) + 20 + '%'}:(data.length > 25 && data.length <= 36) ?{'left' : (width) - 10 + '%'}:{'left' : (width) - 5 + '%'};
            };
            scope.bindData(scope.searchData,0);
          }]);

  }(window.app));