/**
 * @author michael.ash
 */
(
  function (app) {
      /* @fmt: off */
      'use strict';
      // @fmt:on
      app.controller('clinicalCtrl', ['$scope','$http','PatientData',
        function (scope,$http,patientData) {
            scope.ClinicalData=[];
            $http.get(app.api.root+'patients/'+patientData.id+'/clinical-results')
                .success(function (data) {
                    scope.ClinicalData=data.results;
                  });

            scope.columnsSelected = [{ field: 'measureName', displayName: 'Name', columnClass: 'table-column-name' }, { field: 'measureValue', displayName: 'Value', columnClass: 'table-column-status' }, { field: 'measureDate', displayName: 'Value Date', columnClass: 'table-column-date' }, { field: 'action', displayName: 'Chart', columnClass: 'table-column-action', sortable: false }];

            scope.filterOptions = {
                filterText: '',
                useExternalFilter: true
              };
            scope.totalServerItems = 0;
            scope.pageTitle = 'Clinical Results';

            scope.ShowChart = function (measureid){
                scope.MeasureID=measureid.loincCodeId;
                scope.MeasureName=measureid.measureName;
                scope.loincCodeId=measureid.loincCodeId;
                $http.get(app.api.root+'patients/'+patientData.id+'/clinical-results/'+scope.MeasureID)
                    .success(function (data) {
                        scope.PopulateChart(data.results);
                      });
              };

            scope.CloseChart=function(){
              scope.popup = false;
            };

            scope.PopulateChart = function(chartresult){
              var ClinicalChartResults=[];
              chartresult.forEach(function(data){
                var ineach=[new Date(data.dateTaken),data.measureValue];
                ClinicalChartResults.push(ineach);
              });
              scope.chartdata=[{'key': '','values':ClinicalChartResults}];
              scope.xAxisTickFormatFunction = function(){
                return function(d){
                    var xTicks = d3.select('.nv-x.nv-axis > g').selectAll('g');
                    xTicks.selectAll('text').attr('transform', function() { return 'translate (-10, 25) rotate(-60 0,0)'; });
                    return d3.time.format('%x')(new Date(d));
                  };
              };

              scope.yaxisToolTipFunction = function() {
                  return function(d){
                    return d.event.pageY;
                  };
                };
              scope.popup = true;
            };

            scope.toolTipContentFunction = function(){
              return function(key, x, y) {
                return  '<p class=\'clinical-result-chart-tooltip\'>' +  y +' at ' + x + '</p>';
              };
            };

            var format = d3.format(',.4f');
            scope.valueFormatFunction = function(){
              return function(d){
                return format(d);
              };
            };
            scope.CloseAlert=function(){
              scope.isError = false;
            };

          }]);
    }(window.app));
