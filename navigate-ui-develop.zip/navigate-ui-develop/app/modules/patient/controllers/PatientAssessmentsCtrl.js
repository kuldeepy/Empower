(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('AssessmentCtrl', ['$scope', '$timeout', 'PatientData', '$window', 'patientAssessmentSvc', 'authSvc', 'navConstantsSvc','$location', 'userConcurrentLockSvc',
    function (scope, $timeout, patientData, $window, patientAssessmentSvc, authSvc, navConstantsSvc,location, userConcurrentLockSvc) {
      scope.popup = false;
      scope.AssessmentScorelist = [];
      scope.AssessmentScorelistComplete = [];
      scope.AssessmenthistoryPage = 1;
      scope.AssessmenthistoryPageSize = 5;
      scope.hasEditAccess = authSvc.hasEditAccess();
      scope.pageTitle = 'Assessment Details';
      scope.isOpenClicked = true;
      scope.assessmentHistoryGridColumns = [
        {
          field: 'taskCompletedDate',
          displayName: 'Date Completed',
        },
        {
          field: 'completedBy',
          displayName: 'Completed by'
        },
        {
          field: 'dateDue',
          displayName: 'Due Date'
        },
        {
          field: 'scoreRange',
          displayName: 'Score'
        },
        {
          field: 'action',
          displayName: 'Action'
        }
      ];

      scope.openCompletedAssessment = function(){
        if(localStorage.getItem('alert')){
          var message = JSON.parse(localStorage.getItem('alert'));
          scope.showAlert(message.alertmessage,message.alerttype);
          localStorage.removeItem('alert');
        }

      };
      scope.HistoryPopup = false;
      scope.openHistoryPopup = function(obj){
          patientAssessmentSvc.getPatientPastAssessments(patientData.id,obj.entity.assessmentId).then(function (response) {
            scope.Assessmenthistory = response.data.results;
            scope.HistoryPopup = true;
          });
        };
      scope.closeCompleteHistoryPopup = function(){
        scope.HistoryPopup = false;
      };
      scope.getAssessmentsScores = function () {
        patientAssessmentSvc.getPatientOpenAssessments(patientData.id).then(function (response) {
          response.data.results.forEach(function (AssessmentData) {
            AssessmentData.dateDue = AssessmentData.dateDue !== null ? moment(AssessmentData.dateDue).format('L') : AssessmentData.dateDue;
            AssessmentData.dateTaken = AssessmentData.dateTaken !== null ? moment(AssessmentData.dateTaken).format('L') : AssessmentData.dateTaken;
            AssessmentData.scoreRange = (AssessmentData.scoreRange !== null && AssessmentData.scoreRange !== 0) ? AssessmentData.scoreRange : 'N/A';
            if(AssessmentData.daysLate === 0){
              AssessmentData.status = 'Today';
            }else if(AssessmentData.daysLate < 0){
              AssessmentData.status = 'Future';
            }else if(AssessmentData.daysLate > 0){
              AssessmentData.status = 'Past Due';
            }
          });
          scope.AssessmentScorelist = response.data.results;
          scope.getPagedDataAsync(scope.pagingOptions.pageSize, scope.pagingOptions.currentPage);
        });
        patientAssessmentSvc.getPatientClosedAssessments(patientData.id).then(function (response) {
          response.data.results.forEach(function (AssessmentData) {
            AssessmentData.dateDue = AssessmentData.dateDue !== null ? moment(AssessmentData.dateDue).format('L') : AssessmentData.dateDue;
            AssessmentData.dateTaken = AssessmentData.dateTaken !== null ? moment(AssessmentData.dateTaken).format('L') : AssessmentData.dateTaken;
            AssessmentData.scoreRange = (AssessmentData.scoreRange !== null && AssessmentData.scoreRange !== 0) ? AssessmentData.scoreRange : 'N/A';
          });
          scope.AssessmentScorelistComplete = response.data.results;
          scope.openCompletedAssessment();
          scope.getPagedDataAsyncComplete(scope.pagingOptionsComplete.pageSize, scope.pagingOptionsComplete.currentPage);
        });
      };
      scope.getAssessmentsScores();
      scope.filterOptions = {
        filterText : '',
        useExternalFilter : true
      };
      scope.totalServerItemsComplete = 0;
      scope.pagingOptions = {
        pageSizes : [5, 10, 20],
        pageSize : 5,
        currentPage : 1
      };

      scope.pagingOptionsComplete = {
        pageSizes : [5, 10, 20],
        pageSize : 5,
        currentPage : 1
      };
      
      scope.isOpen=true;

      scope.completeTask = function (obj) {
        scope.bindAssessment = obj.entity;
      };

      scope.redirecttoComplete = function(obj){
        obj.entity.page ='/assessements';
        localStorage.setItem('selectedassessment',JSON.stringify(obj.entity));
        location.path(app.currentRoute+'/completion');
      };
      scope.ViewassessmentPage = function(row){
        scope.HistoryPopup = false;
        row.page ='/assessements';
        localStorage.setItem('selectedassessment',JSON.stringify(row));
        location.path(app.currentRoute+'/completion');
      };
      scope.setPagingData = function (data, page, pageSize) {
        var pagedData = data.slice((page - 1) * pageSize, page * pageSize);
        scope.myData = pagedData;
        scope.totalServerItems = data.length;
        if (!scope.$$phase) {
          scope.$apply();
        }
      };
      scope.getPagedDataAsync = function (pageSize, page) {
        setTimeout(function () {
          scope.setPagingData(scope.AssessmentScorelist, page, pageSize);
        }, 100);
      };

      scope.$watch('pagingOptions', function (newVal, oldVal) {
        if (newVal !== oldVal && newVal.currentPage !== oldVal.currentPage) {
          scope.pagingOptions.currentPage = (newVal.currentPage === undefined || newVal.currentPage === null) ? 1 : scope.pagingOptions.currentPage;
          scope.getPagedDataAsync(scope.pagingOptions.pageSize, scope.pagingOptions.currentPage, scope.filterOptions.filterText);
        }
      }, true);
      scope.$watch('filterOptions', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          scope.getPagedDataAsync(scope.pagingOptions.pageSize, scope.pagingOptions.currentPage, scope.filterOptions.filterText);
        }
      }, true);

      scope.$watch('pagingOptionsComplete', function (newVal, oldVal) {
        if (newVal !== oldVal && newVal.currentPage !== oldVal.currentPage) {
          scope.pagingOptionsComplete.currentPage = (newVal.currentPage === undefined || newVal.currentPage === null) ? 1 : scope.pagingOptionsComplete.currentPage;
          scope.getPagedDataAsyncComplete(scope.pagingOptionsComplete.pageSize, scope.pagingOptionsComplete.currentPage, scope.filterOptions.filterText);
        }
      }, true);
      scope.$watch('filterOptionsComplete', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          scope.getPagedDataAsyncComplete(scope.pagingOptionsComplete.pageSize, scope.pagingOptionsComplete.currentPage, scope.filterOptions.filterText);
        }
      }, true);

      scope.setPagingDataComplete = function (data, page, pageSize) {
        var pagedData = data.slice((page - 1) * pageSize, page * pageSize);
        scope.myDataComplete = pagedData;
        scope.totalServerItemsComplete = data.length;
        if (!scope.$$phase) {
          scope.$apply();

        }
      };

      scope.getPagedDataAsyncComplete = function (pageSize, page) {
        setTimeout(function () {
          scope.setPagingDataComplete(scope.AssessmentScorelistComplete, page, pageSize);
        }, 100);
      };

      var templateWithTooltip = '<div class="ngCellText" ng-class="col.colIndex()"><a  ng-mouseover="resetToolTipText(row)"  href="" data="{{row.getProperty(col.headerClass)}}" ng-cell-text tooltip="{{lockedText}}" tooltip-placement="top_large_6ba94f" tooltip-append-to-body="true" ng-click="lockConcurrentTask(row)"><span ng-show="hasEditAccess" class="General-icon_check_6aa84f_30x30"></span></a></div>';
      scope.completeTaskPopup = false;

      scope.AssessmentGrid = {
        data : 'myData',
        multiSelect : false,
        showFooter : true,
        enablePaging : true,
        rowHeight: 45,
        totalServerItems : 'totalServerItems',
        pagingOptions : scope.pagingOptions,
        filterOptions : scope.filterOptions,
        columnDefs : [{
          field : 'assessmentName',
          displayName : 'Name',
          width : '30%'
        },{
          field : 'programName',
          displayName : 'Managed Population',
          width : '30%'
        },
        {
          field : 'status',
          displayName : 'Status',
          width : '8%'
        }, {
          field : 'dateDue',
          displayName : 'Due Date',
          cellTemplate: '<div ng-class="col.colIndex()" class="ngCellText"><span data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field) |date:"MM/dd/yyyy" }}</span></div>',
          width : '10%'
        }, {
          field : 'scoreRange',
          displayName : 'Score',
          width : '6%'
        }, {
          field : 'maxscore',
          displayName : 'Max Score',
          width : '10%'
        }, {
          field : '',
          displayName : 'Action',
          width : '6%',
          cellTemplate:templateWithTooltip
        }]
      };

      scope.AssessmentCompleteGrid = {
        data : 'myDataComplete',
        multiSelect : false,
        showFooter : true,
        enablePaging : true,
        rowHeight: 45,
        totalServerItems : 'totalServerItemsComplete',
        pagingOptions : scope.pagingOptionsComplete,
        filterOptions : scope.filterOptionsComplete,
        columnDefs : [{
          field : 'assessmentName',
          displayName : 'Name',
          width : '25%'
        },{
          field : 'programName',
          displayName : 'Managed Population',
          width : '23%'
        },{
          field : 'taskCompletedDate',
          displayName : 'Date Completed',
          cellTemplate: '<div ng-class="col.colIndex()" class="ngCellText"><span data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field) |date:"MM/dd/yyyy" }}</span><br><span class="btn btn-link" ng-show="row.entity.assessmentCount>1" ng-click="openHistoryPopup(row)" style="font-size:12px;margin-left:-8px;margin-top:-5px;">Past Assessments</span></div>',
          width : '15%'
        },{
          field : 'completedBy',
          displayName : 'Completed By',
          cellTemplate: '<div class="ngCellText"  ng-class="col.colIndex()">'+
          '<span title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</span>'+
          '</div>',
          width : '15%'
        }, {
          field : 'dateDue',
          displayName : 'Due Date',
          cellTemplate: '<div ng-class="col.colIndex()" class="ngCellText"><span data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field) |date:"MM/dd/yyyy" }}</span></div>',
          width : '10%'
        }, {
          field : 'scoreRange',
          displayName : 'Score',
          cellTemplate: '<div class="ngCellText">{{row.getProperty(col.field)}}/{{row.entity.maxscore}}</div>',
          width : '6%'
        }, {
          field : '',
          displayName : 'Action',
          width : '6%',
          cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<span class="General-icon_view_6fa8dc_30x30" ng-click="redirecttoComplete(row)" tooltip= "View {{(row.entity.assessmentName)}}" tooltip-append-to-body="true" ><a href=""  data="{{row.getProperty(col.headerClass)}}" ></a></span>'+
                          '</div>'
        }]
      };


      patientAssessmentSvc.getAssessments('assessments').then(function (response) {
        scope.Questionnaire = response.data.results;
      });

      //does't have to call this If User does not have add/edit access
      if(scope.hasEditAccess){
				patientAssessmentSvc.getManagedPopulations('patients/' + patientData.id + '/patient-populations?type=populations').then(function (response) {
					scope.ManagedPopulation = response.data.results;
				});
			}

      scope.ShowAssessmentPopup = function () {
          scope.popupAction('addAssessment', 'show');
          scope.AssessmentSelectedItems = [];
        };

        //class Name For PopUp
      scope.popupAction = function (className, action) {
        scope.AddAssessment.$setPristine();
        if (action === 'show') {
          $('.' + className + '').modal({
            backdrop: 'static',
            keyboard: false
          });
        } else {
          $('.' + className + '').modal('' + action + '');
        }
      };
      scope.InsertAssessment = function (AssessmentSelectedItems) {
        var date = AssessmentSelectedItems.DueDate;
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        if (month < 10) {
          month = '0' + month;
        }
        var day = date.getDate();
        var DueDate = month + '/' + day + '/' + year;
        scope.AssInsertionData = {
          'assessmentId' : AssessmentSelectedItems.assessmentId,
          'dateDue' : DueDate,
          'managedPopulationId' : AssessmentSelectedItems.populationId
        };
        var requestpath = 'patients/' + patientData.id + '/assessments';
        patientAssessmentSvc.saveAssessment(requestpath, scope.AssInsertionData).success(function (response) {
          if (response.results.patientAssessmentId !== -1) {
            scope.popupAction('addAssessment', 'hide');
            scope.getAssessmentsScores();
            patientData.isMenuDirty = true;
            scope.showAlert('Assessment has been added successfully.', 'alert-success');
          } else {
            scope.showAlert('Insertion failed either because of duplicate record or problem in connection, please try again', 'alert-error');
          }
        }).error(function (errorMessage) {
          scope.setErrorNotification = errorMessage.message;
        });
      };
      scope.ReShowAssessment = function () {
        scope.clickaddnew();
      };

      scope.CancelAssessment = function (calssName) {
          scope.notificationVisible = 'close';
          scope.popupAction(calssName, 'hide');
        };

      scope.showAlert = function (alertmessage, alerttype) {
        window.scrollTo(0, 0);
        scope.alertMessageStyle = alerttype;
        scope.alertMessage = alertmessage;
        scope.isError = true;
        $timeout(function () {
          scope.isError = false;
        }, 6000);
      };

      scope.CloseAlert = function () {
        scope.isError = false;
      };

      scope.open = function ($event) {
          $event.preventDefault();
          $event.stopPropagation();
          if(scope.AssessmentSelectedItems.DueDate === undefined) {
            scope.AssessmentSelectedItems.DueDate = new Date();
          }
          scope.opened = true;
        };

      scope.toggleMin = function () {
          scope.minDate = scope.minDate ? null : new Date();
        };

      scope.toggleMin();

      scope.disabled = function (date, mode) {
          return (mode === 'day' && (date.getDay() === 7));
        };

      scope.closeModal = function (className) {
          $('.' + className + '').modal('hide');
        };

      scope.closeAssessemtModel = function () {
          scope.closeModal('cancelConfirm', 'hide');
          scope.closeModal('openTaskPopUp', 'hide');
          scope.unlockConcurrentTask();
        };

      scope.saveAssessmentSurvey = function (type) {
          scope.addAssessment = type;
        };

      scope.unlockConcurrentTask = function() {
        scope.data={'lockType':'task'};
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(){
            scope.isLocked = false;
          });
      };

      scope.lockConcurrentTask = function(task){
        scope.taskData={'taskId':task.entity.taskId,'lockType':'task','isLocked': true};
        userConcurrentLockSvc.putLockConcurrentTask(scope.taskData).then(function(response){
            scope.status=response.data.results.status;
            if(scope.status === true){
              scope.lockedText = 'Complete '+task.entity.assessmentName;
              scope.redirecttoComplete(task);
            }
            else{
              scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName',response.data.results.name);
            }
          });
      };
      
      scope.resetToolTipText=function(task){
        scope.lockedText = 'Complete '+task.entity.assessmentName;
      };

      scope.unlockConcurrentTask();
    }]);
  }(window.app));
