(function (app) {
  /* @fmt: off */
  'use strict';
  // @fmt:on

  app.controller('PopulationManagementCtrl', ['$scope', '$http', 'PatientData','_','authSvc','populationManagementSvc','navConstantsSvc','$modal', 'userConcurrentLockSvc',
  function (scope, http, patientData, _, authSvc, populationManagementSvc, navConstantsSvc, $modal, userConcurrentLockSvc) {
    scope.pageTitle = 'Managed Population';
    scope.populations = [];
    scope.confirmManagedPopulationMessage = 'Are you sure you want to dis-enroll the patient from the Managed Population? All the open and scheduled tasks from this Managed Population will be marked as missed opportunity.';
    scope.disenrollmentMessage = 'Reason for Disenrollment *';
    scope.disenrollment = {};
    scope.pendingEnrollment = {};
    scope.page = 1;
    scope.pageSize = 5;
    scope.popPage = 1;
    scope.popPageSize = 5;
    scope.popup = false;
    scope.isopen = true;
    scope.showNotification = false;
    scope.hasEditAccess = authSvc.hasEditAccess();
    scope.allPatientsManagedPopulation = navConstantsSvc.allPatientsManagedPopulation;
    scope.notification = {visible: false,message: ''};
    scope.pendingListColumnsSelected = [{ field: 'programName', displayName: 'Managed Population', columnClass: 'table-column-name' ,sortable : false},
                            { field: 'qualifieddate', displayName: 'Qualified date', columnClass: 'table-column-duedate' ,sortable : false},
                            { field: 'careLead', displayName: 'Care Lead', columnClass: 'table-column-name' ,sortable : false },
                            { field: 'careTeamName', displayName: 'Care Team', columnClass: 'table-column-name',sortable : false }];

    scope.getPopulations = function (id) {
      populationManagementSvc.getPatientPopulations(id)
        .then(function (response) {
          var results = response.data.results;
          scope.populations = _.sortBy(results,'enrollmentStartDate').reverse();
          scope.recordCount = results.length;
        });
      populationManagementSvc.getPatientPopulationsByType(id,'I')
        .then(function (response) {
          scope.disenrolledPopulations = response.data.results;
        });
      populationManagementSvc.getPatientPopulationsByType(id,'P')
        .then(function (response) {
          scope.pendingEnrollment = response.data.results;
        });
    };

    scope.getPopulationList = function (){
      scope.populationListExceptEnrolls = [];
      return populationManagementSvc.getPopulations()
        .then (function (response){
          var results = response.data.results;
          scope.populationList = results;
          _.forEach(scope.populationList, function(items){
            var exists = false;
            _.forEach(scope.populations, function(selectedPopulations){
                if (items.id === selectedPopulations.populationId) {
                  exists = true;
                }
              });
            _.forEach(scope.pendingEnrollment, function(pendingPopulations){
                if (items.id === pendingPopulations.programId) {
                  exists = true;
                }
              });
            if (exists === false) {
              scope.populationListExceptEnrolls.push(items);
            }
          });
          scope.populationList=scope.populationListExceptEnrolls;
        });
    };

    scope.getPopulations(patientData.id);

    scope.isEnrolledInPopulation = function(pop) {
      var enrolledPopulationIds = _.pluck(scope.populations, 'populationId');
      return _.contains(enrolledPopulationIds, pop.populationId);
    };

    scope.addPopulation = function (id, dataToAdd) {
      populationManagementSvc.addPopulation(id, dataToAdd)
        .then(function () {
          scope.popup = false;
          scope.showAlert('Patient has been enrolled in Managed Population successfully.','alert-success');
          scope.getPopulations(patientData.id);
          patientData.isMenuDirty = true;
          patientData.isFavoriteFlag = true;
        });
    };

    scope.clickaddnew = function(){
        scope.populationList = [];
        if(scope.hasEditAccess){
          scope.getPopulationList();
        }
        scope.popup = true;
        scope.showNotification = false;
        scope.selectNewPopulation = [];
      };

    scope.clickaddnewCancel = function(){
        scope.popup = false;
        scope.showNotification = false;
      };

    scope.clickaddnewSave = function(){
      var newPopulation = {
        populationId : scope.selectNewPopulation.id,
        programName : scope.selectNewPopulation.name,
        enrollmentStartDate : new Date().toISOString(),
        enrollmentStatus: 'Enrolled',
        missedOpportunityCount: 0
      };
      if(scope.isEnrolledInPopulation(newPopulation)) {
        scope.popup = false;
        scope.showAlert('This patient is already enrolled in the ' + newPopulation.programName + ' managed population.','alert-error');
        return;
      }
      scope.addPopulation(patientData.id, {populationId : scope.selectNewPopulation.id});
      scope.popup = false;
    };

    scope.clickaddnewClose = function(){
      scope.popup = false;
      scope.showNotification = false;
    };

    scope.populationChange= function (a){
      scope.selectNewPopulation = a;
    };
    scope.popupAction = function () {
      scope.modalInstance = $modal.open({
        templateUrl: 'disenrollPatientConfirm.html',
        size: '',
        scope: scope,
        backdrop: 'static'
      });
    };

    scope.clickDisenroll = function (population) {
      scope.disenrollment = {};
      scope.disEnrollPopulation = population;
      scope.data={'taskId':population.patientProgramId,'lockType':'ManagedPopulation', 'IsLocked': true};
      userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
            scope.status=response.data.results.status;
            if(scope.status === true){
              scope.isLocked = false;
              scope.lockedText = '';
              scope.getdisenrollment();
              scope.isComment = true;
              scope.isSave = true;
              scope.popupAction();
            }
            else {
              scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName',response.data.results.name);
              scope.isLocked = true;
            }
          });
    };

    /*GET all disenrollment reason*/
    scope.getdisenrollment = function () {
      populationManagementSvc.getAlldisenrollmentReason()
      .then(function (response) {
          scope.disenrollmentData = response.data.results;
        });
    };

    /*validating Disenrollment Type on change*/
    scope.validateDisenrollmentType = function (value) {
      if(value !== undefined)
      {
        var conversionToJSONObj = JSON.parse(value);
        value = conversionToJSONObj;
      }
      if (value !== null) {
        scope.isComment = false;
        if (value.disenrollReason === 'Other') {
          scope.isComment = false;
          scope.isSave = true;
        } else {
          scope.disenrollment.reason = '';
          scope.isSave = false;
          scope.isComment = true;
        }
      } else {
        scope.disenrollment.reason = '';
        scope.isComment = true;
        scope.isSave = true;
      }
    };

    /*validating Comment for Disenrollment Type change*/
    scope.validateComment = function (comment) {
      if (comment) {
        scope.isSave = false;
      } else {
        scope.isSave = true;
      }
    };

    scope.confirmDisenroll = function () {
        scope.performDisenroll(scope.disEnrollPopulation);
      };
    scope.closeDisenrollPatientPopup = function () {
      scope.unlockConcurrentTask(false, scope.disEnrollPopulation.patientProgramId);
      scope.modalInstance.close(true);
    };

    scope.performDisenroll = function (population) {
      var conversionToJSONObj = typeof scope.disenrollment.selectedDisenrollmentType === 'string' ? JSON.parse(scope.disenrollment.selectedDisenrollmentType) : scope.disenrollment.selectedDisenrollmentType;
      scope.disenrollment.selectedDisenrollmentType = conversionToJSONObj;
      populationManagementSvc.deletePopulation(patientData.id, population.populationId, population.patientProgramId, scope.disenrollment.reason ? scope.disenrollment.reason : '', scope.disenrollment.selectedDisenrollmentType.disenrollReasonId,'I')
     .then(function (response) {
        if (response.data.results.success) {
          scope.showAlert('Patient has been dis-enrolled from Managed Population successfully.','alert-success');
          scope.getPopulations(patientData.id);
          patientData.isMenuDirty = true;
          patientData.isFavoriteFlag = true;
        }
        else {
          scope.unlockConcurrentTask();
          scope.showAlert('Failed to dis-enroll patient from population.','alert-error');
        }
      });
      scope.modalInstance.close(true);
    };
    scope.showAlert = function (alertmessage, alerttype) {
      window.scrollTo(0, 0);
      scope.alertMessageStyle = alerttype;
      scope.alertMessage = alertmessage;
      scope.showNotification = true;
      setTimeout(function() {
        scope.showNotification = false;
      }, 6000);
    };
    scope.unlockConcurrentTask = function(isLocked, taskId) {
      scope.data={'lockType':'ManagedPopulation', 'isLocked': isLocked, 'taskId': taskId };
      userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(){
        scope.isLocked = false;
        scope.lockedText = '';
      });
    };
    scope.resetToolTipText=function(){
        scope.isLocked = false;
      };

    scope.reassignCareLead = function(item){
      scope.notification = {visible: false,message: ''};
      scope.selectedObject = item;
      scope.careLeadId = item.careLeadId;
      scope.managedPopulationId = item.populationId;
      populationManagementSvc.getManagedPopulationCareTeamMembers(item.populationId)
        .then(function (response) {
          scope.careLeads = response.data.results.careLeads;
        });
      scope.modalInstance = $modal.open({
        templateUrl: 'reassignCareLead.html',
        size: '',
        scope: scope,
        backdrop: 'static'
      });
    };

    scope.closeReassignCareLeadPopup= function(){
      scope.modalInstance.close(true);
    };

    scope.changeCareLead = function(item) {
      scope.notification = {visible: false,message: ''};
      populationManagementSvc.getCareLeadReassignStatus(scope.managedPopulationId,item.providerID).then(function(res) {
        if(res.data.results.careLeadStatus === 'I')
        {
          scope.notification.visible = true;
          scope.notification.message = item.providerName + ' is turned \'Closed\' as a Care lead for this managed pop by supervisor';
        }
      });
      scope.selectedCareLeadId = item.providerID;
    };

    scope.updateCareLead = function(){
      if(scope.selectedObject.careLeadId !== scope.selectedCareLeadId){
        populationManagementSvc.updatePatientCareLead(patientData.id,{providerPatientId: scope.selectedObject.patientProgramId ,providerId: scope.selectedObject.careLeadId, assignedProviderId: scope.selectedCareLeadId})
        .then(function() {
          scope.getPopulations(patientData.id);
          patientData.isFavoriteFlag = true;
        });
      }
      scope.modalInstance.close(true);
    };

    scope.unlockConcurrentTask();
  }]);
}(window.app));
