(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('PatientUtilizationCtrl', ['$scope', '$http','$q','_', 'PatientData',
    function (scope , http, q, _, patientData) {

      scope.eventsPage = 1;
      scope.encountersPage = 1;
      scope.eventsPageSize = 10;
      scope.encountersPageSize = 10;
      scope.eventsExpanded = true;
      scope.encountersExpanded = true;
      scope.utilizations = {
        events : [],
        encounters : []
      };

      function getUtilizations(id){
        function successCallBack(data){
          if (/events$/.test(data.href)) {
            scope.utilizations.events = [];
            scope.utilizations.events = data.results;
          } else{
            scope.utilizations.encounters = [];
            scope.utilizations.encounters = data.results;
          }
        }
        var apiUrl=['patients/:id/utilization-events', 'patients/:id/utilization-encounters'],
          urls;
        if(apiUrl.length > 0){
          urls = _.map(apiUrl,function(item){
            return app.api.root +  item.replace(/:id/,id);
          });
        }
        _.each(urls,function (url){
          http.get(url).success(function(data){successCallBack(data);});
        });
      }
     
      scope.getUtilizations = getUtilizations;
      scope.getUtilizations(patientData.id);
      scope.pageTitle = 'Utilization Details';

      scope.eventsTable = {
        captionText : 'ADT Events within the Last 12 Months (Source: HL7)',
        columns : ['Event Type', 'Event Date', 'Primary Dx', 'Facility Name','Days between current admission and last discharge','Days of Inpatient Stay','Readmission Flag'],
        rows: []
      };
      scope.encountersTable = {
        captionText : 'Encounters within the Last 12 Months (Source: Claims)',
        columns : ['Encounter Type', 'Encounter  Date', 'Primary Dx', 'Provider','Provider Specialty','Major Procedures'],
        rows: []
      };
    }]);
  }(window.app));
