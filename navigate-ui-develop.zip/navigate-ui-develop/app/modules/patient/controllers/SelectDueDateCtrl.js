(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('SelectDueDateCtrl', ['$scope', '$http','listStateSvc','$window','httpRequestSvc','PatientData','$location',
    function (scope, http, listStateSvc,window,httpRequestSvc,patientData,location) {
           
      if (scope.initializeStep) {
        scope.initializeStep('selectDueDate', false);
      }

      var currentListState = listStateSvc.get();

      scope.open = function($event) {
        $event.preventDefault();
        $event.stopPropagation();
        scope.opened = true;
      };

      
      scope.initializeSelectDueDate = function() {
        currentListState = listStateSvc.get();
        scope.dueDate = currentListState.CurrentUIState.currentselectedDueDate;
        scope.verifyTaskName();
        if (scope.dueDate !== null && scope.dueDate !== undefined && scope.dueDate !== '') {
          scope.completeStep(true,'selectDueDate');
        }
      };

      scope.enableNextButton = function(status,alertStatus){
        scope.isTaskNameExists = alertStatus;
        scope.completeStep(status,'selectDueDate');
        listStateSvc.set(currentListState);
      };

      scope.dueDateChange = function() {
        if (scope.dueDate !== null && scope.dueDate !== undefined && scope.dueDate !== '') {
          currentListState.CurrentUIState.currentselectedDueDate = window.moment(scope.dueDate).format('MM/DD/YYYY');
          scope.verifyTaskName();
        }else
        {
          scope.dueDate = '';
          scope.enableNextButton(false,false);
        }
      };

      scope.verifyTaskName = function(){
        var flag = true;
        if(scope.dueDate !== undefined && scope.dueDate !== '')
        {
          if(currentListState.CurrentUIState.currentTaskType.name === 'Schedule Procedure' || currentListState.CurrentUIState.currentTaskType.name === 'Assessment')
          {
            flag = (currentListState.CurrentUIState.currentTaskName.id > 0) ? true : false;
          }
          if(flag === true && currentListState.CurrentUIState.currentTaskName !== undefined  && currentListState.CurrentUIState.currentTaskName !== '' && currentListState.CurrentUIState.currentselectedDueDate !== undefined && currentListState.CurrentUIState.currentselectedDueDate !== '') {
            var taskInformations =
            {
              context : 'verification',
              taskTypeId : currentListState.CurrentUIState.currentTaskType.id,
              taskId : (currentListState.CurrentUIState.currentTaskType.name === 'Other Tasks' || currentListState.CurrentUIState.currentTaskType.name === 'Education Material') ? '' : currentListState.CurrentUIState.currentTaskName.id,
              taskDueDate : currentListState.CurrentUIState.currentselectedDueDate,
              taskName : (currentListState.CurrentUIState.currentTaskType.name === 'Other Tasks' || currentListState.CurrentUIState.currentTaskType.name === 'Education Material') ? currentListState.CurrentUIState.currentTaskName.name : '',
              taskTypeName : currentListState.CurrentUIState.currentTaskType.name
            };
            httpRequestSvc.getRequest('patients/' + patientData.id + '/tasks',taskInformations).then(function(response){
              if(response.data.results.length > 0){
                scope.enableNextButton(false,true);
              }
              else{
                scope.enableNextButton(true,false);
              }
            });
          }
          else {
            scope.enableNextButton(true,false);
          }
        }
        else { scope.enableNextButton(false,false); }
      };

      scope.$on('wizardOnClose', function() {
        listStateSvc.clear();
        if(app !== undefined && app.currentRoute !== undefined) {
          location.path(app.currentRoute +'/');
        }
        else{
          location.path('/');
        }
      });

      scope.$watch('selectDueDateForm.$pristine', function () {
        if (scope.selectDueDateForm && !scope.selectDueDateForm.$pristine) {
          localStorage.setItem('isWizardFormDirty', true);
        }
      });
      
      scope.formats = ['MM/dd/yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
      scope.format = scope.formats[0];
      scope.minDate = new Date();

    }]);

  }(window.app));