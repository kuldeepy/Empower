/**
 * @author michael.ash
 */
(
  function (app) {
      /* @fmt: off */
      'use strict';
      // @fmt:on
      app.controller('PopulationManagementCtrl_test', ['$scope',
        function (scope) {
            scope.populations = [];
            scope.Program = [
                { 'ProgramId': '1', 'ProgramName': 'Breast Cancer Screening', 'Status': 'Enrolled', 'ShortProgramName': 'AMI Managed Population...', 'EnrollmentStatus': 'Enrolled', 'EnrollmentStartDate': '12/23/2013', 'CareTeamName': 'Screening Care Team', 'CareTeamID': '1', 'MissedOpportunityNo': '0', },
                { 'ProgramId': '2', 'ProgramName': 'Cerivical Cancer Screening', 'Status': 'DisEnrolled', 'ShortProgramName': 'AdmissionManagedPopulation_0...', 'EnrollmentStatus': 'Enrolled', 'EnrollmentStartDate': '01/10/2014', 'CareTeamName': 'Heart Failure Care Team', 'CareTeamID': '2', 'MissedOpportunityNo': '1', },
                { 'ProgramId': '3', 'ProgramName': 'Congestive Heart failure', 'Status': 'Enrolled', 'ShortProgramName': 'Admitted Managed Population...', 'EnrollmentStatus': 'Enrolled', 'EnrollmentStartDate': '01/10/2014', 'CareTeamName': 'Screening Care Team', 'CareTeamID': '3', 'MissedOpportunityNo': '2', },
                { 'ProgramId': '4', 'ProgramName': 'Breast Cancer Screening', 'Status': 'Enrolled', 'ShortProgramName': 'AMI Managed Population...', 'EnrollmentStatus': 'Enrolled', 'EnrollmentStartDate': '12/23/2013', 'CareTeamName': 'Heart Failure Care Team', 'CareTeamID': '1', 'MissedOpportunityNo': '3', },
                { 'ProgramId': '5', 'ProgramName': 'Cerivical Cancer Screening', 'Status': 'DisEnrolled', 'ShortProgramName': 'AdmissionManagedPopulation_0...', 'EnrollmentStatus': 'Enrolled', 'EnrollmentStartDate': '01/10/2014', 'CareTeamName': 'Screening Care Team', 'CareTeamID': '2', 'MissedOpportunityNo': '4', }
              ];
            scope.notification = {
                visible: false,
                type: 'success',
                message: 'Patient has been enrolled into managed population successfully.',
              };
            scope.button = {
                addNewText: 'Add Managed Population',
                cancelText: 'Cancel',
                saveText: 'Save',
                closeText: 'Close',
                addText: 'Add'
              };
            scope.popup = true;
            scope.addPopup = false;
            scope.clickaddnew = function () {
                scope.popup = true;
                scope.notification.visible = false;
                scope.DisRepPopup = false;
              };
            scope.clickDisenrollYes = function () {
                scope.popup = true;
                scope.notification.visible = false;
                scope.DisRepPopup = true;
                scope.open1();
              };
            scope.clickaddnewCancel = function () {
                scope.popup = true;
                scope.addPopup = false;
                scope.DisenrPopup = true;
                scope.DisPopup = true;
                scope.notification.visible = false;
                scope.DisRepPopup = false;
                $('.openGenericPopUp').modal('show');
                $('.openManagePopUp').modal('hide');
              };
            scope.clickaddnewSave = function () {
                scope.popup = false;
                scope.notification.visible = true;
              };
            scope.clickaddnewClose = function () {
                scope.popup = true;
                scope.addPopup = false;
                scope.DisenrPopup = true;
                scope.notification.visible = false;
              };
            scope.DisEnrollPatient = function () {
                $('.openGenericPopUp').modal('hide');
                scope.popup = true;
                scope.notification.visible = true;
                scope.DisenrPopup = false;
                scope.DisPopup = false;
              };
            scope.CancelDisEnrollPatient = function () {
                scope.popup = true;
                scope.notification.visible = false;
                scope.DisenrPopup = false;
                scope.DisPopup = false;
                $('.openGenericPopUp').modal('hide');
              };
            scope.clickaddCancel = function () {
                scope.popup = true;
                scope.addPopup = false;
                scope.DisenrPopup = false;
                scope.DisPopup = false;
                scope.notification.visible = false;
                scope.DisRepPopup = false;
                $('.openManagePopUp').modal('hide');
              };
            scope.open = function () {
                $('.openGenericPopUp').modal('show');
              };
            scope.open1 = function () {
                $('.openManagePopUp').modal('show');
              };
          }]);
    }(window.app));
