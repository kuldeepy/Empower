(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('SelectTaskTypeCtrl', ['$scope', '$http','listStateSvc','_','$location',
    function (scope, http, listStateSvc,_,location) {
           
      if (scope.initializeStep) {
        scope.initializeStep('selectTaskType',false);
      }

      var currentListState = listStateSvc.get();

      scope.getTaskTypes = function (){
        var url = app.api.root + 'task-types';
        http.get(url)
          .success (function (data){
            var results = data.results;
            scope.taskTypes = results;
            scope.selectedTaskType = _.find(scope.taskTypes, function (item) {
              return item.id === listStateSvc.seletectedTaskType().id;
            });
            if (scope.selectedTaskType !== null && scope.selectedTaskType !== undefined && scope.selectedTaskType !== '') {
              scope.completeStep(true,'selectTaskType');
            }
          });
      };

      scope.initializeSelectTaskTypes = function() {
        scope.getTaskTypes();
      };

      scope.taskTypeChanged = function() {
        if (scope.selectedTaskType !== null && scope.selectedTaskType !== undefined && scope.selectedTaskType !== '') {
          currentListState.CurrentUIState.currentTaskType = scope.selectedTaskType;
          currentListState.CurrentUIState.currentTaskName = '';
          listStateSvc.set(currentListState);
          scope.tabDefinitions[1].clickable = false;
          scope.tabDefinitions[1].isTabCompleted = false;
          scope.stepDefinitions[0][1].isTabCompleted = false;
          scope.stepDefinitions[0][2].clickable = false;
          scope.stepDefinitions[0][3].clickable = false;
          scope.completeStep(true,'selectTaskType');
        } else {
          scope.completeStep(false,'selectTaskType');
        }
      };

      scope.$on('wizardOnClose', function() {
        listStateSvc.clear();
        if(app !== undefined && app.currentRoute !== undefined) {
          location.path(app.currentRoute +'/');
        }
        else{
          location.path('/');
        }
      });

      scope.$watch('selectTaskTypeForm.$pristine', function () {
        if (scope.selectTaskTypeForm && !scope.selectTaskTypeForm.$pristine) {
          localStorage.setItem('isWizardFormDirty', true);
        }
      });


    }]);

  }(window.app));