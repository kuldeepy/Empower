(function (app) {
  'use strict';
  app.controller('patientAssessmentCompletionCtrl', ['$scope','$http','PatientData','patientAssessmentSvc','_','$location','$modal','$timeout','patientVisitPlanSvc','parseToZipFile',function (scope,http,patientData,patientAssessmentSvc,_,location,$modal,$timeout,patientVisitPlanSvc,zipFile) {
    var selectedAssessment = JSON.parse(localStorage.getItem('selectedassessment'));
    var selectedAnswers = [];
    var patientAssessmentSurvey = [];
    scope.assessmentName='';
    scope.printStatus = true;
    scope.printlogo=false;
    scope.printback=false;
    scope.showMandatoryErrorMessage = false;
    localStorage.removeItem('selectedassessment');
    scope.hstep = 1;
    scope.mstep = 1;
    scope.ismeridian = true;
    scope.showSendAssessmentPdf = app.sendAssessmentPdf;
    scope.islink = true;

    patientAssessmentSvc.getPatientData(patientData.id).then(function(response){
      scope.PatientDetails=response.data.results;
    });
    patientVisitPlanSvc.getCompletedAssessments(patientData.id).success(function (data) {
      var assessmentresult=[];
      data.results.forEach(function(res){
        assessmentresult.push({assessmentName:res.assessmentName,dateDue:res.dateDue,dateTaken:res.dateTaken,dateCompleted:res.taskCompletedDate,
          scoreRange:((res.scoreRange!==null && res.scoreRange!==0)?res.scoreRange:'N/A'),maxscore:res.maxscore,completedBy:res.completedBy,patientAssessmentId:res.patientAssessmentId});
      });
      scope.assessmentslist = assessmentresult;
    });
    scope.openAssessmentSurvey = function (assessment) {
      scope.assessmentSets = [];
      scope.questions = [];
      scope.answers = [];

      if (assessment.Name === undefined) {
        scope.assessmentName = assessment.assessmentName;
      }
      else {
        scope.assessmentName = assessment.Name;
      }

      if (assessment.TypeId === undefined) {
        scope.assessmentId = assessment.assessmentId;
      }
      else {
        scope.assessmentId = assessment.TypeId;
      }

      if (assessment.TaskSpecificId === undefined) {
        scope.userAssessmentID = assessment.patientAssessmentId;
      }
      else {
        scope.userAssessmentID = assessment.TaskSpecificId;
      }
      if (assessment.taskCompletedDate || assessment.CompletedDate) {
        scope.isOpenClicked = false;
      }
      else {
        scope.isOpenClicked = true;
      }
      var requestpath = 'patients/' + patientData.id + '/assessments/' + scope.assessmentId + '/' + scope.userAssessmentID;
      patientAssessmentSvc.getPatientAssessmentSurvey(requestpath).then(function (response) {
        if (response.data.results) {
          scope.assessmentSets = [];
          scope.questions = [];
          scope.answers = [];
          scope.assessmentslist = _.where(scope.assessmentslist,{'patientAssessmentId':parseInt(scope.userAssessmentID)});
          scope.data = response.data.results;
          var assessmentSets = scope.data.Assessmentset;
          angular.forEach(assessmentSets, function (assessment) {
            if (angular.equals(assessment.isShow, true)) {
              scope.assessmentSets.push(assessment);
            }
          });

          var questions = scope.data.Questions;
          var count =0;
          angular.forEach(questions, function (question) {
            question.isDatePickerOpen = false;
            question.defaultTime = new Date('00');

            if (angular.equals(question.answerControlType, 'Checkbox')) {
              question.selectedAns = [];
            }
            else if(angular.equals(question.answerControlType, 'DateTime')){
              scope.currentDate = new Date ();
              question.selectedAns = scope.currentDate;
              question.defaultTime = scope.currentDate;
            }
            else {
              question.selectedAns = [];
            }
            question.questionIndex = (count = count + 1);
            scope.questions.push(question);
          });

          var answers = scope.data.Answers;
          angular.forEach(answers, function (answer) {
            answer.enteredAnswer = '';
            scope.answers.push(answer);
          });
          scope.saveAssessmentButtonDisable = true;
          selectedAnswers = scope.data.SelectedAnswers;
          angular.forEach(selectedAnswers, function (selectedAnswer) {
            angular.forEach(scope.questions, function (question) {
              if (selectedAnswer.assessmentSetQuestionId === question.assessmentSetQuestionId) {
                switch (question.answerControlType) {
                  case 'Text':
                  case 'NumberText':
                    if(selectedAnswer.answerString !== null && selectedAnswer.answerString !== undefined && selectedAnswer.answerString !== '')
                    {
                      question.selectedAns = selectedAnswer.answerString;
                      scope.saveAssessmentButtonDisable = false;
                    }
                    break;
                  case 'DateTime':
                    if (selectedAnswer.answerString !== null && selectedAnswer.answerString !== undefined && selectedAnswer.answerString !== '') {
                      question.selectedAns = selectedAnswer.answerString;
                      scope.saveAssessmentButtonDisable = false;
                      scope.value = new Date(question.selectedAns);
                      question.defaultTime = new Date(question.selectedAns);
                      question.selectedAns = scope.value;
                    }
                    break;
                  case 'Radio.Text':
                  case 'Radio.Text.Label':
                    angular.forEach(scope.answers, function (answer) {
                      if (answer.answerId === selectedAnswer.answerId) {
                        if(selectedAnswer.answerId !== null && selectedAnswer.answerId !== undefined && selectedAnswer.answerId !== '')
                        {
                          answer.enteredAnswer = selectedAnswer.answerString;
                          question.selectedAns = selectedAnswer.answerId;
                          scope.saveAssessmentButtonDisable = false;
                        }
                      }
                    });
                    break;
                  case 'Checkbox':
                    if(selectedAnswer.answerId !== null && selectedAnswer.answerId !== undefined && selectedAnswer.answerId !== '')
                    {
                      question.selectedAns.push(selectedAnswer.answerId);
                      scope.saveAssessmentButtonDisable = false;
                    }
                    break;
                  case 'Checkbox.Text':
                  case 'Checkbox.Text.Label':
                    angular.forEach(scope.answers, function (answer) {
                      if (answer.answerId === selectedAnswer.answerId) {
                        if(selectedAnswer.answerId !== null && selectedAnswer.answerId !== undefined && selectedAnswer.answerId !== '')
                        {
                          question.selectedAns.push(selectedAnswer.answerId);
                          answer.enteredAnswer = selectedAnswer.answerString;
                          scope.saveAssessmentButtonDisable = false;
                        }
                      }
                    });
                    break;
                  case 'Radio':
                  case 'DropDown':
                  case 'Gridview':
                    if(selectedAnswer.answerId !== null && selectedAnswer.answerId !== undefined && selectedAnswer.answerId !== '')
                    {
                      question.selectedAns = selectedAnswer.answerId;
                      scope.saveAssessmentButtonDisable = false;
                    }
                    break;
                }
              }
            });
          });
         
        }
      });
    };
      
    scope.printDiv=function() {
      scope.scrollCss = '';
      scope.printStatus = false;
      scope.printlogo=true;
      scope.printback=true;
      var contents='';
      $timeout(function() {
        contents = $('#printable').html();
        var frameData = $('<iframe />');
        frameData[0].name = 'frameData';
        frameData.css({ 'position': 'absolute', 'top': '-1000000px'});
        $('body').append(frameData);
        var frameDoc = frameData[0].contentWindow ? frameData[0].contentWindow : frameData[0].contentDocument.document ? frameData[0].contentDocument.document : frameData[0].contentDocument;
        frameDoc.document.open();
        frameDoc.document.write('<html><head><title>Patient Information</title>');
        frameDoc.document.write('</head><body>');
        frameDoc.document.write('<link href="/bower_components/bootstrap/bootstrap.min.css" rel="stylesheet"  type="text/css" />');
        frameDoc.document.write('<link href="/themes/default/main.css" rel="stylesheet"  type="text/css" />');
        frameDoc.document.write(contents);
        frameDoc.document.write('<script>window.onload = function () { parent.document.title="' + scope.assessmentName + '"; window.print(); parent.document.title="Patient Home Page";};</script></body></html>');
        frameDoc.document.close();
        scope.printlogo=false;
        scope.printback=false;
        scope.printStatus = true;
        
      }, 1000);
    };
    
    scope.checkboxCss = function(answer,selectedAns){
      var count = 0;
      selectedAns.forEach(function(item){
        if((item) === (answer)){
          count = 1;
        }
      });
      return  count === 1 ?(scope.isOpenClicked === true ? 'pdfcheckboxEnable' :'pdfcheckboxEnable pdfcheckboxEnableforcompletion'):'pdfcheckboxDisable';

    };
    scope.redirectToPreviousPage = function(){
      location.path(app.currentRoute+selectedAssessment.page);
    };

    scope.$watch('saveAssessment', function (addAssessment) {
                    if (!addAssessment) {
                      return;
                    }
                    scope.saveAssessment = '';
                    scope.saveAssessmentSurvey(addAssessment);
                  });

    scope.saveButtonDisableForText = function (inputValue, type) {
      if (type === 'Text') {
        scope.transformedInput = inputValue.toLowerCase().replace(/ /g, '');
        if (scope.transformedInput === '') {
          scope.saveAssessmentButtonDisable = true;
          return true;
        } else {
          scope.saveButtonDisable(false);
          return false;
        }
      }
      else if (type === undefined)
      {
        scope.saveButtonDisable(false);
        return false;
      }
    };

    scope.saveButtonDisable = function (value) {
      scope.cancelPopup = true;
      if(validateAtLeastOneQuestionIsAnswered() === true)
      {
        scope.saveAssessmentButtonDisable = value;
      }
      else
      {
        scope.saveAssessmentButtonDisable = true;
      }
    };

    scope.unCheckSlectedRadioOption = function (event, selectedAns) {
      scope.hasAnswerSelected = selectedAns.length === 0 ? false : true;
      if (scope.hasAnswerSelected === true && event.target.value === selectedAns) {
        var answer = _.find(scope.answers, function (ans) { return ans.answerId === parseInt(event.target.value); });
        if (answer && event.target.checked !== event.target.defaultChecked) {
          var question = _.find(scope.questions, function (que) { return que.assessmentSetQuestionId === parseInt(answer.assessmentSetQuestionId); });
          if (question) {
            var index = _.findIndex(scope.questions, question);
            scope.questions[index].selectedAns = [];
            event.target.checked = event.target.checked;
          }
        }
        scope.saveButtonDisable(false);
      }
    };

    var validateAnswerArray = function(ans){
      if(angular.isArray(ans)){
        if(ans.length > 0){
          return true;
        }else{
          return  false;
        }
      }else{
        return true;
      }
    };

    var validateAtLeastOneQuestionIsAnswered = function() {
      var isAtLeastOneQuestionAnswered = false;
      angular.forEach(scope.questions, function (ans) {
        if(!isAtLeastOneQuestionAnswered)
        {
          if (ans.selectedAns !== null && ans.selectedAns !== undefined && ans.selectedAns !== '' && ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns))
          {
            isAtLeastOneQuestionAnswered = true;
          }
        }
      });
      return isAtLeastOneQuestionAnswered;
    };

    scope.closeModal = function (className) {
      if(JSON.stringify(scope.modalInstance) !== '{}'){
        scope.modalInstance.close();
      }
      if(className === undefined){
        location.path(app.currentRoute+selectedAssessment.page);
      }
    };

    scope.openDatePicker = function ($event, question) {
        $event.stopPropagation();
        $event.preventDefault();
        angular.forEach(scope.data.Questions, function (q) {
          q.isDatePickerOpen = false;
        });
        question.isDatePickerOpen = !question.isDatePickerOpen;
      };
    scope.disabled = function (date, mode) {
      return (mode === 'year' && (date.getDay() === 6 || date.getDay() === 0));
    };
    scope.openConfirmation = function (id) {
      var target = $('#assessmentSurveyDiv');
      scope.completeType = id;
      target.scrollTop(0);
      switch (id) {
        case 'saveConfirm':
          scope.openModal('saveConfirm', 'show');
          break;
        case 'cancelConfirmPopup':
          scope.closeAssessemtModel();
          break;
        case 'Resend':
          resendAssessmentPdf();
          break;
        case 'cancelConfirm':
          if (scope.cancelPopup === true) {
            scope.openModal('cancelConfirm', 'show');
          }
            else {
            scope.closeAssessemtModel();
          }
          break;
        case 'complete':
        case 'completeAndSendToEMR':
          checkIfAllTheMandatoryQuestionsAnswered();
          if(scope.showMandatoryErrorMessage === false)
          {
            scope.openModal('completeConfirm', 'show');
          }
          break;
      }
    };
    var checkIfAllTheMandatoryQuestionsAnswered = function(){
      scope.showMandatoryErrorMessage = false;
      for(var x=0; x < scope.questions.length; x=x+1)
      {
        if(scope.questions[x].isRequired === true)
        {
          if (scope.questions[x].selectedAns === null || scope.questions[x].selectedAns === undefined || scope.questions[x].selectedAns === '' || scope.questions[x].selectedAns === [] || !validateAnswerArray(scope.questions[x].selectedAns) || scope.saveButtonDisableForText(scope.questions[x].selectedAns, scope.questions[x].answerControlType))
          {
            scope.showMandatoryErrorMessage = true;
            scope.setErrorNotification = 'Please answer all the mandatory questions';
            break;
          }
        }
      }
    };
    scope.modalInstance = {};
    scope.openModal = function (className, action) {
      scope.scrollCss = '';
      if(action === 'show'){
        scope.modalInstance = $modal.open({
          templateUrl: className+'Popup.html',
          size: '',
          scope: scope,
          backdrop: 'static',
          keyboard: false
        });
      }
      else{
        scope.modalInstance.close();
      }
    };
    
    scope.saveAssessmentSurvey = function (type) {
      var TypeName = 'Pending';
      if(type === 'complete' || type === 'completeAndSendToEMR')
      {
        TypeName = 'complete';
      }
      patientAssessmentSurvey = [];
      angular.forEach(scope.questions, function (ans) {
        switch (ans.answerControlType) {
          case 'Radio':
          case 'DropDown':
          case 'Gridview':
            var surveyAnswered = {
              assessmentId: scope.assessmentId,
              userAssessmentId: scope.userAssessmentID,
              assessmentSetQuestionId: ans.assessmentSetQuestionId,
              answerId: (ans.selectedAns === undefined || (ans.selectedAns !== null && ans.selectedAns.length === 0) ) ? null : ans.selectedAns,
              answerComments: TypeName,
              answerString: ''
            };
            if((ans.answerControlType === 'Gridview' && ans.selectedAns !== '' && ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns)) || ans.answerControlType === 'Radio')
            {
              patientAssessmentSurvey.push(surveyAnswered);
            }
            else if(ans.answerControlType === 'DropDown')
            {
              if(ans.selectedAns === '' || (ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns)))
              {
                patientAssessmentSurvey.push(surveyAnswered);
              }
            }
            break;
          case 'Text':
          case 'NumberText':
            if(ans.selectedAns === '' || (ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns)))
            {
              angular.forEach(scope.data.Answers, function (testAns) {
                if (testAns.assessmentSetQuestionId === ans.assessmentSetQuestionId) {
                  var surveyAnsweredText = {
                    assessmentId: scope.assessmentId,
                    userAssessmentId: scope.userAssessmentID,
                    assessmentSetQuestionId: ans.assessmentSetQuestionId,
                    answerId: testAns.answerId,
                    answerComments: TypeName,
                    answerString: ans.selectedAns
                  };
                  patientAssessmentSurvey.push(surveyAnsweredText);
                }
              });
            }
            break;
          case 'DateTime':
            if (ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns)) {
              if (ans.selectedAns !== null) {
                var year = ans.selectedAns.getFullYear();
                var month = ans.selectedAns.getMonth() + 1;
                if (month < 10) {
                  month = '0' + month;
                }
                var day = ans.selectedAns.getDate();
                var hours = ans.defaultTime.getHours();
                var minutes = ans.defaultTime.getMinutes();
                scope.dateTime = month + '/' + day + '/' + year + ' ' + hours + ':' + minutes;
              } else {
                scope.dateTime = '';
              }
              angular.forEach(scope.data.Answers, function(testAns) {
                if (testAns.assessmentSetQuestionId === ans.assessmentSetQuestionId) {
                  var surveyAnsweredText = {
                    assessmentId: scope.assessmentId,
                    userAssessmentId: scope.userAssessmentID,
                    assessmentSetQuestionId: ans.assessmentSetQuestionId,
                    answerId: testAns.answerId,
                    answerComments: TypeName,
                    answerString: scope.dateTime
                  };
                  patientAssessmentSurvey.push(surveyAnsweredText);
                }
              });
            }
            break;
          case 'Radio.Text':
          case 'Radio.Text.Label':
            var selectId = parseInt(ans.selectedAns, 10);
            angular.forEach(scope.answers, function (radioAns) {
              if (radioAns.answerId === selectId) {
                var surveyAnsweredRadioText = {
                  assessmentId: scope.assessmentId,
                  userAssessmentId: scope.userAssessmentID,
                  assessmentSetQuestionId: ans.assessmentSetQuestionId,
                  answerId: ans.selectedAns,
                  answerComments: TypeName,
                  answerString: radioAns.enteredAnswer
                };
                patientAssessmentSurvey.push(surveyAnsweredRadioText);
              }
            });
            break;
          case 'Checkbox':
            if(ans.selectedAns.length === 0)
            {
              var surveyAnsweredCheckBox = {
                  assessmentId: scope.assessmentId,
                  userAssessmentId: scope.userAssessmentID,
                  assessmentSetQuestionId: ans.assessmentSetQuestionId,
                  answerId: null,
                  answerComments: TypeName,
                  answerString: ''
                };
              patientAssessmentSurvey.push(surveyAnsweredCheckBox);
            }
            angular.forEach(ans.selectedAns, function (checkboxAns) {
              if(ans.selectedAns !== '' && ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns))
              {
                var surveyAnsweredCheckBox = {
                  assessmentId: scope.assessmentId,
                  userAssessmentId: scope.userAssessmentID,
                  assessmentSetQuestionId: ans.assessmentSetQuestionId,
                  answerId: checkboxAns,
                  answerComments: TypeName,
                  answerString: ''
                };
                patientAssessmentSurvey.push(surveyAnsweredCheckBox);
              }
            });
            break;
          case 'Checkbox.Text':
          case 'Checkbox.Text.Label':
            angular.forEach(ans.selectedAns, function (checkboxid) {
              var selectId = parseInt(checkboxid, 10);
              angular.forEach(scope.answers, function (checkboxString) {
                if (checkboxString.answerId === selectId) {
                  var surveyAnswered = {
                    assessmentId: scope.assessmentId,
                    userAssessmentId: scope.userAssessmentID,
                    assessmentSetQuestionId: ans.assessmentSetQuestionId,
                    answerId: checkboxid,
                    answerComments: TypeName,
                    answerString: checkboxString.enteredAnswer
                  };
                  patientAssessmentSurvey.push(surveyAnswered);
                }
              });
            });
            break;
        }
      });
      if (patientAssessmentSurvey.length > 0) {
        angular.forEach(patientAssessmentSurvey, function (answer) {
          if (selectedAnswers.length > 0) {
            angular.forEach(selectedAnswers, function (previousAns) {
              if (previousAns.assessmentSetQuestionId === answer.assessmentSetQuestionId) {
                answer.userAssessmentAnswersId = previousAns.userAssessmentAnswersId;
              }
            });
          }
          else {
            answer.userAssessmentAnswersId = 0;
          }
        });
        sendAssessmentPdf(type);
      }
      else {
        scope.closeModal();
      }
    };
    var resendAssessmentPdf = function () {
      scope.islink = false;
      $.get('/themes/default/pdf_assessment.css', function(data) {
        // read configuration
        var htmlContent = getAssessmentHtml(data);
        var base64EncodedZippedFile = zipFile.getBase64EncodedZippedFile('htmlContent.html', htmlContent);
        var postAssessmentSurveyResend = {
          patientAssessmentId : selectedAssessment.patientAssessmentId,
          htmlData: base64EncodedZippedFile
        };
        scope.islink = true;
        patientAssessmentSvc.savePatientAssessmentSurvey('patients/' + patientData.id + '/assessments/'+ selectedAssessment.assessmentId +'/resend', postAssessmentSurveyResend).
        then(function () {
          scope.isSent = true;
          $timeout(function () {
            scope.isSent = false;
          }, 6000);
        })
        .catch(function () {
          scope.patientMCtrl.errorNotification = 'This assessment cannot be sent to external EMR.';
        });
      });
    };

    scope.closeAssessemtModel = function () {
      scope.closeModal();
    };
    
    var getAssessmentHtml = function(styles){
      function fixupCssForPdf(css){
        // import makes pdf generator very slow, so we remove it as it is not needed.
        var exp = /@import url\("\/\/fonts.googleapis.com.*\);/g;
        return css.replace(exp, '');
      }
      styles = fixupCssForPdf(styles);
      var contents = '';
      contents += '<html><head><title>Assessments</title>';
      contents += '<style>';
      contents += styles;
      contents += '</style>';
      contents += '</head><body>';
      contents += $('#printable').html();
      contents += '</body></html>';
      return contents;
    };

    var sendAssessmentPdf = function(type) {
      scope.scrollCss = '';
      scope.printStatus = false;
      scope.printlogo=true;
      scope.printback=true;
      scope.islink = false;

      scope.isOpenClicked = false;
      $.get('/themes/default/pdf_assessment.css', function(data) {
        // read configuration
        var assessmentHtml = '';
        var base64EncodedZippedFile = '';

        if(app.sendAssessmentPdf === true && type === 'completeAndSendToEMR')
        {
          assessmentHtml = getAssessmentHtml(data);
          base64EncodedZippedFile = zipFile.getBase64EncodedZippedFile('htmlContent.html', assessmentHtml);
        }
        
        patientAssessmentSvc.savePatientAssessmentSurvey('patients/' + patientData.id + '/assessments/' + patientAssessmentSurvey[0].assessmentId +'/send', { patientAssessmentSurvey: patientAssessmentSurvey, htmlData: base64EncodedZippedFile }).success(function (response) {
          if (response.results) {
            if (response.results.status === true) {
        
              if (type === 'save') {
                localStorage.setItem('alert',JSON.stringify({alertmessage: 'Successfully saved your Assessment Task.', alerttype: 'alert-success'}));
              }
              else if(type === 'complete') {
                localStorage.setItem('alert',JSON.stringify({alertmessage: 'Assessment Task completed successfully.', alerttype: 'alert-success'}));
              }
              else
              {
                localStorage.setItem('alert',JSON.stringify({alertmessage: 'Assessment Task completed and sent to EMR successfully.', alerttype: 'alert-success'}));
              }
              scope.closeModal();
            }
            else {
              scope.closeModal();
            }
          }
          else {
            scope.closeModal();
          }
        })
        .error(function (err) {
          scope.patientMCtrl.errorNotification = err.message;
          scope.closeModal();
        });
        scope.isOpenClicked = true;
      });

      scope.printlogo=false;
      scope.printback=false;
      scope.printStatus = true;
  
    };
    
    if(selectedAssessment){
      window.scrollTo(0, 0);
      scope.islink = true;
      scope.openAssessmentSurvey((selectedAssessment));
      scope.previousPageName ='Back to '+(selectedAssessment.page === '' ?'Patient Tasks' :'Assessments');
    }

    scope.valiateTime = function(timeValue){

      if(!timeValue.defaultTime){
        timeValue.invalidtime = true;
      }else{
        timeValue.invalidtime = false;
      }

      angular.forEach(scope.questions, function (ans) {
        if (ans.invalidtime)
        {
          scope.saveAssessmentButtonDisable = true;
        }
      });
    };

    scope.saveAsessessment = function(){
      scope.openConfirmation('saveConfirm');
    };
    
  }]);

})(window.app);