/**
 * @author michael.ash
 */
(
  function (app) {
    'use strict';
    app.controller('SelectEducationMaterialCtrl', ['$scope', '$http', '$window', 'PatientData','listStateSvc','$location','httpRequestSvc',
        function (scope, http, window, patientData,listStateSvc,location,httpRequestSvc) {
        scope.listEducationalLibrary = [];

        scope.eduMatformData = {
          'dataEduLibtask':null,
          'dataEduLibDueDate':null,
          'dataEduLibList':0,
          'dataEduLibListSelected':null,
          'dataManagedPopulation':null,
          'formValidState':false
        };

        scope.formValidation = {
          'documentValidationVisibility':true,
          'educationalAddVisibility':false,
          'educationalMaterialAddVisibility':true,
          'documentTypeValidationVisibility':false,
          'formInvalidMsg':false
        };

        scope.filesFrUpload = [];
        scope.popup = false;
        scope.addPopup = false;
        scope.PatientEducationMaterials =[];
        var currentListState = listStateSvc.get();
        scope.selectedFiles = [];

        scope.readMethod = 'readAsDataURL';
        if (scope.initializeStep) {
          scope.initializeStep('selectTaskName', false);
        }
        
        scope.onReaded = function( e, file ){
            
            scope.selectedFiles.push({'ref':file,'content':e.target.result});
            scope.documentValidationMessage();
          };

        scope.fileExtensionSupported = function(fileExtension){
            var isPDF = fileExtension.indexOf('pdf');
            var isDOC = fileExtension.indexOf('doc');
            var isTXT = fileExtension.indexOf('txt');
            var isJPG = fileExtension.indexOf('jpg');
            var isJPEG = fileExtension.indexOf('jpeg');
            if (isPDF >= 0 || isDOC >= 0 || isTXT >=0 || isJPG >= 0 || isJPEG >= 0)
            {
              return 0;
            }
            else{
              return 1;
            }
          };
       

        scope.listEduLibSelc = [];
        scope.filterOptions = {
            filterText: '',
            useExternalFilter: true
          };
        
        scope.hasItems = false;
        scope.addNew = false;

        scope.verifyTaskName = function(){
          if(scope.eduMatformData.dataEduLibtask !== undefined  && scope.eduMatformData.dataEduLibtask !== '' && currentListState.CurrentUIState.currentselectedDueDate !== undefined && currentListState.CurrentUIState.currentselectedDueDate !== '') {
            var taskInformations =
            {
              context : 'verification',
              taskTypeID : currentListState.CurrentUIState.currentTaskType.id,
              taskId : '',
              taskDueDate : currentListState.CurrentUIState.currentselectedDueDate,
              taskName : scope.eduMatformData.dataEduLibtask,
              taskTypeName : currentListState.CurrentUIState.currentTaskType.name
            };
            httpRequestSvc.getRequest('patients/' + patientData.id + '/tasks',taskInformations).then(function(response){
              if(response.data.results.length > 0){
                scope.isTaskNameExists = true;
                scope.completeStep(false,'selectTaskName');
              }
              else{
                scope.isTaskNameExists = false;
                scope.completeStep(true,'selectTaskName');
                listStateSvc.set(currentListState);
              }
            });
          }
        };

        scope.$on('educationMaterialValidation', function(e){
          if(!e.defaultPrevented){
            e.defaultPrevented = true;
            scope.documentValidationMessage();
          }
        });

        scope.documentValidationMessage = function(){
          if( scope.listEduLibSelc !== undefined && scope.eduMatformData.dataEduLibtask !== undefined  && scope.eduMatformData.dataEduLibtask !== '' && scope.eduMatformData.dataEduLibtask !== null){
            if(scope.listEduLibSelc.length === 0 && scope.selectedFiles.length === 0){
              scope.formValidation.documentValidationVisibility = true;
              scope.completeStep(false,'selectTaskName');
              return;
            }
            else{
              scope.completeStep(true,'selectTaskName');
              scope.verifyTaskName();
              scope.formValidation.documentValidationVisibility = false;
              scope.loadDetails();
              scope.selectedComplete();
            }
          }
          else
          {
            scope.completeStep(false,'selectTaskName');
          }
        };

        scope.loadDetails = function(){
          scope.listSelectedFile = [];
          var  fileName={};
          var count=0;
          angular.forEach(scope.selectedFiles, function (file){
            count= count+ scope.fileExtensionSupported(file.ref.name.substr(file.ref.name.lastIndexOf('.') + 1).toLowerCase());
          });
          if(count !== 0 && scope.selectedFiles.length !== 0){
            scope.formValidation.documentTypeValidationVisibility = true;
            return;
          }
          else if(scope.listEduLibSelc.length === 0 && scope.selectedFiles.length === 0){
            scope.formValidation.documentValidationVisibility = true;
            return;
          }

          angular.forEach(scope.selectedFiles, function (file){
            fileName = {
            };

            fileName.documentContent = file.content;
            fileName.mimeType = file.ref.type;
            fileName.documentName = file.ref.name;
            scope.listSelectedFile.push(fileName);
          });
          scope.listSelectedLibrary = [];
          var  library=[];

          angular.forEach(scope.listEduLibSelc, function (lib){
            library.push(lib.libraryId.toString());
          });
        };

        scope.selectedComplete = function() {
          var selectedTaskName = {
            name : scope.eduMatformData.dataEduLibtask,
            files: scope.listSelectedFile,
            libraries: scope.listEduLibSelc
          };
          currentListState.CurrentUIState.currentTaskName = selectedTaskName;
          listStateSvc.set(currentListState);
          scope.completeStep(true,'selectTaskName');
        };

        scope.populateSelectedDetails = function() {
          var selectedDetails = listStateSvc.seletectedTaskName();
          if( selectedDetails !== null && selectedDetails !== undefined && selectedDetails !== ''){
            scope.eduMatformData.dataEduLibtask = selectedDetails.name;
            scope.listEduLibSelc  = selectedDetails.libraries;
            scope.completeStep(true,'selectTaskName');
            angular.forEach(selectedDetails.files, function (file){
                var selectedEducationDocument = {};
                selectedEducationDocument.ref = {};
                selectedEducationDocument.ref.name = file.documentName;
                selectedEducationDocument.content = file.documentContent;
                selectedEducationDocument.ref.type = file.mimeType;
                scope.selectedFiles.push(selectedEducationDocument);
              });
          }
        };
        scope.removeSelectedFile =  function(selected){
          scope.selectedFiles = scope.selectedFiles.filter(function(removeFile) {
            return (selected.ref.name && (selected.ref.name === removeFile.ref.name)) ? false : true;
          });
          scope.listSelectedFile = scope.selectedFiles;
          scope.selectedComplete();
          scope.documentValidationMessage();
          scope.formValidation.documentTypeValidationVisibility = false;
        };

        scope.clickAddToEduLibList = function(){
          var selectedVal = scope.eduMatformData.dataEduLibList;
          if(selectedVal === '0'){
            return;
          }
          var filteredVal = scope.listEducationalLibrary.filter(function(value){
            if(selectedVal.toString() === value.libraryId.toString()){
              return  true;
            }
          });

          var dataEduLibList = {'libraryId':filteredVal[0].libraryId,'libraryName':filteredVal[0].libraryName};
          var pushState = true;
          if(scope.listEduLibSelc === undefined ||scope.listEduLibSelc.length === 0 ){
            scope.listEduLibSelc.push(dataEduLibList);
          }else if(scope.listEduLibSelc.length > 0){
            angular.forEach(scope.listEduLibSelc,function(element) {
              if(dataEduLibList.libraryId === element.libraryId){
                pushState = false;
              }
            });
            if(pushState){
              scope.listEduLibSelc.push(dataEduLibList);
            }
          }
          scope.documentValidationMessage();
        };

        scope.clickRemoveEduLibList = function(){
          angular.element('.tooltip-inner').hide();
          var modifiedData = [];
          angular.forEach(scope.eduMatformData.dataEduLibListSelected, function(item){
            if(!angular.isObject(item)){
              modifiedData.push(JSON.parse(item));
            }
            else
            {
              modifiedData.push(item);
            }
          });
          scope.eduMatformData.dataEduLibListSelected = modifiedData;
          var dataEduLibListSelected = scope.eduMatformData.dataEduLibListSelected;
          var pushState =false;

          scope.listEduLibSelc = scope.listEduLibSelc.map(function(optionItem) {
            pushState = false;
            angular.forEach(dataEduLibListSelected,function(element) {
              if(optionItem.libraryId === element.libraryId){
                pushState = true;
              }
            });
            return (pushState) ? null : optionItem;
          });

          scope.listEduLibSelc = scope.listEduLibSelc.filter(function(optionItem) {
            return (optionItem === null) ? false : true;
          });
          scope.selectedComplete();
          if(scope.eduMatformData.dataEduLibListSelected.length === 1){
            scope.eduMatformData.dataEduLibListSelected = null;
          }
          scope.documentValidationMessage();
        };

        scope.getPatientLibraries =  function () {
          if(scope.listEducationalLibrary.length === 0){
            http.get(app.api.root+'patient-libraries')
              .success(function (data) {
                scope.listEducationalLibrary = [{'libraryId':0,'libraryName':'Select'}].concat(data.results);
              })
              .error(function () {
                scope.listEducationalLibrary=scope.listEducationalLibrary;
              });
          }
          
          scope.formValidation.educationalAddVisibility = true;
          scope.formValidation.educationalMaterialAddVisibility = false;
        };
          
        scope.init = function(){
          scope.patientid=patientData.id;
          scope.getPatientLibraries();
          scope.populateSelectedDetails();
        };

        scope.$on('wizardOnClose', function() {
          listStateSvc.clear();
          if(app !== undefined && app.currentRoute !== undefined) {
            location.path(app.currentRoute +'/');
          }
          else{
            location.path('/');
          }
        });

        scope.$watch('selectEducationMaterialForm.$pristine', function () {
          if (scope.selectEducationMaterialForm && !scope.selectEducationMaterialForm.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$watch('eduLibListSelected', function () {
					var taskType = currentListState.CurrentUIState.currentTaskType.name;
          if ( taskType === 'Education Material' && currentListState.CurrentUIState.currentTaskName) {
            scope.documentValidationMessage();
          }
        });
      }]);
  }(window.app));