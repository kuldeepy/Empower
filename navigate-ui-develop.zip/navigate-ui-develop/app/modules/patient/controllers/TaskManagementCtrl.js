(function (app) {
    'use strict';

    /* task management controller defination */
    app.controller('TaskManagementCtrl', ['$scope', '$http', 'PatientData', 'authSvc', 'parseToZipFile', 'patientTaskSvc', 'goalsSvc', '$modal', '$timeout', 'navConstantsSvc', function (scope, http, patientData, authSvc, zipFile, patientTaskSvc, goalsSvc, $modal, $timeout, navConstantsSvc) {

        /* variable declarations */
      scope.controllerData = {
        isSaved: false,
        taskNotes : '',
        patientNotes : [],
        dateEntered : new Date(),
        taskNotesPrint : ''
      };

      scope.patientid = patientData.id;
      scope.patientData = '';
      scope.notesData = {};
      scope.hasEditAccess = authSvc.hasEditAccess();
      scope.showSendNotesPdf = app.sendNotesPdf;
      scope.totalServerItems = 0;
      scope.invalidateNoteErrorMessage = 'Are you sure you want to mark the Patient Note as Invalid?';
      scope.patientsNotesEnteredBy = authSvc.user().providerName ;
      scope.pagingOptions = {
        pageSize: 10,
        pageSizes: [5, 10, 15],
        currentPage: 1
      };
      
      scope.noteIsOpen = false;


       /* initialize method which is called when this controller is loaded */
      scope.initialize = function () {
        scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber, { noteState: 'A'});
        scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber, { noteState: 'I'});
        scope.getPatientData();
        scope.getPatientNoteInvalidateReason();
      };
      
      scope.otherReasonDescription = navConstantsSvc.otherReasonDescription;

      scope.$on('getNotesCallback' ,function(event, args){
        scope.getNotesGridData(args.pageSize, args.pageNumber, args.params);
        event.stopPropagation();
      });

      scope.getNotesGridData = function (pageSize, pageNumber, params) {

          http({
            method: 'GET',
            url: app.api.root+'patients/'+ scope.patientid +'/notes',
            params: { pageSize: pageSize, pageNumber: pageNumber, noteState: params.noteState }
          }).success(function(data){
            if(data.results.NoteState === 'A'){
              scope.isValidPatientNotes = data.results.PatientNotes;
              scope.totalValidNoteCollection = data.results.PatientNotesCount;
            }
            else if(data.results.NoteState === 'I'){
              scope.isInvalidPatientNotes = data.results.PatientNotes;
              scope.totalInValidNoteCollectionLength = data.results.PatientNotesCount;
            }
            else{
              scope.controllerData.patientNotes = data.results.PatientNotes;
              scope.isValidPatientNotes = _.filter(scope.controllerData.patientNotes, function (element) {
                return (element.isInvaild === false);
              });
              scope.isInvalidPatientNotes = _.filter(scope.controllerData.patientNotes, function (element) {
                return (element.isInvaild === true);
              });
              scope.totalValidNoteCollection = scope.isValidPatientNotes.length;
              scope.totalInValidNoteCollectionLength = scope.isInvalidPatientNotes.length;
            }
          }).catch(function(){
            scope.controllerData.isSaved = false;
          });

         
        };

      scope.getPatientNoteForPrint = function (notesId) {
          goalsSvc.getPatientNotesByNoteId(patientData.id, notesId).then(function (response) {
              scope.items = [{ 'label': 'Date Entered:', 'val': response.data.results.dateEntered },
                             { 'label': 'Entered By:', 'val': response.data.results.enteredBy },
                             { 'label': 'Patient Notes:', 'val': response.data.results.notes }];

              scope.controllerData.taskNotesPrint = response.data.results.notes;
              scope.controllerData.dateEntered = response.data.results.dateEntered;
              var userDetails = authSvc.user();
              if (userDetails.role === 'Care Manager' || userDetails.role === 'Administrator') {
                scope.items.push({ 'label': 'Access:', 'val': true });
              }
            }).catch(function () {
              scope.controllerData.isSaved = false;
            });
        };

      scope.getPatientData = function () {
          http({
            method: 'GET',
            url: app.api.root + 'patients/' + patientData.id
          })
          .success(function (data) {
            
            scope.patientData = data.results;

            if(data.results.Gender==='F')
            {
              scope.patientData.gender = 'Female';
            }
            else if(data.results.Gender==='M')
            {
              scope.patientData.gender = 'Male';
            }

            if( angular.isDefined(data.results.middleName)){
              scope.patientData.middleName = '';
            }

          })
          .error(function () {
            scope.controllerData.isSaved = false;
          });
        };

      scope.getPatientNoteInvalidateReason = function () {
          patientTaskSvc.getPatientNoteInvalidateReason().then(function (data) {
            scope.PatientNoteInvalidateReasonData = data.data.results;
          });
        };

      scope.popupAction = function () {
          scope.modalInstance = $modal.open({
              templateUrl: 'markAsInvalidNoteConfirm.html',
              size: '',
              scope: scope,
              backdrop: 'static'
            });
        };

      scope.closeInvalidatePatientNotePopup = function () {
          scope.modalInstance.close(true);
        };

      scope.validateDisenrollmentType = function (value) {
        if (value === '') {
          scope.isComment = true;
          scope.isSave = true;
        }
        else {
          scope.conversionToJSONObj = JSON.parse(value);
          value = scope.conversionToJSONObj;
          if (value.reason === 'Other') {
            if(scope.PatientNoteInvalidateReason.reason !== undefined){
              scope.PatientNoteInvalidateReason.reason = '';
            }
            scope.isComment = false;
            scope.isSave = true;
          } else {
            scope.isComment = true;
            scope.isSave = false;
          }
        }
      };

      scope.validateComment = function (comment) {
        if (comment) {
          scope.patientNotevalidateComment = comment;
          scope.isSave = false;
        } else {
          scope.isSave = true;
        }
      };


      scope.clickMarkAsInvalid = function (noteData) {
        scope.PatientNoteInvalidateReason = {};
        scope.isComment = true;
        scope.markAsInvalidNoteData = {'invalidNoteData': noteData};
        scope.popupAction();
        scope.isSave = true;
      };

      scope.markAsInvalid = function (patientNoteData) {
        patientTaskSvc.putPatientNote(patientData.id, patientNoteData).then(function () {
          scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber, { noteState: 'A'});
          scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber, { noteState: 'I'});
          scope.closeInvalidatePatientNotePopup();
          scope.invalidateNotesMessage = 'Patient Notes have been marked as invalid successfully.';
          scope.isSendToEmrValid = true;
          $timeout(function () { scope.isSendToEmrValid = false; }, 6000);
        });
      };

      scope.confirmMarkAsInvalid = function (type) {
        scope.conversionToJSONObjData = JSON.parse(type);
        var patientNoteData = { 'isInvaild': true, 'patientNotesId': scope.markAsInvalidNoteData.invalidNoteData.notesId, 'reason': scope.conversionToJSONObjData.reasonId === 3 ? scope.patientNotevalidateComment : scope.conversionToJSONObjData.reason, 'reasonId': scope.conversionToJSONObjData.reasonId };
        scope.markAsInvalid(patientNoteData);
      };

      scope.isSendToEmrInvalidate = false;
      scope.isSendToEmrValid = false;

      scope.sendToEmr = function (noteData, value) {
          scope.successMessageType = value;
          $.get('/themes/default/pdf_notes.css', function (data) {
              var htmlNotes = '<html><head><title>Goals</title><style>' + data + '</style></head><body>' + $('#printable').html() + '</body></html>';
              var base64EncodedZippedFile = zipFile.getBase64EncodedZippedFile('htmlContent.html', htmlNotes);
              var patientNoteData = { 'note': noteData.notes, 'HtmlData': base64EncodedZippedFile, 'isResend': true, 'PatientNotesId': noteData.notesId, 'isSendToEMR' : true };
              patientTaskSvc.postPatientNote(patientData.id, patientNoteData).success(function () {
                if (scope.successMessageType === true) {
                  scope.sendToEmrInvalidNoteMessage = 'Invalid Patient Note sent to EMR successfully.';
                  scope.isSendToEmrInvalidate = true;
                  $timeout(function () { scope.isSendToEmrInvalidate = false; }, 6000);
                }
                if (scope.successMessageType === false) {
                  scope.invalidateNotesMessage = 'Patient Note sent to EMR successfully.';
                  scope.isSendToEmrValid = true;
                  $timeout(function () { scope.isSendToEmrValid = false; }, 6000);
                }
              }).error(function (err) {
                scope.controllerData.taskNotes = '';
                if (err.message) {
                  scope.patientMCtrl.errorNotification = navConstantsSvc.patientNoteErrorMessage;
                }
              });
            });
        };

      scope.copyNotesData = function(){
        scope.controllerData.taskNotesPrint = angular.copy(scope.controllerData.taskNotes);
        scope.controllerData.dateEntered =  new Date();
      };

      var getTasksHtml = function(data){
        // read configuration
        var contents = '';
        contents += '<html><head><title>Goals</title>';
        contents += '<style>';
        contents += data;
        contents += '</style>';
        contents += '</head><body>';
        contents += $('#pdfNotesContent').html();
        contents += '</body></html>';
        return contents;
      };

    /* savePatientNotes method which is called when save button is invoked */
      scope.savePatientNotes = function (sendToEMR) {
        if(scope.controllerData.taskNotes === undefined || scope.controllerData.taskNotes === '')
        {
          scope.controllerData.isSaved = false;
          return;
        }
      
        if(sendToEMR){
          scope.saveNotesMessage = 'Patient Note saved and sent to EMR successfully.';
        }else{
          scope.saveNotesMessage = 'Note has been added successfully.';
        }
        

        scope.notesData.data = {'dateEntered': new Date() ,'enteredBy': authSvc.user().providerName,'notes': scope.controllerData.taskNotesPrint};
        $.get('/themes/default/pdf_notes.css', function(data) {
          var htmlNotes = '';
          if (app.sendNotesPdf) {
            htmlNotes = getTasksHtml(data);
          }
          var base64EncodedZippedFile = zipFile.getBase64EncodedZippedFile('htmlContent.html', htmlNotes);

          http({
            method: 'POST',
            url: app.api.root+'patients/'+ scope.patientid +'/notes',
            data:
              {
                'note':scope.controllerData.taskNotes,
                'HtmlData':base64EncodedZippedFile,
                'isResend' : false,
                'isSendToEMR' : sendToEMR

              }

            }).
            success(function () {
              scope.ShowNotificationAfterSave();

              scope.controllerData.taskNotes = '';
            }).
            error(function (err) {
              scope.controllerData.isSaved = false;
              scope.controllerData.taskNotes = '';
              scope.patientMCtrl.errorNotification = err.message;
              scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber, { noteState: 'A'});
              scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber, { noteState: 'I'});
            });
        });
      };


      /* ShowNotificationAfterSave method which is called after save is success to show the save message */
      scope.ShowNotificationAfterSave = function () {
        window.scrollTo(0, 0);
        scope.controllerData.isSaved = true;
        window.setTimeout(function() {
                scope.$apply(function() {
                    scope.controllerData.isSaved = false;
                  });
              }, 6000);
        scope.initialize();
      };

    }]);

    app.controller('ModalInstanceCtrl', ['$scope','$http', '$modalInstance', 'items','parseToZipFile', function (scope,http,modalInstance,items,zipFile) {

      scope.items = items;
      scope.selected = {
        item: scope.items[0]
      };

      /* cancel method which is called when click on close icon. */
      scope.cancel = function () {
        modalInstance.dismiss('cancel');
      };

      scope.resendPdfToEmr = function(){
        $.get('/themes/default/pdf_notes.css', function(data) {
          var htmlNotes = '<html><head><title>Goals</title><style>' + data + '</style></head><body>'+ $('#printable').html() +'</body></html>';
          var base64EncodedZippedFile = zipFile.getBase64EncodedZippedFile('htmlContent.html', htmlNotes);
          http({
            method: 'POST',
            url: app.api.root+'patients/'+ modalInstance.patientid +'/notes',
            data: {'note':modalInstance.notes, 'HtmlData':base64EncodedZippedFile, 'isResend' : true, 'PatientNotesId' : modalInstance.PatientNotesId}
          }).
          success(function () {
            scope.cancel();
          });
        });
      };

    }]);

    app.controller('ModalWinCtrl', ['$scope', '$modal', '$http','authSvc', function (scope,modal,http,authSvc) {

      scope.items = [];
      
      /* open method which is called when click on summary icon. */
      scope.open = function (size,notesId) {
        http({
            method: 'GET',
            url: app.api.root+'patients/'+ scope.patientid +'/notes/'+notesId
          })
          .success(function (data) {
            scope.notesData.data  = data.results;
            scope.items = [{'label':'Date Entered:','val':data.results.dateEntered},
                         {'label':'Entered By:','val':data.results.enteredBy},
                         {'label':'Patient Notes:','val':data.results.notes}];
            var userDetails = authSvc.user();
            if(userDetails.role === 'Care Manager' || userDetails.role === 'Administrator'){
              scope.items.push({'label':'Access:','val':true});
            }
            scope.controllerData.taskNotesPrint = data.results.notes;
            scope.controllerData.dateEntered =  data.results.dateEntered;

            var modalInstance = modal.open({
                templateUrl: 'patientNotes.html',
                controller: 'ModalInstanceCtrl',
                size: size,
                resolve: {
                    items: function () {
                        return scope.items;
                      }
                  },
                  backdrop: 'static',
                  keyboard: false
                });
            modalInstance.patientid = scope.patientid;
            modalInstance.notes = data.results.notes;
            modalInstance.PatientNotesId = notesId;
            modalInstance.result.then(function (selectedItem) {
                scope.selected = selectedItem;
              }, function () {

            });
          })
          .error(function () {
            scope.controllerData.isSaved = false;
          });
      };
    }]);
  }(window.app));