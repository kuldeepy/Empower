(
  function (app) {
    'use strict';
    app.controller('educationCtrl', ['$scope', '$http', '$window', 'PatientData', 'httpRequestSvc', 'authSvc',
        function (scope, http, window, patientData, httpRequestSvc, authSvc) {
        scope.listEducationalLibrary = [];
        scope.pageTitle = 'Education Material Details';
        scope.hasEditAccess = authSvc.hasEditAccess();
        scope.change = function() {
          scope.formValidation.addEduDueDateVisibility = false;
        };

        scope.controllerData = {
          isError : false
        };

        scope.eduMatformData = {
          'dataEduLibtask':null,
          'dataEduLibDueDate':null,
          'dataEduLibList':null,
          'dataEduLibListSelected':null,
          'dataManagedPopulation':null,
          'addEduDueDatePopUp':false,
          'formValidState':false
        };

        scope.formValidation = {
          'addEduDueDateVisibility':false,
          'educationalAddVisibility':false,
          'educationalMaterialAddVisibility':true,
          'documentTypeValidationVisibility':false,
          'formInvalidMsg':false,
          'fileSizeValidationVisibility': false,
          'totalFileSizeValidationVisibility':false
        };

        //Date related stuff
        scope.dateOptions = {
          formatYear: 'yy',
          startingDay: 1
        };

        scope.formats = ['MM-dd-yyyy','dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
        scope.format = scope.formats[0];
        scope.minDate = new Date();
        scope.maxDate = window.moment().add('months', 24).format('YYYY-MM-DD');//2015-06-22

        scope.openDatePicker = function(event) {
          event.preventDefault();
          event.stopPropagation();
          if(scope.eduMatformData.dataEduLibDueDate === null) {
            scope.eduMatformData.dataEduLibDueDate = new Date();
          }
          scope.eduMatformData.addEduDueDatePopUp = true;
        };

        scope.filesFrUpload = [];
        scope.popup = false;
        scope.addPopup = false;
        scope.selectPopulation = 'This a sample text';

        scope.button ={
            addNewText : 'Document link',
            cancelText : 'Cancel',
            saveText   : 'Save',
            closeText  : 'Close',
            addText    : 'Add'
          };
        scope.listManagedPopulation = [];
        scope.PatientEducationMaterials =[];
        scope.gridDocumentData = [];
        scope.selectedFiles = [];
        scope.readMethod = 'readAsDataURL';

        scope.onReaded = function( e, file ){
            if( (file.size > 0) &&  (file.size >= scope.fileUploadSize))
            {
              scope.formValidation.fileSizeValidationVisibility = true;
              return;
            }
            else
            {
              scope.formValidation.fileSizeValidationVisibility = false;
              scope.selectedFiles.push({'ref':file,'content':e.target.result});
            }
          };

        scope.fileExtensionSupported = function(fileExtension){
            var isPDF = fileExtension.indexOf('pdf');
            var isDOC = fileExtension.indexOf('doc');
            var isTXT = fileExtension.indexOf('txt');
            var isJPG = fileExtension.indexOf('jpg');
            var isJPEG = fileExtension.indexOf('jpeg');
            if (isPDF >= 0 || isDOC >= 0 || isTXT >=0 || isJPG >= 0 || isJPEG >= 0)
            {
              return 0;
            }
            else{
              return 1;
            }
          };

        scope.notification = {
            visible: false,
            type: 'success',
            message: 'Education Material has been added successfully.',
          };
        var fileName ='';
        scope.notifications = {
            visible: false,
            type: 'danger',
            message: 'The file "' + fileName + '" is too large to view. Please download.',
          };

        scope.listEduLibSelc = [];
        scope.filterOptions = {
            filterText: '',
            useExternalFilter: true
          };

        scope.totalServerItems = 0;

        scope.site = {year : new Date().getFullYear()};
        scope.hasItems = false;
        scope.addNew = false;

        scope.frmEduLibUploadCommit = function (elm) {
          if(elm && elm.eduLibFrm && elm.eduLibFrm.$valid === false){
            scope.formValidation.formInvalidMsg = true;
            window.setTimeout(function() {
              scope.$apply(function() {
                scope.formValidation.formInvalidMsg = false;
              });
            }, 5000);
            return false;
          }

          scope.listSelectedFile = [];
          var  fileName={};
          var count=0;
          var totalSize = 0;
          angular.forEach(scope.selectedFiles, function (file){
            count= count+ scope.fileExtensionSupported(file.ref.name.substr(file.ref.name.lastIndexOf('.') + 1).toLowerCase());
          });
          angular.forEach(scope.selectedFiles, function (file){
            totalSize = totalSize + file.ref.size;
          });

          if( (totalSize > 0) && (totalSize >= scope.totalFileUploadSize))
          {
            scope.formValidation.totalFileSizeValidationVisibility = true;
            return;
          }
          if(count !== 0 && scope.selectedFiles.length !== 0){
            scope.formValidation.documentTypeValidationVisibility = true;
            return;
          }
          else if(scope.listEduLibSelc.length === 0 && scope.selectedFiles.length === 0){
            scope.formValidation.totalFileSizeValidationVisibility = false;
            scope.formValidation.fileSizeValidationVisibility  = false;
            return;
          }

          angular.forEach(scope.selectedFiles, function (file){
            fileName = {
            };

            fileName.documentContent = file.content;
            fileName.mimeType = file.ref.type;
            fileName.documentName = file.ref.name;
            scope.listSelectedFile.push(fileName);
          });
          scope.listSelectedLibrary = [];
          var  library=[];

          angular.forEach(scope.listEduLibSelc, function (lib){
            library.push(lib.libraryId.toString());
          });
          if(window.moment(scope.eduMatformData.dataEduLibDueDate).isValid() === false){
            scope.formValidation.addEduDueDateVisibility = true;
            return;
          }
          scope.formValidation.addEduDueDateVisibility = false;
          http({
            method: 'POST',
            url: app.api.root+'patients/'+scope.patientid+'/educational-materials',
            data: { model: {
              'taskName':scope.eduMatformData.dataEduLibtask,
              'dueDate':window.moment(scope.eduMatformData.dataEduLibDueDate).format('MM/DD/YYYY'),
              'population':scope.eduMatformData.dataManagedPopulation,
              'library':library//scope.listSelectedLibrary
            }, files: scope.listSelectedFile
            }
          }).
          success(function () {
            scope.notification.visible=true;
            scope.openDialog();
            scope.popupAction('addEducationMaterial', 'hide');
            scope.ClearPopUp();
            patientData.isMenuDirty = true;
          }).error(function (errorMessage) {
              scope.setErrorNotification = errorMessage.message;
            });
        };

        scope.removeSelectedFile =  function(selected){
          scope.selectedFiles = scope.selectedFiles.filter(function(removeFile) {
            return (selected.ref.name && (selected.ref.name === removeFile.ref.name)) ? false : true;
          });
          scope.formValidation.documentTypeValidationVisibility = false;
          scope.formValidation.totalFileSizeValidationVisibility = false;
          scope.formValidation.fileSizeValidationVisibility  = false;
        };

        scope.clickAddToEduLibList = function(){
          var selectedVal = scope.eduMatformData.dataEduLibList;
          if(selectedVal === '0'){
            return;
          }
          var filteredVal = scope.listEducationalLibrary.filter(function(value){
            if(selectedVal.toString() === value.libraryId.toString()){
              return  true;
            }
          });

          var dataEduLibList = {'libraryId':filteredVal[0].libraryId,'libraryName':filteredVal[0].libraryName};
          var pushState = true;
          if(scope.listEduLibSelc.length === 0){
            scope.listEduLibSelc.push(dataEduLibList);
          }else if(scope.listEduLibSelc.length > 0){
            angular.forEach(scope.listEduLibSelc,function(element) {
              if(dataEduLibList.libraryId === element.libraryId){
                pushState = false;
              }
            });
            if(pushState){
              scope.listEduLibSelc.push(dataEduLibList);
            }
          }
        };

        scope.clickRemoveEduLibList = function(){
          angular.element('.tooltip-inner').hide();
          var modifiedData = [];
          _.forEach(scope.eduMatformData.dataEduLibListSelected, function(item){
            modifiedData.push(JSON.parse(item));
          });
          scope.eduMatformData.dataEduLibListSelected = modifiedData;
          var dataEduLibListSelected = scope.eduMatformData.dataEduLibListSelected;
          var pushState =false;

          scope.listEduLibSelc = scope.listEduLibSelc.map(function(optionItem) {
            pushState = false;
            angular.forEach(dataEduLibListSelected,function(element) {
              if(optionItem.libraryId === element.libraryId){
                pushState = true;
              }
            });
            return (pushState) ? null : optionItem;
          });

          scope.listEduLibSelc = scope.listEduLibSelc.filter(function(optionItem) {
            return (optionItem === null) ? false : true;
          });

          if(scope.eduMatformData.dataEduLibListSelected.length === 1){
            scope.eduMatformData.dataEduLibListSelected = null;
          }
        };

        scope.openDocDetailsWindow = function(){
          scope.popup = true;
          scope.notification.visible = false;
          scope.notifications.visible = false;
          scope.formValidation.educationalAddVisibility = false;
          scope.formValidation.educationalMaterialAddVisibility = true;
        };

        scope.closeDialogWindow = function(){
            scope.ClearPopUp();
            scope.popup = false;
            scope.notification.visible = false;
            scope.notifications.visible = false;
          };

        //PopUp Class Name
        scope.PopUpClassName = {
            DocumentClassName: 'addEducationMaterialDocument',
          };

        //open EducationMaterial popup
        scope.openDocModalPopup = function (className) {
            resetFormValidation();
            scope.getlibraryData();
            scope.getManagedPopulationData();
            scope.popupAction(className, 'show');
            scope.isCancelAlertVisible = false;
          };

        //class Name For PopUp
        scope.popupAction = function (className, action) {
            scope.eduLibFrm.$setPristine();
            if (action === 'show') {
              $('.' + className + '').modal({
                  backdrop: 'static',
                  keyboard: false
                });
            } else {
              $('.' + className + '').modal('' + action + '');
            }
          };

        //Close EducationMaterial Popup
        scope.closeEducationPopup = function (className) {
            scope.popupAction(className, 'hide');
            scope.notifications = { visible: false };
            scope.ClearPopUp();
          };

        //Close EducationMaterial Pop-Up
        scope.closeEducationMaterialPopup = function (show) {
            if (scope.eduLibFrm.$pristine === true) {
              scope.closeEducationPopup('addEducationMaterial');
            } else {
              scope.isCancelAlertVisible = show;
            }
          };

        //show Cancel Alert
        scope.showCancelAlert = function (show) {
            scope.isCancelAlertVisible = show;
          };

        // GET Method libraryData
        scope.getlibraryData = function () {
            var requestpath = 'patient-libraries';
            httpRequestSvc.getRequest(requestpath).then(function (response) {
                if (response.data.results) {
                  scope.listEducationalLibrary = (response.data.results);
                }
              });
          };

        // GET Method ManagedPopulationData
        scope.getManagedPopulationData = function () {
            var requestpath = 'patients/' + scope.patientid + '/patient-populations?type=populations';
            httpRequestSvc.getRequest(requestpath).then(function (response) {
                if (response.data.results) {
                  scope.listManagedPopulation = response.data.results;
                }
              });
          };

        // GET Method ManagedPopulationData
        scope.getEducationDocumentData = function (className, educationId) {
            scope.fileSize = '';
            scope.eduId = educationId;
            var requestpath = 'patients/' + scope.patientid + '/educational-materials/' + educationId + '/documents';
            httpRequestSvc.getRequest(requestpath).then(function (response) {
                if (response.data.results) {
                  scope.eduDocData = response.data.results;
                  scope.popupAction(className, 'show');
                  window.setTimeout(function () {
                      $(window).resize();
                      $(window).resize();
                    }, 100);
                }
                
              });
          };

            //close the popup
        scope.openDialog = function (fileName) {
            window.scrollTo(0, 0);
            if (fileName !== undefined) {
              scope.notifications = {
                visible: true,
                message: 'The file "' + fileName + '" is too large to view. Please download.'
              };
            } else {
              scope.popup = false;
              scope.addPopup = false;
              scope.notification.visible = true;
            }
            window.setTimeout(function () {
                scope.$apply(function () {
                  scope.notification.visible = false;
                  scope.notifications.visible = false;
                });
              }, 6000);
            scope.init();
          };

        scope.ClearPopUp = function () {
          scope.listEduLibSelc = [];
          scope.eduMatformData.dataEduLibtask = null;
          scope.eduMatformData.dataEduLibDueDate = null;
          scope.eduMatformData.dataEduLibList = null;
          scope.eduMatformData.dataEduLibListSelected = null;
          scope.eduMatformData.dataManagedPopulation = null;
          scope.selectedFiles = [];
          scope.formValidation.formInvalidMsg = false;
          scope.formValidation.documentTypeValidationVisibility = false;
        };

        scope.columnsSelected = [{ field: 'taskName', displayName: 'Task Name', columnClass: 'table-column-name' }, { field: 'dueDate', displayName: 'Due Date', columnClass: 'table-column-date' }, { field: 'managePopulation', displayName: 'Managed Population', columnClass: 'table-column-name' }, { field: 'documentCount', displayName: 'No. of Documents', columnClass: 'table-column-action' }];
        scope.columnsSelectedForPopup = [{ field: 'documentName', displayName: 'Document Name', columnClass: 'table-column-name' }, { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false }];

        scope.init = function () {
          scope.patientid = patientData.id;
          http.get(app.api.root+'patients/'+scope.patientid+'/educational-materials')
            .success(function (data) {
              scope.PatientEducationMaterials=data.results;
            });
        };

        scope.base64ToUint8Array=function(base64) {
          var raw = window.atob(base64); //This is a native function that decodes a base64-encoded string.
          var uint8Array = new Uint8Array(new ArrayBuffer(raw.length));
          for(var i = 0; i < raw.length; i = i+1) {
            uint8Array[i] = raw.charCodeAt(i);
          }
          return uint8Array;
        };

        //Method for document download
        scope.documentDownload = function (documentIDtest, row) {
            http.get(app.api.root + 'patients/' + scope.patientid + '/educational-materials/' + scope.eduId + '/documents/' + documentIDtest + '?type=' + angular.lowercase(row.type))
           .success(function (data) {
                var fileName = data.results.documentName;
                var contentType = data.results.mimeType;
                var content = data.results.content;
                scope.saveData(content, contentType, fileName);
              });
          };

        scope.saveData = function (content, contentType, fileName) {
            var test = scope.base64ToUint8Array(content);
            var blob = new Blob([test], { type: contentType });
            saveAs(blob, fileName);
          };

        //Method for document View
        scope.documentView = function (documentIDtest, row) {
            http.get(app.api.root + 'patients/' + scope.patientid + '/educational-materials/' + scope.eduId + '/documents/' + documentIDtest + '?type=' + angular.lowercase(row.type))
            .success(function (data) {
              var results = data.results.content;
              var contentType = data.results.mimeType;
              var byteCharacters = atob(results);
              var byteNumbers = new Array(byteCharacters.length);
              for (var i = 0; i < byteCharacters.length;  i = i+1) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
              }
              var blob = b64toBlob(results, contentType);
              var blobUrl = window.URL.createObjectURL(blob);
              window.open(blobUrl, '_blank', '');
            });
          };

        function b64toBlob(b64Data, contentType, sliceSize) {
          contentType = contentType || '';
          sliceSize = sliceSize || 512;
          var byteCharacters = atob(b64Data);
          var byteArrays = [];
          for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i = i+1) {
              byteNumbers[i] = slice.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
          }

          var blob = new Blob(byteArrays, {type: contentType});
          return blob;
        }

        function resetFormValidation(){
          scope.formValidation = {
              'addEduDueDateVisibility':false,
              'educationalAddVisibility':false,
              'educationalMaterialAddVisibility':true,
              'documentTypeValidationVisibility':false,
              'formInvalidMsg':false,
              'fileSizeValidationVisibility': false,
              'totalFileSizeValidationVisibility':false
            };
        }

      }]);
  }(window.app));