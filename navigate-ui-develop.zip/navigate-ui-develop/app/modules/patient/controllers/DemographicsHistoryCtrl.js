(function (app) {
    'use strict';
    app.controller('demographicHistoryCtrl', ['$scope', 'PatientData','patientDemographicsHistorySvc','_','authSvc','$modal','$timeout',
        function (scope, patientData,patientDemographicsHistorySvc,_,authSvc,$modal,timeout) {
            scope.user = authSvc.user();
            scope.hasEditAccess = authSvc.hasEditAccess();
            scope.pageTitle = 'Patient Demographic History';
            scope.alertMessage = 'Patient Demographics details has been updated successfully.';
            scope.demographicData = [];
            scope.demographicHistoryData = [];
            scope.pageSize = 5;
            scope.page = 1;
            scope.maxDate = new Date();

            scope.demographic = {
                columns : ['Favorite', 'Source', 'Last Updated On/ By', 'Name', 'DOB','Gender','Phone Numbers','Emails','Address']
              };

            scope.getDemographic = function(){
                patientDemographicsHistorySvc.getPatientDemographics(patientData.id)
                .then(function(response){
                  if(response.data.results){
                    scope.demographicData = response.data.results;
                    var count=_.where(scope.demographicData,{'favourite':true});
                    if(count.length === 0){
                      scope.demographicData[0].favourite = true;
                    }
                  }
                });
              };
            patientDemographicsHistorySvc.getCountries()
              .then(function(response){
                scope.countries = response.data.results;
              });
            patientDemographicsHistorySvc.getStates()
            .then(function(response){
              scope.states = response.data.results;
            });
            scope.getDemographic();
            scope.changeFavorite = function(item){
              patientDemographicsHistorySvc.putPatientDemographicsFavorite(patientData.id,item.historyId)
                .then(function(){
                  scope.getDemographic();
                  patientData.isFavoriteFlag = true;
                  patientData.isMenuStatus = false;
                });
            };
            scope.openUpdateDemographicsPopuUp = function(){
              patientDemographicsHistorySvc.getPatientDemographicData(patientData.id)
              .then(function(response){
                scope.demographics = response.data.results[0];
                scope.demographics.dateOfBirth = moment(scope.demographics.dateOfBirth).format('MM/DD/YYYY');
                /*Chrome Issue*/
                scope.demographics.stateID = scope.demographics.stateID === null ? '' : scope.demographics.stateID;
                scope.demographics.countryID = scope.demographics.countryID === null ? '' : scope.demographics.countryID;
              });
              scope.modalInstance = $modal.open({
                templateUrl: app.root +'templates/patient_demographics.html',
                size: 'lg',
                scope : scope,
                backdrop : 'static',
                keyboard :false
              });
            };
            scope.openDatePicker = function() {
              timeout(function() {
                scope.demographics.openeddemoGraphic = true;
              });
            };
            scope.closePopUp= function(){
              scope.modalInstance.dismiss();
            };
            scope.UpdateDemographics = function(item){
              var data={'firstName' : item.firstName,
                'middleName' : item.middleName,
                'lastName' : item.lastName,
                'dateOfBirth' : moment(item.dateOfBirth).format('MM/DD/YYYY'),'gender' : item.gender,
                'homePhoneNumber' : item.homePhoneNumber,'workPhoneNumber' : item.workPhoneNumber,
                'homeEmailID' : item.homeEmailID,'workEmailID' : item.workEmailID,
                'address' : item.address,'city' : item.city,'stateID' : item.stateID,'countryID' : item.countryID,
                'preferredName' : item.preferredName,
                'zipCode' : item.zipCode, 'providerId' :scope.user.providerId, 'mobileNumber' : item.mobileNumber  };
              patientDemographicsHistorySvc.putPatientDemographicsData(patientData.id,data)
              .then(function(){
                scope.modalInstance.dismiss();
                scope.getDemographic();
                patientData.isFavoriteFlag = true;
                patientData.isMenuStatus = false;
                scope.isAlert = true;
                timeout(function () {scope.isAlert = false;}, 6000);
              });
            };
            scope.homePhoneInput = function(form){
              if(scope.demographics.homePhoneNumber === ''){
                form.homePhone.$setPristine();
                scope.demographics.homePhoneNumber = undefined;
              }
            };
            scope.phoneInput = function(form){
              if(scope.demographics.workPhoneNumber === ''){
                form.workPhone.$setPristine();
                scope.demographics.workPhoneNumber = undefined;
              }
            };
          }]);
  }(window.app));
