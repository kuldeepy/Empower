(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('PatientMedicationCtrl', ['$scope', '$http', 'PatientData',
    function (scope , http, patientData) {
      scope.list = [];
      scope.pagingOptions = {
        pageSizes: [10, 20, 30, 40, 50],
        pageSize: 20,
        currentPage: 1
      };

      function getMedications(id){
        var url = app.api.root + 'patients/' + id + '/medications';
        http.get(url)
        .success(function(data){
          scope.list = _.map(data.results,function(item){
            item.dosage = item.strength + ' ' + item.form + ' ' + item.quantityDispensed + ' times over ' + item.numberOfDays + ' days';
            if(item.datefilled !== undefined && item.datefilled !== null && item.datefilled !== ''){
              item.listDates = item.datefilled.split(',');
              item.listDate = new Date(item.datefilled.split(',')[0]);
            }
            return item;
          });
          scope.list = _.sortBy(scope.list,'prescribedDate').reverse();
        });
      }
       
      getMedications(patientData.id);

      scope.pageTitle = 'Medication Details';
      scope.columnsSelected = [
        {
          field: 'name',
          displayName: 'Medication Name',
          columnClass: 'table-column-name'
        },
        {
          field: 'prescribedDate',
          displayName: 'Prescribed Date',
          columnClass: 'table-column-listDate'
        },
        {
          field: 'listDate',
          displayName: 'Last Filled Date',
          columnClass: 'table-column-listDate'
        },
        {
          field: 'dosage',
          displayName: 'Dosage',
          columnClass: 'table-column-msg-name',
          sortable: false
        },
        {
          field: 'providerName',
          displayName: 'Provider',
          columnClass: 'table-column-name'
        }
      ];
      scope.showAllDates = false;
    }]);
  }(window.app));
