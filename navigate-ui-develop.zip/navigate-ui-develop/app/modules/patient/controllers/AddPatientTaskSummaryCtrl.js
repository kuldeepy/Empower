(function (app) {
		/* @fmt: off */
		'use strict';
		// @fmt:on

		app.controller('AddPatientTaskSummaryCtrl', ['$scope', '$http','listStateSvc','PatientData','$location','$timeout',
		function (scope, http, listStateSvc,patientData,location,timeout) {
					 
			if (scope.initializeStep) {
				scope.initializeStep('addSummaryTask', true);
			}

			var currentListState = {};
			var taskSummary;
			scope.initializeSummary = function() {
				currentListState = listStateSvc.get();
				if(currentListState.CurrentUIState.currentTaskType === undefined){
					return;
				}

				taskSummary = {
					taskType: currentListState.CurrentUIState.currentTaskType.name,
					taskName : currentListState.CurrentUIState.currentTaskName.name,
					dueDate : currentListState.CurrentUIState.currentselectedDueDate ,
					populationProgramName : currentListState.CurrentUIState.currentselectedManagedPopulation.programName,
					files : currentListState.CurrentUIState.currentTaskName.files,
					libraries : currentListState.CurrentUIState.currentTaskName.libraries
				};
				scope.taskSummary = taskSummary;
				scope.showLibraries = (taskSummary.libraries === undefined) ? false : true;
				scope.showDocuments = (taskSummary.files === undefined) ? false : true;
			};

			scope.$on('wizardOnsaveAndClose', function() {
				var currentTaskState = listStateSvc.get();
				var taskToSave = currentTaskState.CurrentUIState.currentTaskType.name;
				if(taskToSave === 'Education Material'){
					scope.SaveEducationTaskType(currentTaskState);
				}
				else{
					scope.SaveTaskType(currentTaskState);
				}
			});
			scope.close = function () {
				listStateSvc.clear();
				if(app !== undefined && app.currentRoute !== undefined) {
					location.path(app.currentRoute +'/');
				}
				else{
					location.path('/');
				}
			};
			scope.SaveEducationTaskType = function(details){
				var  library = [];
				angular.forEach(details.CurrentUIState.currentTaskName.libraries, function (lib){
					library.push(lib.libraryId.toString());
				});
				var educationDetail = {
					taskName : details.CurrentUIState.currentTaskName.name,
					library : library,
					dueDate : details.CurrentUIState.currentselectedDueDate,
					files : details.CurrentUIState.currentTaskName.files,
					population : details.CurrentUIState.currentselectedManagedPopulation.populationId,
				};
				http({
					method: 'POST',
					url: app.api.root+'patients/'+ patientData.id +'/educational-materials',
					data: { model: educationDetail ,
						files : details.CurrentUIState.currentTaskName.files
					}
				}).
				success(function () {
					scope.close();
					patientData.isTaskAddedSuccesfully = true;
				}).
				error(function () {
					patientData.isTaskAddedSuccesfully = false;
				});
			};
			scope.showErrorMessage = function (message) {
				scope.alertMessage = message;
				scope.isError = true;
				timeout(function () {
					scope.isError = false;
				}, 6000);
			};
			scope.SaveTaskType = function(details){
				var currentTaskState = details;
				var taskDetail = {
					taskTypeName:currentTaskState.CurrentUIState.currentTaskType.name,
					name : currentTaskState.CurrentUIState.currentTaskName.name,
					taskSpecificId : currentTaskState.CurrentUIState.currentTaskName.id,
					dateDue : currentTaskState.CurrentUIState.currentselectedDueDate ,
					managedPopulationId : currentTaskState.CurrentUIState.currentselectedManagedPopulation.populationId,
				};
				scope.taskDetail = taskDetail;
				http({
					method: 'POST',
					url: app.api.root + 'patients/' + patientData.id +'/task',
					data: taskDetail
				}).
				success(function(){
					scope.close();
					patientData.isTaskAddedSuccesfully = true;
				}).
				error(function(res){
					scope.showErrorMessage(res.message);
				});
			};
			scope.$on('wizardOnClose', function() {
				scope.close();
			});
		}]);

	}(window.app));