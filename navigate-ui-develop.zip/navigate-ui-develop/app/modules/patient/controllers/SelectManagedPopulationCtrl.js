(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('SelectManagedPopulationCtrl', ['$scope', '$http', 'PatientData', 'listStateSvc','_','$location',
    function (scope, http, patientData, listStateSvc,_,location) {
           
      if (scope.initializeStep) {
        scope.initializeStep('selectManagedPopulation', false);
      }

      var currentListState = listStateSvc.get();

      scope.getManagedPopulations = function (){
        var baseUrl = app.api.root ;
        var url = baseUrl + 'patients/' + patientData.id + '/patient-populations?type=populations';
        http.get(url)
          .success (function (data){
            var results = data.results;
            scope.managedPopulations = results;
            scope.selectedManagedPopulation = _.find(scope.managedPopulations, function (item) {
              return item.populationId === listStateSvc.seletectedPopulation().populationId;
            });

            if (scope.selectedManagedPopulation !== null && scope.selectedManagedPopulation !== undefined && scope.selectedManagedPopulation !== '') {
              scope.completeStep(true,'selectManagedPopulation');
            }

          });
      };

      scope.initializeManagedPopulations = function() {
        scope.getManagedPopulations();
      };

      scope.managedPopulationsChanged = function() {
        if (scope.selectedManagedPopulation !== null && scope.selectedManagedPopulation !== undefined && scope.selectedManagedPopulation !== '') {
          currentListState.CurrentUIState.currentselectedManagedPopulation = scope.selectedManagedPopulation;
          listStateSvc.set(currentListState);
          scope.completeStep(true,'selectManagedPopulation');
        } else {
          scope.completeStep(false,'selectManagedPopulation');
        }
      };

      scope.$on('wizardOnClose', function() {
        listStateSvc.clear();
        if(app !== undefined && app.currentRoute !== undefined) {
          location.path(app.currentRoute +'/');
        }
        else{
          location.path('/');
        }
      });

      scope.$watch('selectManagedPopulationForm.$pristine', function () {
        if (scope.selectManagedPopulationForm && !scope.selectManagedPopulationForm.$pristine) {
          localStorage.setItem('isWizardFormDirty', true);
        }
      });

    }]);

  }(window.app));