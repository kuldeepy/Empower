(
  function (app) {
      /* @fmt: off */
      'use strict';
      // @fmt:on
      app.controller('documentsCtrl', ['$scope', 'PatientData','$timeout','fileReader','$window','patientDocumentSvc', 'authSvc', 'carePlanSvc',
          function (scope,patientData,timeout,fileReader,$window,patientDocumentSvc,authSvc,carePlanSvc) {
              scope.hasEditAccess = authSvc.hasEditAccess();
              var successMessageDoc = 'Document has been added successfully.';
              var carePlanDocument = 'Care Plan';
              scope.isopen=true;
              scope.open = function() {
                    timeout(function() {
                      scope.opened = true;
                    });
                  };
              scope.model = {};
              scope.pageTitle = 'Patient Documents';
              scope.DocumentIndertData={};
              scope.ccdTable ={
                columns : ['Document Category', 'File Name', 'File Type', 'Uploaded On', 'Action']
              };

              scope.pageSize = 5;
              scope.page = 1;
              scope.ccdDocument = 'Request CCD/CDA';

              scope.files = [];
              scope.ccdData = [];

              scope.$on('fileSelected', function (event, args) {
                  scope.$apply(function () {
                      scope.files=(args.file);
                    });
                });
              scope.notification = {
                  visible : false,
                  success : false,
                  failure : false,
                  warning : false,
                  info : false,
                  message : successMessageDoc,
                  status:true,
                  docButton : {
                      yes : 'Yes',
                      no : 'No'
                    }
                  };

              scope.getCommunicationScores=function(){
                patientDocumentSvc.getPatientDocuments(patientData.id)
                .then(function(response){
                  scope.DocumentData= response.data.results;
                  scope.getPagedDataAsyncDoc(scope.pagingOptionsDoc.pageSize, scope.pagingOptionsDoc.currentPage);
                });
              };
              scope.getCommunicationScores();

              scope.filterOptionsDoc = {
                  filterText: '',
                  useExternalFilter: true
                };
              scope.totalServerItemsDoc = 0;
              scope.pagingOptionsDoc ={
                  pageSizes: [5, 10, 15],
                  pageSize: 5,
                  currentPage: 1
                };
              scope.setPagingDataDoc = function (data, page, pageSize) {
                  var pagedData = data.slice((page - 1) * pageSize, page * pageSize);
                  scope.DocumentGridData = pagedData;
                  scope.totalServerItemsDoc = data.length;
                  if (!scope.$$phase) {
                    scope.$apply();
                  }
                };
              scope.getPagedDataAsyncDoc = function (pageSize, page) {
                  setTimeout(function () {scope.setPagingDataDoc(scope.DocumentData, page, pageSize);}, 100);
                };
              scope.$watch('pagingOptionsDoc', function (newVal, oldVal) {
                  if (newVal !== oldVal && newVal.currentPage !== oldVal.currentPage) {
                    scope.getPagedDataAsyncDoc(scope.pagingOptionsDoc.pageSize, scope.pagingOptionsDoc.currentPage, scope.filterOptionsDoc.filterText);
                  }
                }, true);
              scope.$watch('filterOptionsDoc', function (newVal, oldVal) {
                  if (newVal !== oldVal) {
                    scope.getPagedDataAsyncDoc(scope.pagingOptionsDoc.pageSize, scope.pagingOptionsDoc.currentPage, scope.filterOptionsDoc.filterText);
                  }
                }, true);
             
              scope.columnsSelected = [{ field: 'documentCategory', displayName: 'Document Category', columnClass: 'table-column-name' }, { field: 'fileName', displayName: 'File Name', columnClass: 'table-column-name' }, { field: 'filetype', displayName: 'File Type', columnClass: 'table-column-name' }, { field: 'fileSize', displayName: 'File Size(kb)', columnClass: 'table-column-action' }, { field: 'uploadeddate', displayName: 'Uploaded On', columnClass: 'table-column-name' }, { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false }];

              scope.ViewDocument = function(results, contentType){
                var byteCharacters = atob(results);
                var byteNumbers = new Array(byteCharacters.length);
                for (var i = 0; i < byteCharacters.length;  i = i+1) {
                  byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                var blob = b64toBlob(results, contentType);
                var blobUrl = window.URL.createObjectURL(blob);
                window.open(blobUrl, '_blank', '');
              };

              scope.DownloadDocument = function(results, fileName){
                var DocumentBasedata = window.atob(results);
                var htmlText = '<embed width=100% height=100%' + 'type="application/pdf"' + ' src="data:application/pdf,' + escape(DocumentBasedata) + '"></embed>';
                var a = document.createElement('a');
                a.download = fileName;
                a.href = 'data:application/pdf,' + htmlText;
                a.click();
              };

              scope.DocumentView = function(DocumentSelectedData)
              {
                var results = null;
                var contentType  = null;
                if(DocumentSelectedData.documentCategory === carePlanDocument){
                  carePlanSvc.getCarePlanPdf(patientData.id, DocumentSelectedData.patientDocumentID)
                  .then(function(response){
                    results = response.data.results.pdfContent;
                    contentType = 'application/pdf';
                    scope.ViewDocument(results, contentType);
                  });
                }else{
                  patientDocumentSvc.getPatientDocumentDownload(patientData.id, DocumentSelectedData.patientDocumentID)
                  .then(function(response){
                    results = response.data.results[0].documentData;
                    contentType = response.data.results[0].fileType;
                    scope.ViewDocument(results, contentType);
                  });
                }
              };

              scope.DocumentDownload=function(DocumentSelectedData){
                var results = null;
                if(DocumentSelectedData.documentCategory === carePlanDocument){
                  carePlanSvc.getCarePlanPdf(patientData.id, DocumentSelectedData.patientDocumentID)
                  .then(function(response){
                    results = response.data.results.pdfContent;
                    scope.DownloadDocument(results, DocumentSelectedData.fileName);
                  });
                }else{
                  patientDocumentSvc.getPatientDocumentDownload(patientData.id, DocumentSelectedData.patientDocumentID)
                .then(function(response){
                    results = response.data.results[0].documentData;
                    scope.DownloadDocument(results,DocumentSelectedData.fileName);
                  });
                }
              };

              function b64toBlob(b64Data, contentType, sliceSize) {
                contentType = contentType || '';
                sliceSize = sliceSize || 512;
                var byteCharacters = atob(b64Data);
                var byteArrays = [];
                for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                  var slice = byteCharacters.slice(offset, offset + sliceSize);
                  var byteNumbers = new Array(slice.length);
                  for (var i = 0; i < slice.length; i = i+1) {
                    byteNumbers[i] = slice.charCodeAt(i);
                  }
                  var byteArray = new Uint8Array(byteNumbers);
                  byteArrays.push(byteArray);
                }

                var blob = new Blob(byteArrays, {type: contentType});
                return blob;
              }

              scope.docButton ={
                  addNewTextDoc : 'Add Document',
                  cancelText : 'Cancel',
                  saveText : 'Save'
                };

              scope.clickaddnew = function(){
                scope.files = [];
                patientDocumentSvc.getDocumentCategories()
                .then(function(response){
                  scope.DocumentCategory=response.data.results;
                  scope.DocPopup = true;
                  scope.ShowAddDoc=true;
                  scope.ShowAddCom=false;
                  scope.templetview=false;
                  scope.notification.visible = false;
                });
              };
              scope.clickaddnewDocCancel = function(){
                  scope.DocPopup = false;
                  scope.notification.visible = false;
                  $('#uploadFile').val('');
                  scope.DocumentIndertData={};
                };
             
              scope.clickaddnewDocSave=function(SelectedData){
                fileReader.readAsDataUrl(scope.files,scope)
                .then(function(result) {
                  scope.model=result.replace('data:'+scope.files.type+';base64,','');
                  var mimename=scope.files.name.split('.');
                  scope.documentInserteddata= {'documentCategoryId':SelectedData,'documentName':scope.files.name,'documentBody': scope.model, 'documentSizeInBytes': scope.files.size,'documenttype':mimename[1],'mimeType':scope.files.type };
                  var requestpath = 'patients/' + patientData.id + '/documents';
                  patientDocumentSvc.savePatientDocuments(requestpath,scope.documentInserteddata)
                  .then(function(response){
                      if(response.data.results.PatientDocumentId !== -1){
                        patientData.isMenuDirty = true;
                        scope.DocumentIndertData={};
                        patientDocumentSvc.getPatientDocuments(patientData.id).then(function(respon){
                            scope.DocumentData=respon.data.results;
                            scope.getPagedDataAsyncDoc(scope.pagingOptionsDoc.pageSize, 1);
                          });
                        scope.DocPopup = false;
                        $('#uploadFile').val('');
                        scope.showAlert(successMessageDoc,'alert-success');
                      }
                    });
                });
              };
               
              scope.clickgetCcd = function(){
                    patientDocumentSvc.getPatientCcdDocuments(patientData.id)
                .then(function(response){
                      var resultData = response.data.results;
                      scope.ccdData = angular.forEach(resultData,function(data){
                        data.effectiveDateTime = data.effectiveDateTime !== null?moment(data.effectiveDateTime).format('L'):data.effectiveDateTime;
                        data.fileType = 'Pdf';
                      });
                    });
                  };

              scope.showAlert = function (alertmessage, alerttype) {
                window.scrollTo(0, 0);
                scope.alertMessageStyle=alerttype;
                scope.alertMessage = alertmessage;
                scope.isError = true;
                timeout(function () {scope.isError = false;}, 6000);
              };

              scope.onTimeout = function () {
                  scope.notification.visible = false;
                };
              scope.DocPopup = false;
              scope.DocList = function () {
                scope.DocListData = scope.DocListData === true ? false: true;
              };

              scope.ccdDocumentDownload=function(DocumentSelectedData){
                patientDocumentSvc.getPatientCcdDocumentDownload(patientData.id, DocumentSelectedData.fileId)
                .then(function(response){
                  var results = response.data.results.documentData;
                  var DocumentBasedata = window.atob(results);
                  var htmlText = '<embed width=100% height=100%' + 'type="application/pdf"' + ' src="data:application/pdf,' + escape(DocumentBasedata) + '"></embed>';
                  var a = document.createElement('a');
                  a.download = DocumentSelectedData.name;
                  a.href = 'data:application/pdf,' + htmlText;
                  a.click();
                });
              };

              scope.ccdDocumentView=function(DocumentSelectedData)
              {
                patientDocumentSvc.getPatientCcdDocumentDownload(patientData.id, DocumentSelectedData.fileId)
                .then(function(response){
                  var results = response.data.results.documentData;
                  var contentType = response.data.results.fileType;
                  var byteCharacters = atob(results);
                  var byteNumbers = new Array(byteCharacters.length);
                  for (var i = 0; i < byteCharacters.length; i = i+1) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                  }
                  var blob = b64toBlob(results, contentType);
                  var blobUrl = window.URL.createObjectURL(blob);
                  window.open(blobUrl, '_blank', '');

                });
              };
            }]);
      app.directive('fileUpload', function () {
            return {
              scope: true,        //create a new scope
              link: function (scope, el) {
                  el.bind('change', function (event) {
                      var files = event.target.files;
                      //iterate files since 'multiple' may be specified on the element
                      for (var i = 0;i<files.length; i=i+1) {
                          //emit event upward
                        scope.$emit('fileSelected', { file: files[i] });
                      }
                    });
                }
            };
          });
    }(window.app));