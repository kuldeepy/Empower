(function (app) {
  'use strict';
  
  app.controller('AddPatientTaskCtrl', ['$scope',
      function (scope) {
      scope.wizardheader = 'Add Task';
      scope.stepDefinitions = [
        [
          { name: 'selectTaskType', letter: 'a', title: 'Task Type', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false },
          { name: 'selectTaskName', letter: 'b', title: 'Task Name', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false },
          { name: 'selectManagedPopulation', letter: 'c', title: 'Managed Population', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false },
          { name: 'selectDueDate', letter: 'd', title: 'Due Date', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false }
        ],
        [
          { name: 'addSummaryTask', letter: 'a', title: 'Summary', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false }
        ]
      ];

      scope.tabDefinitions = [
        { name: 'selectTaskType', order: '1', number: '1', title: 'Task Type', selectionCss: 'first active', firstCompleted: false, clickable:false, isTabCompleted:false },
        { name: 'addSummaryTask', order: '2', number: '2', title: 'Summary', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false }
      ];

      scope.wizardWorkflow = [
        { 'id': 1, 'name': 'selectTaskType' },
        { 'id': 2, 'name': 'selectTaskName' },
        { 'id': 3, 'name': 'selectManagedPopulation' },
        { 'id': 4, 'name': 'selectDueDate' },
        { 'id': 5, 'name': 'addSummaryTask' }
      ];
    }]);

})(window.app);
