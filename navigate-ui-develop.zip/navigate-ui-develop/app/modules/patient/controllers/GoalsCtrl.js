(function (app) {
  /* @fmt: off */
  'use strict';
  // @fmt:on
  app.controller('patientGoalCtrl', ['$scope', '$timeout', 'PatientData', '$location', 'goalsSvc', 'authSvc', '$modal', 'navConstantsSvc', 'userConcurrentLockSvc', '$http', 'parseToZipFile','patientTaskSvc',
    function (scope, $timeout, patientData, location, goalsSvc, authSvc, modal, navConstantsSvc, userConcurrentLockSvc, http, zipFile, patientTaskSvc) {
      scope.hasEditAccess = authSvc.hasEditAccess();
      scope.pageTitle = '\'s goals';
      scope.firstvalue = false;
      scope.secondvalue = false;
      scope.thirdvalue = false;
      scope.fourthvalue = false;
      scope.fifthvalue = false;
      scope.isPatientNotesSaved = false;
      scope.pageSize = 5;
      scope.page = 1;
      scope.cgPageSize = 5;
      scope.cgPage = 1;
      scope.patientNotespageSize = 5;
      scope.patientNotespage = 1;
      scope.completeActivityData = [];
      scope.goalId = '';
      scope.dueDateCalendar = false;
      scope.minDate = new Date();
      scope.invalidateNoteErrorMessage = 'Are you sure you want to mark the Patient Note as Invalid?';
      scope.noteIsOpen = false;
      scope.patientData = '';
      scope.patientsNotesEnteredBy = authSvc.user().providerName ;
      scope.showSendNotesPdf = app.sendNotesPdf;
      scope.controllerData = {
        isSaved: false,
        taskNotes : '',
        patientNotes : [],
        dateEntered : new Date(),
        taskNotesPrint : ''
      };

      scope.notification = {
        visible : false,
        success : false,
        failure : false,
        message : ''
      };
      scope.totalServerItems = 0;
      scope.pagingOptions = {
        pageSize: 10,
        pageSizes: [5, 10, 15],
        currentPage: 1
      };
      scope.active = navConstantsSvc.active;
      scope.otherReasonDescription = navConstantsSvc.otherReasonDescription;
      scope.getGoalsDetails = function(urlGoalId,taskType){
        goalsSvc.getPatientGoals(patientData.id,'Active').then(function(response){
          if (response.data.results) {
            scope.getOpenGoalsCount =  response.data.results.length;
            scope.calculateGoalPercentage();
            if(urlGoalId > 0)
            {
              scope.goalsData=_.where(response.data.results,{statusCode: scope.active});
              if(taskType === navConstantsSvc.goal){
                scope.IndxCnt =  _.findIndex(scope.goalsData,{goalId:urlGoalId});
              }
              else if(taskType === navConstantsSvc.activity){
                _.forEach(scope.goalsData, function(n, key) {
                    var IndxACnt = _.findIndex(n.patientActivities,{activityId:urlGoalId});
                    if(IndxACnt !== -1){
                      scope.IndxCnt = key;
                    }
                  });
              }
              scope.page = scope.currentPageNumber = Math.ceil((scope.IndxCnt+1)/scope.pageSize);
              scope.goalsData[scope.IndxCnt].isOpen = true;
            }
            else{
              scope.page = scope.currentPageNumber = 1;
            }
            scope.goalsdetails = scope.updateGoalDetails(response.data.results);
          }
        });
      };

      scope.getCompletedGoalsDetails = function(){
        goalsSvc.getPatientGoals(patientData.id,'Complete').then(function(response){
          scope.completedGoalsDetails = scope.updateGoalDetails(response.data.results);
          scope.completedGoalsCount = response.data.results.length;
          scope.isCompletedGoals = scope.completedGoalsCount >= 1 ? true : false;
          scope.calculateGoalPercentage();
        });
      };
      
      scope.updateGoalDetails = function (data) {
        data.forEach (function(item) {
          if(item.patientActivities.length > 0)
          {
            var activies = [];
            item.patientActivities.forEach(function(res){
              activies.push({activityId:res.activityId,activityName:res.activityName,activityTypeId:res.activityTypeId,description:res.description,dueDate:res.dueDate,progressMilestone:res.progressMilestone,goalId:res.goalId,statusCode:res.statusCode,completedDate:res.completedDate,
                firstvalue: (res.progressMilestone > 0 ? true : false),
                secondvalue: (res.progressMilestone > 25 ? true : false),
                thirdvalue: (res.progressMilestone > 50 ? true : false),
                fourthvalue: (res.progressMilestone > 75 ? true : false),
                fifthvalue: (res.progressMilestone === 100 ? true : false),
                milestoneValue0: false,
                milestoneValue25: false,
                milestoneValue50: false,
                milestoneValue75: false,
                milestoneValue100: false
              });
            });
            item.patientActivities = activies;
          }
        });
        return data;
      };

      scope.$on('getNotesCallbackAtGoals' ,function(event, args){
        scope.getNotesGridData(args.pageSize, args.pageNumber, args.params);
        event.stopPropagation();
      });

      scope.getNotesGridData = function (pageSize, pageNumber, params) {
        var queryParams = { pageSize: pageSize, pageNumber: pageNumber, noteState: params.noteState };
        goalsSvc.getPatientNotes(patientData.id, queryParams).then(function(response){
            if(response.data.results.NoteState === 'A'){
              scope.isValidPatientNotes = response.data.results.PatientNotes;
              scope.totalValidNoteCollection = response.data.results.PatientNotesCount;
            }
            else if(response.data.results.NoteState === 'I'){
              scope.isInvalidPatientNotes = response.data.results.PatientNotes;
              scope.totalInValidNoteCollectionLength = response.data.results.PatientNotesCount;
            }
            else{
              scope.controllerData.patientNotes = response.data.results.PatientNotes;
              scope.isValidPatientNotes = _.filter(scope.controllerData.patientNotes, function (element) {
                return (element.isInvaild === false);
              });
              scope.isInvalidPatientNotes = _.filter(scope.controllerData.patientNotes, function (element) {
                return (element.isInvaild === true);
              });
              scope.totalValidNoteCollection = scope.isValidPatientNotes.length;
              scope.totalInValidNoteCollectionLength = scope.isInvalidPatientNotes.length;
            }
            scope.getPatientData();
          })
        .catch(function(){
          scope.controllerData.isSaved = false;
        });
      };

      scope.getPatientNoteInvalidateReason = function () {
          patientTaskSvc.getPatientNoteInvalidateReason().then(function (data) {
            scope.PatientNoteInvalidateReasonData = data.data.results;
            scope.popupAction();
          });
        };

      scope.popupAction = function () {
        scope.modalInstance = modal.open({
          templateUrl: 'markAsInvalidNoteConfirm.html',
          size: '',
          scope: scope,
          backdrop: 'static'
        });
      };

      scope.closeInvalidatePatientNotePopup = function () {
          scope.modalInstance.close(true);
        };

      scope.validateDisenrollmentType = function (value) {
        if (value === '') {
          scope.isComment = true;
          scope.isSave = true;
        }
        else {
          scope.conversionToJSONObj = JSON.parse(value);
          value = scope.conversionToJSONObj;
          if (value.reason === 'Other') {
            if(scope.disenrollment.reason !== undefined){
              scope.disenrollment.reason = '';
            }
            scope.isComment = false;
            scope.isSave = true;
          } else {
            scope.isComment = true;
            scope.isSave = false;
          }
        }
      };

      scope.validateComment = function (comment) {
        if (comment) {
          scope.patientNotevalidateComment = comment;
          scope.isSave = false;
        } else {
          scope.isSave = true;
        }
      };

      scope.clickMarkAsInvalid = function (noteData) {
          scope.disenrollment = {};
          scope.isComment = true;
          scope.markAsInvalidNoteData = { 'invalidNoteData': noteData };
          scope.getPatientNoteInvalidateReason();
          scope.isSave = true;
        };

      scope.markAsInvalid = function (patientNoteData) {
        patientTaskSvc.putPatientNote(patientData.id, patientNoteData).then(function () {
          scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber,  { noteState: 'I'});
          scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber,  { noteState: 'A'});
          scope.closeInvalidatePatientNotePopup();
          scope.invalidateNotesMessage = 'Patient Notes have been marked as invalid successfully.';
          scope.isSendToEmrValid = true;
          $timeout(function () { scope.isSendToEmrValid = false; }, 6000);
        });
      };

      scope.confirmMarkAsInvalid = function (type) {
        scope.conversionToJSONObjData = JSON.parse(type);
        var patientNoteData = { 'isInvaild': true, 'patientNotesId': scope.markAsInvalidNoteData.invalidNoteData.notesId, 'reason': scope.conversionToJSONObjData.reasonId === 3 ? scope.patientNotevalidateComment : scope.conversionToJSONObjData.reason, 'reasonId': scope.conversionToJSONObjData.reasonId };
        scope.markAsInvalid(patientNoteData);
      };

      scope.isSendToEmrInvalidate = false;
      scope.isSendToEmrValid = false;

      scope.sendToEmr = function (noteData, value) {
          scope.patientMCtrl.errorNotification = '';
          scope.successMessageType = value;
          $.get('/themes/default/pdf_notes.css', function (data) {
              var htmlNotes = '<html><head><title>Goals</title><style>' + data + '</style></head><body>' + $('#printable').html() + '</body></html>';
              var base64EncodedZippedFile = zipFile.getBase64EncodedZippedFile('htmlContent.html', htmlNotes);
              var patientNoteData = { 'note': noteData.notes, 'HtmlData': base64EncodedZippedFile, 'isResend': true, 'PatientNotesId': noteData.notesId ,'isSendToEMR' : true};
              patientTaskSvc.postPatientNote(patientData.id, patientNoteData).success(function () {
                if (scope.successMessageType === true) {
                  scope.sendToEmrInvalidNoteMessage = 'Invalid Patient Note sent to EMR successfully.';
                  scope.isSendToEmrInvalidate = true;
                  $timeout(function () { scope.isSendToEmrInvalidate = false; }, 6000);
                }
                if (scope.successMessageType === false) {
                  scope.invalidateNotesMessage = 'Patient Note sent to EMR successfully.';
                  scope.isSendToEmrValid = true;
                  $timeout(function () { scope.isSendToEmrValid = false; }, 6000);
                }
              }).error(function (err) {
                scope.controllerData.taskNotes = '';
                if (err.message) {
                  scope.patientMCtrl.errorNotification = navConstantsSvc.patientNoteErrorMessage;
                }
              });
            });
        };

      scope.getPatientNoteForPrint = function (notesId) {
          goalsSvc.getPatientNotesByNoteId(patientData.id, notesId).then(function (response) {
              scope.items = [{ 'label': 'Date Entered:', 'val': response.data.results.dateEntered },
                             { 'label': 'Entered By:', 'val': response.data.results.enteredBy },
                             { 'label': 'Patient Notes:', 'val': response.data.results.notes }];

              scope.controllerData.taskNotesPrint = response.data.results.notes;
              scope.controllerData.dateEntered = response.data.results.dateEntered;
              var userDetails = authSvc.user();
              if (userDetails.role === 'Care Manager' || userDetails.role === 'Administrator') {
                scope.items.push({ 'label': 'Access:', 'val': true });
              }
            }).catch(function () {
              scope.controllerData.isSaved = false;
            });
        };

      scope.getGoalsDetails(parseInt(location.$$search.goalId),location.$$search.taskType);
      scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber,  { noteState: 'I'});
      scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber,  { noteState: 'A'});

      scope.clickAddNewGoal = function(){
        scope.AddGoal.$setPristine();
        scope.goalSelectedItems = [];
        goalsSvc.getPatientPopulations(patientData.id).then(function(response){
            scope.ManagedPopulation = response.data.results;
          });

        scope.AddGoalPopup = true;
        scope.ShowAddGoal = true;
      };

      scope.getPatientData = function () {
          http({
            method: 'GET',
            url: app.api.root + 'patients/' + patientData.id
          })
          .success(function (data) {
            
            scope.patientData = data.results;
            
            if(data.results.Gender==='F')
            {
              scope.patientData.gender = 'Female';
            }
            else if(data.results.Gender==='M')
            {
              scope.patientData.gender = 'Male';
            }

            if( angular.isDefined(data.results.middleName)){
              scope.patientData.middleName = '';
            }

          })
          .error(function () {
            scope.controllerData.isSaved = false;
          });
        };

      scope.clickAddNewGoalSave = function(goalSelectedItems){
        var dueDate = moment(goalSelectedItems.dueDate).format('L');
        scope.goalInsertionData = {'goalName': goalSelectedItems.goalName,'managedPopulationId': goalSelectedItems.populationId,'dueDate': dueDate};
        goalsSvc.postPatientGoals(patientData.id,scope.goalInsertionData).then(function(response){
            if(response.data.results !== -1)
            {
              patientData.isMenuDirty = true;
              scope.getGoalsDetails(0,navConstantsSvc.goal);
              scope.showAlert('Goal has been added successfully.','alert-success');
            }
            else
            {
              scope.showAlert('Insertion failed either because of duplicate record or problem in connection, please try again','alert-error');
            }
          });
        scope.cancelPopup();
      };

      scope.clickAddNewActivity = function(goalID){
        scope.AddActivity.$setPristine();
        scope.ActivitySelectedItems = [];
        goalsSvc.getActivityTypes().then(function(response){
            scope.Activity = response.data.results;
            scope.goalId = goalID;
          });
        scope.cancelPopup();
        scope.GoalPopup = true;
        scope.ShowAddActivity = true;
      };

      //Calculate Goal Percentage
      scope.calculateGoalPercentage = function () {
        scope.totalGoalsCount = scope.completedGoalsCount + scope.getOpenGoalsCount;
        if (!scope.totalGoalsCount) {
          scope.isNoGoals = true;
        }
        else if (scope.totalGoalsCount >= 1) {
          scope.percentage = window.Math.abs((100 * scope.completedGoalsCount) / scope.totalGoalsCount);
          scope.isPercentage = isNaN(scope.percentage);
          scope.isNoGoals = false;
        }
        else
        {
          scope.isNoGoals = true;
        }
      };

      scope.clickAddNewActivitySave = function(ActivitySelectedItems){
        var dueDate = moment(ActivitySelectedItems.DueDate).format('L');
        scope.activityInsertionData = {'activityTypeId': ActivitySelectedItems.activityTypeId,'description': ActivitySelectedItems.Description,'dueDate': dueDate};
        goalsSvc.postPatientGoalsActivities(patientData.id,scope.goalId,scope.activityInsertionData).then(function(response){
            if(response.data.results !== -1)
            {
              scope.getGoalsDetails(scope.goalId,navConstantsSvc.goal);
              scope.showAlert('Activity has been added successfully.','alert-success');
            }
            else
            {
              scope.showAlert('Insertion failed either because of duplicate record or problem in connection, please try again','alert-error');
            }
          });
        scope.cancelPopup();
      };

      scope.completeGoal = function(Goaldata){
        scope.goalId = Goaldata.goalId;
        scope.cancelPopup();
        scope.data={'lockType':'goals','patientGoalID':scope.goalId, 'isLocked': true};
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
          scope.status=response.data.results.status;
          if(scope.status === true){
            scope.isLocked = false;
            scope.lockedText = '';
            scope.GoalPopup = true;
            scope.ShowCompleteGoal = true;
          }
          else{
            scope.GoalPopup = false;
            scope.ShowCompleteGoal = false;
            scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName',response.data.results.name);
            scope.isLocked = true;
          }
        });
      };

      scope.continueCompleteGoal = function(){
        scope.GoalDetails = {'statusCode': 'Complete'};
        goalsSvc.putPatientGoals(patientData.id,scope.goalId,scope.GoalDetails).then(function(){
            patientData.isMenuDirty = true;
            scope.getGoalsDetails(0,navConstantsSvc.goal);
            scope.getCompletedGoalsDetails();
          });
        scope.cancelPopup();
        scope.showAlert('Goal has been completed successfully.','alert-success');
      };

      scope.cancelGoalCompletion = function(){
        scope.cancelPopup();
        scope.getGoalsDetails(scope.goalId,navConstantsSvc.goal);
        scope.unlockConcurrentTask('goals',false, scope.goalId);
      };

      scope.deleteGoal = function(Goaldata){
        scope.goalId = Goaldata.goalId;
        scope.cancelPopup();
        scope.data={'lockType':'goals','patientGoalID':scope.goalId, 'isLocked': true};
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
          scope.status=response.data.results.status;
          if(scope.status === true){
            scope.isLocked = false;
            scope.lockedText = '';
            scope.GoalPopup = true;
            scope.ShowDeleteGoal = true;
          }
          else{
            scope.GoalPopup = false;
            scope.ShowDeleteGoal = false;
            scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName',response.data.results.name);
            scope.isLocked = true;
          }
        });
      };

      scope.continueDeleteGoal = function(){
        goalsSvc.deletePatientGoals(patientData.id,scope.goalId).then(function(){
          scope.cancelPopup();
          patientData.isMenuDirty = true;
          scope.getGoalsDetails(0,navConstantsSvc.goal);
        });
      };

      scope.deleteActivity = function(Activitydata){
        scope.completeActivityData = Activitydata;
        scope.goalId = Activitydata.goalId;
        scope.isActivity = 1;
        scope.cancelPopup();
        scope.data={'lockType':'activities', 'patientGoalID':scope.goalId, 'isActivity':scope.isActivity, 'isLocked': true};
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
          scope.status=response.data.results.status;
          if(scope.status === true){
            scope.isLocked = false;
            scope.lockedText = '';
            scope.GoalPopup = true;
            scope.ShowDeleteActivity = true;
          }
          else{
            scope.GoalPopup = false;
            scope.ShowDeleteActivity = false;
            scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName',response.data.results.name);
            scope.isLocked = true;
          }
        });
      };

      scope.continueDeleteActivity = function(){
        scope.ActivityDetails = {'progressMilestone': scope.completeActivityData.progressMilestone,'statusCode': 'InActive'};
        goalsSvc.putPatientGoalsActivities(patientData.id,scope.completeActivityData.goalId,scope.completeActivityData.activityId,scope.ActivityDetails)
        .then(function(){
          goalsSvc.deletePatientGoalsActivities(patientData.id,scope.completeActivityData.goalId,scope.completeActivityData.activityId).then(function(){
            scope.cancelPopup();
            scope.getGoalsDetails(scope.completeActivityData.goalId,navConstantsSvc.goal);
          });
        });
      };

      scope.updateActivity = function(Activitydata,valuedata){
        if(scope.hasEditAccess){
          Activitydata.progressMilestone = valuedata;
          Activitydata.firstvalue = valuedata > 0 ? true : false;
          Activitydata.secondvalue = valuedata > 25 ? true : false;
          Activitydata.thirdvalue = valuedata > 50 ? true : false;
          Activitydata.fourthvalue = valuedata > 75 ? true : false;
          Activitydata.fifthvalue = valuedata === 100 ? true : false;

          if(Activitydata.progressMilestone === 100)
          {
            scope.ActivityDetails = {'progressMilestone': Activitydata.progressMilestone,'statusCode': 'Active'};
            scope.completeActivityData = Activitydata;
            scope.goalId = Activitydata.goalId;
            scope.cancelPopup();
            scope.GoalPopup = true;
            scope.ShowCompleteActivity = true;
          }
          else
          {
            scope.ActivityDetails = {'progressMilestone':Activitydata.progressMilestone,'statusCode':'Active'};
            goalsSvc.putPatientGoalsActivities(patientData.id,Activitydata.goalId,Activitydata.activityId,scope.ActivityDetails).then(function(){
                scope.getGoalsDetails(Activitydata.goalId,navConstantsSvc.goal);
              });
          }
        }
      };


      scope.completeActivity = function(){
        scope.ActivityDetails = {'progressMilestone': scope.completeActivityData.progressMilestone,'statusCode': 'Complete'};
        goalsSvc.putPatientGoalsActivities(patientData.id,scope.completeActivityData.goalId,scope.completeActivityData.activityId,scope.ActivityDetails).then(function(){
            scope.getGoalsDetails(scope.completeActivityData.goalId,navConstantsSvc.goal);
          });
        scope.cancelPopup();
        scope.showAlert('Activity has been completed successfully.','alert-success');
      };

      scope.cancelActiviyCompletion = function(){
        scope.cancelPopup();
        scope.getGoalsDetails(scope.goalId,navConstantsSvc.goal);
        scope.unlockConcurrentTask('activities', false, scope.goalId, true);
      };
      scope.controllerData = {
        isSaved: false,
        taskNotes: '',
        patientNotes: []
      };

      scope.table = {
        columns : ['Date Entered', 'Entered By', 'Patient Notes', 'Summary']
      };

      var getGoalsHtml = function(data){
        // read configuration
        var contents = '';
        contents += '<html><head><title>Goals</title>';
        contents += '<style>';
        contents += data;
        contents += '</style>';
        contents += '</head><body>';
        contents += $('#pdfNotesContent').html();
        contents += '</body></html>';
        return contents;
      };

      scope.savePatientNotes = function (sendToEMR) {
        if(scope.controllerData.taskNotes === undefined || scope.controllerData.taskNotes === '')
        {
          scope.controllerData.isSaved = false;
          return;
        }

        if(sendToEMR){
          scope.saveNotesMessage = 'Patient Note saved and sent to EMR successfully.';
        }else{
          scope.saveNotesMessage = 'Note has been added successfully.';
        }

        $.get('/themes/default/pdf_notes.css', function(data) {
          var htmlNotes = '';
          if(app.sendNotesPdf){
            htmlNotes = getGoalsHtml(data);
          }
          var base64EncodedZippedFile = zipFile.getBase64EncodedZippedFile('htmlContent.html', htmlNotes);

          goalsSvc.postPatientNotes(patientData.id,{
            'note':scope.controllerData.taskNotes,
            'HtmlData':base64EncodedZippedFile,
            'isResend' : false,
            'isSendToEMR' : sendToEMR
          }).success(function(){
              scope.controllerData.taskNotes = '';
              scope.isPatientNotesSaved = true;
              $timeout(function() {scope.isPatientNotesSaved = false;}, 6000);
              scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber,  { noteState: 'I'});
              scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber,  { noteState: 'A'});
            }).error(function (err) {
            scope.controllerData.isSaved = false;
            scope.controllerData.taskNotes = '';
            scope.patientMCtrl.errorNotification = err.message;
            scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber,  { noteState: 'I'});
            scope.getNotesGridData(navConstantsSvc.defaultPageParameters.pageSize, navConstantsSvc.defaultPageParameters.pageNumber,  { noteState: 'A'});
          });
        });
      };
      scope.openDatePicker = function(type) {
        $timeout(function() {
          if(type === navConstantsSvc.goal)
          {
            if(scope.goalSelectedItems.dueDate === undefined) {
              scope.goalSelectedItems.dueDate = new Date();
            }
            scope.openedGoal = true;
          }
          else
          {
            if(scope.ActivitySelectedItems.DueDate === undefined) {
              scope.ActivitySelectedItems.DueDate = new Date();
            }
            scope.openedActivity = true;
          }
        });
      };
      
      scope.copyNotesData = function(){
        scope.controllerData.taskNotesPrint = angular.copy(scope.controllerData.taskNotes);
        scope.controllerData.dateEntered =  new Date();
      };

      scope.openSummary = function (size, notesId) {
        goalsSvc.getPatientNotesByNoteId(patientData.id,notesId).then(function(response){
            scope.items = [{'label': 'Date Entered:','val': response.data.results.dateEntered},
                           {'label': 'Entered By:','val': response.data.results.enteredBy},
                           {'label': 'Patient Notes:','val': response.data.results.notes}];

            scope.controllerData.taskNotesPrint = response.data.results.notes;
            scope.controllerData.dateEntered =  response.data.results.dateEntered;
            var userDetails = authSvc.user();
            if(userDetails.role === 'Care Manager' || userDetails.role === 'Administrator'){
              scope.items.push({'label':'Access:','val':true});
            }
            var modalInstance = modal.open({
                templateUrl: 'patientNotes.html',
                controller: 'ModalInstanceCtrl',
                size: size,
                resolve: {
                    items: function () {
                        return scope.items;
                      }
                  },
                  backdrop: 'static',
                  keyboard: false
                });
            modalInstance.patientid = patientData.id;
            modalInstance.notes = response.data.results.notes;
            modalInstance.PatientNotesId = notesId;
            modalInstance.result.then(function (selectedItem) {
                scope.selected = selectedItem;
              }, function () {
            });
          })
          .catch(function(){
            scope.controllerData.isSaved = false;
          });
      };

      scope.errorOnTimeout = function () {scope.isError = false;};

      scope.notificationonTimeout = function () {scope.notification.visible = false;};

      scope.showAlert = function (alertmessage, alerttype) {
        window.scrollTo(0, 0);
        scope.alertMessageStyle = alerttype;
        scope.alertMessage = alertmessage;
        scope.isError = true;
        $timeout(scope.errorOnTimeout, 6000);
      };

      scope.showSuccessAlert = function (alertmessage) {
        window.scrollTo(0, 0);
        scope.alertSuccessMessage = alertmessage;
        scope.isAlert = true;
        $timeout(scope.CloseAlert, 6000);
      };

      scope.CloseAlert = function(){
        scope.alertSuccessMessage = '';
        scope.isAlert = false;
      };

      scope.showNotification = function (alertmessage) {
        window.scrollTo(0, 0);
        scope.notification.message = alertmessage;
        scope.notification.success = true;
        scope.notification.visible = true;
        $timeout(scope.notificationonTimeout, 6000);
      };

      scope.cancelPopup = function(){
        scope.GoalPopup = false;
        scope.AddGoalPopup = false;
        scope.ShowAddGoal = false;
        scope.ShowAddActivity = false;
        scope.ShowCompleteGoal = false;
        scope.ShowCompleteActivity = false;
        scope.ShowCompleteSummary = false;
        scope.ShowDeleteGoal = false;
        scope.ShowDeleteActivity = false;
      };

      scope.unlockConcurrentTask = function(lockType, isLocked, goalId, isActivity) {
        scope.data={'lockType': lockType, 'patientGoalID': goalId, 'isLocked': isLocked, 'isActivity': isActivity };
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(){
          scope.isLocked = false;
          scope.lockedText = '';
        });
      };

      scope.lockConcurrentTask = function(taskDetails,milestoneValue) {
        scope.isActivity = milestoneValue === 100 ? 1 : 0;
        scope.data={'lockType':'activities', 'patientGoalID':taskDetails.goalId, 'isActivity':scope.isActivity, 'isLocked': true};
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
          scope.status=response.data.results.status;
          if(scope.status === true){
            scope.isLocked = false;
            scope.lockedText = '';
            scope.updateActivity(taskDetails,milestoneValue);
          }
          else{
            scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName',response.data.results.name);
            scope.isLocked = true;
            taskDetails.milestoneValue0 = milestoneValue === 0 ? true : false;
            taskDetails.milestoneValue25 = milestoneValue === 28.5 ? true : false;
            taskDetails.milestoneValue50 = milestoneValue === 52 ? true : false;
            taskDetails.milestoneValue75 = milestoneValue === 76 ? true : false;
            taskDetails.milestoneValue100 = milestoneValue === 100 ? true : false;
          }
        });
      };


      scope.resetToolTipText=function(){
        scope.isLocked = false;
      };

      scope.resetActivityToolTip=function(taskDetails){
        taskDetails.milestoneValue0 = false;
        taskDetails.milestoneValue25 = false;
        taskDetails.milestoneValue50 = false;
        taskDetails.milestoneValue75 = false;
        taskDetails.milestoneValue100 = false;
        scope.isLocked = false;
        scope.lockedText = '';
      };

      scope.selectedGoal = JSON.parse(localStorage.getItem('goalData'));

      if(scope.selectedGoal!== null){
        goalsSvc.getPatientGoals(patientData.id,'Complete').then(function(response){
          if(response.data.results){
            scope.goalsCompletedData = _.where(response.data.results, { statusCode: 'Completed' });
            scope.IndxCnt =  _.findIndex(scope.goalsCompletedData,{goalId:scope.selectedGoal.TaskSpecificId});
            scope.goalsCompletedData[scope.IndxCnt].isOpen = true;
            scope.completedGoalsDetails = scope.updateGoalDetails(scope.goalsCompletedData);
            scope.cgPage = scope.cgCurrentPageNumber = Math.ceil((scope.IndxCnt+1)/scope.pageSize);
          }
        });
        localStorage.removeItem('goalData');
      }
      else
      {
        scope.getCompletedGoalsDetails();
      }
          
      scope.unlockConcurrentTask('goals');

    }]);
}(window.app));