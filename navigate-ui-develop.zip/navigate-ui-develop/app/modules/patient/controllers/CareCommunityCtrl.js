(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('CareCommunityCtrl', ['$scope', '$http', '$q', 'PatientData', '$modal', 'careCommunitySvc', 'httpRequestSvc', 'authSvc', 'navConstantsSvc', '$timeout', 'userConcurrentLockSvc', '$filter','$window',
    function (scope, http, q, patientData, $modal, careCommunitySvc, httpRequestSvc, authSvc, navConstantsSvc, timeout, userConcurrentLockSvc, filter, window) {
      scope.pageSize = 5;
      scope.pageSizeProviders = 5;
      scope.page = 1;
      scope.pageProviders = 1;
      scope.careTeams = [];
      scope.providers = [];
      var modalInstance = {};
      scope.$watch('careTeams');
      scope.$watch('providers');
      scope.loginUser = authSvc.user();
      scope.emailPattern = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/;
      scope.pattern = /^[a-z]+[a-z0-9._]+@[a-z]+\.[a-z.]{2,5}$/;
      scope.successMessageFamilyCareCommunity= 'Family & Friend Detail has been added successfully.';
      scope.updateSuccessMessageFamilyCareCommunity = 'Family & Friend Detail has been updated successfully.';
      scope.successMessageProfessionalSupportCommunity = 'Professional Support Team Member has been added successfully.';
      scope.updateSuccessMessageProfessionalSupportCommunity = 'Professional Support Team Member has been updated successfully.';
      scope.isValidate = true;
      scope.isLocked = false;
      scope.lockedText ='';

      scope.hasEditAccess = authSvc.hasEditAccess();
      

      //Initialize professional Support Team data
      scope.professionalSupportTeamData = {
        gender: '',
        id: null,
        type: '',
        firstName: '',
        lastName: '',
        relationship: '',
        homeEmailAddress: '',
        workEmailAddress: '',
        homePhoneNumber: '',
        workPhoneNumber: '',
        faxNumber: '',
        cellNumber: '',
        addressType: '',
        addressLine1: '',
        addressLine2: '',
        city: '',
        stateCode: 0,
        countryCode: 0,
        postalCode: '',
        comments: ''
      };

      //Reset field value for Professional Support Team Information
      scope.clearProfessionalSupportTeamData = function () {
          scope.professionalSupportTeamData.gender = '';
          scope.professionalSupportTeamData.firstName = '';
          scope.professionalSupportTeamData.id = null;
          scope.professionalSupportTeamData.relationship = '';
          scope.professionalSupportTeamData.lastName = '';
          scope.professionalSupportTeamData.cellNumber = '';
          scope.professionalSupportTeamData.faxNumber = '';
          scope.professionalSupportTeamData.workPhoneNumber = '';
          scope.professionalSupportTeamData.homePhoneNumber = '';
          scope.professionalSupportTeamData.workEmailAddress = '';
          scope.professionalSupportTeamData.homeEmailAddress = '';
          scope.professionalSupportTeamData.phoneNumber = '';
          scope.professionalSupportTeamData.city = '';
          scope.professionalSupportTeamData.addressLine1 = '';
          scope.professionalSupportTeamData.postalCode = '';
          scope.professionalSupportTeamData.stateCode = 0;
          scope.professionalSupportTeamData.countryCode = 0;
          scope.professionalSupportTeamData.comments = '';
        };

      //Initialize Family Friends Team data
      scope.familyFriendsTeamData = {
        gender: '',
        firstName: '',
        id: null,
        type: '',
        lastName: '',
        relationship:'',
        homeEmailAddress: '',
        workEmailAddress:'',
        homePhoneNumber: '',
        workPhoneNumber: '',
        faxNumber:'',
        cellNumber:'',
        addressType: '',
        addressLine1: '',
        addressLine2: '',
        city: '',
        stateCode: 0,
        countryCode: 0,
        postalCode: '',
        comments:''
      };

      //Reset field value for Family Friends Team Information
      scope.clearFamilyFriendsTeamData = function () {
        scope.familyFriendsTeamData.gender = '';
        scope.familyFriendsTeamData.firstName = '';
        scope.familyFriendsTeamData.id = null;
        scope.familyFriendsTeamData.relationship = '';
        scope.familyFriendsTeamData.lastName = '';
        scope.familyFriendsTeamData.cellNumber = '';
        scope.familyFriendsTeamData.faxNumber = '';
        scope.familyFriendsTeamData.workPhoneNumber = '';
        scope.familyFriendsTeamData.homePhoneNumber = '';
        scope.familyFriendsTeamData.workEmailAddress = '';
        scope.familyFriendsTeamData.homeEmailAddress = '';
        scope.familyFriendsTeamData.phoneNumber = '';
        scope.familyFriendsTeamData.city = '';
        scope.familyFriendsTeamData.addressLine1 = '';
        scope.familyFriendsTeamData.postalCode = '';
        scope.familyFriendsTeamData.stateCode = 0;
        scope.familyFriendsTeamData.countryCode = 0;
        scope.familyFriendsTeamData.comments = '';
      };

      //Locked Concurrent Care Community
      scope.lockedCareCommunity = function (careCommunitydata, lockValue, isOpenPopup) {
        scope.isLocked = false;
        scope.type = careCommunitydata.type.toLowerCase();
        scope.isOpenPopup = isOpenPopup;
        scope.data = { 'lockType': 'patientcarecommunity', 'PatientConcurrentID': careCommunitydata.id, 'IsLocked': lockValue };
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function (response) {
          scope.status = response.data.results.status;
          if (scope.status === true) {
            scope.isLocked = !scope.status;
            scope.lockedText = '';
            if (scope.type === 'familyfriends' && scope.isOpenPopup === true) {
              scope.addfamilyFriendsTeam();
            } else if (scope.type === 'professionalsupport' && scope.isOpenPopup === true) {
              scope.addProfessionalSupportTeam();
            }
          }
          else {
            scope.isLocked = true;
            scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName', response.data.results.name);

          }
        });

      };

      scope.resetToolTipText = function () {
        scope.isLocked = false;
      };

      function getCareCommunity(id) {
        var baseUrl = app.api.root + 'patients/';
        q.all([
          http.get(baseUrl + id + '/care-teams'),
          http.get(baseUrl + id + '/providers')
        ]).then(function(responses) {
            scope.careTeams = responses[0].data.results;
            scope.providers = responses[1].data.results;

            angular.forEach(scope.careTeams, function(value, key){
              scope.careTeams[key].supervisor = patientData.formatName(value.supervisor);

              angular.forEach(value.managers, function(value2, key2){
                scope.careTeams[key].managers[key2] = patientData.formatName(value2);
              });
            });
          });
      }

      //Get Professional Support Team
      scope.getProfessionalSupportTeam = function () {
        careCommunitySvc.getCareCommunities(navConstantsSvc.professionalSupportTeam).then(function (response) {
          if (response.data.results) {
            scope.professionalCareTeamGridData = response.data.results;
            _.each(scope.professionalCareTeamGridData,function(item){
              item.relationshipTitle = _.filter(careCommunitySvc.patientRelations,{id:parseInt(item.relationship)})[0].name;
            });
          }
        });
      };

      //Map Professional Support And Fsamily & Friends Care Community
      scope.mapCareCommunityDetails = function (CareCommunityViewData, type, isOpenPopup) {
          if (CareCommunityViewData.type.toLowerCase() === navConstantsSvc.professionalSupportTeam.toLowerCase()) {
            scope.isEdit = type === navConstantsSvc.viewState ? true : false;
            scope.professionalSupportTeamData.gender = CareCommunityViewData.gender;
            scope.professionalSupportTeamData.id = CareCommunityViewData.id;
            scope.professionalSupportTeamData.type = CareCommunityViewData.type;
            scope.professionalSupportTeamData.firstName = CareCommunityViewData.firstName;
            scope.professionalSupportTeamData.relationship = CareCommunityViewData.relationship;
            scope.professionalSupportTeamData.lastName = CareCommunityViewData.lastName;
            scope.professionalSupportTeamData.cellNumber = CareCommunityViewData.cellNumber;
            scope.professionalSupportTeamData.faxNumber = CareCommunityViewData.faxNumber;
            scope.professionalSupportTeamData.workPhoneNumber = CareCommunityViewData.workPhoneNumber;
            scope.professionalSupportTeamData.homePhoneNumber = CareCommunityViewData.homePhoneNumber;
            scope.professionalSupportTeamData.workEmailAddress = CareCommunityViewData.workEmailAddress;
            scope.professionalSupportTeamData.homeEmailAddress = CareCommunityViewData.homeEmailAddress;
            scope.professionalSupportTeamData.phoneNumber = CareCommunityViewData.phoneNumber;
            scope.professionalSupportTeamData.city = CareCommunityViewData.city;
            scope.professionalSupportTeamData.addressLine1 = CareCommunityViewData.addressLine1;
            scope.professionalSupportTeamData.postalCode = CareCommunityViewData.postalCode;
            scope.professionalSupportTeamData.stateCode = CareCommunityViewData.stateCode;
            scope.professionalSupportTeamData.countryCode = CareCommunityViewData.countryCode;
            scope.professionalSupportTeamData.comments = CareCommunityViewData.comments;
            if (scope.isEdit === false && isOpenPopup === false) {
              scope.lockedCareCommunity(CareCommunityViewData, 1, true);
            } else if (scope.isEdit === true && isOpenPopup === true) {
              scope.addProfessionalSupportTeam();
              scope.lockedCareCommunity(CareCommunityViewData, 1, false);
            }
          }
          else if (CareCommunityViewData.type.toLowerCase() === navConstantsSvc.familyFriendsTeam.toLowerCase()) {
            scope.isEdit = type === navConstantsSvc.viewState ? true : false;
            scope.familyFriendsTeamData = CareCommunityViewData;
            scope.familyFriendsTeamData.id = CareCommunityViewData.id;
            scope.familyFriendsTeamData.type = CareCommunityViewData.type;
            scope.familyFriendsTeamData.firstName = CareCommunityViewData.firstName;
            scope.familyFriendsTeamData.relationship = CareCommunityViewData.relationship;
            scope.familyFriendsTeamData.lastName = CareCommunityViewData.lastName;
            scope.familyFriendsTeamData.cellNumber = CareCommunityViewData.cellNumber;
            scope.familyFriendsTeamData.faxNumber = CareCommunityViewData.faxNumber;
            scope.familyFriendsTeamData.workPhoneNumber = CareCommunityViewData.workPhoneNumber;
            scope.familyFriendsTeamData.homePhoneNumber = CareCommunityViewData.homePhoneNumber;
            scope.familyFriendsTeamData.workEmailAddress = CareCommunityViewData.workEmailAddress;
            scope.familyFriendsTeamData.homeEmailAddress = CareCommunityViewData.homeEmailAddress;
            scope.familyFriendsTeamData.phoneNumber = CareCommunityViewData.phoneNumber;
            scope.familyFriendsTeamData.city = CareCommunityViewData.city;
            scope.familyFriendsTeamData.addressLine1 = CareCommunityViewData.addressLine1;
            scope.familyFriendsTeamData.postalCode = CareCommunityViewData.postalCode;
            scope.familyFriendsTeamData.stateCode = CareCommunityViewData.stateCode;
            scope.familyFriendsTeamData.countryCode = CareCommunityViewData.countryCode;
            scope.familyFriendsTeamData.comments = CareCommunityViewData.comments;
            if (scope.isEdit === false && isOpenPopup === false) {
              scope.lockedCareCommunity(CareCommunityViewData, 1, true);
            } else if (scope.isEdit === true && isOpenPopup === true) {
              scope.addfamilyFriendsTeam();
              scope.lockedCareCommunity(CareCommunityViewData, 1, false);
            }
          }
        };

      //View Care Community Details
      scope.viewCareCommunityDetails = function (ProfessionalSupportTeamId) {
        careCommunitySvc.getCareCommunity(ProfessionalSupportTeamId).then(function (response) {
          if (response.data.results) {
            scope.mapCareCommunityDetails(response.data.results, navConstantsSvc.viewState, true);
          }
        });
      };

      //Edit Care Community Details
      scope.editCareCommunityDetails = function (ProfessionalSupportTeamId, isOpenPopup) {
        careCommunitySvc.getCareCommunity(ProfessionalSupportTeamId).then(function (response) {
          if (response.data.results) {
            scope.mapCareCommunityDetails(response.data.results, navConstantsSvc.editState , isOpenPopup);
          }
        });
      };

      //Get All Care Community
      scope.getFamilyFriendsTeam = function () {
        careCommunitySvc.getCareCommunities(navConstantsSvc.familyFriendsTeam).then(function (response) {
          if (response.data.results) {
            scope.familyCareTeamGridData = response.data.results;
            _.each(scope.familyCareTeamGridData,function(item){
              item.relationshipTitle = _.filter(careCommunitySvc.patientRelations,{id:parseInt(item.relationship)})[0].name;
            });
          }
        });
      };

      //Delete Care Community Details
      scope.deleteCareCommunityDetails = function (row, lockValue, deleteStatus) {
        if (deleteStatus === false) {
          scope.isLockedDelete = true;
          scope.lockedCareCommunityData = row;
          scope.data = { 'lockType': 'patientcarecommunity', 'PatientConcurrentID': scope.lockedCareCommunityData.id, 'IsLocked': lockValue };
          userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function (response) {
            scope.status = response.data.results.status;
            if (scope.status === true) {
              scope.isLockedDelete = scope.status;
              scope.lockedText = '';
              scope.openModelPopup('delete_CareCommunity.html', 'sm');
            }
            else {
              scope.isLockedDelete = false;
              scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName', response.data.results.name);
            }
          });
        } else if (deleteStatus === true) {
          modalInstance.close(true);
          careCommunitySvc.deleteCareCommunity(scope.lockedCareCommunityData.id).then(function (response) {
            if (response.data.results) {
              scope.lockedCareCommunity(scope.lockedCareCommunityData, 0, false);
              if (scope.lockedCareCommunityData.type.toLowerCase() === navConstantsSvc.professionalSupportTeam.toLowerCase()) {
                scope.getProfessionalSupportTeam();
              } else if (scope.lockedCareCommunityData.type.toLowerCase() === navConstantsSvc.familyFriendsTeam.toLowerCase()) {
                scope.getFamilyFriendsTeam();
              }
            }
          });
        }
      };
      scope.resetToolTipTextDelete = function () {
          scope.isLockedDelete = true;
        };
      //GET states
      scope.getStateData = function () {
        var requestpath = 'states';
        httpRequestSvc.getRequest(requestpath).then(function (response) {
          scope.stateData = response.data.results;
        });
      };

      //GET countries
      scope.getCountryData = function () {
        var requestpath = 'countries?userId=' + scope.loginUser.id;
        httpRequestSvc.getRequest(requestpath).then(function (response) {
          scope.countriesData = response.data.results;
        });
      };

      //GET RelationShip
      scope.getRelationShipData = function () {
        careCommunitySvc.getRelationShip().then(function (response) {
          scope.relationShipData = response.data.results;
          careCommunitySvc.patientRelations = response.data.results;
          scope.relationShipDataForProfessionalSupport = filter('filter')(scope.relationShipData, { type: 'PROFESSIONALSUPPORT' });
          scope.relationShipDataForFamilyFriends = filter('filter')(scope.relationShipData, { type: 'FAMILYFRIENDS' });
          scope.getFamilyFriendsTeam();
          scope.getProfessionalSupportTeam();
        });
      };

      //Get Teams
      scope.getAllTeam = function () {
        scope.getRelationShipData();
      };

      scope.getAllTeam();

      //Accordion Title
      scope.careProfessionalSupportTeam = 'Professional Support Team Details';
      scope.careFamilyTeam = 'Family & Friends Details';

      //table Header
      scope.columnsSelectedProfessional = [{ field: 'firstName', displayName: 'Name', columnClass: 'table-column-name' }, { field: 'gender', displayName: 'Gender', columnClass: 'table-column-actions', sortable: false }, { field: 'relationshipTitle', displayName: 'Relationship', columnClass: 'table-column-assessment-status' }, { field: 'comments', displayName: 'Comments', columnClass: 'table-column-status', sortable: false }, { field: 'actions', displayName: 'Actions', columnClass: 'table-column-name', sortable: false }];

      scope.columnsSelectedFamily = [{ field: 'firstName', displayName: 'Name', columnClass: 'table-column-name' }, { field: 'gender', displayName: 'Gender', columnClass: 'table-column-actions', sortable: false }, { field: 'relationshipTitle', displayName: 'Relationship', columnClass: 'table-column-assessment-status' }, { field: 'comments', displayName: 'Comments', columnClass: 'table-column-status', sortable: false }, { field: 'actions', displayName: 'Actions', columnClass: 'table-column-name', sortable: false }];

      scope.getCareCommunity = getCareCommunity;
      scope.getCareCommunity(patientData.id);

      scope.pageTitle = 'Care Community Details';
      scope.careTeamTitle = 'Care Team Details';
      scope.careTeamTable = {
        captionText : 'List of patient\x27s care teams.',
        columns : ['Care Team Name', 'Care Manager Supervisor', 'Care Manager']
      };

      scope.providersTitle = 'Provider Details';
      scope.providerTable = {
        captionText : 'List of patient\x27s providers.',
        columns : ['Provider Name', 'Provider Specialty']
      };
      scope.providersExpanded = true;
      scope.professionalExpanded = false;
      scope.familyExpanded = false;
      scope.careTeamExpanded = true;

      //Add family And Friends Team
      scope.addfamilyFriendsTeam = function (status) {
        if (status === true) {
          scope.clearProfessionalSupportTeamData();
          scope.clearFamilyFriendsTeamData();
        }
        scope.openModelPopup('family_care_team.html', 'lg');
      };

      //Add Professional Support Team
      scope.addProfessionalSupportTeam = function (status) {
        if (status === true) {
          scope.clearProfessionalSupportTeamData();
          scope.clearFamilyFriendsTeamData();
        }
        scope.openModelPopup('professional_care_team.html', 'lg');
      };

      scope.openModelPopup = function (view, popupSize) {
          scope.isError = false;
          scope.isValidate = true;
          scope.getStateData();
          scope.getCountryData();
          scope.isCancelAlertVisible = false;
          modalInstance = $modal.open({
              animation: true,
              templateUrl: view,
              size: popupSize,
              scope: scope,
              backdrop: 'static'
            });
        };

      //Show Cancel Alert Popup
      scope.showCancelAlertPopup = function (CareCommunityViewData) {
        modalInstance.close(true);
        scope.isError = false;
        scope.isEdit = false;

        scope.lockedCareCommunity(CareCommunityViewData, 0, false);

        scope.clearProfessionalSupportTeamData();
        scope.clearFamilyFriendsTeamData();



      };

      //Show Cancel Alert
      scope.showCancelAlert = function (show) {
        scope.isCancelAlertVisible = show;
      };

      //Close Popup
      scope.closePopup = function (show, myForm, CareCommunityViewData) {
        if (show === 'cancel') {
          modalInstance.close(true);
          scope.lockedCareCommunity(scope.lockedCareCommunityData, 0, false);
        } else {
          if (myForm.$pristine) {
            scope.isCancelAlertVisible = false;
            scope.isError = false;
            scope.showCancelAlertPopup(CareCommunityViewData);
          } else {
            scope.isCancelAlertVisible = show;
          }
        }
      };

      // display error message if failed to get the data from api
      scope.showNotifications = function (errorMsg, style) {
        window.scrollTo(0, 0);
        scope.alertMessageStyle = style;
        scope.alertMessage = errorMsg;
        scope.isError = true;
        scope.isSuccessMsg = style === 'alert-success' ? true : false;
        timeout(function () {
          scope.isError = false;
        }, 6000);
      };

      //Save And Update Care Community Details
      scope.updatedCareCommunityDetails = function (updatedInformation, careCommunitytype, form) {
        scope.careCommunitytype = careCommunitytype;
        var TeamData = {
          id: updatedInformation.id,
          type: careCommunitytype,
          gender: updatedInformation.gender,
          firstName: updatedInformation.firstName,
          lastName: updatedInformation.lastName,
          relationship: updatedInformation.relationship,
          homeEmailAddress: updatedInformation.homeEmailAddress,
          workEmailAddress: updatedInformation.workEmailAddress,
          homePhoneNumber: updatedInformation.homePhoneNumber,
          workPhoneNumber: updatedInformation.workPhoneNumber,
          faxNumber: updatedInformation.faxNumber,
          cellNumber: updatedInformation.cellNumber,
          addressType: updatedInformation.addressType,
          addressLine1: updatedInformation.addressLine1,
          addressLine2: updatedInformation.addressLine2,
          city: updatedInformation.city,
          stateCode: updatedInformation.stateCode,
          countryCode: updatedInformation.countryCode,
          postalCode: updatedInformation.postalCode,
          comments: updatedInformation.comments
        };
          //POST
        if (updatedInformation.id> 0) {
          careCommunitySvc.postCareCommunity(TeamData).then(function (response) {
            if (response.data.results.success === true) {
              scope.isValidate = true;
              form.$setPristine();
              scope.clearProfessionalSupportTeamData();
              scope.clearFamilyFriendsTeamData();
              if (response.data.results.careCommunityId > 0) {
                modalInstance.close(true);
              }
              scope.clearProfessionalSupportTeamData();
              scope.clearFamilyFriendsTeamData();
              if (scope.careCommunitytype === navConstantsSvc.familyFriendsTeam) {
                scope.showNotifications(scope.updateSuccessMessageFamilyCareCommunity, 'alert-success');
                scope.getFamilyFriendsTeam();
              } else if (scope.careCommunitytype === navConstantsSvc.professionalSupportTeam) {
                scope.showNotifications(scope.updateSuccessMessageProfessionalSupportCommunity, 'alert-success');
                scope.getProfessionalSupportTeam();
              }
            }
          });
        }
          //PUT
        else {
          careCommunitySvc.postCareCommunity(TeamData).then(function (response) {
            if (response.data.results.success === true) {
              scope.isValidate = true;
              form.$setPristine();
              if (response.data.results.careCommunityId > 0) {
                modalInstance.close(true);
              }
              scope.clearProfessionalSupportTeamData();
              scope.clearFamilyFriendsTeamData();
              if (scope.careCommunitytype === navConstantsSvc.familyFriendsTeam) {
                scope.showNotifications(scope.successMessageFamilyCareCommunity, 'alert-success');
                scope.getFamilyFriendsTeam();
              } else if (scope.careCommunitytype === navConstantsSvc.professionalSupportTeam) {
                scope.showNotifications(scope.successMessageProfessionalSupportCommunity, 'alert-success');
                scope.getProfessionalSupportTeam();
              }
            }
          });
        }
      };

      //Validate Forms
      scope.validateForm = function (formValue, form) {
        if (formValue.firstName && formValue.relationship && formValue.lastName) {
          if (form.$invalid === false) {
            scope.isValidate = false;
          } else if (form.$invalid === true) {
            scope.isValidate = true;
          }
        } else {
          scope.isValidate = true;
        }
      };

    }]);
  }(window.app));
