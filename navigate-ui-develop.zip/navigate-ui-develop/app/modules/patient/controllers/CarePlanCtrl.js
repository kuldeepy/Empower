﻿(
  function (app) {
    'use strict';
    app.controller('CarePlanCtrl', ['$scope', 'PatientData','carePlanSvc','parseToZipFile','$timeout','patientTaskSvc','goalsSvc','authSvc','careCommunitySvc', '$filter', '$modal', '$location', '$window','$rootScope',
        function (scope, patientData, carePlanSvc, zipFile, $timeout, patientTaskSvc, goalsSvc, authSvc, careCommunitySvc, $filter, $modal, $location, window, rootScope) {
        scope.carePlan = {};
        scope.carePlan.patient = {};
        scope.carePlan.conditions = [];
        scope.carePlan.tasks = [];
        scope.accordionStatus = {};
        scope.accordionStatus.openPD = true;
        scope.providerDate = {};
        scope.ismeridian = true;
        scope.carePlan.medicationAllergies = [];
        scope.carePlan.appointmentsWithProviders = [];
        scope.carePlan.appointmentsWithCommunityServices = [];
        scope.carePlan.careTeams = [];
        scope.carePlan.careCommunities = [];
        scope.carePlan.goals = [];
        scope.carePlan.allergies = [];
        scope.mostRecentCarePlan = {};
        scope.hstep = 1;
        scope.mstep = 1;
        scope.ismeridian = true;
        scope.carePlan.overview = null;
        scope.bodyMeasurements = {};
        scope.patientCareTeams = [];
        scope.carePlan.allergyTypes = [{allergyType:'Environment'},{allergyType:'Food'},{allergyType:'Medication'}];
        scope.carePlan.userMedications = [];
        scope.goalsInfo = {};
        scope.printStatus = false;
        scope.carePlan.overview = '';
        scope.overviewClass = false;
        scope.healthConditionsClass = false;
        scope.taskClass = false;
        scope.allergyClass = false;
        scope.medicationClass = false;
        scope.careTeamContactsClass = false;
        scope.appointmentsWithProvidersClass = false;
        scope.appointmentsWithCommunityServicesClass = false;
        scope.goalClass = false;
        scope.bodyMeasurementsHeightClass = false;
        scope.bodyMeasurementsWeightClass = false;
        scope.bodyMeasurementsBmiClass = false;
        scope.bodyMeasurementsBpClass = false;
        scope.bodyMeasurementsClass = false;
        scope.bodyMeasurements.heightChk = false;
        scope.bodyMeasurements.weightChk = false;
        scope.bodyMeasurements.bmiChk = false;
        scope.bodyMeasurements.bpChk = false;
        scope.openAcc = false;
        scope.isPopup = false;
        scope.isSave = false;
        scope.carePlanLocationCtrl.isFormDirty = false;
        scope.showSendCarePlanPdf = app.sendCarePlanPdf;

        scope.$watch('form.$pristine', function () {
          if (!scope.form.$pristine) {
            scope.carePlanLocationCtrl.isFormDirty = true ;
          }
        });

        scope.$on('showCarePlanChangePopup', function() {
          scope.popupAction();
          event.stopPropagation();
        });

        scope.isPopupOpen = false;

        scope.$on('$locationChangeStart', function (event) {
          if(!scope.form.$pristine && scope.isPopup === false && scope.carePlanLocationCtrl.isLogout === false)
          {
            var nextPath = $location.path();
            localStorage.setItem('newUrlCarePlan', nextPath);
            event.preventDefault(); // This prevents the navigation from happening
            if (!scope.isPopupOpen) {
              scope.popupAction();
            }
          }
        });

        window.onbeforeunload = function() {
          if(!scope.form.$pristine && scope.isSave === false )
          {
            return 'You will lose all unsaved work.';
          }
        };

        scope.popupAction = function () {
          scope.isPopupOpen = true;
          scope.modalInstance = $modal.open({
            templateUrl: 'carePlanCancelPopup.html',
            size: '',
            scope: scope,
            backdrop: 'static'
          });
        };

        scope.close = function () {
            scope.modalInstance.close(true);
            scope.carePlanLocationCtrl.isLogout = false;
            scope.carePlanLocationCtrl.isSwitchRole = false;
            scope.isPopupOpen = false;
          };

        scope.closeAndChangeLocation = function () {
          window.onbeforeunload = null;
          scope.carePlanLocationCtrl.isFormDirty = false;
          if(scope.carePlanLocationCtrl.isSwitchRole){
            rootScope.$emit('switchAuthUser');
            scope.carePlanLocationCtrl.isSwitchRole = false;
            scope.close();
          } else if (scope.carePlanLocationCtrl.isLogout) {
              
            rootScope.$emit('logoutAuthUser');
            scope.close();
            scope.carePlanLocationCtrl.isLogout = true;
          }else{

            var newUrl = localStorage.getItem('newUrlCarePlan');
            scope.modalInstance.close(true);
            if(newUrl)
            {
              scope.isPopup = true;
              $location.url(newUrl);
            }
          }
        };

        scope.init = function () {
          scope.checkUserAccess();
          scope.getCarePlans();
        };

        scope.checkUserAccess = function(){
          var userDetails = authSvc.user();
          if(userDetails.role === 'Care Manager' || userDetails.role === 'Physician' || userDetails.role === 'Administrator'){
            scope.hasEditAccess = true;
          }
        };

        scope.columnsSelected = [
          {
            field: 'lastModifiedDate',
            displayName: 'Date',
            columnClass: 'table-column-name'
          },
          {
            field: 'lastModifiedByUser',
            displayName: 'Changed by Whom',
            columnClass: 'table-column-description'
          },
          {
            field: 'actions',
            displayName: 'Actions',
            columnClass: 'table-column-description',
            sortable: false,
          }
        ];

        var mapPatientDemographicInformation = function() {
          scope.carePlan.overview = scope.mostRecentCarePlan.overview;
          scope.carePlan.height = scope.mostRecentCarePlan.height;
          scope.bodyMeasurements.heightChk = scope.mostRecentCarePlan.height ? true : false;
          scope.carePlan.weight = scope.mostRecentCarePlan.weight;
          scope.bodyMeasurements.weightChk = scope.mostRecentCarePlan.weight ? true : false;
          scope.carePlan.bmi = scope.mostRecentCarePlan.bMI;
          scope.bodyMeasurements.bmiChk = scope.mostRecentCarePlan.bMI ? true : false;
          scope.carePlan.bp = scope.mostRecentCarePlan.bloodPressure;
          scope.bodyMeasurements.bpChk = scope.mostRecentCarePlan.bloodPressure ? true : false;
        };

        var mapMedicationInformation = function() {
          var index = 1;
          scope.carePlan.medicationAllergies.push({rowId:index,medicationAllergyText:''});
          scope.getMedications();
          // get all saved medications with medication id as null (user defined medications) and add it to the list
          var selectedUserMedications = _.where(scope.mostRecentCarePlan.medications, {medicationId: null});
          angular.forEach(selectedUserMedications, function(data){
            scope.carePlan.userMedications.push({rowId:index,medicationDetails:data.medicationDetails, instructions:data.notes, medicationChecked:true, medicationClass:false});
            index = index + 1;
          });
          scope.carePlan.userMedications.push({rowId:scope.carePlan.userMedications.length + 1,medicationDetails:'', instructions:'', medicationChecked:false, medicationClass:false});
        };

        var mapAllergyInformation = function() {
          var index = 1;
          angular.forEach(scope.mostRecentCarePlan.allergies, function(data){
            scope.carePlan.allergies.push({rowId:index,allergyText:data.name,lastReactionOccurred: moment(data.lastReactionOccured, 'YYY-MM-DDTHH:mm:ssZ').toDate(),selectedAllergyType:data.allergyType, reactionsAndAdditionalComments:data.notes, allergyChecked:true, allergyClass:false});
            index = index + 1;
          });
          scope.carePlan.allergies.push({rowId:scope.carePlan.allergies.length + 1,allergyText:'',lastReactionOccurred:new Date(),selectedAllergyType:null, reactionsAndAdditionalComments:'', allergyChecked:false, allergyClass:false});
        };

        var mapAppointmentInformation = function() {
          // map appointments with provider
          var aIndex = 1;
          var selectedAppointmentsWithProvider = _.where(scope.mostRecentCarePlan.appointments, {appointmentType: 'Providers'});
          angular.forEach(selectedAppointmentsWithProvider, function(data){
            scope.carePlan.appointmentsWithProviders.push({rowId:aIndex, physicianName:data.appointmentDetails, physicianSpeciality : '',appointmentDate : moment(data.appointmentTime, 'YYY-MM-DDTHH:mm:ssZ').toDate(),  defaultTime: moment(data.appointmentTime, 'YYY-MM-DDTHH:mm:ssZ').toDate(), invalidtime:false, instruction:data.notes, isChecked:true, isCheckedClass:false});
            aIndex = aIndex + 1;
          });
          scope.carePlan.appointmentsWithProviders.push({rowId:scope.carePlan.appointmentsWithProviders.length + 1, physicianName:'', physicianSpeciality : '',appointmentDate : new Date(),  defaultTime: new Date() ,invalidtime:false, instruction:'', isChecked:false, isCheckedClass:false});
          
          // map appointments with community services
          var cIndex = 1;
          var selectedAppointmentsWithCommunityServices = _.where(scope.mostRecentCarePlan.appointments, {appointmentType: 'Community Services'});
          angular.forEach(selectedAppointmentsWithCommunityServices, function(data){
            scope.carePlan.appointmentsWithCommunityServices.push({rowId:cIndex, communityService:data.appointmentDetails, appointmentDate : moment(data.appointmentTime, 'YYY-MM-DDTHH:mm:ssZ').toDate(),  defaultTime: moment(data.appointmentTime, 'YYY-MM-DDTHH:mm:ssZ').toDate(), invalidtime:false, instruction:data.notes, isChecked:true, isCheckedClass:false});
            cIndex = cIndex + 1;
          });
          scope.carePlan.appointmentsWithCommunityServices.push({rowId:scope.carePlan.appointmentsWithCommunityServices.length + 1, communityService:'', appointmentDate : new Date(),  defaultTime : new Date(), invalidtime:false, instruction:'', isChecked:false, isCheckedClass:false});
        };

        var mapContactInformation = function() {
          // add user contacts
          var index = 1;
          var selectedUserContacts = _.where(scope.mostRecentCarePlan.contacts, {contactType: null});
          angular.forEach(selectedUserContacts, function(data){
            // lets map the already selected user contacts
            scope.patientCareTeams.push({rowId:index, name:data.name, phone:data.phone, email:data.email, isChecked :true, isCheckedClass:false});
            index = index + 1;
          });
          scope.patientCareTeams.push({rowId:scope.patientCareTeams.length + 1, name:'', phone:'', email:'', isChecked :false, isCheckedClass:false});
        };

        var mapMostRecentCarePlan = function()
        {
          var mostRecentCarePlanId = scope.carePlan.carePlanVersions[0].carePlanId;
          // lets make an API call to get the care plan
          carePlanSvc.getCarePlan(patientData.id, mostRecentCarePlanId).then(function (response) {
            scope.mostRecentCarePlan = response.data.results;
            scope.getPatient();

            // map patient demographic information
            mapPatientDemographicInformation();
            scope.getConditions();
            // map allergies
            mapAllergyInformation();
            // map medications
            mapMedicationInformation();
            // map appointments
            mapAppointmentInformation();
            // map contacts
            mapContactInformation();

            scope.getCareTeams();
            scope.getCareCommunity();
           
            scope.getTasks();
            scope.getGoals();
          });
        };

        scope.getCarePlans = function(){
          carePlanSvc.getCarePlans(patientData.id).then(function (response) {
            scope.carePlan.carePlanVersions = response.data.results;

            // if there is a latest care verion available load the same in UI with master data
            if(scope.carePlan.carePlanVersions.length > 0)
            {
              mapMostRecentCarePlan();
            }
            else
            {
              loadPatientInformation();
            }
            scope.form.$setPristine();
          });
        };

        var loadPatientInformation = function()
        {
          scope.getPatient();
          scope.getConditions();
          scope.carePlan.medicationAllergies.push({rowId:1,medicationAllergyText:''});
          scope.patientCareTeams.push({rowId:1, name:'', phone:'', email:'', isChecked :false, isCheckedClass:false});
          scope.carePlan.appointmentsWithProviders.push({rowId:1, physicianName:'', physicianSpeciality : '',appointmentDate : new Date(),  defaultTime: new Date() ,invalidtime:false, instruction:'', isChecked:false, isCheckedClass:false});
          scope.carePlan.appointmentsWithCommunityServices.push({rowId:1, communityService:'', appointmentDate : new Date(),  defaultTime : new Date(), invalidtime:false, instruction:'', isChecked:false, isCheckedClass:false});
          scope.carePlan.allergies.push({rowId:1,allergyText:'',lastReactionOccurred:new Date(),selectedAllergyType:null, reactionsAndAdditionalComments:'', allergyChecked:false, allergyClass:false});
          scope.carePlan.userMedications.push({rowId:1,medicationDetails:'', instructions:'', medicationChecked:false, medicationClass:false});
          scope.getMedications();
          scope.getCareTeams();
          scope.getCareCommunity();
          scope.getTasks();
          scope.getGoals();
        };

        scope.getPatient = function () {
          carePlanSvc.getPatient(patientData.id).success(function (data) {
            scope.carePlan.patient = {
              id: data.results.patientId,
              gender: data.results.Gender,
              memberNumber: data.results.memberNumber,
              fullName: data.results.fullName,
              lastName: data.results.lastName === null ? '' : data.results.lastName,
              firstName: data.results.firstName,
              middleName: data.results.middleName === null ? '' : data.results.middleName,
              email: data.results.EmailIdPrimary,
              PCP: data.results.PCPName,
              Insurance: data.results.insurancePlan === null ? '' : data.results.insurancePlan,
              dateOfBirth: data.results.dateOfBirth,
              age: $filter('ageCalculation')(data.results.dateOfBirth),
            };
          });
        };

        scope.getConditions = function () {
          carePlanSvc.getConditions(patientData.id).then(function (response) {
            scope.carePlan.conditions = response.data.results;
            angular.forEach(scope.carePlan.conditions, function(data){
              // lets map the already selected condition        
              var selectedCondition = _.find(scope.mostRecentCarePlan.conditions, {conditionId: data.diseaseId});
              data.conditionChecked = selectedCondition ? true : false;
              data.HealthConditionNotes = selectedCondition ? selectedCondition.notes : '';
              data.conditionClass = false;
            });
          });
        };

        scope.openProviderDatePicker = function ($event,appointmentsWithProvider) {
          appointmentsWithProvider.appointmentDate = appointmentsWithProvider.appointmentDate === '' ? new Date() : appointmentsWithProvider.appointmentDate;
          $event.stopPropagation();
          $event.preventDefault();
          appointmentsWithProvider.appointmentDate.opened = !appointmentsWithProvider.appointmentDate.opened;
        };

        scope.openAllergyDatePicker = function ($event,allergy) {
          allergy.lastReactionOccurred = allergy.lastReactionOccurred === '' ? new Date() : allergy.lastReactionOccurred;
          $event.stopPropagation();
          $event.preventDefault();
          allergy.lastReactionOccurred.opened = !allergy.lastReactionOccurred.opened;
        };

        scope.openCommunityServiceDatePicker = function ($event,appointmentsWithCommunityService) {
          appointmentsWithCommunityService.appointmentDate = appointmentsWithCommunityService.appointmentDate === '' ? new Date() : appointmentsWithCommunityService.appointmentDate;
          $event.stopPropagation();
          $event.preventDefault();
          appointmentsWithCommunityService.appointmentDate.opened = !appointmentsWithCommunityService.appointmentDate.opened;
        };

        scope.addAllergy = function (index) {
          if(scope.carePlan.allergies.length === index ){
            scope.carePlan.allergies.push({rowId:scope.carePlan.allergies.length + 1,allergyText:'',lastReactionOccurred:new Date(),selectedAllergyType:null, reactionsAndAdditionalComments:'', allergyChecked:false, allergyClass:false});
          }
        };

        scope.addMedication = function(index){
          if(scope.carePlan.userMedications.length === index ){
            scope.carePlan.userMedications.push({rowId:scope.carePlan.userMedications.length + 1,medicationDetails:'', instructions:'', medicationChecked:false, medicationClass:false});
          }
        };

        scope.getMedications = function () {
          carePlanSvc.getMedications(patientData.id).then(function (response) {
            scope.carePlan.medications = response.data.results;
            angular.forEach(scope.carePlan.medications, function(data){
              // lets map the already selected medication        
              var selectedMedication = _.find(scope.mostRecentCarePlan.medications, {medicationId: data.id});
              data.medicationChecked = selectedMedication ? true : false;
              data.medicationClass = false;
              data.notes = selectedMedication ? selectedMedication.notes : '';
              data.medicationDetails = selectedMedication ? selectedMedication.medicationDetails : '';
            });
          });
        };

        scope.getCareTeams = function () {
          carePlanSvc.getCareTeams(patientData.id).then(function (response) {
            scope.carePlan.careTeams = response.data.results;
            var selectedCareTeams = _.where(scope.mostRecentCarePlan.contacts, {contactType: 'Care Team'});
            angular.forEach(scope.carePlan.careTeams, function(data){
              // lets map the already selected care team        
              var selectedCareTeam = _.find(selectedCareTeams, {contactId: data.id});
              if(selectedCareTeam)
              {
                data.id = selectedCareTeam.contactId;
                data.name = selectedCareTeam.name;
                data.email = selectedCareTeam.email;
                data.phone = selectedCareTeam.phone;
                data.contactType = 'Care Team';
                data.isChecked = true;
              }
              else
              {
                data.isChecked = false;
              }
              data.isCheckedClass = false;
            });
          });
        };

        scope.getCareCommunity = function(){
          careCommunitySvc.getCareCommunities('professionalSupport').then(function (response) {
            scope.carePlan.careCommunities = response.data.results;
            var selectedCareCommunities = _.where(scope.mostRecentCarePlan.contacts, {contactType: 'Care Community'});
            angular.forEach(scope.carePlan.careCommunities, function(data){
              // lets map the already selected care team        
              var selectedCareCommunity = _.find(selectedCareCommunities, {contactId: data.id});
              if(selectedCareCommunity)
              {
                data.id = selectedCareCommunity.contactId;
                data.name = selectedCareCommunity.name;
                data.email = selectedCareCommunity.email;
                data.phone = selectedCareCommunity.phone;
                data.contactType = 'Care Community';
              }
              data.isChecked = selectedCareCommunity ? true : false;
              data.isCheckedClass = false;
            });
          });
        };

        scope.addAppointmentsWithProviders = function (index) {
          if(scope.carePlan.appointmentsWithProviders.length ===  index ){
            scope.carePlan.appointmentsWithProviders.push({rowId:scope.carePlan.appointmentsWithProviders.length + 1,physicianName:'',physicianSpeciality:'', appointmentDate : new Date(),  defaultTime:new Date(), instruction:'', isChecked:false, isCheckedClass:false});
          }
        };

        scope.addAppointmentsWithCommunityServices = function (index) {
          if(scope.carePlan.appointmentsWithCommunityServices.length === index ){
            scope.carePlan.appointmentsWithCommunityServices.push({rowId:scope.carePlan.appointmentsWithCommunityServices.length + 1,communityService:'', appointmentDate : new Date(), defaultTime : new Date(), instruction:'', isChecked:false, isCheckedClass:false});
          }
        };

        scope.addCareTeam = function (index) {
          if(scope.patientCareTeams.length === index  ){
            scope.patientCareTeams.push({rowId:scope.patientCareTeams.length + 1,name:'', phone:'', email:'', isChecked :false, isCheckedClass:false});
          }
        };

        scope.getTasks = function () {
          var dateDue,today = window.moment(new Date()).format('YYYY-MM-DD');
          patientTaskSvc.getPatientTasks(patientData.id).then(function (response) {
            scope.carePlan.tasks =  _.filter(response.data.results, function (item) {
              if (item.IsWaitingForClaims) { return false; }
              if(item.TaskTypeName === 'Goal') {return false; }
              if(item.TaskTypeName === 'Activity') {return false; }
              dateDue = window.moment(item.DateDue).format('YYYY-MM-DD');
              return (dateDue >= today);
            });
            angular.forEach(scope.carePlan.tasks, function(data){
              var selectedTask = _.find(scope.mostRecentCarePlan.activities, {activityId: data.Id});
              data.taskNotes = selectedTask ? selectedTask.notes : '';
              data.isChecked = selectedTask ? true : false;
              data.isCheckedClass = false;
            });
          });
        };

        scope.getGoals = function () {
          goalsSvc.getPatientGoals(patientData.id, 'Active').then(function (response) {
            scope.carePlan.goals = response.data.results;
            scope.goalsInfo.activeGoals = response.data.results.length;
            angular.forEach(scope.carePlan.goals, function(goalsList){
              var selectedGoal = _.find(scope.mostRecentCarePlan.goals, {goalId: goalsList.goalId});
              goalsList.selectedActivity = 0;
              goalsList.isOpen = selectedGoal ? true : false;
              angular.forEach(goalsList.patientActivities, function(activity){
                // this may not be the right fix  - currently progress bar data is going as 76 fo 75, 52 for 50 & 28.5 for 25. 
                // we are just parsing it to the right progress bar position based on the number.
                activity.progressMilestone = (activity.progressMilestone === 76) ? 75 : (activity.progressMilestone === 52) ? 50 : (activity.progressMilestone === 28) ? 25 : activity.progressMilestone;
                var selectedActivity = _.find(scope.mostRecentCarePlan.goals, {activityId: activity.activityId});
                activity.activityChecked = selectedActivity ? true : false;
                activity.activityCheckedClass = false;
                activity.instruction = selectedActivity ? selectedActivity.notes : '';
              });
            });
          });
          goalsSvc.getPatientGoals(patientData.id, 'Complete').then(function (response) {
            scope.goalsInfo.completedGoals = response.data.results.length;
          });
        };

        scope.checkAllActivities = function (collection, isChecked) {
          angular.forEach(collection.patientActivities, function(data){
            data.activityChecked = isChecked;
            collection.selectedActivity = isChecked ? collection.patientActivities.length : 0;
          });
        };

        scope.checkAllConditions = function (collection, isChecked) {
          angular.forEach(collection, function(data){
            data.conditionChecked = isChecked;
          });
        };

        scope.checkAllAllergies = function (collection, isChecked) {
          angular.forEach(collection, function(data){
            data.allergyChecked = isChecked;
          });
        };

        scope.checkAllMedications = function (medications, userMedications, isChecked) {
          angular.forEach(medications, function(data){
            data.medicationChecked = isChecked;
          });
          angular.forEach(userMedications, function(data){
            data.medicationChecked = isChecked ? true : false;
          });
        };

        scope.checkAllAppointments = function (collection, isChecked) {
          angular.forEach(collection, function(data){
            data.isChecked = isChecked;
          });
        };

        scope.checkAllCareTeams = function (collection, isChecked) {
          angular.forEach(collection, function(data){
            data.isChecked = isChecked;
          });
          angular.forEach(scope.patientCareTeams, function (data){
              data.isChecked = isChecked;
            });
          angular.forEach(scope.carePlan.careCommunities, function (data){
            data.isChecked = isChecked;
          });
        };

        scope.checkAllTasks = function (collection, isChecked) {
          angular.forEach(collection, function(data){
            data.isChecked = isChecked;
          });
        };
        
        scope.checkAllBodyMeasurements = function (isChecked) {
          scope.bodyMeasurements.heightChk = isChecked;
          scope.bodyMeasurements.weightChk = isChecked;
          scope.bodyMeasurements.bmiChk = isChecked;
          scope.bodyMeasurements.bpChk = isChecked;
        };
        
        scope.valiateTime = function(timeValue){
          if(!timeValue.defaultTime){
            timeValue.invalidtime = true;
          }else{
            timeValue.invalidtime = false;
          }
        };

        var getCarePlanHtml = function(styles){
          function fixupCssForPdf(css){
            // import makes pdf generator very slow, so we remove it as it is not needed.
            var exp = /@import url\("\/\/fonts.googleapis.com.*\);/g;
            return css.replace(exp, '');
          }
          styles = fixupCssForPdf(styles);
          var contents = '';
          contents += '<html><head><title>Care Plan</title>';
          contents += '<style>';
          contents += styles;
          contents += '</style>';
          contents += '</head><body>';
          contents += $('#printable').html();
          contents += '</body></html>';
          return contents;
        };

        scope.saveCarePlanVersion = function(isSendToEmr){
          $.get('/themes/default/pdf_careplan.css', function(data) {
            scope.setPrintable();
            $timeout(function() {
              var htmlContent = getCarePlanHtml(data);
              $timeout(function() {
                scope.reSetPrintable();
                var base64EncodedZippedFile = zipFile.getBase64EncodedZippedFile('htmlContent.html', htmlContent);
                // -- prepare data to save --

                // conditions to save
                var selectedConditions = _.where(scope.carePlan.conditions, {conditionChecked: true});
                var conditionsToSave = _.map(selectedConditions, function (item) {
                  return {
                    conditionId: item.diseaseId,
                    notes: item.HealthConditionNotes
                  };
                });

                // combine both medications and user defined medications
                var selectedMedications = _.where(scope.carePlan.medications, {medicationChecked: true});
                var patientMedicationsToSave = _.map(selectedMedications, function (item) {
                  return {
                    medicationId: item.id,
                    medicationDetails: item.name,
                    notes: item.notes
                  };
                });
                var selectedUserMedications = _.where(scope.carePlan.userMedications, {medicationChecked: true});
                var userMedicationsToSave = _.map(selectedUserMedications, function (item) {
                  return {
                    medicationDetails: item.medicationDetails,
                    notes: item.instructions
                  };
                });
                //combine both user defined and system defined medications
                var medicationsToSave = _.union(patientMedicationsToSave, userMedicationsToSave);

                // allergies
                var selectedAllergy = _.where(scope.carePlan.allergies, {allergyChecked: true});
                var allergiesToSave = _.map(selectedAllergy, function (item) {
                  return {
                    name: item.allergyText,
                    lastReactionOccured: item.lastReactionOccurred,
                    allergyType: item.selectedAllergyType,
                    notes: item.reactionsAndAdditionalComments
                  };
                });

                // appointments - Providers
                var selectedProviderAppointments = _.where(scope.carePlan.appointmentsWithProviders, {isChecked: true});
                var providerAppointmentsToSave = _.map(selectedProviderAppointments, function (item) {
                  return {
                    appointmentDetails: item.physicianName,
                    appointmentTime: item.defaultTime,
                    notes: item.instruction,
                    appointmentType: 'Providers'
                  };
                });
                // appointments - Community Services
                var appointmentsWithCommunityServicesToSave = _.where(scope.carePlan.appointmentsWithCommunityServices, {isChecked: true});
                var communityServicesAppointmentsToSave = _.map(appointmentsWithCommunityServicesToSave, function (item) {
                  return {
                    appointmentDetails: item.communityService,
                    appointmentTime: item.defaultTime,
                    notes: item.instruction,
                    appointmentType: 'Community Services'
                  };
                });
                // combine community services and provider appointments
                var appointmentsToSave = _.union(providerAppointmentsToSave, communityServicesAppointmentsToSave);

                // combine both care teams and community services
                var selectedCareTeams = _.where(scope.carePlan.careTeams, {isChecked: true});
                var careTeamsToSave = _.map(selectedCareTeams, function (item) {
                  return {
                    contactId: item.id,
                    name: item.name,
                    phone: item.phone,
                    email: item.email,
                    contactType: 'Care Team'
                  };
                });

                var selectedCommunityServices = _.where(scope.carePlan.careCommunities, {isChecked: true});
                var communityServicesToSave = _.map(selectedCommunityServices, function (item) {
                  return {
                    contactId: item.id,
                    name: item.name,
                    phone: item.phone,
                    email: item.email,
                    contactType: 'Care Community'
                  };
                });

                var selectedUserContacts = _.where(scope.patientCareTeams, {isChecked: true});
                var userContactsToSave = _.map(selectedUserContacts, function (item) {
                  return {
                    contactId: item.id,
                    name: item.name,
                    phone: item.phone,
                    email: item.email
                  };
                });

                // combine community services and provider appointments
                var contactsToSave = _.union(careTeamsToSave, communityServicesToSave, userContactsToSave);

                // activities to save
                var selectedActivities = _.where(scope.carePlan.tasks, {isChecked: true});
                var activitiesToSave = _.map(selectedActivities, function (item) {
                  return {
                    activityId: item.Id,
                    notes: item.taskNotes
                  };
                });

                // goals to save
                var goalsToSave = [];
                angular.forEach(scope.carePlan.goals, function(goal){
                  var selectedGoalActivities = _.where(goal.patientActivities, {activityChecked: true});
                  var goalToSave = _.map(selectedGoalActivities, function (item) {
                    return {
                      goalId: item.goalId,
                      activityId: item.activityId,
                      notes: item.instruction
                    };
                  });
                  goalsToSave = _.union(goalsToSave, goalToSave);
                });

                var postCarePlan = {
                  careplan: {
                    carePlanId: 0,
                    patientId: patientData.id,
                    pdfContentBase64: base64EncodedZippedFile,
                    overview: scope.carePlan.overview,
                    height: scope.carePlan.height,
                    weight: scope.carePlan.weight,
                    bMI: scope.carePlan.bmi,
                    bloodPressure: scope.carePlan.bp,
                    conditions: conditionsToSave,
                    allergies: allergiesToSave,
                    medications: medicationsToSave,
                    appointments: appointmentsToSave,
                    contacts: contactsToSave,
                    activities: activitiesToSave,
                    goals: goalsToSave
                  },
                  patientId: patientData.id
                };
                carePlanSvc.saveCarePlan(patientData.id, postCarePlan).then(function (response) {
                  if(isSendToEmr){
                    var carePlanId = response.data.results;
                    carePlanSvc.sendPdfToEmr(patientData.id, carePlanId).then(function(){
                      scope.showAlert('Care plan has been sent to EMR successfully.','alert-success');
                    });
                    carePlanSvc.getCarePlans(patientData.id).then(function (response) {
                      scope.carePlan.carePlanVersions = response.data.results;
                    });
                  }
                  else{
                    scope.isSave = true;
                    localStorage.setItem('successAlert', true);
                    window.location.href = '/patients/'+ patientData.id;
                  }
                });
              }, 1000);
            }, 1000);
          });
        };

        scope.downloadCarePlanPdf = function(id){
          carePlanSvc.getCarePlanPdf(patientData.id, id).then(function (response) {
            var fileName = 'care-plan '+ moment().format('MMDDYY-HHMMSS') +'.pdf';
            var a = document.createElement('a');
            document.body.appendChild(a);
            var file = carePlanSvc.base64toBlob(response.data.results.pdfContent);
            var fileURL = window.URL.createObjectURL(file);
            a.href = fileURL;
            a.download = fileName;
            $timeout(function() {
              a.click();
            }, 500);
          });
          scope.showAlert('Care plan downloaded successfully.','alert-success');
        };

        scope.viewCarePlanPdf = function(id){
          carePlanSvc.getCarePlanPdf(patientData.id, id).then(function (response) {
            var a = document.createElement('a');
            document.body.appendChild(a);
            var file = carePlanSvc.base64toBlob(response.data.results.pdfContent);
            var fileURL = window.URL.createObjectURL(file);
            window.open(fileURL,'_self');
          });
        };

        scope.sendToEmr = function(carePlanId){
          carePlanSvc.sendPdfToEmr(patientData.id, carePlanId).then(function(){
            scope.showAlert('Care plan has been sent to EMR successfully.','alert-success');
          });
        };

        scope.setPrintable = function(){
          scope.printStatus = true;
          scope.printlogo=true;
          scope.printback=true;
          scope.goalClass = scope.carePlan.goals.length === 0 ;
          scope.overviewClass = (scope.carePlan.overview === '');
          scope.healthConditionsClass = (_.where(scope.carePlan.conditions, {conditionChecked: true}).length === 0);
          scope.taskClass =  (_.where(scope.carePlan.tasks, {isChecked: true}).length === 0);
          scope.allergyClass = (_.where(scope.carePlan.allergies, {allergyChecked: true}).length === 0);
          scope.medicationClass = (_.where(scope.carePlan.medications, {medicationChecked: true}).length === 0) && (_.where(scope.carePlan.userMedications, {medicationChecked: true}).length === 0);
          scope.careTeamContactsClass = (_.where(scope.carePlan.careTeams, {isChecked: true}).length === 0) && (_.where(scope.patientCareTeams, {isChecked: true}).length === 0) && (_.where(scope.carePlan.careCommunities, {isChecked: true}).length === 0);
          scope.appointmentsWithProvidersClass = (_.where(scope.carePlan.appointmentsWithProviders, {isChecked: true}).length === 0);
          scope.appointmentsWithCommunityServicesClass = (_.where(scope.carePlan.appointmentsWithCommunityServices, {isChecked: true}).length === 0);
          scope.bodyMeasurementsClass = (!scope.bodyMeasurements.heightChk && !scope.bodyMeasurements.weightChk && !scope.bodyMeasurements.bmiChk && !scope.bodyMeasurements.bpChk);
          scope.bodyMeasurementsHeightClass = !scope.bodyMeasurements.heightChk;
          scope.bodyMeasurementsWeightClass = !scope.bodyMeasurements.weightChk;
          scope.bodyMeasurementsBmiClass = !scope.bodyMeasurements.bmiChk;
          scope.bodyMeasurementsBpClass = !scope.bodyMeasurements.bpChk;
          angular.forEach(scope.carePlan.conditions, function(data){
            data.conditionClass = !data.conditionChecked;
          });
          angular.forEach(scope.carePlan.tasks, function(data){
            data.isCheckedClass = !data.isChecked;
          });
          angular.forEach(scope.carePlan.allergies, function(data){
            data.allergyClass = !data.allergyChecked;
          });
          angular.forEach(scope.carePlan.medications, function(data){
            data.medicationClass = !data.medicationChecked;
          });
          angular.forEach(scope.carePlan.userMedications, function(data){
            data.medicationClass = !data.medicationChecked;
          });
          angular.forEach(scope.carePlan.appointmentsWithProviders, function(data){
            data.isCheckedClass = !data.isChecked;
          });
          angular.forEach(scope.carePlan.appointmentsWithCommunityServices, function(data){
            data.isCheckedClass = !data.isChecked;
          });
          angular.forEach(scope.carePlan.careTeams, function(data){
            data.isCheckedClass = !data.isChecked;
          });
          angular.forEach(scope.patientCareTeams, function(data){
            data.isCheckedClass = !data.isChecked;
          });
          angular.forEach(scope.carePlan.careCommunities, function(data){
            data.isCheckedClass = !data.isChecked;
          });
          angular.forEach(scope.carePlan.goals, function(goalsList){
            goalsList.isOpen = true;
            angular.forEach(goalsList.patientActivities, function(activity){
              activity.activityCheckedClass =!activity.activityChecked;
            });
          });
        };

        scope.reSetForm = function() {
          scope.carePlan.bmi = null;
          scope.carePlan.bp = null;
          scope.carePlan.height = null;
          scope.carePlan.weight = null;
          scope.carePlan.patient = {};
          scope.carePlan.conditions = [];
          scope.carePlan.tasks = [];
          scope.accordionStatus = {};
          scope.accordionStatus.openPD = true;
          scope.providerDate = {};
          scope.ismeridian = true;
          scope.carePlan.medicationAllergies = [];
          scope.carePlan.appointmentsWithProviders = [];
          scope.carePlan.appointmentsWithCommunityServices = [];
          scope.carePlan.careTeams = [];
          scope.carePlan.careCommunities = [];
          scope.carePlan.goals = [];
          scope.carePlan.allergies = [];
          scope.mostRecentCarePlan = {};
          scope.hstep = 1;
          scope.mstep = 1;
          scope.ismeridian = true;
          scope.carePlan.overview = null;
          scope.bodyMeasurements = {};
          scope.patientCareTeams = [];
          scope.carePlan.allergyTypes = [{allergyType:'Environment'},{allergyType:'Food'},{allergyType:'Medication'}];
          scope.carePlan.medications = [];
          scope.carePlan.userMedications = [];
          scope.goalsInfo = {};
          scope.printStatus = false;
          scope.carePlan.overview = '';
          scope.overviewClass = false;
          scope.healthConditionsClass = false;
          scope.taskClass = false;
          scope.allergyClass = false;
          scope.medicationClass = false;
          scope.careTeamContactsClass = false;
          scope.appointmentsWithProvidersClass = false;
          scope.appointmentsWithCommunityServicesClass = false;
          scope.goalClass = false;
          scope.bodyMeasurementsHeightClass = false;
          scope.bodyMeasurementsWeightClass = false;
          scope.bodyMeasurementsBmiClass = false;
          scope.bodyMeasurementsBpClass = false;
          scope.bodyMeasurementsClass = false;
          scope.bodyMeasurements.heightChk = false;
          scope.bodyMeasurements.weightChk = false;
          scope.bodyMeasurements.bmiChk = false;
          scope.bodyMeasurements.bpChk = false;
          scope.openAcc = false;
          scope.isPopup = false;

          loadPatientInformation();
        };

        scope.reSetPrintable = function(){
          scope.mostRecentCarePlan = {};
          scope.printlogo=false;
          scope.printback=false;
          scope.printStatus = false;
          scope.overviewClass = false;
          scope.bodyMeasurementsClass = false;
          scope.bodyMeasurementsHeightClass = false;
          scope.bodyMeasurementsWeightClass = false;
          scope.bodyMeasurementsBmiClass = false;
          scope.bodyMeasurementsBpClass = false;
          scope.healthConditionsClass = false;
          scope.taskClass = false;
          scope.goalClass = false;
          scope.allergyClass = false;
          scope.medicationClass = false;
          scope.careTeamContactsClass = false;
          scope.appointmentsWithProvidersClass = false;
          scope.appointmentsWithCommunityServicesClass = false;
          angular.forEach(scope.carePlan.conditions, function(data){
            if(data.conditionChecked === false){
              data.conditionClass = !data.conditionClass;
            }
          });
          angular.forEach(scope.carePlan.tasks, function(data){
            if(data.isChecked === false){
              data.isCheckedClass = !data.isCheckedClass;
            }
          });
          angular.forEach(scope.carePlan.allergies, function(data){
            if(data.allergyChecked === false){
              data.allergyClass = !data.allergyClass;
            }
          });
          angular.forEach(scope.carePlan.medications, function(data){
            if(data.medicationChecked === false){
              data.medicationClass = !data.medicationClass;
            }
          });
          angular.forEach(scope.carePlan.userMedications, function(data){
            if(data.medicationChecked === false){
              data.medicationClass = !data.medicationClass;
            }
          });
          angular.forEach(scope.carePlan.appointmentsWithProviders, function(data){
            if(data.isChecked === false){
              data.isCheckedClass = !data.isCheckedClass;
            }
          });
          angular.forEach(scope.carePlan.appointmentsWithCommunityServices, function(data){
            if(data.isChecked === false){
              data.isCheckedClass = !data.isCheckedClass;
            }
          });
          angular.forEach(scope.carePlan.careTeams, function(data){
            if(data.isChecked === false){
              data.isCheckedClass = !data.isCheckedClass;
            }
          });
          angular.forEach(scope.patientCareTeams, function(data){
            if(data.isChecked === false){
              data.isCheckedClass = !data.isCheckedClass;
            }
          });
          angular.forEach(scope.carePlan.careCommunities, function(data){
            if(data.isChecked === false){
              data.isCheckedClass = !data.isCheckedClass;
            }
          });
          angular.forEach(scope.carePlan.goals, function(goalsList){
            goalsList.isOpen = false;
            angular.forEach(goalsList.patientActivities, function(activity){
              if(activity.activityChecked === false){
                activity.activityCheckedClass =!activity.activityCheckedClass;
              }
            });
          });
        };

        scope.printDiv=function() {
          scope.openAcc = 'false';
          scope.scrollCss = '';
          var htmlContent='';
          scope.setPrintable();
          $.get('/themes/default/pdf_careplan.css', function(data) {
            $timeout(function() {
              htmlContent = getCarePlanHtml(data);
              var frameData = $('<iframe />');
              frameData[0].name = 'frameData';
              frameData.css({ 'position': 'absolute', 'top': '-1000000px'});
              $('body').append(frameData);
              var frameDoc = frameData[0].contentWindow ? frameData[0].contentWindow : frameData[0].contentDocument.document ? frameData[0].contentDocument.document : frameData[0].contentDocument;
              frameDoc.document.open();
              frameDoc.document.write(htmlContent);
              frameDoc.document.write('<script>window.onload = function () { window.print();};</script></body></html>');
              frameDoc.document.close();
              scope.reSetPrintable();
            }, 1000);
          });
        };

        scope.enableRow = function(id, section){
          switch (section) {
            case 'condition':
              angular.forEach(scope.carePlan.conditions, function(data){
                if(id === data.name){
                  data.conditionChecked = true;
                  data.conditionCheckedTxt = true;
                }
              });
              break;
            case 'allergy':
              angular.forEach(scope.carePlan.allergies, function(data){
                if(id === data.rowId){
                  data.allergyChecked = true;
                  data.allergyCheckedTxt = true;
                  scope.addAllergy(data.rowId);
                }
              });
              break;
            case 'medication':
              angular.forEach(scope.carePlan.medications, function(data){
                if(id === data.name){
                  data.medicationChecked = true;
                  data.medicationCheckedTxt = true;
                }
              });
              break;
            case 'userMedications':
              angular.forEach(scope.carePlan.userMedications, function(data){
                if(id === data.rowId){
                  data.medicationChecked = true;
                  data.medicationCheckedTxt = true;
                  scope.addMedication(data.rowId);
                }
              });
              break;
            case 'appointmentsWithProviders':
              angular.forEach(scope.carePlan.appointmentsWithProviders, function(data){
                if(id === data.rowId){
                  data.isChecked = true;
                  scope.addAppointmentsWithProviders(data.rowId);
                }
              });
              break;
            case 'appointmentsWithCommunityServices':
              angular.forEach(scope.carePlan.appointmentsWithCommunityServices, function(data){
                if(id === data.rowId){
                  data.isChecked = true;
                  scope.addAppointmentsWithCommunityServices(data.rowId);
                }
              });
              break;
            case 'careTeamContact':
              angular.forEach(scope.carePlan.careTeams, function(data){
                if(id === data.name){
                  data.isChecked = true;
                }
              });
              break;
            case 'professionalSupport':
              angular.forEach(scope.carePlan.careCommunities, function(data){
                if(id === data.id){
                  data.isChecked = true;
                }
              });
              break;
            case 'patientCareTeam':
              angular.forEach(scope.patientCareTeams, function(data){
                if(id === data.rowId){
                  data.isChecked = true;
                  scope.addCareTeam(id);
                }
              });
              break;
            case 'myActivities':
              angular.forEach(scope.carePlan.tasks, function(data){
                if(id === data.Id){
                  data.isChecked = true;
                }
              });
              break;
            case 'goalActivity':
              angular.forEach(scope.carePlan.goals, function(goalsList){
                angular.forEach(goalsList.patientActivities, function(activity){
                  if(id === activity.activityId){
                    activity.activityChecked = true;
                  }
                });
              });
              break;
          }
        };

        scope.errorOnTimeout = function () {scope.isError = false;};

        scope.showAlert = function (alertmessage, alerttype) {
          window.scrollTo(0, 0);
          scope.alertMessageStyle = alerttype;
          scope.alertMessage = alertmessage;
          scope.isError = true;
          $timeout(scope.errorOnTimeout, 6000);
        };
      }
    ]);
  }(window.app)
);