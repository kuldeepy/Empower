(function(app) {
  'use strict';
  
  app.controller('careIndicatorCtrl', ['$scope', '$modal', 'careIndicatorSvc', 'PatientData', '$timeout', 'authSvc', 'navConstantsSvc',
		function(scope, $modal, careIndicatorSvc, patientData, timeout, authSvc, navConstantsSvc){
			scope.allCareIndicator = [];
			scope.isShow = true;
			scope.hasEditAccess = (authSvc.user().role === navConstantsSvc.administrator || authSvc.user().role === navConstantsSvc.careManager) ? true : false;
			scope.careIndicatorHeader = [{ field: 'category', displayName: 'Category Name', columnClass: 'table-column-category' },
									{ field: 'description', displayName: 'Category Description', columnClass: 'table-column-descriptions' },
									{ field: 'lastUpdated', displayName: 'Last updated', columnClass: 'table-column-lastUpdated' },
									{ field: 'action', displayName: 'Actions', columnClass: 'table-column-actions' }];

			scope.getAllCareIndictors = function(){
				careIndicatorSvc.getPatientCareIndicators(patientData.id).then(function(res){
					scope.actvieCareIndicator = _.where(res.data.results,{'isActive':'A'});
					scope.inActvieCareIndicator = _.where(res.data.results,{'isActive':'I'});
				});
			};

			scope.addDeleteCareindicator = function(item){
				careIndicatorSvc.putPatientCareIndicator(patientData.id,{patientCareIndicatorId: item.patientCareIndicatorId,isActive: (item.isActive === 'A' ? 'I' : 'A')}).then(function(){
					patientData.isMenuDirty = true;
					scope.getAllCareIndictors();
					scope.alertMessage = item.category + ' has been ' + (item.isActive === 'A' ? 'Inactivated' : 'Activated') + ' successfully.';
					scope.showNotification = true;
					timeout(function() { scope.showNotification = false;}, 6000);
				});
			};

			scope.addCareIndicator = function(){
				careIndicatorSvc.getCareIndicators().then(function(res){
					scope.careIndicatorList = res.data.results;
				});
				scope.careIndicatorModel = {id: '', description: ''};
				scope.modalPopUp = $modal.open({
					templateUrl: 'myModalContent.html',
					scope: scope,
					backdrop : 'static'
				});
			};

			scope.saveCareIndicator = function(item){
				careIndicatorSvc.postPatientCareIndicator(patientData.id,{careIndicatorId: item.id,description : item.description}).then(function(res){
					scope.careIndicatorList = res.data.results.careIndicators;
					patientData.isMenuDirty = true;
					scope.getAllCareIndictors();
					scope.alertMessage = 'Care Indicator has been added successfully.';
					scope.showNotification = true;
					timeout(function() { scope.showNotification = false;}, 6000);
				});
				scope.modalPopUp.close();
			};

			scope.closeModal = function(){
				scope.modalPopUp.close();
			};

			scope.viewHistory = function(row){
				row.isShow = !row.isShow;
				careIndicatorSvc.getPatientCareIndicatorHistory(patientData.id, row.patientCareIndicatorId).then(function(res){
					row.history = res.data.results;
				});
			};

			scope.getAllCareIndictors();
		}
	]);
})(window.app);