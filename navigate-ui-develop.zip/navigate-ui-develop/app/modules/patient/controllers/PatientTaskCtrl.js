(function (app) {
  /* @fmt: off */
  'use strict';
  // @fmt:on
  app.controller('PatientTaskCtrl', ['$scope', '$timeout', 'PatientData', '_', '$window', 'patientTaskSvc', '$location', 'authSvc','listStateSvc', 'navConstantsSvc', 'userConcurrentLockSvc',
    function (scope, timeout, patientData, _, $window, patientTaskSvc, location, authSvc, listStateSvc, navConstantsSvc, userConcurrentLockSvc) {
      /* variable declarations */
      scope.controllerData = {
        accordionData: []
      };

      scope.hide=false;
      patientData.id = app.routing.routeParams.patientId;
      scope.hasEditAccess = authSvc.hasEditAccess();
      scope.user = authSvc.user();
      scope.currentIndex = 1;
      
      scope.isMergeNotificationLocked = true;
      scope.patientid = patientData.id;
      scope.activePosition = 0;
      scope.menuIndex = 0;
      scope.errorCount = 0;

      scope.completeTaskPopup = false;
      scope.completeTaskError = false;

      scope.taskCompletedCount = 0;

      scope.accordionStatus = {
        openPD: false,
        openToday: false,
        openFuture: false,
        openWC: false,
        openMO: false,
        openCC: false
      };

      scope.closeAccordian = function(){
        scope.accordionStatus = {
          openPD: false,
          openToday: false,
          openFuture: false,
          openWC: false,
          openMO: false,
          openCC: false
        };
        window.scrollTo(0, 0);
      };

      /*Assessment Survey */
      scope.assessmentPopup = false;
      scope.assessmentSurveyComplete=false;
      scope.assessmentCompleteMessage='';
      scope.assessmentId='';
      scope.userAssessmentID='';
      scope.assessmentName='';
      scope.currentAssessment = 0;
      scope.assessmentQuestionsLenght='';
      scope.assessmentSets = [];

      scope.closeModal = function (className) {
        $('.' + className + '').modal('hide');
      };

      scope.closeAssessemtModel = function () {
        scope.UnlockConcurrentTask();
        scope.closeModal('cancelConfirm', 'hide');
        scope.closeModal('openTaskPopUp', 'hide');
      };

      scope.saveAssessmentSurvey = function (type) {
        scope.addAssessment = type;
      };

      scope.addNewTask = function(){
        listStateSvc.clear();
        location.path(app.currentRoute+'/task/add');
      };

      scope.prevPage = function () {
            if (scope.currentAssessment > 0) {
              scope.currentAssessment=scope.currentAssessment-1;
              scope.selectedAssessment = scope.assessmentSets[scope.currentAssessment];
            }
          };

      scope.nextPage = function () {
            if (scope.currentAssessment < scope.assessmentSets.length - 1) {
              scope.currentAssessment=scope.currentAssessment+1;
              scope.selectedAssessment = scope.assessmentSets[scope.currentAssessment];
            }
          };

      scope.cancelAssessment = function () {
        scope.UnlockConcurrentTask();
        scope.assessmentPopup = false;
        scope.disgard();
      };


      /*Assessment Survey End*/
      scope.patientTasks = [
        { id: 'pastDue', tasks: [], name: 'Past Due' },
        { id: 'today', tasks: [], name: 'Today\'s' },
        { id: 'future', tasks: [], name: 'Future' },
        { id: 'claims', tasks: [], name: 'Waiting for Claims' },
        { id: 'opportunity', tasks: [], name: 'Missed Opportunity' },
        { id: 'completed', tasks: [], name: 'Completed Tasks' }
      ];

      /* field value for Admission Tool-tip   */
      scope.FieldForAdmission = {
        admittedOn:   'Admitted On                :',
        facilityName: 'Facility Name              : ',
        lastDischargeDate: 'Last Discharge Date  : ',
        lastFacilityName: 'Last Facility Name     : ',
        inpatientDays: 'No. of days between <br />current admission <br/>and last discharge     : '
      };

      scope.FieldForERVisit = {
        erDate: 'ER Date                        :',
        facilityName: 'Facility Name     : ',
        lastDischargeDate: 'Last Discharge Date   : ',
        lastFacilityName: 'Last Facility Name     : ',
        inpatientDays: 'No. of days between current admission and last discharge: '
      };

      /* field value for Discharged Tool-tip  */
      scope.FieldForDischarged = {
        discharge: 'Discharged On             :',
        facilityName: 'Facility Name               : ',
        dischargeTo: 'Discharged To             : ',
        admittedOn: 'Admitted On                 : ',
        inpatientDays: 'No. of Inpatient Days  : '
      };

      /* initialize method which is called when this controller is loaded */
      scope.init = function () {
        scope.bindData();
        scope.ShowSuccessNotification();
        scope.UnlockConcurrentTask();
        if(localStorage.getItem('successAlert')){
          scope.showAlert('Care Plan has been saved successfully.', 'alert-success');
          localStorage.removeItem('successAlert');
        }
      };

      /* bind data */
      scope.bindData = function () {
        scope.getOtherTasksData();
        scope.getMissedOpportunityData();
      };

      /* function to get other tasks details for accordion */
      scope.getOtherTasksData = function () {
        patientTaskSvc.getPatientTasks(patientData.id).then(function(response){
          if(response.data.results){
            scope.allTaskData = response.data;
            scope.groupTask(response.data);
          }
        });
      };

      /* function to get missed opportunity tasks details for accordion */
      scope.getMissedOpportunityData = function () {
        patientTaskSvc.getPatientMissedOpportunity(patientData.id).then(function(response){
          if(response.data.results){
            scope.patientTasks[4].tasks = _.filter(response.data.results, function (item) {
              item.DateDue = window.moment(item.DateDue).format('MM/DD/YYYY');
              item.OpprotunityDate = window.moment(item.OpprotunityDate).format('MM/DD/YYYY');
              return true;
            });
          }
        });
      };

      /* function to group the tasks */
      scope.groupTask = function (data) {
        var dateDue,today = window.moment(new Date()).format('MM/DD/YYYY');
        scope.patientTasks[3].tasks = _.filter(data.results, function (item) {
          item.DateDue = window.moment(item.DateDue).format('MM/DD/YYYY');
          if(item.IsWaitingForClaims)
          {
            item.CompletedDate = window.moment(item.CompletedDate).format('MM/DD/YYYY');
          }
          item.ReminderDate = window.moment(item.ReminderDate).format('MM/DD/YYYY');
          return item.IsWaitingForClaims;
        });
        scope.patientTasks[0].tasks = _.filter(data.results, function (item) {
          if (item.IsWaitingForClaims) { return false; }
          if(!item.IsAdhoc){
            dateDue = item.ReminderDate;
          }
          else{
            dateDue = item.DateDue;
          }
          return (dateDue < today);
        });
        scope.patientTasks[1].tasks = _.filter(data.results, function (item) {
          if (item.IsWaitingForClaims) { return false; }
          if(!item.IsAdhoc){
            dateDue = item.ReminderDate;
          }
          else{
            dateDue = item.DateDue;
          }
          return (dateDue === today);
        });
        scope.patientTasks[2].tasks = _.filter(data.results, function (item) {
          if (item.IsWaitingForClaims) { return false; }
          if(!item.IsAdhoc){
            dateDue = item.ReminderDate;
          }
          else{
            dateDue = item.DateDue;
          }
          return (dateDue > today);
        });
      };
    
      scope.ShowSuccessNotification = function () {
        window.scrollTo(0, 0);
        scope.notification = {
          visible: patientData.isTaskAddedSuccesfully,
          message: ' Task has been added successfully',
        };
        timeout(function () {
          scope.notification.visible = false;
          patientData.isTaskAddedSuccesfully = false;
        }, 5000);
      };

      scope.showAlert = function (alertmessage, alerttype) {
        window.scrollTo(0, 0);
        scope.alertMessageStyle = alerttype;
        scope.alertMessage = alertmessage;
        scope.isError = true;
        timeout(function () {
          scope.isError = false;
        }, 6000);
      };
      scope.isLocked=false;
      scope.completeTask = function (task) {
        switch(task.TaskTypeName){
          case 'Goal':
          case 'Activity':
            $window.location.href = app.currentRoute +'/goals?goalId=' + task.TaskSpecificId +'&taskType='+task.TaskTypeName;
            break;
          case 'Assessment':
            if(scope.isLocked === false){
              task.page = '';
              localStorage.setItem('selectedassessment', JSON.stringify(task));
              location.path(app.currentRoute+'/completion');
            }
            break;
          case 'Other Tasks':
          case 'Schedule Procedure':
          case 'Education Material':
          case 'Managed Population Enrollment':
          case 'Medication Prescription':
          case 'Communications':
            if(scope.isLocked === false){
              scope.completeTaskPopup = true;
              scope.confirmComplete = function() {
                var messageBody = {
                  specificTaskId: task.TaskSpecificId,
                  taskTypeName: task.TaskTypeName,
                  comments: ''
                };
                patientTaskSvc.putPatientTask(patientData.id,task.Id, messageBody).then(function(response){
                  if(response.data.results){
                    scope.showAlert('Task has been completed successfully.','alert-success');
                    scope.completeTaskPopup = false;
                    scope.getOtherTasksData();
                    scope.resetCompletedTasks();
                  }
                  else{
                    scope.completeTaskError = true;
                  }
                });
              };
            }
            break;
        }
        
      };

      scope.resetCompletedTasks = function(){
        scope.currentIndex = 1;
        scope.taskCompletedCount = 0;
        scope.patientTasks[5].tasks = [];
        scope.getCompletedTasksData();
      };

      scope.closeCompleteTaskPopup = function () {
        scope.completeTaskPopup = false;
        scope.UnlockConcurrentTask();
        //Account for fade effect.
        setTimeout(function() {
          scope.completeTaskError = false;
        }, 500);
      };

      scope.UnlockConcurrentTask = function() {
        scope.data={'patientId':patientData.id,'lockType':'patientdashboard'};
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
          scope.status=response.data.results.status;
          if(scope.status === true){
            scope.isMergeNotificationLocked = true;
            scope.data={'taskId':scope.selectedTaskId,'lockType':'task', 'isLocked': false};
            userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(){
            });
          }
          else{
            scope.isMergeNotificationLocked = false;
          }
        });
      };

      scope.lockConcurrentTask = function(task){
        scope.selectedTaskId = task.Id;
        scope.data={'taskId':task.Id,'lockType':'task', 'isLocked': true};
        userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
            scope.status=response.data.results.status;
            if(scope.status === true){
              scope.lockedText = '';
              scope.isLocked = false;
              scope.completeTask(task);
            }
            else{
              scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName',response.data.results.name);
              scope.isLocked = true;
            }
          });
      };

      scope.resetToolTipText=function(){
        scope.isLocked = false;
      };
      scope.opentaskDetails = function(task){
        if(scope.isMergeNotificationLocked)
        {
          switch(task.TaskTypeName){
            case 'Goal':
              localStorage.setItem('goalData', JSON.stringify(task));
              $window.location.href = app.currentRoute +'/goals';
              break;
            case 'Assessment':
              task.status ='Closed Complete';
              task.page = '';
              localStorage.setItem('selectedassessment', JSON.stringify(task));
              location.path(app.currentRoute+'/completion');
              break;
          }
        }
      };
      
      scope.getCompletedTasksData = function() {
        var filterData = {
          pageIndex : scope.currentIndex,
          pageSize : 20
        };
        if(scope.taskCompletedCount === 0 || (scope.patientTasks[5].tasks.length < scope.taskCompletedCount )) {
          patientTaskSvc.getPatientCompletedTasks(patientData.id,filterData).then(function(response){
            if(response.data.results){
              if(scope.currentIndex === 1){
                scope.taskCompletedCount = response.data.results.ClosedCompleteCount;
              }
              scope.taskCompletedTemp = response.data.results.PatientTasks;
              scope.currentIndex = scope.currentIndex + 1;
              response.data.results.PatientTasks.forEach(function(item){
                item.DateDue = window.moment(item.DateDue).format('MM/DD/YYYY');
                item.CompletedDate = window.moment(item.CompletedDate).format('MM/DD/YYYY');
                scope.patientTasks[5].tasks.push(item);
              });
            }
          });
        }
      };

      scope.pageload = function(){
        if(localStorage.getItem('alert')){
          var message = JSON.parse(localStorage.getItem('alert'));
          scope.showAlert(message.alertmessage,message.alerttype);
          localStorage.removeItem('alert');
        }
      };

      scope.loadMoreRecords = function () {
        scope.getCompletedTasksData();
      };

      scope.loadMoreRecords();
      scope.pageload();
      scope.$on('updateCompletTask', function() {
        scope.resetCompletedTasks();
      });


    }]);
}(window.app));
