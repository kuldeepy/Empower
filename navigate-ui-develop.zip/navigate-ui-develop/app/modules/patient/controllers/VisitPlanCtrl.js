(
  function (app) {
      /* @fmt: off */
      'use strict';
      // @fmt:on
      app.controller('patientVisitPlanCtrl', ['$scope', '$http', 'PatientData', 'patientVisitPlanSvc', 'visitPlanConstantsSvc','populationManagementSvc','careCommunitySvc','navConstantsSvc',
        function (scope, http, patientData, patientVisitPlanSvc, visitPlanConstantsSvc, populationManagementSvc, careCommunitySvc, navConstantsSvc) {
          scope.conditionslist = [];
          scope.clinicallist = [];
          scope.Medicationslist = [];
          scope.UtilizationHL7list = [];
          scope.UtilizationClaimslist = [];
          scope.CareTeamlist = [];
          scope.professionalSupportTeamGridData = [];
          scope.familyFriendsTeamGridData = [];
          scope.CareProviderlist = [];
          scope.assessmentslist = [];
          scope.ManagedPopulationPendinglist = [];
          scope.ManagedPopulationlist = [];
          scope.ManagedPopulationDisenrollmentlist = [];
          scope.StandardQualitylist = [];
          scope.OpenTasklist = [];
          scope.ClosedTasklist = [];

          scope.getRelationShipData = function () {

            careCommunitySvc.getRelationShip().then(function (response) {
              careCommunitySvc.patientRelations = response.data.results;
              scope.relationShipData = response.data.results;
            });

          };

          scope.getpatientInfo =function(){
            http.get(app.api.root+'patients/' + patientData.id)
            .success(function (data) {
              scope.PatientDetails=data.results;
              scope.getallVisitPlanGrids();

            });
          };
          scope.getpatientInfo();
          scope.getRelationShipData();

          scope.getallVisitPlanGrids = function(){
            http.get(app.api.root + 'patients/' + patientData.id + '/conditions')
            .success(function(data){
              scope.conditionslist = _.sortBy(data.results,'diagnosedDate').reverse();
            });

            careCommunitySvc.getCareCommunities(navConstantsSvc.professionalSupportTeam).then(function (response) {
              if (response.data.results) {
                scope.professionalCareTeamGridData = response.data.results;

                _.each(scope.professionalCareTeamGridData,function(item){
                  item.relationshipTitle = _.filter(careCommunitySvc.patientRelations,{id:parseInt(item.relationship)})[0].name;
                });
              }
            });

            careCommunitySvc.getCareCommunities(navConstantsSvc.familyFriendsTeam).then(function (response) {
              if (response.data.results) {
                scope.familyCareTeamGridData = response.data.results;

                _.each(scope.familyCareTeamGridData,function(item){
                  item.relationshipTitle = _.filter(careCommunitySvc.patientRelations,{id:parseInt(item.relationship)})[0].name;
                });

              }
            });
            http.get(app.api.root + 'patients/' + patientData.id + '/clinical-results')
            .success(function(data){
              scope.clinicallist = data.results;
            });
            http.get(app.api.root + 'patients/' + patientData.id + '/medications')
            .success(function(data){
              scope.Medicationslist = data.results;
            });
            http.get(app.api.root + 'patients/' + patientData.id + '/utilization-events')
            .success(function(data){
              scope.UtilizationHL7list = data.results;
            });
            http.get(app.api.root + 'patients/' + patientData.id + '/utilization-encounters')
            .success(function(data){
              scope.UtilizationClaimslist = data.results;
            });
            http.get(app.api.root + 'patients/' + patientData.id + '/care-teams')
            .success(function(data){
              scope.CareTeamlist = data.results;
              angular.forEach(scope.CareTeamlist, function(value, key){
                scope.CareTeamlist[key].supervisor = patientData.formatName(value.supervisor);

                angular.forEach(value.managers, function(value2, key2){
                  scope.CareTeamlist[key].managers[key2] = patientData.formatName(value2);
                });
              });
            });
            http.get(app.api.root + 'patients/' + patientData.id + '/providers')
            .success(function(data){
              scope.CareProviderlist = data.results;
            });
            patientVisitPlanSvc.getCompletedAssessments(patientData.id)
            .success(function (data) {
              var assessmentresult=[];
              data.results.forEach(function(res){
                assessmentresult.push({assessmentName:res.assessmentName,dateDue:res.dateDue,dateTaken:res.dateTaken,programName: res.programName,dateCompleted:res.taskCompletedDate,
                  scoreRange:((res.scoreRange!==null && res.scoreRange!==0)?res.scoreRange:'N/A'),maxscore:res.maxscore,completedBy:res.completedBy});
              });
              scope.assessmentslist = assessmentresult;
            });

            http.get(app.api.root + 'patients/' + patientData.id + '/patient-populations')
            .success(function(data){
              scope.ManagedPopulationlist =_.sortBy(data.results,'enrollmentStartDate').reverse();
            });

            populationManagementSvc.getPatientPopulationsByType(patientData.id,'I')
            .then(function (response) {
              scope.ManagedPopulationDisenrollmentlist = response.data.results;
            });
            populationManagementSvc.getPatientPopulationsByType(patientData.id,'P')
              .then(function (response) {
                scope.ManagedPopulationPendinglist= response.data.results;
              });

            http.get(app.api.root + 'patients/' + patientData.id + '/visit-plan')
            .success(function(data){
              scope.StandardQualitylist = data.results;
            });
            http.get(app.api.root+'patients/'+ patientData.id +'/tasks',{ params : { pageType : 'V' } })
            .success(function (data) {
              var OpenTaskData = _.filter(data.results, function (item) {
                return (item.CompletedDate === null);
              });
              var ClosedTaskData = _.filter(data.results, function (item) {
                return (item.CompletedDate !== null);
              });
              scope.OpenTasklist=OpenTaskData;
              scope.ClosedTasks(ClosedTaskData);
            });

          };
          scope.ClosedTasks=function(ClosedData){
            var Closedres=[];
            var missedopportunitiesres=[];
            http.get(app.api.root+'patients/'+ patientData.id +'/missed-opportunities')
            .success(function (data) {
              if(ClosedData!==null)
               {
                ClosedData.forEach(function(res){
                  Closedres.push({'taskType':res.TaskTypeName,'TaskName':res.Name,'ProgramName' : res.ProgramName ,'dueDate':res.DateDue,'TaskCompletionDate':res.CompletedDate,'MissedTask':''});
                });
              }
              if(data.results!==null)
               {
                data.results.forEach(function(res){
                  missedopportunitiesres.push({'taskType':res.TaskTypeName,'TaskName':res.Name,'ProgramName' : res.ProgramName, 'dueDate':res.DateDue,'TaskCompletionDate':'','MissedTask': 'Yes ' + (res.Reason !== null ?(((((res.Reason).indexOf('-') > -1) === true) ? '- ' +((res.Reason).replace('-', '(') + ')') : '- ' + res.Reason)): '')});
                });
              }
              scope.ClosedTasklist=Closedres.concat(missedopportunitiesres);
            });
          };
          scope.convertEncountertoString=function(item){
            var DiagnosisArray=item.Diagnoses;
            var Diagnosis='';
            DiagnosisArray.forEach(function(data){
              if(Diagnosis==='')
                {Diagnosis=data;}
              else
                {Diagnosis=Diagnosis+', '+data;}
            });
            item.Diagnoses=Diagnosis;
          };

          scope.downloadPdf = function() {
            var firstStartY = 90;
            var imgData = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAlCAYAAAAHgqbCAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyRpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoTWFjaW50b3NoKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo4RTJEODI4NTQwQTMxMUU0OEI4MEFDNUY2REM2OTg1QiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo4RTJEODI4NjQwQTMxMUU0OEI4MEFDNUY2REM2OTg1QiI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkMwNDU4NTZDM0RBODExRTQ4QjgwQUM1RjZEQzY5ODVCIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjhFMkQ4Mjg0NDBBMzExRTQ4QjgwQUM1RjZEQzY5ODVCIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+RBE38wAACwxJREFUeNrsXQ1YVeUdfy9cEJiAIB9ZKJpJmE4I6skQmlhNHp3LPrbcmoQt19hymPVsz3LVmj09lDZX7RFntRDUzS3b3B7J5UpMRaaDEDQUVMAM0RDlQ1S497Lf/96XcTycc+659577Zef3PD/OPe/3ec///77/9+vABgYGmBxZSdEucBrzJEqKFoClTIcOD0BJ/olGO/HvAqshsEW4Ps9y88+7UTGm4u/vwW+Au/RXp8MXYFQRJhB8EqSW/Vlc34GiWDRUjCj8fRH8Cc9Lhw6fQYADYWPAdeB+CPWdGihGAPg4fh0Fl+jKocNfexAx0sEKCPd6XH+B3uSME8pxBzenbtPqQSYmjidljxA49R5vae4ThTHgEilw6kEYk0x6VDcjlcIiTBAuX1NZRKnyhAsahn74X1TxnCNwCRU4dSLegEQ4KlcQv7UgTJdEmAgHGsmLSKPfTp13I4xZptziupINK0o/FbwJpLrqBmsR74gD9aMEM09Tkx5EjEfBRgj7MjBIpWLEg+/iV6WWysExDjwv4PclwkSKwvxZIb1MUdhMiTBzRWGUKFWe3QL/jSqfM1+UbqRMuI2CMLUyYWodKP9cFXX+ukK5xXX1dQUhDwF/jp+tYBW4GXybX+vhR1zIGzx79aPE3VqaWFIgrX4NPAjBv1dBMYzgU/jVAOb5UA/6ICp5qW5IaIafoj4fdtESSMTlv+ArYLxMsGSSKnArwof5yhhECZPBD6EEW8BEkXLczVuq34q6Y1/Bq6jk6bpsa4a3UZ9JTioHjXM/AqfImENizAML/UFBBvEAeARKMZIrB93/myuQr4LMw7/g5URrkBZNi0fJcJOPC/afFMpO3KYyHXr3W1CfoU6UYTXpieD+HLPNbsZh3EFjwlhwMTe9CE3gS3bSTFF4pix3DNLtIUSQbgTzD4wlmx0vdY7UgNcB0MDzgp+2/H0alp3WtNaAixzoPajXeUTgREqQgTK1DDrgdzvvobZSowY+AbezdpLucuW5ApiOQeSAv9SrQTPkQZAdGW/eDwoH3cuEyiEE3L8Es8EGdz+E8Sv+EovB+3h3S1iBl7oXFe/sSv5qxO+Ueanzfbwuvo2y18j4bUT5V6o0kfK5FUEoQppViFunIu6twt6MBuAaPVcZytAn805SPasgtH+r6fMKNia+12ZBdh5hFlMjix09yUeFgloomq7+h6BH3YwKTXUyvZl+3FhECRoKMcpVpkGTMbTo+5bA3H4P9almSj9G8PsMhPeyRs/l0vhXOxOrta2J7alpYed6M9ihJtuC0onT7azp7CRW8elB1nOxyxelAi/in8w2pTiIeD6gvpZW9s0erE9arygROCUJFEYJPUJllVnj8Dhc70FI8A82nGBBIaksRGLiwoDnDApNYXUnrrCQwCo27eY0Fhho8DEB+hU4gw0tBmY7qSCrwC/cXNYe0f11oNQgNFw0G2QP/2LyU6anHCwjzTxRr3ELv6e1EXuzhE2C3yO5yVWtQX19D2zzvIKYzQOs7mg1u2SewoJD7ZskxqARzMTS2b7aVpYQ28PGJyT5inbQFhK+wEU2eCx3vsuJpMhWr3FzcZtE97MYTa1fPSNEyjFdZEraQxvKXq5RfV5EGR7CzwNsaHvJvSoUVLho+zKfVRy2MRbuwcw2Q7ZOxaxjJcI0u8vE2ifp2nyqgVXWtbH+gHQIfohDOY4IvZ592ZPEdlcfZp1dUi0bPfAuLygJTSvSNKOF+TbonQjt8+cgMGMFwkO9M235EK4wf+yF+qzH5ccORPkQPCy4n02mLp5ntEg5bsRlO7gWXONuU8xeD0Jmxw/AV61dOQl07bHTLCRsKgsOcS3nkLAprP5zEwuywOxKTmFBQVQW2qP1JMvNr/JST7IDFb4CP1/wQvZpyLtYxq9wcIMerr0I9wf8LBCYWHVw28xNqW8y24ZSoXml5gBapkL+VgFG3pscrM8NSJPM1idUhLUgLJlmOwUNN/Xq8+C+B9cOkJTjdjY0HUwKeJybtrJmL+L3KPjnOa8gufnUmpembSrZfq793PKW+pbFVuXQCoGBRmYJTA/YX38saXraW5PDR63620Pf8XYLvoKPRe72cL7UCzwq41csMqOe4+UbfBe0YfFHMoPzxyF8PSryn8iuXsUW4wJzbjfAUm7upahQkk8gzLn4SRtaBzfAhnGll8Kn4Ho7yT5oxz/PaROrdNtOA7jwqcixtS9NTC0onHHPpRgLO6Td3IrZlB4WWbU2Z/745XE3vfJAaMxe5Jfu5fEICRXtvD3tqzYWytjNe/fNSsHI7kfYv3u5rJe5kHapDL+RN1B7FILRLCltkp1Bi4beNLH2gv8/HHVDVNTo1XPmj95zrLHhj/W14f1BgWOczTjGYjj8dEb2dQlR0UKFoJbmAJTkhwvnZr/rYJLUwr0ouJcaLF8WhSmXeUln0ZLRwt4c4chLIugRUXqOzpas5SaSPTRLlJEEbgHKSfl/i7f+dBbiDH9vH8iddRHgd+AolWWtdLLOqazHUc77RRMfbQpKsh+XLMRJ44P7Ccy2RnOe5/G+whaTSlGZXILB+nEGGWwoK5f17DOZBtbv31e9u+Ps1AFj4IhhPdObrw+wJQV00KXxKo3s7299LDmlJ2tSktIs1htQkAKmQ4eboST/anoQWQQbjYbFGVnp87u7u16rKK//wmJOZQrzCQaz+UpmdNyhvNvvTKO4+qvR4Q9weaEwNjw8onD2vNTqky1Na2oOBFwJNl59HgQKekNAwMFlWbMmxEVEpOtVruMrpSCDSBuXOGHd2HFsx9HPKjY026yqnMQbTbdFxzbeHD8mRa9qL6GkiGaB4hithufmm0R+CdZxWW5+u0zc68lYkPDpkY0zFJdWzum4w0m7X8Gx5dOnmGZJEe3VGqmQCsVvlYg3jpe3Q+ROZYuWGVsKxgoaIsBgYLOTp2SU5tg2rj4yeZoRyjFJl1KvgqZIafU9QcKPZoqU1hDKeFwxV9kReDKhd/Kw31VRxjK7adr8mxRYJhOPNlA+L+H+GBu+K8G9CqLjmsQWZptFEvIZO3HoCAF9kfOwVTjpE0+ug4T8Vs7BD0gsE7g97I6HN+rvX4cdkHnS7IBJR70H7USg7ULLeS9F6yB/dakUufknreaaLY/BzZlNcHfr3jd3KIhwn1C/Ll8+g3UQrF6RW5yKeJmIVyxyewOCKbfTltZkUq2tfG7+XsSlvWPP4voe35nhHTNz+DPcomrYoHFB3geTF87NtlYErrSL9B6wXpdPr4MWFi+IqGZbDw3SR4mo9B006jVot8UH/H4lV5j7vPjsVySe/ZInexBSgAIoxA6xB9w+Kt22k+xROmn2a+Y/H3K41vDMMFOppGimingfI16eSvOKzvXfwe8suBf6voD7rV7qRXYh36WistK93SMNrvYgtCfoaTBFSjkESmIC6bwyrZ4X67J6zYIaQNoDli3ib3gvMtvfHsiVHsT6bV4Ivupv8/Kwi9Cj0B4kTb/Nq8NtyEFrWy5yq5FokWfx3mMR/MpFfhXMdsCJFGi7A/kUIq3t/qYgdFZjCYR9n7OZIu5/oCRUmTQX/TIbOsWnQ3vQF0Xos68dEn7Usisdp10p825OyVgjtH9uwzCf3Pw+CD8dRkvHNRL3nSrzOSlTrg7+TGq+lkKfcvpM0uyypaEIRzYrtltnIxh7BwKu2ZkNKIrU/wfRNyvq8Ai02KxI5yOs/2EKQqv5f5jiaf4MikJfvniT2f7DlA4dfjEG+YSbU7XuLgjyoO5yJhRlAVM+2aZDh8fwPwEGAON5+m7TR3B9AAAAAElFTkSuQmCC';
            var doc = new jsPDF('l', 'pt');
            doc.setFontSize(22);
            doc.text('Visit Plan Report', 40, 50);
            doc.addImage(imgData, 'JPEG', 608, 25, 200, 37);
            doc.setFontSize(18);
           
            var endPosY = doc.autoTableEndPosY();
            var pdfOptions = { margins: {horizontal: 40, top: 80, bottom: 50} };

            // patient table
            var resPatient = doc.autoTableHtmlToJson(document.getElementById('printablePatientInfo'), true);
            var pageSplit = resPatient.data.length > 0 ? true : false;
            doc.autoTable(resPatient.columns, resPatient.data, { startY: 80, avoidPageSplit: pageSplit, options: pdfOptions });
            
            // conditions table
            endPosY = doc.autoTableEndPosY();
            doc.text('Identified Conditions', 40, endPosY + 30);
            var resConditions = doc.autoTableHtmlToJson(document.getElementById('printableConditions'), true);
            pageSplit = resConditions.data.length > 0 ? true : false;
            doc.autoTable(resConditions.columns, resConditions.data, { startY: endPosY ? endPosY + 40 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [0], options: pdfOptions });
           
             // clinical results table
            endPosY = doc.autoTableEndPosY();
            doc.text('Clinical Results', 40, endPosY + 30);
            var resClinicalResults = doc.autoTableHtmlToJson(document.getElementById('printableClinical'), true);
            pageSplit = resClinicalResults.data.length > 0 ? true : false;
            doc.autoTable(resClinicalResults.columns, resClinicalResults.data, { startY: endPosY ? endPosY + 40 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [0], options: pdfOptions });

            // medications table
            endPosY = doc.autoTableEndPosY();
            doc.text('Medications', 40, endPosY + 30);
            var resMedications = doc.autoTableHtmlToJson(document.getElementById('printableMedications'), true);
            pageSplit = resMedications.data.length > 0 ? true : false;
            doc.autoTable(resMedications.columns, resMedications.data, { startY: endPosY ? endPosY + 40 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [0,5,6,7], options: pdfOptions });

            // utilization - ADT events in last 1 year (source: HL7) table
            endPosY = doc.autoTableEndPosY();
            doc.text('Utilization', 40, endPosY + 30);
            doc.setFontSize(12);
            var res = doc.autoTableHtmlToJson(document.getElementById('printableUtilization'), true);
            doc.text('ADT Events in Last 1 Year (Source: HL7)', 40, endPosY + 50);
            doc.setFontSize(8);
            doc.text('* No. of Days: Days between Current Admission and Last Discharge', 40, endPosY + 70);

            pageSplit = res.data.length > 0 ? true : false;
            doc.autoTable(res.columns, res.data, { startY: endPosY ? endPosY + 80 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [2], options: pdfOptions });

            // utilization - encounters in last 1 year
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(12);
            doc.text('Encounters in Last 1 Year (Source: Claims)', 40, endPosY + 20);
            var resEncounters = doc.autoTableHtmlToJson(document.getElementById('printableClaims'), true);
            pageSplit = resEncounters.data.length > 0 ? true : false;
            doc.autoTable(resEncounters.columns, resEncounters.data, { startY: endPosY ? endPosY + 30 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [2], options: pdfOptions });

            // care cummunity - care team details
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(18);
            doc.text('Care Community', 40, endPosY + 30);
            doc.setFontSize(12);
            doc.text('Care Team Details', 40, endPosY + 50);
            var resCareCommunity = doc.autoTableHtmlToJson(document.getElementById('printableCareTeam'), true);
            pageSplit = resCareCommunity.data.length > 0 ? true : false;
            doc.autoTable(resCareCommunity.columns, resCareCommunity.data, { startY: endPosY ? endPosY + 60 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [2], options: pdfOptions });

            // care cummunity - provider details
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(12);
            doc.text('Provider Details', 40, endPosY + 20);
            var resProvider = doc.autoTableHtmlToJson(document.getElementById('printableProvider'), true);
            pageSplit = resProvider.data.length > 0 ? true : false;
            doc.autoTable(resProvider.columns, resProvider.data, { startY: endPosY ? endPosY + 30 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [0], options: pdfOptions });

            //  care cummunity - Professional Support Team Details
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(12);
            doc.text('Professional Support Team Details', 40, endPosY + 20);
            var resProfessionalSupportTeam = doc.autoTableHtmlToJson(document.getElementById('printableprofessionalSupportTeam'), true);
            pageSplit = resProfessionalSupportTeam.data.length > 0 ? true : false;
            doc.autoTable(resProfessionalSupportTeam.columns, resProfessionalSupportTeam.data, { startY: endPosY ? endPosY + 30 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [0], options: pdfOptions });

            // care cummunity - Family & Friends Details
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(12);
            doc.text('Family & Friends Details', 40, endPosY + 20);
            var resFamilyFriendsTeam = doc.autoTableHtmlToJson(document.getElementById('printablefamilyFriendsTeam'), true);
            pageSplit = resFamilyFriendsTeam.data.length > 0 ? true : false;
            doc.autoTable(resFamilyFriendsTeam.columns, resFamilyFriendsTeam.data, { startY: endPosY ? endPosY + 30 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [0], options: pdfOptions });

            // assessment score - assessment completed
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(18);
            doc.text('Assessments Score', 40, endPosY + 30);
            doc.setFontSize(12);
            doc.text('Assessments - Completed', 40, endPosY + 50);
            var resAssessment = doc.autoTableHtmlToJson(document.getElementById('printableAssessments'), true);
            pageSplit = resAssessment.data.length > 0 ? true : false;
            doc.autoTable(resAssessment.columns, resAssessment.data, { startY: endPosY ? endPosY + 60 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [0,2], options: pdfOptions });
            
           // managed populations - pending
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(18);
            doc.text('Pending - Managed Population List', 40, endPosY + 30);
            var resManagedPendingPopulationE = doc.autoTableHtmlToJson(document.getElementById('printablependingManagedPopulation'), true);
            pageSplit = resManagedPendingPopulationE.data.length > 0 ? true : false;
            doc.autoTable(resManagedPendingPopulationE.columns, resManagedPendingPopulationE.data, { startY: endPosY ? endPosY + 40 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [2], options: pdfOptions });


            // managed populations - Enrolled
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(18);
            doc.text('Enrolled - Managed Population List', 40, endPosY + 30);
            var resManagedPopulationE = doc.autoTableHtmlToJson(document.getElementById('printableManagedPopulation'), true);
            pageSplit = resManagedPopulationE.data.length > 0 ? true : false;
            doc.autoTable(resManagedPopulationE.columns, resManagedPopulationE.data, { startY: endPosY ? endPosY + 40 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [2], options: pdfOptions });


           
            // managed populations - Disenrolled
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(18);
            doc.text('Disenrolled/Declined - Managed Population List', 40, endPosY + 30);
            var resManagedPopulationD = doc.autoTableHtmlToJson(document.getElementById('printableManagedPopulationDisenrolled'), true);
            pageSplit = resManagedPopulationD.data.length > 0 ? true : false;
            doc.autoTable(resManagedPopulationD.columns, resManagedPopulationD.data, { startY: endPosY ? endPosY + 40 : firstStartY, avoidPageSplit: false, overflow: 'linebreak', overflowColumns: [3,4], options: pdfOptions });

            // standard quality metrics table
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(18);
            doc.text('Standard Quality Metrics', 40, endPosY + 30);
            var resStandartQuality = doc.autoTableHtmlToJson(document.getElementById('printableStandardQuality'), true);
            pageSplit = resStandartQuality.data.length > 0 ? true : false;
            doc.autoTable(resStandartQuality.columns, resStandartQuality.data, { startY: endPosY ? endPosY + 40 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [1,2], options: pdfOptions });

            // tasks - open tasks
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(18);
            doc.text('Tasks', 40, endPosY + 30);
            doc.setFontSize(12);
            doc.text('Open Tasks', 40, endPosY + 50);
            var resOpenTasks = doc.autoTableHtmlToJson(document.getElementById('printableTask'), true);
            pageSplit = resOpenTasks.data.length > 0 ? true : false;
            doc.autoTable(resOpenTasks.columns, resOpenTasks.data, { startY: endPosY ? endPosY + 60 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [1], options: pdfOptions });

            // tasks - closed tasks in last 1 year
            endPosY = doc.autoTableEndPosY();
            doc.setFontSize(12);
            doc.text('Closed Tasks in Last 1 Year', 40, endPosY + 20);
            var resClosedTasks = doc.autoTableHtmlToJson(document.getElementById('printableTaskClosed'), true);
            pageSplit = resClosedTasks.data.length > 0 ? true : false;
            doc.autoTable(resClosedTasks.columns, resClosedTasks.data, { startY: endPosY ? endPosY + 30 : firstStartY, avoidPageSplit: pageSplit, overflow: 'linebreak', overflowColumns: [1,4], options: pdfOptions });
            
            doc.save('VisitPlan.pdf');
          };

          scope.convertManagertoString=function(item){
            var ManagerArray=item.managers;
            var Manager='';
            ManagerArray.forEach(function(data){
              if(Manager==='')
                {Manager=data;}
              else
                {Manager=Manager+', '+data;}
            });
            item.managers=Manager;
          };
          
          scope.Conditionstable = {
            captionText : 'Identified Conditions',
            columns : ['Name', 'Date Identified']
          };
          
          scope.clinicaltable = {
            captionText : 'Clinical Results',
            columns : ['Name', 'Date Identified','Value','Value Date']
          };
          
          scope.professionalSupportTeamTable = {
            captionText: 'Professional Support Team Details',
            columns: ['Name', 'Gender', 'Relationship', 'Comments']
          };
          scope.familyFriendsTeamTable = {
            captionText: 'Family & Friends Details',
            columns: ['Name', 'Gender', 'Relationship', 'Comments']
          };

          scope.Medicationstable = {
            captionText : 'Medications',
            columns : ['Medication Name', 'Prescribed Date','Last Filled Date','Dosage','Provider']
          };
          
          scope.UtilizationHL7table = {
            captionText : 'ADT Events in Last 1 Year (Source: HL7)',
            columns : ['Event Type', 'Event Date','Primary Dx','Facility Name','No. of Days','Days of Inpatient Stay','Readmission Flag']
          };
          
          scope.UtilizationClaimstable = {
            captionText : 'Encounters in Last 1 Year (Source: Claims)',
            columns : ['Encounter Type', 'Encounter Date','Diagnosis','Provider','Provider Specialty','Major Procedures']
          };
          
          scope.CareTeamtable = {
            captionText : 'Care Team Details',
            columns : ['Care Team Name', 'Care Manager Supervisor','Care Manager']
          };
          
          scope.CareProvidertable = {
            captionText : 'Provider Details',
            columns : ['Provider Name', 'Provider Speciality']
          };
          
          scope.assessmentstable = {
            captionText : 'Assessments Score',
            captionSubText: 'Assessments - Completed',
            columns: ['Name', 'Managed Population', 'Date Completed', 'Completed By', 'Due Date', 'Score', 'Max Score']
          };
          
          scope.ManagedPopulationPendingtable = {
            captionText : 'Pending - Managed Population List',
            columns : ['Managed Population', 'Qualified date','Care Lead','Care Team']
          };

          scope.ManagedPopulationtable = {
            captionText : 'Enrolled - Managed Population List',
            columns : ['Managed Population', 'Enrollment Date','Care Team','Missed Opportunity']
          };

          scope.ManagedPopulationDisenrollmentTable = {
            captionText : 'Disenrolled/Declined - Managed Population List',
            columns : ['Managed Population','Status (Disenrolled/Declined)',visitPlanConstantsSvc.enrollmentStartDate,visitPlanConstantsSvc.enrollmentEndDate,visitPlanConstantsSvc.disenrolledBy, visitPlanConstantsSvc.reason]
          };

          scope.StandardQualitytable = {
            captionText : 'Standard Quality Metrics',
            columns : ['Report', 'Metric Name','Population','Score','Measurement Date']
          };

          scope.OpenTasktable = {
            captionText : 'Open Tasks',
            columns : ['Task Type', 'Task Name', 'Managed Population', 'Due Date']
          };
          
          scope.ClosedTasktable = {
            captionText : 'Closed Tasks in Last 1 Year',
            columns : ['Task Type', 'Task Name', 'Managed Population', 'Due Date','Task Completion Date','Missed Task']
          };
        }]);
    }(window.app));