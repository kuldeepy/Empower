(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('SelectTaskNameCtrl', ['$scope', '$http','PatientData','listStateSvc','$state','httpRequestSvc','$location','navConstantsSvc',
    function (scope, http,patientData,listStateSvc,state,httpRequestSvc,location,navConstantsSvc) {
     
      
      if (scope.initializeStep) {
        scope.initializeStep('selectTaskName', false);
      }
      
      var currentListState = listStateSvc.get();
      var taskNameList = [];
      scope.showAssessmentTaskName = false;
      scope.showOtherTaskName = false;
      scope.showProcedureTaskName = false;
      scope.showSelectTaskType = false;
      scope.showEducationMaterial = false;
      var taskType;
      var rootUrl = app.api.root;
      scope.filterCodes = [];

      scope.getTaskNames = function (){
        currentListState = listStateSvc.get();
        if(currentListState.CurrentUIState.currentTaskType === undefined){
          scope.showSelectTaskType = true;
          return;
        }
        taskType = currentListState.CurrentUIState.currentTaskType.name;
        var previousSelectedTaskName = listStateSvc.seletectedTaskName();
        switch(taskType){
          case 'Assessment' :
          
            var url = rootUrl + 'assessments';
            scope.showAssessmentTaskName = true;
            http.get(url)
            .success (function (data){
              var results = data.results;
              scope.assessmentsTaskNames = results;
              scope.convertassessmentsTaskNamesToGenericTask(previousSelectedTaskName.id);
            });
            break;
          case 'Other Tasks' :
            scope.showOtherTaskName = true;
            if(previousSelectedTaskName !== ''){
              scope.OtherTaskName = previousSelectedTaskName.name;
            }
            break;
          case 'Schedule Procedure':
            scope.showProcedureTaskName = true;
            if(previousSelectedTaskName !== ''){
              if(previousSelectedTaskName.name){
                scope.selectedCodeGroup = previousSelectedTaskName.name;
              }
              scope.selectedCodeId = previousSelectedTaskName.id;
            }
            break;
          case 'Education Material' :
            scope.showEducationMaterial = true;
            break;
          default :
            scope.showSelectTaskType = true;
            break;
        }
      };


      scope.$watch('selectedCodeGroup',function(val) {

        scope.completeStep(false,'selectTaskName');

        scope.filterCodes.filter( function (item) {
          if(item === val){
            scope.completeStep(true, 'selectTaskName');
            scope.selectedComplete(scope.selectedCodeGroup, scope.selectedCodeId);
          }
        });
      });

      scope.getCodeGroupings = function (val){
       
        var codeGroupUrl = rootUrl + 'code-groupings?name='+val;
        return http.get(codeGroupUrl
        ).then(function(res){
          var codes = [];
          scope.filterCodes = [];
          angular.forEach(res.data.results, function(item){
            codes.push(item.name);
            scope.filterCodes.push(item.name);
            scope.selectedCodeId = item.id;
          });
          if(scope.filterCodes.length === 0)
          {
            codes.push(navConstantsSvc.noRecords);
            scope.filterCodes.push(navConstantsSvc.noRecords);
            scope.selectedCodeId = -1;
          }
          return codes;
        });
      };
      
      scope.convertassessmentsTaskNamesToGenericTask = function (previousSelectedId){
        scope.assessmentsTaskNames.forEach(function(a){
          var taskName = {
            name : a.assessmentName,
            id : a.assessmentId
          };
          taskNameList.push(taskName);
        });

        scope.taskNames = taskNameList;
        scope.selectedTaskName = _.find(scope.taskNames, function (item) {
              return item.id === previousSelectedId;
            });
      };

      scope.initializeSelectTaskName = function() {
        scope.getTaskNames();
        scope.selectedTaskName = currentListState.CurrentUIState.currentTaskName;
        if (scope.selectedTaskName !== null && scope.selectedTaskName !== undefined && scope.selectedTaskName !== '') {
          scope.completeStep(true,'selectTaskName');
        }
      };

      scope.otherTaskchanged = function() {
        scope.selectedComplete(scope.OtherTaskName);
      };
      
      scope.taskNameChanged = function() {
        if(scope.selectedTaskName !== undefined){
          scope.selectedComplete(scope.selectedTaskName.name,scope.selectedTaskName.id);
        }
      };

      scope.$watch('selectTaskNameForm', function () {
        if(taskType === 'Education Material'){
          scope.$broadcast('educationMaterialValidation');
        }
        else{
          scope.taskNameChanged();
        }
      });

      scope.selectedComplete = function(selectedName,selectedId) {
        if (selectedName!== null && selectedName !== undefined && selectedName !== '' && selectedId!==null && selectedId!== -1) {
          var selectedTaskName = {
            name : selectedName,
            id :selectedId
          };
          currentListState.CurrentUIState.currentTaskName = selectedTaskName;
          scope.verifyTaskName();
        } else {
          scope.completeStep(false,'selectTaskName');
        }
      };

      scope.enableNextButton = function(status,alertStatus){
        scope.isTaskNameExists = alertStatus;
        scope.completeStep(status,'selectTaskName');
        listStateSvc.set(currentListState);
      };

      scope.verifyTaskName = function(){
        var flag = true;
        if(currentListState.CurrentUIState.currentTaskType.name === 'Schedule Procedure' || currentListState.CurrentUIState.currentTaskType.name === 'Assessment')
        {
          flag = (currentListState.CurrentUIState.currentTaskName.id > 0) ? true : false;
        }
        if(flag === true && currentListState.CurrentUIState.currentTaskName !== undefined  && currentListState.CurrentUIState.currentTaskName !== '' && currentListState.CurrentUIState.currentselectedDueDate !== undefined && currentListState.CurrentUIState.currentselectedDueDate !== '') {
          var taskInformations =
          {
            context : 'verification',
            taskTypeId : currentListState.CurrentUIState.currentTaskType.id,
            taskId : (currentListState.CurrentUIState.currentTaskType.name === 'Other Tasks' || currentListState.CurrentUIState.currentTaskType.name === 'Education Material') ? '' : currentListState.CurrentUIState.currentTaskName.id,
            taskDueDate : currentListState.CurrentUIState.currentselectedDueDate,
            taskName : (currentListState.CurrentUIState.currentTaskType.name === 'Other Tasks' || currentListState.CurrentUIState.currentTaskType.name === 'Education Material') ? currentListState.CurrentUIState.currentTaskName.name : '',
            taskTypeName : currentListState.CurrentUIState.currentTaskType.name
          };
          httpRequestSvc.getRequest('patients/' + patientData.id + '/tasks',taskInformations).then(function(response){
            if(response.data.results.length > 0){
              scope.enableNextButton(false,true);
            }
            else{
              scope.enableNextButton(true,false);
            }
          });
        }
        else
        {
          scope.enableNextButton(true,false);
        }
      };

      scope.$on('wizardOnClose', function() {
        listStateSvc.clear();
        if(app !== undefined && app.currentRoute !== undefined) {
          location.path(app.currentRoute +'/');
        }
        else{
          location.path('/');
        }
      });

      scope.$watch('selectTaskNameForm.$pristine', function () {
        if (scope.selectTaskNameForm && !scope.selectTaskNameForm.$pristine) {
          localStorage.setItem('isWizardFormDirty', true);
        }
      });

    }]);

  }(window.app));