/**
 * @author michael.ash
 *
 */
(
  function (app) {
    // @fmt:off
  'use strict';
  // @fmt:on

  app.controller('PatientCtrl', ['$scope', '$window','$http', '$interval', '$q', 'PatientData', 'navMenuService', '_', 'formatService', 'patientTaskSvc', 'navConstantsSvc', '$filter', 'userConcurrentLockSvc','authSvc',
    function (scope, window, http, interval, q, patientData, navMenu, _, format, patientTaskSvc, navConstantsSvc, $filter, userConcurrentLockSvc,authSvc) {
      var baseUrl = app.api.root,
        dataFormatters,
        stopMenu;
      patientData.id = app.routing.routeParams.patientId;
      /*
     * Functions for formatting the data for the patient context menu's sub listing.
       * @returns array An Array of objects to display in the submenu. . Each object should have a type property to tell the derective the display type
       * The display types are 1) text, 2) dlist, 3) title.
       * Display items of type text must also have a propety of "value" which contains a text string.
       * @example {type : "text", value : ['text to display'}
       * Display items of type dlist must also have  propeties of "dterm" {{string}} and defs {{array of strings}}.
       * @example {type : "dlist", dterm : "term", defs : ['term 1', 'term 2', 'term 3']}
       * Display items of type title must also have  propeties of "name" {{string}} and title {{string}}.
       * @example {type : "title", name : "name to display", title : "title text "}
       */
      dataFormatters = {
        /*
         * format medications data for context menu
         */
        medications : function formatMedications (data) {
          var x,
            z,
            lenc,
            temp = [];
          function getDate(med){
            return new Date(med.date).toISOString();
          }
          scope.medications = _.sortBy(data[0].data.results,getDate).reverse();
          x = _.findWhere(scope.menu,{id : 'medications'});

          if(x){
            for(z=0,lenc = scope.medications.length;z < lenc; z = z+1){
              temp.push(
              {
                selection : 'dlist',
                id : scope.medications[z].name + '/' + scope.medications[z].date,
                dterm : scope.medications[z].name,
                defs : [
                  scope.medications[z].strength + ' ' + scope.medications[z].form,
                  'RX Date: ' + moment(scope.medications[z].date).format('MM/DD/YYYY')
                ]
              }
            );
            }
          }
          return temp;
        },
        /*
         * format view conditions data for context menu
         */

        conditions :  function formatConditions (data) {
          var results = _.sortBy(data[0].data.results,'diagnosedDate').reverse(),
            x,
            z,
            lenc,
            temp =[];
          scope.conditions = results;
          x = _.findWhere(scope.menu, {id: 'conditions' });
          for (z = 0, lenc = results.length; z < lenc; z = z + 1) {
            if (results[z].diagnosedDate === null) {
              results[z].diagnosedDate = '';
            } else {
              results[z].diagnosedDate = window.moment(results[z].diagnosedDate).format('MM/DD/YYYY');
            }
            temp.push({ id : results[z].diseaseId, value : results[z].name,
                date: 'Date Identified:' + results[z].diagnosedDate,
                            selection : 'text'});
          }
          return temp;
        },
        /*
         * format mangaged populations data for context menu
         */

        managedPopulations :  function formatPopulations (data) {
          var results = _.sortBy(data[0].data.results,'enrollmentStartDate').reverse(),
            x,
            z,
            lenc,
            temp =[];
          scope.populations = results;
          x = _.findWhere(scope.menu,{id : 'managedPopulations'});
          for(z=0,lenc = results.length;z < lenc; z = z+1){
            temp.push({ id : results[z].populationId + '/' + results[z].careTeamId, value : results[z].programName, selection : 'text'});
          }
          return temp;
        },

        documents: function formatDocuments(data)
        {
          var results = data[0].data.results,
            x,
            z,
            lenc,
            temp=[];
          scope.Documents=results;
          x = _.findWhere(scope.menu,{id : 'documents'});
          for(z=0,lenc = results.length;z < lenc; z = z+1){
            var date=results[z].uploadeddate!==null?moment(results[z].uploadeddate).format('L'):results[z].uploadeddate;
            temp.push(
              {
                selection : 'dlist',
                dterm : results[z].documentCategory,
                defs : [
                  results[z].fileName,
                  'Uploaded On: ' +date
                ]
              }
            );
          }
          return temp;
        },
         /*
         * format assessements data for context menu
         */
        assessements: function formatDocuments(data)
          {
              var results = data[0].data.results,
              x,
              z,
              lenc,
              temp=[];
              scope.assessements=results;
              x = _.findWhere(scope.menu,{id : 'assessements'});
              if(x){
                for(z=0,lenc = scope.assessements.length;z < lenc; z = z+1){
                  temp.push(
                    {
                    selection : 'dlist',
                    dterm : scope.assessements[z].assessmentName,
                    defs : [
                      'Due Date: ' + (scope.assessements[z].dateDue !==null?moment(scope.assessements[z].dateDue).format('L'):'')
                    ]
                  }
              );
                }
              }
              return temp;

            },
        /*
         * format mangaged populations data for context menu
         */
        educationalMaterial :  function formatEducational (data) {
          var results = _.sortBy(data[0].data.results,'dueDate').reverse(),
            x,
            z,
            lenc,
            temp =[];

          scope.educationals = results;
          x = _.findWhere(scope.menu,{id : 'educationalMaterial'});
          for(z=0,lenc = results.length;z < lenc; z = z+1){
            //NEEDS CHANGE WITH CORRECT API PARAMETERES
            temp.push({ id : results[z].patientEducationalMaterialId , value : results[z].taskName, date:'Due Date:'+window.moment(results[z].dueDate).format('MM/DD/YYYY'),selection : 'text'});
          }
          return temp;
        },

        /*
         * format care clinical results data for context menu
         */
        clinicalResults :  function formatPopulations (data) {
          var results = data[0].data.results,
            x,
            z,
            lenc,
            temp =[];

          scope.clinicalresults = results;
          x = _.findWhere(scope.menu,{id : 'clinicalResults'});
          for(z=0,lenc = results.length;z < lenc; z = z+1){
            temp.push(
                {
              selection : 'dlist',
              dterm : results[z].measureName,
              defs : [
                'Value: ' + results[z].measureValue,
                'Value Date: ' + results[z].measureDate
              ]
            }
              );

          }
          return temp;
        },

        /*
         * format care community data for context menu
         */
        careCommunity :  function formatCareCommunity (data) {
          var x,
            lenc,
            temp = [],
            reformattedName;
          scope.careTeams = data[0].data.results;
          scope.providers = data[1].data.results;

          for(x=0, lenc = scope.careTeams.length; x < lenc; x = x + 1){
            reformattedName = patientData.formatName(scope.careTeams[x].supervisor);
            temp.push(
              {
                selection : 'dlist',
                id : reformattedName,
                dterm : reformattedName,
                defs : [
                  scope.careTeams[x].name
                ]
              }
            );
          }

          for(x=0, lenc = scope.providers.length; x < lenc; x = x + 1){
            temp.push(
              {
                selection : 'dlist',
                id : scope.providers[x].name,
                dterm : scope.providers[x].name,
                defs : [
                  scope.providers[x].specialty
                ]
              }
            );
          }

          return _.sortBy(temp, 'id');
        },
        utilizations : function(data){
          var temp = [],
            events,
            encounters;

          events = _.sortBy(data[0].data.results,'EventDate').reverse();

          encounters = data[1].data.results;
          _.each(events, function(el) {
            temp.push(
            {
              selection : 'dlist',
              id : el.EventType,
              dterm : el.EventType,
              defs : [
                'Event Date: ' + window.moment(el.EventDate).format('MM/DD/YYYY'),
              ]
            }
          );
          });
          _.each(encounters, function(el) {
            var diagnosisDescription = 'Not Available';
            if( el.Diagnoses && el.Diagnoses.length > 0 ) {
              diagnosisDescription = el.Diagnoses[0].split('-').length > 1 ? el.Diagnoses[0].split('-')[1] :el.Diagnoses[0];
              diagnosisDescription = format.toTitleCase(diagnosisDescription);
            }
            temp.push(
              {
                selection : 'dlist',
                id : el.EncounterType,
                dterm : el.EncounterType,
                defs : [
                  'Encounter Date: ' + window.moment(el.EncounterDate).format('MM/DD/YYYY'),
                  'Primary Dx: ' + diagnosisDescription
                ]
              }
            );
          });
          return temp;
        },
         /*
         * format Goals data for context menu
         */
        goals: function formatDocuments(data)
          {
              var results = data[0].data.results,
              x,
              z,
              lenc,
              temp=[];
              scope.goals=results;
              x = _.findWhere(scope.menu,{id : 'goals'});
              if(x){
                for(z=0,lenc = scope.goals.length;z < lenc; z = z+1){
                  temp.push(
                    {
                    selection : 'dlist',
                    dterm : scope.goals[z].goalName,
                    defs : [
                      'Due Date: ' + window.moment(scope.goals[z].dueDate).format('MM/DD/YYYY'),
                    ]
                  }
              );
                }
              }
              return temp;
            },
        /*
         * format Goals data for context menu
         */
        careIndicators: function formatDocuments(data)
          {
              var results = _.where(data[0].data.results,{'isActive':'A'}),
              x,
              z,
              lenc,
              temp=[];
              scope.careIndicators=results;
              x = _.findWhere(scope.menu,{id : 'careIndicators'});
              if(x){
                for(z=0,lenc = scope.careIndicators.length;z < lenc; z = z+1){
                  temp.push(
                    {
                    selection : 'continues-text',
                    name : scope.careIndicators[z].category + ': ',
                    text : scope.careIndicators[z].description.slice(0,30) + ' ' +  window.moment(scope.careIndicators[z].lastUpdated).format('MM/DD/YYYY')
                  });
                }
              }
              return temp;
            }
      };

      /*
       * @function
       * @param {array} menu The patient context menu
       * @param {string} id The menu item's key
       * Popluate the context menu for the patient if the pateintData.isMenuDirty flag is true.
       * Set the flag to 'true' on module add, update and deletes.
       */
      function populatePatientMenu (menu, id, q) {
        var url, promises;
        if(!patientData.isMenuDirty) {return;}
        angular.forEach(menu,function(element, index) {
          promises = [];
          element.fullPath = app.routing.routeUrl + element.path;
          if (element.apiUrl && element.apiUrl.length > 0) {
            angular.forEach(element.apiUrl, function(item) {
              if (item !== '') {
                url = navMenu.getApiUrl(item, id);
                promises.push(http.get(url));
              }
            });
            q.all(promises).then(function(results){
              menu[index].items = dataFormatters[element.id.toString()](results);
            });
          }
        });
      }
      scope.data={'patientId':patientData.id,'lockType':'patientdashboard'};
      userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
        scope.isMergedNotificationLocked = false;
        scope.status=response.data.results.status;
        if(scope.status === true){
          stopMenu = interval(function(){
              if(patientData.isFavoriteFlag === true){
                http.get(baseUrl + 'patients/' + patientData.id).success(function (data) {
                  var patient;
                  patientData.isFavoriteFlag = false;
                  patientData.isMenuDirty = patientData.isMenuStatus === true ? true : false;
                  var Gender;
                  if(data.results.Gender==='F')
                  {
                    Gender='Female';
                  }
                  else if(data.results.Gender==='M')
                  {
                    Gender='Male';
                  }

                  var phoneNumber;

                  phoneNumber = data.results.phone.replace(/[^0-9]/g, '');
                  phoneNumber = phoneNumber.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');

                  patient = {
                    id:data.results.patientId,
                    gender : Gender,
                    memberNumber : data.results.memberNumber,
                    dateOfBirth:data.results.dateOfBirth,
                    fullName:data.results.fullName,
                    lastName:data.results.lastName === null ? '' : data.results.lastName,
                    firstName:data.results.firstName,
                    middleName:data.results.middleName === null ? '' : data.results.middleName,
                    Phone : phoneNumber,
                    email : data.results.EmailIdPrimary,
                    LastERVisit : data.results.LastERVisit !== null?data.results.LastERVisit:'',
                    LastInPatient : data.results.LastInPatient !== null?data.results.LastInPatient:'',
                    PCP : data.results.PCPName,
                    secondaryIdentifier : data.results.secondaryIdentifier !== null ? data.results.secondaryIdentifier.split(',',4) : 'None',
                    careLeads :data.results.careLeads,
                    isDeceased : data.results.isDeceased,
                    preferredName : data.results.preferredName,
                    dateDeceased : data.results.dateDeceased
                  };

                  scope.patient = patient;

                }).error(function() {
                  patientData.isMenuDirty = false;
                  interval.cancel(stopMenu);
                });
              }
              if(patientData.isMenuDirty){
                scope.menu = navMenu.menu.patient;
                populatePatientMenu(scope.menu, patientData.id, q);
                patientData.isMenuDirty = false;
              }
            },500);
        }
        else{
          scope.patientMCtrl.errorNotification = navConstantsSvc.lockedMessage.replace('UserName', $filter('isNull')(response.data.results.name));
          scope.isMergedNotificationLocked = true;
          patientData.isMenuDirty = false;
          interval.cancel(stopMenu);
        }
      });
      scope.site = {year : new Date().getFullYear()};
      scope.hasItems = false;
      scope.expandMe = function () {
        scope.hasItems = true;
      };
      scope.addNew = false;
      scope.clickAdd = function () {
        scope.addNew = true;
      };

      /* function to format date in required format */
      scope.formatDate = function (date, format) {
        return window.moment(date).format(format);
      };

      scope.navigateToPage = function(page){
        if(!scope.isMergedNotificationLocked){
          window.location.href = app.currentRoute +'/'+page;
        }
      };

      scope.hasEditAccess = authSvc.hasEditAccess();

    }]);
}(window.app));

