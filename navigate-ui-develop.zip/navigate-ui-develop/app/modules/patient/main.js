(function (app) {
  'use strict';
  /* module root controller */
  app.controller('PatientModuleCtrl', ['$scope','authSvc', 'homeURL', 'userConcurrentLockSvc', function (scope,authSvc, homeURL, userConcurrentLockSvc) {
    scope.model = {
      routeParams: {}
    };
    /*Max Fize size for file upload*/
		scope.fileUploadSize = '3145728';
		scope.totalFileUploadSize = '15728640';
    scope.user = authSvc.user();
    scope.user.backURL = homeURL.getURL(scope.user.role);
    scope.unlockConcurrentTask = function() {
      scope.data={'lockType':'Notifications'};
      userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(){
        scope.errorNotification = '';
      });
    };
  }]);
}(window.app));
