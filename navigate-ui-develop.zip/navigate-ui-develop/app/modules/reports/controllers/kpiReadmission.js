(function (app) {
  'use strict';

  app.controller('kpiReadmission', ['$scope', '$http', '$filter','authSvc','$modal','homeURL','_','iuiAlertService', 'kpiReadmissionReportSvc','downloadCsv',
    function (scope, http, filter, authSvc, $modal,homeURL, _, alertSvc, kpiReadmissionReportSvc, downloadCsv) {

      scope.classMethod('kpiReadmission');
      scope.pageTitle = 'KPI Readmission';
      scope.isOpen = true;
      scope.reportIsOpen = true;
      scope.user = authSvc.user();
      scope.user.backURL = '';
      scope.filterValue='all';
      var  months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      scope.filter = {
        startDateOptions: {
          month: '',
          years: []
        },
        endDateOptions: {
          month: '',
          years: []
        },
        selected: {
          startDate: {
            year: '',
            month: ''
          },
          endDate: {
            year: '',
            month: ''
          },
        },
        months:months,
        years: []
      };

      alertSvc.add('alert_report', { type: 'error' });

      scope.setLabelDateRange = function() {
        if ((scope.filter.selected.startDate.month + scope.filter.selected.startDate.year) === (scope.filter.selected.endDate.month + scope.filter.selected.endDate.year)) {
          scope.dateRange = ' (' + scope.filter.selected.startDate.month + ' ' + scope.filter.selected.startDate.year + ')';
        } else {
          scope.dateRange = ' (' + scope.filter.selected.startDate.month + ' ' + scope.filter.selected.startDate.year + ' to ' + scope.filter.selected.endDate.month + ' ' + scope.filter.selected.endDate.year + ')';
        }
      };
      scope.setLabelDateRange();
      scope.getAccordionReports = function(reportIsOpen, filterValue){
        if(reportIsOpen){
          if(filterValue === 'all'){
            scope.filterData = scope.kpiReadmissionPatients;
          }
          scope.getKpiReportByLabel(filterValue);
        }
      };

      scope.getKpiReportByLabel = function(label){
        scope.filterData = _.filter(scope.kpiReadmissionPatients, function(item){
          return item[label] !== null && item[label] !== 'No Assessment';
        });
      };

     
      var totalReadmittedPatientsColumns = [
        {
          field: 'patientName',
          displayName: 'Patient Name',
        },
        {
          field: 'medicalRecordNumber',
          displayName: 'Unique Identifier #',
        },
        {
          field: 'initialPAAScore',
          displayName: 'Home Visit PAA Score',
        },
        {
          field: 'finalPAAScore',
          displayName: 'Follow Up Phone Call with #3 PAA Score',
        },
        {
          field: 'medicationReconciliationCount',
          displayName: 'Medication Reconciliation Count',
        },
        {
          field: 'readmissionRiskscore',
          displayName: 'Readmission Risk Score',
        }
      ];
      var initialPAAAverageColumns =  [
        {
          field: 'patientName',
          displayName: 'Patient Name',
        },
        {
          field: 'medicalRecordNumber',
          displayName: 'Unique Identifier #',
        },
        {
          field: 'initialPAAScore',
          displayName: 'Home Visit PAA Score',
        },
        {
          field: 'initialPAAScoreCompletionDate',
          displayName: 'Assessment Completion Date',
        }
      ];
      var finalPAAAverageColumns = [
        {
          field: 'patientName',
          displayName: 'Patient Name',
        },
        {
          field: 'medicalRecordNumber',
          displayName: 'Unique Identifier #',
        },
        {
          field: 'finalPAAScore',
          displayName: 'Follow Up Phone Call with #3 PAA Score',
        },
        {
          field: 'finalPAAScoreCompletionDate',
          displayName: 'Assessment Completion Date',
        }
      ];
      var medicationDiscrepanciesColumns = [
        {
          field: 'patientName',
          displayName: 'Patient Name',
        },
        {
          field: 'medicalRecordNumber',
          displayName: 'Unique Identifier #',
        },
        {
          field: 'medicationReconciliationCount',
          displayName: 'Medication Reconciliation Count',
        },
        {
          field: 'medicationReconciliationCompletionDate',
          displayName: 'Assessment Completion Date',
        }
      ];
      var riskScoreColumns = [
        {
          field: 'patientName',
          displayName: 'Patient Name',
        },
        {
          field: 'medicalRecordNumber',
          displayName: 'Unique Identifier #',
        },
        {
          field: 'readmissionRiskscore',
          displayName: 'Readmission Risk Score',
        },
        {
          field: 'readmissionRiskscoreCompletionDate',
          displayName: 'Assessment Completion Date',
        }
      ];


      var rangeValidate = function() {
        var valid = true;
        var startMonth = scope.filter.months.indexOf(scope.filter.selected.startDate.month);
        var endMonth = scope.filter.months.indexOf(scope.filter.selected.endDate.month);
        if(scope.filter.selected.startDate.year > scope.filter.selected.endDate.year) { valid = false; }
        else if(scope.filter.selected.startDate.year === scope.filter.years[0] && startMonth > new Date().getMonth()) { valid = false; }
        else if(scope.filter.selected.endDate.year === scope.filter.years[0] && endMonth > new Date().getMonth()) { valid = false; }
        else if(scope.filter.selected.startDate.year === scope.filter.selected.endDate.year && startMonth > endMonth) { valid = false; }
        return valid;
      };
      
      scope.generateKpiReports = function(item){
        scope.kpiReports = [];
        scope.kpiReports.push({label : 'Total Readmitted Patients',value: item.totalPatients,columns: totalReadmittedPatientsColumns, filterValue: 'all'});
        scope.kpiReports.push({label : 'Initial PAA Average',value: item.initialPAAAverage,columns: initialPAAAverageColumns, filterValue: 'initialPAAScore'});
        scope.kpiReports.push({label : 'Final PAA Average',value: item.finalPAAAverage,columns: finalPAAAverageColumns, filterValue: 'finalPAAScore'});
        scope.kpiReports.push({label : 'Average of Medication Discrepancies', value: item.medicationDiscrepanciesAverage,columns: medicationDiscrepanciesColumns, filterValue: 'medicationReconciliationCount'});
        scope.kpiReports.push({label : 'Average Risk Score',value: item.riskScoreAverage,columns: riskScoreColumns, filterValue: 'readmissionRiskscore'});
      };

      scope.downloadCSVReport = function(report,fileName) {
        fileName = fileName + ' - ' + scope.dateRange;
        downloadCsv.toCSV(fileName,scope.filterData,_.pluck(report,'displayName'),_.pluck(report,'field'));
      };

      scope.getDateKey = function() {
        scope.user.backURL = homeURL.getURL(scope.user.role);
        kpiReadmissionReportSvc.getDateKeyRequest(scope.filterData).then(function(res){
          if(res.data.results !== '1')
          {
            var date=new Date();
            var startDateKey = res.data.results;
            scope.filter.years = _.sortBy(_.range(startDateKey, (new Date().getFullYear()) + 1)).reverse();
            scope.filter.startDateOptions.years = scope.filter.years;
            scope.filter.endDateOptions.years = scope.filter.years;
            scope.filter.selected.startDate.year = scope.filter.selected.endDate.year = scope.filter.years[0];
            scope.filter.selected.startDate.month = scope.filter.selected.endDate.month = scope.filter.months[date.getMonth()];
            scope.Getadmisssiondata();
          }
        });
      };
      
      scope.getFilterReportData = function() {
        if(rangeValidate()){
          alertSvc.clear('alert_report');
          scope.Getadmisssiondata();
        }
        else {
          alertSvc.add('alert_report', {
            type: 'error',
            activeFor: 6000,
            message: 'Selected date range is not valid.'
          });
        }
      };

      scope.Getadmisssiondata=function(){
        scope.kpiReadmissionPatients = '';
        scope.setLabelDateRange();
        scope.filterSearchData = {};
        scope.filterSearchData.StartDate = scope.filter.selected.startDate.year + '-' + moment(new Date(scope.filter.selected.startDate.month + ' 1, 2000')).format('MM')+ '-01';
        scope.filterSearchData.EndDate = scope.filter.selected.endDate.year + '-' + moment(new Date(scope.filter.selected.endDate.month + ' 1, 2000')).format('MM')+ '-'+ new Date(scope.filter.selected.endDate.year, moment(new Date(scope.filter.selected.endDate.month + ' 1, 2000')).format('MM'), 0).getDate();
        kpiReadmissionReportSvc.getKpiReadmissionReportRequest(scope.filterSearchData).then(function(res){
          scope.sourceViewer = res.data.results.sourceViewer;
          scope.kpiReadmissionPatients = res.data.results.kpiReadmissionPatients;
          scope.filterData=res.data.results.kpiReadmissionPatients;
          scope.generateKpiReports(scope.sourceViewer);
        });
      };
      scope.getDateKey();
    }]);
}(window.app));
