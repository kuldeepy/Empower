(function (app) {
  'use strict';
  app.controller('missedopportunityCtrl', ['$scope','$location','modalService','missedOpportunityReportSvc','_', 'navConstantsSvc', '$modal',
    function (scope,location,modalService,missedOpportunityReportSvc,_, navConstantsSvc, modal) {
      scope.pageTitle = 'Missed Opportunities';
      scope.filterOptions = {
        filterText: '',
        useExternalFilter: true
      };
      scope.totalServerItems = 0;
      scope.pagingOptions ={
        pageSize: 10,
        currentPage: 1
      };
      scope.pagingOptionsMissedOpportunity ={
        pageSizes: [10],
        pageSize: 10,
        currentPage: 1
      };
      scope.infoToolTip = false;
      scope.missedList = [];
      scope.careTeam = [];
      scope.sortingClass = '';
      var careTeamUnique = [];
      var careTeamMembersUnique = [];
      var careTeamLoad = [];
      scope.filter={};
      var careTeamMembersLoad = [];
      scope.taskTypes = [];
      var taskTypesLoad = [];
      var taskNamesLoad = [];
      scope.managedPopulationsIds = '';
      scope.taskTypeIds = '';
      scope.isOpen = true;
      scope.selectedConditionName = '';
      scope.filterRequest = {};
      scope.notification = {
        visible : false,
        failure : false
      };
      var filterTaskNames = [];

      scope.missedOpportunityList = [];

      scope.missedOpportunityTable = {
        columns : ['Patient Name', '# Missed', 'Managed Population(s)','Care Team(s)','Last PCP Visit']
      };
      scope.bindFilters=function(){
        missedOpportunityReportSvc.getManagedPopulationsRequest()
        .then(function(response){
            scope.managedPopulations = response.data.results;
            var strManagedPopulations = null;
            scope.managedPopulations.forEach(function(item){
              strManagedPopulations = ((strManagedPopulations !== null)? strManagedPopulations + ',' + item.programId :item.programId);
            });
            scope.managedPopulationsIds = strManagedPopulations;
            missedOpportunityReportSvc.getTasksRequest().then(function(response){
                var unique = [];
                var blocked = [];
                taskTypesLoad = response.data.results.taskTypes;
                if(taskTypesLoad.length > 0){
                  unique.push(response.data.results.taskTypes[0]);
                  blocked.push(response.data.results.taskTypes[0].taskTypeId);
                  for (var i = 1, j = response.data.results.taskTypes.length; i < j; i = i+ 1){
                    if (blocked.indexOf(response.data.results.taskTypes[i].taskTypeId) <= -1) {
                      unique.push(response.data.results.taskTypes[i]);
                      blocked.push(response.data.results.taskTypes[i].taskTypeId);
                    }
                  }
                  scope.taskTypes = unique;
                }
                blocked = [];
                taskNamesLoad = response.data.results.taskName;
                if(taskNamesLoad.length > 0){
                  filterTaskNames.push(response.data.results.taskName[0]);
                  blocked.push(response.data.results.taskName[0].taskName);
                  for (var k = 1, l = response.data.results.taskName.length; k < l; k = k+ 1){
                    if (blocked.indexOf(response.data.results.taskName[k].taskName) <= -1) {
                      filterTaskNames.push(response.data.results.taskName[k]);
                      blocked.push(response.data.results.taskName[k].taskName);
                    }
                  }
                  scope.taskNames = filterTaskNames;
                }
                var strTaskTypes = null;
                scope.taskTypes.forEach(function(item){
                  strTaskTypes = ((strTaskTypes !== null)? strTaskTypes + ',' + item.taskTypeId :item.taskTypeId);
                });
                scope.taskTypeIds=strTaskTypes;
                scope.getMissedOpportunityData();
              });
          });
        missedOpportunityReportSvc.getCareTeamRequest().then(function(response){
            careTeamUnique = [];
            var blocked = [];
            careTeamLoad = response.data.results;
            if(careTeamLoad.length > 0){
              if(response.data.results[0].careTeamName !== navConstantsSvc.allPatientCareTeamName){
                careTeamUnique.push(response.data.results[0]);
                blocked.push(response.data.results[0].careTeamId);
              }
              var allPatientCareTeam = _.filter(response.data.results, function(careTeam){ return careTeam.careTeamName === navConstantsSvc.allPatientCareTeamName; });
              if(allPatientCareTeam.length > 0){
                blocked.push(allPatientCareTeam[0].careTeamId);
              }
              for (var i = 1, j = response.data.results.length; i < j; i = i+ 1){
                if (blocked.indexOf(response.data.results[i].careTeamId) <= -1) {
                  careTeamUnique.push(response.data.results[i]);
                  blocked.push(response.data.results[i].careTeamId);
                }
              }
              scope.careTeam = careTeamUnique;
              scope.getCareTeamMembers();
            }
          });
      };

      scope.getCareTeamMembers=function(){
        missedOpportunityReportSvc.getCareTeamMembersRequest().then(function(response){
          careTeamMembersUnique = [];
          careTeamMembersLoad = response.data.results;
          careTeamMembersUnique = _.findByValues(careTeamMembersLoad, 'careTeamId', _.pluck(scope.careTeam,'careTeamId'));
          careTeamMembersUnique = _.unique(careTeamMembersUnique,'careteammemberID');
          scope.careTeamMembers = careTeamMembersUnique;
        });
      };

      scope.bindCareTeamTaskNames=function(programID){
        scope.filter.careteamId = '';
        scope.filter.careteamMemId = '';
        scope.filter.taskNames = '';
        if(programID === null || programID === '')
        {
          careTeamMembersUnique = _.unique(careTeamMembersLoad,'careteammemberID');
          scope.careTeamMembers = careTeamMembersUnique;
          scope.careTeam = careTeamUnique;
          scope.taskNames = filterTaskNames;
          scope.filter = {};
        }
        else
        {
          scope.careTeam = [];
          scope.taskNames = [];
          scope.careTeam = _.filter(careTeamLoad, function (item) {
            return (String(item.programId) === programID);
          });
          careTeamMembersUnique = [];
          careTeamMembersUnique = _.findByValues(careTeamMembersLoad, 'careTeamId', _.pluck(scope.careTeam,'careTeamId'));
          careTeamMembersUnique =_.unique(careTeamMembersUnique,'careteammemberID');
          scope.careTeamMembers = careTeamMembersUnique;
          var taskNamestemp = _.filter(taskTypesLoad, function (item) {
            return (String(item.programid) === programID);
          });
          taskNamestemp.forEach(function(taskitem){
            var taskTypeIds= taskitem.taskTypeId;
            filterTaskNames.forEach(function(item){
              if(item.taskTypeId === taskTypeIds){
                scope.taskNames.push(item);
              }
            });
          });
          var unique = [];
          var blocked = [];
          if(scope.taskNames.length>0){
            unique.push(scope.taskNames[0]);
            blocked.push(scope.taskNames[0].taskName);
            for (var i = 1, j = scope.taskNames.length; i < j; i = i+ 1){
              if (blocked.indexOf(scope.taskNames[i].taskName) <= -1) {
                unique.push(scope.taskNames[i]);
                blocked.push(scope.taskNames[i].taskName);
              }
            }
          }
          scope.taskNames = unique;
        }
      };

      scope.bindCareTeamMembers=function(careTeamID){
        scope.filter.careteamMemId = '';
        if(careTeamID === null || careTeamID === '')
        {
          scope.careTeamMembers = careTeamMembersUnique;
        }
        else
        {
          scope.careTeamMembers = _.filter(careTeamMembersLoad, function (item) {
            return (String(item.careTeamId) === careTeamID);
          });
        }
      };

      scope.getMissedOpportunityData = function(){
        scope.filterRequest ={ 'managedPopulationId': scope.managedPopulationsIds,
                                'tasktypeId': scope.taskTypeIds,
                                'careTeamMembersId': null,
                                'taskSpecificId':null,
                                'taskSpecificTypeId': null,
                                'taskSpecificName':null,
                                'startRowIndex' :scope.pagingOptionsMissedOpportunity.currentPage,
                                'endRowIndex' :scope.pagingOptionsMissedOpportunity.pageSize,
                                'sortType' : 'asc'
                              };
        missedOpportunityReportSvc.getMissedOpportunityRequest(scope.filterRequest).then(function(response){
            scope.missedOpportunityList=response.data.results.missedOpportunities;
            scope.totalCount=response.data.results.totalCount;
          });
      };

      scope.getFilterMissedOpportunityData = function(filter){
        var taskSpecificId = null, careTeamDetails = null, taskSpecificTypeId=null;
        scope.fliterManagedPopulationsIds=scope.managedPopulationsIds;
        if(filter !== undefined){
          if(filter.managedpopulationID !== undefined && filter.managedpopulationID !== null)
          {
            scope.fliterManagedPopulationsIds = filter.managedpopulationID;
          }
          else
          {
            scope.fliterManagedPopulationsIds=scope.managedPopulationsIds;
          }
          careTeamDetails=(filter.careteamMemId !== '' && filter.careteamMemId !== undefined ? filter.careteamMemId: null);
          taskSpecificId = (filter.taskNames !== ''  && filter.taskNames !== undefined? JSON.parse(filter.taskNames).taskID : null);
          taskSpecificTypeId = (filter.taskNames !== '' && filter.taskNames !== undefined? JSON.parse(filter.taskNames).taskTypeId: null);
        }
        scope.pagingOptionsMissedOpportunity.currentPage = 1;
        scope.filterRequest ={  'managedPopulationId': scope.fliterManagedPopulationsIds,
                                'tasktypeId': scope.taskTypeIds,
                                'careTeamMembersId': careTeamDetails,
                                'taskSpecificId':taskSpecificId,
                                'taskSpecificTypeId': taskSpecificTypeId,
                                'taskSpecificName':null,
                                'startRowIndex' :scope.pagingOptionsMissedOpportunity.currentPage,
                                'endRowIndex' :scope.pagingOptionsMissedOpportunity.pageSize,
                                'sortType' : 'asc'
                              };
        missedOpportunityReportSvc.getMissedOpportunityRequest(scope.filterRequest).then(function(response){
            scope.missedOpportunityList=response.data.results.missedOpportunities;
            scope.totalCount=response.data.results.totalCount;
          });
      };
      
      scope.bindFilters();

      scope.redirectToPatientInfo=function(item){
        window.location.href = '/patients/' + item.patientID;
      };

      scope.setPagingData = function (data, page, pageSize) {
        var pagedData = data.slice((page - 1) * pageSize, page * pageSize);
        scope.myData = pagedData;
        scope.totalServerItems = data.length;
        if (!scope.$$phase) {
          scope.$apply();
        }
      };

      scope.getPagedDataAsync = function (pageSize, page, searchText) {
        setTimeout(function () {
          if (searchText) {
            scope.setPagingData(scope.missedList, page, pageSize);
          } else {
            scope.setPagingData(scope.missedList, page, pageSize);
          }
        }, 100);
      };

      scope.$watch('pagingOptions', function (newVal, oldVal) {
        if (newVal !== oldVal && newVal.currentPage !== oldVal.currentPage) {
          scope.pagingOptions.currentPage = (newVal.currentPage === undefined || newVal.currentPage === null) ? 1 : scope.pagingOptions.currentPage;
          scope.getPagedDataAsync(scope.pagingOptions.pageSize, scope.pagingOptions.currentPage, scope.filterOptions.filterText);
        }
      }, true);

      scope.$watch('filterOptions', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          scope.getPagedDataAsync(scope.pagingOptions.pageSize, scope.pagingOptions.currentPage, scope.filterOptions.filterText);
        }
      }, true);

      scope.$watch('pagingOptionsMissedOpportunity', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          scope.filterRequest.startRowIndex=scope.pagingOptionsMissedOpportunity.currentPage;
          missedOpportunityReportSvc.getMissedOpportunityRequest(scope.filterRequest).then(function(response){
            scope.missedOpportunityList=response.data.results.missedOpportunities;
            scope.totalCount=response.data.results.totalCount;
          });
        }
      }, true);

      scope.MissedOpportunityListColumns = {columns : ['Patient Name','Incomplete','Disenrollment','Managed Population(s)','Care Team(s)','Last PCP Visit']};
      scope.sortInfo = {fields: ['Task Name'], directions: ['asc', 'desc']};
      scope.missedListGrid = {
        data: 'myData',
        multiSelect: false,
        showFooter: true,
        enablePaging: true,
        totalServerItems: 'totalServerItems',
        pagingOptions: scope.pagingOptions,
        filterOptions: scope.filterOptions,
        sortInfo: scope.sortInfo,
        columnDefs: [
          { field: 'taskTypeID', visible: false},
          { field: 'taskType', displayName: 'Task Type', width : '20%'},
          { field: 'taskName',
            displayName: 'Task Name',
            width : '20%',
            cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<span title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</span>'+
                          '</div>'
          },
          { field: 'taskDueDate', displayName: 'Due Date',width : '20%' },
          { field: 'programName',
            displayName: 'Managed Population',
            width : '20%',
            cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<span title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</span>'+
                          '</div>'
          },
          { field: 'missedOpportunityDate', displayName: 'Missed Date',width : '19%' }
        ]
      };

      var sortData = function (field, direction) {
        if (!scope.missedList) { return; }
        scope.missedList.sort(function (a, b) {
          if (direction === 'asc') {
            return a[field] > b[field] ? 1 : -1;
          } else {
            return a[field] > b[field] ? -1 : 1;
          }
        });
      };
       
      scope.$watch('sortInfo', function (newVal) {
        sortData(newVal.fields[0], newVal.directions[0]);
        scope.getPagedDataAsync(scope.pagingOptions.pageSize, scope.pagingOptions.currentPage);
      }, true);

      scope.showMissed= function(item,text){
        scope.filterRequest.status = text;
        missedOpportunityReportSvc.getMissedOpportunityReportRequest(item.patientID,scope.filterRequest).then(function(response){
            scope.missedListGrid.data = [];
            scope.missedListGrid.data = 'myData';
            scope.missedList = response.data.results.map(function (node) {
              return { 'taskId': node.taskId,
                       'programName': node.programName,
                       'taskType': node.taskType,
                       'taskName': node.taskName,
                       'taskDueDate': node.taskDueDate,
                       'missedOpportunityDate':  moment(node.missedOpportunityDate).format('MM/DD/YYYY h:mm A')
                     };
            });
            scope.pagingOptions.currentPage = 1;
            scope.getPagedDataAsync(scope.pagingOptions.pageSize, scope.pagingOptions.currentPage);
            scope.patientName = item.patientName;
            scope.modalPopUp = modal.open({
              templateUrl: 'patientMissedTasksList.html',
              scope: scope,
              size: 'lg'
            });
          });
      };

      scope.closeAlert = function(){scope.notification.visible = false;};

      scope.closePopup = function(){ scope.modalPopUp.close(); };

      scope.downloadExcel=function(){
        var fileName = 'Patients_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
        var missedListHeader = ['Task Type','Task Name','Due Date','Managed Population','Missed Date'];
        var csvResult = missedListHeader.toString() + '\n';
        angular.forEach(scope.missedList, function (res){
          var missedData=[];
          missedData = [res.taskType.indexOf(',') === -1 ?res.taskType:'"' + res.taskType + '"',res.taskName.indexOf(',') === -1 ?res.taskName:'"' +res.taskName+'"',res.taskDueDate,res.programName.indexOf(',') === -1 ?res.programName:'"'+res.programName+'"',res.missedOpportunityDate];
          csvResult = csvResult + missedData.toString() + '\n';
        });
        var blob = new Blob([csvResult], {type:'data:text/csv'});
        window.saveAs(blob, fileName);
      };

      scope.showInfoToolTip = function(){
        if(scope.infoToolTip === true){
          scope.infoToolTip = false;
        }
        else{
          scope.infoToolTip = true;
        }
      };

      scope.patientNameSort = function(){
        scope.filterRequest.startRowIndex = scope.pagingOptionsMissedOpportunity.currentPage;
        scope.filterRequest.sortType = scope.filterRequest.sortType === 'desc' ? 'asc' : 'desc';
        scope.sortingClass = scope.filterRequest.sortType === 'desc' ? 'iui-sort-heading sorted' : 'iui-sort-heading sorted reversed';
        missedOpportunityReportSvc.getMissedOpportunityRequest(scope.filterRequest).then(function(response){
          scope.missedOpportunityList = response.data.results.missedOpportunities;
          scope.totalCount = response.data.results.totalCount;
        });
      };

      scope.classMethod('missedopportunity');
    }]);
})(window.app);
