(function (app) {
  'use strict';

  app.controller('kpiTotalPatientsCtrl', ['$scope','kpiTotalPatientsSvc', '$http', '$filter','authSvc','$modal','homeURL','_','iuiAlertService', 'downloadCsv',
    function (scope, kpiTotalPatientsSvc, http, filter, authSvc, $modal,homeURL, _, alertService, downloadCsv) {

      scope.classMethod('kpiTotalPatients');
      scope.pageTitle = 'KPI Total Patients';
      scope.isOpen = true;
      scope.kpiReportPatientData = [];
      scope.dateRange = 'Date Range';
      scope.user = authSvc.user();
      scope.user.backURL = '';
      scope.filter = {
        selected: {
          startDate: {
            year: '',
            month: ''
          },
          endDate: {
            year: '',
            month: ''
          },
        },
        months: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        years: []
      };
      scope.selectedFilter = {
        sourceViewer: null,
        startDate: '',
        endDate:''
      };
      scope.selectedAccordian = 0;
      
      scope.columns = {
        totalPatients: [
            {
              field: 'patientName',
              displayName: 'Patient Name',
            },
            {
              field: 'medicalRecordNumber',
              displayName: 'Unique Identifier #',
            },
            {
              field: 'initialPAAScore',
              displayName: 'Home Visit PAA Score',
            },
            {
              field: 'finalPAAScore',
              displayName: 'Follow Up Phone Call with #3 PAA Score',
            },
            {
              field: 'medicationReconciliationCount',
              displayName: 'Medication Reconciliation Count',
            },
            {
              field: 'readmissionRiskscore',
              displayName: 'Readmission Risk Score',
            }
          ],
          initialPAAAverage: [
            {
              field: 'patientName',
              displayName: 'Patient Name',
            },
            {
              field: 'medicalRecordNumber',
              displayName: 'Unique Identifier #',
            },
            {
              field: 'totalScore',
              displayName: 'Home Visit PAA Score',
            },
            {
              field: 'dateTaken',
              displayName: 'Assessment Completion Date',
            }
          ],
          finalPAAAverage: [
            {
              field: 'patientName',
              displayName: 'Patient Name',
            },
            {
              field: 'medicalRecordNumber',
              displayName: 'Unique Identifier #',
            },
            {
              field: 'totalScore',
              displayName: 'Follow Up Phone Call with #3 PAA Score',
            },
            {
              field: 'dateTaken',
              displayName: 'Assessment Completion Date',
            }
          ],
          medication: [
            {
              field: 'patientName',
              displayName: 'Patient Name',
            },
            {
              field: 'medicalRecordNumber',
              displayName: 'Unique Identifier #',
            },
            {
              field: 'totalScore',
              displayName: 'Medication Reconciliation Count',
            },
            {
              field: 'dateTaken',
              displayName: 'Assessment Completion Date',
            }
          ],
          riskScore: [
            {
              field: 'patientName',
              displayName: 'Patient Name',
            },
            {
              field: 'medicalRecordNumber',
              displayName: 'Unique Identifier #',
            },
            {
              field: 'totalScore',
              displayName: 'Readmission Risk Score',
            },
            {
              field: 'dateTaken',
              displayName: 'Assessment Completion Date',
            }
          ]
        };

      alertService.add('alert_date', { type: 'error' });

      scope.setLabelDateRange = function() {
        if ((scope.filter.selected.startDate.month + scope.filter.selected.startDate.year) === (scope.filter.selected.endDate.month + scope.filter.selected.endDate.year)) {
          scope.dateRange = ' - (' + scope.filter.selected.startDate.month + ' ' + scope.filter.selected.startDate.year + ')';
        } else {
          scope.dateRange = ' - (' + scope.filter.selected.startDate.month + ' ' + scope.filter.selected.startDate.year + ' to ' + scope.filter.selected.endDate.month + ' ' + scope.filter.selected.endDate.year + ')';
        }
      };

      scope.downloadCSVReport = function(report,fileName) {
          fileName = fileName + ' - ' + scope.dateRange;
          downloadCsv.toCSV(fileName,scope.kpiReportPatientData,_.pluck(report,'displayName'),_.pluck(report,'field'));
        };

      scope.getReport = function(val, index)
      {
        if(val.isOpen && scope.selectedAccordian !== index)
        {
          scope.kpiReportPatientData = [];
          scope.selectedAccordian = index;
          scope.selectedFilter.sourceViewer = val.sourceType;
          kpiTotalPatientsSvc.getkpiTotalPatientsRequest(scope.selectedFilter).then(function(res) {
            switch(val.sourceType) {
              case 'TotalPatients':
                scope.kpiReportPatientData = res.data.results.totalPatientsSourceViewer;
                break;
              case 'InitialPAA':
                scope.kpiReportPatientData = res.data.results.sourceViewerDetails;
                break;
              case 'FinalPAA':
                scope.kpiReportPatientData = res.data.results.sourceViewerDetails;
                break;
              case 'MedicationDiscrepancies':
                scope.kpiReportPatientData = res.data.results.sourceViewerDetails;
                break;
              case 'Risk':
                scope.kpiReportPatientData = res.data.results.sourceViewerDetails;
                break;
            }
          });
        }
      };

      var rangeValidate = function() {
        var valid = true;
        var startMonth = scope.filter.months.indexOf(scope.filter.selected.startDate.month);
        var endMonth = scope.filter.months.indexOf(scope.filter.selected.endDate.month);
        if(scope.filter.selected.startDate.year > scope.filter.selected.endDate.year) { valid = false; }
        else if(scope.filter.selected.startDate.year === scope.filter.years[0] && startMonth > new Date().getMonth()) { valid = false; }
        else if(scope.filter.selected.endDate.year === scope.filter.years[0] && endMonth > new Date().getMonth()) { valid = false; }
        else if(scope.filter.selected.startDate.year === scope.filter.selected.endDate.year && startMonth > endMonth) { valid = false; }
        return valid;
      };

      scope.getFilterData = function() {
        if(rangeValidate())
        {
          alertService.clear('alert_date');
          scope.selectedAccordian = 0;
          scope.selectedFilter.sourceViewer = null;
          var startMonth = scope.filter.months.indexOf(scope.filter.selected.startDate.month) + 1;
          scope.selectedFilter.startDate = scope.filter.selected.startDate.year + '-' + ((startMonth > 9) ? startMonth : ('0' + startMonth)) + '-' + '01';
          var endMonth = scope.filter.months.indexOf(scope.filter.selected.endDate.month) + 1;
          scope.selectedFilter.endDate = scope.filter.selected.endDate.year + '-' + ((endMonth > 9) ? endMonth : ('0' + endMonth)) + '-' + new Date(scope.filter.selected.endDate.year, endMonth, 0).getDate();
          scope.setLabelDateRange();

          var totals = {};
          kpiTotalPatientsSvc.getkpiTotalPatientsRequest(scope.selectedFilter).then(function(res) {
            totals = res.data.results.totals;
            scope.kpiReportPatientData = res.data.results.totalPatientsSourceViewer;
            scope.kpiReports = [{
                label: 'Total Patients' + ' ' + scope.dateRange,
                value: totals.totalPatients,
                isOpen: true,
                sourceType: 'TotalPatients',
                columns: scope.columns.totalPatients
              },
              {
                label: 'Initial PAA Average' + ' ' + scope.dateRange,
                value: totals.initialPAAAverage,
                isOpen: false,
                sourceType: 'InitialPAA',
                columns: scope.columns.initialPAAAverage
              },
              {
                label: 'Final PAA Average' + ' ' + scope.dateRange,
                value: totals.finalPAAAverage,
                isOpen: false,
                sourceType: 'FinalPAA',
                columns: scope.columns.finalPAAAverage
              },
              {
                label: 'Average of Medication Discrepancies' + ' ' + scope.dateRange,
                value: totals.averageMedicationDiscrepancies,
                isOpen: false,
                sourceType: 'MedicationDiscrepancies',
                columns: scope.columns.medication
              },
              {
                label: 'Average Risk Score' + ' ' + scope.dateRange,
                value: totals.averageRiskScore,
                isOpen: false,
                sourceType: 'Risk',
                columns: scope.columns.riskScore
              }
            ];
          });
        }
        else {
          alertService.add('alert_date', {
            type: 'error',
            activeFor: 6000,
            message: 'Selected date range is not valid.'
          });
        }
      };

      scope.kpiReport = function()
      {
        scope.user.backURL = homeURL.getURL(scope.user.role);
        var date = new Date();
        var currentYear = date.getFullYear();
        kpiTotalPatientsSvc.getDateKeyRequest().then(function(res){
          if(res.data.results !== 1)
          {
            while (currentYear >= res.data.results) {
              scope.filter.years.push(currentYear);
              currentYear = currentYear - 1;
            }
            scope.filter.selected.startDate.year = scope.filter.selected.endDate.year = scope.filter.years[0];
            scope.filter.selected.startDate.month = scope.filter.selected.endDate.month = scope.filter.months[date.getMonth()];
            scope.getFilterData();
          }
        });
      };

      scope.kpiReport();

    }]);
}(window.app));
