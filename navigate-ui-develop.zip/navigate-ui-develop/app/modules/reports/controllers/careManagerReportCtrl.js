(function (app) {
    'use strict';

    app.controller('careManagerReportCtrl', ['$scope', 'careManagementReportSvc', '$http', '$filter','authSvc','$filter', 'navConstantsSvc',
      function (scope,  careManagementReport, http, $filter, authSvc, filter, navConstantsSvc) {
          scope.pageTitle = 'Care Management';
          scope.totalServerItems = 0;
          scope.cmGridData = [];
          scope.pagingOptions = {
              pageSizes: [5, 10, 15],
              pageSize: 10,
              currentPage: 1
            };
          scope.sortBy = '';
          scope.sortType = '';
          scope.gridFilterPatient = [];
          scope.filterReportGrid = [];
          scope.patientListSortingOptions={
            field: 'name',
            reverse: false
          };

          scope.$watch('patientListSortingOptions', function (newVal, oldVal) {
            if(newVal !== oldVal){
              scope.sortBy = newVal.field;
              scope.sortType = newVal.reverse === false ? 'ASC' : 'DESC';
              if(scope.popupURL){
                scope.bindGrid();
              }
            }
          }, true);

          scope.cmTotalServerItems = 0;
          scope.cmPagingOptions = {
            pageSizes: [5, 10, 15],
            pageSize: 10,
            currentPage: 1
          };

          scope.pageIndex = 1;
          scope.pageSize = 10;
          scope.isOpen=true;
          scope.isError = false;

          scope.isGraph = false;
          scope.isCompleteSelected = false;
          scope.isGraphExp = false;
          scope.isPatientdetails = false;
          scope.gridFilterPatient = [];
          scope.list = {
              managedPopulationList: [],
              careTeamList: [],
              careTeamMemberList: [],
              dueDateList: [],
              selectedPopulation: '',
              selectedCareTeam: '',
              selectedCareTeamMember: '',
              selectedDueDate: ''
            };

          scope.user = authSvc.user();
          scope.user.backURL = '';
          scope.gPatientTotal = 0;
          scope.gPatientOpen = 0;
          scope.gPatientMissed = 0;
          scope.gPatientClosedComplete = 0;
          scope.gPatientScheduled = 0;
          scope.popupTitle = '';

          scope.programIdSelected = '';
          scope.careTeamMemberSelected = '';
          scope.careTeamSelected = '';


          scope.init = function () {

              scope.getManagedPopulation();

              scope.patientSearchData = [];
              scope.columnsSelectedPopup = scope.filterReportGridCompleted;
              if (angular.lowercase(scope.user.role) === 'administrator')
              {
                scope.user.backURL = 'admin';
              }
              else if (angular.lowercase(scope.user.role) === 'care manager'){
                scope.user.backURL = 'caremanager';
              }
            };


          /*Loads the Grid on the landing page of Care management*/
          scope.getFilterData = function () {
              var url = 'reports/care-management?';
              var tmpData = '';

              scope.programIdSelected = '';
              scope.primaryCarePhysicianIdSelected = '';
              scope.careTeamMembersIdSelected = '';
              scope.cmPagingOptions.currentPage=1;

              /*Concatenate and send the values if 'All' is selected in the UI -- Managed Population*/
              if (scope.list.selectedPopulation === '' || scope.list.selectedPopulation === null) {
                if (scope.list.selectedPopulation === null) {
                  scope.list.selectedPopulation = '';
                }
                angular.forEach(scope.list.managedPopulationList, function (selectedCondition) {
                      if (tmpData === '') {
                        tmpData = selectedCondition.programId;
                      }
                      else {
                        tmpData = tmpData + ',' + selectedCondition.programId;
                      }
                    });
                scope.programIdSelected = tmpData;
                url = url + '&programId=' + tmpData;
              } else {
                url = url + '&programId=' + scope.list.selectedPopulation;
                scope.programIdSelected = scope.list.selectedPopulation;
              }

              /*Concatenate and send the values if 'All' is selected in the UI -- Care Team*/
              tmpData = '';
              if (scope.list.selectedCareTeam === '' || scope.list.selectedCareTeam === null) {

                angular.forEach(scope.list.careTeamList, function (selected) {
                      if (tmpData === '') {
                        tmpData = selected.id;
                      }
                      else {
                        tmpData = tmpData + ',' + selected.id;
                      }
                    });
                url = url + '&primaryCarePhysicianId=' + tmpData;
              } else {
                url = url + '&primaryCarePhysicianId=' + scope.list.selectedCareTeam;
                scope.primaryCarePhysicianIdSelected = scope.list.selectedCareTeam;
              }

              tmpData = '';
              /*Concatenate and send the values if 'All' is selected in the UI -- Care Team Member*/
              if (scope.list.selectedCareTeamMember === ''  || scope.list.selectedCareTeamMember === null) {

                angular.forEach(scope.list.careTeamMemberList, function (selected) {
                      if (tmpData === '') {
                        tmpData = selected.id;
                      }
                      else {
                        tmpData = tmpData + ',' + selected.id;
                      }
                    });
                url = url + '&careTeamMembersId=' + tmpData;
                scope.careTeamMembersIdSelected = tmpData;
              } else {
                url = url + '&careTeamMembersId=' + scope.list.selectedCareTeamMember;
                scope.careTeamMembersIdSelected = scope.list.selectedCareTeamMember;
              }

              tmpData = '';
              /*Concatenate and send the values if 'All' is selected in the UI -- Due Date*/
              if (scope.list.selectedDueDate === ''  || scope.list.selectedDueDate === null || document.getElementById('cmbDueDates').selectedIndex <= 0) {

                angular.forEach(scope.list.dueDateList, function (selected) {
                      if (tmpData === '') {
                        tmpData = selected.value;
                      }
                      else {
                        tmpData = tmpData + ',' + selected.value;
                      }
                    });

              } else {
                url = url + '&dueDateValue=' + scope.list.selectedDueDate;

              }

              careManagementReport.getStaticData(url)
              .then(function (data) {
                  if (data) {
                    if(data.careManagementList.length > 0){
                      scope.cmGridData = data.careManagementList.slice(0,data.careManagementList.length-2);
                      scope.cmGridDataFooter = data.careManagementList.slice(data.careManagementList.length-2,data.careManagementList.length);
                    }
                    scope.totalActivePatients = data.totalPatientCount;
                    scope.count=Math.ceil(scope.cmGridData.length/scope.cmPagingOptions.pageSize);
                    if (parseInt(scope.totalActivePatients) <= 0) {
                      scope.cmGridData = [];
                      scope.cmGridDataFooter = [];
                    }
                  }
                });
            };

          scope.getManagedPopulation = function () {
              careManagementReport.getStaticData('reports/missed-opportunity/managed-populations')
              .then(function (data) {
                  if (data) {
                    scope.list.managedPopulationList = data;
                    scope.getCareTeam();
                  }
                });
            };

          scope.getCareTeam = function () {

            var url = '';

            url = 'care-teams?context=Report';

            careManagementReport.getStaticData(url)
              .then(function (data) {
                  if (data) {
                    scope.list.careTeamList = _.filter(data, function(careTeam){ return careTeam.name !== navConstantsSvc.allPatientCareTeamName; });
                    scope.getCareTeamMember();
                    scope.getDueDates();
                  }
                });
          };

          scope.changeCareTeam = function () {
            var url = '';

            url = 'care-teams?context=Report';

            scope.list.selectedCareTeam = '';

            if (!(scope.list.selectedPopulation === '' || scope.list.selectedPopulation === null))
              {
              url = 'care-teams?PopulationId=' + scope.list.selectedPopulation + '&context=Report';
            }

            careManagementReport.getStaticData(url)
              .then(function (data) {
                  if (data) {
                    scope.list.careTeamList = _.filter(data, function(careTeam){ return careTeam.name !== navConstantsSvc.allPatientCareTeamName; });
                    scope.getCareTeamMember();
                  }
                });
          };

          scope.getCareTeamMember = function () {

              scope.list.careTeamMemberList = [];
              scope.list.selectedCareTeamMember = '';

              var careTeamIds = '';
              
              _.each( scope.list.careTeamList, function( val ) {
                if ( val ) {
                  if( careTeamIds === ''){
                    careTeamIds = val.id;
                  }else{
                    careTeamIds = careTeamIds + ',' + val.id;
                  }
                }
              });

              careManagementReport.getStaticData('care-team-members?context=Report&careTeamId=' + careTeamIds)
              .then(function (data) {
                  if (data) {
                    scope.list.careTeamMemberList = data.members;
                  }
                });
            };

          scope.changeCareTeams = function()
          {
              var url = '';
              url = 'care-team-members?context=Report';

              if (scope.list.selectedCareTeam !== '' && scope.list.selectedCareTeam !== null) {
                url = url + '&careteamId='+ scope.list.selectedCareTeam ;
                careManagementReport.getStaticData(url)
                .then(function (data) {
                    if (data) {
                      scope.list.selectedCareTeamMember = '';
                      scope.list.careTeamMemberList = data.members;
                    }
                  });
              }
              else{
                scope.getCareTeamMember();
              }
            };

          scope.getDueDates = function () {
              careManagementReport.getStaticData('reports/care-management/due-dates')
              .then(function (data) {
                  if (data) {
                    scope.list.dueDateList = data;
                    scope.getFilterData();
                  }
                });
            };
          scope.reportPatientGrid = {
              data: 'gridFilterPatient',
              multiSelect: false,
              showFooter: true,
              enablePaging: true,
              totalServerItems: 'totalServerItems',
              pagingOptions: scope.pagingOptions,
              filterOptions: scope.filterOptions,
              columnDefs: 'columnsSelectedPopup'
            };

          scope.errorMessage = 'Unfortunately, we are not able to process your request right now. Please try again later or contact your system administrator if this continues.';

          scope.redirectToPatientInfo=function(row){
            window.location.href ='/patients/' + row.patientID;
          };

          scope.filterReportGridCompleted = [
            {
              field: 'memberNum',
              displayName: 'MRN #'
            },
            {
              field: 'patientName',
              displayName: 'Full Name',
              headerClass: 'id',
              cellTemplate: scope.user.role === 'Care Manager' ? '<div class="ngCellText" ng-class="col.colIndex()">' +
                              '<a href="" title="{{row.getProperty(col.field)}}" ng-click="redirectToPatientInfo(row.entity)">{{row.getProperty(col.field)}}</a>' +
                              '</div>' : '<div class="ngCellText" ng-class="col.colIndex()">{{row.getProperty(col.field)}}' +
                              '</div>'
            },
            {
              field: 'age',
              displayName: 'Age',
            },
            {
              field: 'gender',
              displayName: 'Gender',
            },
            {
              field: 'taskTypeName',
              displayName: 'Task Name',
              cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<span title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</span>'+
                          '</div>',
            },
            {
              field: 'taskDueDate',
              displayName: 'Due Date',
              cellFilter: 'date:\'MM/dd/yyyy\'',
            },
            {
              field: 'dateTaken',
              displayName: 'Completed Date',
              cellFilter: 'date:\'MM/dd/yyyy\'',
              width:'*',
            }
          ];

          scope.filterReportGrid = [
            {
              field: 'memberNum',
              displayName: 'MRN #'
            },
            {
              field: 'patientName',
              displayName: 'Full Name',
              headerClass: 'id',
              cellTemplate: scope.user.role === 'Care Manager' ? '<div class="ngCellText" ng-class="col.colIndex()">' +
                              '<a href="" title="{{row.getProperty(col.field)}}" ng-click="redirectToPatientInfo(row.entity)">{{row.getProperty(col.field)}}</a>' +
                              '</div>' : '<div class="ngCellText" ng-class="col.colIndex()">{{row.getProperty(col.field)}}' +
                              '</div>'
            },
            {
              field: 'age',
              displayName: 'Age',
            },
            {
              field: 'gender',
              displayName: 'Gender',
            },
            {
              field: 'taskTypeName',
              displayName: 'Task Name',
              cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<span title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</span>'+
                          '</div>',
            },
            {
              field: 'taskDueDate',
              displayName: 'Due Date',
              cellFilter: 'date:\'MM/dd/yyyy\'',
            }
          ];

          scope.openPatientPopup = function (row, showGraph, showPatients, colTitle,status) {
              
              //Variable initialization for Popup Graphs
              scope.gridFilterPatient = [];
              scope.patientListSortingOptions.field = '';
              scope.patientListSortingOptions.reverse = false;
              scope.pageIndex = 1;
              scope.columnsSelectedPopup = scope.filterReportGrid;
              scope.isCompleteSelected = false;

              if(colTitle === 'Scheduled Tasks'){
                scope.totalServerItems = row.scheduled;
              }

              if(colTitle === 'Total Open Tasks'){
                scope.totalServerItems = row.open;
                scope.reportPatientGrid.totalServerItems = row.open;
              }

              if(colTitle === 'Completed Tasks'){
                scope.totalServerItems = row.closedComplete;
                scope.columnsSelectedPopup = scope.filterReportGridCompleted;
                scope.isCompleteSelected = true;
              }

              if(colTitle === 'Missed Opportunity Tasks'){
                scope.totalServerItems = (status === 'Closed Incomplete' ? row.closedInComplete : row.disEnroll);
              }

              scope.gPatientTotal = 0;
              scope.gPatientOpen = 0;
              scope.gPatientMissed = 0;
              scope.gPatientClosedComplete = 0;
              scope.gPatientScheduled = 0;
              scope.gPatientOpenWidth = 0;
              scope.gPatientMissedWidth = 0;
              scope.gPatientClosedCompleteWidth = 0;
              scope.gPatientScheduledWidth = 0;
              scope.gtaskTypeName = row.taskTypeName;
              scope.gTabRowId = row.tabRowId;
              scope.reportPatientGrid.pagingOptions.currentPage = 1;
              scope.pageSize = 10;

              scope.gPatientOpenCount = row.open;
              scope.gPatientMissedCount = parseInt(row.closedInComplete) + parseInt(row.disEnroll);
              scope.gPatientClosedCompleteCount = row.closedComplete;
              scope.gPatientScheduledCount = row.scheduled;

              if (showGraph === true) {
                scope.popupTitle = row.taskTypeName + ' - ' + row.name;
              } else {
                scope.popupTitle = 'Patient Details' + ' - ' + colTitle;
              }

              scope.totalTasks = 0;

              scope.totalTasks = parseInt(row.open) + parseInt(row.closedInComplete) + parseInt(row.disEnroll) + parseInt(row.closedComplete) + parseInt(row.scheduled);

              if (scope.totalTasks > 0) {
                scope.gPatientOpen = (4 * (row.open * 100) / scope.totalTasks).toFixed(2);
                scope.gPatientMissed = (4 * ((parseInt(row.closedInComplete) + parseInt(row.disEnroll)) * 100) / scope.totalTasks).toFixed(2);
                scope.gPatientClosedComplete = (4 * (row.closedComplete * 100) / scope.totalTasks).toFixed(2);
                scope.gPatientScheduled = (4 * (row.scheduled * 100) / scope.totalTasks).toFixed(2);
                scope.gPatientOpenDisplay = ( (row.open * 100) / scope.totalTasks).toFixed(2);
                scope.gPatientMissedDisplay = ((parseInt(row.closedInComplete) + parseInt(row.disEnroll)) * 100 / scope.totalTasks).toFixed(2);
                scope.gPatientClosedCompleteDisplay = ( (row.closedComplete * 100) / scope.totalTasks).toFixed(2);
                scope.gPatientScheduledDisplay = ( (row.scheduled * 100) / scope.totalTasks).toFixed(2);


                if (scope.gPatientOpen > 0 && scope.gPatientOpen < 40) {
                  scope.gPatientOpenWidth = '40';
                } else {
                  scope.gPatientOpenWidth = scope.gPatientOpen;
                  scope.gPatientOpen = (scope.gPatientOpen / 4).toFixed(2);
                }

                if (scope.gPatientMissed > 0 && scope.gPatientMissed < 40) {
                  scope.gPatientMissedWidth = '40';
                } else {
                  scope.gPatientMissedWidth = scope.gPatientMissed;
                  scope.gPatientMissed = (scope.gPatientMissed / 4).toFixed(2);
                }

                if (scope.gPatientClosedComplete > 0 && scope.gPatientClosedComplete < 40) {
                  scope.gPatientClosedCompleteWidth = '40';
                } else {
                  scope.gPatientClosedCompleteWidth = scope.gPatientClosedComplete;
                  scope.gPatientClosedComplete = (scope.gPatientClosedComplete / 4).toFixed(2);
                }

                if (scope.gPatientScheduled > 0 && scope.gPatientScheduled < 40) {
                  scope.gPatientScheduledWidth = '40';
                } else {
                  scope.gPatientScheduledWidth = scope.gPatientScheduled;
                  scope.gPatientScheduled = (scope.gPatientScheduled / 4).toFixed(2);
                }
              }

              scope.isGraph = showGraph;
              scope.isGraphExp = false;
              scope.pagingOptions.currentPage = 1;
              scope.isPatientdetails = showPatients;
              scope.rowValue = row;
              var dueDate =  scope.list.selectedDueDate !== '' ? scope.list.selectedDueDate : '';
              if (!scope.isGraph){
                scope.popupURL = 'reports/care-management-patients?programId=' + scope.programIdSelected + '&status=' + status + '&taskTypeName=' + scope.gtaskTypeName + '&tabRowId=' + scope.gTabRowId + '&duedate=' + dueDate;
                var url = scope.popupURL + '&pageIndex=' + scope.pageIndex + '&pageSize=' + scope.pageSize;
                careManagementReport.getStaticData(url)
                .then(function (data) {
                  if (data) {
                    scope.gridFilterPatient = data;
                    scope.setPagingData(scope.gridFilterPatient);
                  }
                });
              }
              $('.careManagerPatientDetailPopUp').modal({
                backdrop: 'static',
                keyboard: false
              });

              //Fix the grid freezing issue.
              window.setTimeout(function () {
                        $(window).resize();
                        $(window).resize();
                      }, 100);

            };

          scope.setPagingData = function (data) {
            scope.gridFilterPatient = data;
            if (!scope.$$phase) {
              scope.$apply();
            }
          };

          scope.$watch('pagingOptions', function (newVal, oldVal) {
            var pageSizeCount = parseInt(scope.pagingOptions.pageSize);
            if (newVal !== oldVal) {
              scope.pageIndex = scope.pagingOptions.currentPage;
              scope.pageSize = pageSizeCount;
              scope.bindGrid();
            }
          }, true);

          scope.bindGrid = function () {
            var getUrl = '';
            getUrl = app.api.root + scope.popupURL + '&pageIndex=' + scope.pageIndex + '&pageSize=' + scope.pageSize + '&sortBy=' + filter('isNull')(scope.sortBy) + '&sortType=' + filter('isNull')(scope.sortType);
            http({
              method: 'GET',
              url: getUrl
            })
             .success(function (data) {
                scope.patientSearchData  = data.results;
                scope.setPagingData(scope.patientSearchData);
              })
              .error(function () {
                scope.setPagingData(scope.patientSearchData);
              });
          };

          scope.showPatientDetails = function (status,totalPatients) {
              scope.isPatientdetails = true;

              scope.isGraphExp = true;
              var dueDate =  scope.list.selectedDueDate !== '' ? scope.list.selectedDueDate : '';
              scope.popupURL = 'reports/care-management-patients?programId=' + scope.programIdSelected + '&status=' + status + '&taskTypeName=' + scope.gtaskTypeName + '&tabRowId=' + scope.gTabRowId + '&duedate=' + dueDate;
              var url = scope.popupURL + '&pageIndex=' + scope.pageIndex + '&pageSize=' + scope.pageSize;

              scope.columnsSelectedPopup = scope.filterReportGrid;
              scope.isCompleteSelected = false;

              if(status === 'Closed Complete'){
                scope.columnsSelectedPopup = scope.filterReportGridCompleted;
                scope.isCompleteSelected = true;
              }

              scope.reportPatientGrid.totalServerItems = totalPatients;
              scope.totalServerItems = totalPatients;
              scope.reportPatientGrid.pagingOptions.currentPage = 1;
              scope.pagingOptions.currentPage = 1;

              careManagementReport.getStaticData(url)
              .then(function (data) {
                if (data) {
                  scope.gridFilterPatient = data;
                }
              });
              window.setTimeout(function () {
                        $(window).resize();
                        $(window).resize();
                      }, 100);
            };

          scope.openCareManagerInfo = function () {
              $('.pop-up-container').hide();
              $('.pop-up-container').show();
              window.setTimeout(function () {
                        $(window).resize();
                        $(window).resize();
                      }, 100);
            };

          scope.closeCareManagerInfo = function () {
              $('.pop-up-container').hide();
            };

          /* function to get csv data */
          scope.downloadExcel = function () {
              var url ='';
              url = scope.popupURL + '&pageIndex=1&pageSize=' + scope.totalServerItems;
              careManagementReport.getStaticData(url)
              .then(function (data) {
                  if (data) {
                    var fileName = 'Patients_' + moment().format('MM-DD-YYYY HH:mm:ss') +'.csv';
                    var csvResult = scope.popupTitle + '\n';

                    var myPatientsHeader = ['MRN#', 'Patient Name', 'Age', 'Gender','Task Name', 'Due Date','Completed Date'];

                    if (!scope.isCompleteSelected){
                      myPatientsHeader = ['MRN#', 'Patient Name', 'Age', 'Gender','Task Name', 'Due Date'];
                    }
                    csvResult = csvResult + myPatientsHeader.toString() + '\n';
                    angular.forEach(data, function (patient) {
                      var myPatient = [];

                      if (!scope.isCompleteSelected){
                        myPatient = [patient.memberNum, (patient.patientName.indexOf(',') === -1 ? patient.patientName : '"' + patient.patientName + '"'), patient.age, patient.gender,(patient.taskTypeName.indexOf(',') === -1 ? patient.taskTypeName : '"' + patient.taskTypeName + '"'),$filter('date')(new Date(patient.taskDueDate), 'MM/dd/yyyy')];
                      }else{
                        myPatient = [patient.memberNum, (patient.patientName.indexOf(',') === -1 ? patient.patientName : '"' + patient.patientName + '"'), patient.age, patient.gender,(patient.taskTypeName.indexOf(',') === -1 ? patient.taskTypeName : '"' + patient.taskTypeName + '"'),$filter('date')(new Date(patient.taskDueDate), 'MM/dd/yyyy'),  $filter('date')(new Date(patient.dateTaken), 'MM/dd/yyyy')];
                      }
                      csvResult = csvResult + myPatient.toString() + '\n';
                    });
                    var blob = new Blob([csvResult], {type:'data:text/csv'});
                    window.saveAs(blob, fileName);
                  }
                });
            };

          /* Close the modal pop*/
          scope.closePopup = function () {
              $('.careManagerInfoPopUp').modal('hide');
              $('.careManagerPatientDetailPopUp').modal('hide');
            };


          scope.ShowGraphToolTip = function (obj) {
              $('.crReportTooltip').hide();
              $(obj.target.parentNode.parentNode).find('.crReportTooltip').fadeIn('slow');
            };

          scope.hideGraphToolTip = function (obj) {
              $('.crReportTooltip').hide();
              $(obj).next().fadeOut('slow');
            };
          scope.classMethod('caremanagementreport');
        }]);
  }(window.app));