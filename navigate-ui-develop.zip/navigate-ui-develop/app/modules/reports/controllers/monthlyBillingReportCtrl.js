(function (app) {
  'use strict';

  app.controller('monthlyBillingReportCtrl', ['$scope', 'monthlyBillingReportSvc', '$http', '$filter','authSvc','createUserSvc', 'homeURL', 'downloadCsv',
    function (scope, monthlyBillingReportSvc, http, $filter, authSvc, createUserSvc, homeURL, downloadCsv) {

      scope.pageTitle = 'CCM Monthly Billing Report';
      scope.isOpen = true;
      scope.classMethod('monthlybilling');
      scope.practiceTotals = [];
      scope.practiceDetails = [];
      scope.patientDetails = [];
      scope.practiceData = [];
      scope.monthData = [];
      scope.monthYear = '';
      scope.user = authSvc.user();
      scope.user.backURL = '';
      scope.filter = {practice:[''],dateKey:'',practiceStartIndex:1, practiceEndIndex:20, patientStartIndex:1, patientEndIndex: 50};
      scope.practiceColumns = [{ field: 'practiceName', displayName: 'Practice Name', columnClass: 'table-column-name', sortable: false }, { field: 'totalTime', displayName: 'Total Time (mins)', columnClass: 'table-column-name', sortable: false }];
      scope.practiceDetailsColumns = [{ field: 'practiceName', displayName: 'Practice Name', columnClass: 'table-column-name', sortable: false }, { field: 'patientName', displayName: 'Patient Name', columnClass: 'table-column-name', sortable: false },
                                      { field: 'iD', displayName: 'ID', columnClass: 'table-column-name', sortable: false }, { field: 'totalTime', displayName: 'Total Time (mins)', columnClass: 'table-column-name', sortable: false }];
      scope.patientDetailsColumns = [{ field: 'patientName', displayName: 'Patient Name', columnClass: 'table-column-name', sortable: false }, { field: 'iD', displayName: 'ID', columnClass: 'table-column-name', sortable: false },
                                      { field: 'dOB', displayName: 'DOB', columnClass: 'table-column-name', sortable: false }, { field: 'practiceName', displayName: 'Practice Name', columnClass: 'table-column-name', sortable: false },
                                      { field: 'provider', displayName: 'Provider', columnClass: 'table-column-name', sortable: false }, { field: 'assessmentComplete', displayName: 'Assessment Complete', columnClass: 'table-column-name', sortable: false },
                                      { field: 'contactType', displayName: 'Contact Type', columnClass: 'table-column-name', sortable: false }, { field: 'contactStatus', displayName: 'Contact Status', columnClass: 'table-column-name', sortable: false },
                                      { field: 'totalTime', displayName: 'Time (mins)', columnClass: 'table-column-name', sortable: false }];
      scope.pagingpracticeDetails = {
        size: 20,
        currentPage: 1,
        name: 'Practice'
      };
      scope.pagingpatientDetails = {
        size: 50,
        currentPage: 1,
        name: 'Patient'
      };
      scope.practiceCount = scope.patientCount = 0;

      scope.getFilterData = function() {
        scope.filter.practiceStartIndex = 1;
        scope.filter.patientStartIndex = 1;
        scope.monthYear = (_.find(scope.monthData, function(obj) { return obj.id === scope.filter.dateKey; })).name;
        scope.filter.practiceId = '';
        scope.filter.practice.forEach(function(item){
          scope.filter.practiceId = ((scope.filter.practiceId !== '')? scope.filter.practiceId + ',' + item :item);
        });
        scope.filter.setType = '';
        scope.filter.isExport = false;
        monthlyBillingReportSvc.getMonthlyBillingRequest(scope.filter).then(function(res){
          scope.practiceTotals = res.data.results.practiceTotals;
          scope.practiceDetails = res.data.results.practiceDetails;
          scope.patientDetails = res.data.results.patientDetails;
          scope.practiceCount =  res.data.results.practiceCount.practiceCount;
          scope.patientCount = res.data.results.patientCount.patientCount;
          scope.practiceGrandTotal = res.data.results.practiceCount.grandTotal;
        });
      };

      scope.practiceDataChange = function(data) {
        if(data[0] === '' && data.length > 1)
        {
          scope.filter.practice = [''];
        }
      };

      scope.monthlyBillingReport = function() {
        scope.user.backURL = homeURL.getURL(scope.user.role);
        monthlyBillingReportSvc.getDateKeyRequest().then(function(res) {
          if(res.data.results !== '1')
          {
            var startDate = moment(res.data.results, 'YYYY-MM-DD');
            while (startDate.isBefore(moment(new Date()).format('YYYY-MM-DD'))) {
              var date = startDate.format('YYYY-MM-DD').split('-');
              scope.monthData.push({id: date[0] + '-' + date[1] + '-' + new Date(date[0], date[1], 0).getDate(), name: startDate.format('MMMM YYYY')});
              startDate = startDate.add(1, 'month');
            }
            scope.monthData.reverse();
            if(scope.monthData.length > 1)
            {
              scope.filter.dateKey = scope.monthData[1].id;
              scope.getFilterData();
            }
          }
        });

        createUserSvc.clinics().then(function(data) {
            scope.practiceData = data;
          });
      };

      scope.$watch('pagingpatientDetails', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          scope.filter.isExport = false;
          scope.filter.patientStartIndex = scope.pagingpatientDetails.currentPage;
          scope.filter.patientEndIndex = scope.pagingpatientDetails.size;
          scope.filter.setType = scope.pagingpatientDetails.name;
          monthlyBillingReportSvc.getMonthlyBillingRequest(scope.filter).then(function(res){
            scope.patientDetails = res.data.results.patientDetails;
          });
        }
      }, true);

      scope.$watch('pagingpracticeDetails', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          scope.filter.isExport = false;
          scope.filter.practiceStartIndex = scope.pagingpracticeDetails.currentPage;
          scope.filter.practiceEndIndex = scope.pagingpracticeDetails.size;
          scope.filter.setType = scope.pagingpracticeDetails.name;
          monthlyBillingReportSvc.getMonthlyBillingRequest(scope.filter).then(function(res){
            scope.practiceDetails = res.data.results.practiceDetails;
          });
        }
      }, true);

      scope.downloadCSV = function(val)
      {
        switch(val){
          case 'Totals':{
              var fileName = 'CCMMonthlyBillingPracticeTotals';
              downloadCsv.toCSV(fileName,scope.practiceTotals,_.pluck(scope.practiceColumns,'displayName'),_.pluck(scope.practiceColumns,'field'));
              break;
            }
          case 'Practice':{
              scope.filter.setType = 'Practice';
              scope.filter.isExport = true;
              monthlyBillingReportSvc.getMonthlyBillingRequest(scope.filter).then(function(res){
                var fileName = 'CCMMonthlyBillingPracticeDetails';
                downloadCsv.toCSV(fileName,res.data.results.practiceDetails,_.pluck(scope.practiceDetailsColumns,'displayName'),_.pluck(scope.practiceDetailsColumns,'field'));
              });
              break;
            }
          case 'Patient':{
              scope.filter.setType = 'Patient';
              scope.filter.isExport = true;
              monthlyBillingReportSvc.getMonthlyBillingRequest(scope.filter).then(function(res){
                var fileName = 'CCMMonthlyBillingPatientDetails';
                downloadCsv.toCSV(fileName,res.data.results.patientDetails,_.pluck(scope.patientDetailsColumns,'displayName'),_.pluck(scope.patientDetailsColumns,'field'));
              });
              break;
            }
        }
      };
    }]);
}(window.app));