(function (app) {
  'use strict';

  app.controller('programStatusReportCtrl', ['$scope', 'programStatusReportSvc', '$http', '$filter','authSvc','$modal','homeURL','_','downloadCsv',
    function (scope, programStatusReportSvc, http, filter, authSvc, $modal,homeURL, _,downloadCsv) {

      scope.pageTitle = 'Program Status per Month';
      scope.isOpen = true;
      scope.user = authSvc.user();
      scope.user.backURL = '';
      scope.classMethod('programStatusReport');
      scope.popUpprogramDetails = [];
      scope.showColumnsCSV = false;
      scope.pagingprogramStatusDetails ={
        pageSize: 10,
        currentPage: 1
      };
      scope.init = function () {
          scope.user.backURL = homeURL.getURL(scope.user.role);
        };
      
      var displaymonths = [],
        monthNames = [ 'January', 'February', 'March', 'April', 'May', 'June',
                       'July', 'August', 'September', 'October', 'November', 'December' ];
      
      var tmpDate = new Date();
      var tmpYear = tmpDate.getFullYear();
      var tmpMonth = tmpDate.getMonth();
      for (var i = 0; i < 12;  i = i+1) {
        var loadmonth = {id:'',name:''};
        tmpDate.setMonth(tmpMonth);
        tmpDate.setFullYear(tmpYear);
        loadmonth.name = monthNames[tmpMonth] + ' ' + tmpYear;
        loadmonth.id = tmpYear + '-' + ((tmpMonth + 1) > 9 ? (tmpMonth + 1) : ('0' + (tmpMonth + 1))) + '-' + new Date(tmpYear, tmpMonth+1, 0).getDate();
        displaymonths.push(loadmonth);
        tmpYear = (tmpMonth === 0) ? tmpYear - 1 : tmpYear;
        tmpMonth = (tmpMonth === 0) ? 11 : tmpMonth - 1;
      }
      scope.monthData = displaymonths;
      scope.filter = {};
      scope.filter.filterDate = scope.monthData[0].id;
      scope.codesetPrograms = [];
      programStatusReportSvc.getCodeSetPrograms().then(function(response){
        scope.codesetPrograms = response.data.results;
      });
      scope.getAnchorDates = function(index){
        _.each(scope.anchorDates,function(item){
          scope.gridData[index][item] = '';
        });
      };
      scope.loadInitialData = function(){
       
        programStatusReportSvc.getProgramStatus(scope.filter).then(function (response) {
          scope.data = response.data.results;

          scope.gridData=[];
          scope.anchorDateData=[];
          _.each(scope.data,function(item){
            item.anchorDate= moment(item.anchorDate).format('MMM[-]YYYY');
            scope.anchorDateData.push(item);
          });
          scope.data=scope.anchorDateData;
          var groupedByCount = _.countBy(scope.data, function (item) {
            return item.anchorDate;
          });
          scope.anchorDates=_.uniq(_.pluck(scope.data,'anchorDate'));
          for(var i=0;i<_.max(groupedByCount);i=i+1){
            scope.gridData.push({Status:''});
            scope.getAnchorDates(i);
          }
          scope.dateHeaders=['Status'].concat(scope.anchorDates);
          scope.dateHeaders.push('Total');
          _.each(scope.data,function(item){
            var index;
            var data;
            if((_.where(scope.gridData,{Status:item.statusDefinition})).length>0){
              data = _.where(scope.gridData,{Status:item.statusDefinition});
              index=scope.gridData.indexOf(data[0]);
            }
            else{
              data = _.where(scope.gridData,{Status:''});
              index= data.length>0?scope.gridData.indexOf(data[0]):0;
              scope.gridData[index].Status=item.statusDefinition;
            }
            for(var property in scope.gridData[index]) {
              if(property === item.anchorDate){
                scope.gridData[index][item.anchorDate] = item.patientCount;
              }
            }
          });
          scope.gridData.push({Status:'Total'});
        });
      };
      scope.loadInitialData();
      scope.openPatientPopup = function (item,dateColumn,count) {
        scope.columnsSelected = [];
        scope.monthandYear = moment(dateColumn).format('MMMM-YYYY');
        scope.patientStatus = item.Status;
        var dateaslettrs = moment(dateColumn).format('YYYY-MM-DD');
        var dateasnumericals = new Date(dateaslettrs);
        var lastDay = new Date(dateasnumericals.getFullYear(), dateasnumericals.getMonth() + 1, 0);
        var lastdatefinal = moment(lastDay).format('YYYY-MM-DD');
        scope.totalCount = count;
        scope.rowData = {
          lastDate :lastdatefinal,
          status : item.Status,
          pageIndex : scope.pagingprogramStatusDetails.currentPage,
          pageSize : scope.pagingprogramStatusDetails.pageSize,
          programIds : scope.filter.ProgramIds
        };
        programStatusReportSvc.getProgramStatusDetails(scope.rowData).then(function(response){
          var filterData = _.filter(response.data.results, function(item){ return item.assessmentName !== null; });
          if(item.Status === 'Ineligible' || (item.Status === 'Transferred' && filterData.length > 0 ) || item.Status === 'Pending' || (item.Status ===  'Declined' && filterData.length > 0)){
            scope.showColumnsCSV = true;
            scope.columnsSelected = [
              { field: 'firstName', displayName: 'Name', columnClass: 'table-column-name' },
              { field: 'medicalRecordNumber', displayName: 'ID', columnClass: 'table-column-listDate' },
              { field: 'dateOfBirth', displayName: 'DOB', columnClass: 'table-column-listDate'},
              { field: 'assessmentName', displayName: 'Assessment Name'},
              { field: 'answer', displayName: 'Answer'},
              { field: 'completionDate', displayName: 'Completion Date'}
            ];
          }
          else{
            scope.showColumnsCSV = false;
            scope.columnsSelected = [
              { field: 'firstName', displayName: 'Name', columnClass: 'table-column-name' },
              { field: 'medicalRecordNumber', displayName: 'ID', columnClass: 'table-column-medicalRecordNumber' },
              { field: 'dateOfBirth', displayName: 'DOB', columnClass: 'table-column-dateOfBirth'}
            ];
          }
          scope.popUpprogramDetails = response.data.results;
        });
        scope.programStatusPatientPopup = $modal.open({
          templateUrl: 'programStatusPatientPopup.html',
          scope: scope,
          backdrop: 'static',
          size: 'lg',
          keyboard: false
        });
      };
      
      scope.closePopup = function () {
        scope.popUpprogramDetails = [];
        scope.programStatusPatientPopup.close();
      };
      scope.getFilterData = function(filter)
      {
        scope.filter.filterDate = filter.filterDate;
        scope.loadInitialData();
      };
      scope.downloadCSVReport = function()
      {
        var programStatusReport=[];
        angular.forEach(scope.gridData, function (item){
          var columnsData = [];
          angular.forEach(item, function (header){
            columnsData.push(header);
          });
          var sumOfColumns = 0;
          angular.forEach(columnsData, function (row){
            if(angular.isNumber(row)){
              sumOfColumns = sumOfColumns + (parseInt(row));
            }
          });
          columnsData[columnsData.length-1] = sumOfColumns;
          programStatusReport.push(columnsData);
        });
        programStatusReport.pop();
        var objRowsData = [];
        objRowsData.push('Total');
        var grandTotal = 0;
        angular.forEach(scope.dateHeaders, function (header){
          if(header !== 'Status'){
            var sumOfRowsData = 0;
            scope.gridData.forEach(function(res){
              if(parseInt(res[header])){
                sumOfRowsData = sumOfRowsData + parseInt(res[header]);
              }
            });
            objRowsData.push(sumOfRowsData);
            grandTotal = grandTotal + sumOfRowsData;
          }
        });
        objRowsData[objRowsData.length -1] = grandTotal;
        programStatusReport.push(objRowsData);
        var fileName = 'ProgramStatusMonth-' + moment(scope.filter.filterDate).format('MMMM-YYYY');
        downloadCsv.toCSV(fileName,programStatusReport,scope.dateHeaders,[]);
      };
      scope.ExportToCSV = function()
      {
        var fileName = 'ProgramStatusMonth_PatientDetails-' + moment(scope.monthandYear).format('MMMM-YYYY') + '_' + moment().format('MM-DD-YYYY HH:mm:ss');
        var rowData = {
          lastDate :scope.rowData.lastDate,
          status : scope.rowData.status,
          pageIndex : 1,
          pageSize : scope.totalCount,
          programIds : scope.filter.ProgramIds
        };
        var csvResult = _.pluck(scope.columnsSelected,'displayName').toString() + '\n';
        programStatusReportSvc.getProgramStatusDetails(rowData).then(function(response){
          scope.popUpprogramDetailsCSV = response.data.results;
          angular.forEach(scope.popUpprogramDetailsCSV, function (patient){
            var programPatient = [];
            if(scope.showColumnsCSV){
              programPatient = [patient.lastName + ' ' + patient.firstName,patient.medicalRecordNumber,moment(patient.dateOfBirth).format('MM/DD/YYYY'),patient.assessmentName,patient.answer,patient.completionDate!==null?(moment(patient.completionDate).format('MM/DD/YYYY')):''];
            }
            else{
              programPatient = [patient.lastName + ' ' + patient.firstName,patient.medicalRecordNumber,moment(patient.dateOfBirth).format('MM/DD/YYYY')];
            }
            csvResult = csvResult + programPatient.toString() + '\n';
          });
          fileName = fileName +'.csv';
          var blob = new Blob([csvResult], {type:'data:text/csv'});
          window.saveAs(blob, fileName);
        });
      };
      scope.$watch('pagingprogramStatusDetails', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          scope.rowData.pageIndex=scope.pagingprogramStatusDetails.currentPage;
          programStatusReportSvc.getProgramStatusDetails(scope.rowData).then(function(response){
            scope.popUpprogramDetails = response.data.results;
          });
        }
      }, true);

    }]);
}(window.app));
