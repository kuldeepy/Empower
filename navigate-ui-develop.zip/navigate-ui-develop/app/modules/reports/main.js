(function (app) {
  'use strict';

/* module root controller */
  var modulePath = 'modules/administrator';

  /* module root controller */
  app.controller('reportsMainCtrl', ['$scope', 'authSvc', function (scope, authSvc) {
    scope.model = {
      routeParams: {}
    };
    scope.classMethod=function(name){
      scope.classState=name;
    };
    scope.classMethod('condition');
    scope.auser = authSvc.user();
  }]);

   /* load required controllers */
  $.when(
  $.getScript('/modules/administrator/controllers/conditionPrevalenceCtrl.js'),
  $.getScript('/modules/administrator/controllers/comorbidityReportCtrl.js'),
  $.getScript('/modules/administrator/controllers/hedisCtrl.js'),
  $.getScript('/modules/administrator/controllers/payForPerformanceCtrl.js'),
  $.getScript('/modules/administrator/controllers/chronicCareManagementCtrl.js'),
  $.getScript('/modules/administrator/controllers/PatientlistCtrl.js')
  ).done(function () {
    app.publish('moduleReady', modulePath);
  });

}(window.app));
