﻿(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('GeneralInformationCtrl', ['$scope', '$state', 'taskBundleStateSvc', '$location','taskBundleDataSvc',
    function (scope,state,taskBundleStateSvc,location,taskBundleDataSvc) {
      
      scope.init = function(){
        scope.hideNotifications();
        if (scope.initializeStep) {
          if (scope.editTaskBundle.isEditStatus === 'true') {
            scope.editTaskBundle.isEditStatus = false;
            state.go('summary');
            scope.initializeStep('summary',true);
          } else {
            scope.initializeStep(state.current.name,false);
          }
        }
      };

      scope.$watch('createTaskBundle.$pristine', function () {
        if (scope.createTaskBundle && !scope.createTaskBundle.$pristine) {
          localStorage.setItem('isWizardFormDirty', true);
        }
      });

      scope.$watch('createTaskBundle.$valid', function (val) {
          
          if (state.current.name === 'generalInformation' && !scope.checkTaskBundleExist()) {
            scope.completeStep(val, 'generalInformation');
          }
        });

      scope.$on('wizardOnClose', function() {
        taskBundleStateSvc.clear();
        if(app !== undefined && app.currentRoute !== undefined) {
          location.url(app.currentRoute);
        }
        else{
          location.url('/admin/taskbundle');
        }
      });
      scope.inactivealert='This is the only task bundle associated to ';
      scope.inactivealertjoin=' Managed Population(s). Please add another active task bundle to that Managed Population before inactivating this task bundle.';
      scope.taskStatus = function(value) {
        if (value === 'Active') {
          scope.notification = {
            visible: false
          };
          scope.completeStep(scope.createTaskBundle.$valid, 'generalInformation');
        } else {
          if(scope.taskPersistedData.generic.id){
            taskBundleDataSvc.getInActiveTaskBundles(scope.taskPersistedData.generic.id).then(
              function(response) {
                scope.active=response.data.results;
                var programName;
                if(scope.active.activeTaskStatus){
                  programName = _.pluck(scope.active.taskBundleActiveStatus,'programName');
                  programName = programName.join(', ');
                  scope.notification = {
                    visible: true,
                    message: scope.inactivealert + programName + scope.inactivealertjoin
                  };
                  scope.completeStep(!scope.active.activeTaskStatus, 'generalInformation');
                }
              }
            );
          }
        }
      };

      scope.checkTaskBundleExist = function () {
        scope.isTaskBundleExist = false;

        if(scope.taskPersistedData.generic){

          taskBundleDataSvc.getTaskBundlesByName(scope.taskPersistedData.generic.name).then(
            function(response){

              response.data.results.forEach(function(taskBundle){
                if( taskBundle.name.toLowerCase() === scope.taskPersistedData.generic.name.toLowerCase() && parseInt(scope.editTaskBundle.id) !== taskBundle.id ){
                  scope.isTaskBundleExist = true;
                  scope.createTaskBundle.taskBundleName.$setValidity('required', false);
                }
              });

              if(scope.createTaskBundle.$valid){
                scope.completeStep(!scope.isTaskBundleExist, 'generalInformation');
              }
            }
          );
        }
        return scope.isTaskBundleExist;
      };
    }]);
  }(window.app));