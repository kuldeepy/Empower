(function (app) {
  'use strict';

  app.controller('AssessmentBundleCtrl', ['$scope', '$state','taskBundleStateSvc', '$location', function (scope, state, taskBundleStateSvc, location) {
    scope.welcomeText = 'Patients';

    scope.totalServerItems = 0;
    scope.pagingOptions = {
      pageSizes: [5, 10, 15],
      pageSize: 10,
      currentPage: 1
    };

    scope.gridAssessment = {
      data: 'gridAssessmentData',
      multiSelect: false,
      showFooter: true,
      enablePaging: true,
      enableSorting:false,
      totalServerItems: 'totalServerItems',
      pagingOptions: scope.pagingOptions,
      filterOptions: scope.filterOptions,
      columnDefs: 'AssessmentColumns'
    };

    scope.assessmentSeedData = {
      'recurrence': [{ id: 'One Time', name: 'One Time' }, { id: 'Recurring', name: 'Recurring' }],
      'frequency': [{ id: 'Day(s)', name: 'Day(s)' }, { id: 'Week(s)', name: 'Week(s)' }, { id: 'Month(s)', name: 'Month(s)' }, { id: 'Years(s)', name: 'Years(s)' }],
      'fcounter': Array.apply(0, new Array(100)).map(function (n, i) { return (i + 1); })
    };

    scope.checkPersistedData = function(persistedData){
      if(persistedData && persistedData.length >= 1){
        return persistedData;
      }else{
        return false;
      }
    };

    scope.gridAssessmentData = scope.checkPersistedData(scope.taskPersistedData.assessments) || [
      {id: '1', assessmentname: '', recurrence: '', frequency: '',fcounter:'',newrow:true, active: 0,state:'create'}
    ];

    scope.refreshState = function(){
        scope.gridAssessmentData = scope.gridAssessmentData.map(function(node){
          if( $.trim(node.assessmentname).length !== 0 && $.trim(node.recurrence).length !== 0  &&
              $.trim(node.frequency).length !== 0  && $.trim(node.fcounter).length !== 0 && node.newrow === true && node.active === 0){
            node.active = 1;
          }
          return node;
        });
      };

    scope.$watch(function() {
        return scope.gridAssessmentData;
      }, function(newValue) {
          scope.taskPersistedData.assessments = newValue;
          scope.refreshState();
        },true);

    scope.init = function () {
      if (scope.initializeStep) {
        scope.initializeStep('assessments', false);
      }
      //var staticApiData = scope.$parent.$parent.$parent.$parent.taskBundleData;
      scope.assessmentSeedData = angular.extend(scope.assessmentSeedData, scope.taskBundleData);
    };

    scope.addRow = function (id) {
      localStorage.setItem('isWizardFormDirty', true);
      var selectedAssessments = _.where(scope.gridAssessmentData,{assessmentname: scope.gridAssessmentData[id].assessmentname, recurrence:scope.gridAssessmentData[id].recurrence, frequency: scope.gridAssessmentData[id].frequency, fcounter: scope.gridAssessmentData[id].fcounter});
      if (scope.gridAssessmentData[id].newrow === true && scope.gridAssessmentData[id].active === 1) {
        if (selectedAssessments.length > 1) {
          scope.completeStep(false, 'assessments');
          scope.ShowNotifications('Assessment name already exists. Please enter a different name', 'alert-error');
          return false;
        }
        scope.gridAssessmentData[id].newrow = false;
        scope.gridAssessmentData.push({ id: scope.gridAssessmentData.length + 1, assessmentname: '', recurrence: '', frequency: '', fcounter: '', newrow: true, active: 0, state: 'create' });
      } else if (scope.gridAssessmentData[id].newrow === false) {
        scope.gridAssessmentData = scope.gridAssessmentData.filter(function (node, idx) {
          if (id !== idx) {
            return true;
          } else if (node.state === 'edit') {
            scope.taskDeletedData.assessments.push(node);
          }
        });
        scope.taskPersistedData.assessments = scope.gridAssessmentData;
        scope.checkValidation();
      }
    };

    scope.$watch('taskAssessments.$valid', function (val) {
      
      if (state.current.name === 'assessments') { //&& scope.tempCareManagers.length > 1
        //scope.getCareTeamDetails();
        localStorage.setItem('isWizardFormDirty', true);
        scope.completeStep(val, 'assessments');
      }
    });

    scope.$on('wizardOnClose', function() {

      taskBundleStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {
        location.url(app.currentRoute);
      }
      else{
        location.url('/admin/taskbundle');
      }
    });

    scope.$watch('taskPersistedData.assessments.length', function () {

      if( scope.isCriteriaStepComplete()){
        if (_.filter(scope.taskPersistedData.education, function (item) { return (item.eduName === undefined || item.eduName === '' && item.newrow === false); }).length > 0|| _.filter(scope.taskPersistedData.othertasks, function (item) { return (item.taskname === undefined || item.taskname === '' && item.newrow === false); }).length > 0) {
          scope.setStepSummaryClickable();
        } else {
          scope.setStepSummaryClickable();
        }
        scope.tabDefinitions[2].clickable = scope.tabDefinitions[2].isTabCompleted;
      }else{
        scope.setStepSummaryClickable();
        scope.tabDefinitions[2].clickable = false;
      }
      scope.checkValidation();
    });

    scope.checkValidation = function(id) {
      if(id){
        if(scope.gridAssessmentData[id].newrow === false){
          var selectedAssessments = _.where(scope.gridAssessmentData,{assessmentname: scope.gridAssessmentData[id].assessmentname, recurrence:scope.gridAssessmentData[id].recurrence, frequency: scope.gridAssessmentData[id].frequency, fcounter: scope.gridAssessmentData[id].fcounter});
          if (selectedAssessments.length > 1) {
            scope.ShowNotifications('Assessment name already exists. Please enter a different name', 'alert-error');
            scope.completeStep(false, 'assessments');
          }
          else{
            scope.completeStep(true, 'assessments');
          }
        }
      }
      else {
        var duplicateAssessment = _.groupBy(scope.gridAssessmentData, function(item) {
          return item.assessmentname+ '-' + item.recurrence+ '-' + item.frequency+ '-' + item.fcounter;
        });
        _.forEach(duplicateAssessment, function(items) {
          if (items.length > 1) {
            scope.ShowNotifications('Assessment name already exists. Please enter a different name', 'alert-error');
            scope.completeStep(false, 'assessments');
          }
          else{
            scope.completeStep((items.length > 1 ? false : true), 'assessments');
          }
          return false;
        });
      }
    };

  }]);
}(window.app));
