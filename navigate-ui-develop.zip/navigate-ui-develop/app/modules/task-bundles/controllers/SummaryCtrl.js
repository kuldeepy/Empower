(function (app) {
  'use strict';

  app.controller('SummaryCtrl', ['$scope', '$http','$state', '$location', 'taskBundleStateSvc',
  function (scope, http,state,location,taskBundleStateSvc) {
    scope.init = function () {

      if (scope.initializeStep) {
        scope.initializeStep('summary', true);
      }
      if (scope.editTaskBundle.isEdit === 'true' && scope.summaryState.state === 1) {
        scope.taskBundleHeader = 'Edit Task Bundle';
        scope.getTaskBundle();
      } else {
        scope.mapTaskIdsToName();
        //fixed this because other task's were not mandatory before so just others.length might through an error.
        if( !( scope.taskPersistedData.procedures.length > 1 || scope.taskPersistedData.assessments.length > 1 || scope.taskPersistedData.education.length > 1 || (scope.taskPersistedData.othertasks ? (scope.taskPersistedData.othertasks.length > 1 ? true : false) : false)  )){
          scope.initializeStep('otherTasks', false);
          state.go('otherTasks');
        }
      }

      scope.hasValidData = true;


      var duplicateAssessment = _.groupBy(scope.taskPersistedData.assessments, function(item) {
        return item.assessmentname+ '-' + item.recurrence+ '-' + item.frequency+ '-' + item.fcounter;
      });


      _.forEach(duplicateAssessment, function(items) {
        if (items.length > 1) {
          scope.ShowNotifications('There are duplicate tasks added in ‘Assessments’. Request you to please remove the duplicate tasks to save this Task Bundle.', 'alert-error',false);
          scope.hasValidData = false;
        }
      });

      var emptyTaskName = _.where(scope.taskPersistedData.othertasks,{taskname:undefined,newrow:false});

      if(emptyTaskName.length>0){
        scope.ShowNotifications('There are invalid tasks added in ‘Other-tasks’. Request you to please remove the invalid tasks to save this Task Bundle.', 'alert-error',false);
        scope.hasValidData = false;
      }

      scope.$emit('setSaveDisabled', !scope.hasValidData);
      scope.$emit('setSaveAsDraftDisabled', !scope.hasValidData);
      scope.$emit('setSaveAsDraftDisabled', scope.taskPersistedData.generic.productionStatus === 'Final' ? true : false);
    };
    
    scope.mapTaskIdsToName = function () {
      var taskText = '';

      angular.forEach(scope.taskPersistedData, function (node, key) {

        if ( node === null){
          node = [];
          if(key === 'education'){
            scope.taskPersistedData.education = [];
          }
        }

        if (key === 'assessments') {
          scope.taskPersistedData.assessments = node.map(function (nd) {
            nd.taskText = '';
            taskText = scope.taskBundleData.assessments.filter(function (ele) {
              return parseInt(ele.assessmentId, 10) === parseInt(nd.assessmentname, 10);
            });
            if (taskText.length > 0 && taskText[0].assessmentName) {
              nd.taskText = taskText[0].assessmentName;
            }
            return nd;
          });
        } else if (key === 'procedures') {
          scope.taskPersistedData.procedures = node.map(function (nd) {
            nd.taskText = '';
            taskText = scope.taskBundleData.procedures.filter(function (ele) {
              return parseInt(ele.id, 10) === parseInt(nd.procedurename, 10);
            });
            if (taskText.length > 0 && taskText[0].name) {
              nd.taskText = taskText[0].name;
            }
            return nd;
          });
        }
      });
    };

    scope.getTaskBundle = function () {
      var getUrl = app.api.root + 'task-bundles/' + scope.editTaskBundle.id;
      http({
        method: 'GET',
        url: getUrl
      })
      .success(function (data) {
        scope.clearTaskPersistedData();
        scope.editViewDataBuildUp(data);
        scope.summaryState.state = scope.summaryState.state + 1;
        scope.mapTaskIdsToName();
        scope.$emit('setSaveAsDraftDisabled', scope.taskPersistedData.generic.productionStatus === 'Final' ? true : false);
      });
    };

    scope.$on('wizardOnsaveAndClose', function() {
        scope.saveAndClose('Final');
      });

    scope.$on('wizardOnsaveDraftAndClose', function() {
        scope.saveAndClose('Draft');
      });

    scope.saveAndClose = function (prodStatus) {
            
          if (!scope.taskPersistedData.generic.name) {
            scope.ShowNotifications('Task Bundle Name required', 'alert-error');
            return false;
          }

          scope.editTaskBundle.isSaveAsDraft = false;
          if (prodStatus === 'Draft') {
            scope.editTaskBundle.isSaveAsDraft = true;
          }
          var apiPayload = {}, method = '', successMessage = '', deleteStack = [];
          if(scope.editTaskBundle.isEdit === 'true'){
            method = 'PUT';
            apiPayload = scope.createApiData('edit', prodStatus);
            if(scope.taskDeletedData.assessments.length > 0 ||
               scope.taskDeletedData.procedures.length > 0 ||
               scope.taskDeletedData.othertasks.length > 0 ||
               scope.taskDeletedData.education.length > 0){
                
              deleteStack = scope.createApiData('delete', prodStatus);
              $.merge(apiPayload.criterias,deleteStack);
            }
            successMessage = 'Task Bundle has been updated successfully';
          }else{
            method = 'POST';
            apiPayload = scope.createApiData('create', prodStatus);
            successMessage = 'Task Bundle has been added successfully';
            if (scope.editTaskBundle.isSaveAsDraft) {
              successMessage = 'Task Bundle has been saved as draft successfully';
            }
          }

          http({
            method: method,
            url: app.api.root + 'task-bundles',
            data: apiPayload
          }).
          success(function (data) {
            if (data.results === -99) {
              scope.ShowNotifications('Task Bundle name already exists. Please enter different name', 'alert-error');
              return false;
            }
            
            scope.ShowSuccessNotifications(successMessage, 'alert-success');
            scope.clearTaskPersistedData();
            location.path('admin/taskbundle');
          });
        };

    scope.clearTaskPersistedData = function () {
          // scope.taskPersistedData = {} will create a local scope object
          // and won't clear actual data
          scope.taskPersistedData.assessments = null;
          scope.taskPersistedData.procedures = null;
          scope.taskPersistedData.othertasks = null;
          scope.taskPersistedData.education = null;
          scope.taskPersistedData.generic = null;

          scope.taskDeletedData.assessments = [];
          scope.taskDeletedData.procedures = [];
          scope.taskDeletedData.othertasks = [];
          scope.taskDeletedData.education = [];
        };

    scope.$on('wizardOnClose', function() {
      taskBundleStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {
        location.url(app.currentRoute);
      }
      else{
        location.url('/admin/taskbundle');
      }
    });

  }]);

}(window.app));