(function (app) {
  'use strict';

  app.controller('EducationBundleCtrl', ['$scope','$http', '$state', 'taskBundleStateSvc', '$location', function (scope,http,state,taskBundleStateSvc,location) {

    scope.checkPersistedData = function(persistedData){
      if(persistedData && persistedData.length >= 1){
        return persistedData;
      }else{
        return false;
      }
    };

    scope.eduBundleGrid = scope.checkPersistedData(scope.taskPersistedData.education) ||  [
      {id: '1', eduName: '', eduBundleList: '', fcounter:'',newrow:true,active: 0,state:'create'}
    ];

    scope.listEducationaBundle = [];


    scope.init = function () {
      if (scope.initializeStep) {
        scope.initializeStep('educationMaterials', false);
      }

      if(scope.listEducationaBundle.length === 0){
        http.get(app.api.root+'documents')
          .success(function (data) {
            scope.listEducationaBundle = [{'id':0,'name':'Select'}].concat(data.results);
          });
      }
    };

    scope.refreshState = function(){
      scope.eduBundleGrid = scope.eduBundleGrid.map(function(node){
        if( $.trim(node.eduName).length !== 0 && $.trim(node.lstSelectedDoc).length !== 0 && node.newrow === true && node.active === 0){
          node.active = 1;
        }
        else if($.trim(node.lstSelectedDoc).length === 0)
        {
          node.active = 0;
        }
        return node;
      });
    };

    scope.$watch(function () {
      return scope.eduBundleGrid;
    }, function (newValue) {
      scope.taskPersistedData.education = newValue;
      scope.refreshState();
    },true);


    scope.addEducationBundle = function (id) {
      localStorage.setItem('isWizardFormDirty', true);
      var eduName = scope.eduBundleGrid[id].eduName ? scope.eduBundleGrid[id].eduName.toLocaleLowerCase() : '',
       selectedNames = scope.eduBundleGrid.map(function (node) {
          return node.eduName ? node.eduName.toLocaleLowerCase() : '';
        });
      selectedNames.pop(eduName);

      if (scope.eduBundleGrid[id].newrow === true && scope.eduBundleGrid[id].active === 1) {
        if (selectedNames.indexOf(eduName) !== -1) {
          showDuplicateErrorAndMakeIncomplete();
          return false;
        }
        scope.eduBundleGrid[id].newrow = false;
        scope.eduBundleGrid.push({ id: scope.eduBundleGrid.length + 1, eduName: '', eduBundleList: '', fcounter: '', newrow: true, active: 0, state: 'create' });
      } else if (scope.eduBundleGrid[id].newrow === false) {
        scope.eduBundleGrid = scope.eduBundleGrid.filter(function (node, idx) {
          if (id !== idx) {
            return true;
          } else if (node.state === 'edit') {
            scope.taskDeletedData.education.push(node);
          }
        });
        scope.taskPersistedData.education = scope.eduBundleGrid;
      }
      scope.taskNameChanged();
    };

    scope.clickRemoveEduBundleList = function(index){
      localStorage.setItem('isWizardFormDirty', true);
      var modifiedData = [];
      _.forEach(scope.eduBundleGrid[index].removeSelectedDoc, function(item){
        if(!angular.isObject(item))
        {
          modifiedData.push(JSON.parse(item));
        }
        else
        {
          modifiedData.push(item);
        }
      });
      scope.eduBundleGrid[index].removeSelectedDoc = modifiedData;
      var dataEduLibListSelected = scope.eduBundleGrid[index].removeSelectedDoc;
      var pushState =false;
      scope.eduBundleGrid[index].lstSelectedDoc = scope.eduBundleGrid[index].lstSelectedDoc.map(function(optionItem) {
        pushState = false;
        angular.forEach(dataEduLibListSelected,function(element) {
          if(optionItem.id === element.id){
            pushState = true;
          }
        });
        return (pushState) ? null : optionItem;
      });

      scope.eduBundleGrid[index].lstSelectedDoc = scope.eduBundleGrid[index].lstSelectedDoc.filter(function(optionItem) {
        return (optionItem === null) ? false : true;
      });
    };

    scope.clickAddToEduBundleList = function(index){
      localStorage.setItem('isWizardFormDirty', true);
      var selectedVal = scope.eduBundleGrid[index].eduBundleList;
      if(selectedVal === '0'){
        return;
      }
      var filteredVal = scope.listEducationaBundle.filter(function(value){
        if(selectedVal.toString() === value.id.toString()){
          return  true;
        }
      });

      var dataEduLibList = {'id':filteredVal[0].id,'name':filteredVal[0].name};
      var pushState = true;
      if(scope.eduBundleGrid[index].lstSelectedDoc === undefined)
      {
        scope.eduBundleGrid[index].lstSelectedDoc = [];
      }
      if(scope.eduBundleGrid[index].lstSelectedDoc.length === 0){
        scope.eduBundleGrid[index].lstSelectedDoc.push(dataEduLibList);
      }else if(scope.eduBundleGrid[index].lstSelectedDoc.length > 0){
        angular.forEach(scope.eduBundleGrid[index].lstSelectedDoc,function(element) {
          if(dataEduLibList.id === element.id){
            pushState = false;
          }
        });
        if(pushState){
          scope.eduBundleGrid[index].lstSelectedDoc.push(dataEduLibList);
        }
      }
    };

    scope.$watch('taskEducation.$valid', function(val) {
      if (state.current.name === 'educationMaterials') {
        localStorage.setItem('isWizardFormDirty', true);
        if (hasDuplicateTaskNames()) {
          showDuplicateErrorAndMakeIncomplete();
        } else {
          scope.completeStep(val, 'educationMaterials');
        }
      }
    });

    scope.$on('wizardOnClose', function() {
      taskBundleStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {
        location.url(app.currentRoute);
      }
      else{
        location.url('/admin/taskbundle');
      }
    });
    
    scope.$watch('taskPersistedData.education.length', function () {
      if (scope.isCriteriaStepComplete()) {
        if (_.filter(scope.taskPersistedData.education, function (item) { return (item.eduName === undefined || item.eduName === '' && item.newrow === false); }).length > 0 || _.filter(scope.taskPersistedData.othertasks, function (item) { return (item.taskname === undefined || item.taskname === '' && item.newrow === false); }).length > 0) {
          scope.setStepSummaryClickable();
        } else {
          scope.setStepSummaryClickable();
        }
        scope.tabDefinitions[2].clickable = scope.tabDefinitions[2].isTabCompleted;
      }else{
        scope.setStepSummaryClickable();
        scope.tabDefinitions[2].clickable = false;
      }
    });

    function hasDuplicateTaskNames(){
      
      var names = _.pluck(scope.eduBundleGrid, 'eduName').map(function(name){
        return name.toLowerCase();
      });
      var grouped = _.groupBy(names, function(n) { return n; });
      return _.some(_.values(grouped), function(a) { return a.length > 1; });
    }

    function showDuplicateErrorAndMakeIncomplete(){
      scope.ShowNotifications('Task name already exists. Please enter a different name', 'alert-error');
      scope.completeStep(false, 'educationMaterials');
    }

    scope.taskNameChanged = function() {
      if (hasDuplicateTaskNames()) {
        showDuplicateErrorAndMakeIncomplete();
      } else {
        scope.completeStep(true, 'educationMaterials');
      }
    };

  }]);
}(window.app));
