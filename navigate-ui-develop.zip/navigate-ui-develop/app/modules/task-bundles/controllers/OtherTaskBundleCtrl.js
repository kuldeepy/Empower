(function (app) {
  'use strict';

  app.controller('OtherTaskBundleCtrl', ['$scope', '$state', 'taskBundleStateSvc', '$location', function (scope,state,taskBundleStateSvc,location) {
    scope.welcomeText = 'Patients';

    scope.totalServerItems = 0;
    scope.showValidationNote = true;
    scope.pagingOptions = {
      pageSizes: [5, 10, 15],
      pageSize: 10,
      currentPage: 1
    };


    scope.otherTaskSeedData = {
      'recurrence': [{ id: 'One Time', name: 'One Time' }, { id: 'Recurring', name: 'Recurring' }],
      'frequency': [{ id: 'Day(s)', name: 'Day(s)' }, { id: 'Week(s)', name: 'Week(s)' }, { id: 'Month(s)', name: 'Month(s)' }, { id: 'Years(s)', name: 'Years(s)' }],
      'fcounter': Array.apply(0, new Array(100)).map(function (n, i) { return (i + 1); })
    };

    scope.checkPersistedData = function(persistedData){
      if(persistedData && persistedData.length >= 1){
        return persistedData;
      }else{
        return false;
      }
    };

    scope.gridOtherTaskData = scope.checkPersistedData(scope.taskPersistedData.othertasks) || [
      {id: '1', taskname: '', recurrence: '', frequency: '',fcounter:'',newrow:true, active: 0, state:'create'}
    ];
    
    scope.refreshState = function(){
        scope.gridOtherTaskData = scope.gridOtherTaskData.map(function(node){
          if( $.trim(node.taskname).length !== 0 && $.trim(node.recurrence).length !== 0  &&
              $.trim(node.frequency).length !== 0  && $.trim(node.fcounter).length !== 0 &&
               node.newrow === true && node.active === 0){
            node.active = 1;
          }
          return node;
        });
      };

    scope.$watch(function() {
        return scope.gridOtherTaskData;
      }, function(newValue) {
          scope.taskPersistedData.othertasks = newValue;
          scope.refreshState();
        },true);

    scope.init = function () {
      scope.hideNotifications();
      if (scope.initializeStep) {
        scope.initializeStep('otherTasks', false);
      }
      //var staticApiData = scope.$parent.$parent.$parent.$parent.taskBundleData;
      scope.otherTaskSeedData = angular.extend(scope.otherTaskSeedData, scope.taskBundleData);
    };


    scope.addRow = function (id) {
      localStorage.setItem('isWizardFormDirty', true);
      var selectedNames = _.where(scope.gridOtherTaskData,{taskname: scope.gridOtherTaskData[id].taskname, recurrence:scope.gridOtherTaskData[id].recurrence, frequency: scope.gridOtherTaskData[id].frequency, fcounter: scope.gridOtherTaskData[id].fcounter});
      if (scope.gridOtherTaskData[id].newrow === true && scope.gridOtherTaskData[id].active === 1) {
        if (selectedNames.length > 1) {
          scope.ShowNotifications('Task name already exists. Please enter a different name', 'alert-error');
          scope.completeStep(false, 'otherTasks');
          return false;
        }
        scope.gridOtherTaskData[id].newrow = false;
        scope.gridOtherTaskData.push({ id: scope.gridOtherTaskData.length + 1, taskname: '', recurrence: '', frequency: '', fcounter: '', newrow: true, active: 0, state: 'create' });
      } else if (scope.gridOtherTaskData[id].newrow === false) {
        scope.gridOtherTaskData = scope.gridOtherTaskData.filter(function (node, idx) {
          if (id !== idx) {
            return true;
          } else if (node.state === 'edit') {
            scope.taskDeletedData.othertasks.push(node);
          }
        });
        scope.taskPersistedData.othertasks = scope.gridOtherTaskData;
        scope.checkValidation();
      }
    };

    scope.$watch('taskOthers.$valid', function (val) {
      scope.showValidationNote = true;
      if (state.current.name === 'otherTasks'){
        localStorage.setItem('isWizardFormDirty', true);
      }

      if (state.current.name === 'otherTasks' && scope.isCriteriaStepComplete()) {
        scope.completeStep(val, 'otherTasks');
        scope.checkValidation();
        scope.showValidationNote = false;
      }
    });

    scope.$watch('taskPersistedData.othertasks.length', function () {

      scope.showValidationNote = true;

      if (state.current.name === 'otherTasks' && scope.isCriteriaStepComplete() ) {
        scope.completeStep(true, 'otherTasks');
        scope.showValidationNote = false;
        if (_.filter(scope.taskPersistedData.education, function (item) { return (item.eduName === undefined || item.eduName === '' && item.newrow === false); }).length > 0 || _.filter(scope.taskPersistedData.othertasks, function (item) { return (item.taskname === undefined || item.taskname === '' && item.newrow === false); }).length > 0) {
          scope.setStepSummaryClickable();
        } else {
          scope.setStepSummaryClickable();
        }
      }else{
        scope.completeStep(false, 'otherTasks');
        scope.setStepSummaryClickable();
        scope.tabDefinitions[2].clickable = false;
      }
      scope.checkValidation();
    });

    scope.$on('wizardOnClose', function() {
      taskBundleStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {
        location.url(app.currentRoute);
      }
      else{
        location.url('/admin/taskbundle');
      }
    });

    scope.checkValidation = function(id) {
      var emptyTaskName = _.where(scope.gridOtherTaskData,{taskname:undefined,newrow:false});
      if(emptyTaskName.length>0){
        scope.completeStep(false, 'otherTasks');
        return false;
      }
      if(id){
        if(scope.gridOtherTaskData[id].newrow === false){
          var selectedNames = _.where(scope.gridOtherTaskData,{taskname: scope.gridOtherTaskData[id].taskname, recurrence:scope.gridOtherTaskData[id].recurrence, frequency: scope.gridOtherTaskData[id].frequency, fcounter: scope.gridOtherTaskData[id].fcounter});
          if (selectedNames.length > 1) {
            scope.ShowNotifications('Task name already exists. Please enter a different name', 'alert-error');
            scope.completeStep(false, 'otherTasks');
          }
          else{
            scope.completeStep(true, 'otherTasks');
          }
        }
        
      }
      else {
        var duplicateOtherTasks = _.groupBy(scope.gridOtherTaskData, function(item) {
          return item.taskname+ '-' + item.recurrence+ '-' + item.frequency+ '-' + item.fcounter;
        });
        _.forEach(duplicateOtherTasks, function(items) {
          if (items.length > 1) {
            scope.ShowNotifications('Task name already exists. Please enter a different name', 'alert-error');
            scope.completeStep(false, 'otherTasks');
          }
          else{
            scope.completeStep(((items.length > 1) ? false : true), 'otherTasks');
          }
          return false;
        });
      }
    };

  }]);
}(window.app));
