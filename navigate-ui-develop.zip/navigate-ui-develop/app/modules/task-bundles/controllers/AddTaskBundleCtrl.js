(function (app) {
  'use strict';

  app.controller('AddTaskBundleCtrl', ['$scope', '$state', 'taskBundleStateSvc', '$location', 'PatientData', '$modal', '_', '$rootScope',
      function (scope, state, taskBundleStateSvc, location, patientData, $modal, _, $rootScope) {
        patientData.id = app.routing.routeParams.patientId;
        patientData.isTaskAddedSuccesfully = false;
                
        scope.editTaskBundle.id = localStorage.getItem('taskBundleId');
        scope.editTaskBundle.isEdit = localStorage.getItem('isTaskBundleEdit');
        scope.editTaskBundle.isEditStatus = localStorage.getItem('isTaskBundleEdit');

        scope.isSaveAsDraftDisabled = false;
        scope.hideSaveAsDraft = false;
        scope.isSaveDisabled  = true;

        if(scope.editTaskBundle.id > 0){
          scope.taskBundleHeader = 'Edit Task Bundle';

        }else{
          scope.taskBundleHeader = 'Add Task Bundle';
        }

        localStorage.removeItem('taskBundleId');
        localStorage.removeItem('isTaskBundleEdit');

        scope.model = {
          routeParams: {}
        };

        scope.wizardWorkflow = [
            { 'id': 1, 'name': 'generalInformation' },
            { 'id': 2, 'name': 'procedures' },
            { 'id': 3, 'name': 'assessments' },
            { 'id': 4, 'name': 'educationMaterials' },
            { 'id': 5, 'name': 'otherTasks' },
            { 'id': 6, 'name': 'summary' }
          ];

        scope.tabDefinitions = [
          { name: 'generalInformation', number: '1', title: 'General Information', selectionCss: 'first active', completed: false, clickable:false, isTabCompleted:false  },
          { name: 'procedures', number: '2', title: 'Define Criteria', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false  },
          { name: 'summary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false  }
        ];

        scope.stepDefinitions = [
          [
            { name: 'generalInformation', letter: 'a', title: 'General Information', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false  }
          ],
          //Select Ideal Target task type Tab
          [
            { name: 'procedures', letter: 'a', title: 'Procedures', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false  },
            { name: 'assessments', letter: 'b', title: 'Assessments', selectionCss: 'active', completed: true, clickable:true, isTabCompleted:false  },
            { name: 'educationMaterials', letter: 'c', title: 'Education Materials', selectionCss: 'active', completed: true, clickable:false, isTabCompleted:false  },
            { name: 'otherTasks', letter: 'd', title: 'Other Tasks', selectionCss: 'active', completed: true, clickable:true, isTabCompleted:false  }
          ],
          [
            { name: 'summary', letter: 'a', title: 'Summary', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false  }
          ]
        ];

        var proceedWithDuplicates = false;
        var nextDesiredState = null;

        scope.checkForDuplicateTasks = function() {
          if (currentStepHasDuplicateTaskNames() && !proceedWithDuplicates) {
            scope.confirmDuplicateTasksModal = $modal.open({
              templateUrl: 'confirmDuplicateTasks.html',
              scope: scope,
              backdrop: 'static',
              keyboard: false,
              action: 'show'
            });
            return false;
          }
          return true;
        };

        scope.confirmDuplicateTasks = function(proceed) {
          if (scope.confirmDuplicateTasksModal) {
            scope.confirmDuplicateTasksModal.close();
          }
          proceedWithDuplicates = proceed;
          if (proceedWithDuplicates) {
            if (nextDesiredState) {
              state.go(nextDesiredState);
            } else {
              var steps = scope.stepDefinitions[1];
              var nextStep;
              var currentStepIndex = _.findIndex(steps, {
                name: state.current.name
              });
              if (currentStepIndex === steps.length - 1) {
                nextStep = 'summary';
              } else {
                nextStep = steps[currentStepIndex + 1].name;
              }
              state.go(nextStep);
            }
            scope.$broadcast('wizardOnNext');
            proceedWithDuplicates = false;
          }
        };

        function currentStepHasDuplicateTaskNames() {
          var names;
          switch (state.current.name) {
            case 'procedures':
              names = _.pluck(_.filter(scope.taskPersistedData.procedures, {
                newrow: false
              }), 'procedurename');
              break;
            case 'assessments':
              names = _.pluck(_.filter(scope.taskPersistedData.assessments, {
                newrow: false
              }), 'assessmentname');
              break;
            case 'educationMaterials':
              names = _.pluck(_.filter(scope.taskPersistedData.education, {
                newrow: false
              }), 'eduName');
              break;
            case 'otherTasks':
              names = _.pluck(_.filter(scope.taskPersistedData.othertasks, {
                newrow: false
              }), 'taskname');
              break;
            default:
              names = [];
              break;
          }
          names = _.map(names, function(n) {
            return n.toLowerCase();
          });
          var grouped = _.groupBy(names, function(n) {
            return n;
          });
          return _.some(_.values(grouped), function(a) {
            return a.length > 1;
          });
        }

        scope.isCriteriaStepComplete = function(){
          
          if(scope.taskPersistedData.procedures){
            if(scope.taskPersistedData.procedures.length > 1){
              return true;
            }
          }
          if(scope.taskPersistedData.assessments){
            if(scope.taskPersistedData.assessments.length > 1){
              return true;
            }
          }
          if(scope.taskPersistedData.education){
            if(scope.taskPersistedData.education.length > 1){
              return true;
            }
          }
          if(scope.taskPersistedData.othertasks){
            if(scope.taskPersistedData.othertasks.length > 1){
              return true;
            }
          }
        };

        scope.setStepSummaryClickable = function(){
          //The requiremnt of Taskbundle Criteria Steps is, Summary should be 
          //clickable if any of the task is added.. we have written this custom code to make summary step clickable
          //as wizard directive does not take care of this condition.          
          for(var a = 0; a < scope.stepDefinitions[1].length; a=a+1)
          {
            if(scope.stepDefinitions[1][a].isTabCompleted)
            {
              scope.stepDefinitions[1][a].clickable = true;
            }
            else if (scope.stepDefinitions[1][a-1].isTabCompleted)
            {
              scope.stepDefinitions[1][a].clickable = true;
            }
          }
        };
        
        scope.$on('setSaveDisabled', function(event, flag) {
          scope.isSaveDisabled  = flag;
          event.stopPropagation();
        });

        scope.$on('setSaveAsDraftDisabled', function(event, flag) {
          scope.isSaveAsDraftDisabled = flag;
          event.stopPropagation();
        });

        $rootScope.$on('$stateChangeStart', function(event, toState) {
          var isStateChange = true;
          if(scope.taskPersistedData.othertasks !== null && scope.taskPersistedData.othertasks.length > 0)
          {
            var other = _.filter(scope.taskPersistedData.othertasks, {
                newrow: false
              });
            if(other !== null && other.length > 0)
            {
              var duplicateTasks = _.groupBy(other, function(item) {
                return item.taskname+ '-' + item.recurrence+ '-' + item.frequency+ '-' + item.fcounter;
              });
              _.forEach(duplicateTasks, function(items) {
                if (items.length > 1) {
                  isStateChange = false;
                }
              });
            }
          }
          if(isStateChange)
          {
            var shouldProceed = scope.checkForDuplicateTasks();
            if (!shouldProceed) {
              nextDesiredState = toState;
              event.preventDefault();
            }
          }
          else
          {
            scope.ShowNotifications('Task name already exists. Please enter a different name', 'alert-error');
            event.preventDefault();
          }
        });

      }]);
})(window.app);
