(function (app) {
  'use strict';

  app.controller('ProcedureBundleCtrl', ['$scope','$state','taskBundleStateSvc', '$location', function (scope,state,taskBundleStateSvc,location) {
    scope.welcomeText = 'Patients';

    scope.totalServerItems = 0;
    scope.pagingOptions = {
      pageSizes: [5, 10, 15],
      pageSize: 10,
      currentPage: 1
    };


    scope.taskSeedData = {
      'recurrence': [{ id: 'One Time', name: 'One Time' }, { id: 'Recurring', name: 'Recurring' }],
      'frequency': [{ id: 'Day(s)', name: 'Day(s)' }, { id: 'Week(s)', name: 'Week(s)' }, { id: 'Month(s)', name: 'Month(s)' }, { id: 'Years(s)', name: 'Year(s)' }],
      'fcounter': Array.apply(0, new Array(100)).map(function (n, i) { return (i + 1); })
    };

    scope.checkPersistedData = function(persistedData){
      if(persistedData && persistedData.length >= 1){
        return persistedData;
      }else{
        return false;
      }
    };

    scope.gridProcedureData = scope.checkPersistedData(scope.taskPersistedData.procedures) ||  [
      {id: '0', procedurename: '', recurrence: '', frequency: '',fcounter:'',newrow:true, active: 0}
    ];

    scope.refreshState = function(){
        scope.gridProcedureData = scope.gridProcedureData.map(function(node){
          if( $.trim(node.procedurename).length !== 0 && $.trim(node.recurrence).length !== 0  &&
              $.trim(node.frequency).length !== 0  && $.trim(node.fcounter).length !== 0 && node.newrow === true && node.active === 0){
            node.active = 1;
          }
          return node;
        });
      };

    scope.$watch(function() {
        return scope.gridProcedureData;
      }, function(newValue) {
          scope.taskPersistedData.procedures = newValue;
          scope.refreshState();
        },true);

    scope.init = function () {
      scope.hideNotifications();
      if (scope.initializeStep) {
        scope.initializeStep('procedures', false);
      }
      //var staticApiData = scope.$parent.$parent.$parent.$parent.taskBundleData;
      scope.taskSeedData = angular.extend(scope.taskSeedData, scope.taskBundleData);
    };

    scope.addProcedure = function (id) {
      localStorage.setItem('isWizardFormDirty', true);
      var selectedProcs = _.where(scope.gridProcedureData,{procedurename: scope.gridProcedureData[id].procedurename, recurrence:scope.gridProcedureData[id].recurrence, frequency: scope.gridProcedureData[id].frequency, fcounter: scope.gridProcedureData[id].fcounter});
      if (scope.gridProcedureData[id].newrow === true && scope.gridProcedureData[id].active === 1) {
        if (selectedProcs.length > 1) {
          scope.ShowNotifications('Procedure name already exists. Please enter a different name', 'alert-error');
          scope.completeStep(false, 'procedures');
          return false;
        }
        scope.gridProcedureData[id].newrow = false;
        scope.gridProcedureData.push({ id: scope.gridProcedureData.length + 1, procedurename: '', recurrence: '', frequency: '', fcounter: '', newrow: true, active: 0, state: 'create' });
      } else if (scope.gridProcedureData[id].newrow === false) {
        scope.gridProcedureData = scope.gridProcedureData.filter(function (node, idx) {
          if (id !== idx) {
            return true;
          } else if (node.state === 'edit') {
            scope.taskDeletedData.procedures.push(node);
          }
        });
        scope.taskPersistedData.procedures = scope.gridProcedureData;
        scope.checkValidation();
      }
    };
   
    scope.$watch('taskProcedure.$valid', function (val) {
      
      if (state.current.name === 'procedures') {
        localStorage.setItem('isWizardFormDirty', true);
        scope.completeStep(val, 'procedures');
      }
    });

    scope.$watch('taskPersistedData.procedures.length', function () {

      if( scope.isCriteriaStepComplete()){
        if (_.filter(scope.taskPersistedData.education, function (item) { return (item.eduName === undefined || item.eduName === '' && item.newrow === false); }).length > 0 || _.filter(scope.taskPersistedData.othertasks, function (item) { return (item.taskname === undefined || item.taskname === '' && item.newrow === false); }).length > 0) {
          scope.setStepSummaryClickable();
        }
        scope.tabDefinitions[2].clickable = scope.tabDefinitions[2].isTabCompleted;
      }else{
        scope.setStepSummaryClickable();
        scope.tabDefinitions[2].clickable = false;
      }
      scope.checkValidation();
    });

    scope.$on('wizardOnClose', function() {
      taskBundleStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {
        location.url(app.currentRoute);
      }
      else{
        location.url('/admin/taskbundle');
      }
    });

    scope.checkValidation = function(id) {
      if(id){
        if(scope.gridProcedureData[id].newrow === false){
          var selectedProcs = _.where(scope.gridProcedureData,{procedurename: scope.gridProcedureData[id].procedurename, recurrence:scope.gridProcedureData[id].recurrence, frequency: scope.gridProcedureData[id].frequency, fcounter: scope.gridProcedureData[id].fcounter});
          if (selectedProcs.length > 1) {
            scope.ShowNotifications('Procedure name already exists. Please enter a different name', 'alert-error');
            scope.completeStep(false, 'procedures');
          }
          else{
            scope.completeStep(true, 'procedures');
          }
        }
      }
      else {
        var duplicateProcedure = _.groupBy(scope.gridProcedureData, function(item) {
          return item.procedurename+ '-' + item.recurrence+ '-' + item.frequency+ '-' + item.fcounter;
        });
        _.forEach(duplicateProcedure, function(items) {
          if (items.length > 1) {
            scope.ShowNotifications('Procedure name already exists. Please enter a different name', 'alert-error');
            scope.completeStep(false, 'procedures');
          }
          else{
            scope.completeStep((items.length > 1 ? false : true), 'procedures');
          }
          return false;
        });
      }
    };

  }]);
}(window.app));
