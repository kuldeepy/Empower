﻿(function (app) {
  'use strict';

  app.controller('TaskBundlesCtrl', ['$scope', '$http','taskBundleStateSvc','authSvc','homeURL','$location', '$state',
    function (scope, http,taskBundleStateSvc,authSvc,homeURL,location,state) {

    scope.welcomeText = 'Patients';
    scope.pageTitle = 'Task Bundle';
    scope.totalServerItems = 0;
    scope.taskBundleHeader = 'Add Task Bundle';


    scope.pagingOptions = {
      pageSizes: [5, 10, 15],
      pageSize: 10,
      currentPage: 1
    };

    scope.searchIsOpen = true;
    scope.taskBundleGridData =[];
    scope.isOpen = true;
    scope.user = authSvc.user();
    scope.user.backURL = '';

    scope.gridProcedure = {
      data: 'gridProcedureData',
      multiSelect: false,
      showFooter: true,
      enablePaging: true,
      totalServerItems: 'totalServerItems',
      pagingOptions: scope.pagingOptions,
      filterOptions: scope.filterOptions,
      columnDefs: 'ProcedureColumnsS'
    };

    scope.taskBundledata = {
      status: 'Active',
      production: 'All',
      taskBundleName: '',
      description: ''
    };

    scope.columnsSelected = [{ field: 'name', displayName: 'Task Bundle Name', columnClass: 'table-column-name' }, { field: 'description', displayName: 'Description', columnClass: 'table-column-assessment-description' }, { field: 'productionStatus', displayName: 'Production', columnClass: 'table-column-assessment-status' }, { field: 'status', displayName: 'Status', columnClass: 'table-column-status', sortable: false }, { field: 'lastUpdated', displayName: 'Last Updated', columnClass: 'table-column-date' }, { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false }];

    scope.gridProcedureData = [
      {id: '1', procedurename: '', recurrence: '', frequency: ''}
    ];

    scope.ProcedureColumnsS = [
      {
        field: 'id',
        displayName: 'id',
        visible: false
      },
      {
        field: 'procedurename',
        displayName: 'Procedure Name',
        width: '30%',
        cellTemplate: '<div class="ngCellText">' +
          '<select style="width: 125px"><option value=""></option><option value="1">1</option></select>'+
          '</div>'
      },
      {
        field: 'recurrence',
        displayName: 'Recurrence',
        width: '28%',
        cellTemplate: '<div class="ngCellText">' +
         '<select style="width: 125px;"><option value=""></option><option value="Recurring">Recurring</option></select>'+
          '</div>'

      },
      {
        field: 'frequency',
        displayName: 'Frequency',
        width: '30%',
        cellTemplate: '<div class="ngCellText">' +
          '<select class="dropdown-toggle" style="width: 55px;"><option value="">'+
          '</option><option value="1">1</option><option value="2">2</option>'+
          '<option value="3">3</option><option value="4">4</option><option value="5">5</option>'+
          '<option value="6">6</option><option value="7">7</option><option value="8">8</option>'+
          '<option value="9">9</option><option value="10">10</option><option value="11">11</option>'+
          '<option value="12">12</option></select>'+
          '<select style="width: 65px;"><option value=""></option><option value="Months">Months</option><option value="Years">Years</option></select>'+
          '</div>'
      },
      {
        field: 'action',
        displayName: 'Action',
        width: '10%',
        cellTemplate: '<div class="ngCellText">' +
          '<button type="button" class="cursor-pointer taskBundleAdd" ng-click="addProcedure(row.entity);" tooltip="Add procedure">'+
          '<span class="General-icon_add_6fa8dc_30x30"> <span class="border"></span> <span class="visually-hidden">Add procedure</span> </span>' +
          '</button>' +
          '</div>'
      }
    ];

    scope.searchTaskBundle = function(){
      var productionStatus = '';

      scope.user.backURL = homeURL.getURL(scope.user.role);
      if (scope.taskBundledata.production === 'All') {
        productionStatus = '';
      }
      else {
        productionStatus = scope.taskBundledata.production;
      }

      var taskBundleName = window.encodeURIComponent(scope.taskBundledata.taskBundleName);
      var taskBundleDesc = window.encodeURIComponent(scope.taskBundledata.description);

      var getUrl = app.api.root + 'task-bundles?name=' + taskBundleName + '&description=' + taskBundleDesc + '&statusCode=' + scope.taskBundledata.status + '&productionStatus=' + productionStatus;
      http({
        method: 'GET',
        url: getUrl
      })
      .success(function (data) {
        scope.taskBundleGridData = data.results;
        scope.taskBundleGridData.forEach(function(item){
          item.lastUpdated = item.lastUpdated ? item.lastUpdated : item.createdDate;
        });
        scope.pagingOptions.currentPage = 1;
      });
    };

    scope.addTaskBundle = function (id) {

      localStorage.setItem('taskBundleId',  id ? id : 0);
      localStorage.setItem('isTaskBundleEdit', id ? true : false);
      taskBundleStateSvc.clear();
      scope.clearTaskPersistedData();

      if(id > 0 ){
        scope.summaryState.state = 1;
        state.go('summary');
      }

      location.url(app.currentRoute +'/add');

    };

    scope.clearTaskPersistedData = function () {
      // scope.taskPersistedData = {} will create a local scope object
      // and won't clear actual data
      scope.taskPersistedData.assessments = null;
      scope.taskPersistedData.procedures = null;
      scope.taskPersistedData.othertasks = null;
      scope.taskPersistedData.education = null;
      scope.taskPersistedData.generic = null;

      scope.taskPersistedData.generic = { 'status' : 'Active'};
    };

    scope.addProcedure = function(){
      scope.gridProcedureData.push({id: '1', procedurename: '', recurrence: '', frequency: ''});
    };

    scope.clearTaskBundle = function(){
      scope.taskbundleform.$setPristine();
      scope.taskBundledata.status = 'Active';
      scope.taskBundledata.production = 'All';
      scope.taskBundledata.taskBundleName = '';
      scope.taskBundledata.description = '';
      scope.searchTaskBundle();
    };

  }]);

}(window.app));
