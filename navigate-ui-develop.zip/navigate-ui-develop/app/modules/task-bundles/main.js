﻿(function (app) {
  'use strict';

  /* module root controller */
  var modulePath = 'modules/task-bundles';

  app.controller('TaskBundlesMainCtrl', ['$scope', '$timeout','$q','taskBundleDataSvc', function (scope,timeout,q,taskBundleDataSvc) {
    scope.model = {
      routeParams: {}
    };

    scope.eduBundleGrid = [
      {}
    ];

    scope.editTaskBundle = {
      'id': 0,
      'isEdit': false,
      'isSaveAsDraft': false
    };

    scope.header = {
      contentHeader: 'Add Task Bundle',
      isLeftTabVisible: true
    };

    scope.isError = false;

    scope.eduBundleGrid[0].lstSelectedDoc = [];
    
    scope.taskBundleData = {
      'assessments':null,
      'procedures':null,
      'documents':null
    };

    scope.taskPersistedData = {
      'assessments':null,
      'procedures':null,
      'othertasks':null,
      'education':null,
      'generic':
      {
        'id': null,
        'name': null,
        'description': null,
        'productionStatus': null,
        'status': 'Active'
      }
    };
    
    scope.taskBundleResult = {};
    scope.taskDeletedData = {
      'assessments':[],
      'procedures':[],
      'othertasks':[],
      'education':[]
    };

    scope.summaryState = {
      state: 1
    };

    scope.editViewDataBuildUp = function(taskBundleResponseData){
      var getTaskTypeCount = function(taskBundleArray,taskType){

        return taskBundleArray.filter(function(val){
          return val.type === taskType;
        }).length;

      };

      var taskTypeCounts = {
        'othertasks' : getTaskTypeCount(taskBundleResponseData.results.criterias,'Task'),
        'education'  : getTaskTypeCount(taskBundleResponseData.results.criterias,'EducationalMaterial'),
        'assessments': getTaskTypeCount(taskBundleResponseData.results.criterias,'Assessment'),
        'procedures' : getTaskTypeCount(taskBundleResponseData.results.criterias,'Procedure')
      };

      scope.taskPersistedData.generic = {
        'id':taskBundleResponseData.results.id || null,
        'name':taskBundleResponseData.results.name || null,
        'description':taskBundleResponseData.results.description || null,
        'productionStatus':taskBundleResponseData.results.productionStatus || null,
        'status': taskBundleResponseData.results.status === 'A' ? 'Active' : 'Inactive'
      };
      scope.isSaveAsDraftDisabled = scope.taskPersistedData.generic.productionStatus === 'Final';
      angular.forEach(taskBundleResponseData.results.criterias, function(node) {
        switch ($.trim(node.type)) {
          case 'Task':
            scope.taskPersistedData.othertasks = scope.taskPersistedData.othertasks || [];
            scope.taskPersistedData.othertasks.push([node].map(function(nd){
                return {
                  id: nd.id,
                  taskname: nd.typeName,
                  recurrence: nd.recurrence,
                  frequency: nd.frequencyUnits,
                  fcounter: nd.frequencyCount || 0,
                  newrow:false,
                  active: 1,
                  state:'edit'
                };
              })[0]);
            break;
          case 'EducationalMaterial':
            scope.taskPersistedData.education = scope.taskPersistedData.education || [];
            scope.taskPersistedData.education.push([node].map(function(nd){
              //nd.typeId = 4;
              //nd.typeId = ((nd.typeId.toString() === '10') ? 4 : node.typeId);
              //nd.typeId = ((nd.typeId.toString() === '11') ? '5,4' : node.typeId);              
              return {
                id: nd.id,
                eduName: nd.typeName,
                lstSelectedDoc:nd.typeId.toString().split(/,/).map(function(elm){
                    return scope.taskBundleData.documents.filter(function(elm1){
                              return parseInt(elm1.id) === parseInt(elm);
                            })[0];
                  }),
                eduBundleList: null,
                fcounter: 0,
                newrow:false,
                active: 1,
                state:'edit'
              };
            })[0]);
            break;
          case 'Assessment':
            scope.taskPersistedData.assessments = scope.taskPersistedData.assessments || [];
            scope.taskPersistedData.assessments.push([node].map(function(nd){
              return {
                id: nd.id,
                assessmentname: nd.typeId,
                recurrence: nd.recurrence,
                frequency: nd.frequencyUnits,
                fcounter: nd.frequencyCount || 0,
                newrow:false,
                active: 1,
                state:'edit'
              };
            })[0]);
            break;
          case 'Procedure':
            scope.taskPersistedData.procedures = scope.taskPersistedData.procedures || [];
            scope.taskPersistedData.procedures.push([node].map(function(nd){
              return {
                id: node.id,
                procedurename: nd.typeId,
                recurrence: nd.recurrence,
                frequency: nd.frequencyUnits,
                fcounter: nd.frequencyCount || 0,
                newrow:false,
                active: 1,
                state:'edit'
              };
            })[0]);
            break;
          default:
            //document.write("Sorry, we are out of " + expr + ".<br>");
        }
      });

      if(taskTypeCounts.othertasks >= 1){
        scope.taskPersistedData.othertasks[taskTypeCounts.othertasks] = {id:taskTypeCounts.othertasks, taskname: '', recurrence: '', frequency: '',fcounter:'',newrow:true, active: 0, state:'create'};
      }
      if(taskTypeCounts.education >= 1){
        scope.taskPersistedData.education[taskTypeCounts.education] = {id: taskTypeCounts.education, eduName: '', eduBundleList: '',fcounter:'',newrow:true,active: 0,state:'create'};
      }
      if(taskTypeCounts.assessments >= 1){
        scope.taskPersistedData.assessments[taskTypeCounts.assessments] = {id: taskTypeCounts.assessments, assessmentname: '', recurrence: '', frequency: '',fcounter:'',newrow:true, active: 0, state:'create'};
      }
      if(taskTypeCounts.procedures >= 1){
        scope.taskPersistedData.procedures[taskTypeCounts.procedures] = { id: taskTypeCounts.procedures, procedurename: '', recurrence: '', frequency: '', fcounter: '', newrow: true, active: 0, state:'create'};
      }
    };

    //recurrence: '', frequency: '',fcounter
    scope.createApiData = function(mode,prodStatus){

      var allFinalBundleData = [],
          finalAssessmentsData = [],
          finalProceduresData = [],
          finalOtherTasksData = [],
          finalEducationData = [],
          allFinalBundle = {};

      var taskWorkingData = ((mode === 'delete') ? scope.taskDeletedData : scope.taskPersistedData);
      //var taskWorkingData = scope.taskPersistedData;

      if(taskWorkingData.assessments !== null){
        finalAssessmentsData = taskWorkingData.assessments.map(function (node) {

          if (node.active && !node.newrow) {
            var newNode = {
              'id': ((mode === 'create') || (node.state === 'create') ? 0 : node.id),
              'typeId': node.assessmentname,
              'typeName': null,
              'type': 'Assessment',
              'recurrence': node.recurrence,
              'frequencyCount': node.fcounter || 0,
              'frequencyUnits': node.frequency,
              'status': ((mode === 'delete') ? 'I' : 'A'),
              'comments': ''
            };
            return newNode;
          }
        });
      }

      if(taskWorkingData.procedures !== null){
        finalProceduresData = taskWorkingData.procedures.map(function (node) {
          if (node.active && !node.newrow) {
            var newNode = {
              'id': ((mode === 'create') || (node.state === 'create') ? 0 : node.id),
              'typeId': node.procedurename,
              'typeName': null,
              'type': 'Procedure',
              'recurrence': node.recurrence,
              'frequencyCount': node.fcounter || 0,
              'frequencyUnits': node.frequency,
              'status': ((mode === 'delete') ? 'I' : 'A'),
              'comments': ''
            };
            return newNode;
          }
        });
      }

      if(taskWorkingData.othertasks !== null){
        finalOtherTasksData = taskWorkingData.othertasks.map(function (node) {
          if (node.active && !node.newrow) {
            var newNode = {
              'id': ((mode === 'create') || (node.state === 'create') ? 0 : node.id),
              'typeName': node.taskname,
              'type': 'Task',
              'recurrence': node.recurrence,
              'frequencyCount': node.fcounter || 0,
              'frequencyUnits': node.frequency,
              'status': ((mode === 'delete') ? 'I' : 'A'),
              'comments': ''
            };
            return newNode;
          }
        });
      }
      if(taskWorkingData.education !== null){
        finalEducationData = taskWorkingData.education.map(function (node) {
          if (node.active && !node.newrow) {
            var ids = '';
            if (node.lstSelectedDoc && node.lstSelectedDoc[0] !== undefined && node.lstSelectedDoc.length >= 1) {
              ids = node.lstSelectedDoc.map(function (elm) {
                return elm.id;
              }).join(',');
            }

            var newNode = {
              'id': ((mode === 'create') || (node.state === 'create') ? 0 : node.id),
              /*'typeId':node.id,*/
              'typeId': ids,
              'typeName': node.eduName,
              'type': 'EducationalMaterial',
              'recurrence': null,
              'frequencyCount': 0,
              'frequencyUnits': null,
              'status': ((mode === 'delete') ? 'I' : 'A'),
              'comments': ''
            };
            return newNode;
          }
        });
      }
      angular.forEach(finalAssessmentsData, function (node) {
        // check node is null or undefined
        if (node) {
          allFinalBundleData.push(node);
        }
      });

      angular.forEach(finalProceduresData, function (node) {
        // check node is null or undefined
        if (node) {
          allFinalBundleData.push(node);
        }
      });

      angular.forEach(finalOtherTasksData, function (node) {
        // check node is null or undefined
        if (node) {
          allFinalBundleData.push(node);
        }
      });

      angular.forEach(finalEducationData, function (node) {
        // check node is null or undefined
        if (node) {
          allFinalBundleData.push(node);
        }
      });
      
      if(mode === 'delete'){
        return allFinalBundleData;

      }else{
        
        allFinalBundle.id = ((mode === 'create') ? null : scope.editTaskBundle.id);
        allFinalBundle.name = scope.taskPersistedData.generic.name;
        if( scope.taskPersistedData.generic.description !== null){
          allFinalBundle.description =  scope.taskPersistedData.generic.description;
        }else{
          allFinalBundle.description = '';
        }
        allFinalBundle.productionStatus =  scope.taskPersistedData.generic.productionStatus;
        allFinalBundle.status = scope.taskPersistedData.generic.status === 'Inactive' ? 'I' : 'A';
        allFinalBundle.productionStatus = prodStatus;
        allFinalBundle.criterias =  allFinalBundleData;
        return allFinalBundle;
      }
    };

    scope.errorMessage = 'Unfortunately, we are not able to process your request at this time. Please try again later or contact your system administrator if this continues.';

    /* display error message if failed to get the data from api*/
    scope.ShowNotifications = function (errorMsg, style,timer) {
      window.scrollTo(0, 0);
      scope.alertMessageStyle = style;
      scope.alertMessage = errorMsg;
      scope.isError = true;
      scope.isSuccessMsg = style === 'alert-success' ? true : false;
      timer = timer === undefined ? true : false;
      if(timer){
        timeout(function () {
          scope.isError = false;
        }, 6000);
      }
    };

    scope.hideNotifications = function () {
      scope.isError = false;
    };
      /* display success message*/
    scope.ShowSuccessNotifications = function (errorMsg, style) {
        window.scrollTo(0, 0);
        scope.alertSuccessMessageStyle = style;
        scope.alertSuccessMessage = errorMsg;
        scope.isErrorAlert = true;
        scope.isSuccessMsg = style === 'alert-success' ? true : false;
        timeout(function () {
            scope.isErrorAlert = false;
          }, 6000);
      };
    taskBundleDataSvc.getStaticData('procedures')
      .then(function(data) {
          if (data) {
            scope.taskBundleData.procedures = data;
          }
        }, function() {
          ////function(error)   
          //Error handler if needed;
    });

    taskBundleDataSvc.getStaticData('assessments')
      .then(function(data) {
          if (data) {
            scope.taskBundleData.assessments = data;
          }
        }, function() {
          //function(error) 
          //Error handler if needed;
    });

    taskBundleDataSvc.getStaticData('documents')
      .then(function(data) {
          if (data) {
            scope.taskBundleData.documents = data;
          }
        }, function() {
          //function(error) 
          //Error handler if needed;
    });
  }]);

  /* load required controllers */
  $.when(
	$.getScript('/modules/patient/controllers/PatientCtrl.js'),
  $.getScript('/modules/administrator/controllers/administratorCtrl.js')
  ).done(function () {
    app.publish('moduleReady', modulePath);
  });

}(window.app));