(function (app) {
  'use strict';
  app.controller('EventNotificationMainCtrl', ['$scope', 'adtNotificationSvc', '$modal', '$timeout', '$location','authSvc', function (scope, adtNotificationSvc, $modal, $timeout, location,authSvc) {
    scope.model = {
      routeParams: {}
    };
    scope.headerData = [{ 'headerText' : 'Date', 'isOpen':false }, { 'headerText' : 'Event', 'isOpen' : false }, { 'headerText' : 'Facility', 'isOpen' : false }, { 'headerText' : 'Status', 'isOpen' :false }];
    scope.gridHeaders = [
      {
        field: 'status',
        displayName: 'Status',
      },
      {
        field: 'patientName',
        displayName: 'Patient Name',
      },
      {
        field: 'eventDate',
        displayName: 'Date and Time',
      },
      {
        field: 'eventDescription',
        displayName: 'Event',
      },
      {
        field: 'facility',
        displayName: 'Facility',
      }
    ];
    scope.moduleData = {isAllEvents : true, isAllFacility : true, events : [], eventsMaster : [], facility : [], facilityMaster:  []};
    var modalInstance;
    scope.date = {};
    scope.currentDate = moment(new Date ()).format('MM/DD/YYYY');
    scope.adtNotificationDataGridData = [];
    scope.pagingOptionsAdtNotifications = {pageSize : 10,currentPage : 1};
    scope.user = authSvc.user();
    scope.bindFilters = function(){
        adtNotificationSvc.getFiltersRequest().then(function(response){
            scope.moduleData.events = response.data.results.events;
            scope.moduleData.eventsMaster = response.data.results.events;
            scope.moduleData.facility = response.data.results.facilities;
            scope.moduleData.facilityMaster = response.data.results.facilities;
          });
        scope.status = [{ 'id' : 'Complete', 'name' : 'Complete' }, {'id' : 'Pending', 'name' : 'Pending'}];
      };

    scope.bindGrid = function(){
        var data = {'pageIndex' : scope.pagingOptionsAdtNotifications.currentPage, 'pageSize' : scope.pagingOptionsAdtNotifications.pageSize, 'startDate' : (scope.moduleData.dateFrom !== undefined && scope.moduleData.dateFrom !== null) ? moment(scope.moduleData.dateFrom).format('MM-DD-YYYY') : null, 'endDate' : (scope.moduleData.dateTo !== undefined && scope.moduleData.dateTo !== null) ? moment(scope.moduleData.dateTo).format('MM-DD-YYYY') : null, 'events': scope.moduleData.events !== null ? scope.moduleData.events.length !== scope.moduleData.eventsMaster.length ? _.pluck(scope.moduleData.events,'id').join(): null : null, 'facilities' : scope.moduleData.facility !== null ? scope.moduleData.facility.length !== scope.moduleData.facilityMaster.length ? _.pluck(scope.moduleData.facility,'id').join() : null : null, 'status' : (scope.moduleData.status !== undefined && scope.moduleData.status !== null) ? scope.moduleData.status.name : null,'processType':'G'};
        adtNotificationSvc.getNotificationsRequest(data,scope.user.providerId).then(function(response){
            scope.adtNotificationDataGridData = response.data.results.notification;
            scope.totalCount = response.data.results.count;
            scope.getUnreadNotificationCount();
          });
      };

    scope.openDateFromPopout = function(){
        $timeout(function() { scope.date.fromDateopened = true; });
      };

    scope.openDateToPopout = function(){
        $timeout(function() { scope.date.toDateopened = true; });
      };

    scope.changedFilterData = function(){
        scope.pagingOptionsAdtNotifications.currentPage = 1;
        scope.bindGrid();
      };

    scope.deleteNode = function (id, stack) {
        if (stack === 'Events') {
          if(scope.moduleData.events.length > 1) {
            var filteredEvents = scope.moduleData.events.filter(function(node){
              return node.id.toString() !== id.toString();
            });
            if(filteredEvents.length === 0 ){
              filteredEvents =  scope.moduleData.eventsMaster;
            }
            updateFilterEvents(filteredEvents);
          }
        }
        else if (stack === 'Facility') {
          if (scope.moduleData.facility.length > 1) {
            var filteredFacilities = scope.moduleData.facility.filter(function (node) {
              return node.id.toString() !== id.toString();
            });
            if (filteredFacilities.length === 0) {
              filteredFacilities = scope.moduleData.facilityMater;
            }
            updateFilterFacilities(filteredFacilities);
          }
        }
      };

    var updateFilterEvents = function(data){
        scope.moduleData.events = data;
        if (data.length === 0) {
          scope.moduleData.isAllEvents = true;
        }
        else if (scope.moduleData.eventsMaster.length !== data.length) {
          scope.moduleData.isAllEvents = false;
        }
        else {
          scope.moduleData.isAllEvents = true;
        }
        scope.changedFilterData(scope.moduleData,'events');
      };

    scope.openFilterSelectModal = function(data) {
        scope.isError = false;
        scope.modalOptions = {};
        scope.modalOptions.events = data.eventsMaster;
        scope.modalOptions.selectedEvents = data.events;
        modalInstance = $modal.open({
          templateUrl: app.root + 'modules/notifications/templates/eventsfilterpopup.html',
          scope : scope,
          backdrop : 'static',
          keyboard: false
        });
      };

    scope.close = function(){
        modalInstance.close();
      };

    scope.save = function (result,name) {
        scope.isError = false;
        if (result.length !== 0) {
          modalInstance.close();
          if(name === 'event'){
            updateFilterEvents(result);
          }
          else{
            updateFilterFacilities(result);
          }
        }
        else {
          scope.alertMessageStyle = 'alert-error';
          scope.alertMessage = 'At least one ' + name + ' should be selected.';
          scope.isError = true;
        }
      };

    var updateFilterFacilities = function(data){
        scope.moduleData.facility = data;
        if (data.length === 0) {
          scope.moduleData.isAllFacility = true;
        }else if (scope.moduleData.facilityMaster.length !== data.length) {
          scope.moduleData.isAllFacility = false;
        } else {
          scope.moduleData.isAllFacility = true;
        }
        scope.changedFilterData(data,'facility');
      };

    scope.openFilterSelectFacilityModal = function(data){
        scope.isError = false;
        scope.modalOptions = {};
        scope.modalOptions.facilities = data.facilityMaster;
        scope.modalOptions.selectedfacilities = data.facility;
        modalInstance = $modal.open({
          'templateUrl': app.root + 'modules/notifications/templates/facilityfilterpopup.html',
          'scope' : scope,
          'backdrop' : 'static',
          keyboard: false
        });
      };

    scope.getUnreadNotificationCount = function () {
        var filters = {'status':'Pending','pageSize': 5,'pageIndex': 1,'processType':'F'};
        adtNotificationSvc.getNotificationsRequest(filters,scope.user.providerId).then(function(response){
          response.data.results.notification =_.forEach(response.data.results.notification,function(item){
            item.color ='info';
            item.img = 'General-icon_check_cccccc_30x30';
            item.eventDate = moment(item.eventDate).fromNow();
          });
          scope.adtNotification.adtNotificationData = response.data.results.notification;
          scope.adtNotification.unreadCount = response.data.results.count;
          scope.adtNotification.totalElements= response.data.results.count;
          scope.adtNotification.dataChunkSize=5;
          scope.adtNotification.dataChunkIndex=1;
        });
      };
    scope.redirectToPatientPage = function(item){
        if(item.readStatus !== 'Complete'){
          var data = {'PatientEventNotificationId':item.patientEventNotificationId};
          adtNotificationSvc.putAdtNotificationRequest(data,scope.user.providerId).then(function(){
            scope.getUnreadNotificationCount();
          });
        }
        location.url('/patients/' + item.patientId);
      };

    scope.redirectToEnrollmentPage = function(item){
      var enrollmentData ={'patientEventId':item.patientEventId,'patientId':item.patientId,'patientProgramID':item.patientProgramID,'programName':item.programName,'programId':item.programId};
      localStorage.setItem('enrollmentData' , JSON.stringify(enrollmentData));
      window.location.href ='/enrollments';
    };

    scope.resetFileds = function(){
        scope.moduleData.dateFrom = null;
        scope.moduleData.dateTo = null;
        scope.moduleData.status = null;
        scope.moduleData.events = scope.moduleData.eventsMaster;
        scope.moduleData.facility = scope.moduleData.facilityMaster;
        scope.moduleData.isAllEvents = true;
        scope.moduleData.isAllFacility = true;
        scope.pagingOptionsAdtNotifications.currentPage = 1;
        scope.headerData = _.forEach(scope.headerData,function(item){
          item.isOpen = false;
        });
        scope.bindGrid();
      };
    scope.bindGrid();
    scope.bindFilters();
  }]);
}(window.app));