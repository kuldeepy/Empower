(function (app) {
    'use strict';

    app.controller('EventNotificationCtrl', ['$scope','authSvc','homeURL','adtNotificationSvc', 'navConstantsSvc', '$location','$filter', 'userConcurrentLockSvc',
        function (scope,authSvc,homeURL,adtNotificationSvc, navConstantsSvc, location, $filter, userConcurrentLockSvc) {
          scope.moduleData = {};
          scope.pageTitle ='My Notifications';
          scope.user = authSvc.user();
          scope.user.backURL = homeURL.getURL(scope.user.role);

          scope.$watch('pagingOptionsAdtNotifications', function (newVal, oldVal) {
            if (newVal !== oldVal) {
              scope.bindGrid();
            }
          }, true);

          scope.class = function(data){
            return data.readStatus === 'Complete'?'General-icon_check_666666_30x30':'General-icon_check_cccccc_30x30';
          };

          scope.changeStatus = function(selectedData){
            var data = {'PatientEventNotificationId':selectedData.patientEventNotificationId,'status':selectedData.readStatus === 'Complete'?1:0 };
            adtNotificationSvc.putAdtNotificationRequest(data,scope.user.providerId).then(function(){
              scope.bindGrid();
            });
          };
          
          scope.redirectToPatientMergePage=function(item){
            adtNotificationSvc.checkMergeNotificationDependencies(item.patientEventId).then(function(response){
              if(response.data.results.length > 0){
                var patientNames = _.pluck(response.data.results,'patientName').join(',');
                scope.lockedText = navConstantsSvc.mergeDependenceMessage.replace('UserName', $filter('isNull')(patientNames));
                scope.isLocked = true;
              }
              else{
                scope.putLockConcurrentTask(item);
              }
            });
          };

          scope.putLockConcurrentTask = function(item){
            scope.data={'patientEventId':item.patientEventId,'lockType':'Notifications'};
            userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(response){
              localStorage.setItem('islockFlag',true);
              scope.status=response.data.results.status;
              if(scope.status === true){
                scope.isLocked = false;
                scope.lockedText = '';
                window.location.href = '/merge/' + item.patientId + '/' + item.patientEventNotificationId;
              }
              else {
                scope.lockedText = navConstantsSvc.lockedMessage.replace('UserName', $filter('isNull')(response.data.results.name));
                scope.isLocked = true;
              }
            });
          };

          scope.unlockConcurrentTask = function() {
            if(location.path().split('/')[1] !== 'patients'){
              scope.data={'lockType':'Notifications'};
              userConcurrentLockSvc.putLockConcurrentTask(scope.data).then(function(){
                scope.isLocked = false;
                scope.lockedText = '';
              });
            }
          };

          scope.resetToolTipText=function(){
            scope.isLocked = false;
          };

          scope.unlockConcurrentTask();
          
        }]);
  }(window.app));