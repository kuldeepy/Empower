(function (app) {
  'use strict';

  app.controller('MapMetricsCtrl', ['$scope','metricsConfigStateSvc','$location', function (scope,metricsConfigStateSvc,location) {
    scope.ngMetricname = true;
    scope.resetDenominator = function () {
      scope.metricData.denominatorId = '';
    };

    scope.checkPersistedData = function (persistedData) {
      if (persistedData && persistedData.length >= 1) {
        return persistedData;
      } else {
        return false;
      }
    };

    scope.init = function () {
      if (scope.initializeStep) {
        scope.initializeStep('metricsConfigMap', false);
      }
      scope.metricOptionsData.numeratorDetails = (
        (scope.metricOptionsData.numeratorDetails && scope.metricOptionsData.numeratorDetails.type) ?
         scope.metricOptionsData.numeratorDetails : { 'type': null, 'numeratorValues': [] }
      );
      scope.$watch('mapMetricsForm.$valid', function(validity) {
          validity = scope.metricData.metricType === 'Outcome Metric'? (scope.metricData.valueAttributeId!== null && scope.metricData.valueAttributeId!== 0)?validity:false:validity;
          scope.checkValueAttribute(validity);
        });
      scope.$watch('mapMetricsForm.$pristine', function () {
        if (scope.mapMetricsForm && !scope.mapMetricsForm.$pristine) {
          localStorage.setItem('isWizardFormDirty', true);
        }
      });
    };
    scope.$watch('metricData.metricType', function (validity) {
      if(scope.metricData.denominatorId !== null &&  scope.metricData.denominatorId !== '' && scope.metricData.denominatorId !== undefined && scope.metricData.denominatorType !== null && scope.metricData.denominatorType !== undefined){
        scope.checkValueAttribute(validity === 'Outcome Metric'?false:true);
      }
    });

    scope.$watch('metricData.valueAttributeId', function () {
        if (scope.metricData.denominatorId !== null && scope.metricData.denominatorId !== '' && scope.metricData.denominatorId !== undefined && scope.metricData.denominatorType !== null && scope.metricData.denominatorType !== undefined && scope.metricData.valueAttributeId !== null) {
          scope.checkValueAttribute(true);
        }
        if (scope.metricData.valueAttributeId === null) {
          scope.checkValueAttribute(false);
        }
      });

    scope.checkValueAttribute = function(validity){
      scope.completeStep(validity,'metricsConfigMap');
    };
    scope.$on('wizardOnClose', function() {
      metricsConfigStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {

        location.url(app.currentRoute);
      }
      else{
        location.url('/admin/metrics');
      }
    });
  }]);
}(window.app));
