(function (app) {
  'use strict';

  app.controller('SummaryMetricsCtrl', ['$scope', '$http','metricsConfigStateSvc','$location','metricsDataSvc',
  function (scope, http,metricsConfigStateSvc,location,metricsDataSvc) {
    scope.init = function () {
      scope.getStaticOptionsData();
      if (scope.initializeStep) {
        scope.initializeStep('metricsConfigSummary', true);
      }
      if (scope.editMetrics.isEdit === 'true' && scope.summaryState.state === 1) {
        scope.header.contentHeader = 'Edit Metric';
        scope.getMetricDetails();
      } else {
        scope.getData();
      }
      if (scope.segmentation.segmentationHashUI !== null) {
        scope.metricData.criterias = [];
        scope.metricData.criterias.push(scope.segmentation.segmentationHashUI.Good);
        scope.metricData.criterias.push(scope.segmentation.segmentationHashUI.Fair);
        scope.metricData.criterias.push(scope.segmentation.segmentationHashUI.Poor);
        scope.mapSegmentRage();
      }
    };

    scope.getData = function () {
      scope.denominatorName = [];
      var numeratorName = [], valueAttributeName = [];
      scope.denominatorName = scope.metricOptionsData.denominatorsM.filter(function (node) {
        if (node.id.toString() === scope.metricData.denominatorId.toString()) {
          return true;
        }
      });

      if (scope.denominatorName.length === 0) {
        scope.denominatorName = scope.metricOptionsData.denominatorsP.filter(function (node) {
          if (node.id.toString() === scope.metricData.denominatorId.toString()) {
            return true;
          }
        });
      }

      scope.metricData.denominatorName = scope.denominatorName[0].name;
      numeratorName = scope.metricOptionsData.numerators.filter(function (node) {
        if (node.id.toString() === scope.metricData.numeratorId.toString()) {
          return true;
        }

      });

      scope.metricData.numeratorName = numeratorName[0].name;
      valueAttributeName = scope.metricOptionsData.numeratorDetails.numeratorValues.filter(function (node) {
        if (node.id.toString() === scope.metricData.valueAttributeId.toString()) {
          return true;
        }
      });

      scope.metricData.valueAttributeName = valueAttributeName[0] ? valueAttributeName[0].name : 'N/A';
    };

    scope.getMetricDetails = function () {
      metricsDataSvc.getMetricDetailsRequest(scope.editMetrics.id)
      .then(function (response) {
        scope.editMetrics.isEdit = 'true';
        scope.summaryState.state = scope.summaryState.state + 1;
        if (response.data.results.status === 'InActive') {
          response.data.results.status = 'Inactive';
        }
        scope.mapTaskIdsToName(response.data.results);
      });
    };
    scope.$on('wizardOnsaveAndClose', function() {
      scope.method = 'POST';
      scope.url = 'metrics/';
      if (scope.editMetrics.isEdit === 'true') {
        scope.method = 'PUT';
        scope.url = scope.url + scope.editMetrics.id;
      }
      scope.apiCall(scope.method, scope.url, scope.metricData);
    });
    scope.$on('wizardOnClose', function() {
      metricsConfigStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {

        location.url(app.currentRoute);
      }
      else{
        location.url('/admin/metrics');
      }
    });

  }]);

}(window.app));