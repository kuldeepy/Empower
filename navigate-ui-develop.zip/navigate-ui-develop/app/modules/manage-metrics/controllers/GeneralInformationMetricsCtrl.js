(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('GeneralInformationMetricsCtrl', ['$scope','$state','metricsConfigStateSvc','$location',
    function (scope,state,metricsConfigStateSvc,location) {
      scope.initialize = function () {
        scope.getStaticOptionsData();
        if (scope.initializeStep) {
          if(scope.editMetrics.isEditStatus === 'true'){
            scope.editMetrics.isEditStatus=false;
            state.go('metricsConfigSummary');
            scope.initializeStep('metricsConfigSummary', true);
          }
          else{
            scope.initializeStep('metricsConfigGeneralInfo', false);
          }
        }
      };

      scope.$on('wizardOnClose', function() {
        metricsConfigStateSvc.clear();
        if(app !== undefined && app.currentRoute !== undefined) {
          location.url(app.currentRoute);
        }
        else{
          location.url('/admin/metrics');
        }
      });

      scope.$watch('generalInformationForm.$pristine', function () {
        if (scope.generalInformationForm && !scope.generalInformationForm.$pristine) {
          localStorage.setItem('isWizardFormDirty', true);
        }
      });

      scope.$watch('generalInformationForm.$valid', function(validity) {
        scope.completeStep(validity,'metricsConfigGeneralInfo');
      });

    }]);
  }(window.app));