(function (app) {
  'use strict';

  app.controller('SegmentationMetricsCtrl', ['$scope', '$http','$state','metricsConfigStateSvc','$location','metricsDataSvc', function (scope, http, state, metricsConfigStateSvc, location,metricsDataSvc) {
    //scope.segmentationHashUI = null;

    scope.getOperators = function () {
      metricsDataSvc.getOperatorsRequest()
      .then(function (response) {
        scope.listOperator = response.data.results;
      });
    };

    scope.segmentationUiBind = function () {
      scope.segmentationData = {};
      var segmentationHash = {};
      if (scope.metricData.criterias && scope.metricData.criterias.length > 0 && scope.editMetrics.isEdit === 'true') {
        scope.segmentationData = scope.metricData.criterias.filter(function (node) {
          if (node.label === 'Good' || node.label === 'Fair' || node.label === 'Poor') {
            segmentationHash[node.label] = node;
            return true;
          }
        });
        scope.segmentation.segmentationHashUI = segmentationHash;
      } else if (scope.segmentation.segmentationHashUI === null) {
        segmentationHash = {
          'Good': { 'label': 'Good', 'id': 0, 'fromOperator': null, 'fromFrequency': null, 'toOperator': null, 'toFrequency': null },
          'Fair': { 'label': 'Fair', 'id': 1, 'fromOperator': null, 'fromFrequency': null, 'toOperator': null, 'toFrequency': null },
          'Poor': { 'label': 'Poor', 'id': 2, 'fromOperator': null, 'fromFrequency': null, 'toOperator': null, 'toFrequency': null }
        };
        scope.segmentation.segmentationHashUI = segmentationHash;
      }
    };

    scope.init = function () {
      if (scope.initializeStep) {
        scope.initializeStep('metricsConfigSegmentation', false);
      }
      scope.getOperators();
      scope.segmentationUiBind();
    };
    
    scope.checkSegmentValidation=function(){
      if (!scope.validateRequiredFields()) {
        scope.completeStep(false,'metricsConfigSegmentation');
      }
      else{
        scope.completeStep(true,'metricsConfigSegmentation');
      }
    };

    scope.validateRequiredFields = function () {
      scope.result = true;
      if (state.current.name === 'metricsConfigSegmentation') {
        scope.isValid = [];
        var countidx = 0;
        angular.forEach(scope.segmentation.segmentationHashUI, function (key) {
          scope.isValid[countidx] = (key.fromOperator && key.fromFrequency) || (key.toOperator && key.toFrequency) ? true : false;
          countidx += 1;
        });
        if ((scope.isValid[0] ||scope.isValid[1]||scope.isValid[2])===false) {
          return false;
        }
        if (!scope.ckeckValidation(scope.segmentation.segmentationHashUI.Good)) {
          return false;
        }
        if (!scope.ckeckValidation(scope.segmentation.segmentationHashUI.Fair)) {
          return false;
        }
        if (!scope.ckeckValidation(scope.segmentation.segmentationHashUI.Poor)) {
          return false;
        }
      }
      return true;
    };

    scope.ckeckValidation = function (segmentationValue) {
      if ((segmentationValue.fromOperator) || (segmentationValue.fromFrequency)) // if either of them are selected
        {
        if (!((segmentationValue.fromOperator) && (segmentationValue.fromFrequency))) // both should be selected 
          {
          return false;
        }
      }
      if ((segmentationValue.toOperator) || (segmentationValue.toFrequency)) // if either of them are selected
        {
        if (!((segmentationValue.toOperator) && (segmentationValue.toFrequency))) // both should be selected 
          {
          return false;
        }
      }
      return true;
    };
    scope.$watch('segmentationMetricsForm.$valid', function(validity) {
      scope.completeStep(validity,'metricsConfigSegmentation');
    });
    
    scope.$watch('segmentationMetricsForm.$pristine', function () {
      if (scope.segmentationMetricsForm && !scope.segmentationMetricsForm.$pristine) {
        localStorage.setItem('isWizardFormDirty', true);
      }
    });

    scope.$on('wizardOnClose', function() {
      metricsConfigStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {

        location.url(app.currentRoute);
      }
      else{
        location.url('/admin/metrics');
      }
    });

  }]);
}(window.app));
