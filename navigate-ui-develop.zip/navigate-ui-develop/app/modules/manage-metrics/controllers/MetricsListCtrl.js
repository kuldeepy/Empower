(function (app) {
  'use strict';

  app.controller('MetricsListCtrl', ['$scope', '$http', '$location', 'metricsConfigStateSvc','authSvc','homeURL','$state','_','metricsDataSvc',
    function (scope, http, location, metricsConfigStateSvc,authSvc,homeURL,state,_,metricsDataSvc) {

    scope.pageTitle = 'Metrics';
    scope.totalServerItems = 0;

    scope.user = authSvc.user();
    scope.user.backURL = '';

    scope.metricGridData = [];
    scope.getSearchDenominatorData = [];
    scope.items = [];
    scope.isOpen = true;

    scope.metricData = {
      status: 'Active',
      metricName: '',
      description: '',
      denominator: '',
      numerator: ''
    };

    scope.columnsSelected = [{ field: 'name', displayName: 'Metric Name', columnClass: 'table-column-name' }, { field: 'description', displayName: 'Description', columnClass: 'table-column-description' }, { field: 'numeratorType', displayName: 'Metric Type', columnClass: 'table-column-name' }, { field: 'denominatorName', displayName: 'Denominator', columnClass: 'table-column-name' }, { field: 'numeratorName', displayName: 'Numerator', columnClass: 'table-column-name' }, { field: 'status', displayName: 'Status', columnClass: 'table-column-status', sortable: false }, { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false  }];

    scope.init = function () {
      scope.user.backURL = homeURL.getURL(scope.user.role);
      scope.getMetricData();
      scope.getStaticOptionsData();
      scope.getSearchDenominatorData();
    };

    scope.getSearchDenominatorData = function () {
        
        metricsDataSvc.getDenominatorDataRequest()
        .then(function (response) {
            scope.searchDenominatorsData = response.data.results;
          });
      };

    scope.getMetricData = function () {
        var getUrl = 'metrics?name=' + scope.metricData.metricName + '&description=' + scope.metricData.description + '&status=' + scope.metricData.status;

        if (scope.metricData.denominator.length > 0) { // Check for denominator
          getUrl = getUrl + '&denominator=' + angular.fromJson(scope.metricData.denominator).type + '&denominatorId=' + angular.fromJson(scope.metricData.denominator).id;
        }

        if (scope.metricData.numerator.length > 0) { // Check for Numerator
          getUrl = getUrl + '&numerator=' + scope.metricData.numerator;
        }
        metricsDataSvc.getMetricDataRequest(getUrl)
      .then(function (response) {
          scope.metricGridData =_.sortBy(response.data.results,function(item){
            return angular.lowercase(item.name);
          });
          scope.metricGridData.forEach(function (data) {
              switch (data.status) {
                case 'InActive':
                  data.status = 'Inactive';
                  break;
              }
            });
        });
      };

    scope.addMetric = function (id) {
      localStorage.setItem('metricsConfigId', id ? id : 0);
      localStorage.setItem('isMetricsConfigEdit', id ? true : false);
      metricsConfigStateSvc.clear();
      if(id>0){
        scope.summaryState.state=1;
        state.go('metricsConfigSummary');
      }
      location.url(app.currentRoute +'/add');
    };

    scope.clearMetricData = function () {
      scope.metricData.status = 'Active';
      scope.metricData.metricName = '';
      scope.metricData.description = '';
      scope.metricData.denominator = '';
      scope.metricData.numerator = '';
      scope.metricform.$setPristine();
      scope.getMetricData();
    };
  }]);
}(window.app));
