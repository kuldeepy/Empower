(function (app) {
  'use strict';

  app.controller('AddMetricsCtrl', ['$scope', '$state', 'metricsConfigStateSvc', '$location', 'PatientData',
      function (scope, state, metricsConfigStateSvc, location, patientData) {
        scope.pageload();
        patientData.isTaskAddedSuccesfully = false;
        scope.editMetrics.id = localStorage.getItem('metricsConfigId');
        scope.editMetrics.isEdit = localStorage.getItem('isMetricsConfigEdit');
        scope.editMetrics.isEditStatus = localStorage.getItem('isMetricsConfigEdit');
        if(scope.editMetrics.id > 0){
          scope.wizardheader = 'Edit Metric';
        }
        else{
          scope.wizardheader = 'Add Metric';
          scope.segmentation.segmentationHashUI=null;
        }
        localStorage.removeItem('metricsConfigId');
        localStorage.removeItem('isMetricsConfigEdit');
        scope.wizardWorkflow = [
          { 'id': 1, 'name': 'metricsConfigGeneralInfo' },
          { 'id': 2, 'name': 'metricsConfigMap' },
          { 'id': 3, 'name': 'metricsConfigSegmentation' },
          { 'id': 4, 'name': 'metricsConfigSummary' }
        ];

        scope.tabDefinitions = [
          { name: 'metricsConfigGeneralInfo', number: '1', title: 'General Information', selectionCss: 'first active', completed: false ,clickable:false,isTabCompleted:false},
          { name: 'metricsConfigMap', number: '2', title: 'Metric Details', selectionCss: 'inactive', completed: false ,clickable:false,isTabCompleted:false},
          { name: 'metricsConfigSummary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false ,clickable:false,isTabCompleted:false}
        ];

        scope.stepDefinitions = [
          [{ name: 'metricsConfigGeneralInfo', letter: 'a', title: 'General Information', selectionCss: 'active', completed: false ,clickable:false,isTabCompleted:false}],
          [{ name: 'metricsConfigMap', letter: 'a', title: 'MAP DR & NR', selectionCss: 'active', completed: false ,clickable:false,isTabCompleted:false},
           { name: 'metricsConfigSegmentation', letter: 'b', title: 'Numerator Segmentation', selectionCss: 'inactive', completed: false ,clickable:false,isTabCompleted:false}],
          [{ name: 'metricsConfigSummary', letter: 'a', title: 'Summary', selectionCss: 'active', completed: false,clickable:false,isTabCompleted:false }]
        ];
      }]);
})(window.app);
