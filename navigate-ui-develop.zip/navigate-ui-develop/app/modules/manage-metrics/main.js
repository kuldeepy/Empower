(function (app) {
  'use strict';

  /* module root controller */
  var modulePath = 'modules/manage-metrics';

  app.controller('MetricsMainCtrl', ['$scope', '$timeout', 'metricsDataSvc', '$http', '$location', function (scope, timeout, metricsDataSvc, http, location) {
    scope.model = {
      routeParams: {}
    };
    scope.segmentation = { 'segmentationHashUI': null };

    scope.header = {
      contentHeader: 'Add Metric',
      isLeftTabVisible: true
    };

    scope.list = {
      numerators: [],
      denominator: [],
      denominatorM: [],
      denominatorP: []
    };

    scope.editMetrics = {
      'id': 0,
      'isEdit': false
    };

    scope.metricOptionsData = {
      'denominatorsM': null,
      'denominatorsP': null,
      'operators': null,
      'numerators': null,
      'numeratorDetails': null
    };
    scope.pageload=function(){
      scope.metricData = {
        'id': null, //metric ID
        'name': '',
        'description': null,
        'denominatorType': null,//C/M/P
        'denominatorName': null,//C/M/P
        'denominatorId': null,//99
        'numeratorId': null,//11
        'metricType': null,//11
        'valueAttributeId': 0,//11
        'valueAttributeName': null,//11
        'status': 'Active',
        'criterias': [
            {
              'id': 0, //Id of Good
              'fromOperator': '',
              'fromFrequency': '',
              'toOperator': '',
              'toFrequency': ''
            },
            {
              'Id': 0, //Id of Fair
              'fromOperator': '',
              'fromFrequency': '',
              'toOperator': '',
              'toFrequency': ''
            },
            {
              'id': 0, //Id of Poor
              'fromOperator': '',
              'fromFrequency': '',
              'toOperator': '',
              'toFrequency': ''
            }
          ]
        };
    };
    scope.summaryState = {
      state: 1
    };

    scope.errorMessage = 'Unfortunately, we are not able to process your request at this time. Please try again later or contact your system administrator if this continues.';
    scope.requiredValidationError = 'Metric name is mandatory.';
    scope.successMessage = 'Metric has been added successfully.';
    scope.updateSuccessMessage = 'Metric has been updated successfully.';

    scope.getStaticOptionsData = function () {
      metricsDataSvc.getStaticData('denominators?type=M')
        .then(function (data) {
          if (data) {
            scope.metricOptionsData.denominatorsM = data;
            scope.list.denominatorM = data;
            scope.list.denominator = data;
          }
        });

      metricsDataSvc.getStaticData('denominators?type=P')
        .then(function (data) {
          if (data) {
            scope.metricOptionsData.denominatorsP = data;
            scope.list.denominator = data;
            $.merge(scope.list.denominator, scope.list.denominatorM);
          }
        });

      metricsDataSvc.getStaticData('operators')
        .then(function (data) {
          if (data) {
            scope.metricOptionsData.operators = data;
            scope.list.denominator = data;
          }
        }, function () {
          //function(error) 
          //Error handler if needed;
      });

      metricsDataSvc.getStaticData('numerators')
        .then(function (data) {
          if (data) {
            scope.metricOptionsData.numerators = data;
            scope.list.numerators = data;
          }
        });
    };
    scope.mapTaskIdsToName = function (data) {
      scope.metricData = data;
      scope.getMetricType();
    };

    scope.mapSegmentRage = function () {
      scope.isError = false;
      scope.segmentRangeValues = [];
      angular.forEach(scope.metricData.criterias, function (item, key) {
        var temp = [];
        temp[0] = item.fromOperator && item.fromFrequency ? item.fromOperator + item.fromFrequency : '';
        temp[1] = item.toOperator && item.toFrequency ? item.toOperator + item.toFrequency : '';
        scope.segmentRangeValues[key] = temp.filter(Boolean).join(' ');
      });

      var segmentRangeText = '';
      if (scope.metricData.metricType === 'Outcome Metric') {
        segmentRangeText = 'Value';
      }
      else {
        segmentRangeText = 'Performed';
      }
      scope.metricData.segmentRange = scope.metricData.numeratorName + '(' + segmentRangeText + scope.segmentRangeValues.filter(Boolean).join(', ') + ')';

    };

    scope.getMetricType = function () {
      if( scope.metricData.numeratorId !== null && scope.metricData.numeratorId !== undefined){
        metricsDataSvc.getMetricTypeRequest(scope.metricData.numeratorId)
        .then(function (response) {
          scope.metricOptionsData.numeratorDetails = { 'type': null, 'numeratorValues': [] };
          scope.metricOptionsData.numeratorDetails.type = response.data.results.type;
          scope.metricData.metricType = response.data.results.type;
          scope.metricOptionsData.numeratorDetails.numeratorValues = response.data.results.numeratorValues;
          if (scope.metricData.metricType !== 'Outcome Metric') {
            scope.metricData.valueAttributeId = 0;
            scope.metricData.valueAttributeName = 'N/A';

          } else if (scope.metricData.valueAttributeId) {
            var valueAttributeName = scope.metricOptionsData.numeratorDetails.numeratorValues ? scope.metricOptionsData.numeratorDetails.numeratorValues.filter(function (node) {
              if (node.id === scope.metricData.valueAttributeId) {
                return true;
              }
            }) : [];
            scope.metricData.valueAttributeName = valueAttributeName[0] ? valueAttributeName[0].name : 'N/A';
          }
          scope.mapSegmentRage();
        });
      }else{
        scope.metricData.valueAttributeId = 0;
        scope.metricData.metricType = '';
      }
    };

    /* display error message if failed to get the data from api*/
    scope.ShowNotifications = function (errorMsg, style) {
      window.scrollTo(0, 0);
      scope.alertMessageStyle = style;
      scope.alertMessage = errorMsg;
      scope.isError = true;
      scope.isSuccessMsg = style === 'alert-success' ? true : false;
      timeout(function () {
        scope.isError = false;
      }, 6000);
    };

    scope.apiCall = function (methodType, url, metricsData) {
      scope.methodType = methodType;
      metricsDataSvc.apiCall(url,methodType,metricsData)
       .then(function () {
          if (scope.methodType === 'POST') {
            scope.ShowNotifications(scope.successMessage, 'alert-success');
          }
          else {
            scope.ShowNotifications(scope.updateSuccessMessage, 'alert-success');
          }
          location.path('/admin/metrics');
        })
       .catch(function(err){
          scope.showAlert(scope.methodType,err.data.message);
        });
    };

    scope.showAlert = function(methodType,message){
        window.scrollTo(0, 0);
        scope.isAddTaskError = true;
        scope.alertMessage = message;
        timeout(function () { scope.isAddTaskError = false; }, 6000);
      };
  }]);

  /* load required controllers */
  $.when(
  $.getScript('/modules/patient/controllers/PatientCtrl.js'),
  $.getScript('/modules/administrator/controllers/administratorCtrl.js')
  ).done(function () {
    app.publish('moduleReady', modulePath);
  });

}(window.app));