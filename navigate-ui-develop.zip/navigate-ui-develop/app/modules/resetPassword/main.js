(function (app) {
  'use strict';

  /* module root controller */
  app.controller('ResetPasswordModuleCtrl', ['$scope', function (scope) {
    scope.model = {
      routeParams: {}
    };
  }]);

}(window.app));