(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('ResetPasswordCtrl', ['$scope', '$http', '$location', '$timeout','navConstantsSvc',
      function (scope, http, location, timeout,navConstantsSvc) {
        var resetPasswordToken = location.search();
        
        scope.year = new Date().getFullYear();
        scope.user = {
          username: '',
          token: resetPasswordToken.token,
          password: ''
        };
        scope.confirmPassword = '';
        scope.passwordChanged = false;
        scope.passwordPattern = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[(_)<>#?!@$%^&*-]).{6,}$/;
        scope.successMessage = 'Your password has been updated successfully.';
        scope.errorMessageForUsername = 'Username does not exist in the Database.';
        scope.errorMessageForLinkExpired = 'Reset Password link has expired, Please go back to login screen to generate a new reset password link.';

        scope.isPasswordExpired = false;

        scope.resetPassword = function(initLoad) {
          scope.isPasswordExpired = false;

          if (scope.user.password === scope.confirmPassword || initLoad) {
            http
              .put(app.api.root + 'reset-password', scope.user )
              .then(
              
                // SUCCESS
                function () {
                  scope.showNotifications(scope.successMessage, 'alert-success');
                  timeout(function() {
                    location.path('/');
                  }, 1000);
                },
                // ERROR
                function (error) {
                  // Erase the token if user fails to login
                  scope.forgotPasswordUsername = {username: ''};

                  if(error.data.message === navConstantsSvc.expiredDeveloperError){
                    scope.isPasswordExpired = true;
                    scope.showNotifications(scope.errorMessageForLinkExpired, 'alert-danger');
                  }
                  else if(!initLoad){
                    scope.showNotifications(scope.errorMessageForUsername, 'alert-danger');
                  }
                  
                  scope.user.password = '';
                  scope.confirmPassword = '';
                });
          } else {
            scope.user.password = '';
            scope.confirmPassword = '';
          }
        };

        scope.resetPassword(true);

        scope.cancelPassword = function () {
            window.location.href = '/';
          };

          // display error message if failed the api 
        scope.showNotifications = function (errorMsg, style) {
            window.scrollTo(0, 0);
            scope.alertMessageStyle = style;
            scope.alertMessage = errorMsg;
            scope.isError = true;
            timeout(function () {
                scope.isError = false;
              }, 6000);
          };

      }]);
  }(window.app)
);