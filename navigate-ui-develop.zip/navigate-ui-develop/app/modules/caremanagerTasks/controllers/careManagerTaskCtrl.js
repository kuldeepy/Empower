(function (app) {
  'use strict';
  app.controller('careManagerTaskCtrl', ['$scope', 'httpRequestSvc', '$modal',
    function (scope, httpRequestSvc, modal) {

      scope.managedPopulationColumnsHeader = [ { displayName: '#', columnClass: 'table-column-action' },
                            { field: 'programName', displayName: 'Managed Population Name', columnClass: 'table-column-programName' },
                            { field: 'enrollmentStartDate', displayName: 'Enrollment Date', columnClass: 'table-column-enrollmentStartDate' }];

      scope.openPatientPage = function (row) {
        window.location.href = 'patients/' + row.patientId;
      };

      scope.closeModal = function(){
        scope.modalPopUp.close();
      };
      
      scope.getPopulations = function (patientId) {
        var url = 'patients/' + patientId + '/patient-populations';
        httpRequestSvc.getRequest(url).then(function (res) {
          scope.managedPopulationPopUpData = res.data.results;
          scope.modalPopUp = modal.open({
            templateUrl: 'managedPopulationModalContent.html',
            scope: scope
          });
        });
      };
    }
  ]);
}(window.app));