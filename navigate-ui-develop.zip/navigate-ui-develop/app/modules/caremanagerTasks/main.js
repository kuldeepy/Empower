(function (app) {
  'use strict';
  app.controller('myTasksMainCtrl', ['$scope', '$modal', 'authSvc', 'httpRequestSvc', 'teamManagementSvc', 'careTeamSvc', '$filter',
    function (scope, modal, authSvc, httpRequestSvc, teamManagementSvc, careTeamSvc, $filter) {
      scope.isSupervisor = true;
      scope.enrollmentCount = 0;
      scope.user = authSvc.user();
      var requestpath = 'providers/'+ scope.user.providerId + '/task-info';
      scope.isSaveFilterdata = false;
      scope.sortingOptions = {
        field: 'patientName',
        reverse: false
      };
      scope.pagingOptions = {
        pastDueCurrentPage: 1,
        todaysCurrentPage: 1,
        futureCurrentPage: 1,
        claimsCurrentPage: 1,
        pageSize: 10
      };
      
      scope.columnsHeader = [ { field: 'patientName', displayName: 'Name', columnClass: 'table-column-name' },
                            { field: 'medicalRecordNumber', displayName: 'MRN', columnClass: 'table-column-listDate',sortable : false },
                            { field: 'age', displayName: 'Age', columnClass: 'table-column-age' },
                            { field: 'gender', displayName: 'Gender', columnClass: 'table-column-age' },
                            { field: 'dueDate', displayName: 'Due Date', columnClass: 'table-column-duedate' ,sortable : false},
                            { field: 'attemptsDate', displayName: 'Reminder Date', columnClass: 'table-column-duedate' ,sortable : false},
                            { field: 'primaryCarePhysician', displayName: 'PCP', columnClass: 'table-column-name' ,sortable : false},
                            { field: 'taskCount', displayName: 'Total Tasks', columnClass: 'table-column-age' ,sortable : false},
                            { field: 'managedPopulation', displayName: 'Managed Population', columnClass: 'table-column-name' ,sortable : false },
                            { field: 'adtStatus', displayName: 'Event', columnClass: 'table-column-action',sortable : false }];

      scope.getSupervisor = function () {
        teamManagementSvc.getSupervisor(scope.user.providerId).success(function (data) {
          scope.isSupervisor = data.results > 0 ? true : false;
        });
      };

      var filterOut = function(original, toFilter) {
        var filtered = [];
        angular.forEach(original, function(entity) {
          var match = false;
          for(var i = 0; i < toFilter.length; i = i+1) {
            if(toFilter[i].id === entity.id) {
              match = true;
              break;
            }
          }
          if(!match) {
            filtered.push(entity);
          }
        });
        return filtered;
      };

      var assignPCPAsFirstParameter = function(data){
        var searchValue = _.findWhere(data, {name: 'No PCP Assigned'});
        var index = _.findIndex(data, searchValue);
        data[index].name = ' ' + data[index].name;
        return data;
      };

      scope.openFilterPopUp = function(item){
        scope.popUpData = {};
        if(item.isInitial)
        {
          var URL = item.url;
          item.isInitial = false;
          httpRequestSvc.getRequest(URL).then(function (result) {
            item.rightSideData = item.modelData;
            item.data = (item.headerText === 'PCP') ? assignPCPAsFirstParameter(modifyParameterName(result.data.results, item.headerText)) : modifyParameterName(result.data.results, item.headerText);
            if(item.rightSideData.length === 0) {
              item.rightSideData = item.data;
            }
            else{
              item.leftSideData = filterOut((item.headerText === 'PCP') ? assignPCPAsFirstParameter(modifyParameterName(result.data.results, item.headerText)) : modifyParameterName(result.data.results, item.headerText), item.rightSideData);
            }
            openPopUpModal(item);
          });
        }
        else
        {
          if(item.modelData.length === 0) {
            item.rightSideData = item.data;
          }
          else{
            item.rightSideData = item.modelData;
            item.leftSideData = filterOut(item.data, item.rightSideData);
          }
          openPopUpModal(item);
        }
      };

      var openPopUpModal = function(item){
        scope.popUpData = item;
        scope.modalPopUp = modal.open({
          templateUrl: 'myModalContent.html',
          scope: scope,
          size: 'lg'
        });
      };

      var modifyParameterName = function(data, type){
        var modifiedData = [];
        switch (type) {
          case 'Managed Population':
            data = _.without(data,_.findWhere(data,{managedPopulationName:'All Patients Managed population'}));
            modifiedData = _.map(data, function (item) {
              return {
                id: item.managedPopulationId,
                name: item.managedPopulationName
              };
            });
            break;
          case 'Care Team':
            modifiedData = _.map(data, function (item) {
              return {
                id: item.careTeamId,
                name: item.careTeamName
              };
            });
            break;
          case 'Care Leads':
          case 'Care Manager':
            modifiedData = _.uniq(_.map(data, function (item) {
              return {
                id: item.userId,
                name: item.firstName + ' ' + item.lastName
              };
            }), 'id');
            break;
          case 'Task Types':
            modifiedData = _.map(data, function (item) {
              return {
                id: item.id,
                name: item.name
              };
            });
            break;
          case 'Task Names':
            modifiedData = _.map(data, function (item) {
              return {
                id: item.taskSpecificId,
                taskTypeId: item.taskTypeId,
                name: item.name
              };
            });
            break;
          case 'PCP':
            modifiedData = _.map(data, function (item) {
              return {
                id: item.id,
                name: $filter('isNull')(item.lastName) === '' ? $filter('isNull')(item.firstName) : item.lastName + (($filter('isNull')(item.firstName) !== '') ? ',' : '') + ' ' + $filter('isNull')(item.firstName)
              };
            });
            break;
        }
        return modifiedData;
      };

      scope.deleteNode = function(item, headerText){
        _.forEach(scope.leftMenuData, function(row) {
          if(row.headerText === headerText)
          {
            row.modelData = row.rightSideData = _.without(row.rightSideData,item);
            row.leftSideData.push(item);
            row.isAllStatus = (row.data.length === row.rightSideData.length) ? true : false;
            scope.isSaveFilterdata = true;
            resetAccordion();
          }
        });
      };

      scope.closeModal = function(){ scope.modalPopUp.close(); };

      scope.applyFilter = function(item, type){
        _.forEach(scope.leftMenuData, function(row) {
          if(row.headerText === type)
          {
            item.isAllStatus = (item.data.length === item.rightSideData.length) ? true : false;
            item.modelData = item.headerText === 'PCP' ? validatePCPToTop(item.rightSideData) : item.rightSideData;
            resetAccordion();
          }
        });
        scope.isSaveFilterdata = true;
        scope.modalPopUp.close();
      };

      var validatePCPToTop = function(data){
        var item = _.findWhere(data, {name: ' No PCP Assigned'});
        if(item){
          var element = data[data.indexOf(item)];
          data.splice(data.indexOf(item), 1);
          data.splice(0, 0, element);
        }
        return data;
      };

      var validingSelection = function(data){
        var result = !data.isAllStatus ? ((data.rightSideData.length > 0) ? _.map(data.rightSideData, function(item){ return item.id; }).join(',') : '') : '';
        return result;
      };

      var updateTaskName = function(data){
        var result = [];
        if(!data.isAllStatus)
        {
          _.forEach(data.rightSideData, function(row){
            result.push({taskSpecificId: row.id, taskTypeId: row.taskTypeId, name: row.name});
          });
        }
        return result;
      };

      var getRequestData = function(taskBucket, currentPage, pageSize){
        return {
          model: {
            managedPopulations: validingSelection(_.where(scope.leftMenuData,{headerText:'Managed Population'})[0]),
            taskTypes: validingSelection(_.where(scope.leftMenuData,{headerText:'Task Types'})[0]),
            primaryCarePhysicians: validingSelection(_.where(scope.leftMenuData,{headerText:'PCP'})[0]),
            careTeamMembers: validingSelection(_.where(scope.leftMenuData,{headerText:'Care Manager'})[0]),
            sortColumn: scope.sortBy,
            sortDirection: scope.sortType,
            startRow: currentPage,
            endRow: pageSize,
            taskBucket: taskBucket,
            taskSpecificTypes: updateTaskName(_.where(scope.leftMenuData,{headerText:'Task Names'})[0]),
            careLeads : validingSelection(_.where(scope.leftMenuData,{headerText:'Care Leads'})[0]),
            careTeams : validingSelection(_.where(scope.leftMenuData,{headerText:'Care Team'})[0])
          }
        };
      };

      scope.getPastDueData = function () {
        httpRequestSvc.postRequest(requestpath, getRequestData('PastDue', scope.pagingOptions.pastDueCurrentPage, scope.pagingOptions.pageSize)).then(function (response) {
          if (response.data.results) {
            scope.pastDueGridData = response.data.results.tasks;

            scope.pastDuePatientCount = response.data.results.pastDueTasks.PatientCnt;
            scope.pastDueTasksCount = response.data.results.pastDueTasks.PastDueTasks;

            scope.todaysPatientCount = response.data.results.todaysTasks.PatientCnt;
            scope.todaysTasksCount = response.data.results.todaysTasks.TodayTasks;

            scope.futurePatientCount = response.data.results.futureTasks.PatientCnt;
            scope.futureTasksCount = response.data.results.futureTasks.FutureTasks;

            scope.claimsPatientCount = response.data.results.pendingForClaimsTasks.PatientCnt;
            scope.claimsTasksCount = response.data.results.pendingForClaimsTasks.PendingForClaims;
          }
        });
      };

      scope.getTodayData = function () {
        httpRequestSvc.postRequest(requestpath, getRequestData('Today', scope.pagingOptions.todaysCurrentPage, scope.pagingOptions.pageSize)).then(function (response) {
          if (response.data.results) {
            scope.todaysGridData = response.data.results.tasks;
          }
        });
      };

      scope.getFutureData = function () {
        httpRequestSvc.postRequest(requestpath, getRequestData('Future', scope.pagingOptions.futureCurrentPage, scope.pagingOptions.pageSize)).then(function (response) {
          if (response.data.results) {
            scope.futureGridData =response.data.results.tasks;
          }
        });
      };

      scope.getClaimsData = function () {
        httpRequestSvc.postRequest(requestpath, getRequestData('PendingForClaims', scope.pagingOptions.claimsCurrentPage, scope.pagingOptions.pageSize)).then(function (response) {
          if (response.data.results) {
            scope.claimsGridData = response.data.results.tasks;
          }
        });
      };

      scope.resetFilters = function(status){
        scope.leftMenuData = [
          {
            headerText: 'Managed Population',
            isOpen: false,
            filterText: 'Managed Populations',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/managed-populations',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'Care Team',
            isOpen: false,
            filterText: 'Care Teams',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/care-teams?managedPopulationIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'Care Leads',
            isOpen: false,
            filterText: 'Care Leads',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/care-team-members?careTeamIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'Care Manager',
            isOpen: false,
            filterText: 'Care Managers',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/care-team-members?careTeamIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'Task Types',
            isOpen: false,
            filterText: 'Task Types',
            isAllStatus: true,
            isInitial: true,
            url: 'task-types?context=all',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'Task Names',
            isOpen: false,
            filterText: 'Task Names',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/task-names?managedPopulationIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'PCP',
            isOpen: false,
            filterText: 'PCP',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/primary-care-physicians?managedPopulationIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          }
        ];

        scope.myTaskAccordion = [{
          isPastDueOpen:true,
          isTodaysOpen:false,
          isFutureOpen:false,
          isClaimsOpen:false
        }];

        scope.accordion = [{
          isPastDueOpen:true,
          isTodaysOpen:false,
          isFutureOpen:false,
          isClaimsOpen:false
        }];

        defaultValues();

        if(status){
          scope.isSaveFilterdata = true;
          resetAccordion();
        }
      };

      var defaultValues = function(){
        scope.pastDueGridData = [];
        scope.todaysGridData = [];
        scope.futureGridData = [];
        scope.claimsGridData = [];
        scope.pastDueTasksCount = 0;
        scope.pastDuePatientCount = 0;

        scope.todaysTasksCount = 0;
        scope.todaysPatientCount = 0;

        scope.futureTasksCount = 0;
        scope.futurePatientCount = 0;

        scope.claimsTasksCount = 0;
        scope.claimsPatientCount = 0;

        scope.isIntialPastDue = false;
        scope.isIntialToday = true;
        scope.isIntialFuture = true;
        scope.isIntialClaims = true;

        scope.pagingOptions = {
          pastDueCurrentPage: 1,
          todaysCurrentPage: 1,
          futureCurrentPage: 1,
          claimsCurrentPage: 1,
          pageSize: 10
        };
        
        scope.sortBy ='patientName';
        scope.sortType ='Asc';
      };

      var resetAccordion = function(){
        scope.myTaskAccordion = scope.myTaskAccordion.map(function (data) {
          return data;
        });
        scope.accordion = scope.accordion.map(function (data) {
          return data;
        });
        scope.myTaskAccordion.isPastDueOpen = true;
        scope.accordion.isPastDueOpen = true;
        defaultValues();
        window.setTimeout(function () {
          $(window).resize();
        }, 20);
        bindFilters();
      };

      scope.saveFilteredData = function(){
        var taskInfoRequestBody = {
          managedPopulations: validingSelection(_.where(scope.leftMenuData,{headerText:'Managed Population'})[0]),
          taskTypes: validingSelection(_.where(scope.leftMenuData,{headerText:'Task Types'})[0]),
          primaryCarePhysicians: validingSelection(_.where(scope.leftMenuData,{headerText:'PCP'})[0]),
          careTeamMembers: validingSelection(_.where(scope.leftMenuData,{headerText:'Care Manager'})[0]),
          taskSpecificType: updateTaskName(_.where(scope.leftMenuData,{headerText:'Task Names'})[0]),
          careTeamIds: validingSelection(_.where(scope.leftMenuData,{headerText:'Care Team'})[0]),
          careLeadIds: validingSelection(_.where(scope.leftMenuData,{headerText:'Care Leads'})[0])
        };
        careTeamSvc.postAppliedTaskFilter(taskInfoRequestBody).success(function () {
          scope.isSaveFilterdata = false;
        });
      };

      var generatingSavedData = function(filteredData, item){
        item.rightSideData = [];
        _.forEach(filteredData, function(row) {
          item.rightSideData.push(row);
          item.isAllStatus = (item.data.length === item.rightSideData.length) ? true : false;
          item.isOpen = item.rightSideData.length > 0 ? true : false;
        });
        var modifiedData = [];
        if(item.headerText === 'Care Leads'){
          modifiedData = [];
          _.forEach(filteredData, function(res) {
            modifiedData.push({id: res.userId, name: res.name});
          });
          item.rightSideData = modifiedData;
        }
        else if(item.headerText === 'Task Names'){
          modifiedData = [];
          _.forEach(filteredData, function(res) {
            modifiedData.push({id: res.taskSpecificId, taskTypeId: res.taskTypeId, name: res.taskTypeName});
          });
          item.rightSideData = modifiedData;
        }
        item.modelData = item.rightSideData;
        return item;
      };

      scope.getSavedFilteredCriteria = function () {
        careTeamSvc.getAppliedTaskFilter().success(function (data) {
          _.forEach(scope.leftMenuData, function(row) {
            switch (row.headerText) {
              case 'Managed Population':
                if(data.results.managedPopulationsList){
                  if(data.results.managedPopulationsList.length > 0){
                    row = generatingSavedData(data.results.managedPopulationsList, row);
                  }
                }
                break;
              case 'Task Types':
                if(data.results.managedPopulationsList){
                  if(data.results.taskTypesList.length > 0){
                    row = generatingSavedData(data.results.taskTypesList, row);
                  }
                }
                break;
              case 'Care Team':
                if(data.results.careTeamsList){
                  if(data.results.careTeamsList.length > 0){
                    row = generatingSavedData(data.results.careTeamsList, row);
                  }
                }
                break;
              case 'PCP':
                if(data.results.primaryCarePhysiciansList){
                  if(data.results.primaryCarePhysiciansList.length > 0){
                    row = generatingSavedData(data.results.primaryCarePhysiciansList, row);
                  }
                }
                break;
              case 'Care Leads':
                if(data.results.careLeadsList){
                  if(data.results.careLeadsList.length > 0){
                    row = generatingSavedData(data.results.careLeadsList, row);
                  }
                }
                break;
              case 'Care Manager':
                if(data.results.careManagersList){
                  if(data.results.careManagersList.length > 0){
                    row = generatingSavedData(data.results.careManagersList, row);
                  }
                }
                break;
              case 'Task Names':
                if(data.results.taskSpecificTypeFilter){
                  if(data.results.taskSpecificTypeFilter.length > 0){
                    row = generatingSavedData(data.results.taskSpecificTypeFilter, row);
                  }
                }
                break;
            }
          });
          resetAccordion();
        });
      };

      scope.$watch('pagingOptions', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          bindFilters();
        }
      }, true);

      scope.$watch('sortingOptions', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          scope.sortBy = newVal.field;
          scope.sortType = newVal.reverse === false ? 'ASC' : 'DESC';
          bindFilters();
        }
      }, true);

      scope.activeAccordionData = function (activeTab, status, isIntialStatus) {
        if(isIntialStatus){
          if(status){
            scope.accordion.isPastDueOpen = false;
            scope.accordion.isTodaysOpen = false;
            scope.accordion.isFutureOpen = false;
            scope.accordion.isClaimsOpen = false;
            scope.myTaskAccordion.isPastDueOpen = false;
            scope.myTaskAccordion.isTodaysOpen = false;
            scope.myTaskAccordion.isFutureOpen = false;
            scope.myTaskAccordion.isClaimsOpen = false;
            scope.isIntialPastDue = true;
            scope.isIntialToday = true;
            scope.isIntialFuture = true;
            scope.isIntialClaims = true;
            scope.sortBy = 'patientName';
            scope.sortType = 'ASC';
            scope.sortingOptions.field = 'patientName';
            scope.sortingOptions.reverse = false;
            scope.pagingOptions = {
              pastDueCurrentPage: 1,
              todaysCurrentPage: 1,
              futureCurrentPage: 1,
              claimsCurrentPage: 1,
              pageSize: 10
            };

            if(activeTab === 'pastdue')
            {
              scope.isIntialPastDue = !isIntialStatus;
              scope.getPastDueData();
              scope.accordion.isPastDueOpen = true;
              scope.myTaskAccordion.isPastDueOpen = true;
            }
            if(activeTab === 'today')
            {
              scope.isIntialToday = !isIntialStatus;
              scope.getTodayData();
              scope.accordion.isTodaysOpen = true;
              scope.myTaskAccordion.isTodaysOpen = true;
            }
            if(activeTab === 'future')
            {
              scope.isIntialFuture = !isIntialStatus;
              scope.getFutureData();
              scope.accordion.isFutureOpen = true;
              scope.myTaskAccordion.isFutureOpen = true;
            }
            if(activeTab === 'claims')
            {
              scope.isIntialClaims = !isIntialStatus;
              scope.getClaimsData();
              scope.accordion.isClaimsOpen = true;
              scope.myTaskAccordion.isClaimsOpen = true;
            }
            window.setTimeout(function () {
              $(window).resize();
            }, 20);
          }
        }
      };

      var bindFilters = function(){
        if(scope.accordion.isPastDueOpen === true){
          scope.getPastDueData();
        }
        else if(scope.accordion.isFutureOpen === true){
          scope.getFutureData();
        }
        else if(scope.accordion.isTodaysOpen === true){
          scope.getTodayData();
        }
        else if(scope.accordion.isClaimsOpen === true){
          scope.getClaimsData();
        }
      };

      scope.init = function(){
        scope.getSupervisor();
        scope.resetFilters(false);
        scope.getSavedFilteredCriteria();
        scope.getSupervisor();
        scope.getEnrollmentCount();
      };

      scope.getEnrollmentCount = function() {
        httpRequestSvc.getRequest('providers/' + scope.user.providerId + '/enrollments-count').then(function (result) {
            scope.enrollmentCount = result.data.results.count;
          });
      };
    }
  ]);
}(window.app));