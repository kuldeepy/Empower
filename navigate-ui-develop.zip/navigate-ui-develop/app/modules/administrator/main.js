(function (app) {
  'use strict';

  /* module root controller */
  app.controller('AdminModuleCtrl', ['$scope', function (scope) {
    scope.model = {
      routeParams: {}
    };
  }]);

}(window.app));