(function (app) {
  'use strict';

  app.controller('AdminstatorCareTeamCtrl', ['$scope','$location', 'modalService', 'listStateSvc','careTeamSvc','$timeout','$state','$filter','$modal',
    function (scope, location, modalService, listStateSvc, careTeamSvc, timeout, state, filter, $modal) {
      scope.careTeams = [];
      scope.accordionOpen = true;
      scope.careTeamSearch = {'careTeamName' : '', 'description' : '', status : 'Active'};
      scope.filterText = {'careTeamName' : '', 'description' : '', status : 'Active'};
      scope.pageSize = 10;
      scope.page = 1;
      scope.careTeamPopUP = false;
      scope.careTeamList = [];
        
      scope.columnsSelected = [{ field: 'name', displayName: 'Care Team Name', columnClass: 'table-column-name' }, { field: 'description', displayName: 'Description', columnClass: 'table-column-descriptions' }, { field: 'isStatus', displayName: 'Status', columnClass: 'table-column-status', sortable: false }, { field: 'action', displayName: 'Action', columnClass: 'table-column-actions', sortable: false }];

      scope.pageTitle = 'Care Team';
      scope.popUpCareTeams = [];
      scope.popUpPageSize = 5;
      scope.popUpPage = 1;
        
      scope.popUpCareTeamTable = [{ field: 'name', displayName: 'Name', columnClass: 'table-column-description' }, { field: 'emailAddress', displayName: 'Email', columnClass: 'table-column-description' }, { field: 'isCareSupervisor', displayName: 'Supervisor', columnClass: 'table-column-status' }];
      
      scope.$watch('page');
      scope.$watch('careTeams');
      var currentListState = listStateSvc.get();

      var errorMessage = 'Unfortunately, we are not able to process your request right now. Please try again later or contact your system administrator if this continues';
      scope.notification = {
        visible : false,
        success : false,
        failure : false,
        warning : false,
        info : false,
        message : errorMessage
      };

      this.notification = function(message){
        scope.alertMessage = message;
        scope.isError = true;
        window.scrollTo(0, 0);
        timeout(function () {scope.isError = false;}, 6000);
      };


      scope.errorNotification=function(alertMessage,isSuccess,isFailure){
        scope.notification.message = alertMessage;
        scope.notification.visible = true;
        scope.notification.success = isSuccess;
        scope.notification.failure = isFailure;
        window.scrollTo(0, 0);
        timeout(function () {scope.notification.visible = false;}, 8000);
      };

      scope.cancelAlert=function(){
        scope.notification.visible = false;
      };

      this.careTeamHeader='Add Care Team';

      this.careTeamPost = {
        id:'',
        name: '',
        description: '',
        status: 'Active',
        careManagers: []
      };

      scope.getCareTeamDetails = function(){
        if(currentListState.CurrentUIState.careTeamDetails !== undefined){
          if(currentListState.CurrentUIState.careTeamDetails.isAlert === true){
            scope.errorNotification(currentListState.CurrentUIState.careTeamDetails.message,true,false);
            currentListState.CurrentUIState.careTeamDetails = {isAlert:false};
            listStateSvc.set(currentListState);
          }
        }
        scope.careTeams = [];
        careTeamSvc.getRequest('care-teams?IncludeInActive=true').then(function(response){
          scope.careTeams = response.data.results;
          angular.forEach(scope.careTeams, function (value) {
            if (value.status === 'Active') {
              value.isStatus = true;
            } else {
              value.isStatus = false;
            }
          });
          scope.careTeams = filter('filter')(scope.careTeams, { isStatus: true });
          scope.careTeamSearchData = response.data.results;
          scope.page = 1;
        });
      };
      scope.getCareTeamDetails('');

      scope.searchCareTeams = function () {
        if (currentListState.CurrentUIState.careTeamDetails !== undefined) {
          if (currentListState.CurrentUIState.careTeamDetails.isAlert === true) {
            scope.errorNotification(currentListState.CurrentUIState.careTeamDetails.message, true, false);
            currentListState.CurrentUIState.careTeamDetails = { isAlert: false };
            listStateSvc.set(currentListState);
          }
        }
        scope.careTeams = [];
        careTeamSvc.getRequest('care-teams?IncludeInActive=true').then(function (response) {
          scope.careTeamSearchData = response.data.results;
          angular.forEach(scope.careTeamSearchData, function (value) {
            if (value.status === 'Active') {
              value.isStatus = true;
            } else {
              value.isStatus = false;
            }
          });
          scope.page = 1;
        });
        scope.filterData = { name: scope.careTeamSearch.careTeamName !== '' ? scope.careTeamSearch.careTeamName : '', description: scope.careTeamSearch.description !== '' ? scope.careTeamSearch.description : '', isStatus: scope.careTeamSearch.status === 'Active' ? true : false };
        scope.careTeams = filter('filter')(scope.careTeamSearchData, { name: scope.filterData.name, description: scope.filterData.description, isStatus: scope.filterData.isStatus });
      };

      scope.clearselection = function(){
        scope.careTeam.$setPristine();
        scope.careTeamSearch = {'careTeamName' : '', 'description' : '', status : 'Active'};
        scope.filterText = { 'careTeamName': '', 'description': '', status: 'Active' };
        scope.getCareTeamDetails();
      };

      scope.editCareTeam = function(careTeam){
        var careManagerDetails=[];
        var careTeamData ={};
        var careTeamId={ 'careteamId' : careTeam.id,
                         'context' : 'careteammembers' };
        careTeamSvc.getRequest('care-team-members',careTeamId).then(function(response){
            careManagerDetails = response.data.results.careTeamMembers;
            careTeamData = {
              careTeamStatus : true,
              id : careTeam.id,
              name : careTeam.name,
              description: careTeam.description,
              status: careTeam.status,
              careManagers: careManagerDetails,
              currentState : 'adminCareTeamSummary'
            };
            currentListState.CurrentUIState.careTeamDetails = careTeamData;
            listStateSvc.set(currentListState);
            state.go(careTeamData.currentState);
            location.url(app.currentRoute +'/library/care/add');
          })
          .catch(function(){
            careTeamData = {
              careTeamStatus : true,
              id : careTeam.id,
              name : careTeam.name,
              description: careTeam.description,
              status: careTeam.status,
              careManagers: [],
              currentState : 'adminCareTeamSummary'
            };
            currentListState.CurrentUIState.careTeamDetails = careTeamData;
            listStateSvc.set(currentListState);
            state.go(careTeamData.currentState);
            location.url(app.currentRoute +'/library/care/add');
          });
      };

      scope.showCareTeamDetails = function (careTeam) {
        var careTeamId={ 'careteamId' : careTeam.id,
                         'context' : 'careteammembers' };
        careTeamSvc.getRequest('care-team-members',careTeamId).then(function(response){
            scope.headerText = careTeam.name;
            scope.popUpCareTeams = response.data.results.careTeamMembers;
            scope.showCareTeamPopup = $modal.open({
              templateUrl: 'careTeamPopUp.html',
              scope: scope,
              backdrop: 'static',
              size: 'lg',
              keyboard: false,
              action: 'show'
            });
          });
      };

      scope.close = function () {
        scope.showCareTeamPopup.close();
        scope.popUpCareTeams = [];
      };

      scope.newCareTeam = function(){
        currentListState.CurrentUIState.careTeamDetails = {id : 0};
        listStateSvc.set(currentListState);
        location.url(app.currentRoute +'/library/care/add');
      };

      scope.wizardWorkflow = [
        { 'id': 1, 'name': 'adminCareTeamName' },
        { 'id': 2, 'name': 'adminCareTeamDetails' },
        { 'id': 3, 'name': 'adminCareTeamSummary' }
      ];

      scope.tabDefinitions = [
        { name: 'adminCareTeamName', number: '1', title: 'Care Team Name', selectionCss: 'first active', completed: false,clickable:false,isTabCompleted:false  },
        { name: 'adminCareTeamDetails', number: '2', title: 'Care Team Details', selectionCss: 'inactive', completed: false,clickable:false,isTabCompleted:false  },
        { name: 'adminCareTeamSummary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false,clickable:false,isTabCompleted:false  }
      ];

      scope.stepDefinitions = [
        [{ name: 'adminCareTeamName', letter: 'a', title: 'Care Team Name', selectionCss: 'active', completed: false,clickable:false,isTabCompleted:false  }],
        [{ name: 'adminCareTeamDetails', letter: 'a', title: 'Assign Members', selectionCss: 'active', completed: false,clickable:false,isTabCompleted:false  }],
        [{ name: 'adminCareTeamSummary', letter: 'a', title: 'Summary', selectionCss: 'active', completed: false,clickable:false,isTabCompleted:false  }]
      ];
    }]);

}(window.app));