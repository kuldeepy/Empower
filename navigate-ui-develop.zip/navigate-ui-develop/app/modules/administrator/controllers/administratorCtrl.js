/**
 * @author michael.ash
 */
(function (app) {
  'use strict';

  app.controller('administratorCtrl', ['$scope', function (scope) {
    scope.menu = {
      users : {
        text : 'Users',
        items : [
          {text: 'User Management', route : '/admin/users/user'}
        ]
      },
      library : {
        text : 'Library',
        items : [
          {text: 'Population Definition', route : '/admin/library/population'},
          {text: 'Metrics', route : '/admin/metrics'},
          {text: 'Care Team', route : '/admin/library/care'},
          {text: 'Task Bundle', route : '/admin/taskbundle'},
          {text: 'Reminder Schedule', route : '/admin/library/reminder'},
          {text: 'Assessment', route: '/admin/library/assessment' }
        ]
      },
      system :{
        text : 'System Admin',
        items : [
          {text : 'System Errors', route : '/admin/system/application'},
          {text : 'User Sessions', route : '/admin/system/login'},
          {text : 'User Activities', route : '/admin/system/activity'},
          {text : 'Patient Data Access Log', route : '/admin/system/patient'}
        ]
      },
      reports :{
        text : 'Reports',
        items : [
          {text : 'Condition Prevalence Report', route : '/admin/reports/condition'},
          {text : 'Comorbidity Report', route : '/admin/reports/comorbidity'},
          {text : 'Standard Quality Report - HEDIS', route : '/admin/report/hedis'},
          {text : 'Standard Quality Report - P4P ', route : '/admin/report/p4p'},
          {text : 'Chronic Care Management ', route : '/admin/report/chroniccare'}
        ]
      },
      configuration : {
        text : 'Configuration',
        items : [
          {text : 'Managed Population', route : '/admin/configuration/population'}
        ]
      }
    };
    scope.site = {link : '/admin', headerText : 'Home'};
    scope.messages = {link : '/message', headerText : 'My Messages'};
    if(app.showMonthlyBillingReport)
    {
      scope.menu.reports.items.push({text : 'CCM Monthly Billing Report ', route : '/reports/monthlybilling'});
    }
    if(app.showProgramStatusReport)
    {
      scope.menu.reports.items.push({text : 'Program Status per Month ', route : '/reports/programstatus'});
    }
    if(app.showKpiTotalPatientsReport)
    {
      scope.menu.reports.items.push({text : 'KPI Total Patients ', route : '/reports/kpitotalpatients'});
    }
    if(app.showKpiReadmissionReport)
    {
      scope.menu.reports.items.push({text : 'KPI Readmission ', route : '/reports/kpireadmission'});
    }
    scope.reports = {link : '/admin/reports',  headerText : 'Reports'};

  }]);

}(window.app));