(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('GeneralInformationAdminCtrl', ['$scope', 'listStateSvc', '$window', '$state', 'populationDefinitionSvc',
    function (scope,listStateSvc,window,state,populationDefinitionSvc) {
      if(scope.initializeStep){
        scope.initializeStep('pdgeneralinformation', true);
      }
      scope.isShowGeneralInfoCancel=true;
      scope.isReEnrollDisabled = false;
      var currentListState = listStateSvc.get();
      scope.pdselection={status:'Active',refresh:'Daily',isAutoReEnroll:'yes'};
      scope.populatePopulationDefinition = function(){
        var populationDefinitionId = currentListState.CurrentUIState.populationDefinition.id;
        if(currentListState.CurrentUIState.populationDefinition.isDraft === false){
          scope.isShowGeneralInfoCancel=false;
          scope.isReEnrollDisabled = true;
        }
        if(populationDefinitionId > 0){
          scope.populationDefinitionSearch={populationDefinitionId:populationDefinitionId};
          populationDefinitionSvc.populationDefinitionGetData('population-definition?populationDefinitionSearch='+JSON.stringify(scope.populationDefinitionSearch)).then(function(response){
            if(response.data.results){
              scope.pdselection=response.data.results[0];
              if(scope.pdselection.isAutoReEnroll){
                scope.pdselection.isAutoReEnroll = 'yes';
              }
              else
              {
                scope.pdselection.isAutoReEnroll = 'no';
              }
            }
          });
        }
      };

      scope.populatePopulationDefinition();

      scope.$on('wizardonCancel', function() {
        if(!currentListState.CurrentUIState.flag){
          if(!scope.form.$pristine){
            var isflag = !scope.form.$pristine;
            currentListState.CurrentUIState.flag = isflag;
            listStateSvc.set(currentListState);
          }
          else{
            currentListState.CurrentUIState.flag = false;
            listStateSvc.set(currentListState);
          }
        }
      });

      scope.insertUpdatePopulationDefinition = function(pdselection){
        var populationDefinitionId = currentListState.CurrentUIState.populationDefinition.id;
        var populationDefinitionDetails = {};
        scope.generalInformation = {populationDefinitionName:pdselection.populationDefinitionName,description:pdselection.description,status:(pdselection.status === 'Active' ? 'Active':'InActive'),refresh:pdselection.refresh,productionStatus:(currentListState.CurrentUIState.populationDefinition.isDraft === true?'Draft':'Final'),isAutoReEnroll:(pdselection.isAutoReEnroll === 'yes' ? true : false)};
        if(populationDefinitionId <= 0){
          populationDefinitionSvc.populationDefinitionPostData('population-definition',scope.generalInformation).then(function(response){
            if(response.data.results){
              if(response.data.results !== -1){
                populationDefinitionId= response.data.results;
                populationDefinitionDetails = {
                  id : populationDefinitionId,
                  state : 'pdselectCriteria',
                  isNew : currentListState.CurrentUIState.populationDefinition.isNew,
                  isDraft : currentListState.CurrentUIState.populationDefinition.isDraft
                };
                currentListState.CurrentUIState.populationDefinition = populationDefinitionDetails;
                listStateSvc.set(currentListState);
                state.go('pdselectCriteria');
              }
            }
          });
        }
        else if(populationDefinitionId > 0){
          populationDefinitionSvc.populationDefinitionPutData('population-definition/'+ populationDefinitionId,scope.generalInformation).then(function(response){
            if(response.data.results){
              populationDefinitionDetails = {
                id : populationDefinitionId,
                state : 'pdselectCriteria',
                isNew : currentListState.CurrentUIState.populationDefinition.isNew,
                isDraft : currentListState.CurrentUIState.populationDefinition.isDraft
              };
              currentListState.CurrentUIState.populationDefinition = populationDefinitionDetails;
              listStateSvc.set(currentListState);
              state.go('pdselectCriteria');
            }
            else{
              scope.showErrorNotifications('Population Definition name already exists. Please enter a different name','alert-error');
            }
          });
        }
      };
     

      scope.saveGeneralInformation = function(pdselection){
        populationDefinitionSvc.populationDefinitionGetData('population-definition?populationDefinitionSearch='+JSON.stringify({populationDefinitionName : pdselection.populationDefinitionName})).then(function(response){
          var populationDefinitionData =  _.filter(response.data.results, function (item) {
            return (item.populationDefinitionName === pdselection.populationDefinitionName );
          });
          if(populationDefinitionData.length > 0){
            if(populationDefinitionData[0].populationDefinitionId !== currentListState.CurrentUIState.populationDefinition.id){
              scope.showErrorNotifications('Population Definition name already exists. Please enter a different name','alert-error');
            }
            else
            {
              scope.insertUpdatePopulationDefinition(pdselection);
            }
          }
          else{
            scope.insertUpdatePopulationDefinition(pdselection);
          }
        });
      };

    }]);
  }(window.app));