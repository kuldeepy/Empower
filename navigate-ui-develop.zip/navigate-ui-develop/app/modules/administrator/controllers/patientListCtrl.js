(function (app) {
  'use strict';
  app.controller('PatientlistCtrl', ['$scope','$modalInstance','$window','$location','conditionPrevalenceSvc','downloadCsv',
    function ($scope,modalInstance,$window,location,conditionPrevalenceSvc,downloadCsv) {
      $scope.patientData = [];
      var tempModalOptions = {};
      $scope.modalOptions = tempModalOptions;
      $scope.patientGridData = [];
      $scope.totalServerItems = 0;
      $scope.totalNumberOfPatients = '';
      $scope.pagingOptions = {
        pageSizes: [10],
        pageSize: 10,
        currentPage: 1
      };

      $scope.filterOptions = {
        filterText: '',
        useExternalFilter: true
      };

      $scope.setPagingData = function (data) {
        var pagedData;
        switch($scope.reportType){
          case 'HEDIS' :
            pagedData = data.hedisPatients;
            break;
          case 'p4p' :
            pagedData = data.payForPerformancePatients;
            break;
          case 'chronicCare' :
            pagedData = data;
            break;
          default:
            pagedData = data.conditionPrevalencePatients;
        }
        $scope.patientGridData = pagedData;
        $scope.totalServerItems = $scope.pateintCount;
        if (!$scope.$$phase) {
          $scope.$apply();
        }
      };

      $scope.getPagedDataAsync = function (pageSize, page,startIndex,endIndex,searchText,type) {
        var conditionsDrilldownParameters = {};
        setTimeout(function () {
          switch($scope.selectedMetric){
            case '0':
              $scope.key = $scope.item.conditionMetricId;
              $scope.populationConditionName = $scope.item.conditionMetricName;
              conditionsDrilldownParameters = { 'metricType': 'Process', 'range':$scope.range,  'dateKey': $scope.dateKeyId,  'startIndex': startIndex,  'endIndex':type === 'excel' ? $scope.pateintCount : $scope.pagingOptions.pageSize, 'clinicId' : $scope.clinciId, 'pcpId' : $scope.pcpId, 'healthPlanId' : $scope.healthPlanId, 'productId' : $scope.productId, 'populationConditionId' : $scope.item.populationConditionId, 'sortType':$scope.sortType, 'sortName': $scope.sortBy};
              break;
            case '1':
              $scope.key = $scope.item.conditionMetricId;
              $scope.populationConditionName = $scope.item.conditionMetricName;
              conditionsDrilldownParameters = { 'metricType': 'Outcome', 'range':$scope.range,  'dateKey': $scope.dateKeyId,  'startIndex': startIndex,  'endIndex':type === 'excel' ? $scope.pateintCount : $scope.pagingOptions.pageSize, 'clinicId' : $scope.clinciId, 'pcpId' : $scope.pcpId, 'healthPlanId' : $scope.healthPlanId, 'productId' : $scope.productId, 'populationConditionId' : $scope.item.populationConditionId, 'sortType':$scope.sortType, 'sortName': $scope.sortBy};
              break;
            case '2':
              $scope.key = $scope.item.conditionMetricId;
              $scope.populationConditionName = $scope.item.conditionMetricName;
              conditionsDrilldownParameters = { 'metricType': 'Utilization', 'range':$scope.range,  'dateKey': $scope.dateKeyId,  'startIndex': startIndex,  'endIndex': type === 'excel' ? $scope.pateintCount : $scope.pagingOptions.pageSize, 'clinicId' : $scope.clinciId, 'pcpId' : $scope.pcpId, 'healthPlanId' : $scope.healthPlanId, 'productId' : $scope.productId, 'populationConditionId' : $scope.item.populationConditionId, 'sortType':$scope.sortType, 'sortName': $scope.sortBy};
              break;
            case '3':
              $scope.key = $scope.item.populationConditionId;
              $scope.populationConditionName = $scope.item.populationConditionName;
              conditionsDrilldownParameters = { 'metricType': 'Conditions', 'dateKey': $scope.dateKeyId,  'startIndex': startIndex,  'endIndex': type === 'excel' ? $scope.pateintCount : $scope.pagingOptions.pageSize, 'clinicId' : $scope.clinciId, 'pcpId' : $scope.pcpId, 'healthPlanId' : $scope.healthPlanId, 'productId' : $scope.productId , 'sortType':$scope.sortType, 'sortName': $scope.sortBy};
              break;
          }
          switch($scope.reportType){
            case 'HEDIS':
              conditionPrevalenceSvc.getHedisRequest($scope.key,JSON.stringify(conditionsDrilldownParameters)).then(function(response){
                $scope.patientData = response.data.results;
                if(angular.equals(type,'grid')){
                  $scope.totalNumberOfPatients = $scope.pateintCount;
                  $scope.setPagingData($scope.patientData);
                }
              else{
                  $scope.exporttoExcel($scope.patientData.hedisPatients);
                }
              });

              break;
            case 'p4p':
              conditionPrevalenceSvc.getPayForPerformanceRequest($scope.key,JSON.stringify(conditionsDrilldownParameters)).then(function(response){
                $scope.patientData=response.data.results;
                if(angular.equals(type,'grid')){
                  $scope.totalNumberOfPatients=$scope.pateintCount;
                  $scope.setPagingData($scope.patientData);
                }
              else{
                  $scope.exporttoExcel($scope.patientData.payForPerformancePatients);
                }
              });
              break;

            case 'chronicCare' :
              $scope.populationConditionName = $scope.item.managedPopulationName;
              conditionsDrilldownParameters = {'type':$scope.range,'managedPopulationId' : $scope.item.managedPopulationId, 'dateKey': $scope.dateKeyId,  'startIndex': startIndex,  'endIndex': type === 'excel' ? $scope.pateintCount : $scope.pagingOptions.pageSize, 'clinicId' : $scope.filterData.clinicId, 'productId' : $scope.filterData.productId, 'pcpId' : $scope.filterData.pcpId, 'sortType':$scope.sortType, 'sortName': $scope.sortBy,'isExport' : type === 'excel' ?true:false};
              conditionPrevalenceSvc.getCronicCareRequest(conditionsDrilldownParameters).then(function(response){
                if(angular.equals(type,'grid')){
                  $scope.patientData=response.data.results.patients;
                  $scope.totalNumberOfPatients=$scope.pateintCount;
                  $scope.setPagingData($scope.patientData);
                }
              });
              break;

            default:
              conditionPrevalenceSvc.getConditionPrevalenceRequest($scope.key,JSON.stringify(conditionsDrilldownParameters)).then(function(response){
                $scope.patientData=response.data.results;
                if(angular.equals(type,'grid')){
                  $scope.totalNumberOfPatients=$scope.pateintCount;
                  $scope.setPagingData($scope.patientData);
                }
              else{
                  $scope.exporttoExcel($scope.patientData.conditionPrevalencePatients);
                }
              });
          }
        }, 100);
      };

      $scope.$watch('pagingOptions', function (newVal, oldVal) {
        if (newVal !== oldVal && newVal.currentPage !== oldVal.currentPage) {
          $scope.pagingOptions.currentPage = (newVal.currentPage === undefined || newVal.currentPage === null)? 1 : $scope.pagingOptions.currentPage;
          $scope.startIndex = (($scope.pagingOptions.currentPage - 1) * $scope.pagingOptions.pageSize);
          $scope.endIndex = ($scope.pagingOptions.currentPage) * $scope.pagingOptions.pageSize;
          $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage,$scope.startIndex,$scope.endIndex , $scope.filterOptions.filterText, 'grid');
        }
      }, true);

      $scope.sortOptions = {
        fields: ['Patient Name'],
        directions: ['desc']
      };

      $scope.$watch('sortOptions', function (newVal, oldVal) {
        if(newVal !== oldVal){
          if(newVal.directions.length === 0){
            newVal.directions.push('asc');
          }
          $scope.data=$scope.sortName(newVal.fields[0]);
          $scope.sortBy = $scope.data;
          $scope.sortType = newVal.directions[0] ==='asc' ? 'BASC' : 'BDESC';
          $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage,$scope.startIndex===undefined?0:$scope.startIndex,$scope.endIndex , $scope.filterOptions.filterText, 'grid');
        }
      }, true);

      $scope.$watch('filterOptions', function (newVal, oldVal) {
        if (newVal !== oldVal) {
          $scope.getPagedDataAsync($scope.pagingOptions.pageSize, $scope.pagingOptions.currentPage, $scope.filterOptions.filterText, 'grid');
        }
      }, true);

      $scope.sortName =function(name){
        switch(name){
          case 'age':
            return 'PatientAge';
          case 'gender':
            return 'PatientGender';
          case 'pcpName':
            return 'PCPList';
          case 'noofConditions':
            return 'DrCnt';
          case 'conditions':
            return $scope.reportType==='chronicCare'?'ConditionList' : 'DrList';
          case 'managedPopulation':
            return 'ProgramList';
          case 'noOfMinutes' :
            return 'Num Of Minutes';
          case 'careTeam' :
            return 'CareTeamList';
          default:
            return 'patientName';
        }
      };
      
      $scope.gridOptions = {
        data: 'patientGridData',
        multiSelect: false,
        showFooter: true,
        enablePaging: true,
        totalServerItems: 'totalServerItems',
        pagingOptions: $scope.pagingOptions,
        filterOptions: $scope.filterOptions,
        sortInfo: $scope.sortOptions,
        useExternalSorting: true,
        columnDefs: [
          { field: 'memberNum', displayName: 'MRN #',width : '100px'},
          { field: 'patientId', displayName: 'patientId',width : '100px',visible:false},
          { field: 'patientName', displayName: 'Patient Name',  cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()" ng-click="showViewPatients(row.entity);">' +
          '<a data-toggle="tooltip" data-placement="top" title="{{row.getProperty(col.field)}}" data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field)}}</a>' +
          '</div>'
          },
          { field: 'age', displayName: 'Age',width : '50px' },
          { field: 'gender', displayName: 'Gender',width : '60px' },
          { field: 'pcpName', displayName: 'PCP',cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">' +
            '<data-toggle="tooltip" data-placement="top" title="{{row.getProperty(col.field)}}" data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field)}}' +'</div>' },
          { field: 'noofConditions', displayName:($scope.reportType==='HEDIS'?'# of Population':$scope.reportType==='p4p'?'# of Population':'# of Conditions'),width : '110px',visible:($scope.reportType==='chronicCare'?false:true)},
          { field: 'noOfMinutes', displayName:'# of Minutes',width : '110px',visible:($scope.reportType==='chronicCare'?true:false)},
          { field: 'conditions', displayName: ($scope.reportType==='HEDIS'?'Population Name':$scope.reportType==='p4p'?'Population Name':'Conditions'),cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">' +
            '<data-toggle="tooltip" data-placement="top" title="{{row.getProperty(col.field)}}" data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field)}}' +   '</div>'},
          { field: 'managedPopulation', displayName: 'Managed Population',cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">' +
            '<data-toggle="tooltip" data-placement="top" title="{{row.getProperty(col.field)}}" data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field)}}' +  '</div>',width : '150px',visible:($scope.reportType==='chronicCare'?false:true)},
          { field: 'careTeam', displayName: 'Care Team',cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">' +
            '<data-toggle="tooltip" data-placement="top" title="{{row.getProperty(col.field)}}" data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field)}}' +  '</div>',width : '150px',visible:($scope.reportType==='chronicCare'?true:false)}
        ]
      };

      //$scope.getPagedDataAsync($scope.pagingOptions.pageSize, 1, 0, $scope.pagingOptions.pageSize, null, 'grid');

      $scope.modalOptions.close = function () {
        modalInstance.dismiss('cancel');
      };

      $scope.showViewPatients=function(item){
        modalInstance.dismiss('cancel');
        conditionPrevalenceSvc.getMergePatient(item.patientId).then(function(response){
          window.location.href='/patients/' + response.data.results;
        });
      };

      $scope.exporttoExcel=function(patientData){
        var fileName = 'Patients_' + moment().format('MM-DD-YYYY HH:mm:ss');
        var myPatientsHeader;
        var myPatientsFields;
        switch($scope.reportType){
        case 'HEDIS':
        case 'p4p':
          myPatientsHeader = ['MRN #','Patient Name','Age','Gender','PCP','# of Populations','Population Name','Managed Population'];
          myPatientsFields = ['memberNum','patientName','age','gender','pcpName','noofConditions','conditions','managedPopulation'];
          break;
        case 'chronicCare':
          myPatientsHeader = ['MRN #','Patient Name','Age','Gender','PCP','# of Minutes','Conditions','care Team'];
          myPatientsFields = ['memberNum','patientName','age','gender','pcpName','noOfMinutes','conditions','careTeam'];
          break;
        default:
          myPatientsHeader = ['MRN #','Patient Name','Age','Gender','PCP','# of Conditions','Conditions','Managed Population'];
          myPatientsFields = ['memberNum','patientName','age','gender','pcpName','noofConditions','conditions','managedPopulation'];
          break;
        }
        downloadCsv.toCSV(fileName,patientData,myPatientsHeader,myPatientsFields,'Patient Details');
      };
    }]);
})(window.app);
