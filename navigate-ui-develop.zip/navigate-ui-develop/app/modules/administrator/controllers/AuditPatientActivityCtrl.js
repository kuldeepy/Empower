(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('AuditPatientActivityCtrl', ['$scope', 'auditSvc', 'exportSvc', '_',
      function (scope, auditSvc, exportSvc, _) {

        function getPatientActivityFilters() {

          var patientName = scope.search.patientName ? scope.search.patientName.split(', ') : [undefined, undefined];
          return {
            onlyPatientRelated: true,
            patientFirstName: patientName[1],
            patientLastName: patientName[0],
            resource: scope.search.resource,
            action: actionMapFromFriendly[scope.search.action],
            patientMrn: scope.search.mrn,
            startDate: scope.search.dateFrom.value ? window.moment(scope.search.dateFrom.value).format('YYYY-MM-DD') : undefined,
            endDate:
              //Add a day so the upper limit includes the end date
              scope.search.dateTo.value ?
                window.moment(scope.search.dateTo.value)
                .add(1, 'day')
                .format('YYYY-MM-DD')
              : undefined,
            pageSize: scope.scroller.dataChunkSize,
            pageIndex: scope.scroller.dataChunkIndex
          };
        }
      
        function loadMoreUserActivities() {
          scope.scroller.pause = true;
          if (scope.scroller.dataChunkSize * scope.scroller.dataChunkIndex <= scope.scroller.totalElements) {

            var filters = getPatientActivityFilters();

            auditSvc.userActivities(filters)
            .then(function(userActivities) {
              //Format data for UI
              _.forEach(userActivities.userActivities, function(activity) {
                activity.request.dateTime = window.moment(activity.request.dateTime).format('M/D/YYYY h:mm:ss A');
                activity.request.action = actionMapToFriendly[activity.request.action];
                activity.patient.displayName = [activity.patient.name.lastName, activity.patient.name.firstName].join(', ');
                activity.patient.age = activity.patient.dateOfBirth ? moment().diff(activity.patient.dateOfBirth, 'years') : undefined;
                activity.user.displayName = [activity.user.name.lastName, activity.user.name.firstName].join(', ');
              });
              scope.userActivities = scope.userActivities.concat(userActivities.userActivities);
              scope.scroller.totalElements = userActivities.totalActivitiesCount;
              scope.scroller.pause = false;
            });

            scope.scroller.dataChunkIndex += 1;
          }
        }

        scope.title = 'Patient Data Access Log';

        scope.userActivityTable = {
          columns: ['Date & Time', 'Patient Name', 'MRN', 'Age', 'Sex', 'PCP', 'Information Accessed', 'User', 'Operation Performed'],
        };

        scope.scroller = {
          more: loadMoreUserActivities,
          totalElements: 0,
          pause: false,
          dataChunkSize: 40,
          dataChunkIndex: 0
        };

        scope.userActivities = [];

        scope.search = {
          isOpen: true,
          patientNames: [],
          resources: [],
          actions: ['Viewed', 'Created', 'Updated', 'Deleted'],
          mrns: [],
          dateFrom: {
            opened: false,
            value: null,
            maxDate: new Date(),
            format: 'MM/dd/yyyy'
          },
          dateTo: {
            opened: false,
            value: null,
            maxDate: new Date(),
            format: 'MM/dd/yyyy'
          }
        };

        var actionMapToFriendly = {
          GET: 'Viewed',
          POST: 'Created',
          PUT: 'Updated',
          DELETE: 'Deleted'
        };
        var actionMapFromFriendly = _.invert(actionMapToFriendly);

        scope.clearSearchFields = function() {
          scope.activitySearch.$setPristine();
          scope.search.patientName = null;
          scope.search.resource = null;
          scope.search.action = null;
          scope.search.mrn = null;
          scope.search.dateFrom.value = null;
          scope.search.dateTo.value = null;
          scope.applyFilters();
        };

        scope.applyFilters = function() {
          scope.userActivities = [];
          scope.scroller.pause = false;
          scope.scroller.totalElements = 0;
          scope.scroller.dataChunkIndex = 0;
          scope.scroller.more();
        };

        scope.openDateFromPopout = function($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateFrom.opened = !scope.search.dateFrom.opened;
        };

        scope.openDateToPopout = function($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateTo.opened = !scope.search.dateTo.opened;
        };

        scope.export = function() {
          var filters = getPatientActivityFilters();
          filters.pageSize = undefined;
          filters.pageIndex = undefined;
          var dataRows = [[ //First entry in array of arrays
            'Date & Time',
            'Patient First Name',
            'Patient Last Name',
            'MRN',
            'Age',
            'Sex',
            'PCP',
            'Information Accessed',
            'User First Name',
            'User Last Name',
            'Role',
            'Operation Performed'
          ]];

          auditSvc.userActivities(filters)
          .then(function(results) {
            var activities = results.userActivities;
            _.each(activities, function(activity) {
              activity.request.dateTime = window.moment(activity.request.dateTime).format('M/D/YYYY h:mm:ss A');
              activity.request.action = actionMapToFriendly[activity.request.action];
              activity.patient.age = activity.patient.dateOfBirth ? moment().diff(activity.patient.dateOfBirth, 'years') : undefined;
              dataRows.push([
                activity.request.dateTime,
                activity.patient.name.firstName,
                activity.patient.name.lastName,
                activity.patient.mrn,
                activity.patient.age,
                activity.patient.gender,
                activity.patient.primaryCareProvider,
                activity.request.resource,
                activity.user.name.firstName,
                activity.user.name.lastName,
                activity.user.role,
                activity.request.action
              ]);
            });
            var date = window.moment(new Date()).format('M-D-YY');
            exportSvc.toExcel('Patient Activity Report ' + date, dataRows);
          });
        };

        /* function to get excel data */
        scope.downloadExcel=function() {
          var filters = getPatientActivityFilters();
          filters.isExport = true;

         
          auditSvc.patientActivitiesExport(filters).then(function () {
            
          },
          // ERROR
          function (error) {
            var errorData = null;
            var errorObject = null;
            if(error !== null && error.data !== null)
            {
              errorData = String.fromCharCode.apply(null, new Uint16Array(error.data));
              errorObject = angular.fromJson(errorData);
            }

            if(errorData === null || errorObject.developerMessage === 'Timeout expired.  The timeout period elapsed prior to completion of the operation or the server is not responding.')
            {
              scope.ADMainCtrl.errorNotification = 'Query requested is too large. Server timed out. Please select a smaller Date Range.';
            }
          });
        };

        (function populateSearchData() {
          
          var searchFilter = {
            onlyPatientResource: true
          };

          auditSvc.userActivityResources(searchFilter).then(function(resources) {
            scope.search.resources = resources;
          });

          auditSvc.userActivityPatientMrns().then(function(mrns) {
            scope.search.mrns = mrns;
          });

          auditSvc.userActivityPatientNames().then(function(patientNames) {
            _.forEach(patientNames, function(patientName) {
              scope.search.patientNames.push(patientName.lastName + ', ' + patientName.firstName);
            });
          });

        }());

      }]);

  }(window.app)
);