(function (app) {
  'use strict';
  
  app.controller('PopulationDefinitionCtrl', ['$scope','listStateSvc','$location','populationDefinitionSvc','$timeout','authSvc','homeURL',
    function (scope,listStateSvc,location,populationDefinitionSvc,timeout,authSvc,homeURL) {
      var currentListState = listStateSvc.get();
      scope.populationDefinitionDetails = [];
      scope.pageSize = 10;
      scope.page = 1;
      scope.isopen=true;
      scope.pdselection={status:'Active',productionStatus:'All',refresh:'All'};
      scope.user = authSvc.user();
      scope.user.backURL = '';
      scope.user.backURL = homeURL.getURL(scope.user.role);
      scope.columnsSelected = [{ field: 'populationDefinitionName', displayName: 'Population Definition Name', columnClass: 'table-column-description' }, { field: 'description', displayName: 'Description', columnClass: 'table-column-description' }, { field: 'productionStatus', displayName: 'Production', columnClass: 'table-column-name' }, { field: 'status', displayName: 'Status', columnClass: 'table-column-name', sortable: false }, { field: 'refresh', displayName: 'Refresh', columnClass: 'table-column-status' }, { field: 'modifiable', displayName: 'Modifiable', columnClass: 'table-column-action' }, { field: 'lastUpdatedDate', displayName: 'Last Updated', columnClass: 'table-column-name' }, { field: 'isAutoReEnroll', displayName: 'Automatic Re-enrollment', columnClass: 'table-column-action' }, { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false }];

      scope.getpopulationDefinition = function(selection){
        scope.populationDefinitionDetails = [];
       
        var populationDefinitionSearch={
          populationDefinitionId:selection.populationDefinitionId,
          status:selection.status,
          populationDefinitionName:window.encodeURIComponent(selection.populationDefinitionName ? selection.populationDefinitionName : ''),
          description:window.encodeURIComponent(selection.description ? selection.description : ''),
          productionStatus:selection.productionStatus,
          refresh:selection.refresh
        };

        

        populationDefinitionSvc.populationDefinitionGetData('population-definition?populationDefinitionSearch='+JSON.stringify(populationDefinitionSearch)).then(function(response){
          if(response.data.results){
            scope.page = 1;
            scope.populationDefinitionDetails = response.data.results;
          }
        });
      };
      scope.showSuccessAlert = function(){
        scope.isAlert = populationDefinitionSvc.isAddedSuccesfully;
        scope.alertMessage = populationDefinitionSvc.messageAlert;
        window.scrollTo(0, 0);
        timeout(function () {scope.isAlert = false;}, 6000);
        populationDefinitionSvc.isAddedSuccesfully = false;
        populationDefinitionSvc.messageAlert = '';
      };
      scope.pageTitle = 'Population Definition';
      scope.getpopulationDefinition(scope.pdselection);
      scope.showSuccessAlert();
      
      scope.editPopulationDefintion = function(item){
        listStateSvc.clear();
        var populationDefinitionDetails = {
          id : item.populationDefinitionId,
          state : 'pdsummary',
          isNew : false,
          isDraft : (item.productionStatus==='Final'?false:true)
        };
        currentListState.CurrentUIState.populationDefinition = populationDefinitionDetails;
        currentListState.CurrentUIState.flag = false;
        listStateSvc.set(currentListState);
        if(app !== undefined && app.currentRoute !== undefined) {
          location.url(app.currentRoute +'/library/population/add');
        }
        else{
          location.url('/library/population/add');
        }
      };

      scope.newPopulationDefintion = function(){
        listStateSvc.clear();
        var populationDefinitionDetails = {
          id : 0,
          state : 'pdgeneralinformation',
          isNew : true,
          isDraft : true
        };
        currentListState.CurrentUIState.populationDefinition = populationDefinitionDetails;
        currentListState.CurrentUIState.flag = false;
        listStateSvc.set(currentListState);
        if(app !== undefined && app.currentRoute !== undefined) {
          location.url(app.currentRoute +'/library/population/add');
        }
        else{
          location.url('/library/population/add');
        }
      };

      scope.clearselection = function(){
        listStateSvc.clear();
        scope.testform.$setPristine();
        scope.pdselection={status:'Active',productionStatus:'All',refresh:'All'};
        scope.getpopulationDefinition(scope.pdselection);
      };

    }]);

})(window.app);