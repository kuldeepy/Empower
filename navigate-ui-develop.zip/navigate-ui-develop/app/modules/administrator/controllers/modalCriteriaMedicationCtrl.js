(function (app) {
  'use strict';
  
  app.controller('Medication', ['$scope','$modalInstance','$window','$http','listStateSvc','populationDefinitionSvc',function(scope,modalInstance,$window,http,listStateSvc,populationDefinitionSvc){
      var tempModalOptions = {};
      scope.modalOptions = tempModalOptions;
      scope.timeInMs = 0;
      scope.BindPopup=function(){
          switch(scope.criteriaName){
          case 'NDC':
            scope.ndc={};
            scope.ndc.equals='Equals';
            tempModalOptions.headerText='NDC Codes';
            tempModalOptions.options = [];
            tempModalOptions.selectedOptions=[];
            tempModalOptions.selectedData = [];
            tempModalOptions.placeholder='Enter 3 chars min';
            tempModalOptions.available=[];
            tempModalOptions.selected=[];
            scope.modalOptions = tempModalOptions;
            scope.modalOptions.httptest=http;
            scope.multiselect={'url':'ndc-codes','http':scope.modalOptions.httptest,'checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.available,'selectedavailabledata':scope.modalOptions.selected};
            scope.ndcVisisble=true;
            break;
          case 'Medication Groupers':
            scope.medicationSearch={};
            scope.medication={};
            scope.medication.durationcost='0';
            populationDefinitionSvc.populationDefinitionGetData('code-grouping-source/?searchText=Medication Groupers').then(function(response){
              if(response.data.results){
                scope.soureceDD=response.data.results;
                populationDefinitionSvc.populationDefinitionGetData('operators').then(function(responseoperator){
                  if(responseoperator.data.results){
                    scope.amountSymbolsDD=responseoperator.data.results;
                  }
                });
              }
            });
            tempModalOptions.available=[];
            tempModalOptions.selected=[];
            scope.medicationGroup=true;
            break;
          }
        };
      scope.modalOptions.close = function () {
          modalInstance.dismiss('cancel');
        };
       
      scope.addMedications=function(item){
            scope.insertData={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':item.equals==='Equals'?'Equals':'Not Equals','radioType':'','value1':!item.value1?'':item.value1,'value2':!item.value2?'':item.value2,'listValues':scope.multiselect.selectedavailabledata};
            populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.insertData).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
          };

      scope.searchMedicationGroupers=function(item){
          if(item && item.source){
            var grouperName='&groupersText='+item.grouperName;
            var isTask='isTask=1&';
            populationDefinitionSvc.populationDefinitionGetData('search-code-groupers/?'+(item.isTask?isTask:'')+'sourceId='+item.source+''+(item.grouperName?grouperName:'')).then(function(response){
              if(response.data.results){
                scope.modalOptions.selected=[];
                scope.modalOptions.available=response.data.results;
              }
            });
          }

        };
      scope.searchMedicationGroupClear=function(){
          scope.medicationSearch={};
        };
      scope.saveMedicationsGroupers=function(item){
          scope.InsertMedicationGroupers={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':'','radioType':item.durationcost==='0'?'Duration':'Cost','value1':item.durationcost==='0'?!item.value1?'':item.value1:!item.symbol?'':item.symbol,'value2':item.durationcost==='0'?!item.value2?'':item.value2:!item.amount?'':item.amount,'listValues':scope.modalOptions.selected};
          populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.InsertMedicationGroupers).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
        };
      scope.clearAllData=function(){
          scope.medication.value1='';
          scope.medication.value2='';
          scope.medication.symbol='';
          scope.medication.amount='';
        };
      scope.BindPopup();
    }]);
})(window.app);