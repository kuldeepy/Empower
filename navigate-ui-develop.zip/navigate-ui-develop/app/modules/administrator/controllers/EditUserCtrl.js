(
  function (app) {
    /* @fmt: off */
    'use strict';

    // @fmt:on
    app.controller('EditUserCtrl', ['$scope', '$http', 'userMgmtSvc', 'createUserSvc', 'navConstantsSvc', 'authSvc', '$state', '$timeout', '$location', '_','$modal',
      function (scope, http, userMgmtSvc, createUserSvc, navConstantsSvc, authSvc, state, timeout, location, _,$modal) {
        var resetPasswordtWindow;
        scope.active={};
        scope.user = {
          newPassword: '',
          confirm:''
        };

        scope.isUserEmailUnique = true;
        scope.inactivealert='This is the only care manager associated to ';
        scope.inactivealertjoin=' Care Team(s).Please add another active care manager to that Care Team before inactivating/removing this care manager.';
        scope.inactivealertforCareLeadTeam=' is assigned as care lead for patients, and wouldn\'t be allowed to make inactive until not assigned any patients as care lead.';
        scope.isEmailUnique = function(emailAddress){
          scope.isUserEmailUnique = true;
          if(scope.editCtrl.user.emailAddress){
            if (scope.editCtrl.user.emailAddress !== scope.editCtrl.user.emailAddressCopy) {
              scope.editUserDetails.email.$setValidity('required', false);
              createUserSvc.isEmailUnique(emailAddress).then(function (result) {
                scope.isUserEmailUnique = result;
                scope.editUserDetails.email.$setValidity('required', result);
              });
            }else{
              scope.isUserEmailUnique = true;
              scope.editUserDetails.email.$setValidity('required', true);
            }
          }
        };

        scope.checkStatus = function(Value){
          localStorage.setItem('ischangeoptiondirty', true);
          if(Value === 'I'){
            var providerId = _.where(scope.editCtrl.user.roles,{name:navConstantsSvc.careManager});
            if (providerId.length > 0 && providerId[0].providerId) {
              createUserSvc.getActiveCareManagersCount(providerId[0].providerId).then(
                  function(response) {
                      scope.UserCred = response.data.results;
                      var careLeadName;
                      if(scope.UserCred.careTeamNames.length>0){
                        careLeadName=scope.UserCred.careTeamNames[0].careLeadName;
                        if(careLeadName!==null){
                          scope.dangernotification = {
                            visible: true,
                            message: careLeadName+scope.inactivealertforCareLeadTeam
                          };
                          scope.completeStep(!scope.UserCred.status,'editUserCredentials');
                        }else if (scope.UserCred.status) {
                          var programName;
                          programName = _.pluck(scope.UserCred.careTeamNames,'programName');
                          programName = programName.join(', ');
                          scope.dangernotification = {
                            visible: true,
                            message: scope.inactivealert + programName + scope.inactivealertjoin
                          };
                          scope.completeStep(!scope.UserCred.status,'editUserCredentials');
                        }
                      }
                    }
              );
            }
          }
          else{
            scope.completeStep(true,'editUserCredentials');
            scope.dangernotification = {
              visible: false
            };
          }
        };

        var resetFormFields = function()
        {
          if(scope.editCtrl.selectedRoles !== undefined && scope.editCtrl.selectedRoles.length > 0)
          {
            var clinicAdmins = _.where(scope.editCtrl.selectedRoles, {name: navConstantsSvc.clinicAdministrator});
            if(clinicAdmins.length === 0)
            {
              scope.editCtrl.provider = null;
              scope.editCtrl.clinicAdmins = [];
            }
            else
            {
              scope.editCtrl.provider = null;
            }
            var insuranceGroups = _.where(scope.editCtrl.selectedRoles, {name: navConstantsSvc.insuranceGroupProvider});
            if(insuranceGroups.length === 0)
            {
              scope.groupId = null;
              scope.editCtrl.insuranceGroups = [];
            }
            else
            {
              scope.groupId = null;
            }
            var physicians = _.where(scope.editCtrl.selectedRoles, {name: navConstantsSvc.physician});
            if(physicians.length === 0)
            {
              scope.editCtrl.clinicIdForPhysician = null;
              scope.physicianId = null;
              scope.editCtrl.physicianDisabled = true;
              scope.editCtrl.physicians = [];
            }
            else
            {
              scope.editCtrl.physicianDisabled = true;
              scope.editCtrl.clinicIdForPhysician = null;
              scope.physicianId = null;
            }
          }
          else if(scope.editCtrl.selectedRoles !== undefined && scope.editCtrl.selectedRoles.length === 0)
          {
            scope.editCtrl.provider = null;
            scope.editCtrl.clinicAdmins = [];
            scope.editCtrl.clinicIdForPhysician = null;
            scope.physicianId = null;
            scope.editCtrl.physicianDisabled = true;
            scope.editCtrl.physicians = [];
            scope.groupId = null;
            scope.editCtrl.insuranceGroups = [];
          }
        };

        scope.checkUserStatus = function(providerId,role){
          createUserSvc.getActiveCareManagersCount(providerId).then(function(response) {
            scope.active = response.data.results;
            if (scope.active.status) {
              var careLeadName;
              if(scope.active.careTeamNames.length>0){
                careLeadName=scope.active.careTeamNames[0].careLeadName;
                if(careLeadName!==null){
                  scope.notification = {
                    visible: true,
                    message: careLeadName+scope.inactivealertforCareLeadTeam
                  };
                  scope.completeStep(!scope.active.status, state.current.name);
                }else {
                  var programName;
                  programName = _.pluck(scope.active.careTeamNames,'programName');
                  programName = programName.join(', ');
                  scope.notification = {
                    visible: true,
                    message: scope.inactivealert + programName + scope.inactivealertjoin
                  };
                  scope.completeStep(!scope.active.status, state.current.name);
                }
              }
            }
            scope.deleteRoles(role);
          });
        };
        if (scope.initializeStep) {
          if(scope.editCtrl.editStatus === true){
            scope.editCtrl.editStatus = false;
            state.go('editUserSummary');
          }
          if (state.current.name === 'editUserSummary') {
            scope.initializeStep(state.current.name,true);
          }
          else
          {
            scope.initializeStep(state.current.name,false);
            resetFormFields();
            if(state.current.name === 'editUserCredentials' && localStorage.getItem('ischangeoptiondirty')) {
              scope.checkStatus(scope.editCtrl.user.statusCode);
            }
            if(state.current.name === 'editSecurityRoles') {
              var role = _.where(scope.editCtrl.selectedRoles, {name: navConstantsSvc.careManager});
              if(role.length === 0)
              {
                var providerId = _.where(scope.editCtrl.user.roles,{name:navConstantsSvc.careManager});
                if (providerId.length>0 && providerId[0].providerId) {
                  scope.checkUserStatus(providerId[0].providerId,navConstantsSvc.careManager);
                }
              }
            }
          }
        }

        scope.isChecked = function(role) {
          var userRoles = scope.editCtrl.selectedRoles;
          var y = userRoles.length;
          for (var i=0; i<y; i=i+1) {
            if (userRoles[i].name === role.name) {
              return true;
            }
          }
          scope.completeStep(userRoles.length > 0, 'editSecurityRoles');
          if(scope.active.status!==undefined && userRoles.length > 0){
            scope.completeStep(!scope.active.status, state.current.name);
          }
        };
        scope.updateState = function(){
          scope.editCtrl.user.addressState = {};
          var filterData = _.where(scope.editCtrl.states, {Id: scope.editCtrl.user.primaryAddress.stateCode});
          scope.editCtrl.user.addressState = filterData[0];
        };

        scope.updateCountry = function(){
          scope.editCtrl.user.addressCountry = {};
          var filterData = _.where(scope.editCtrl.countries, {id: scope.editCtrl.user.primaryAddress.countryCode});
          scope.editCtrl.user.addressCountry = filterData[0];
        };

        scope.openResetPassword = function()
        {
          scope.user.newPassword = '';
          scope.user.confirm = '';
          showResetPassword();
        };

        scope.cancelResetPassword = function(){
          resetPasswordtWindow.close();
        };

        var showResetPassword = function(){
          resetPasswordtWindow = $modal.open({
            templateUrl: 'resetPasswordModalContent.html',
            size: 'md',
            scope: scope,
            backdrop : 'static'
          });
        };

        scope.hideNotification = function () {
          scope.notification.visible = false;
        };

        var showResetPasswordSuccessNotification = function () {
          scope.notification = {
            visible: true,
            message: 'Password has been reset successfully'
          };
          timeout(function () {
            scope.notification.visible = false;
          }, 6000);
        };

        scope.saveNewPassword = function(){
          var body = {
            userName : scope.editCtrl.user.userName,
            password : scope.user.newPassword
          };
          userMgmtSvc.saveUserPassword(scope.editCtrl.user.userId, body)
          .then(function(){
            resetPasswordtWindow.close();
            showResetPasswordSuccessNotification();
          });
        };

        scope.$watch('editSecurityRoles.$pristine', function () {
          if (scope.editCtrl.roles) {
            if (scope.editCtrl.roles[2].isChecked && scope.editCtrl.clinicAdmins.length === 0) {
              scope.editCtrl.roles[2].isChecked = false;
            }
            if (scope.editCtrl.roles[3].isChecked && scope.editCtrl.physicians.length === 0) {
              scope.editCtrl.roles[3].isChecked = false;
            }
            if (scope.editCtrl.roles[4].isChecked && scope.editCtrl.insuranceGroups.length === 0) {
              scope.editCtrl.roles[4].isChecked = false;
            }
          }
        });

        scope.change = function (role) {
          var userRoles = scope.editCtrl.selectedRoles;
          if (role.isChecked === true) {
            switch (role.name) {
              case navConstantsSvc.administrator:
                userRoles.push(role);
                break;
              case navConstantsSvc.careManager:
                userRoles.push(role);
                scope.active.status=false;
                scope.notification = {
                  visible: false
                };
                scope.isChecked(navConstantsSvc.careManager);
                break;
              case navConstantsSvc.clinicAdministrator:
                scope.editCtrl.clinicDisabled = false;
                break;
              case navConstantsSvc.physician:
                scope.editCtrl.clinicPhysicianDisabled = false;
                break;
              case navConstantsSvc.insuranceGroupProvider:
                scope.editCtrl.insuranceDisabled = false;
                break;
              case 'Analyst':
                userRoles.push(role);
                break;
              case 'Marketing Analyst':
                userRoles.push(role);
                break;
            }
          } else {
            for (var i=0; i<userRoles.length; i=i+1) {
              var currentRole = userRoles[i];
              switch (role.name) {
                case navConstantsSvc.clinicAdministrator:
                  scope.editCtrl.provider = null;
                  scope.editCtrl.clinicDisabled = true;
                  scope.editCtrl.clinicAdmins = [];
                  role.isChecked = false;
                  break;
                case navConstantsSvc.physician:
                  scope.editCtrl.clinicIdForPhysician = null;
                  scope.physicianId = null;
                  scope.editCtrl.clinicPhysicianDisabled = true;
                  scope.editCtrl.physicianDisabled = true;
                  currentRole.physicianId = null;
                  scope.editCtrl.clinicIdForPhysician = null;
                  scope.editCtrl.physicians = [];
                  break;
                case navConstantsSvc.insuranceGroupProvider:
                  scope.groupId = null;
                  scope.editCtrl.insuranceDisabled = true;
                  currentRole.groupId = null;
                  scope.editCtrl.insuranceGroups = [];
                  break;
              }
              if(role.name === navConstantsSvc.careManager) {
                var providerId = _.where(scope.editCtrl.user.roles,{name:navConstantsSvc.careManager});
                if (providerId.length>0 && providerId[0].providerId) {
                  scope.checkUserStatus(providerId[0].providerId,role.name);
                }
                
              }
              else if (currentRole.name === role.name) {
                scope.deleteRoles(role.name);
              }

            }
             
          }
        };

        scope.deleteRoles = function(role){
          var deleteSelectedRole = _.filter(scope.editCtrl.selectedRoles, function (item) {
            return (item.name !== role);
          });
          scope.editCtrl.selectedRoles = deleteSelectedRole;
        };

        scope.addClinicAdmin = function() {
          var checkDuplicate = _.filter(scope.editCtrl.clinicAdmins, function (item) {
            return (item === scope.editCtrl.provider.name);
          });
          if(checkDuplicate.length === 0){
            var roleDetails = _.filter(scope.editCtrl.roles, function (item) {
              return (item.name === navConstantsSvc.clinicAdministrator);
            });
            var userRoles = scope.editCtrl.selectedRoles;
            userRoles.push({id : roleDetails[0].id,name : roleDetails[0].name,providerId : scope.editCtrl.provider.id,providerName : scope.editCtrl.provider.name});
            scope.editCtrl.clinicAdmins.push(scope.editCtrl.provider.name);
            scope.editCtrl.provider = null;
            scope.completeStep(true, 'editSecurityRoles');
          }
        };

        scope.addPhysician = function() {
          if(scope.editCtrl.physicians === undefined){
            scope.editCtrl.physicians = [];
          }
          var checkDuplicate = _.filter(scope.editCtrl.physicians, function (item) {
            return (item === scope.physicianId.organizationName);
          });
          if(checkDuplicate.length === 0){
            var roleDetails = _.filter(scope.editCtrl.roles, function (item) {
              return (item.name === navConstantsSvc.physician);
            });
            var userRoles = scope.editCtrl.selectedRoles;
            userRoles.push({id : roleDetails[0].id,name : roleDetails[0].name,providerId : scope.physicianId.providerID,providerName : scope.physicianId.organizationName});
            scope.editCtrl.physicians.push(scope.physicianId.organizationName);
            scope.physicianId = null;
            scope.editCtrl.physicianDisabled = true;
            scope.editCtrl.clinicIdForPhysician = null;
            scope.completeStep(true, 'editSecurityRoles');
          }
        };

        scope.addInsuranceId = function() {
          if(scope.editCtrl.insuranceGroups === undefined){
            scope.editCtrl.insuranceGroups = [];
          }
          var checkDuplicate = _.filter(scope.editCtrl.insuranceGroups, function (item) {
            return (item === scope.groupId.name);
          });
          if(checkDuplicate.length === 0){
            var roleDetails = _.filter(scope.editCtrl.roles, function (item) {
              return (item.name === navConstantsSvc.insuranceGroupProvider);
            });
            var userRoles = scope.editCtrl.selectedRoles;
            userRoles.push({id : roleDetails[0].id,name : roleDetails[0].name,providerId : scope.groupId.id,providerName : scope.groupId.name});
            scope.editCtrl.insuranceGroups.push(scope.groupId.name);
            scope.groupId = null;
            scope.completeStep(true, 'editSecurityRoles');
          }
        };

        scope.deleteClinicRole = function(provider) {
          localStorage.setItem('isWizardFormDirty', true);
          scope.editCtrl.selectedRoles =_.filter(scope.editCtrl.selectedRoles,function(item){
            return (item.providerName !== provider);
          });
          scope.editCtrl.clinicAdmins = _.filter(scope.editCtrl.clinicAdmins,function(item){
            return item !== provider;
          });
          scope.checkRole(navConstantsSvc.clinicAdministrator,scope.editCtrl.clinicAdmins);
        };

        scope.deleteIGPRole =function(insurance){
          localStorage.setItem('isWizardFormDirty', true);
          scope.editCtrl.selectedRoles = _.filter(scope.editCtrl.selectedRoles,function(item){
            return (item.providerName !== insurance);
          });
          scope.editCtrl.insuranceGroups = _.filter(scope.editCtrl.insuranceGroups,function(item){
            return item !== insurance;
          });
          scope.checkRole(navConstantsSvc.insuranceGroupProvider,scope.editCtrl.insuranceGroups);
        };

        scope.deletePhysicianRole = function(physician) {
          localStorage.setItem('isWizardFormDirty', true);
          scope.editCtrl.selectedRoles = _.filter(scope.editCtrl.selectedRoles,function(item){
            return (item.providerName !== physician);
          });
          scope.editCtrl.physicians = _.filter(scope.editCtrl.physicians,function(item){
            return item !== physician;
          });
          scope.checkRole(navConstantsSvc.physician,scope.editCtrl.physicians);
        };

        scope.checkRole = function(role,data){
          var k, len;
          for (k = 0, len = scope.editCtrl.roles.length; k < len; k = k + 1){
            if(scope.editCtrl.roles[k].name === role){
              scope.editCtrl.roles[k].isChecked = data.length > 0 ? true : false;
            }
          }
        };

        scope.getProviderId = function() {
          var userRoles = scope.editCtrl.selectedRoles;
          for (var i=0; i<userRoles.length; i=i+1) {
            if (userRoles[i].name === navConstantsSvc.clinicAdministrator) {
              userRoles[i].providerId = scope.editCtrl.provider.id;
              userRoles[i].providerName = scope.editCtrl.provider.name;
            }
          }
        };

        scope.getGroupId = function() {

          var userRoles = scope.editCtrl.selectedRoles;
          for (var i=0; i<userRoles.length; i=i+1) {
            if (userRoles[i].name === navConstantsSvc.insuranceGroupProvider) {
              userRoles[i].providerId = scope.groupId;
            }
          }
        };

        scope.getClinicPhysicianId = function() {
          var clinicId = scope.editCtrl.clinicIdForPhysician;
          if (clinicId !== null) {
            // GET physicians
            createUserSvc.physicians(clinicId).then(function(data) {
              scope.physicians = data.physicians;
              scope.editCtrl.physicianDisabled = false;
            });
          }
          scope.physicianId = null;
          scope.editCtrl.physicianDisabled = true;
        };

        scope.getPhysicianId = function() {
          var userRoles = scope.editCtrl.selectedRoles;
          for (var i=0; i<userRoles.length; i=i+1) {
            if (userRoles[i].name === navConstantsSvc.physician) {
              userRoles[i].providerId = scope.physicianId;
            }
          }
        };

        // PUT to /users/userId
        scope.success = false;
        scope.$on('wizardOnsaveAndClose', function() {
          scope.editCtrl.user.roles = scope.editCtrl.selectedRoles;
          scope.editCtrl.user.applicationLink = window.location.origin;
          http
            .put(app.api.root + 'users/' + scope.editCtrl.user.userId, scope.editCtrl.user)
            .then(
              // success
              function() {
                createUserSvc.isAddedSuccesfully = true;
                createUserSvc.messageAlert = 'User has been updated successfully';
                location.path('/admin/users/user/');
              });
          localStorage.removeItem('ischangeoptiondirty');
        });

        scope.$on('wizardOnClose', function() {
          scope.editCtrl.editStatus = false;
          location.path('/admin/users/user');
          localStorage.removeItem('ischangeoptiondirty');
        });

        scope.filterRoles = function(roleName){
          var roleDetails = _.filter(scope.editCtrl.selectedRoles, function (item) {
            return (roleName === item.name);
          });
          return roleDetails;
        };

        scope.$on('wizardOnNext', function() {
          if(state.current.name === 'editSecurityRoles') {
            var i, len;
            for (i = 0, len = scope.editCtrl.roles.length; i < len; i = i + 1){
              if(scope.editCtrl.roles[i].name === navConstantsSvc.clinicAdministrator || scope.editCtrl.roles[i].name === navConstantsSvc.physician || scope.editCtrl.roles[i].name === navConstantsSvc.insuranceGroupProvider){
                var roleDetails = scope.filterRoles(scope.editCtrl.roles[i].name);
                scope.editCtrl.roles[i].isChecked = roleDetails.length > 0 ? true : false;
              }
            }
          }
        });

        scope.$watch('editUserDetails.$pristine', function () {
          if (scope.editUserDetails && !scope.editUserDetails.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$watch('editUserCredentials.$pristine', function () {
          if (scope.editUserCredentials && !scope.editUserCredentials.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$watch('editSecurityRoles.$pristine', function () {
          if (scope.editSecurityRoles && !scope.editSecurityRoles.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$watch('editUserDetails.$valid', function(val) {
          if (scope.completeStep && state.current.name === 'editUserDetails') {
            scope.completeStep(val, 'editUserDetails');
          }
        });

        if(state.current.name === 'editSecurityRoles'){
          scope.completeStep(scope.editCtrl.selectedRoles.length > 0, 'editSecurityRoles');
        }

        scope.$watch('editUserCredentials.$valid', function(val) {
          if (state.current.name === 'editUserCredentials') {
            scope.completeStep(val, 'editUserCredentials');
          }
        });
      }]);

  }(window.app)
);