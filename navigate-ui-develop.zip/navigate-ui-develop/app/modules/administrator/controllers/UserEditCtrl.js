(
  function (app) {
    /* @fmt: off */
    'use strict';

    // @fmt:on
    app.controller('UserEditCtrl', ['$scope', '$http', 'userMgmtSvc', 'createUserSvc',
      function (scope, http, userMgmtSvc, createUserSvc) {

        // ******************************************* EDIT WIZARD FLOW ********************************************
        
        scope.wizardheader = 'Edit User';

        scope.wizardWorkflow = [
          { 'id': 1, 'name': 'editUserDetails' },
          { 'id': 2, 'name': 'editUserCredentials' },
          { 'id': 3, 'name': 'editSecurityRoles' },
          { 'id': 4, 'name': 'editUserSummary' }
        ];

        //Tab and Step Definitions
        scope.tabDefinitions = [
          { name: 'editUserDetails', number: '1', title: 'User Details', selectionCss: 'first active', completed: true, clickable:true, isTabCompleted:true },
          { name: 'editUserCredentials', number: '2', title: 'User Credentials', selectionCss: 'inactive', completed: true, clickable:true, isTabCompleted:true },
          { name: 'editUserSummary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: true, clickable:true, isTabCompleted:true }
        ];

        scope.stepDefinitions = [
          //Select Ideal Target task type Tab
          [
            { name: 'editUserDetails', letter: 'a', title: 'User Details', selectionCss: 'active', completed: true, clickable:true, isTabCompleted:true }
          ],
          [
            { name: 'editUserCredentials', letter: 'a', title: 'Credentials', selectionCss: 'active', completed: true, clickable:true, isTabCompleted:true  },
            { name: 'editSecurityRoles', letter: 'b', title: 'Security Role(s)', selectionCss: 'active', completed: true, clickable:true, isTabCompleted:true  }
          ],
          //Define summary Tab
          [
            { name: 'editUserSummary', letter: 'a', title: 'Summary', selectionCss: 'active', completed: true, clickable:true, isTabCompleted:true  }
          ]
        ];

        // ******************************************* END WIZARD FLOW ********************************************

        var _this = this;

        scope.editUserId = userMgmtSvc.editUserId;

        _this.clinicDisabled = true;
        _this.clinicPhysicianDisabled = true;
        _this.physicianDisabled = true;
        _this.insuranceDisabled = true;
        _this.editStatus = true;
        _this.providerId = null;
        _this.groupId = null;
        _this.physicians = [];
        _this.insuranceGroups = [];
        _this.clinicAdmins = [];

        // INITIALIZE EDIT USER FORMS
        userMgmtSvc.user(scope.editUserId.id || sessionStorage.getItem('editUser')).then(function (data) {
          scope.isEdit = true;
          data.emailAddressCopy = data.emailAddress;
          _this.user = data;
          
          // GET states
          createUserSvc.states().then(function(data) {
            _this.states = data;
            if(_this.user.primaryAddress){
              _this.user.addressState =  _.findWhere(_this.states,{Id: _this.user.primaryAddress.stateCode});
            }
          });

          // GET countries
          createUserSvc.countries().then(function(data) {
            _this.countries = data;
            if(_this.user.primaryAddress){
              _this.user.addressCountry =  _.findWhere(_this.countries,{id: _this.user.primaryAddress.countryCode});
            }
          });

          // GET roles
          createUserSvc.roles().then(function(data) {
            _this.roles = data;
          });

          // GET insurance groups
          createUserSvc.insuranceGroups().then(function(data) {
            _this.insuranceGroupsDetails = data;
          });

          _this.selectedRoles = _this.user.roles;

          // GET clinics
          createUserSvc.clinics().then(function(data) {
            createUserSvc.insuranceGroups().then(function(data1) {
              _this.clinics = data;
              var IGP = [];
              for (var i=0; i<_this.selectedRoles.length; i=i+1) {
                switch (_this.selectedRoles[i].name) {
                  case 'Clinic Administrator':
                    _this.providerId = _this.selectedRoles[i].providerId;
                    _this.clinicDisabled = false;
                    for (var x=0; x<_this.clinics.length; x=x+1) {
                      if (_this.clinics[x].id === _this.providerId) {
                        _this.clinicAdmins.push(_this.clinics[x].name);
                      }
                    }
                    break;
                  case 'Physician':
                    _this.physicians.push(_this.selectedRoles[i].providerName);
                    _this.physicianId = _this.selectedRoles[i].providerId;
                    _this.clinicPhysicianDisabled = false;
                    _this.physicianDisabled = true;
                    break;
                  case 'Insurance Group Provider':

                    scope.selectedIGP=_.where(data1,{id :_this.selectedRoles[i].providerId  });
                    if(scope.selectedIGP.length > 0){
                      IGP.push(scope.selectedIGP[0]);
                      _this.insuranceGroups=_.pluck(IGP, 'name');
                      _this.insuranceDisabled = false;
                    }
                    break;
                  
                }
              }
              var k, len;
              for (k = 0, len = _this.roles.length; k < len; k = k + 1){
                var roleDetails = scope.filterRoles(_this.roles[k].name);
                if(_this.roles[k].name === 'Clinic Administrator' || _this.roles[k].name === 'Physician' || _this.roles[k].name === 'Insurance Group Provider'){
                  _this.roles[k].isChecked = roleDetails.length > 0 ? true : false;
                }
              }
            });
          });
        });
        
        scope.filterRoles = function(roleName){
          var roleDetails = _.filter(_this.selectedRoles, function (item) {
            return (roleName === item.name);
          });
          return roleDetails;
        };

      }]);

  }(window.app)
);