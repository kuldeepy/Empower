(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('mapResolveTaskConflictsCtrl', ['$scope', 'managedPopulationSvc', '_', '$state', '$location', '$modal', '$rootScope',
    function (scope, managedPopulationSvc, _, state, location, $modal, $rootScope) {

      scope.persistedTaskReminders = [];
      scope.taskConflictsCount = -1;
      
      var csvTaskBundleIds = _.map(scope.mngpopCtrl.managedPopulation.taskBundles, function(num){ return num.id; }).join(',');
      
      if (scope.initializeStep) {
        scope.initializeStep('mapResolveTaskConflicts', false);
      }

      scope.init = function () {
        scope.completeStep(true, 'mapResolveTaskConflicts');
      };

      scope.getAllTaskConflicts = function(){
        managedPopulationSvc.getTaskConflicts(csvTaskBundleIds).then(function(response){
          managedPopulationSvc.taskConflicts = response.data.results;
          scope.groupTaskConflicts();
        });
      };

      var resolvedConflictsFunction = function(tasks,conflictsToResolve,nonTaskConflicts){
        var conflictsToResolveGrouped = _.groupBy(tasks,'typeName');
        _.forEach(conflictsToResolveGrouped, function(item) {
          if(item.length > 1){
            conflictsToResolve.push(item);
          }else{
            _.forEach(item, function(items) {
              nonTaskConflicts.push(items);
            });
          }
        });
        return {'conflictsToResolve': conflictsToResolve,'nonTaskConflicts': nonTaskConflicts};
      };

      scope.groupTaskConflicts = function(){
        if(managedPopulationSvc.taskConflicts.length >0){
          var totalData = [];
          _.forEach(managedPopulationSvc.taskConflicts, function(item) {
            totalData.push({copyInclude: item.copyInclude, frequency: item.frequency, frequencyNumber: item.frequencyNumber, frequencyOrder: item.frequencyOrder, frequencyTitration: item.frequencyTitration, id: item.id, isConflict: item.isConflict, recurrenceType: item.recurrenceType, scheduledDays: item.scheduledDays, taskBundleId: item.taskBundleId, taskBundleName: item.taskBundleName, taskName: item.taskName, taskType: item.taskType, taskTypeGeneralizedId: item.taskTypeGeneralizedId, typeId: item.typeId, typeName: item.typeName, uniqueId: item.uniqueId, taskDeleted: (item.taskDeleted !== undefined ? item.taskDeleted : false)});
          });
          managedPopulationSvc.taskConflicts = totalData;
          var conflictsToResolve = [] , conflictsToResolveGrouped = [];
          conflictsToResolveGrouped = resolvedConflictsFunction(managedPopulationSvc.taskConflicts, [], []);
          conflictsToResolve = conflictsToResolveGrouped.conflictsToResolve;
          managedPopulationSvc.nonTaskConflicts = conflictsToResolveGrouped.nonTaskConflicts;
          scope.groupedConflicts = conflictsToResolve;
          scope.taskConflictsCount = _.keys(conflictsToResolve).length;
          saveTaskBundleConflictResolution();
        }
      };

      if(!managedPopulationSvc.taskResolvedEdit){
        if(managedPopulationSvc.taskConflicts.length < 1) { scope.getAllTaskConflicts(); }
        else{
          scope.groupedConflicts = managedPopulationSvc.taskResolvedGrouped;
          scope.groupTaskConflicts();
        }
      }else{
        scope.completeStep(true, 'mapResolveTaskConflicts');
      }

      scope.$on('wizardOnNext', function() {
        if(!managedPopulationSvc.taskResolvedEdit){
          saveTaskBundleConflictResolution();
        }
      });
       
      scope.$on('wizardOnPrev', function() {
        scope.groupTaskConflicts();
      });

      scope.$on('wizardOnClose', function () {
        if (app !== undefined && app.currentRoute !== undefined) {
          location.url(app.currentRoute + '/configuration/population');
        }
        else {
          location.url('/admin/configuration/population');
        }
      });

      function saveTaskBundleConflictResolution() {
        var resolvedTaskConflicts = [];
        _.forEach(scope.groupedConflicts, function(value) {
          var result = _.filter(value, function (item) {
            return item.taskDeleted === false;
          });
          if(result.length > 1){
            _.forEach(result, function(items) {
              resolvedTaskConflicts.push(items);
            });
          }
          else {
            _.forEach(result, function(items) {
              resolvedTaskConflicts.push(items);
            });
          }
        });
        managedPopulationSvc.nonTaskConflicts.forEach(function(res){
          resolvedTaskConflicts.push(res);
        });
        var resolvedConflicts = {
          managedPopulationId : managedPopulationSvc.managedPopulationId,
        };
        resolvedConflicts.tasks = managedPopulationSvc.taskConflictsResolved =  resolvedTaskConflicts;
        scope.mngpopCtrl.managedPopulation.tasksResolvedConflicts = resolvedConflicts.tasks;
        managedPopulationSvc.taskResolvedGrouped = scope.groupedConflicts;
      }

      var proceedWithConflicts = false;
      var nextDesiredState = null;

      scope.checkForUnresolvedConflicts = function() {
        if (hasUnresolvedConflicts() && !proceedWithConflicts) {
          scope.confirmConflictsModal = $modal.open({
            templateUrl: 'confirmConflicts.html',
            scope: scope,
            backdrop: 'static',
            keyboard: false,
            action: 'show'
          });
          return false;
        }
        return true;
      };

      $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState) {
        if (fromState.name === 'mapResolveTaskConflicts') {
          var shouldProceed = scope.checkForUnresolvedConflicts();
          if (!shouldProceed) {
            nextDesiredState = toState;
            event.preventDefault();
          }
        }
      });

      function hasUnresolvedConflicts() {
        return _.some(_.values(scope.groupedConflicts), function(group) {
          return _.filter(group, function(conflict) {
            return !conflict.taskDeleted;
          }).length > 1;
        });
      }

      scope.confirmConflicts = function(proceed) {
        if (scope.confirmConflictsModal) {
          scope.confirmConflictsModal.close();
        }
        proceedWithConflicts = proceed;
        if (proceedWithConflicts) {
          if (nextDesiredState) {
            state.go(nextDesiredState);
          } else {
            scope.goToNext();
          }
        }
      };

    }]);
  }(window.app));