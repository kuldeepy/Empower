(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('AuditSessionCtrl', ['$scope', 'auditSvc', 'exportSvc', '_',
      function (scope, auditSvc, exportSvc, _) {

        function getUserSessionFilters() {

          var name = scope.search.name ? scope.search.name.split(', ') : [undefined, undefined];
 
          return {
            firstName: name[1],
            lastName: name[0],
            status: scope.search.sessionStatus,
            startDate: scope.search.dateFrom.value ? window.moment(scope.search.dateFrom.value).format('YYYY-MM-DD') : undefined,
            endDate:
              //Add a day so the upper limit includes the end date
              scope.search.dateTo.value ?
                window.moment(scope.search.dateTo.value)
                .add(1, 'day')
                .format('YYYY-MM-DD')
              : undefined,
            pageSize: scope.scroller.dataChunkSize,
            pageIndex: scope.scroller.dataChunkIndex
          };
        }

        function loadMoreSessions() {
          scope.scroller.pause = true;
          if (scope.scroller.dataChunkSize * scope.scroller.dataChunkIndex <= scope.scroller.totalElements) {

            var filters = getUserSessionFilters();

            auditSvc.sessions(filters)
            .then(function(results) {
              _.forEach(results.sessions, formatDate);
              _.forEach(results.sessions, formatSessionState);
              scope.sessions = scope.sessions.concat(results.sessions);
              scope.scroller.totalElements = results.totalSessionCount;
              scope.scroller.pause = false;
            });

            scope.scroller.dataChunkIndex += 1;
          }
        }

        scope.pageTitle = 'User Sessions';

        scope.sessionTable = {
          columns: ['Login Date', 'Username', 'First Name', 'Last Name', 'IP Address', 'Session Status', 'Logout Date'],
        };

        scope.search = {
          isOpen: true,
          names: [],
          sessionStatus: null,
          dateFrom: {
            opened: false,
            value: null,
            maxDate: new Date(),
            format: 'MM/dd/yyyy'
          },
          dateTo: {
            opened: false,
            value: null,
            maxDate: new Date(),
            format: 'MM/dd/yyyy'
          }
        };

        scope.scroller = {
          more: loadMoreSessions,
          totalElements: 0,
          pause: false,
          dataChunkSize: 40,
          dataChunkIndex: 0
        };

        scope.sessions = [];

        function formatDate(session) {
          session.loginDate = window.moment(session.loginDate).format('M/D/YYYY h:mm:ss A');
          if (session.logoutDate) {
            session.logoutDate = window.moment(session.logoutDate).format('M/D/YYYY h:mm:ss A');
          }
        }

        function formatSessionState(session) {
          if (session.loginStatus === 201) {
            session.status = 'Logged In';
          }
          else if (session.loginStatus === 204) {
            session.status = 'Logged Out - ' + session.logoutType;
          }
          else if (session.loginStatus >= 400 && session.loginStatus < 500) {
            session.status = 'Login Failure - Client Error';
          }
          else if (session.loginStatus >= 500) {
            session.status = 'Login Failure - Server Error';
          }
        }

        scope.openDateFromPopout = function($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateFrom.opened = !scope.search.dateFrom.opened;
        };

        scope.openDateToPopout = function($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateTo.opened = !scope.search.dateTo.opened;
        };

        scope.clearSearchFields = function() {
          scope.search.name = null;
          scope.search.sessionStatus = null;
          scope.search.dateFrom.value = null;
          scope.search.dateTo.value = null;
          scope.applyFilters();
        };

        scope.applyFilters = function() {
          scope.sessions = [];
          scope.scroller.pause = false;
          scope.scroller.totalElements = 0;
          scope.scroller.dataChunkIndex = 0;
          scope.scroller.more();
        };

        /* function to get excel data */
        scope.downloadExcel=function() {
          var filters = getUserSessionFilters();
          filters.isExport = true;

         
          auditSvc.sessionsExport(filters).then(function() {
          },
          // ERROR
          function (error) {
            var errorData = null;
            var errorObject = null;
            if(error !== null && error.data !== null)
            {
              errorData = String.fromCharCode.apply(null, new Uint16Array(error.data));
              errorObject = angular.fromJson(errorData);
            }

            if(errorData === null || errorObject.developerMessage === 'Timeout expired.  The timeout period elapsed prior to completion of the operation or the server is not responding.')
            {
              scope.ADMainCtrl.errorNotification = 'Query requested is too large. Server timed out. Please select a smaller Date Range.';
            }
          });
        };

        (function populateSearchData() {
          scope.search.sessionStatuses = [];
          scope.search.sessionStatuses.push('Logged In');
          scope.search.sessionStatuses.push('Logged Out');
          scope.search.sessionStatuses.push('Login Failure - Client Error');
          scope.search.sessionStatuses.push('Login Failure - Server Error');

          auditSvc.userActivityUserNames().then(function(names) {
            _.forEach(names, function(name) {
              scope.search.names.push(name.lastName + ', ' + name.firstName);
            });
          });
        }());
        
      }]);

  }(window.app)
);