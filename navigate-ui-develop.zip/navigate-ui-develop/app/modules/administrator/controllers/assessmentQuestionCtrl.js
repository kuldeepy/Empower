(
  function(app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('assessmentQuestionCtrl', ['$scope', '$state', '$location', 'assessmentBuilderSvc','_',
      function(scope, state, location, assessmentBuilderSvc,_) {

        scope.answerTypeListData = [];
        scope.readonlyInput = true;
        scope.questions = angular.copy(scope.assessmentData.assessment.questions);

        function trackIsOpen(question) {
          var isOpen = false;
          if(!_.has(question,'isOpen'))
          {
            Object.defineProperty(question, 'isOpen', {
              get: function() {
                return isOpen;
              },
              set: function(newValue) {
                isOpen = newValue;
                if (isOpen) {
                  scope.activeQuestion = question;
                }
              }
            });
          }
          question.isOpen = isOpen;
        }
        
        scope.questions.forEach(trackIsOpen);
        if(scope.questions.length > 0 && state.params.questionIndex){
          scope.questions[state.params.questionIndex].isOpen = true;
        }
        scope.sortableConfig = {
          animation: 150,
          handle: '.drag-handle',
          onSort: function() {
            _.each(scope.questions, function(question, index) {
              question.sortOrder = index + 1;
            });
            scope.assessmentData.assessment.questions = angular.copy(scope.questions);
          }
        };

        if (scope.initializeStep) {
          scope.addNewQuestion = false;
          scope.initializeStep(state.current.name, false);
        }

        // Go get the answerTypeListData
        assessmentBuilderSvc.getAnswerTypeList().then(function(response) {
          response.data.results.forEach(function(item) {
            if (_.findWhere(scope.assessmentData.answerTypeUI, {
                'db': item.answerTypeText
              })) {
                item.answerTypeText = _.findWhere(scope.assessmentData.answerTypeUI, {
                  'db': item.answerTypeText
                }).ui;
                scope.answerTypeListData.push(item);
              }
          });
        });


        scope.$watch('assessmentQuestions.$pristine', function () {
          if (scope.assessmentQuestions && !scope.assessmentQuestions.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.addQuestion = function() {
          scope.addNewQuestion = true;
          var question = {
            status: 'A',
            text: '',
            isMandatory: false,
            isCCMReport: false,
            uniqueId: '',
            answerTypeId: 1,
            answerTypeText: 'Text Box',
            sortOrder: scope.questions.length + 1,
            options: [{
              value: '',
              sortOrder: 1,
              status: 'A',
              uniqueId: '',
              score: ''
            }]
          };
          trackIsOpen(question);
          question.isOpen = true;
          scope.questions.push(question);
          validateAll();
        };

        scope.addAnswer = function(currentAnswers) {
          if (currentAnswers) {
            var answer = {
              value: '',
              sortOrder: currentAnswers.length + 1,
              status: 'A',
              uniqueId: '',
              score: ''
            };
            currentAnswers.push(answer);
            validateAll();
          }
        };

        scope.deleteQuestion = function(currentQuestion) {
          if (currentQuestion) {
            var currentQuestionIndex = scope.questions.indexOf(currentQuestion);
            scope.questions.splice(currentQuestionIndex, 1);
            scope.assessmentData.assessment.questions = angular.copy(scope.questions);
            validateAll();
          }
        };

        scope.deleteAnswer = function(currentQuestion, currentAnswer) {
          if (currentQuestion && currentAnswer) {
            var currentQuestionIndex = scope.questions.indexOf(currentQuestion);
            var currentAnswerIndex = scope.questions[currentQuestionIndex].options.indexOf(currentAnswer);
            scope.questions[currentQuestionIndex].options.splice(currentAnswerIndex, 1);
            scope.assessmentData.assessment.questions = angular.copy(scope.questions);
            validateAll();
          }
        };

        // set the answerTypeText to the right
        scope.setAnswerTypeText = function(currentQuestion) {
          
          scope.currentQuestion = currentQuestion;

          if(currentQuestion.id){
            $('.assesmentBulder').modal({
              backdrop: 'static',
              keyboard: false
            });
          }else{
            scope.confirmYes();
          }
          
        };

        scope.confirmYes = function(){
          scope.currentQuestion.options=[];
          scope.currentQuestion.answerTypeText = _.findWhere(scope.answerTypeListData, {
            answerTypeId: scope.currentQuestion.answerTypeId
          }).answerTypeText;
          scope.assessmentData.assessment.questions = angular.copy(scope.questions);
          scope.addAnswer(scope.currentQuestion.options);
          validateAll();
          $('.assesmentBulder').modal('hide');
        };

        scope.confirmCancel = function(){
          scope.currentQuestion.answerTypeText = _.findWhere(scope.assessmentData.assessment.questions, {
            id:scope.currentQuestion.id
          }).answerTypeText;
          scope.currentQuestion.answerTypeId = _.findWhere(scope.assessmentData.assessment.questions, {
            id:scope.currentQuestion.id
          }).answerTypeId;
          $('.assesmentBulder').modal('hide');
        };

        scope.questionUniqueIdChanged = function(index) {
          if(scope.addNewQuestion){
            if (!scope.activeQuestion) {
              return;
            }
            checkZeroUniqueId(scope.activeQuestion);
            checkUniqueId(scope.questions);
            validateAll();
          }
          else{
            scope.assessmentData.assessment.questions = angular.copy(scope.questions);
            checkZeroUniqueId(scope.questions[index]);
            checkUniqueId(scope.questions);
            validateAll();
          }
        };

        scope.answerUniqueIdChanged = function(answer) {
          if (!scope.activeQuestion) {
            return;
          }
          scope.assessmentData.assessment.questions = angular.copy(scope.questions);
          checkZeroUniqueId(answer);
          checkUniqueId(scope.activeQuestion.options);
          validateAll();
        };

        function checkZeroUniqueId(item) {
          item.uniqueIdIsZero = false;
          if (item.uniqueId !== undefined) {
            if (item.uniqueId.toString() === '0') {
              item.uniqueIdIsZero = true;
            }
          }
        }

        function checkUniqueId(group) {
          group.forEach(function(item) {
            item.uniqueIdNotUnique = false;
            if (item.uniqueId !== undefined && item.uniqueId !== '' ) {
              var match = _.find(group, function(other) {
                return other !== item && other.uniqueId.toString() === item.uniqueId.toString();
              });
              if (match) {
                item.uniqueIdNotUnique = true;
              }
            }
          });
          scope.assessmentData.assessment.questions = scope.questions;
        }

        scope.questionTextChanged = function() {
          scope.assessmentData.assessment.questions = angular.copy(scope.questions);
          validateAll();
        };

        scope.answerScoreChanged = function() {
          scope.assessmentData.assessment.questions = angular.copy(scope.questions);
          validateAll();
        };

        scope.answerValueChanged = function() {
          scope.assessmentData.assessment.questions = angular.copy(scope.questions);
          validateAll();
        };

        scope.questionIsMandatory = function() {
          scope.assessmentData.assessment.questions = angular.copy(scope.questions);
        };
        
        function validateAll() {
          var allValid = scope.questions.length > 0;
          if (allValid) {
            scope.questions.forEach(function(q) {
              if (!q.text) {
                allValid = false;
              }
              if (q.uniqueIdNotUnique) {
                allValid = false;
              }
              if (q.uniqueIdIsZero) {
                allValid = false;
              }
              if (q.options.length === 0) {
                allValid = false;
              }
              q.options.forEach(function(o) {
                if ((!o.value) && (q.answerTypeId === 2 || q.answerTypeId === 4 || q.answerTypeId === 9)) {
                  allValid = false;
                }
                if(o.score < 0 || o.score === ''){
                  allValid = false;
                }
                if (o.uniqueIdNotUnique) {
                  allValid = false;
                }
                if (o.uniqueIdIsZero) {
                  allValid = false;
                }
              });
            });
          }
          scope.completeStep(allValid, state.current.name);
        }
        
        validateAll();

        scope.$on('wizardOnClose', function() {
          if (app !== undefined && app.currentRoute !== undefined) {
            location.url(app.currentRoute + '/library/assessment');
          } else {
            location.url('/library/assessment');
          }
        });
      }
    ]);
  }(window.app));