(function (app) {
  'use strict';
  
  app.controller('Labs', ['$scope','$modalInstance','$window','$http','listStateSvc','populationDefinitionSvc',function(scope,modalInstance,$window,http,listStateSvc,populationDefinitionSvc){
      var tempModalOptions = {};
      scope.modalOptions = tempModalOptions;
      scope.lastOperatorDD=[];
      scope.timeInMs = 0;
      scope.BindPopup=function(){
          switch(scope.criteriaName){
          case 'LOINC':
            scope.loinc={};
            scope.loinc.isequal='Equals';
            tempModalOptions.options = [];
            tempModalOptions.selectedOptions=[];
            tempModalOptions.selectedData = [];
            tempModalOptions.placeholder='Enter 3 chars min';
            tempModalOptions.available=[];
            tempModalOptions.selected=[];
            scope.modalOptions = tempModalOptions;
            scope.modalOptions.httptest=http;
            scope.multiselect={'url':'loinc-codes','http':scope.modalOptions.httptest,'checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.available,'selectedavailabledata':scope.modalOptions.selected};
            scope.loinc.operator='AND';
            scope.BindOperators();
            scope.loincPopUp=true;
            break;
          case 'Lab Groupers':
            scope.labsearch={};
            scope.labGroupers={};
            scope.labGroupers.operator='AND';
            scope.labGroupers.isequal='Equals';
            populationDefinitionSvc.populationDefinitionGetData('code-grouping-source/?searchText=Lab Groupers').then(function(response){
              if(response.data.results){
                scope.soureceDD=response.data.results;
                scope.BindOperators();
              }
            });
            tempModalOptions.available=[];
            tempModalOptions.selected=[];
            scope.LabGroupers=true;
            break;
          }
        };
      scope.modalOptions.close = function () {
          modalInstance.dismiss('cancel');
        };
       
      scope.Addloincs=function(item){
            scope.insertData={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':item.isequal==='Equals'?'Equals':'Not Equals','times':!item.isduration?'':!item.value1?'':item.value1,'days':!item.isduration?'':!item.value2?'':item.value2,'costOperator':'','costInput':'','valueOperator1':!item.value?'':item.symbol1,'valueInput1':!item.value?'':!item.symbol1?'':item.valueInput1,'valueLogicalOperator':!item.value?'':item.operator,'valueOperator2':!item.value?'':item.symbol2,'valueInput2':!item.value?'':!item.symbol2?'':item.valueInput2,'listValues':scope.multiselect.selectedavailabledata};
            populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/labs-criteria',scope.insertData).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
          };

      scope.searchLabGroupers=function(item){
          if(item && item.source){
            var grouperName='&groupersText='+item.grouperName;
            var isTask='isTask=1&';
            scope.modalOptions.available=[];
            populationDefinitionSvc.populationDefinitionGetData('search-code-groupers/?'+(item.isTask?isTask:'')+'sourceId='+item.source+''+(item.grouperName?grouperName:'')).then(function(response){
              if(response.data.results){
                scope.modalOptions.selected=[];
                scope.modalOptions.available=response.data.results;
              }
            });
          }

        };
      scope.searchLabGroupClear=function(){
          scope.labsearch={};
        };
      scope.savelabGroupers=function(item){
          scope.InsertLabGroupers={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':item.isequal==='Equals'?'Equals':'Not Equals','times':!item.isduration?'':!item.value1?'':item.value1,'days':!item.isduration?'':!item.value2?'':item.value2,'costOperator':'','costInput':'','valueOperator1':!item.value?'':item.symbol1,'valueInput1':!item.value?'':!item.symbol1?'':item.valueInput1,'valueLogicalOperator':!item.value?'':item.operator,'valueOperator2':!item.value?'':item.symbol2,'valueInput2':!item.value?'':!item.symbol2?'':item.valueInput2,'listValues':scope.modalOptions.selected};
          populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/labs-criteria',scope.InsertLabGroupers).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
        };
      scope.BindOperators=function(){
          populationDefinitionSvc.populationDefinitionGetData('operators').then(function(response){
              if(response.data.results){
                scope.amountSymbolsDD=response.data.results;
                scope.lastOperatorDD=[{'id':1,'name':'AND'},{'id':2,'name':'OR'}];
              }
            });
        };
      scope.clearLoincDurationdata=function(){
        if(!scope.loinc.isduration){
          scope.loinc.time = '';
          scope.loinc.days = '';
          scope.loinc.value1 = '';
          scope.loinc.value2 = '';
        }
      };
      scope.clearLoincValues=function(){
        if(!scope.loinc.value){
          scope.loinc.symbol1 = '';
          scope.loinc.valueInput1 = '';
          scope.loinc.operator = 'AND';
          scope.loinc.symbol2 = '';
          scope.loinc.valueInput2 = '';
        }
      };
      scope.clearLabDurationdata=function(){
        if(!scope.labGroupers.isduration){
          scope.labGroupers.time = '';
          scope.labGroupers.days = '';
          scope.labGroupers.value1 = '';
          scope.labGroupers.value2 = '';
        }
      };
      scope.clearLabValues=function(){
        if(!scope.labGroupers.value){
          scope.labGroupers.symbol1 = '';
          scope.labGroupers.valueInput1 = '';
          scope.labGroupers.operator = 'AND';
          scope.labGroupers.symbol2 = '';
          scope.labGroupers.valueInput2 = '';
        }
      };
      scope.clearcost=function(){
        if(!scope.labGroupers.iscost){
          scope.labGroupers.costOperator='';
          scope.labGroupers.costInput='';
        }
      };

      scope.BindPopup();
    }]);
})(window.app);