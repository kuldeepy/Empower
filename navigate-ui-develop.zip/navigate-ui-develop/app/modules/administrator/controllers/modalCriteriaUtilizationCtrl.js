(function (app) {
  'use strict';
  
  app.controller('Utilization', ['$scope','$modalInstance','$window','listStateSvc','populationDefinitionSvc',function(scope,modalInstance,$window,listStateSvc,populationDefinitionSvc){
        var tempModalOptions = {};
        scope.modalOptions = tempModalOptions;
        scope.timeInMs = 0;
        scope.utilizationSearch={};
        scope.utilization={};
        scope.utilization.durationcost='0';
        populationDefinitionSvc.populationDefinitionGetData('code-grouping-source/?searchText=Utilization Groupers').then(function(response){
          if(response.data.results){
            scope.soureceDD=response.data.results;
            populationDefinitionSvc.populationDefinitionGetData('operators').then(function(responseoperator){
              if(responseoperator.data.results){
                scope.amountSymbolsDD=responseoperator.data.results;
              }
            });
          }
        });
        tempModalOptions.available=[];
        tempModalOptions.selected=[];
        scope.medicationGroup=true;
        
        scope.searchUtilizationGroup=function(item){
          if(item && item.source){
            var grouperName='&groupersText='+item.grouperName;
            var isTask='isTask=' + (item.isTask ? 1 : 0) + '&';
            populationDefinitionSvc.populationDefinitionGetData('search-code-groupers/?' + isTask + 'sourceId=' + item.source+''+(item.grouperName?grouperName:'')).then(function(response){
              if(response.data.results){
                scope.modalOptions.selected=[];
                scope.modalOptions.available=[];
                scope.modalOptions.available=response.data.results;
              }
            });
          }
        };

        scope.modalOptions.close = function () {
          modalInstance.dismiss('cancel');
        };

        scope.searchGroupClear=function(){
          scope.utilizationSearch={};
        };
        scope.saveUtilizationGroupers=function(item){
            scope.InsertUtilizationGroupers={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':'','radioType':item.durationcost==='0'?'Duration':'Cost','value1':item.durationcost==='0'?!item.value1?'':item.value1:!item.symbol?'':item.symbol,'value2':item.durationcost==='0'?!item.value2?'':item.value2:!item.amount?'':item.amount,'listValues':scope.modalOptions.selected};
            populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.InsertUtilizationGroupers).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
          };
        scope.clearCommon=function(){
          scope.utilization.value1='';
          scope.utilization.value2='';
          scope.utilization.symbol='';
          scope.utilization.amount='';
        };
        
      }]);
})(window.app);