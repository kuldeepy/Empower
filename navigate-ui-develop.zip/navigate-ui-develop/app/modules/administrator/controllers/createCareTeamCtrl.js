(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('CareTeamDetailsCtrl', ['$scope', '$state','modalService','$location', 'listStateSvc','httpRequestSvc','careTeamSvc',
      function (scope, state, modalService,location,listStateSvc,httpRequestSvc,careTeamSvc) {
        scope.tempCareManagers = [];
       
        var currentListState = listStateSvc.get();
        scope.memberlistCount = 1;
        scope.isValidCareTeam = false;

        var getDetails = function(){
          var careTeamId = currentListState.CurrentUIState.careTeamDetails.id;
          if(careTeamId > 0)
          {
            scope.careCtrl.careTeamHeader = 'Edit Care Team';
            if(currentListState.CurrentUIState.careTeamDetails.careTeamStatus === true){
              scope.careCtrl.careTeamPost.id=currentListState.CurrentUIState.careTeamDetails.id;
              scope.careCtrl.careTeamPost.name=currentListState.CurrentUIState.careTeamDetails.name;
              scope.careCtrl.careTeamPost.description=currentListState.CurrentUIState.careTeamDetails.description;
              scope.careCtrl.careTeamPost.status=currentListState.CurrentUIState.careTeamDetails.status;
              scope.careCtrl.careTeamPost.careManagers = currentListState.CurrentUIState.careTeamDetails.careManagers;
              currentListState.CurrentUIState.careTeamDetails = {};
              listStateSvc.set(currentListState);
            }
          }
          else
          {
            scope.tempCareManagers = scope.careCtrl.careTeamPost.careManagers;
            if(scope.tempCareManagers.length > 0){
              if(scope.tempCareManagers[scope.tempCareManagers.length-1].isTrue !== true || scope.tempCareManagers[scope.tempCareManagers.length-1].isTrue === undefined)
              {
                scope.tempCareManagers.push({id: '',name: null,emailAddress: null,isCareSupervisor: false,isNew: true,isTrue: true});
              }
            }
            else
            {
              scope.tempCareManagers.push({id: '',name: null,emailAddress: null,isCareSupervisor: false,isNew: true,isTrue: true});
            }
            if (state.current.name === 'adminCareTeamSummary') {
              var result = [];
              scope.careCtrl.careTeamPost.careManagers.forEach(function(item){
                if(item.isTrue !== true){
                  result.push(item);
                }
              });
              scope.careCtrl.careTeamPost.careManagers = result;
            }
          }
        };

        if (scope.initializeStep) {
          if(currentListState.CurrentUIState.careTeamDetails.currentState === 'adminCareTeamSummary'){
            state.go('adminCareTeamSummary');
          }
          if(state.current.name === 'adminCareTeamSummary'){
            scope.initializeStep(state.current.name,true);
          }else{
            scope.initializeStep(state.current.name,false);
          }
          getDetails();
        }

        scope.$watch('createCareTeam.$pristine', function () {
          if (scope.createCareTeam && !scope.createCareTeam.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$watch('careTeamDetails.$pristine', function () {
          if (scope.careTeamDetails && !scope.careTeamDetails.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$watch('createCareTeam.$valid', function (val) {
          scope.checkCareTeamNameExist();
          if (state.current.name === 'adminCareTeamName' && !scope.isCareTeamExists) {
            scope.completeStep(val, 'adminCareTeamName');
          }
        });

        scope.$watch('careTeamDetails.$valid', function (val) {
          if (state.current.name === 'adminCareTeamDetails' && scope.tempCareManagers.length > 1) {
            scope.getCareTeamDetails();
            scope.completeStep(val, 'adminCareTeamDetails');
          }
        });

        scope.membersPageSize = 10;
        scope.membersPage = 1;
        scope.membersTable = {
          columns : ['Name', 'Email', 'Supervisor', 'Action']
        };

        scope.memberssummaryTable = {
          columns : ['Name', 'Email', 'Supervisor']
        };

        scope.deleteAssignedMembers = function(index){
          var careDetails=[];
          scope.tempCareManagers.forEach(function(item){
            if(item.id !== index.id){
              careDetails.push(item);
            }
          });
          scope.tempCareManagers = careDetails;
          if(scope.tempCareManagers.length === 0){
            scope.tempCareManagers = [{id: '',name: null,emailAddress: null,isCareSupervisor: false,isNew: true,isTrue: false}];
          }
          scope.filterMembersData();
          scope.memberlistCount = scope.tempCareManagers.length;
          localStorage.setItem('isWizardFormDirty', true);
        };

        scope.addAssignedMembers = function(item){
          if(item.id > 0){
            var count =scope.tempCareManagers.length-1;
            scope.tempCareManagers[count].id = item.id;
            scope.tempCareManagers[count].name = item.name;
            scope.tempCareManagers[count].emailAddress = item.emailAddress;
            scope.tempCareManagers[count].isCareSupervisor = item.isCareSupervisor;
            scope.tempCareManagers[count].isNew = true;
            scope.tempCareManagers[count].isTrue = false;
            scope.tempCareManagers.push({id: '',name: null,emailAddress: null,isCareSupervisor: false,isNew: true,isTrue: true});
            scope.filterMembersData();
            scope.memberlistCount = scope.tempCareManagers.length;
            localStorage.setItem('isWizardFormDirty', true);
          }
        };

        scope.filterMembersData = function(){
          var count = 0;
          scope.careCtrl.careTeamPost.careManagers = [];
          scope.tempCareManagers.forEach(function(item){
            if(count < scope.tempCareManagers.length-1){
              scope.careCtrl.careTeamPost.careManagers.push(item);
            }
            count = count + 1;
          });
        };
        scope.inactivealert = 'This is the only care team associated to ';
        scope.inactivealertjoin = ' Managed Population(s).Please add another active care team to that Managed Population before inactivating this care team.';
        scope.careTeamstatus = function (value) {
          if (value === 'Active') {
            scope.completeStep(scope.createCareTeam.$valid, 'adminCareTeamName');
            scope.notification.visible = false;
            scope.isValidCareTeam = false;
          } else {
            if (scope.careCtrl.careTeamPost.id) {
              careTeamSvc.getActiveCareTeamsCount(scope.careCtrl.careTeamPost.id).then(
                function(response) {
                  scope.active = response.data.results;
                  if (scope.active.status === true) {
                    scope.isValidCareTeam = scope.active.status;
                    var programName;
                    programName = _.pluck(scope.active.managedPopulationName,'programName');
                    programName = programName.join(', ');
                    scope.notification = {
                      visible: true,
                      message: scope.inactivealert + programName + scope.inactivealertjoin
                    };
                    scope.completeStep(!scope.active.status, 'adminCareTeamName');
                  } else if (scope.active.status === false) {
                    scope.isValidCareTeam = scope.active.status;
                  }
                }
              );
            }
          }
        };
        
        scope.modalOpenProviderSearch = function () {
          scope.totalServerItems = 0;
          var modalOptions = {
            closeButtonText: 'Cancel',
            actionButtonText: 'Search',
            resetButtonText: 'Clear',
            headerText: 'Provider Search',
            bodyText: ''
          };
          var modalDefaults = {
            'templateUrl': app.root + 'templates/modalProviderSearch.html',
            'size': 'lg'
          };

          modalDefaults.controller = function ($scope, $modalInstance) {
            var tempModalOptions = {};
            angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
            $scope.modalOptions = tempModalOptions;
            $scope.patientSearchUrl = '';
            $scope.pageIndex = 1;
            $scope.pageSize = 10;

            $scope.providerSearchData = {
              userName : '',
              firstname : '',
              lastName : '',
              phoneNumber : '',
              city : '',
              emailAddress : '',
              state : '',
              accountStatus : 'A',
              zipCode : ''
            };

            scope.filterPaginations = {
              pageSizes: [5, 10, 15],
              pageSize: 10,
              currentPage: 1
            };

            $scope.providerSearchGrid = {
              data: 'gridProviderData',
              multiSelect: false,
              showFooter: true,
              enablePaging: true,
              rowHeight: 45,
              totalServerItems: 'totalServerItems',
              
              pagingOptions: scope.filterPaginations,
              filterOptions: scope.filterOption,
              columnDefs: [
                { field: 'userId', displayName: 'id', visible: false },
                { field: 'userLoginName', displayName: 'Username', width: '20%'},
                { field: 'fullName', displayName: 'Name', width: '20%' },
                { field: 'roleName', displayName: 'Role', width: '20%' },
                { field: 'email', displayName: 'Email', width: '20%' },
                { field: 'description', displayName: 'Status', width: '10%' },
                { field: '', displayName: 'Action', width: '10%',
                  cellTemplate: '<span ng-click="addProvider(row.entity)"><span class="btn newMessageIconStyle care-team-details-action General-icon_add_6fa8dc_30x30"></span></span>'
                }
              ]
            };

            $scope.addProvider = function (row) {
              localStorage.setItem('isWizardFormDirty', true);
              $modalInstance.dismiss('cancel');
              var checkDuplicates = _.filter(scope.tempCareManagers, function (item) {
                return (row.userId === item.id);
              });
              if(checkDuplicates.length === 0){
                var count = scope.tempCareManagers.length-1;
                scope.tempCareManagers[count].id = row.userId;
                scope.tempCareManagers[count].name = row.fullName;
                scope.tempCareManagers[count].emailAddress = row.email;
                scope.tempCareManagers[count].isCareSupervisor = false;
                scope.tempCareManagers[count].isTrue = true;
                scope.tempCareManagers[count].isNew = true;
              }
              else{
                scope.careCtrl.notification('Selected Care Manager/Member already exists');
              }
            };

            $scope.getProviderSearch = function () {
              httpRequestSvc.getRequest('members',$scope.patientSearchUrl).then(function(response){
                  $scope.gridProviderData = response.data.results.members;
                  $scope.totalServerItems = response.data.results.totalCount;
                  scope.setPatientSearchPaging($scope.gridPatientData);
                });
            };

            $scope.getProviderSearchUrl = function () {
              $scope.patientSearchUrl = { 'isPatient' : false,
                                          'status' : $scope.providerSearchData.accountStatus,
                                          'userLoginName': $scope.providerSearchData.userName === undefined ? '' : $scope.providerSearchData.userName,
                                          'firstName': $scope.providerSearchData.firstName === undefined ? '' : $scope.providerSearchData.firstName,
                                          'lastName': $scope.providerSearchData.lastName === undefined ? '' : $scope.providerSearchData.lastName,
                                          'phone':$scope.providerSearchData.phoneNumber === undefined ? '' : $scope.providerSearchData.phoneNumber,
                                          'city': $scope.providerSearchData.city === undefined ? '' : $scope.providerSearchData.city,
                                          'email': $scope.providerSearchData.emailAddress === undefined ? '' : $scope.providerSearchData.emailAddress,
                                          'state': $scope.providerSearchData.state === undefined ? '' : $scope.providerSearchData.state,
                                          'zipCode': $scope.providerSearchData.zipCode === undefined ? '' : $scope.providerSearchData.zipCode,
                                          'pageIndex': $scope.pageIndex,
                                          'pageSize': $scope.pageSize,
                                          'isCareManagersOnly': true
                                        };
              $scope.getProviderSearch();
            };

            $scope.modalOptions.search = function () {
              $scope.providerSearchGrid.pagingOptions.currentPage = 1;
              $scope.getProviderSearchUrl();
            };

            $scope.getProviderSearchUrl();

            $scope.phoneInput = function()
            {
              if($scope.providerSearchData.phoneNumber === '')
              {
                $scope.userSearchForm.phone.$setPristine();
                $scope.providerSearchData.phoneNumber = undefined;
              }
            };

            $scope.modalOptions.reset = function () {
                $scope.userSearchForm.$setPristine();
                $scope.providerSearchData.userName = '';
                $scope.providerSearchData.firstName = '';
                $scope.providerSearchData.lastName = '';
                $scope.providerSearchData.phoneNumber = '';
                $scope.providerSearchData.city = '';
                $scope.providerSearchData.emailAddress = '';
                $scope.providerSearchData.state = '';
                $scope.providerSearchData.accountStatus = 'A';
                $scope.providerSearchData.zipCode = '';
                $scope.patientSearchUrl = { 'isPatient' : false,'status' : 'A', isCareManagersOnly: true};
                $scope.pageIndex = 1;
                $scope.pageSize = 10;
                $scope.providerSearchGrid.pagingOptions.currentPage = 1;
                $scope.getProviderSearchUrl();
              };
            $scope.modalOptions.close = function () {
              $modalInstance.dismiss('cancel');
            };

            scope.$watch('filterPaginations', function (newVal, oldVal) {
                var pageSizeCount = parseInt(scope.filterPaginations.pageSize);
                if (newVal !== oldVal) {
                  scope.filterPaginations.currentPage = (newVal.currentPage === undefined || newVal.currentPage === null) ? 1 : scope.filterPaginations.currentPage;
                  $scope.pageIndex = (newVal.currentPage === undefined || newVal.currentPage === null) ? 1 : newVal.currentPage;
                  $scope.pageSize = pageSizeCount;
                  $scope.getProviderSearchUrl();
                }
              }, true);
          };

          var tempModalOptions = {};
          angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);

          modalService.showModal(modalDefaults, modalOptions);
        };

        scope.setPatientSearchPaging = function (data) {
          if (data !== undefined) {
            scope.gridProviderData = data;
          }
          if (scope.totalPatientCount === undefined){
            scope.totalServerItems = 0;
            scope.totalPatientCount = 0;
          }
          if (!scope.$$phase) {
            scope.$apply();
          }
        };

        scope.$on('wizardOnsaveAndClose', function() {
          scope.checkDuplicate(scope.careCtrl.careTeamPost.name,scope.careCtrl.careTeamPost.id);
        });

        scope.checkDuplicate = function(careTeamName,id){
          httpRequestSvc.getRequest('care-teams?IncludeInActive=true').then(function(response){
            var careFilterData =  _.filter(response.data.results, function (item) {
              return (item.name === careTeamName );
            });
            if(careFilterData.length > 0){
              if(careFilterData[0].id !== id){
                scope.careCtrl.notification('Care Team name already exists');
              }
              else
              {
                scope.insertUpdateCareTeam();
              }
            }
            else{
              scope.insertUpdateCareTeam();
            }
          });
        };

        scope.insertUpdateCareTeam = function(){
          var careTeamDetails = {};
          if(scope.careCtrl.careTeamPost.id >0){
            careTeamDetails = {'careTeam': {'id': scope.careCtrl.careTeamPost.id,
                                            'name': scope.careCtrl.careTeamPost.name,
                                            'description': scope.careCtrl.careTeamPost.description,
                                            'status': scope.careCtrl.careTeamPost.status,
                                            'careManagers': scope.careCtrl.careTeamPost.careManagers}};
            currentListState.CurrentUIState.careTeamDetails = { isAlert:true,message:'Care Team has been updated successfully.'};
            listStateSvc.set(currentListState);

            httpRequestSvc.putRequest('care-teams/',careTeamDetails).then(function(response){
                if(response.data.results !== -1)
                {
                  location.url(app.currentRoute +'/library/care');
                }
              });
              
          }
          else{
            careTeamDetails = {'careTeam': {'name': scope.careCtrl.careTeamPost.name,
                                            'description': scope.careCtrl.careTeamPost.description,
                                            'status': scope.careCtrl.careTeamPost.status,
                                            'careManagers': scope.careCtrl.careTeamPost.careManagers}};
            currentListState.CurrentUIState.careTeamDetails = { isAlert:true,message:'Care Team has been added successfully.'};
            listStateSvc.set(currentListState);
            httpRequestSvc.postRequest('care-teams/',careTeamDetails).then(function(response){
                if(response.data.results !== -1)
                {
                  location.url(app.currentRoute + '/library/care');
                }
              });
          }
        };

        scope.$on('wizardOnClose', function() {
          listStateSvc.clear();
          if(app !== undefined && app.currentRoute !== undefined) {
            location.url(app.currentRoute + '/library/care');
          }
          else{
            location.url('/library/care');
          }
        });

        scope.$watch('memberlistCount', function () {
          
          scope.memberlistCount = '';
          if(scope.tempCareManagers.length > 1){
            scope.completeStep(true, 'adminCareTeamDetails');
          }else{
            scope.completeStep(false, 'adminCareTeamDetails');
          }
        });

        scope.checkCareTeamNameExist = function () {
          scope.isCareTeamExists = false;
          scope.completeStep(false, 'adminCareTeamDetails');
          if(scope.careCtrl.careTeamPost.name){
            careTeamSvc.GetActiveCareTeams({IncludeInActive:true}).then(
              function (response) {
                response.data.results.forEach(function (careTeam) {
                  if( careTeam.name.toLowerCase() === scope.careCtrl.careTeamPost.name.toLowerCase() && scope.careCtrl.careTeamPost.id !== careTeam.id ){
                    scope.isCareTeamExists = true;
                    scope.createCareTeam.careTeamName.$setValidity('required', false);
                  }
                });
                if(scope.createCareTeam){
                  if(scope.createCareTeam.$valid && scope.isValidCareTeam === false){
                    scope.completeStep(!scope.isCareTeamExists, 'adminCareTeamName');
                  }
                }
              }
            );
          }
        };

      }]);
  }(window.app)
);
