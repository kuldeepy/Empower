(function (app) {
  'use strict';
  app.controller('chronicCareManagementCtrl', ['$scope','chronicCareManagementSvc','homeURL','authSvc','_','modalService','navConstantsSvc',function (scope,chronicCareManagementSvc,homeURL,authSvc,_,modalService,navConstantsSvc) {
    scope.pageload = function(){
        scope.isOpen=true;
        scope.user = authSvc.user();
        scope.user.backURL = homeURL.getURL(scope.user.role);
        scope.years = [];
        scope.month = [];
        scope.monthData = [];
        scope.filter = {};
        chronicCareManagementSvc.getDateKey().then(function(response){
            response.data.results.forEach(function(item){
                scope.years.push({name:item.year,id:item.yearValue});
                scope.month.push({name:item.month,id:item.monthValue,year:item.yearValue});
                scope.monthData.push({name:item.month,id:item.monthValue,year:item.yearValue});
              });
            if(response.data.results.length>0){
              scope.filterReportData(false);
              scope.bindchronicData(scope.filter);
            }
          });
      };

    scope.barWidth = function (item) {
      return {'width':(item)+'%'};
    };
    scope.patientDrilldown=function(item,type,count){
        scope.item=item;
        scope.pateintCount = count;
        scope.range = type === 'patients'? '' : type;
        scope.dateKeyId = scope.filter.monthId !== ''?scope.filter.monthId:scope.filter.yearId !== ''?scope.filter.yearId:'';
        scope.filterData=scope.filter;
        scope.reportType='chronicCare';
        var modalOptions={};
        var modalDefaults = {
            'templateUrl': app.root + 'modules/administrator/templates/PatientList.html',
            'size':'lg',
            'controller':'PatientlistCtrl',
            'scope':scope
          };
        var tempModalOptions = {};
        angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
        modalOptions.copyProviders = scope.masterProviders;
        modalService.showModal(modalDefaults, modalOptions);
      };

    scope.bindchronicData = function(filter) {
      filter.managedPopulationId = null;
      filter.dateKey=scope.filter.monthId !== null?scope.filter.monthId:scope.filter.yearId !== null?scope.filter.yearId:'';
      var careTeams = _.where(scope.careTeams,{id:scope.filter.careTeamId});
      _.forEach(careTeams,function(item){
          filter.managedPopulationId = filter.managedPopulationId? filter.managedPopulationId + ',' + item.managedPopulationId: item.managedPopulationId;
        });
      chronicCareManagementSvc.getFilterData(filter).then(function(response){
        _.each(response.data.results,function(item){
          var maxValue = _.max({'mins0':item.mins0,'mins10':item.mins10,'mins20':item.mins20,'minsAbove20':item.minsAbove20});
          scope.iFlag = 0;
          var totalValue = item.mins0+item.mins10+item.mins20+item.minsAbove20;
          item.mins0Width = scope.validateWidth(item.mins0, totalValue);
          item.mins10Width = scope.validateWidth(item.mins10, totalValue);
          item.mins20Width = scope.validateWidth(item.mins20, totalValue);
          item.minsAbove20Width = scope.validateWidth(item.minsAbove20, totalValue);
          if(scope.iFlag>0){
            item.mins0Width = item.mins0  === maxValue ? item.mins0Width-scope.iFlag:item.mins0Width;
            item.mins10Width = item.mins10 === maxValue ? item.mins10Width-scope.iFlag:item.mins10Width;
            item.mins20Width = item.mins20 === maxValue ? item.mins20Width-scope.iFlag:item.mins20Width;
            item.minsAbove20Width = item.minsAbove20 === maxValue ? item.minsAbove20Width-scope.iFlag:item.minsAbove20Width;
          }
        });
        scope.chronicCareData = response.data.results;
      });
    };

    
    scope.validateWidth=function(item,totalValue){
      var value = ((item)/(totalValue))*100;
      if(value > 0 && value < 1){
        scope.iFlag = scope.iFlag + 1;
        value = value+1;
      }
      return value;
    };

    scope.bindPhysicians = function(clinicId) {
        if(clinicId !== ''){
          var data ={'clinicId':clinicId,'dateKey':scope.filter.monthId !== ''?scope.filter.monthId:scope.filter.yearId !== ''?scope.filter.yearId:''};
          chronicCareManagementSvc.getPhysicianFilter(data).then(function(response){
                scope.pcp = response.data.results;
              });
        }
        else if(scope.user.role === navConstantsSvc.physician){
          var object ={'dateKey':scope.filter.monthId !== ''?scope.filter.monthId:scope.filter.yearId !== ''?scope.filter.yearId:''};
          chronicCareManagementSvc.getPhysicianFilter(object).then(function(response){
            scope.pcp = response.data.results;
          });
        }
        else{
          scope.pcp = [];
        }
        scope.filter.pcpId ='';
      };

    scope.bindCareTeamMembers = function(careTeamId) {
        if(careTeamId !== '' && scope.user.role !== navConstantsSvc.careManager){
          var data ={'careTeamId':careTeamId,'dateKey':scope.filter.monthId !== ''?scope.filter.monthId:scope.filter.yearId !== ''?scope.filter.yearId:''};
          chronicCareManagementSvc.getCareTeamMembersFilter(data).then(function(response){
                scope.careTeamMembers = response.data.results;
              });
        }
        else{
          scope.careTeamMembers = scope.user.role === navConstantsSvc.careManager ? scope.careTeamMembers : [];
        }
        scope.filter.careTeamMemberId = scope.user.role === navConstantsSvc.careManager ? scope.filter.careTeamMemberId: '';
      };

    scope.bindMonthFilter = function() {
        scope.filterReportData(true);
      };

    scope.bindYearFilter = function(id) {
        scope.month = id? _.sortBy(_.where(scope.monthData,{year:id? id:''}),'id').reverse() : _.sortBy(scope.monthData,'id').reverse() ;
        scope.filter.monthId = '';
        scope.filterReportData(true);
      };
    scope.filterReportData = function(id){
        var datekey;
        if(id === false){
          scope.filter.yearId = scope.years[0]?scope.years[0].id:'';
          scope.month = _.sortBy(_.where(scope.month,{year:scope.years[0]?scope.years[0].id:''}),'id').reverse();
          scope.filter.monthId = scope.month[0]?scope.month[0].id:'';
          datekey = scope.filter.monthId;
        }
        else{
          datekey = scope.filter.monthId!==''?scope.filter.monthId:scope.filter.yearId!==''?scope.filter.yearId:'';
        }
        chronicCareManagementSvc.getCareTeamFilter({'dateKey':datekey}).then(function(response){
            var filteredCareTeams = _.filter(response.data.results, function(careTeam){ return careTeam.name !== navConstantsSvc.allPatientCareTeamName; });
            scope.careTeams = filteredCareTeams;
            if(scope.user.role === navConstantsSvc.careManager?scope.careTeams.length>0:true){
              chronicCareManagementSvc.getClinicsFilter({'dateKey':datekey}).then(function(response){
                scope.clinics = response.data.results;
                if(scope.user.role === navConstantsSvc.clinicAdministrator){
                  scope.filter.clinicId = scope.clinics[0]?scope.clinics[0].id:'';
                  scope.bindPhysicians(scope.filter.clinicId);
                }
              });

              chronicCareManagementSvc.getProductTypesFilter({'dateKey':datekey}).then(function(response){
                scope.productType = response.data.results;
              });
            }
            else{
              scope.productType=[];
              scope.clinics=[];
              scope.physician=[];
            }
          });
        if(scope.user.role === navConstantsSvc.physician){
          chronicCareManagementSvc.getPhysicianFilter({'dateKey':datekey}).then(function(response){
                scope.pcp = response.data.results;
                scope.filter.pcpId = scope.pcp[0]?scope.pcp[0].id:'';
              });
        }
        if(scope.user.role === navConstantsSvc.careManager){
          scope.careTeamMembers = [{'id': scope.user.providerId,'name': scope.user.providerName}];
          scope.filter.careTeamMemberId = scope.careTeamMembers[0].id;
        }
        scope.filter.clinicId = scope.user.role!==navConstantsSvc.clinicAdministrator? '' : scope.filter.clinicId;
        scope.filter.pcpId = scope.user.role!==navConstantsSvc.physician? '' : scope.filter.pcpId;
        scope.filter.careTeamId = '';
        scope.filter.careTeamMemberId = scope.user.role !== navConstantsSvc.careManager ? '': scope.filter.careTeamMemberId;
        scope.filter.productId = '';
        scope.careTeamMembers = scope.user.role !== navConstantsSvc.careManager ? [] : scope.careTeamMembers;
        scope.pcp = scope.user.role!==navConstantsSvc.physician? [] : scope.pcp;
      };

    scope.pageload();

  }]);
})(window.app);
