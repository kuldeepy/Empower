(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('MapReminderScheduleCtrl', ['$scope', 'managedPopulationSvc','_','$modal','$location',
    function (scope, managedPopulationSvc, _, $modal, location) {
      var mi, popId;
      scope.persistedTaskReminders = [];
      scope.remindersToSave = [];
      
      if (scope.initializeStep) {
        scope.initializeStep('mapReminderSchedule', false);
        if( (scope.remindersToSave.length <= 0) && (scope.mngpopCtrl.managedPopulation.reminders.length > 0) ){
          scope.remindersToSave = scope.mngpopCtrl.managedPopulation.reminders;
        }
      }
     

      scope.$on('wizardOnClose', function() {
        if(app !== undefined && app.currentRoute !== undefined) {
          location.url(app.currentRoute+'/configuration/population');
        }
        else{
          location.url('/admin/configuration/population');
        }
      });
      
      popId = managedPopulationSvc.managedPopulationId;

      scope.reminderTable = {
        columns : ['Task Name', 'Frequency', 'Days to mark Task open', 'Reminders']
      };
      
      scope.addRow = function (objToAdd) {
        var k;
        var flag = false;

        localStorage.setItem('isWizardFormDirty', true);

        k = scope.taskReminders.indexOf(objToAdd);
        if(k > 0){
          if(scope.taskReminders[k-1].daysBeforeDueDate) {
            if(objToAdd.daysBeforeDueDate) {
              flag=scope.taskReminders[k-1].daysBeforeDueDate >= objToAdd.daysBeforeDueDate ? true : false;
            }
          }
          else{
            if(objToAdd.daysBeforeDueDate) {
              flag = true;
            }
            else{
              flag = false;
            }
          }
          if(scope.taskReminders[k-1].daysAfterDueDate) {
            if(objToAdd.daysAfterDueDate) {
              flag = scope.taskReminders[k-1].daysAfterDueDate < objToAdd.daysAfterDueDate ? true : false;
            }
          }
          else{
            if(objToAdd.daysAfterDueDate) {
              flag = true;
            }
            else{
              flag = angular.equals(flag, false) ? false : true;
            }
          }
          if(scope.taskReminders[k-1].daysAfterDueDate) {
            if(objToAdd.numberOfDaysBeforeTaskClosedIncomplete) {
              flag = scope.taskReminders[k-1].daysAfterDueDate < objToAdd.numberOfDaysBeforeTaskClosedIncomplete ? true : false;
            }
          }
          else{
            if(objToAdd.numberOfDaysBeforeTaskClosedIncomplete) {
              flag = true;
            }
            else{
              flag = angular.equals(flag,false) ? false : true;
            }
          }
        }
        if(angular.equals(flag,true) || angular.equals(k,0)) {
          if(angular.equals(k,0)) {
            if(objToAdd.daysBeforeDueDate || objToAdd.daysAfterDueDate) {
              flag = true;
            }
            else{
              flag = false;
            }
          }
          else{
            flag = true;
          }
          if(angular.equals(flag,true)) {
            scope.taskReminders[k].newReminder = false;
            scope.taskReminders[k].isSave = true;
            scope.addNewReminder(objToAdd.taskBundleId, objToAdd.generalizedId);
            scope.filterTaskReminders(scope.persistedTaskReminders);
          }
        }
      };

      scope.inActive = function (obj) {
        var j;
        j = scope.persistedTaskReminders.indexOf(obj);
        localStorage.setItem('isWizardFormDirty', true);
        if (obj.id > 0) {
          scope.persistedTaskReminders[j].statusCode = 'I';
        }else{
          scope.persistedTaskReminders[j].statusCode = 'I';
        }
        scope.filterTaskReminders(scope.persistedTaskReminders);
        var hasNewReminder = _.findWhere(scope.taskReminders,{newReminder : true});
        if(!hasNewReminder){
          scope.addNewReminder(obj.programTaskBundleID, obj.generalizedId);
        }

        
      };
      
      scope.updateReminder = function(item){
        mi = $modal.open({
          templateUrl: 'myModalContent.html',
          size: 'lg',
          scope: scope,
          backdrop : 'static'
        });
        scope.backUpData = item;
        scope.getTaskBundleReminders( item.taskBundleId ? item.taskBundleId : item.taskBundleID,item.scheduledDays, item.taskTypeGeneralizedId,item.taskType,item.frequencyTitration,item.taskName,item.recurrenceType);
      };

      scope.ok = function(){
        scope.saveReminders();
        mi.close();
      };

      scope.closeModal = function(){
        mi.close();
      };

      scope.getTaskBundlesTasks = function () {

          scope.tasks = managedPopulationSvc.taskConflictsResolved;
          
          scope.allTasks = [{
            titleName : 'Procedures',
            tasks : _.filter(scope.tasks, function(pTask){ if(pTask){return pTask.taskType === managedPopulationSvc.procedureTaskType;}}),
          },
          {
            titleName : 'Assessments',
            tasks : _.filter(scope.tasks,function(aTask){ if(aTask){return aTask.taskType === managedPopulationSvc.assessmentTaskType;}}),
          },
          {
            titleName : 'Education Material',
            tasks : _.filter(scope.tasks, function(eType){ if(eType){return eType.taskType === managedPopulationSvc.educationTaskType;}}),
          },
          {
            titleName : 'Others',
            tasks : _.filter(scope.tasks,function(oType){ if(oType){return  oType.taskType === managedPopulationSvc.otherTaskType;}}),
          },
         ];
          scope.mngpopCtrl.managedPopulation.summaryOfAllTasks = scope.allTasks;
          scope.completeStep(true,'mapReminderSchedule');
        };
       
      scope.init = function () {
        scope.getTaskBundlesTasks();
      };

      managedPopulationSvc.getcommunicationTypes().then(
        function(response){
          scope.communicationTypes = response.data.results;
          scope.phoneCommunication = _.findWhere(scope.communicationTypes,{communicationType : 'Phone Call'});
        }
      );
      scope.saveReminders = function(){
        var itemsToUpdate = _.filter(scope.persistedTaskReminders, function(item){ return item.id > 0; });
        _.each(itemsToUpdate, function(itemToSave){
          itemToSave.taskType = scope.taskType;
          itemToSave.taskName=scope.backUpData.taskName;
          itemToSave.recurrenceType=scope.backUpData.recurrenceType;
          itemToSave.frequency=scope.backUpData.frequency;
          itemToSave.frequencyNumber=scope.backUpData.frequencyNumber;
          itemToSave.frequencyTitration=scope.backUpData.frequencyTitration;
          itemToSave.communicationSequence = itemToSave.communicationSequence;
          itemToSave.communicationTypeId = scope.phoneCommunication.communicationTypeId;
          itemToSave.numberOfDaysBeforeTaskClosedIncomplete = itemToSave.numberOfDaysBeforeTaskClosedIncomplete !== null ? itemToSave.numberOfDaysBeforeTaskClosedIncomplete : itemToSave.numberOfDaysBeforeTaskClosedIncomplete;
        });
        var itemsToSave = _.filter(scope.persistedTaskReminders, function(item){ return (item.isSave); });
        var communicationSequenceCount = 0;
        _.each(itemsToSave, function(item){
          item.taskName=scope.backUpData.taskName;
          item.recurrenceType=scope.backUpData.recurrenceType;
          item.frequency=scope.backUpData.frequency;
          item.frequencyNumber=scope.backUpData.frequencyNumber;
          item.frequencyTitration=scope.backUpData.frequencyTitration;
          communicationSequenceCount = communicationSequenceCount + 1;
          item.communicationSequence = itemsToUpdate.length === 0 ? communicationSequenceCount : item.communicationSequence;
          item.communicationAttemptDays = item.daysAfterDueDate ? item.daysAfterDueDate : item.daysBeforeDueDate;
          if(item.numberOfDaysBeforeTaskClosedIncomplete !== null || item.daysAfterDueDate !== undefined){
            item.remainderState = 'A';
          }
          else
          {
            item.remainderState = 'B';
          }
          item.numberOfDaysBeforeTaskClosedIncomplete = item.numberOfDaysBeforeTaskClosedIncomplete !== null ? item.numberOfDaysBeforeTaskClosedIncomplete : item.numberOfDaysBeforeTaskClosedIncomplete;
        });

        var isUpdateRemindersEmpty = _.isEmpty(itemsToUpdate);
        if(!isUpdateRemindersEmpty){
          managedPopulationSvc.updateTaskBundleReminders(popId,itemsToUpdate).then(
            function(){scope.persistedTaskReminders = [];});
        }

        var isSaveRemindersEmpty = _.isEmpty(itemsToSave);
        if(!isSaveRemindersEmpty){
          /*scope.remindersToSave = _.filter(scope.remindersToSave, function(outter) { 
            outter.outcomes = _.filter(outter.outcomes, function(inner) { 
              return scope.persistedTaskReminders[0].taskBundleId && inner.taskBundleId ; 
            });            
            return outter.generalizedId !== scope.persistedTaskReminders[0].generalizedId && outter.taskName!==scope.persistedTaskReminders[0].taskName && outter.frequencyTitration!==scope.persistedTaskReminders[0].frequencyTitration && outter.recurrenceType!==scope.persistedTaskReminders[0].recurrenceType; 
          });*/
          _.forEach(itemsToSave, function(item) {
              scope.remindersToSave.push(item);
            });
          scope.remindersToSave = _.uniq(scope.remindersToSave);
        }
      };

      scope.$watch('remindersToSave.length',function(){
        scope.mngpopCtrl.managedPopulation.reminders = scope.remindersToSave;
      });


      scope.getTaskBundleReminders = function (id, scheduledDays, generalizedId,taskType,frequencyTitration,taskName,recurrenceType) {
        scope.persistedTaskReminders = _.filter(scope.remindersToSave,{taskBundleId:id, generalizedId:generalizedId,frequencyTitration:frequencyTitration,taskName:taskName,recurrenceType:recurrenceType});

        _.each(scope.persistedTaskReminders, function(item){
          item.newReminder = false;
          item.daysBeforeDueDate = item.numberOfDaysBeforeTaskClosedIncomplete ? null : item.daysBeforeDueDate;
          item.communicationTypeId = scope.phoneCommunication.communicationTypeId;
        });
        scope.addNewReminder(id, generalizedId,scheduledDays,taskType);
        scope.filterTaskReminders(scope.persistedTaskReminders,scheduledDays);
      };

      scope.filterTaskReminders = function(remindersToBeFiltered,scheduledDays){
        scope.taskReminders = _.filter(remindersToBeFiltered,{ statusCode : 'A' });
        if(scope.taskReminders.length === 1){
          scope.taskReminders[0].daysBeforeDueDate = scheduledDays;
        }
      };

      scope.addNewReminder = function(tasksBundleId, generalizedId,scheduledDays,taskType){
        var taskBundleTask = _.findWhere(scope.tasks,{taskBundleId: tasksBundleId , taskTypeGeneralizedId: generalizedId });
        var reminderGeneralizedId,reminderTaskType;
        if(!taskBundleTask){
          reminderGeneralizedId = generalizedId;
          reminderTaskType = taskType;
          scope.maxScheduledDays = scheduledDays;
        }else{
          scope.taskType = reminderTaskType = taskBundleTask.taskType;
          reminderGeneralizedId = taskBundleTask.taskTypeGeneralizedId;
          scope.maxScheduledDays = taskBundleTask.scheduledDays;
        }
        var newReminder = {
          id : '',
          generalizedId : reminderGeneralizedId,
          communicationTypeId: scope.phoneCommunication.communicationTypeId,
          taskBundleId : tasksBundleId,
          numberOfDaysBeforeTaskClosedIncomplete  : null,
          taskType: reminderTaskType,
          remainderState : 'A',
          statusCode  : 'A',
          communicationSequence: scope.persistedTaskReminders.length + 1,
          newReminder : true,
          statusDescription :'Active',
          beforeCommunicationAttemptDays:'',
          afterCommunicationAttemptDays:'',
          communicationAttemptDays : 0,
        };
        scope.persistedTaskReminders.push(newReminder);
      };

    }]);

  }(window.app));