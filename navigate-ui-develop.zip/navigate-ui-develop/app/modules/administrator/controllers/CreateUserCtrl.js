(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('CreateUserCtrl', ['$scope', '$http', 'createUserSvc', '$state', '$location', '$timeout',
      function (scope, http, createUserSvc, state, location, timeout) {

        if (scope.initializeStep) {
          //scope.initializeStep('userDetails' ,false);
          if (state.current.name === 'userSummary') {
            scope.initializeStep(state.current.name,true);
          }else{
            scope.initializeStep(state.current.name,false);
          }
        }

        // GET states
        createUserSvc.states().then(function(data) {
          scope.states = data;
        });

        // GET countries
        createUserSvc.countries().then(function(data) {
          scope.countries = data;
        });

        scope.filterRoles = function(roleName){
          var roleDetails = _.filter(scope.userCtrl.userPost.user.roles, function (item) {
            return (roleName === item.name);
          });
          return roleDetails;
        };

        // GET roles
        createUserSvc.roles().then(function(data) {
          scope.roles = data;
          var i, len;
          for (i = 0, len = scope.roles.length; i < len; i = i + 1){
            var roleDetails = scope.filterRoles(scope.roles[i].name);
            if(scope.roles[i].name === 'Clinic Administrator' || scope.roles[i].name === 'Physician' || scope.roles[i].name === 'Insurance Group Provider'){
              scope.roles[i].isChecked = roleDetails.length > 0 ? true : false;
            }
          }
        });

        scope.success = false;
        scope.isUserEmailUnique = true;
        scope.error =false;
        scope.setStatus = [{ name: 'Active', value: 'A'}, {name: 'Inactive', value: 'I'}];

        // GET clinics
        createUserSvc.clinics().then(function(data) {
          scope.clinics = data;
        });

        // GET insurance groups
        createUserSvc.insuranceGroups().then(function(data) {
          scope.insuranceGroups = data;
        });

        scope.success = false;
        scope.setStatus = ['Active', 'Inactive'];

        scope.clinicAdmin = false;
        scope.physician = false;
        scope.insuranceGroupProvider = false;

        scope.isChecked = function(role) {
          var userRoles = scope.userCtrl.userPost.user.roles;
          scope.completeStep(userRoles.length > 0, 'securityRoles');
          for (var i=0; i <userRoles.length; i=i+1) {
            if (userRoles[i].name === role.name) {
              return true;
            }
          }
        };

        scope.change = function(role) {
          var userRoles = scope.userCtrl.userPost.user.roles;
          if (role.isChecked === true) {
            switch (role.name) {
              case 'Administrator':
                userRoles.push(role);
                break;
              case 'Care Manager':
                userRoles.push(role);
                break;
              case 'Clinic Administrator':
                scope.userCtrl.clinicDisabled = false;
                break;
              case 'Physician':
                scope.userCtrl.clinicPhysicianDisabled = false;
                break;
              case 'Insurance Group Provider':
                scope.userCtrl.insuranceDisabled = false;
                break;
              case 'Analyst':
                userRoles.push(role);
                break;
              case 'Marketing Analyst':
                userRoles.push(role);
                break;
            }
          }else{
            for (var i=0; i<userRoles.length; i=i+1) {
              var currentRole = userRoles[i];
              switch (role.name) {
                case 'Clinic Administrator':
                  scope.userCtrl.clinicDisabled = true;
                  scope.userCtrl.providerId = null;
                  scope.clinicAdmin = false;
                  scope.userCtrl.providerId = null;
                  scope.userCtrl.clinicAdmins = [];
                  break;
                case 'Physician':
                  scope.userCtrl.clinicPhysicianDisabled = true;
                  scope.userCtrl.physicianDisabled = true;
                  scope.userCtrl.physicianId = null;
                  scope.userCtrl.providerId = null;
                  scope.userCtrl.clinicIdForPhysician = null;
                  scope.userCtrl.physicians = [];
                  break;
                case 'Insurance Group Provider':
                  scope.userCtrl.providerId = null;
                  scope.userCtrl.insuranceDisabled = true;
                  scope.userCtrl.groupId = null;
                  scope.userCtrl.insuranceGroups = [];
                  break;
              }
              if (currentRole.name === role.name) {
                scope.deleteRoles(role.name);
              }
            }
          }
        };

        scope.deleteRoles = function(role){
          var deleteSelectedRole = _.filter(scope.userCtrl.userPost.user.roles, function (item) {
            return (item.name !== role);
          });
          scope.userCtrl.userPost.user.roles = deleteSelectedRole;
        };

        scope.addClinicAdmin = function() {
          // check for id         
          var clinicAdminRole = _.filter(scope.clinics, function (item) {
            return (item.id === scope.userCtrl.providerId.id);
          });

          if(clinicAdminRole.length > 0)
          {
            var checkDuplicate = _.filter(scope.userCtrl.clinicAdmins, function (item)
            {
              return (item === scope.userCtrl.providerId.name);
            });
            if(checkDuplicate.length === 0)
            {
              var roleDetails = _.filter(scope.roles, function (item)
              {
                return (item.name === 'Clinic Administrator');
              });
              var userRoles = scope.userCtrl.userPost.user.roles;
              userRoles.push({id : roleDetails[0].id,name : roleDetails[0].name,providerId : scope.userCtrl.providerId.id,providerName : scope.userCtrl.providerId.name});
              scope.userCtrl.clinicAdmins.push(scope.userCtrl.providerId.name);
              scope.userCtrl.providerId = null;
            }
          }
        };

        scope.getClinicId = function() {
          var clinicId = scope.userCtrl.clinicIdForPhysician;
          if (clinicId !== null) {
            // GET physicians
            createUserSvc.physicians(clinicId).then(function(data) {
              scope.physicians = data.physicians;
              
              scope.userCtrl.physicianDisabled = false;
            });
          }
          scope.userCtrl.physicianId = null;
          scope.userCtrl.physicianDisabled = true;
        };

        scope.addPhysician = function() {
          if(scope.userCtrl.physicians === undefined){
            scope.userCtrl.physicians = [];
          }
          // check for id
          var physicianRole = _.filter(scope.physicians, function (item) {
            return (item.id === scope.userCtrl.physicianId.id);
          });

          if(physicianRole.length > 0)
          {
            var checkDuplicate = _.filter(scope.userCtrl.physicians, function (item) {
              return (item === scope.userCtrl.physicianId.organizationName);
            });
            if(checkDuplicate.length === 0)
            {
              var roleDetails = _.filter(scope.roles, function (item)
              {
                return (item.name === 'Physician');
              });
              var userRoles = scope.userCtrl.userPost.user.roles;
              userRoles.push({id : roleDetails[0].id,name : roleDetails[0].name,providerId : scope.userCtrl.physicianId.providerID,providerName : scope.userCtrl.physicianId.organizationName});
              scope.userCtrl.physicians.push(scope.userCtrl.physicianId.organizationName);
              scope.userCtrl.physicianId = null;
              scope.userCtrl.clinicIdForPhysician = null;
              scope.userCtrl.physicianDisabled = true;
            }
          }
        };

        scope.addInsuranceId = function() {
          if(scope.userCtrl.insuranceGroups === undefined){
            scope.userCtrl.insuranceGroups = [];
          }
          var clinicInsuranceGroup = _.filter(scope.insuranceGroups, function (item) {
            return (item.id === scope.userCtrl.groupId.id);
          });

          if(clinicInsuranceGroup.length > 0)
          {
            var checkDuplicate = _.filter(scope.userCtrl.insuranceGroups, function (item)
            {
              return (item === scope.userCtrl.groupId.name);
            });
            if(checkDuplicate.length === 0)
            {
              var roleDetails = _.filter(scope.roles, function (item)
              {
                return (item.name === 'Insurance Group Provider');
              });
              var userRoles = scope.userCtrl.userPost.user.roles;
              userRoles.push({id : roleDetails[0].id,name : roleDetails[0].name,providerId : scope.userCtrl.groupId.id,providerName : scope.userCtrl.groupId.name});
              scope.userCtrl.insuranceGroups.push(scope.userCtrl.groupId.name);
              scope.userCtrl.groupId = null;
            }
          }
        };

        scope.deleteClinicRole = function(provider) {
          scope.userCtrl.userPost.user.roles = _.filter(scope.userCtrl.userPost.user.roles,function(item){
            return (item.providerName !== provider);
          });
          scope.userCtrl.clinicAdmins = _.filter(scope.userCtrl.clinicAdmins,function(item){
            return item !== provider;
          });
          scope.checkRole('Clinic Administrator',scope.userCtrl.clinicAdmins);
        };

        scope.deleteIGPRole =function(insurance){
          scope.userCtrl.userPost.user.roles = _.filter(scope.userCtrl.userPost.user.roles,function(item){
            return (item.providerName !== insurance);
          });
          scope.userCtrl.insuranceGroups = _.filter(scope.userCtrl.insuranceGroups,function(item){
            return item !== insurance;
          });
          scope.checkRole('Insurance Group Provider',scope.userCtrl.insuranceGroups);
        };

        scope.deletePhysicianRole = function(physician) {
          scope.userCtrl.userPost.user.roles = _.filter(scope.userCtrl.userPost.user.roles,function(item){
            return (item.providerName !== physician);
          });
          scope.userCtrl.physicians = _.filter(scope.userCtrl.physicians,function(item){
            return item !== physician;
          });
          scope.checkRole('Physician',scope.userCtrl.physicians);
        };

        scope.checkRole = function(role,data){
          var k, len;
          for (k = 0, len = scope.roles.length; k < len; k = k + 1){
            if(scope.roles[k].name === role){
              scope.roles[k].isChecked = data.length > 0 ? true : false;
            }
          }
        };

        scope.phoneInput = function()
          {
            if(scope.userCtrl.userPost.user.phoneNumber === ''){
              scope.createUser.phone.$setPristine();
              scope.userCtrl.userPost.user.phoneNumber = undefined;
            }
          };
        scope.$watch('createUser.$pristine', function () {
          if (scope.createUser && !scope.createUser.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$watch('userCredentials.$pristine', function () {
          if (scope.userCredentials && !scope.userCredentials.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$watch('createUser.$valid', function(val) {

          if (state.current.name === 'userDetails') {
            scope.completeStep(val, 'userDetails');
          }
        });

        scope.$watch('userCredentials.$valid', function(val) {

          if (state.current.name === 'userCredentials') {
            if (scope.userCtrl.confirm !== scope.userCtrl.userPost.password) {
              val = false;
            }
            scope.completeStep(false, 'userCredentials');
            scope.checkUserExist();
          }

        });

        scope.$on('wizardOnNext', function() {
          if (state.current.name === 'userDetails') {
            var states = scope.states;
            var countries = scope.countries;
            var stateCode = scope.userCtrl.userPost.user.primaryAddress.stateCode;
            var countryCode = scope.userCtrl.userPost.user.primaryAddress.countryCode;
            for (var i=0; i<states.length; i=i+1) {
              if (states[i].Id === stateCode) {
                scope.userCtrl.stateCode = states[i].Name;
              }
            }
            for (var e=0; e<countries.length; e=e+1) {
              if (countries[e].id === countryCode) {
                scope.userCtrl.countryCode = countries[e].name;
              }
            }
          }
        });

        scope.$on('wizardOnNext', function() {
          if(state.current.name === 'securityRoles') {
            var i, len;
            for (i = 0, len = scope.roles.length; i < len; i = i + 1){
              if(scope.roles[i].name === 'Clinic Administrator' || scope.roles[i].name === 'Physician' || scope.roles[i].name === 'Insurance Group Provider'){
                var roleDetails = scope.filterRoles(scope.roles[i].name);
                scope.roles[i].isChecked = roleDetails.length > 0 ? true : false;
              }
            }
          }
          scope.userCtrl.clinicIdForPhysician = null;
          scope.userCtrl.providerId = null;
          scope.userCtrl.physicianId = null;
          scope.userCtrl.clinicIdForPhysician = null;
          scope.userCtrl.groupId = null;
          scope.userCtrl.physicianDisabled = true;
        });

        scope.$on('wizardOnClose', function() {
          location.path('/admin/users/user');
        });

        scope.$on('wizardOnsaveAndClose', function() {
          // set state and country code in user object
          
          var userData = scope.userCtrl.userPost;
          http
            .post(app.api.root + 'users', userData)
            .then(
              // success
              function() {
                createUserSvc.isAddedSuccesfully = true;
                window.scrollTo(0, 0);
                createUserSvc.messageAlert = 'User has been added successfully';
                location.path('/admin/users/user/');
              }
            )
            .catch(function (error) {
              if(error.data.developerMessage === 'DuplicateEmail'){
                scope.errorMessage = 'Email address already exists';
                scope.error = true;
              }
              else if(error.data.developerMessage === 'DuplicateUserName'){
                scope.errorMessage = 'User name already exists';
                scope.error = true;
              }
              
              timeout(function() {scope.error = false;}, 6000);
            });
        });

        scope.checkUserPassword = function () {
          var checkUserPasswordDisable = true;
          if (scope.userCredentials.$valid && (scope.userCtrl.confirm === scope.userCtrl.userPost.password)) {
            scope.completeStep(checkUserPasswordDisable, 'userCredentials');
          }
          else {
            scope.completeStep(!checkUserPasswordDisable, 'userCredentials');
          }
        };

        scope.checkUserExist = function () {
          if (scope.userCtrl.userPost.user.userName) {
            createUserSvc.checkUser(scope.userCtrl.userPost.user.userName).then(function (data) {
              scope.isUserExists = data;
              if (scope.isUserExists === true) {
                scope.userCredentials.username.$setValidity('required', false);
              }
              else
              {
                scope.userCredentials.username.$setValidity('required', true);
              }
              if (scope.userCredentials.$valid && (scope.userCtrl.confirm === scope.userCtrl.userPost.password)) {
                scope.completeStep(!scope.isUserExists, 'userCredentials');
              }
            });
          }
          if (scope.isUserExists === false) {
            scope.completeStep(scope.isUserExists, 'userCredentials');
          }
          else {
            scope.isUserExists = false;
          }
        };

        scope.isEmailUnique = function(){

          scope.isUserEmailUnique = true;
          scope.completeStep(false, 'userDetails');
          if (scope.userCtrl.userPost.user.emailAddress) {
            createUserSvc.isEmailUnique(scope.userCtrl.userPost.user.emailAddress).then(function (result) {
              scope.isUserEmailUnique = result;
              if( scope.createUser.$valid){
                scope.completeStep(result, 'userDetails');
              }
              
              scope.createUser.email.$setValidity('required', result);
            });
          }
        };

      }
    ]);
  }(window.app)
);
