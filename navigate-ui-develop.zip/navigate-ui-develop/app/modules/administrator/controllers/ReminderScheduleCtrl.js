﻿(function (app) {
  'use strict';

  app.controller('ReminderScheduleCtrl', ['$scope','$timeout','reminderScheduleSvc', 'homeURL','authSvc', '$modal',
    function (scope, $timeout,reminderScheduleSvc, homeURL, authSvc, $modal) {

    var successMessage = 'Reminder Schedule has been updated successfully',
        errorMessage = 'Unfortunately, we are not able to process your request right now. Please try again later or contact your system administrator if this continues',
        modalInstance;
    scope.notification = {
      visible : false,
      success : false,
      failure : false,
      message : successMessage,
      errormessage : errorMessage
    };
    scope.pageTitle = 'Reminder Schedule';
    scope.reminderScheduleList = [];
    scope.user = authSvc.user();
    scope.user.backURL = homeURL.getURL(scope.user.role);
    scope.reminderScheduleTable = {
        columns : ['Task Type', 'Description', 'Days to Mark Task Open','Action']
      };

    scope.getReminderScheduleList = function(){
        reminderScheduleSvc.reminderScheduleList().then(function(response){
          if(response.data.results){
            scope.reminderScheduleList=response.data.results;
          }
        });
      };

    scope.getReminderScheduleList();
    scope.updatedReminderSchedule = {};

    scope.updateReminderSchedule = function(reminderSchedule){
        scope.updatedReminderSchedule = reminderSchedule;
        scope.updatedReminderSchedule.daysToMarkTaskOpen =  reminderSchedule.scheduledDays;
        scope.editReminderSchedulePopup = true;
        modalInstance = $modal.open({
          templateUrl: 'reminderScheduleEditTemplate.html',
          scope : scope,
          backdrop : 'static'
        });
      };

    scope.clickReminderScheduleUpdate=function(){
        reminderScheduleSvc.updateReminderSchedule(scope.updatedReminderSchedule).then(function(response){
          if(response.data.results){
            if(angular.equals(response.data.results,true))
            {
              modalInstance.close();
              scope.getReminderScheduleList();
              scope.editReminderSchedulePopup = false;
              scope.notification.visible = true;
              scope.notification.failure = false;
              scope.notification.success = true;
              window.scrollTo(0, 0);
              $timeout(function () {scope.notification.visible = false;}, 6000);
            }
          }
        });
      };


    scope.clickReminderScheduleCancel = function(){
        scope.editReminderSchedulePopup = false;
        scope.notification.visible = false;
        modalInstance.close();
      };

    scope.Cancel=function(){
        scope.notification.visible = false;
      };
  }]);
}(window.app));
