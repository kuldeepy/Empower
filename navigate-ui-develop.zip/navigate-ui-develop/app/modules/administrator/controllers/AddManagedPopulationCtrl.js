(function (app) {
  'use strict';
  
  app.controller('AddManagedPopulationCtrl', ['$scope','managedPopulationSvc','$location','$timeout',
      function (scope,managedPopulationSvc,location,timeout) {
      
      scope.wizardHeader = 'Add Managed Population';
      scope.errorMessage = 'Please try again later or contact your system administrator if this continues.';
      managedPopulationSvc.managedPopulationId = 0;
            
      /* display error message if failed to get the data from api*/
      this.showNotifications = function (errorMsg, style) {
        window.scrollTo(0, 0);
        scope.alertMessageStyle = style;
        scope.alertMessage = errorMsg;
        scope.isError = true;
        timeout(function () {
          scope.isError = false;
        }, 6000);
      };

      this.managedPopulation = {
        statusCode : 'A',
        id : 0,
        description : '',
        name : '',
        editManagedPopulationName : '',
        populationId: '',
        populationDefinition : {
          populationDefinitionId:'',
          populationDefinitionName:'',
        },
        careTeams : [] ,
        taskBundles:[],
        reminders :[],
        tasksResolvedConflicts :[],
        summaryOfAllTasks :[],
        productionStatus : 'F'
      };
      
      scope.actionTitle = 'Add Managed Population';
      scope.isSaveAsDraftDisabled = false;
      
      var id = localStorage.getItem('managedPopulationId');

      if(id !== null){
        this.managedPopulation.populationId = id;
        managedPopulationSvc.managedPopulationId = id;
        managedPopulationSvc.productionStatus = localStorage.getItem('productionStatus');
        scope.actionTitle = 'Edit Managed Population';
        var status = localStorage.getItem('productionStatus');
        localStorage.removeItem('productionStatus');
        scope.isSaveAsDraftDisabled = status === 'F' ? true : false;
        id = localStorage.removeItem('managedPopulationId');
      }
      scope.hideSaveAsDraft = false;

      scope.wizardWorkflow = [
        { 'id': 1, 'name': 'managedPopulationInformation' },
        { 'id': 2, 'name': 'mapPopulationDefinition' },
        { 'id': 3, 'name': 'mapTaskBundles' },
        { 'id': 4, 'name': 'mapResolveTaskConflicts' },
        { 'id': 5, 'name': 'mapReminderSchedule' },
        { 'id': 6, 'name': 'mapCareTeam' },
        { 'id': 7, 'name': 'managedPopulationSummary' },
      ];

      //Tab and Step Definitions
      scope.tabDefinitions = [
        { name: 'managedPopulationInformation', number: '1', title: 'General Information', selectionCss: 'first active', completed: false, clickable:false, isTabCompleted:false },
        { name: 'mapPopulationDefinition', number: '2', title: 'Map Library Components', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false },
        { name: 'managedPopulationSummary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false }
      ];
          
      scope.stepDefinitions = [
          //Select Ideal Target task type Tab
        [
          { name: 'managedPopulationInformation', letter: 'a', title: 'General Information', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false  }
        ],

        [
          { name: 'mapPopulationDefinition', letter: 'a', title: 'Map Population Definition', selectionCss: 'active', completed: false, allowStepNavigation: id !== null ? false : true, clickable:false, isTabCompleted:false  },
          { name: 'mapTaskBundles', letter: 'b', title: 'Map Task Bundle(s)', selectionCss: 'inactive', completed: false, allowStepNavigation: id !== null ? false : true, clickable:false, isTabCompleted:false  },
          { name: 'mapResolveTaskConflicts', letter: 'c', title: 'Resolve Task Conflict(s)', selectionCss: 'inactive', completed: false, allowStepNavigation: id !== null ? false : true, clickable:false, isTabCompleted:false  },
          { name: 'mapReminderSchedule', letter: 'd', title: 'Map Reminder Schedule', selectionCss: 'inactive', completed: false, allowStepNavigation: id !== null ? false : true, clickable:false, isTabCompleted:false  },
          { name: 'mapCareTeam', letter: 'e', title: 'Map Care Team(s)', selectionCss: 'inactive', completed: false, allowStepNavigation: id !== null ? false : true, clickable:false, isTabCompleted:false  }
        ],

        [
          { name: 'managedPopulationSummary', letter: 'a', title: '', selectionCss: 'active', completed: false, allowStepNavigation: id !== null ? false : true }
        ]
        
      ];
  
    }]);

})(window.app);
