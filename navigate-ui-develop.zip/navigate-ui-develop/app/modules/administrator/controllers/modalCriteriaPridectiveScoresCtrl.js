(function (app) {
  'use strict';
  
  app.controller('pridectiveScoresCtrl', ['$scope','$modalInstance','populationDefinitionSvc',function(scope,modalInstance,populationDefinitionSvc){
    scope.selectedItems = [];

    scope.getacgoperatersDetails = function(){
      populationDefinitionSvc.populationDefinitionGetData('acg-names').then(function(response){
        if(response.data.results){
          scope.acgDetails = response.data.results;
        }
      });
      populationDefinitionSvc.populationDefinitionGetData('operators').then(function(response){
        if(response.data.results){
          scope.valueDD = response.data.results;
          scope.valueSymbolsDD = response.data.results;
        }
      });
    };


    scope.savepridectiveScores = function(){
      modalInstance.dismiss('cancel');
    };

    scope.closePopup = function(){modalInstance.dismiss('cancel');};

    scope.getacgoperatersDetails();

  }]);
})(window.app);