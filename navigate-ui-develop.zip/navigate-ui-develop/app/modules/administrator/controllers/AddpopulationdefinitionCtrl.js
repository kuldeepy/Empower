
(function (app) {
  'use strict';
  
  app.controller('AddPopulationDefinitionCtrl', ['$scope', '$state','listStateSvc','$location','PatientData','$timeout','modalService','populationDefinitionSvc','$modal',
  function (scope, state, listStateSvc, location, patientData, timeout, modalService, populationDefinitionSvc, $modal) {
    var modalOptions = {};
    scope.alert = 'navbar';
    scope.isPreviousOrCancel = false;
    patientData.isTaskAddedSuccesfully = false;
    scope.isCancelAlertVisible = false;
    scope.isPreviousMsg = false;
    scope.buildDetails = [];
    scope.cancelMessage = '';
    scope.errorMessage = 'Unfortunately, we are not able to complete the task right now. Please try again later or contact your system administrator if this continues.';
    scope.steps = [
      { name: 'pdgeneralinformation', letter: 'a', title: 'General Information', selectionCss: 'active', completed: true }
    ];
    scope.tabs = [
      { name: 'generalinformationtab', order: '1', number: '1', title: 'General Information', selectionCss: 'first active', completed: false},
      { name: 'selectcriteriatab', order: '2', number: '2', title: 'Select Criteria Type', selectionCss: 'inactive', completed: false },
      { name: 'summarytab', order: '3', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false }
    ];

    scope.modalOpenPatientInfomation = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaPatientInformation.html',
        'controller':'modalCriteriaPatientInformationCtrl',
        'size':'lg',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenProcedures = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaProcedures.html',
        'size':'lg',
        'controller':'modalCriteriaProceduresCtrl',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenDiagnosis = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaDiagnosis.html',
        'size':'lg',
        'controller':'Diagnosis',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenMedications = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaMedications.html',
        'size':'lg',
        'controller':'Medication',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenLabs = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaLabs.html',
        'size':'lg',
        'controller':'Labs',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenVitals = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaVitals.html',
        'size':'lg',
        'controller':'Vitals',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenUtilization = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaUtilization.html',
        'size':'lg',
        'controller':'Utilization',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenEpisodicGroupers = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaEpisodicGroupers.html',
        'controller':'episodicGroupersCtrl',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenPredectiveScores = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaPridectiveScores.html',
        'controller':'pridectiveScoresCtrl',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenCareProviders = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaCareProvider.html',
        'controller':'CareProvider',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenInsurance = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaInsurance.html',
        'controller':'Insurance',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenAssessments = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaAssessments.html',
        'controller':'modalCriteriaAssessmentCtrl',
        'size':'lg',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    scope.modalOpenADTFeed = function (CriteriaName,CriteriaId) {
      scope.criteriaName=CriteriaName;
      scope.criteriaId=CriteriaId;
      var modalDefaults = {
        'templateUrl': app.root + 'modules/administrator/templates/modalCriteriaADT.html',
        'controller':'modalCriteriaADTCtrl',
        'size':'sm',
        'scope':scope
      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.copyProviders = scope.masterProviders;
      modalService.showModal(modalDefaults, modalOptions);
    };

    //Tab and Step Definitions
    scope.tabDefinitions = [
        { name: 'generalinformationtab', order: '1', number: '1', title: 'General Information', selectionCss: 'first active', completed: false},
        { name: 'selectcriteriatab', order: '2', number: '2', title: 'Select Criteria Type', selectionCss: 'inactive', completed: false },
        { name: 'summarytab', order: '3', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false }
      ];
      
    scope.stepDefinitions = [
      [
        { name: 'pdgeneralinformation', letter: 'a', title: 'General Information', selectionCss: 'active', completed: false }
      ],
      [
        { name: 'pdselectCriteria', letter: 'a', title: 'Select Criteria', selectionCss: 'inactive', completed: false },
        { name: 'pdbuildDefinition', letter: 'b', title: 'Build Definition', selectionCss: 'inactive', completed: true }
      ],
      [
        { name: 'pdsummary', letter: 'a', title: 'Summary', selectionCss: 'inactive', completed: false }
      ]
    ];
    
    scope.updateWizardHeaders = function (currentStepName) {
      var tabIndex = 0;
      var stepIndex = 0;
      var tempTabs = [];
      var tempSteps = [];
        
      for (var i = 0; i < scope.stepDefinitions.length; i = i + 1) {
        for (var j = 0; j < scope.stepDefinitions[i].length; j = j + 1) {
          if (scope.stepDefinitions[i][j].name === currentStepName) {
            tabIndex = i;
            stepIndex = j;
          }
        }
      }

      for (var k = 0; k < scope.tabDefinitions.length; k = k + 1) {
        tempTabs.push(scope.tabDefinitions[k]);
      }
      for (var l = 0; l < scope.stepDefinitions[tabIndex].length; l = l + 1) {
        tempSteps.push(scope.stepDefinitions[tabIndex][l]);
      }
        
      for (var m = 0; m < scope.tabDefinitions.length; m = m + 1) {
        if (m === tabIndex) {
          tempTabs[m].completed = false;
          tempTabs[m].active = true;
          tempTabs[m].selectionCss = 'active';
        } else {
          tempTabs[m].active = false;
        }
        if (m < tabIndex) {
          tempTabs[m].completed = true;
          tempTabs[m].selectionCss = 'success';
        }
        if (m > tabIndex) {
          tempTabs[m].completed = false;
          tempTabs[m].selectionCss = 'inactive';
        }
        if (m === 0) {
          tempTabs[m].selectionCss = tempTabs[m].selectionCss + ' first';
        }
        if (m === scope.tabDefinitions.length - 1) {
          tempTabs[m].selectionCss = tempTabs[m].selectionCss + ' last';
        }
      }
      for (var n = 0; n < scope.stepDefinitions[tabIndex].length; n = n + 1) {
        if (n === stepIndex) {
          tempSteps[n].completed = false;
          tempSteps[n].active = true;
          tempSteps[n].selectionCss = 'active';
        } else {
          tempSteps[n].active = false;
        }
        if (n < stepIndex) {
          tempSteps[n].completed = true;
          tempSteps[n].selectionCss = 'success';
        }
        if (n > stepIndex) {
          tempSteps[n].completed = false;
          tempSteps[n].selectionCss = 'inactive';
        }
      }

      while (scope.steps.length > 0) { scope.steps.pop(); }
      while (scope.tabs.length > 0) { scope.tabs.pop(); }
        
      for (var x = 0; x < tempTabs.length; x = x + 1) {
        scope.tabs.push(tempTabs[x]);
      }
      for (var y = 0; y < tempSteps.length; y = y + 1) {
        scope.steps.push(tempSteps[y]);
      }
    };

    scope.resetState = function () {
      scope.definitionDiv = true;
      scope.summaryClass = 'lb-body-content';
    };

    var modalInstance ={};
    
    scope.popupAction = function () {
        
      modalInstance = $modal.open({
        templateUrl: 'populationDefinitionCancelPopup.html',
        size: '',
        scope: scope,
        backdrop: 'static'
      });
    };

    scope.cancelPopulationDefinition = function () {
      scope.isPreviousOrCancel = true;
      scope.$broadcast('wizardonCancel');
      var currentListState = listStateSvc.get();
      var populationDefinitionId=currentListState.CurrentUIState.populationDefinition.id;
      if(currentListState.CurrentUIState.populationDefinition.isDraft === true) {
        if(!currentListState.CurrentUIState.flag){
          populationDefinitionSvc.populationDefinitiondeleteRequest('population-definition/'+ populationDefinitionId).then(function(response){
            if(response.data.results){
              scope.isCancelAlertVisible = false;
              scope.closePopulationDefinition();
            }
          });
        }
        else {
          scope.isCancelAlertVisible = true;
          window.scrollTo(0,document.body.scrollHeight);
          scope.alert = 'alert-cancel';
          scope.isPreviousMsg = false;
          scope.popupAction();
        }
      }
      else {
        scope.closePopulationDefinition();
        window.location.reload(true);
      }
    };

    scope.closePopulationDefinition = function(){
      listStateSvc.clear();
      if(app !== undefined && app.currentRoute !== undefined) {
        location.path(app.currentRoute +'/library/population');
      }
      else{
        location.path('/library/population');
      }
    };

    scope.SavePopulationDefintion = function(status){
      var currentListState = listStateSvc.get();
      var populationDefinitionId=currentListState.CurrentUIState.populationDefinition.id;
      scope.generalInformation = {productionStatus:status};
      if(status === 'Final')
      {
        populationDefinitionSvc.populationDefinitionPutData('population-definition/'+ populationDefinitionId,scope.generalInformation).then(function(response){
          if(response.data.results){
            populationDefinitionSvc.isAddedSuccesfully = true;
            if(currentListState.CurrentUIState.populationDefinition.isNew===true){
              populationDefinitionSvc.messageAlert = 'Population definition has been added successfully';
            }
            else{
              populationDefinitionSvc.messageAlert = 'Population definition has been updated successfully';
            }
            location.path(app.currentRoute +'/library/population');
          }
        });
      }
      else
      {
        populationDefinitionSvc.isAddedSuccesfully = true;
        populationDefinitionSvc.messageAlert = 'Population definition has been saved as draft successfully';
        location.path(app.currentRoute +'/library/population');
      }
    };

    scope.saveMessageAlert = function (alertMessage) {
      window.scrollTo(0, 0);
      scope.alertMessage = alertMessage;
      scope.alertType = 'background-green color-white';
      scope.isAlertMessage = true;
      timeout(function () {
        scope.isAlertMessage = false;
        listStateSvc.clear();
        if(app !== undefined && app.currentRoute !== undefined) {
          location.path(app.currentRoute +'/library/population');
        }
        else{
          location.path('/library/population');
        }
      }, 6000);
    };

    scope.updateButtonVisibility = function(stepName){
      scope.resetState();
      if(stepName==='pdsummary')
      {
        scope.definitionDiv = false;
        scope.showWizardSteps = false;
        scope.summaryClass='lb-body-content-max';
      } else {
        scope.showWizardSteps = true;
      }

    };

    scope.updatePopulationDefinitionscope = function(step){
      var currentListState = listStateSvc.get();
      var populationDefinitionDetails = {
        id : currentListState.CurrentUIState.populationDefinition.id,
        state : step,
        isNew : currentListState.CurrentUIState.populationDefinition.isNew,
        isDraft : currentListState.CurrentUIState.populationDefinition.isDraft
      };
      currentListState.CurrentUIState.populationDefinition = populationDefinitionDetails;
      currentListState.CurrentUIState.flag = true;
      currentListState.CurrentUIState.criteriaIds = [];
      listStateSvc.set(currentListState);
    };

    scope.goToNext = function (criteria) {
      if(state.current.name ==='pdselectCriteria'){
        scope.updatePopulationDefinitionscope('pdbuildDefinition');
        state.go('pdbuildDefinition');
      }
      else if(state.current.name ==='pdbuildDefinition'){
        var currentListState = listStateSvc.get();
        var populationDefinitionId = currentListState.CurrentUIState.populationDefinition.id;
        if(currentListState.CurrentUIState.criteriaIds.length > 0){
          var criteriaIds = currentListState.CurrentUIState.criteriaIds.toString();
          populationDefinitionSvc.populationDefinitiondeleteRequest('population-definition/' + populationDefinitionId + '/criterias/' + criteriaIds).then(function(){
          });
          currentListState.CurrentUIState.criteriaIds = [];
          listStateSvc.set(currentListState);
        }
        scope.buildCriteria(criteria);
      }
    };

    scope.buildCriteria = function(criteria){
        var populationDefinitionDetails = listStateSvc.get();
        var populationDefinitionId = populationDefinitionDetails.CurrentUIState.populationDefinition.id;
        var buildCriteria = [];
        criteria[0].nodes.forEach(function(res){
          buildCriteria.push({criteriaId:res.id,
                              criteriaSql:res.criteriaSQL,
                              criteriaName:res.criteriaName,
                              criteriaText:res.title,
                              logicalOperator:res.operator,
                              parentId:''});
          if(res.nodes.length>0)
          {
            var node=res.nodes;
            scope.nodeLoop(node,res.id,buildCriteria);
          }
        });
        if(buildCriteria.length>0)
        {
          buildCriteria[buildCriteria.length-1].logicalOperator = '';
        }
        var Build={'buildCriteria':buildCriteria};
        scope.isBuildCriteriaOpen = false;
        scope.isNextDisabled = false;
        scope.isTextDefinitionOpen = true;
        populationDefinitionSvc.populationDefinitionPostData('population-definition/'+populationDefinitionId+'/build-definition',Build).then(function(response){
          if(response.data.results){
            if(response.data.results===true){
              scope.updatePopulationDefinitionscope('pdsummary');
              state.go('pdsummary');
            }
          }
        });
      };

    scope.nodeLoop = function(node,id,buildCriteria){
        node.forEach(function(res){
          buildCriteria.push({criteriaId:res.id,
                              criteriaSql:res.criteriaSQL,
                              criteriaName:res.criteriaName,
                              criteriaText:res.title,
                              logicalOperator:res.operator,
                              parentId:id});
          if(res.nodes.length>0)
          {
            var node1=res.nodes;
            scope.nodeLoop(node1,res.id,buildCriteria);
          }
        });
      };
    scope.redirectstate = '';
    scope.goToPrevious = function () {
      if(state.current.name ==='pdselectCriteria'){
        scope.updatePopulationDefinitionscope('pdgeneralinformation');
        state.go('pdgeneralinformation');
      }
      else if(state.current.name ==='pdbuildDefinition'){
        scope.updatePopulationDefinitionscope('pdselectCriteria');
        state.go('pdselectCriteria');
      }
      else if(state.current.name ==='pdsummary'){
        scope.updatePopulationDefinitionscope('pdbuildDefinition');
        state.go('pdbuildDefinition');
      }
    };

    scope.closeCancelAlert = function () {
      modalInstance.close(true);
      scope.alert = 'navbar';
    };

    scope.goto = function(page){
      scope.redirectstate=page;
      scope.isPreviousOrCancel = false;
      scope.continueCancelAlert();
    };

    scope.continueCancelAlert = function () {
      scope.alert = 'navbar';
      var currentListState = listStateSvc.get();
      if(scope.isPreviousOrCancel === false)
      {
        var populationDefinitionDetails = {
          id : currentListState.CurrentUIState.populationDefinition.id,
          state : scope.redirectstate,
          isNew : currentListState.CurrentUIState.populationDefinition.isNew,
          isDraft : currentListState.CurrentUIState.populationDefinition.isDraft
        };
        currentListState.CurrentUIState.populationDefinition = populationDefinitionDetails;
        listStateSvc.set(currentListState);
        state.go(scope.redirectstate);
      }
     else
      {
        modalInstance.close(true);
        window.scrollTo(0,document.body.scrollHeight);
        var populationDefinitionId=currentListState.CurrentUIState.populationDefinition.id;
        populationDefinitionSvc.populationDefinitiondeleteRequest('population-definition/'+ populationDefinitionId).then(function(){
        });
        scope.closePopulationDefinition();
      }
    };

    scope.initializeStep = function (stepName) {
      scope.updateWizardHeaders(stepName);
      scope.updateButtonVisibility(stepName);
    };

    scope.isPopulationDefinitionExists = function(){
      var populationDefinitionDetails = listStateSvc.get();
      if(populationDefinitionDetails.CurrentUIState.populationDefinition.isNew === true)
      {
        scope.populationDefinitionHeader = 'Add Population Definition';
      }
      else{
        scope.populationDefinitionHeader = 'Edit Population Definition';
      }
      var populationDefinitionState = populationDefinitionDetails.CurrentUIState.populationDefinition.state;
      state.go(populationDefinitionState);
    };

    scope.getBuildedCriteria = function(){
      var populationDefinitionDetails = listStateSvc.get();
      var populationDefinitionId = populationDefinitionDetails.CurrentUIState.populationDefinition.id;
      populationDefinitionSvc.populationDefinitionGetData('population-definition/'+populationDefinitionId+'/summary').then(function(response){
          if(response.data.results){
            scope.buildDetails = response.data.results.criterias;
          }
        });
    };
    

    scope.ShowNotifications = function (alertMsg,alertTyp) {
      scope.alertMessage = alertMsg;
      scope.alertType = alertTyp; //--alert-error --alert-success
      scope.isAlertMessage = true;
      timeout(function () {scope.isAlertMessage = false;}, 6000);
    };

    //TODO : Need to remove this code since we have notification directive
    scope.showErrorNotifications = function(message){
      scope.isErrorAlertMessage=true;
      scope.errorAlertMessage = message;
      timeout(function () {scope.isErrorAlertMessage = false;}, 6000);
    };
    
    scope.closeAlert = function(){
      scope.alertMessage ='';
      scope.isAlertMessage = false;
    };

    scope.closeErrorAlert = function(){
      scope.isErrorAlertMessage = false;
    };
    scope.isPopulationDefinitionExists();

  }]);
})(window.app);