(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('SelectCriteriaCtrl', ['$scope','listStateSvc','populationDefinitionSvc',
    function (scope,listStateSvc,populationDefinitionSvc) {
      if (scope.initializeStep) {
        scope.initializeStep('pdselectCriteria', true);
      }
      scope.isShowCriteriaCancel = true;
      scope.criteriaDetails = [];
      scope.ShowCriteria = function(criteriaType,criteriaName,criteriaId){
        switch(criteriaType){
          case 'Patient Information':
            scope.modalOpenPatientInfomation(criteriaName,criteriaId);
            break;
          case 'Procedures':
            scope.modalOpenProcedures(criteriaName,criteriaId);
            break;
          case 'Diagnosis':
            scope.modalOpenDiagnosis(criteriaName,criteriaId);
            break;
          case 'Medications':
            scope.modalOpenMedications(criteriaName,criteriaId);
            break;
          case 'Labs':
            scope.modalOpenLabs(criteriaName,criteriaId);
            break;
          case 'Vitals':
            scope.modalOpenVitals(criteriaName,criteriaId);
            break;
          case 'Utilization':
            scope.modalOpenUtilization(criteriaName,criteriaId);
            break;
          case 'Episodic Groupers':
            scope.modalOpenEpisodicGroupers(criteriaName,criteriaId);
            break;
          case 'Predictive Scores':
            scope.modalOpenPredectiveScores(criteriaName,criteriaId);
            break;
          case 'Care Providers':
            scope.modalOpenCareProviders(criteriaName,criteriaId);
            break;
          case 'Insurance':
            scope.modalOpenInsurance(criteriaName,criteriaId);
            break;
          case 'Assessments':
            scope.modalOpenAssessments(criteriaName,criteriaId);
            break;
          case 'ADT Feed':
            scope.modalOpenADTFeed(criteriaName,criteriaId);
            break;
        }
      };

      scope.$on('wizardonCancel', function() {
        var currentListState = listStateSvc.get();
        currentListState.CurrentUIState.flag = true;
        listStateSvc.set(currentListState);
      });

      scope.getPDCriteriaList = function(){
        if(listStateSvc.get().CurrentUIState.populationDefinition.isDraft === false){
          scope.isShowCriteriaCancel = false;
        }
        populationDefinitionSvc.populationDefinitionGetData('criteria-types').then(function(response){
          if(response.data.results){
            scope.criteriaDetails = response.data.results;
            scope.getBuildedCriteria();
          }
        });

      };

      scope.collapseExpand=function(data,criteriaDetails){
        criteriaDetails.forEach(function(res){
          if(data.id !== res.id){
            res.collapsed = false;
          }
        });
        data.collapsed = !data.collapsed;
      };

      scope.getPDCriteriaList();
      
    }]);
  }(window.app));