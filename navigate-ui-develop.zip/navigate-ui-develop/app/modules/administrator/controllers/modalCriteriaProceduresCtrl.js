(function (app) {
  'use strict';
  
  app.controller('modalCriteriaProceduresCtrl', ['$scope','$modalInstance','$http','$timeout','$window','listStateSvc','populationDefinitionSvc',
    function (scope,modalInstance,http,$timeout,$window,listStateSvc,populationDefinitionSvc) {
        var tempModalOptions = {};
        scope.modalOptions = tempModalOptions;
        scope.timeInMs = 0;
        scope.Linkpopup=function(){
          switch(scope.criteriaName){
          case 'CPT':
            scope.cptDiv=true;
            scope.modalOptions.headerText='CPT Codes';
            scope.CPTInfoData={};
            scope.CPTInfoData.equals='Equals';
            tempModalOptions.selectedOptions=[];
            tempModalOptions.selectedData = [];
            tempModalOptions.available=[];
            tempModalOptions.listValues=[];
            tempModalOptions.placeholder='Enter 3 chars min';
            scope.selectedData={};
            scope.CPTInfoData.listValues=[];
            scope.modalOptions = tempModalOptions;
            scope.modalOptions.selectedData=[];
            scope.modalOptions.httptest=http;
            scope.multiselect={'url':'cpt-codes','http':scope.modalOptions.httptest,'checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.available,'selectedavailabledata':scope.CPTInfoData.listValues};
            break;
          case 'CPT-CAT-II':
            scope.cptcatDiv=true;
            scope.modalOptions.headerText='CPT Codes II';
            scope.CPT2InfoData={};
            scope.CPT2InfoData.equals='Equals';
            tempModalOptions.selectedOptions=[];
            tempModalOptions.selectedData = [];
            tempModalOptions.available=[];
            tempModalOptions.listValues=[];
            tempModalOptions.placeholder='Enter 3 chars min';
            scope.selectedData={};
            scope.modalOptions.selectedData=[];
            scope.CPT2InfoData.listValues=[];
            scope.modalOptions = tempModalOptions;
            scope.modalOptions.httptest=http;
            scope.multiselect={'url':'procedure-codes','http':scope.modalOptions.httptest,'Type':'CPT-CAT-II','checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.available,'selectedavailabledata':scope.CPT2InfoData.listValues};
            break;
          case 'HCPCS':
            scope.hcpcsDiv=true;
            scope.modalOptions.headerText='HCPCS Codes';
            scope.HCPCSInfoData={};
            scope.HCPCSInfoData.equals='Equals';
            tempModalOptions.selectedOptions=[];
            tempModalOptions.selectedData = [];
            tempModalOptions.available=[];
            tempModalOptions.listValues=[];
            tempModalOptions.placeholder='Enter 3 chars min';
            scope.selectedData={};
            scope.HCPCSInfoData.listValues=[];
            scope.modalOptions.httptest=http;
            scope.modalOptions = tempModalOptions;
            scope.multiselect={'url':'procedure-codes','http':scope.modalOptions.httptest,'Type':'HCPCS','checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.available,'selectedavailabledata':scope.HCPCSInfoData.listValues};
            break;
          case 'ICD-10-CM-Proc':
            scope.icdDiv=true;
            scope.modalOptions.headerText='ICD-10 CM Procedure Codes';
            scope.ICDInfoData={};
            scope.ICDInfoData.equals='Equals';
            tempModalOptions.selectedOptions=[];
            tempModalOptions.selectedData = [];
            tempModalOptions.available=[];
            tempModalOptions.listValues=[];
            tempModalOptions.placeholder='Enter 3 chars min';
            scope.selectedData={};
            scope.ICDInfoData.listValues=[];
            scope.modalOptions.httptest=http;
            scope.modalOptions = tempModalOptions;
            scope.multiselect={'url':'procedure-codes','http':scope.modalOptions.httptest,'Type':'ICD-9-CM-Proc','checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.available,'selectedavailabledata':scope.ICDInfoData.listValues};
            break;
          case 'UB-Revenue':
            scope.revenueDiv=true;
            scope.modalOptions.headerText='UB Revenue Codes';
            scope.RevenueData={};
            scope.RevenueData.equals='Equals';
            tempModalOptions.selectedOptions=[];
            tempModalOptions.selectedData = [];
            tempModalOptions.available=[];
            tempModalOptions.listValues=[];
            tempModalOptions.placeholder='Enter 3 chars min';
            scope.selectedData={};
            scope.RevenueData.listValues=[];
            scope.modalOptions.httptest=http;
            scope.modalOptions = tempModalOptions;
            scope.multiselect={'url':'procedure-codes','http':scope.modalOptions.httptest,'Type':'UB-Revenue','checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.available,'selectedavailabledata':scope.RevenueData.listValues};
            break;
          case 'Procedure Groupers':
            scope.procedureGroupers=true;
            scope.modalOptions.headerText='Procedure Groupers';
            scope.procedureSearch={};
            scope.ProcedureGroupersData={};
            scope.ProcedureGroupersData.radioType='0';
            populationDefinitionSvc.populationDefinitionGetData('code-grouping-source/?searchText=Procedure Groupers').then(function(response){
              if(response.data.results){
                scope.soureceDD=response.data.results;
                populationDefinitionSvc.populationDefinitionGetData('operators').then(function(responseoperator){
                  if(responseoperator.data.results){
                    scope.amountSymbolsDD=responseoperator.data.results;
                  }
                });
              }
            });
            tempModalOptions.available = [];
            tempModalOptions.selected = [];
            scope.modalOptions = tempModalOptions;
            scope.ProcedureGroupersData.listValues = [];
            break;
          }
        };

        scope.searchProcedureGroup=function(item){
          if(item && item.source){
            var grouperName='&groupersText='+item.grouperName;
            var isTask='isTask=1&';
            populationDefinitionSvc.populationDefinitionGetData('search-code-groupers/?'+(item.isTask?isTask:'')+'sourceId='+item.source+''+(item.grouperName?grouperName:'')).then(function(response){
              if(response.data.results){
                scope.ProcedureGroupersData.listValues=[];
                scope.modalOptions.available=response.data.results;
              }
            });
          }
        };
        scope.searchProcedureGroupClear=function(){
          scope.procedureSearch={};
        };

        scope.clickaddProceduresInformation=function(SaveLink,data){
          switch(SaveLink){
            case 'CPT':
              data.criteriaTypeId=scope.criteriaId;
              data.criteriaTypeName= scope.criteriaName;
              data.listValues=scope.multiselect.selectedavailabledata;
              data.radioType= '';
              data = {'equalsOperator':data.equals,'listValues':data.listValues,'value1':data.value1,'value2':data.value2,'criteriaTypeId':data.criteriaTypeId,'criteriaTypeName':data.criteriaTypeName,'radioType':data.radioType};
              populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',data).then(function(response){
                if(response.data.results){
                  if(response.data.results === true)
                 {
                    modalInstance.dismiss('cancel');
                    scope.getBuildedCriteria();
                  }
                }
              });

              break;
            case 'CPT-CAT-II':
              data.criteriaTypeId=scope.criteriaId;
              data.criteriaTypeName= scope.criteriaName;
              data.listValues=scope.multiselect.selectedavailabledata;
              data.radioType= '';
              data = {'equalsOperator':data.equals,'listValues':data.listValues,'value1':data.value1,'value2':data.value2,'criteriaTypeId':data.criteriaTypeId,'criteriaTypeName':data.criteriaTypeName,'radioType':data.radioType};
              populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',data).then(function(response){
                if(response.data.results){
                  if(response.data.results === true)
                 {
                    modalInstance.dismiss('cancel');
                    scope.getBuildedCriteria();
                  }
                }
              });

              break;
            case 'HCPCS':
              data.criteriaTypeId = scope.criteriaId;
              data.criteriaTypeName = scope.criteriaName;
              data.listValues = scope.multiselect.selectedavailabledata;
              data.radioType = '';
              data = {'equalsOperator':data.equals,'listValues':data.listValues,'value1':data.value1,'value2':data.value2,'criteriaTypeId':data.criteriaTypeId,'criteriaTypeName':data.criteriaTypeName,'radioType':data.radioType};
              populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',data).then(function(response){
                if(response.data.results){
                  if(response.data.results === true)
                 {
                    modalInstance.dismiss('cancel');
                    scope.getBuildedCriteria();
                  }
                }
              });
              break;
            case 'ICD-10-CM-Proc':
              data.criteriaTypeId=scope.criteriaId;
              data.criteriaTypeName= scope.criteriaName;
              data.listValues=scope.multiselect.selectedavailabledata;
              data.radioType= '';
              data = {'equalsOperator':data.equals,'listValues':data.listValues,'value1':data.value1,'value2':data.value2,'criteriaTypeId':data.criteriaTypeId,'criteriaTypeName':data.criteriaTypeName,'radioType':data.radioType};
              populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',data).then(function(response){
                if(response.data.results){
                  if(response.data.results === true)
                 {
                    modalInstance.dismiss('cancel');
                    scope.getBuildedCriteria();
                  }
                }
              });
              break;
            case 'UB-Revenue':
              data.criteriaTypeId=scope.criteriaId;
              data.criteriaTypeName= scope.criteriaName;
              data.listValues=scope.multiselect.selectedavailabledata;
              data.radioType= '';
              data.value1=!data.value1?'':data.value1;
              data.value2=!data.value2?'':data.value2;
              data = {'equalsOperator':data.equals,'listValues':data.listValues,'value1':data.value1,'value2':data.value2,'criteriaTypeId':data.criteriaTypeId,'criteriaTypeName':data.criteriaTypeName,'radioType':data.radioType};
              populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',data).then(function(response){
                if(response.data.results){
                  if(response.data.results === true)
                 {
                    modalInstance.dismiss('cancel');
                    scope.getBuildedCriteria();
                  }
                }
              });
              break;
            case 'Procedure Groupers':
              scope.InsertProcedureGroupers={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':'','radioType':data.radioType==='0'?'Duration':'Cost','value1':data.radioType==='0'?!data.value1?'':data.value1:!data.symbol?'':data.symbol,'value2':data.radioType==='0'?!data.value2?'':data.value2:!data.amount?'':data.amount,'listValues':data.listValues};
              populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.InsertProcedureGroupers).then(function(response){
                if(response.data.results){
                  if(response.data.results === true)
                 {
                    modalInstance.dismiss('cancel');
                    scope.getBuildedCriteria();
                  }
                }
              });
              break;
          }
        };
        scope.modalOptions.close = function () {
          modalInstance.dismiss('cancel');
        };
        scope.clearAllData=function(){
          scope.ProcedureGroupersData.value1='';
          scope.ProcedureGroupersData.value2='';
          scope.ProcedureGroupersData.symbol='';
          scope.ProcedureGroupersData.amount='';
        };
        scope.Linkpopup();
      }]);
})(window.app);
