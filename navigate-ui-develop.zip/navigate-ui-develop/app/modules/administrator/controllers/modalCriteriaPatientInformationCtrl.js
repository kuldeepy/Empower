(function (app) {
  'use strict';
  
  app.controller('modalCriteriaPatientInformationCtrl', ['$scope','$modalInstance','$timeout','listStateSvc','populationDefinitionSvc',
    function (scope,modalInstance,$timeout, listStateSvc,populationDefinitionSvc) {
      var tempModalOptions = {};
      //Map modal.html $scope custom properties to defaults defined in service
      scope.modalOptions = tempModalOptions;
      scope.timeInMs = 0;
      scope.PatientDemographicsInfoData={};
      scope.CloseAllPopUp = function(){
        scope.PatientDemographics=false;
        scope.Languages=false;
        scope.Race=false;
        scope.Ethinicity=false;
        scope.City=false;
        scope.State=false;
        scope.ZipCodes=false;
      };

      scope.Linkpopup=function(){
        switch(scope.criteriaName){
          case 'Patient Demographics':
            scope.modalOptions.headerText='Patient Demographics';
            scope.PatientDemographics=true;
            scope.PatientDemographicsInfoData={};
            scope.PatientDemographicsInfoData.gender='Male';
            populationDefinitionSvc.populationDefinitionGetData('operators').then(function(responseoperator){
              if(responseoperator.data.results){
                scope.OperatorsDD=responseoperator.data.results;
                scope.OperatorsFromDD=responseoperator.data.results;
              }
            });
            break;
          case 'Languages':
            scope.Languages=true;
            scope.modalOptions.headerText='Languages';
            scope.LanguagesInfoData={};
            scope.LanguagesInfoData.equalsOperator='Equals';
            scope.modalOptions.Languagesavailable=[];
            scope.LanguagesInfoData.listValues=[];
            populationDefinitionSvc.populationDefinitionGetData('languages').then(function(response){
              if(response.data.results){
                scope.modalOptions.Languagesavailable=response.data.results;
              }
            });
            break;
          case 'Race':
            scope.Race=true;
            scope.modalOptions.headerText='Race';
            scope.RaceData={};
            scope.RaceData.equalsOperator='Equals';
            scope.modalOptions.Raceavailable=[];
            scope.RaceData.listValues=[];
            populationDefinitionSvc.populationDefinitionGetData('races').then(function(response){
              if(response.data.results){
                scope.modalOptions.Raceavailable=response.data.results;
              }
            });
            break;
          case 'Ethnicity':
            scope.Ethnicity=true;
            scope.modalOptions.headerText='Ethnicity';
            scope.EthinicityData={};
            scope.EthinicityData.equalsOperator='Equals';
            scope.modalOptions.Ethinicityavailable=[];
            scope.EthinicityData.listValues=[];
            populationDefinitionSvc.populationDefinitionGetData('ethnicities').then(function(response){
              if(response.data.results){
                scope.modalOptions.Ethnicitiesavailable=response.data.results;
              }
            });
            break;
          case 'City':
            scope.City=true;
            scope.CityInfoData={};
            scope.modalOptions.headerText='Cities';
            scope.CityData={};
            scope.CityData.equalsOperator='Equals';
            scope.modalOptions.Cityavailable=[];
            scope.CityData.listValues=[];
            break;
          case 'State':
            scope.State=true;
            scope.modalOptions.headerText='States';
            scope.StateData={};
            scope.StateData.equalsOperator='Equals';
            scope.modalOptions.Stateavailable=[];
            scope.StateData.listValues=[];
            populationDefinitionSvc.populationDefinitionGetData('states').then(function(response){
              if(response.data.results){
                scope.modalOptions.Stateavailable=response.data.results;
              }
            });
            break;
          case 'Zip Codes':
            scope.ZipCodes=true;
            scope.ZipCodeInfoData={};
            scope.modalOptions.headerText='Zip Codes';
            scope.ZipCodeInfoData={};
            scope.ZipCodeInfoData.equalsOperator='Equals';
            scope.modalOptions.Zipavailable=[];
            scope.ZipCodeInfoData.listValues=[];
            break;
        }
      };

      scope.AddCity=function(listValues){
        if(listValues!==''){
          scope.modalOptions.Cityavailable.push({id:null,name:listValues});
          scope.CityInfoData.City='';
        }
      };

      scope.AddZipCode=function(selectedZip){
        if(selectedZip!==''){
          scope.modalOptions.Zipavailable.push({id:null,name:selectedZip});
          scope.ZipCodeInfoData.Zip='';
        }
      };
        
      scope.clickaddPatientDemographicsInformation=function(SaveLink,data){
        var currentListState = listStateSvc.get();
        data.criteriaTypeId=scope.criteriaId;
        data.criteriaTypeName= SaveLink;
        scope.Populationid=currentListState.CurrentUIState.populationDefinition.id;
        switch(SaveLink){
          case 'Patient Demographics':
            data.operator1=!data.operator1?'':data.operator1;
            data.operator2=!data.operator2?'':data.operator2;
            data.input1=!data.input1?'':data.input1;
            data.input2=!data.input2?'':data.input2;
            populationDefinitionSvc.populationDefinitionPostData('population-definition/' +scope.Populationid+'/demographics-criteria',data).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
            break;
          case 'Languages':
            data.radioType= '';
            data.value1 = '';
            data.value2= '';
            populationDefinitionSvc.populationDefinitionPostData('population-definition/' +scope.Populationid+'/criteria',scope.LanguagesInfoData).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
            break;
          case 'Race':
            data.radioType= '';
            data.value1 = '';
            data.value2= '';
            populationDefinitionSvc.populationDefinitionPostData('population-definition/' +scope.Populationid+'/criteria',scope.RaceData).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
            break;
          case 'Ethnicity':
            data.radioType= '';
            data.value1 = '';
            data.value2= '';
            populationDefinitionSvc.populationDefinitionPostData('population-definition/' +scope.Populationid+'/criteria',scope.EthinicityData).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
            break;
          case 'City':
            data.radioType= '';
            data.value1 = '';
            data.value2= '';
            populationDefinitionSvc.populationDefinitionPostData('population-definition/' +scope.Populationid+'/criteria',scope.CityData).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
            break;
          case 'State':
            data.radioType= '';
            data.value1 = '';
            data.value2= '';
            var listVal = [];
            scope.StateData.listValues.forEach(function(res){
              listVal.push({id:res.Code,name:res.Name});
            });
            scope.StateData.listValues=listVal;
            populationDefinitionSvc.populationDefinitionPostData('population-definition/' +scope.Populationid+'/criteria',scope.StateData).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
            break;
          case 'Zip Codes':
            data.radioType= '';
            data.value1 = '';
            data.value2= '';
            populationDefinitionSvc.populationDefinitionPostData('population-definition/' +scope.Populationid+'/criteria',scope.ZipCodeInfoData).then(function(response){
              if(response.data.results){
                if(response.data.results === true)
                 {
                  modalInstance.dismiss('cancel');
                  scope.getBuildedCriteria();
                }
              }
            });
            break;
        }
      };

      scope.modalOptions.close = function () {
        modalInstance.dismiss('cancel');
      };

      scope.open = function() {
        $timeout(function() {
          scope.opened = false;
        });
      };

      scope.Linkpopup();
    }]);
})(window.app);