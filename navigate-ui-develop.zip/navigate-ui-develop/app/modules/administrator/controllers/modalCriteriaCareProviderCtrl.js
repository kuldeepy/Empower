(function (app) {
  'use strict';
  
  app.controller('CareProvider', ['$scope','$modalInstance','$window','$http','listStateSvc','populationDefinitionSvc',function(scope,modalInstance,$window,http,listStateSvc,populationDefinitionSvc){
      
        var tempModalOptions = {};
        scope.timeInMs = 0;
        scope.BindPopup=function(){
          switch(scope.criteriaName){
            case 'Care Teams':
              scope.CareTeamdata={};
              scope.CareTeamdata.isequal='Equals';
              scope.CareTeamdata.selected=[];
              populationDefinitionSvc.populationDefinitionGetData('care-teams?IncludeInActive=True').then(function(response){
                if(response.data.results){
                  scope.CareTeamDD=response.data.results;
                }
              });
              scope.modalOptions = tempModalOptions;
              scope.CareTeam=true;
              break;
            case 'Clinics':
              scope.clinicsdata={};
              scope.clinicsdata.isequal='Equals';
              scope.clinicsdata.selected=[];
              tempModalOptions.options = [];
              tempModalOptions.selectedOptions=[];
              tempModalOptions.selectedData = [];
              tempModalOptions.placeholder='Enter 3 chars min';
              tempModalOptions.ClinicDD=[];
              scope.modalOptions = tempModalOptions;
              scope.modalOptions.httptest=http;
              scope.multiselect={'url':'clinics','http':scope.modalOptions.httptest,'checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.ClinicDD,'selectedavailabledata':scope.clinicsdata.selected};
              scope.Clinics=true;
              break;
            case 'PCPs':
              scope.pcpData={};
              scope.pcpData.isequal='Equals';
              scope.pcpData.selected=[];
              tempModalOptions.options = [];
              tempModalOptions.selectedOptions=[];
              tempModalOptions.selectedData = [];
              tempModalOptions.placeholder='Enter 3 chars min';
              tempModalOptions.PcpDD=[];
              scope.modalOptions = tempModalOptions;
              scope.modalOptions.httptest=http;
              scope.multiselect={'url':'primary-care-physicians','http':scope.modalOptions.httptest,'checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.PcpDD,'selectedavailabledata':scope.pcpData.selected};
              scope.PCPs=true;
              break;
    
          }
        };
        scope.close = function () {
          modalInstance.dismiss('cancel');
        };
       
        scope.AddCareTeam=function(item,name){
        
          scope.insertData={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':item.isequal==='Equals'?'Equals':'Not Equals','radioType':'','value1':'','value2':'','listValues':name==='Care Teams'?item.selected:scope.multiselect.selectedavailabledata};
          
          populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.insertData).then(function(response){
            if(response.data.results){
              if(response.data.results === true)
               {
                modalInstance.dismiss('cancel');
                scope.getBuildedCriteria();
              }
            }
          });
        };
        scope.BindPopup();
      }]);
})(window.app);