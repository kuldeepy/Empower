(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('ManagedPopulationSummaryCtrl', ['$scope','managedPopulationSvc','$location',
    function (scope,managedPopulationSvc,location) {
      if (scope.initializeStep) {
        scope.initializeStep('managedPopulationSummary', true);
      }

      scope.$on('wizardOnsaveAndClose', function () {
        scope.saveAndClose('F');
      });

      scope.$on('wizardOnsaveDraftAndClose', function () {
        scope.saveAndClose('D');
      });

      scope.saveAndClose = function (managedProductionStatus) {
        if (managedPopulationSvc.editStatus === true) {
          managedPopulationSvc.messageAlert = 'Managed Population has been updated successfully';
        }
        else {
          managedPopulationSvc.messageAlert = 'Managed Population has been added successfully';
        }
        localStorage.removeItem('managedPopulationId');

        scope.mngpopCtrl.managedPopulation.productionStatus = managedProductionStatus;
     
        if(scope.mngpopCtrl.managedPopulation.tasksResolvedConflicts.length < 1){
          scope.mngpopCtrl.managedPopulation.tasksResolvedConflicts = managedPopulationSvc.taskConflictsResolved;
          scope.mngpopCtrl.managedPopulation.tasksResolvedConflicts.forEach(function (item){ item.copyInclude = item.copyInclude  ? 1 : 0; });
        }
        managedPopulationSvc.saveManagedPopulation(scope.mngpopCtrl.managedPopulation);
        managedPopulationSvc.isAddedSuccesfully = true;
        location.path(app.currentRoute + '/configuration/population/');
      };

      scope.$on('wizardOnClose', function () {
        if (app !== undefined && app.currentRoute !== undefined) {
          location.url(app.currentRoute + '/configuration/population');
        }
        else {
          location.url('/admin/configuration/population');
        }
      });
      scope.initEdit = function(){
        managedPopulationSvc.getManagedPopulationsById(managedPopulationSvc.managedPopulationId).then(function(response){
          scope.managedpop  = response.data.results.ManagedPopulations;
          scope.mngpopCtrl.managedPopulation.statusCode = scope.managedpop[0].StatusDescription === 'Active' ? 'A' : 'I';
          scope.mngpopCtrl.managedPopulation.name = scope.managedpop[0].Name;
          scope.mngpopCtrl.managedPopulation.editManagedPopulationName = scope.managedpop[0].Name;
          scope.mngpopCtrl.managedPopulation.description = scope.managedpop[0].Description;
          scope.mngpopCtrl.managedPopulation.id  = managedPopulationSvc.managedPopulationId;
          scope.mngpopCtrl.managedPopulation.productionStatus = scope.managedpop[0].ProductionStatus;
          scope.$emit('setSaveAsDraftDisabled', scope.managedpop[0].ProductionStatus === 'D' ? true : false);

          managedPopulationSvc.getManagedPopulationTaskBundles(managedPopulationSvc.managedPopulationId).then(function(response){
            scope.mngpopCtrl.managedPopulation.taskBundles = response.data.results;
            managedPopulationSvc.taskBundles = response.data.results;
            getTaskBundlesTasks();
            var hasNoTaskBundles = _.isEmpty(scope.mngpopCtrl.managedPopulation.taskBundles);
            if(hasNoTaskBundles){
              scope.mngpopCtrl.managedPopulation.taskBundles = [];
            }
          });

          managedPopulationSvc.getManagedPopulationCareTeams(managedPopulationSvc.managedPopulationId)
          .then(function(response){
            scope.mngpopCtrl.managedPopulation.careTeams = response.data.results;
          });
          managedPopulationSvc.getmanagedPopulationDefinition(managedPopulationSvc.managedPopulationId)
          .then(function(response){
            scope.mngpopCtrl.managedPopulation.populationDefinition = response.data.results;
          });

          managedPopulationSvc.getRemindersByManagedPopulationId(managedPopulationSvc.managedPopulationId).then(function(response){
            scope.mngpopCtrl.managedPopulation.reminders = response.data.results.length ? response.data.results : [];
            
            _.each(scope.mngpopCtrl.managedPopulation.reminders, function(item){
              item.communicationAttemptDays = item.remainderState === 'A' ?  item.daysAfterDueDate : item.daysBeforeDueDate ? item.daysBeforeDueDate : item.numberOfDaysBeforeTaskClosedIncomplete;
            });


          });
        });
      };

      var getTaskBundlesTasks = function () {

        if(scope.mngpopCtrl.managedPopulation.populationId > 0 && scope.mngpopCtrl.managedPopulation.populationId !== undefined){

          managedPopulationSvc.taskResolvedEdit = true;

          managedPopulationSvc.getTaskBundleTasks(managedPopulationSvc.managedPopulationId).then(function(response){

            scope.summarytasks  = managedPopulationSvc.taskConflictsResolved =  _.filter(response.data.results,function(tasks){return angular.equals(tasks.statusCode,'Active');});
            scope.mngpopCtrl.managedPopulation.summaryOfAllTasks = [{
              titleName : 'Procedures' ,
              tasks : _.filter(scope.summarytasks, function(pTask){ return pTask.taskType === managedPopulationSvc.procedureTaskType;}),
            },
            {
              titleName : 'Assessments' ,
              tasks : _.filter(scope.summarytasks,function(aTask){ return aTask.taskType === managedPopulationSvc.assessmentTaskType;}),
            },
            {
              titleName : 'Education Material' ,
              tasks : _.filter(scope.summarytasks, function(eType){return eType.taskType === managedPopulationSvc.educationTaskType;}),
            },
            { titleName : 'Others' ,
              tasks : _.filter(scope.summarytasks,function(oType){ return oType.taskType === managedPopulationSvc.otherTaskType;}),
            },
           ];
          });
        }
        else
        {
          scope.summarytasks = scope.mngpopCtrl.managedPopulation.tasksResolvedConflicts;

          scope.mngpopCtrl.managedPopulation.summaryOfAllTasks = [{
              titleName : 'Procedures' ,
              tasks : _.filter(scope.summarytasks, function(pTask){ return pTask.taskType === managedPopulationSvc.procedureTaskType;}),
            },
            {
              titleName : 'Assessments' ,
              tasks : _.filter(scope.summarytasks,function(aTask){ return aTask.taskType === managedPopulationSvc.assessmentTaskType;}),
            },
            {
              titleName : 'Education Material' ,
              tasks : _.filter(scope.summarytasks, function(eType){return eType.taskType === managedPopulationSvc.educationTaskType;}),
            },
            { titleName : 'Others' ,
              tasks : _.filter(scope.summarytasks,function(oType){ return oType.taskType === managedPopulationSvc.otherTaskType;}),
            },
           ];
        }
      };
      

      if(!managedPopulationSvc.hasInitEdit){
        managedPopulationSvc.hasInitEdit = true;
        scope.summaryOfAllTasks = [ { 'id' : 1}];
        scope.initEdit();
      }

    }]);

  }(window.app));