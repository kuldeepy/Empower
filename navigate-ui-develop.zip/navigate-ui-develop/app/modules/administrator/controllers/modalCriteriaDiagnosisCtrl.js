(function (app) {
  'use strict';
  
  app.controller('Diagnosis', ['$scope','$modalInstance','$window','$http','listStateSvc','populationDefinitionSvc',function(scope,modalInstance,$window,http,listStateSvc,populationDefinitionSvc){
        var tempModalOptions = {};
        scope.timeInMs = 0;
        scope.Popup=function(){
          switch(scope.criteriaName){
          case 'ICD-10-CM-Diag':
            scope.icd={};
            scope.icd.equals='Equals';
            tempModalOptions.options = [];
            tempModalOptions.selectedOptions=[];
            tempModalOptions.selectedData = [];
            tempModalOptions.placeholder='Enter 3 chars min';
            tempModalOptions.available=[];
            tempModalOptions.selected=[];
            tempModalOptions.headerText = 'Diagnosis';
            scope.modalOptions = tempModalOptions;
            scope.modalOptions.httptest=http;
            scope.multiselect={'url':'icd-codes','http':scope.modalOptions.httptest,'checkeddata':scope.modalOptions.selectedData,'availabledata':scope.modalOptions.available,'selectedavailabledata':scope.modalOptions.selected};
            scope.icd9=true;
            break;
          case 'Diagnosis Groupers':
            scope.diagnosisSearch={};
            scope.diagnosis={};
            scope.diagnosis.durationcost='0';
            populationDefinitionSvc.populationDefinitionGetData('code-grouping-source/?searchText=Diagnosis Groupers').then(function(response){
                if(response.data.results){
                  scope.soureceDD = response.data.results;
                  populationDefinitionSvc.populationDefinitionGetData('operators').then(function(responseOperators){
                    if(responseOperators.data.results){
                      scope.amountSymbolsDD=responseOperators.data.results;
                    }
                  });
                }
              });
            tempModalOptions.available=[];
            tempModalOptions.selected=[];
            scope.modalOptions = tempModalOptions;
            scope.diagnosisGroup=true;
            break;
          }
        };
          
        scope.close = function () {
          modalInstance.dismiss('cancel');
        };
       
        scope.addDiagnosis=function(item){
          scope.insertData={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':item.equals==='Equals'?'Equals':'Not Equals','radioType':'','value1':!item.value1?'':item.value1,'value2':!item.value2?'':item.value2,'listValues':scope.multiselect.selectedavailabledata};
          populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.insertData).then(function(response){
            if(response.data.results){
              if(response.data.results === true)
               {
                modalInstance.dismiss('cancel');
                scope.getBuildedCriteria();
              }
            }
          });
        };
        scope.searchDiagnosisGroup=function(item){
          if(item && item.source){
            var grouperName='&groupersText='+item.grouperName;
            populationDefinitionSvc.populationDefinitionGetData('search-code-groupers/?sourceId='+item.source+''+(item.grouperName?grouperName:'')).then(function(response){
                if(response.data.results){
                  scope.modalOptions.selected=[];
                  scope.modalOptions.available=response.data.results;
                }
              });
          }
        };
        scope.searchDiagnosisGroupClear=function(){
          scope.diagnosisSearch={};
        };
        scope.saveDiagnosisGroupers=function(item){
          scope.InsertDiagnosisGroupers={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':'','radioType':item.durationcost==='0'?'Duration':'Cost','value1':item.durationcost==='0'?!item.value1?'':item.value1:!item.symbol?'':item.symbol,'value2':item.durationcost==='0'?!item.value2?'':item.value2:!item.amount?'':item.amount,'listValues':scope.modalOptions.selected};
          
          populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.InsertDiagnosisGroupers).then(function(response){
            if(response.data.results){
              if(response.data.results === true)
               {
                modalInstance.dismiss('cancel');
                scope.getBuildedCriteria();
              }
            }
          });
        };
        scope.clearAllData=function(){
          scope.diagnosis.value1 = '';
          scope.diagnosis.value2 = '';
          scope.diagnosis.symbol = '';
          scope.diagnosis.amount = '';
        };
        scope.Popup();
 
      }]);
})(window.app);