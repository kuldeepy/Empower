(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('assessmentSummaryCtrl', ['$scope', '$state', '$location','assessmentBuilderSvc',
      function (scope, state,location,assessmentBuilderSvc) {


        scope.getAssessmentDetails = function(){
          assessmentBuilderSvc.getAssessmentDetailsById(scope.assessmentData.editAssessmentBuider.id).then(function(response){
              scope.assessmentData.assessment = response.data.results;
              localStorage.setItem('assessmentData', JSON.stringify(scope.assessmentData.assessment));
              scope.assessmentData.assessment.questions.forEach(function (item) {
                if(_.findWhere(scope.assessmentData.answerTypeUI,{'db' : item.answerTypeText})){
                  item.answerTypeText = _.findWhere(scope.assessmentData.answerTypeUI,{'db' : item.answerTypeText}).ui;
                }
              });
            });
        };

        if(localStorage.getItem('assessmentBuilderId')){
          scope.assessmentData.editAssessmentBuider.id = localStorage.getItem('assessmentBuilderId');
          scope.assessmentData.editAssessmentBuider.isEdit = localStorage.getItem('isAssessmentBuilderEdit');
          scope.assessmentData.editAssessmentBuider.isEditStatus = localStorage.getItem('isAssessmentBuilderEdit');
          scope.assessmentData.editAssessmentBuider.uniqueId = localStorage.getItem('uniqueId');
          if (scope.assessmentData.editAssessmentBuider.isEdit === 'true') {
            scope.assessmentData.assessmentHeader = 'Edit Assessment';
            scope.getAssessmentDetails();
          }
        }


        if (scope.initializeStep) {
          scope.initializeStep(state.current.name,true);
        }


        scope.$on('wizardOnsaveDraftAndClose', function() {
          scope.saveQuestionnaire('D');
        });


        scope.$on('wizardOnsaveAndClose', function() {
          scope.saveQuestionnaire('F');
        });

        scope.saveQuestionnaire = function(productionStatus){

          scope.assessmentData.assessment.productionStatus = productionStatus;

          if(scope.assessmentData.assessment.id > 0){
            var data = localStorage.getItem('assessmentData');
            scope.assessmentFinalData = JSON.parse(data);
            if (scope.assessmentFinalData.productionStatus === 'F') {
              angular.forEach(scope.assessmentData.assessment.questions, function (questions, index) {
                angular.forEach(questions.options, function (option1, filterIndex) {
                  scope.assessmentData.assessment.questions[index].options[filterIndex].id = scope.assessmentFinalData.questions[index].options[filterIndex].id;
                });
              });
            }
            assessmentBuilderSvc.updateQuestionnaire(scope.assessmentData.assessment)
            .then(function () {
              localStorage.removeItem('assessmentData');
              assessmentBuilderSvc.saveNotificationMsg = 'Assessment has been updated successfully';
              location.url(app.currentRoute + '/library/assessment');
            });
          }else{
            assessmentBuilderSvc.saveQuestionnaire(scope.assessmentData.assessment)
            .then(function(){
              assessmentBuilderSvc.saveNotificationMsg = 'Assessment has been added successfully';
              location.url(app.currentRoute + '/library/assessment');
            });
          }
        };

        scope.$on('wizardOnClose', function() {

          if(app !== undefined && app.currentRoute !== undefined) {
            location.url(app.currentRoute + '/library/assessment');
          }
          else{
            location.url('/library/assessment');
          }
        });

      }]);
  }(window.app)
);