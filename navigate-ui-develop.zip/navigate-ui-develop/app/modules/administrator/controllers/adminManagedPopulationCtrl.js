(
  function (app) {
  /* @fmt: off */
  'use strict';
  // @fmt:on

  app.controller('adminManagePopulationCtrl', ['$scope','managedPopulationSvc','$state','$timeout','$location','$filter',
    function (scope, managedPopulationSvc, state, timeout, location, filter) {
    scope.errorMessage = 'Please try again later or contact your system administrator if this continues.';
    // GET managedPopulations from managedPopulationSvc
    managedPopulationSvc.editSummaryStatus ='';
    managedPopulationSvc.getManagedPopulations().then(
      function (response) {
        scope.populations  = response.data.results;
        scope.populationSearch = response.data.results;
        angular.forEach(scope.populations, function (value) {
          if (value.statusDescription === 'Active') {
            value.isStatus = true;
          } else {
            value.isStatus = false;
          }
        });
        scope.populations = filter('filter')(scope.populations, { isStatus: true });
      });
    
    scope.isOpen = true;
    scope.page = 1;
    scope.pageSize = 10;

    scope.search = {
      text1 : 'Managed Population Name',
      text2 : 'Description',
      status : 'Active',
      production : ''
    };
    scope.columnsSelected = [{ field: 'name', displayName: 'Managed Population Name', columnClass: 'table-column-managepopulation-name' }, { field: 'description', displayName: 'Description', columnClass: 'table-column-assessment-description' }, { field: 'productionStatus', displayName: 'Production', columnClass: 'table-column-assessment-status' }, { field: 'isStatus', displayName: 'Status', columnClass: 'table-column-managepopulation-status', sortable: false }, { field: 'updatedOn', displayName: 'Last Updated', columnClass: 'table-column-name' }, { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false }];

    scope.hideNotification = function () {
      scope.notification.visible = false;
    };

    scope.ShowSuccessNotification = function () {
      window.scrollTo(0, 0);
      scope.notification = {
        visible: managedPopulationSvc.isAddedSuccesfully,
        message: managedPopulationSvc.messageAlert
      };
      timeout(function () {
        scope.notification.visible = false;
      }, 6000);
      managedPopulationSvc.isAddedSuccesfully=false;
    };
    
    
    scope.ShowSuccessNotification();
    scope.addManagedPopulation = function () {
      managedPopulationSvc.taskBundles = [];
      managedPopulationSvc.editSummaryStatus = '';
      managedPopulationSvc.editStatus = false;
      managedPopulationSvc.managedPopulationId = 0;
      managedPopulationSvc.productionStatus = '';
      localStorage.removeItem('managedPopulationId');
      localStorage.removeItem('productionStatus');
      managedPopulationSvc.isAddedSuccesfully = false;
      location.path(app.currentRoute+'/configuration/population/add');
    };
    scope.updateManagedPopulation = function(population){
      managedPopulationSvc.editSummaryStatus = 'managedPopulationSummary';
      managedPopulationSvc.editStatus = true;
      managedPopulationSvc.isAddedSuccesfully = false;
      managedPopulationSvc.hasInitEdit = false;
      localStorage.setItem('productionStatus', population.productionStatus);
      localStorage.setItem('managedPopulationId', population.id);
      state.go(managedPopulationSvc.editSummaryStatus);
      location.path(app.currentRoute+'/configuration/population/add');
    };
    scope.filterManagePopulation = function (val) {
      managedPopulationSvc.getManagedPopulations().then(
      function (response) {
        scope.populationSearch = response.data.results;
        angular.forEach(scope.populationSearch, function (value) {
          if (value.statusDescription === 'Active') {
            value.isStatus = true;
          } else {
            value.isStatus = false;
          }
        });
      });
      scope.filterData = { name: val.name === 'undefined' ? '' : val.name, description: val.description === 'undefined' ? '' : val.description, isStatus: val.status === 'Active' ? true : false, productionStatus : val.production };
      scope.populations = filter('filter')(scope.populationSearch, { name: scope.filterData.name, description: scope.filterData.description, isStatus: scope.filterData.isStatus, productionStatus: scope.filterData.productionStatus });
    };

  }]);

}(window.app));
