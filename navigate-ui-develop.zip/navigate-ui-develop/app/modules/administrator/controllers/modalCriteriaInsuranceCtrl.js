(function (app) {
  'use strict';
  
  app.controller('Insurance', ['$scope','$modalInstance','$window','$timeout','listStateSvc','populationDefinitionSvc',function(scope,modalInstance,$window,timeout,listStateSvc,populationDefinitionSvc){
      var tempModalOptions = {};
      scope.modalOptions = tempModalOptions;
      scope.timeInMs = 0;
      scope.BindPopup=function(){
        switch(scope.criteriaName){
          case 'Insurance':
            scope.insuranceData={};
            populationDefinitionSvc.populationDefinitionGetData('insurance-groups').then(function(response){
              if(response.data.results){
                scope.insuranceDD=response.data.results;
                if(response.data.results.length>0){
                  scope.insuranceData.insurance=JSON.stringify(scope.insuranceDD[0]);
                  scope.BindDropdownData(JSON.stringify(scope.insuranceDD[0]));
                }
              }
            });
            scope.insuranceStates=true;
            break;
          case 'Employers':
            scope.employeeData={};
            scope.employeeData.isequal='0';
            scope.employeeData.selected=[];
            populationDefinitionSvc.populationDefinitionGetData('insurance-employers').then(function(response){
              if(response.data.results){
                scope.EmployeeDD=response.data.results;
              }
            });
            scope.insuranceEmployers=true;
            break;
        }
      };
      scope.open = function(id) {
        timeout(function() {
          if(id==='1'){
            scope.opened = true;
          }
          else{
            scope.openedendData = true;
          }
        });
      };
      
      scope.BindDropdownData=function(item)
      {
        item = JSON.parse(item).id;
        populationDefinitionSvc.populationDefinitionGetData( 'insurance-groups/'+item+'/plans').then(function(response){
          if(response.data.results){
            scope.insurancePlanDD=response.data.results;
          }
        });
      };

      scope.modalOptions.close = function () {
        modalInstance.dismiss('cancel');
      };
      scope.AddInsurance=function(item){
        var modifiedData = [];
        _.forEach(item.insurancePlan, function(res){
          modifiedData.push(JSON.parse(res));
        });
        item.insurance = JSON.parse(item.insurance);
        item.insurancePlan = modifiedData;
        scope.insertData={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'insuranceId':item.insurance.id,'insuranceName':item.insurance.name,'listValues':!item.insurancePlan?scope.insurancePlanDD:item.insurancePlan};
        populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/insurance-criteria',scope.insertData).then(function(response){
          if(response.data.results){
            if(response.data.results === true)
             {
              modalInstance.dismiss('cancel');
              scope.getBuildedCriteria();
            }
          }
        });
      };

      scope.AddEmployee=function(item){
          scope.insertData={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName, 'equalsOperator':item.isequal==='0'?'Equals':'Not Equals','radioType':'date','value1':!item.startdate?'':moment(item.startdate).format('L'),'value2':!item.enddate?'':moment(item.enddate).format('L'),'listValues':item.selected};
          populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.insertData).then(function(response){
            if(response.data.results){
              if(response.data.results === true)
             {
                modalInstance.dismiss('cancel');
                scope.getBuildedCriteria();
              }
            }
          });
        };
      scope.BindPopup();
    }]);
})(window.app);