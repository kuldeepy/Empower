(function (app) {
  'use strict';
  
  app.controller('episodicGroupersCtrl', ['$scope','$modalInstance','$window','listStateSvc','populationDefinitionSvc',
  function(scope,modalInstance,$window,listStateSvc,populationDefinitionSvc){
    scope.episodicGroupersDetails = [];
    scope.episodicGroupersDetailsCount = 0;
    scope.pageSize = 5;
    scope.page = 1;
    scope.episodicGrouperstable = {
      columns : ['System', 'Condition', 'Stage', 'Dx CAT','Action']
    };
    var currentListState = listStateSvc.get();
    scope.selectedItems = [];

    scope.getSystemDetails = function(){
      populationDefinitionSvc.populationDefinitionGetData('systems').then(function(response){
        if(response.data.results){
          var sysDetails = [];
          response.data.results.forEach(function(res){
            sysDetails.push({sysid:res.id,sysname:res.name});
          });
          scope.systemDetails = sysDetails;
        }
      });
    };

    scope.populateGrouperConditions = function(systemId){
      /*Chrome Issue*/
      if(systemId !== undefined)
      {
        var conversionToJSONObj = JSON.parse(systemId);
        systemId = conversionToJSONObj.sysid;
      }
      /*Chrome Issue*/
      populationDefinitionSvc.populationDefinitionGetData('systems/'+systemId+'/grouper-conditions').then(function(response){
        if(response.data.results){
          var condDetails = [];
          response.data.results.forEach(function(res){
            condDetails.push({condid:res.id,condname:res.name});
          });
          scope.conditionDetails = condDetails;
        }
      });
    };

    scope.populateGrouperStages = function(conditionId){
      /*Chrome Issue*/
      if(conditionId !== undefined)
      {
        var conversionToJSONObj = JSON.parse(conditionId);
        conditionId = conversionToJSONObj.condid;
      }
      /*Chrome Issue*/
      populationDefinitionSvc.populationDefinitionGetData('conditions/'+conditionId+'/grouper-stages').then(function(response){
        if(response.data.results){
          scope.stageDetails = response.data.results.grouperSeveritys;
          scope.selectedItems.dxCAT = response.data.results.stage;
        }
      });
    };

    scope.saveGroupers = function(selectedItems){
      /*Chrome Issue*/
      var conversionSystemToJSONObj = JSON.parse(selectedItems.systemDetails);
      selectedItems.systemDetails = conversionSystemToJSONObj;
      var conversionConditionToJSONObj = JSON.parse(selectedItems.conditionDetails);
      selectedItems.conditionDetails = conversionConditionToJSONObj;
      var conversionStageToJSONObj = JSON.parse(selectedItems.stageDetails);
      selectedItems.stageDetails = conversionStageToJSONObj;
      /*Chrome Issue*/
      scope.episodicGroupersDetails.push({id:scope.episodicGroupersDetails.length+1,
        systemId:selectedItems.systemDetails.sysid,
        systemText:selectedItems.systemDetails.sysname,
        conditionId:selectedItems.conditionDetails.condid,
        conditionText:selectedItems.conditionDetails.condname,
        stageId:selectedItems.stageDetails.grouperStageId,
        stageText:selectedItems.stageDetails.stage,
        dxCat:selectedItems.dxCAT});
      scope.selectedItems = [];
      scope.episodicGroupersDetailsCount = scope.episodicGroupersDetails.length;
    };

    scope.saveEpisodicGroupers = function(){
      if(scope.episodicGroupersDetails.length > 0){
        var EpisodicGroupersdata={criteriaTypeID:scope.criteriaId,criteriaTypeName:scope.criteriaName,listValues:scope.episodicGroupersDetails};
        var populationDefinitionId = currentListState.CurrentUIState.populationDefinition.id;
        populationDefinitionSvc.populationDefinitionPostData('population-definition/'+ populationDefinitionId+'/med-stat-criteria',EpisodicGroupersdata).then(function(response){
          if(response.data.results){
            if(response.data.results === true)
             {
              modalInstance.dismiss('cancel');
              scope.getBuildedCriteria();
            }
          }
        });
      }
    };

    scope.closePopup = function(){modalInstance.dismiss('cancel');};

    scope.deleteEpisodicGroupers = function(index){
      scope.episodicGroupersDetails.splice(index,1);
    };
    scope.getSystemDetails();



  }]);
})(window.app);