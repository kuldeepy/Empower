(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('UserMgmtCtrl', ['$scope', '$http', 'userMgmtSvc', 'createUserSvc', 'authSvc', '$location', '_','$timeout','$state','$filter',
      function (scope, http, userMgmtSvc, createUserSvc, authSvc, location, _, timeout,state, filter) {
      scope.users = [];
      scope.search = {userName : '', lastName : '', firstName : '', rolesname : '',emailAddress : '',status : ''};
      scope.roles = [];
      scope.isError = false;
      scope.usersTemp = [];
          // GET users from userMgmtSvc
      scope.init = function () {
        userMgmtSvc.users().then(function (data) {
          data.forEach(function (user) {
            user.roles = _.uniq(user.roles, 'name');
          });
          scope.userData = data;
          scope.users = angular.forEach(scope.userData, function (filterObj, filterIndex) {
            scope.gridRoles = '';
            angular.forEach(filterObj.roles, function (roles) {
              if (scope.gridRoles === '') {
                scope.gridRoles = roles.name;
              } else {
                scope.gridRoles = scope.gridRoles + ',  ' + roles.name;
              }
              scope.userData[filterIndex].gridRoles = scope.gridRoles;
            });
          });
          scope.usersTemp = scope.users;
          scope.userManagementSearch();
        });
      };
          
      scope.viaMyProfile = false;
      scope.daysLeftChangePassword =  authSvc.getLastChangedPasswordDays();
      scope.daysLeftChangePassword = scope.daysLeftChangePassword.toString();
      scope.notifyChangePassword = authSvc.getChangePasswordReminderDays(scope.daysLeftChangePassword);

      // for pager
      scope.page = 1;
      scope.pageSize = 10;
      scope.status = {
        open: true
      };
      scope.title = 'User Management';
      scope.accordionOpen = true;
      scope.columnsSelected = [{ field: 'userName', displayName: 'Username', columnClass: 'table-column-name' }, { field: 'firstName', displayName: 'Name', columnClass: 'table-column-name' }, { field: 'gridRoles', displayName: 'Role', columnClass: 'table-column-name', sortable: false }, { field: 'emailAddress', displayName: 'Email', columnClass: 'table-column-name' }, { field: 'status', displayName: 'Status', columnClass: 'table-column-action', sortable: false }, { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false }];
      
      createUserSvc.roles().then(function(data) {
          scope.roles = data;
        });

      scope.userManagementSearch = function() {
        scope.users = filter('filter')( scope.usersTemp,{ userName: scope.search.userName !== '' ? scope.search.userName : '', lastName: scope.search.lastName !== '' ? scope.search.lastName : '', firstName: scope.search.firstName !== '' ? scope.search.firstName : '', roles: (scope.search.rolesname !== '' && scope.search.rolesname !== null) ? scope.search.rolesname : '', emailAddress: scope.search.emailAddress !== '' ? scope.search.emailAddress : '', statusCode: (scope.search.status === '' ? '' :  scope.search.status === 'Active' ?  'A' :  (scope.search.status === 'Locked' ? 'L' : 'I') ) });
      };

      scope.clearFields = function() {
        scope.userSearch.$setPristine();
        scope.search = {userName : '', lastName : '', firstName : '', rolesname : '',emailAddress : '',status : ''};
        scope.page = 1;
        scope.init();
      };

      scope.export = function() {
        var headers = ['User Name', 'Name', 'Role', 'Email','Status'];
        var csvResult = headers.toString() + '\n';
        _.each(scope.users, function (user) {
          var dataRows = [];
          var name = '"' + [user.firstName, user.lastName].join(' ') + '"';
          name = name.indexOf(',') === -1?name:'"'+name+'"';
          var roles = '"' +  _.pluck(user.roles, 'name').join(', ') + '"';
          dataRows.push([user.userName,name,roles,user.emailAddress,user.status]);
          csvResult = csvResult + dataRows.toString() + '\n';
        });
        var blob = new Blob([csvResult], {type:'data:text/csv'});
        window.saveAs(blob, 'Users_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv');
      };

      scope.ShowSuccessNotification = function () {
        scope.isAlert = createUserSvc.isAddedSuccesfully;
        scope.alertMessage = createUserSvc.messageAlert;
        window.scrollTo(0, 0);
        timeout(function () {
          scope.isAlert = false;
        }, 6000);
        createUserSvc.isAddedSuccesfully = false;
        createUserSvc.messageAlert = '';
      };

      scope.$watchCollection('search.roles',function(oldValue,newValue){
        if(newValue === null){
          scope.search.roles = undefined;
        }
      });
    
      scope.ShowSuccessNotification();

      // ******************************************* CREATE WIZARD FLOW ********************************************

      scope.wizardheader = 'Add User';

      scope.wizardWorkflow = [
        { 'id': 1, 'name': 'userDetails' },
        { 'id': 2, 'name': 'userCredentials' },
        { 'id': 3, 'name': 'securityRoles' },
        { 'id': 4, 'name': 'userSummary' }
      ];

      //Tab and Step Definitions
      scope.tabDefinitions = [
        { name: 'userDetails', number: '1', title: 'User Details', selectionCss: 'first active', completed: false,clickable:false,isTabCompleted:false },
        { name: 'userCredentials', number: '2', title: 'User Credentials', selectionCss: 'inactive', completed: false,clickable:false,isTabCompleted:false },
        { name: 'userSummary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false,clickable:false,isTabCompleted:false }
      ];
      
      scope.stepDefinitions = [
        //Select Ideal Target task type Tab
        [
          { name: 'userDetails',number: '1', letter: 'a', title: 'User Details', selectionCss: 'active', completed: false,clickable:false,isTabCompleted:false }
        ],
        [
          { name: 'userCredentials',number: '2', letter: 'a', title: 'Credentials', selectionCss: 'active', completed: false,clickable:false,isTabCompleted:false },
          { name: 'securityRoles',number: '2', letter: 'b', title: 'Security Role(s)', selectionCss: 'active', completed: false,clickable:false,isTabCompleted:false }
        ],
        //Define summary Tab
        [
          { name: 'userSummary',number: '3', letter: 'a', title: 'Summary', selectionCss: 'active', completed: false,clickable:false,isTabCompleted:false }
        ]
      ];

       // ******************************************* END WIZARD FLOW ********************************************

      this.currentUser = authSvc.user();

      this.clinicAdmins = [];
      this.physicians = [];
      this.insuranceGroups = [];
      this.insuranceGroupsdetails = [];

      this.userPost = {
        currentUserId: this.currentUser.id,
        password: '',
        user: {
          firstName: '',
          lastName: '',
          gender: '',
          phoneNumber: '',
          emailAddress: '',
          userName: '',
          primaryAddress: {
            addressType: 1,
            addressLine1: '',
            city: '',
            postalCode: ''
          },
          roles: [],
          status: ''
        }
      };

      this.providerId = null;
      this.groupId = null;
      this.clinicIdForPhysician = null;
      this.physicianId = null;

      this.clinicDisabled = true;
      this.clinicPhysicianDisabled = true;
      this.insuranceDisabled = true;
      this.physicianDisabled = true;
      this.editStatus = true;

      scope.getUserId = function(id) {
        userMgmtSvc.editUserId = {id: id};
        sessionStorage.setItem('editUser', JSON.stringify(id));
        state.go('editUserSummary');
        location.path('/admin/users/user/edit');
      };

      // Edit User Object
      this.user = {};

    }]);

  }(window.app)
);