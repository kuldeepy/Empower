(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('buildDefinitionCtrl', ['$scope', 'listStateSvc','populationDefinitionSvc',
    function (scope,listStateSvc,populationDefinitionSvc) {
      if(scope.initializeStep){
        scope.initializeStep('pdbuildDefinition', true);
      }
      scope.isOpen = true;
      scope.isShowBuildCancel=true;
      scope.getBuildCriteria = function(){
        var populationDefinitionDetails = listStateSvc.get();
        var populationDefinitionId = populationDefinitionDetails.CurrentUIState.populationDefinition.id;
        if(populationDefinitionDetails.CurrentUIState.populationDefinition.isDraft===false){
          scope.isShowBuildCancel=false;
        }
        populationDefinitionSvc.populationDefinitionGetData('population-definition/'+populationDefinitionId+'/summary').then(function(response){
            if(response.data.results){
              var childnodes = [];
              response.data.results.criterias.forEach(function(res){
                childnodes.push({id:res.criteriaId,title:res.criteriaText,criteriaName:res.criteriaName,showdelete:true,operator:'AND',showoperator:true,criteriaSQL:res.criteriaSQL,nodes: []});
              });
              if(childnodes.length>0){
                childnodes[childnodes.length-1].showoperator = false;
              }
              scope.buildcriteriadetails = [{
                'nodes': childnodes
              }];
            }
           else{
              
            }
          });
      };
      scope.nodeLoop = function(node,id,buildCriteria){
        node.forEach(function(res){
          buildCriteria.push({criteriaId:res.id,
                              criteriaSql:res.criteriaSQL,
                              criteriaText:res.title,
                              logicalOperator:res.operator,
                              parentId:id});
          if(res.nodes.length>0)
          {
            var node1=res.nodes;
            scope.nodeLoop(node1,res.id,buildCriteria);
          }
        });
      };

      scope.getBuildCriteria();

      scope.deleteCriteria = function(scope,node) {
        scope.remove();
        var currentListState = listStateSvc.get();
        if(currentListState.CurrentUIState.criteriaIds === undefined){
          currentListState.CurrentUIState.criteriaIds = [node.id];
        }
        else{
          currentListState.CurrentUIState.criteriaIds.push(node.id);
        }
        listStateSvc.set(currentListState);
      };

      scope.$on('wizardonCancel', function() {
        var currentListState = listStateSvc.get();
        currentListState.CurrentUIState.flag = true;
        listStateSvc.set(currentListState);
      });

      scope.visible = function(item) {
        if (scope.query && scope.query.length > 0 && item.title.indexOf(scope.query) === -1) {
          return false;
        }
        return true;
      };

    }]);
  }(window.app));