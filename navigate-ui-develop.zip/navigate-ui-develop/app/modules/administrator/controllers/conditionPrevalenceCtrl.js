(function (app) {
  'use strict';
  app.controller('conditionPrevalenceCtrl', ['$scope', '$location', 'modalService', 'conditionPrevalenceSvc', '_', 'authSvc', 'homeURL',
    function (scope, location, modalService, conditionPrevalenceSvc, _, authSvc, homeURL) {
      scope.trendType = '';
      scope.isBackShow = true;
      scope.chartTypeName = 'Line Chart';
      scope.isOpen = true;
      scope.conditionsCheckedStatus = false;
      scope.selectedConditionName = '';
      scope.conditionstable = {
        columns : ['Condition', '% of Patients',,]
      };
      scope.filter = {clinicId : null, pcpId : null, healthPlanId : null, productId : null};
      scope.filterTrendGraph = {dateKey : null,clinicId : null, pcpId : null, healthPlanId : null, productId : null};
      scope.metric = '0';
      scope.toolTips = {good : [],fair : [],poor : [],notTested : []};
      scope.conditionPrevalenceData = [];
      scope.dateKey = '';
      scope.dateKeyName = '';
      scope.user = authSvc.user();
      scope.user.backURL = '';
      scope.filter.clinicId = '';
      scope.filter.pcpId = '';
      scope.filter.healthPlanId = '';
      scope.filter.productId = '';

      scope.daysLeftChangePassword =  authSvc.getLastChangedPasswordDays();
      scope.daysLeftChangePassword = scope.daysLeftChangePassword.toString();

        /* initialize method which is called when this controller is loaded */
      scope.init = function () {
          scope.user.backURL = homeURL.getURL(scope.user.role);
          scope.isBackShow = (scope.user.role === 'Clinic Administrator' || scope.user.role === 'Physician' || scope.user.role === 'Insurance Group Provider') ? false : true;
        };

      scope.GetLatestDateKey= function () {
          conditionPrevalenceSvc.getLatestDateKeyRequest().then(function(response){
              scope.dateKey = response.data.results[0].dateKey;
              scope.dateKeyName = response.data.results[0].dateKeyname;
              scope.filterTrendGraph.dateKey = scope.dateKey;
              scope.BindFilters();
            });
        };

      scope.BindFilters = function () {
          conditionPrevalenceSvc.getClinicsRequest(scope.dateKey).then(function(response){
              scope.clinics = response.data.results;
              if(scope.user.role === 'Physician'){
                scope.filter.clinicId = scope.clinics[0].id;
                scope.filterTrendGraph.clinicId = scope.clinics[0].id;
              }
              if(scope.user.role === 'Clinic Administrator'){
                if(scope.clinics === null){
                  scope.clinics = [{'id': scope.user.providerId,'name': scope.user.providerName}];
                }
                scope.filterTrendGraph.clinicId = scope.user.providerId;
              }
              conditionPrevalenceSvc.getInsurancePlansRequest().then(function(response){
                scope.healthPlans = response.data.results;
                if(scope.user.role === 'Insurance Group Provider'){
                  scope.filter.healthPlanId = scope.healthPlans[0].id;
                  scope.filterTrendGraph.healthPlanId = scope.healthPlans[0].id;
                }
                conditionPrevalenceSvc.getProductsRequest().then(function(response){
                  scope.products = response.data.results;
                  scope.getGraphData();
                });
              });
            });
        };
      if(scope.user.role === 'Physician')
      {
        scope.pcp = [{'id': scope.user.providerId,'name': scope.user.providerName}];
        scope.filter.pcpId = scope.pcp[0].id;
        scope.filterTrendGraph.pcpId = scope.pcp[0].id;
      }
      scope.getGraphData = function(){
        scope.clinicsAll = false;
        if(scope.user.role === 'Clinic Administrator'){
          if(scope.filter.clinicId === '')
          {
            scope.clinicsAll = true;
            scope.filter.clinicId = scope.user.providerId;
          }
        }

        var conditionPrevalenceParameters = {  'dateKey': scope.dateKey, 'clinicId': scope.filter.clinicId,  'pcpId': scope.filter.pcpId,  'healthPlanId': scope.filter.healthPlanId,  'productId': scope.filter.productId};
        conditionPrevalenceSvc.getGraphDataRequest(JSON.stringify(conditionPrevalenceParameters)).then(function(response){
          
            scope.conditionPrevalenceData = response.data.results;
            scope.graph = scope.conditionPrevalenceData.processMetric;
            scope.filter.clinicId = (scope.user.role === 'Clinic Administrator' ? scope.clinicsAll === true ? '' : scope.user.providerId : scope.filter.clinicId);
          });
      };
      
      scope.GetLatestDateKey();
      
      
      scope.trimDecimal=function(value){
        scope.strValue = parseFloat(value).toFixed(4).substring(0, parseFloat(value).toFixed(4).length-3);
        return scope.strValue;
      };

      scope.toolTip=function(item,scopeName,name){
        scopeName.push('<div class="reprt-tooltip-wdt"><p>'+ (name==='notTested'?'':('Segment Range :'+(name==='good'?item.derivedGoodValue:name==='fair'?item.derivedFairValue:name==='poor'?item.derivedPoorValue:''))) +'</p><p>'+'% of Patients :'+(name==='good'?item.goodPercentage:name==='fair'?item.fairPercentage:name==='poor'?item.poorPercentage:item.notTestedPercentage)+'%'+'</p><p>'+'# of Patients :'+(name==='good'?item.goodCount:name==='fair'?item.fairCount:name==='poor'?item.poorCount:item.notTestedCount)+ '</p><p>'+(scope.metric==='2'?'':'Segment Name :'+(name==='good'?item.goodRange:name==='fair'?item.fairRange:name==='poor'?item.poorRange:'Not Tested'))+'</p></div>');
        var data=scope.trimDecimal((name==='good'?item.goodPercentage:name==='fair'?item.fairPercentage:name==='poor'?item.poorPercentage:item.notTestedPercentage))+'%';
        return data;
      };

      scope.toolTipvalue = function (item,status) {return {'width':scope.toolTip(item,(status==='good'?scope.toolTips.good:status==='fair'?scope.toolTips.fair:status==='poor'?scope.toolTips.poor:scope.toolTips.notTested),status)};};


      scope.bindAllMetrics = function(item,data){
        if(!data)
        {
          scope.conditionPrevalenceData.conditions.forEach(function(value){
            if(item.populationConditionId !== value.populationConditionId){
              value.isChecked = true;
            }
          });
          scope.conditionsCheckedStatus = true;

          var metricType = (scope.metric === '0' ? 'Process' : scope.metric === '1' ? 'Outcome' : 'Utilization');
          conditionPrevalenceSvc.getAllMetricsRequest(item.populationConditionId,metricType,scope.filterTrendGraph).then(function(response){
            
              scope.graph = _.sortBy(response.data.results,'conditionMetricName');
              scope.toolTips = {good : [], fair : [], poor : [], notTested : []};
            });
        }
        else
        {
          scope.conditionsCheckedStatus = false;
          scope.conditionPrevalenceData.conditions.forEach(function(value){
            if(item.populationConditionId !== value.populationConditionId){
              value.isChecked = false;
            }
          });
          scope.bindMetricData(scope.metric);
        }
        
      };

      scope.bindMetricData=function(id){
        scope.toolTips = {good:[],fair:[],poor:[],notTested:[]};
        scope.graph=(id==='0'?scope.conditionPrevalenceData.processMetric:id==='1'?scope.conditionPrevalenceData.outcomeMetric:scope.conditionPrevalenceData.utilizationMetric);
      };

      scope.clickCancel=function(){scope.trendChartPopup=false;};

      scope.bindPhysicians=function(filter){
        if(scope.user.role !== 'Physician'){
          if(filter === null || filter === '')
           {
            scope.pcp = [];
          }
        else
        {
            conditionPrevalenceSvc.getPhysiciansRequest(filter,scope.dateKey).then(function(response){
              scope.pcp = response.data.results.clinicPhysicians;
            },
           function(){
            });
          }
          scope.filter.pcpId = '';
        }
      };

      scope.bindConditionPrevalence=function(filter){
        scope.clinicsAll = false;
        if(scope.user.role === 'Clinic Administrator'){
          if(filter.clinicId === null || filter.clinicId === '')
          {
            scope.clinicsAll = true;
            filter.clinicId = scope.user.providerId;
          }
        }
        scope.filterTrendGraph = {'dateKey': scope.dateKey,'clinicId':filter.clinicId,'pcpId':filter.pcpId,'healthPlanId':filter.healthPlanId,'productId':filter.productId};
        scope.metric = '0';
        scope.conditionsCheckedStatus = false;
        filter.dateKey = scope.dateKey;
        conditionPrevalenceSvc.getGraphDataRequest(JSON.stringify(filter)).then(function(response){
          
            scope.toolTips = {good:[],fair:[],poor:[],notTested:[]};
            scope.conditionPrevalenceData.totalPopulationCnt = response.data.results.totalPopulationCnt;
            scope.conditionPrevalenceData.conditions = response.data.results.conditions;
            scope.conditionPrevalenceData.processMetric = response.data.results.processMetric;
            scope.conditionPrevalenceData.outcomeMetric = response.data.results.outcomeMetric;
            scope.conditionPrevalenceData.utilizationMetric = response.data.results.utilizationMetric;
            scope.graph=(scope.metric === '0'?scope.conditionPrevalenceData.processMetric:scope.metric === '1'?scope.conditionPrevalenceData.outcomeMetric:scope.conditionPrevalenceData.utilizationMetric);
            scope.filter.clinicId = (scope.user.role === 'Clinic Administrator' ? scope.clinicsAll === true ? '' : scope.user.providerId : filter.clinicId);
          });
      };

      scope.conditionsTrendTootlTip=function(data,value){
        var count;
        data.forEach(function(item){
          if(item.datePeriod===value){
            count=item.populationConditionCnt;
          }
        });
        return count;
      };

      scope.conditionsTrendGraph=function(item){
        scope.trendLegend=false;
        scope.trendType='ConditionsTrend';
        scope.chartTypeName='Line Chart';
        scope.trendChartPopup=true;
        scope.conditionPopup=true;
        scope.selectedConditionName=item.populationConditionName;
        if(scope.user.role==='Physician' )
        {
          scope.filterTrendGraph.clinicId = (scope.filterTrendGraph.clinicId === null) ? scope.clinics[0].id : scope.filterTrendGraph.clinicId;
          scope.filterTrendGraph.pcpId = (scope.filterTrendGraph.pcpId === null) ?  scope.user.providerId : scope.filterTrendGraph.pcpId;
        }
        if(scope.user.role === 'Clinic Administrator' && scope.filterTrendGraph.clinicId === null){
          scope.filterTrendGraph.clinicId=scope.user.providerId;
        }
        var conditionsTrendParameters = {  'dateKey': scope.dateKey,  'populationConditionId': item.populationConditionId,  'clinicId': scope.filterTrendGraph.clinicId,  'pcpId': scope.filterTrendGraph.pcpId,  'healthPlanId': scope.filterTrendGraph.healthPlanId,  'productId': scope.filterTrendGraph.productId};
        conditionPrevalenceSvc.getConditonsTrendRequest(JSON.stringify(conditionsTrendParameters)).then(function(response){
            response.data.results.forEach(function(item){
              scope.dataFormate(item.datePeriod);
              item.datekey = scope.date;
            });
            scope.conditionsTrendData = response.data.results;
            scope.bindConditionsTrendGraph();
          });
      };

      scope.bindConditionsTrendGraph=function(){
        if(scope.chartTypeName==='Line Chart')
        {
          scope.chartTypeName='Bar Chart';
          scope.chartSeriesType=dimple.plot.line;
        }
        else
        {
          scope.chartTypeName='Line Chart';
          scope.chartSeriesType=dimple.plot.bar;
        }
        var svg = dimple.newSvg('#divTrendGraph', 500, 300);
        var conditionsTrendChart = new dimple.chart(svg, scope.conditionsTrendData);
        conditionsTrendChart.setBounds('10%', '10%', '90%', '70%');
        var x = conditionsTrendChart.addCategoryAxis('x', 'datePeriod');
        x.addOrderRule('dateKey');
        var y = conditionsTrendChart.addMeasureAxis('y', 'prevalencePercent');
        y.overrideMin = 0;
        y.overrideMax = 100;
        var seriesMetricTrend = conditionsTrendChart.addSeries('y', scope.chartSeriesType);
        seriesMetricTrend.lineMarkers = true;
        seriesMetricTrend.barGap = 0.9;
        conditionsTrendChart.draw();
        seriesMetricTrend.getTooltipText = function (e) {
          var numberOfpatients=scope.conditionsTrendTootlTip(scope.conditionsTrendData,e.xField.toString());
          var tooltip;
          tooltip = ['Condition Name : ' + scope.selectedConditionName, 'Measurement Date :' + e.xField.toString(), '%of patients : ' +  e.yValue.toString(), '# of patients : ' +  numberOfpatients];
          return tooltip;
        };
        conditionsTrendChart.axes[0].titleShape.remove();
        y.titleShape.text('% of patients');
        if(scope.chartTypeName==='Line Chart')
        {
          seriesMetricTrend.shapes.each(function (d) {
            var shape = d3.select(this);
            svg.append('text')
            .attr('x', parseFloat(shape.attr('x')) + parseFloat(shape.attr('width')) / 2)
            .attr('y', y._scale(d.height))
            .attr('dy', '-1em')
            .style('text-anchor', 'middle')
            .style('font-size', '12px')
            .style('font-family', 'sans-serif')
            .style('opacity', 0.9)
            .text(d3.format(',.2f')(d.yValue)+'%');
          });
        }
      };

      scope.metricTrendGraph=function(item){
        scope.trendLegend=true;
        scope.trendType='MetricTrend';
        scope.chartTypeName='Line Chart';
        scope.trendChartPopup=true;
        scope.metricPatientsPopup=true;
        scope.metricType = '';
        scope.metricId = item.conditionMetricId;
        scope.selectedConditionName=item.conditionMetricName;
        switch(scope.metric)
        {
          case '0':
            scope.metricType = 'P';
            break;
          case '1':
            scope.metricType = 'M';
            break;
          case '2':
            scope.metricType = 'U';
            break;
        }
        var metricTrendParameters = {  'dateKey': scope.dateKey,  'populationConditionId': item.populationConditionId,  'clinicId': scope.filterTrendGraph.clinicId,  'pcpId': scope.filterTrendGraph.pcpId,  'healthPlanId': scope.filterTrendGraph.healthPlanId,  'productId': scope.filterTrendGraph.productId,'isOutcomeProcess': scope.metricType,  'metricId': scope.metricId};
        conditionPrevalenceSvc.getMetricsTrendRequest(JSON.stringify(metricTrendParameters)).then(function(response){
          
            scope.metricdata=[];
            response.data.results.forEach(function(item){
              scope.dataFormate(item.datePeriod);
              item.datekey = scope.date;
              scope.metricdata.push(item);
            });
            scope.metricTrendData = scope.metricdata;
            scope.bindConditionsMetricTrendGraph();
          });
      };

      scope.months = [{id:'01',name:'jan'},{id:'02',name:'feb'},{id:'03',name:'mar'},{id:'04',name:'apr'},{id:'05',name:'may'},{id:'06',name:'jun'},{id:'07',name:'jul'},{id:'08',name:'aug'},{id:'09',name:'sep'},{id:'10',name:'oct'},{id:'11',name:'nov'},{id:'12',name:'dec'}];
      scope.metricdata = [];
      scope.date = '';
      scope.dataFormate = function(datename){
        var name = datename.split(' ');
        scope.months.forEach(function(item){
          if(angular.equals(item.name,name[0].slice(0,3).toLowerCase())){
            scope.date = name[1] + item.id;
          }
        });
      };


      scope.metricTrendTootltip=function(data,value,range){
        scope.metricTrendTooltipData={};
        data.forEach(function(item){
          if((angular.equals(item.datePeriod,value)) && (angular.equals(item.derivedMeasureRange,range))){
            scope.metricTrendTooltipData.patientCount=item.patientCount;
            scope.metricTrendTooltipData.measureRange=item.range;
          }
        });
        return scope.metricTrendTooltipData;
      };

      scope.bindConditionsMetricTrendGraph=function(){
        if(scope.chartTypeName==='Line Chart')
        {
          scope.chartTypeName='Bar Chart';
          scope.chartSeriesType=dimple.plot.line;
        }
        else
        {
          scope.chartTypeName='Line Chart';
          scope.chartSeriesType=dimple.plot.bar;
        }
        var svg = dimple.newSvg('#divTrendGraph', 500, 300);
        var metricsTrendChart = new dimple.chart(svg, scope.metricTrendData);
        metricsTrendChart.setBounds('10%', '10%', '90%', '70%');
        metricsTrendChart.assignColor('Good', '#6aa84f', '#6aa84f', 5);
        metricsTrendChart.assignColor('Fair', '#ff9900', '#ff9900', 5);
        metricsTrendChart.assignColor('Poor', '#e06666', '#e06666', 5);
        metricsTrendChart.assignColor('NotTested', '#8e7cc3', '#8e7cc3', 5);
        var x = metricsTrendChart.addCategoryAxis('x', ['datePeriod', 'derivedMeasureRange']);
        x.addGroupOrderRule(['Good', 'Fair', 'Poor', 'NotTested']);
        x.addOrderRule('datekey');
        var y = metricsTrendChart.addMeasureAxis('y', 'percentage');
        y.overrideMin = 0;
        y.overrideMax = 100;
        var seriesMetricTrend = metricsTrendChart.addSeries('derivedMeasureRange', scope.chartSeriesType, [x, y]);
        seriesMetricTrend.lineMarkers = true;
        seriesMetricTrend.getTooltipText = function (e) {
          scope.metricTooltipData=scope.metricTrendTootltip(scope.metricTrendData,e.xField[0].toString(),e.aggField.toString());
          var tooltip;
          tooltip = [(e.aggField.toString()==='NotTested'?'': ('Segment Range : ' +  scope.metricTooltipData.measureRange)),'Measurement Date :' + e.xField[0].toString(), '%of patients :' + e.yValue.toString(), '# of patients : ' +  scope.metricTooltipData.patientCount];
          return tooltip;
        };
        seriesMetricTrend.barGap = 0.9;
        metricsTrendChart.draw();
        metricsTrendChart.axes[0].titleShape.remove();
        y.titleShape.text('% of patients');
        seriesMetricTrend.shapes.each(function (d)
        {
          var shape = d3.select(this);
          if (d.yValue > 0)
          {
            svg.append('text')
            .attr('x', parseFloat(shape.attr('x')) + parseFloat(shape.attr('width')) / 2)
            .attr('y', y._scale(d.height))
            .attr('dy', '-1em')
            .style('text-anchor', 'middle')
            .style('font-size', '11px')
            .style('font-family', 'sans-serif')
            .style('opacity', 0.9)
            .text(d3.format(',.2f')(d.yValue) + '%');
          }
        });
      };

      scope.TrendType=function(){
        if(scope.trendType==='ConditionsTrend')
        {
          scope.bindConditionsTrendGraph();
        }
        else
        {
          scope.bindConditionsMetricTrendGraph();
        }
      };

      scope.patientDrilldown = function(item,type){
        scope.item = item;
        switch(type)
        {
          case 'Good':
            scope.pateintCount = item.goodCount;
            break;
          case 'Fair':
            scope.pateintCount = item.fairCount;
            break;
          case 'Poor':
            scope.pateintCount = item.poorCount;
            break;
          case 'NoData':
            scope.pateintCount = item.notTestedCount;
            break;
          case 'Patients':
            scope.pateintCount = item.populationConditionCnt;
            break;
        }
        scope.item.outcomeMeasureKey = item.conditionMetricId;
        scope.range = type;
        scope.selectedMetric=type === 'Patients' ? '3' : scope.metric;
        scope.dateKeyId = scope.dateKey;
        scope.clinciId = scope.filterTrendGraph.clinicId;
        scope.pcpId = scope.filterTrendGraph.pcpId;
        scope.productId = scope.filterTrendGraph.productId;
        scope.healthPlanId = scope.filterTrendGraph.healthPlanId;

        var modalOptions = {};
        var modalDefaults = {
          'templateUrl': app.root + 'modules/administrator/templates/PatientList.html',
          'size':'lg',
          'controller':'PatientlistCtrl',
          'scope':scope
        };
        var tempModalOptions = {};
        angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
        modalOptions.copyProviders = scope.masterProviders;
        modalService.showModal(modalDefaults, modalOptions);
      };
      if(location.$$path!=='/admin/reports/condition')
      {
        scope.classMethod('condition');
      }
    }]);
   
})(window.app);
