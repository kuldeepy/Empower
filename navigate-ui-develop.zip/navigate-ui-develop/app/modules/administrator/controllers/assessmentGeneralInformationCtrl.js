﻿(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('assessmentCtrl', ['$scope', '$state', '$location', 'assessmentBuilderSvc',
      function (scope, state,location,assessmentBuilderSvc) {
                 
          scope.questionAnswers = [];
          scope.tempOptionScore = [];
          scope.assessmentHeader = 'Add Assessment';
          scope.isAssessmentUniqueIdExists = false;
          scope.isAssessmentExists = false;

          scope.activeQuestion = {
            id: '',
            status: 'A',
            text: '',
            answerType: 0,
            options: [
              {
                id: '',
                value: '',
                score: '',
                sortOrder: '',
                status: 'A'
              }
            ],
            sortOrder: '',
            isMandatory: false
          };

          scope.activeQuestion = {
            question : '',
            isMandatory : false,
            answerType : '',
          };

          scope.questionOrder = 'Question 1';

          if(localStorage.getItem('assessmentBuilderId')){
            scope.assessmentData.editAssessmentBuider.id = localStorage.getItem('assessmentBuilderId');
            scope.assessmentData.editAssessmentBuider.isEdit = localStorage.getItem('isAssessmentBuilderEdit');
            scope.assessmentData.editAssessmentBuider.isEditStatus = localStorage.getItem('isAssessmentBuilderEdit');
            scope.assessmentData.editAssessmentBuider.uniqueId = localStorage.getItem('uniqueId');
            localStorage.removeItem('assessmentBuilderId');
            localStorage.removeItem('isAssessmentBuilderEdit');
          }
          
          if (scope.assessmentData.editAssessmentBuider.isEdit === 'true') {
            scope.assessmentHeader = 'Edit Assessment';
          }

          if (scope.initializeStep) {
            if(state.current.name === 'adminassessmentGeneralInformation' && scope.assessmentData.editAssessmentBuider.isEditStatus === 'true' ){
              state.go('adminassessmentSummary');
              scope.assessmentData.editAssessmentBuider.isEditStatus = false;
            }else{
              scope.initializeStep(state.current.name,false);
            }

            if(scope.assessmentData.assessment.questions.length > 0)
            {
              scope.assessmentData.assessment.questions.forEach(function(item){
                item.isEdit = false;
              });
              scope.tabDefinitions[1].isTabCompleted = true;
            }
          }

          scope.$watch('assessmentGeneralInformation.$pristine', function () {
            if (scope.assessmentGeneralInformation && !scope.assessmentGeneralInformation.$pristine) {
              localStorage.setItem('isWizardFormDirty', true);
            }
          });
    
          scope.$on('wizardOnClose', function() {
              if(app !== undefined && app.currentRoute !== undefined) {
                location.url(app.currentRoute + '/library/assessment');
              }
              else{
                location.url('/library/assessment');
              }
            });


          scope.$watch('assessmentGeneralInformation.$valid', function () {
            if (state.current.name === 'adminassessmentGeneralInformation') {
              scope.validateFields();
            }
          });

          scope.validateFields = function(){
            scope.isAssessmentUniqueId = false;
            scope.completeStep(false, 'adminassessmentGeneralInformation');
           
            if( (scope.isAssessmentExists  || scope.isAssessmentUniqueIdExists ) === false  && (scope.assessmentData.assessment.name && scope.assessmentData.assessment.description)) {
              scope.completeStep(true, 'adminassessmentGeneralInformation');
            }

            if(parseInt(scope.assessmentData.assessment.uniqueId) === 0){
              scope.completeStep(false, 'adminassessmentGeneralInformation');
              scope.isAssessmentUniqueId = true;
            }
          };

          
          scope.checkAssessmentUniqueIdExist = function () {

            scope.isAssessmentUniqueIdExists = false;
            scope.completeStep(false, 'adminassessmentGeneralInformation');

            if(scope.assessmentData.assessment.uniqueId){
              scope.uniqueId = parseInt(scope.assessmentData.assessment.uniqueId, 10);

              assessmentBuilderSvc.getAssessments('', '', '', '', scope.assessmentData.assessment.uniqueId).then(function (response) {
                scope.isEditUniqueId = parseInt(scope.assessmentData.editAssessmentBuider.uniqueId, 10);

                scope.assessmentUniqueIdData =  response.data.results;
                scope.assessmentUniqueIdData.forEach(function (item)
                {
                  if (scope.uniqueId === item.uniqueId && scope.isEditUniqueId !== item.uniqueId)
                  {
                    scope.isAssessmentUniqueIdExists = true;
                  }
                });
                if(!scope.assessmentData.assessment.uniqueId)
                {
                  scope.isAssessmentUniqueIdExists = false;
                }
                scope.validateFields();
              });
            }
            else
            {
              if(scope.isAssessmentExists  === false  && (scope.assessmentData.assessment.name && scope.assessmentData.assessment.description))
              {
                scope.isAssessmentUniqueId = false;
                scope.completeStep(true, 'adminassessmentGeneralInformation');
              }
            }
          };

          scope.checkAssessmentNameExist = function () {
            scope.isAssessmentExists = false;
            scope.completeStep(false, 'adminassessmentGeneralInformation');

            if (scope.assessmentData.assessment.name)
            {
              assessmentBuilderSvc.getAssessments(scope.assessmentData.assessment.name,'','','','').then(function(response){
                response.data.results.forEach(function(item){
                  if(scope.assessmentData.assessment.name){
                    if (scope.assessmentData.assessment.name.toLowerCase() === item.name.toLowerCase() && scope.assessmentData.assessment.id !== item.id) {
                      scope.isAssessmentExists = true;
                      scope.assessmentGeneralInformation.assessmentName.$setValidity('required', false);
                    }
                    else
                    {
                      scope.assessmentGeneralInformation.assessmentName.$setValidity('required', true);
                    }
                  }
                });
                scope.validateFields();
              });
            }
          };

          scope.isaddDisable = true;
          scope.isTypeDisable = true;
          scope.isOptionScoreDisable = true;
          scope.isSaveDisable = false;

          scope.selectAnswer = function (value) {
            scope.disable = false;

            if (scope.tempOptionScore.length >= 0 && value > 0) {
              angular.forEach(scope.tempOptionScore, function (option) {
                scope.tempOptionScore= [{ id: option.id, value: option.value, score: option.score, sortOrder: option.sortOrder, status: option.status }];
              });
            }

            if (scope.tempOptionScore.length === 0 && value > 0) {
              scope.addOptionScore(value);
              scope.isaddDisable = true;
              scope.optionScoreChange();
            }
          };

          scope.questionsChange = function () {

            if (scope.activeQuestion.text) {
              scope.isTypeDisable = scope.activeQuestion.text.length > 0 ? false : true;
            }
            else {
              scope.isTypeDisable = false;
            }
          };

          //option and Score Change
          scope.isDelete = true;
          scope.optionScoreChange = function (optionValue, index) {
            if (index === 0 && optionValue.score && optionValue.value) {
              scope.isOptionScoreDisable = false;
              scope.isaddDisable = false;
              scope.isSaveDisable = true;
              scope.isDelete = false;
            }
            if (index === 0 && optionValue.score ==='' && optionValue.value) {
              scope.isaddDisable = true;
              scope.isDelete = true;
              scope.isSaveDisable = false;
            }
            if (index === 0 && optionValue.score && (optionValue.value === '' || optionValue.value === undefined)) {
              scope.isaddDisable = true;
              scope.isDelete = true;
              scope.isSaveDisable = false;
            }
          };

          scope.addOptionScore = function (id) {
            if (id > 0 && id !== undefined) {
              scope.isShow = true;
              scope.tempOptionScore = [{ id: '', value: '', score: '', sortOrder: '', status: 'A' }];
            }
            else {
              scope.isShow = false;
            }

          };

          scope.removeOptionScore = function (index) {
              scope.tempOptionScore.splice(index, 1);
              if (scope.tempOptionScore.length ===0)
              {
                scope.tempOptionScore.push({ id: '', value: '', score: null, sortOrder: '', status: 'A' });
                scope.isDelete = true;
              }
            };

          scope.removeQuestion = function (index) {

            scope.assessmentData.assessment.questions.splice(index,1);
          };

          scope.addOptionsRow = function () {
              scope.tempOptionScore.push({ id: '', value: '', score: null, sortOrder: '', status: 'A' });
              angular.forEach(scope.tempOptionScore, function (option) {
                  if (option.value === '' && option.score === null) {
                  }
                });
            };

          scope.click = function (check) {
              scope.assessmentData.assessment.questions.isMandatory = !check;
            };


          scope.saveQuestionOrder = function (question) {

            scope.questionAnswers.push(question);
            scope.assessmentData.assessment.questions = scope.questionAnswers;
            assessmentBuilderSvc.questionAnswers = scope.questionAnswers;
            scope.clearQuestion();

          };

          scope.clearQuestion = function () {
            scope.activeQuestion.text = '';
            scope.activeQuestion.isMandatory = false;
            scope.activeQuestion.options = [];
            scope.activeQuestion.answerType = 1;
            scope.isTypeDisable = true;
            scope.tempOptionScore = [];
            scope.isSaveDisable = false;
            scope.isaddDisable = true;
            scope.selectAnswer();
          };

          if(state.current.name === 'adminassessmentQuestions'){
            if(assessmentBuilderSvc.questionAnswers.length > 0){
              scope.questionAnswers = assessmentBuilderSvc.questionAnswers;
            }
          }
        }]);
  }(window.app)
);