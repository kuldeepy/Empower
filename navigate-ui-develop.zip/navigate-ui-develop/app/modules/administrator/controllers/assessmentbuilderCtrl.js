(function (app) {
  'use strict';

  app.controller('assessmentbuilderCtrl', ['$scope','assessmentBuilderSvc',
    function (scope,assessmentBuilderSvc) {
      
      scope.pageTitle = 'Assessment';
      scope.hideSaveAsDraft = false;

      scope.isSaveAsDraftDisabled = assessmentBuilderSvc.productionStatus === 'F' ? true : false;
      scope.isSaveDisabled = assessmentBuilderSvc.productionStatus === '' ? true : false;
      
      scope.summaryState = {
        state: 1
      };

      scope.searchIsOpen = true;
      scope.taskBundleGridData = [];
      scope.isOpen = true;

      this.answerTypeUI = [
        {
          'db' : 'Radio',
          'ui' : 'Radio Button'
        },
        {
          'db' : 'Text',
          'ui' : 'Text Box'
        },
        {
          'db' : 'Checkbox',
          'ui' : 'Check Box'
        },
        {
          'db' : 'DropDown',
          'ui' : 'Dropdown'
        },
        {
          'db' : 'DateTime',
          'ui' : 'Date and Time'
        },
        {
          'db' : 'NumberText',
          'ui' : 'Text Box (Numbers only)'
        }
      ];
      scope.assesmentdata = {
        status: 'A',
        production: 'F',
        assesmentName: '',
        uniqueId: '',
        description: ''
      };

      this.editAssessmentBuider = {
        id: '',
        isEdit: '',
        isEditStatus: '',
        uniqueId: null ,
      };

      this.assessmentHeader = 'Add Assessment';

      this.assessment = {
          id: 0,
          name: '',
          uniqueId: '',
          description: '',
          productionStatus: 'F',
          status: 'A',
          questions: []
        };



      scope.wizardWorkflow = [
        { 'id': 1, 'name': 'adminassessmentGeneralInformation' },
        { 'id': 2, 'name': 'adminassessmentQuestions' },
        { 'id': 3, 'name': 'adminassessmentSummary' }
      ];


      this.summaryEditURL = '';
      this.finalAssessment = '';
      this.assessmentStatus = '';

      scope.isAssessmentFinal = function () {
        if (scope.assessmentData.assessment.id === 0) {
          scope.isDisable = false;
        } else {
          var flag = (scope.assessmentData.assessment.productionStatus === '' && scope.assessmentData.assessment.id !== 0);
          scope.assessmentData.summaryEditURL = flag ? scope.assessmentData.assessment.productionStatus === 'F' : 'adminassessmentGeneralInformation';
          if (scope.assessmentData.assessment.productionStatus === 'F') {
            scope.isDisable = true;
            scope.assessmentData.finalAssessment = true;
          } else {
            scope.isDisable = false;
            scope.assessmentData.finalAssessment = false;
          }
          scope.assessmentData.assessmentStatus = false;
        }
        return scope.isDisable;
      };


      scope.tabDefinitions = [
        { name: 'adminassessmentGeneralInformation', number: '1', title: 'General Information', selectionCss: 'first active', completed: false, clickable: false, isTabCompleted: false },
        { name: 'adminassessmentQuestions', number: '2', title: 'Define Question(s)', selectionCss: 'inactive', completed: false, clickable: false, isTabCompleted: false },
        { name: 'adminassessmentSummary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false,clickable:false,isTabCompleted:false  }
      ];

      scope.stepDefinitions = [
        [{ name: 'adminassessmentGeneralInformation', letter: 'a', title: 'General Information', selectionCss: 'active', completed: false, clickable: false, isTabCompleted: false }],
        [{ name: 'adminassessmentQuestions', letter: 'a', title: 'Define Question(s)', selectionCss: 'active', completed: false, clickable: false, isTabCompleted: false }],
        [{ name: 'adminassessmentSummary', letter: 'a', title: 'Summary', selectionCss: 'active', completed: false, clickable: false, isTabCompleted: false }]
      ];

    }]);
}(window.app));