(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('AuditUserActivityCtrl', ['$scope', 'auditSvc', 'createUserSvc',  'exportSvc',  '_',
      function (scope, auditSvc, createUserSvc, exportSvc, _) {

        function getUserActivityFilters() {

          var name = scope.search.name ? scope.search.name.split(', ') : [undefined, undefined];
          return {
            role: scope.search.role,
            resource: (scope.search.resource === '') ? null : scope.search.resource,
            action: actionMapFromFriendly[scope.search.action],
            userFirstName: name[1],
            userLastName: name[0],
            startDate: scope.search.dateFrom.value ? window.moment(scope.search.dateFrom.value).format('YYYY-MM-DD') : undefined,
            endDate:
              //Add a day so the upper limit includes the end date
              scope.search.dateTo.value ?
                window.moment(scope.search.dateTo.value)
                .add(1, 'day')
                .format('YYYY-MM-DD')
              : undefined,
            pageSize: scope.scroller.dataChunkSize,
            pageIndex: scope.scroller.dataChunkIndex
          };
        }
      
        function loadMoreUserActivities() {
          scope.scroller.pause = true;
          if (scope.scroller.dataChunkSize * scope.scroller.dataChunkIndex <= scope.scroller.totalElements) {

            var filters = getUserActivityFilters();
            auditSvc.userActivities(filters)
            .then(function(userActivities) {
              _.forEach(userActivities.userActivities, function(activity) {
                activity.request.dateTime = window.moment(activity.request.dateTime).format('M/D/YYYY h:mm:ss A');
                activity.request.action = actionMapToFriendly[activity.request.action];
              });
              
              scope.userActivities = scope.userActivities.concat(userActivities.userActivities);
              scope.scroller.totalElements = userActivities.totalActivitiesCount;
              scope.scroller.pause = false;
            });

            scope.scroller.dataChunkIndex += 1;
          }
        }

        scope.pageTitle = 'User Activities';

        scope.userActivityTable = {
          columns: ['Date & Time', 'Username', 'Provider Name', 'Role', 'Resource Accessed', 'Operation Performed'],
        };

        scope.scroller = {
          more: loadMoreUserActivities,
          totalElements: 0,
          pause: false,
          dataChunkSize: 40,
          dataChunkIndex: 0
        };

        scope.userActivities = [];

        scope.search = {
          isOpen: true,
          roles: [],
          resources: [],
          actions: ['Viewed', 'Created', 'Updated', 'Deleted'],
          names: [],
          dateFrom: {
            opened: false,
            value: null,
            maxDate: new Date(),
            format: 'MM/dd/yyyy'
          },
          dateTo: {
            opened: false,
            value: null,
            maxDate: new Date(),
            format: 'MM/dd/yyyy'
          }
        };

        var actionMapToFriendly = {
          GET: 'Viewed',
          POST: 'Created',
          PUT: 'Updated',
          DELETE: 'Deleted'
        };
        var actionMapFromFriendly = _.invert(actionMapToFriendly);

        scope.clearSearchFields = function() {
          scope.activitySearch.$setPristine();
          scope.search.role = null;
          scope.search.resource = '';
          scope.search.action = null;
          scope.search.name = null;
          scope.search.dateFrom.value = null;
          scope.search.dateTo.value = null;
          scope.applyFilters();
        };

        scope.applyFilters = function() {
          scope.userActivities = [];
          scope.scroller.pause = false;
          scope.scroller.totalElements = 0;
          scope.scroller.dataChunkIndex = 0;
          scope.scroller.more();
        };

        scope.openDateFromPopout = function($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateFrom.opened = !scope.search.dateFrom.opened;
        };

        scope.openDateToPopout = function($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateTo.opened = !scope.search.dateTo.opened;
        };

        scope.exportData = function() {
          var filters = getUserActivityFilters();
          filters.pageSize = undefined;
          filters.pageIndex = undefined;
          filters.isExport = true;
          
          auditSvc.userActivitiesExport(filters).then(function() {
          },
          // ERROR
          function (error) {
            var errorData = null;
            var errorObject = null;
            if(error !== null && error.data !== null)
            {
              errorData = String.fromCharCode.apply(null, new Uint8Array(error.data));
              errorObject = angular.fromJson(errorData);
            }

            if(errorData === null || errorObject.developerMessage === 'Timeout expired.  The timeout period elapsed prior to completion of the operation or the server is not responding.'  || errorObject.code === 'System.Data.SqlClient.SqlException')
            {
              scope.ADMainCtrl.errorNotification = 'Query requested is too large. Server timed out. Please select a smaller Date Range.';
            }
          });
        };

        (function populateSearchData() {

          var searchFilter = {
            onlyPatientResource: false
          };

          auditSvc.userActivityResources(searchFilter).then(function(resources) {
            scope.search.resources = resources;
          });

          auditSvc.userActivityUserNames().then(function(names) {
            _.forEach(names, function(name) {
              scope.search.names.push(name.lastName + ', ' + name.firstName);
            });
          });

          createUserSvc.roles().then(function(roles) {
            _.forEach(roles, function(role) {
              scope.search.roles.push(role.name);
            });
          });

        }());
      }]);

  }(window.app)
);