(function (app) {
  'use strict';
  
  app.controller('modalCriteriaAssessmentCtrl', ['$scope','$modalInstance','$window', '$timeout' ,'listStateSvc','populationDefinitionSvc',
    function (scope,modalInstance,$window,$timeout,listStateSvc,populationDefinitionSvc){
        var tempModalOptions={};
        //Map modal.html $scope custom properties to defaults defined in service
        scope.modalOptions=tempModalOptions;
        scope.modalOptions.available=[];
        scope.modalOptions.selectedAnswers=[];
        scope.AssessmentData={};
        scope.AssessmentData.List=[];
        scope.isDateTimeAnswerType = false;

        scope.timeInMs = 0;
        scope.Linkpopup=function(){
          switch(scope.criteriaName){
          case 'Answers and Scores':
            scope.Questions={};
            scope.modalOptions.headerText='Assessments';
            scope.Questions.compare='0';
            scope.assessmentAnswer=true;
            scope.divQuestions=true;
            scope.divScoreRanges=false;
            scope.isDisable = true;
            populationDefinitionSvc.populationDefinitionGetData('assessments').then(function(response){
              if(response.data.results){
                scope.QuestionaireDD=response.data.results;
              }
            });
            populationDefinitionSvc.populationDefinitionGetData('operators').then(function(responseoperator){
              if(responseoperator.data.results){
                scope.OperatorsDD = responseoperator.data.results;
                scope.OperatorsFromDD = responseoperator.data.results;
              }
            });
            break;
          case 'Assessment Name':
            scope.assessmentNames=true;
            scope.modalOptions.headerText='Assessments';
            scope.AssessmentsData={};
            scope.AssessmentsData.equalsOperator='Equals';
            scope.AssessmentsData.listValues=[];
            scope.modalOptions.Assessmentavailable=[];
            populationDefinitionSvc.populationDefinitionGetData('assessments').then(function(response){
              if(response.data.results){
                scope.modalOptions.Assessmentavailable=response.data.results;
              }
            });
            break;
          }
        };
        
        scope.bindQuestions = function(selectid) {
                scope.isDateTimeAnswerType = false;
                scope.AssessmentData.fromDate = '';
                scope.AssessmentData.toDate = '';
                scope.QuestionsDD = [];

                /*Chrome Issue*/
                if(selectid !== undefined)
                {
                  var conversionToJSONObj = JSON.parse(selectid);
                  selectid = conversionToJSONObj.assessmentId;
                }
                /*Chrome Issue*/
                if(scope.Questions.compare === '0' && selectid > 0){
                  populationDefinitionSvc.populationDefinitionGetData('assessments/' + selectid +'/questions').then(function(response){
                    if(response.data.results){
                      scope.QuestionsDD = _.filter(response.data.results,function(item){
                        if(item.answerType !== 'Text' && item.answerType !== 'NumberText'){
                          return true;
                        }
                      });
                      scope.AnswersDD = [];
                      scope.AssessmentData.Questions='';
                    }
                  });
                }
                if(!selectid)
                {
                  scope.QuestionsDD = [];
                  scope.AnswersDD = [];
                  /*Chrome Issue*/
                  scope.AssessmentData = {List:[]};
                  /*Chrome Issue*/
                }
              };

        scope.BindAnswers = function(selectid,selectAssessmentid) {
                var conversionToJSONQuestionsObj = JSON.parse(scope.AssessmentData.Questions);
                if(conversionToJSONQuestionsObj.answerType !== 'DateTime'){
                   /*Chrome Issue*/
                  var conversionToJSONObj = JSON.parse(selectid);
                  selectid = conversionToJSONObj.id;
                  conversionToJSONObj = JSON.parse(selectAssessmentid);
                  selectAssessmentid = conversionToJSONObj.assessmentId;
                  /*Chrome Issue*/
                  scope.isDateTimeAnswerType = false;
                  populationDefinitionSvc.populationDefinitionGetData('assessments/' + selectAssessmentid +'/questions/'+selectid +'/answers').then(function(response){
                      if(response.data.results){
                        scope.AnswersDD=response.data.results;
                        scope.AssessmentData.List = '';
                        scope.AssessmentData.fromDate = '';
                        scope.AssessmentData.toDate = '';
                      }
                    });
                }
                else{
                  scope.isDateTimeAnswerType = true;
                  scope.AssessmentData.List = [];
                }
                    
              };

        scope.clickAddQuestionAnswer=function(){
          scope.AssessmentData.List.forEach(function(data){
            if(scope.modalOptions.available.length===0){
              scope.modalOptions.available.push(data);
            }
            else
            {
              var flag=0;
              scope.modalOptions.available.forEach(function(selectedData){
                if(selectedData.id===data.id)
               {
                  flag=1;
                }
              });
              if(flag===0)
              {
                scope.modalOptions.available.push(data);
              }
            }
          });
        };

        scope.clickaddAssessmentQuestions=function(AssessmentData,Type){
                  var postAnswersAndScoresCriteria={};
                  /*Chrome Issue*/
                  var conversionToJSONObj = JSON.parse(AssessmentData.assessment);
                  AssessmentData.assessment = conversionToJSONObj;
                  var modifiedData = [];
                  _.each(AssessmentData.List, function(item){
                    modifiedData.push(JSON.parse(item));
                  });
                  
                  AssessmentData.List = modifiedData;
                  /*Chrome Issue*/
                  if(Type === 'Answers'){
                    var conversionToJSONQuestionObj = JSON.parse(AssessmentData.Questions);
                    postAnswersAndScoresCriteria = {
                      criteriaTypeId:scope.criteriaId,
                      criteriaTypeName:scope.criteriaName,
                      assessmentId:AssessmentData.assessment.assessmentId,
                      assessmentName:AssessmentData.assessment.assessmentName,
                      questionId: conversionToJSONQuestionObj.id,
                      questionName: conversionToJSONQuestionObj.name,
                      answerListValues:AssessmentData.List,
                      operator1:'fromDate',
                      operator2:'toDate',
                      input1: AssessmentData.fromDate !== '' ? moment(AssessmentData.fromDate).format('L') : '',
                      input2: AssessmentData.toDate !== '' ? moment(AssessmentData.toDate).format('L') : ''
                    };
                  }
                  else if(Type === 'Score'){
                    postAnswersAndScoresCriteria = {
                        criteriaTypeId:scope.criteriaId,
                        criteriaTypeName:scope.criteriaName,
                        assessmentId:AssessmentData.assessment.assessmentId,
                        assessmentName:AssessmentData.assessment.assessmentName,
                        questionId:'',
                        questionName:'',
                        answerListValues:[],
                        operator1:AssessmentData.operator1,
                        operator2:AssessmentData.operator2,
                        input1:AssessmentData.input1,
                        input2:AssessmentData.input2
                      };
                  }
                  populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/answers-scores-criteria',postAnswersAndScoresCriteria).then(function(response){
                    if(response.data.results){
                      if(response.data.results === true)
                      {
                        modalInstance.dismiss('cancel');
                        scope.getBuildedCriteria();
                      }
                    }
                  });
                };

        scope.clickaddAssessments=function(AssessmentsData){
                  var listVal=[];
                  AssessmentsData.criteriaTypeId=scope.criteriaId;
                  AssessmentsData.criteriaTypeName= scope.criteriaName;
                  AssessmentsData.radioType= '';
                  
                  scope.AssessmentsData.listValues.forEach(function(res){
                    listVal.push({id:res.assessmentId,name:res.assessmentName});
                  });
                  scope.AssessmentsData.listValues=listVal;
                  
                  populationDefinitionSvc.populationDefinitionPostData('population-definition/' +listStateSvc.get().CurrentUIState.populationDefinition.id+'/criteria',scope.AssessmentsData).then(function(response){
                    if(response.data.results){
                      if(response.data.results === true)
                      {
                        modalInstance.dismiss('cancel');
                        scope.getBuildedCriteria();
                      }
                    }
                  });
                };
        scope.modalOptions.close = function () {
          modalInstance.dismiss('cancel');
        };
  
        scope.modalOptions.openQuestions = function(){
          scope.Questions.compare = '0';
          if(scope.AssessmentData.assessment){
            scope.bindQuestions(scope.AssessmentData.assessment.assessmentId);
          }
          scope.assessmentAnswer=true;
          scope.assessmentNames=false;
          scope.divQuestions=true;
          scope.divScoreRanges=false;
          scope.AssessmentData.List=[];
        };
        scope.modalOptions.openScoreRanges = function(){
          scope.assessmentAnswer=true;
          scope.assessmentNames=false;
          scope.divQuestions=false;
          scope.divScoreRanges=true;
          scope.AssessmentData.List=[];
        };

        scope.checkValidation = function(){
          scope.isDisable = true;
          if(scope.AssessmentData.operator1)
          {
            scope.isDisable = (scope.AssessmentData.input1 !== '' && scope.AssessmentData.input1 !== undefined) ? false : true;
          }
          else
          {
            scope.AssessmentData.input1 = '';
          }
          if(scope.AssessmentData.operator2 && !scope.isDisable)
          {
            scope.isDisable = (scope.AssessmentData.input2 !== '' && scope.AssessmentData.input2 !== undefined) ? false : true;
          }
          else
          {
            scope.AssessmentData.input2 = '';
          }
        };

        scope.toDateOpen = function() {
          $timeout(function() {
            scope.toDateOpened = true;
          });
        };

        scope.fromDateOpen = function() {
          $timeout(function() {
            scope.fromDateOpened = true;
          });
        };

        scope.Linkpopup();

      }]);
})(window.app);