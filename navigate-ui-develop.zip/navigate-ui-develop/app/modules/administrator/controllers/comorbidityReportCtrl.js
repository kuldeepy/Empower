(function (app) {
  'use strict';

  app.controller('comorbidityReportCtrl', ['$scope','reportDataSvc','$http','$filter','$timeout','authSvc','homeURL','downloadCsv',
    function (scope,reportDataSvc,http,$filter,timeout,authSvc,homeURL,downloadCsv) {
    
    scope.totalServerItems = 0;
    scope.pagingOptions = {
        pageSizes: [5, 10, 15],
        pageSize: 10,
        currentPage: 1
      };
    scope.keyValue = 0;
    scope.pageIndex = 1;
    scope.pageSize = 10;
    scope.isOpen=true;
    scope.isPhysician = false;
    scope.isInsurance = false;
    scope.selectedConditions = '';
    scope.selectedConditionsTitle = '';
    scope.rowValue = [];

    scope.list = {
      clinicList: [],
      healthPlanList: [],
      vennDiagramData: [],
      comorbidityDate:[],
      selectedClinic: '',
      selectedPhysician: '',
      selectedHealthPlan: '',
      selectedProduct: ''
    };

    scope.user = authSvc.user();

    scope.user.backURL = '';

    scope.canFilterConditions = false;
    scope.showVennLegends = false;

    scope.disableFilterIcon = false;

    scope.patientSearchData = [];

    scope.totalActivePatients = 0;
    scope.popupTitle = '';
    scope.sortOptions = {
      fields: ['patientName'],
      directions: ['BASC']
    };

    scope.gridOptions = {
      data: 'gridData',
      multiSelect: false,
      showFooter: false,
      enablePaging: true,
      totalServerItems: 'totalServerItems',
      columnDefs: 'columnsSelected'
    };

    scope.reportPatientGrid = {
      data: 'gridFilterPatient',
      multiSelect: false,
      showFooter: true,
      enablePaging: true,
      totalServerItems: 'totalServerItems',
      pagingOptions: scope.pagingOptions,
      filterOptions: scope.filterOptions,
      sortInfo : scope.sortOptions,
      useExternalSorting: true,
      columnDefs: 'filterReportGrid'
    };

    scope.errorMessage = 'Unfortunately, we are not able to process your request right now. Please try again later or contact your system administrator if this continues.';
    scope.columnsSelected = [
        {
          field: 'comorbidityKey',
          displayName: 'comorbidityKey',
          visible: false
        },
        {
          field: 'sequenceTitle',
          displayName: '# of Chronic Conditions',
          width:'60%'
        },
        {
          field: 'count',
          displayName: '# of Pts',
          width:'20%',
        },
        {
          field: 'percentage',
          displayName: '% of Pts',
          width:'20%',
          cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<a href="" data="{{row.getProperty(col.headerClass)}}" ng-click="openPatientDetailWindow(row.entity);">{{row.getProperty(col.field)}}%</a>'+
                          '</div>'
        }
      ];

    scope.filterReportGrid = [
        {
          field: 'id',
          displayName: 'id',
          visible: false
        },
        {

          field: 'memberNumber',
          displayName: 'MRN #',
          width:'80px'
        },
        {
          field: 'name',
          displayName: 'Patient Name',
          headerClass: 'id',
          cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<a href="" data="{{row.getProperty(col.headerClass)}}" ng-click="openPatientDetail(row.entity);" title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</a>'+
                          '</div>'

        },
        {
          field: 'age',
          displayName: 'Age',
          width:'60px'
        },
        {
          field: 'gender',
          displayName: 'Gender',
          width:'65px'
        },
        {
          field: 'providerName',
          width:'80px',
          displayName: 'PCP',
          cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<span title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</span>'+
                          '</div>'
        },
        {
          field: 'totalConditions',
          displayName: '# of Conditions',
          width:'110px'
        },
        {
          field: 'conditions',
          displayName: 'Condition(s) Name',
          cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<span title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</span>'+
                          '</div>'
        },
        {
          field: 'managedPopulation',
          displayName: 'Managed Population',
          cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">'+
                          '<span title="{{row.getProperty(col.field)}}">{{row.getProperty(col.field)}}</span>'+
                          '</div>'
        },
        {
          field: 'patientId',
          displayName: 'PatientId',
          visible: false
        }
      ];
    scope.sortName =function(name){
        switch(name){
          case 'memberNumber':
            return 'patientMRN';
          case 'name':
            return 'patientName';
          case 'age':
            return 'PatientAge';
          case 'gender':
            return 'PatientGender';
          case 'providerName':
            return 'PCPList';
          case 'totalConditions':
            return 'DrCnt';
          case 'conditions':
            return 'DrList';
          case 'managedPopulation':
            return 'ProgramList';
        }
      };
    scope.conditionDataList = [];
    scope.conditionValue = [];

    scope.init = function () {
      scope.getComorbidityKey();
      scope.user.backURL = homeURL.getURL(scope.user.role);
    };

    scope.getComorbidityKey = function(){
      reportDataSvc.getLatestDateKeyRequest()
        .then(function (response) {
            scope.list.comorbidityDate = response.data.results[0].dateKeyname;
            scope.keyValue = response.data.results[0].dateKey;
            scope.getClinicsData();
          });
    };

    scope.getClinicsData = function(){
      scope.isPhysician = false;
      reportDataSvc.getClinicsRequest(scope.keyValue)
        .then(function (response) {
          if (response.data.results) {
            scope.list.clinicList = response.data.results;
            if(scope.user.role==='Clinic Administrator'){
              if(scope.list.clinicList===null){
                scope.list.clinicList=[{'id': scope.user.providerId,'name': scope.user.providerName}];
              }
            }
            if(scope.user.role==='Physician'){
              scope.isPhysician = true;
              var pcp =[{'id': scope.user.providerId,'name': scope.user.providerName}];
              scope.list.PhysicianList = pcp ;
              scope.list.selectedClinic = scope.list.clinicList[0].id;
              scope.list.selectedPhysician = scope.user.providerId;
            }
            scope.getHealthPlans();
          }
        });
    };

    scope.openPatientDetail = function(row){
      reportDataSvc.getMergePatient(row.patientId)
      .then(function (response) {
        window.location.href = '/patients/'+ response.data.results;
      });
    };

    scope.getConditions = function(){
      var urlClinicFilter = '';
       
      if(scope.comorbidityReportFilter.selectedClinic !== '') {
        urlClinicFilter = urlClinicFilter + '&clinicId=' + scope.comorbidityReportFilter.selectedClinic;
      }

      if(scope.comorbidityReportFilter.selectedPhysician !== '') {
        urlClinicFilter = urlClinicFilter + '&physicianId=' + scope.comorbidityReportFilter.selectedPhysician;
      }

      if(scope.comorbidityReportFilter.selectedHealthPlan !== '') {
        urlClinicFilter = urlClinicFilter + '&healthPlanId=' + scope.comorbidityReportFilter.selectedHealthPlan;
      }

      if(scope.comorbidityReportFilter.selectedProduct !== '') {
        urlClinicFilter = urlClinicFilter + '&productId=' + scope.comorbidityReportFilter.selectedProduct;
      }
      reportDataSvc.getComorbidityConditionsRequest(scope.keyValue,urlClinicFilter)
     .then(function (response) {
        if (response.data.results) {
          angular.forEach(response.data.results, function (cData) {
            scope.conditionSelectedValue = {};
            scope.conditionSelectedValue.name = cData.name;
            scope.conditionSelectedValue.id = cData.id;
            scope.conditionSelectedValue.ticked = false;
            scope.conditionValue.push(scope.conditionSelectedValue);
          });
          scope.conditionDataList = scope.conditionValue;
        }
      });
    };

    scope.bindGrid = function () {
      reportDataSvc.getBindGridRequest(scope.popupURL, scope.pageIndex, scope.pageSize, scope.sortType===undefined?'BASC':scope.sortType,scope.sortBy===undefined?'patientName':scope.sortBy)
       .then(function (response) {
          scope.patientSearchData  = response.data.results;
          scope.setPagingData(scope.patientSearchData);
        })
        .catch(function () {
          scope.setPagingData(scope.patientSearchData);
          
        });
    };

    scope.openPatientDetailWindow = function(row){
      var urlClinicFilter = '';

      urlClinicFilter = urlClinicFilter + '&key=' + scope.keyValue;

      if(scope.comorbidityReportFilter.selectedClinic !== '') {
        urlClinicFilter = urlClinicFilter + '&clinicId=' + scope.comorbidityReportFilter.selectedClinic;
      }

      if(scope.comorbidityReportFilter.selectedPhysician !== '') {
        urlClinicFilter = urlClinicFilter + '&physicianId=' + scope.comorbidityReportFilter.selectedPhysician;
      }

      if(scope.comorbidityReportFilter.selectedHealthPlan !== '') {
        urlClinicFilter = urlClinicFilter + '&healthPlanId=' + scope.comorbidityReportFilter.selectedHealthPlan;
      }

      if(scope.comorbidityReportFilter.selectedProduct !== '') {
        urlClinicFilter = urlClinicFilter + '&productId=' + scope.comorbidityReportFilter.selectedProduct;
      }
      
      scope.rowValue = row;
      scope.popupTitle = 'Chronic Conditions - '  + row.sequence + ' = # of Patient (' + row.count + ')';
      
      scope.popupURL = 'reports/comorbidity-patients?comorbidityKey=' + row.comorbidityKey + urlClinicFilter;

      scope.reportPatientGrid.pagingOptions.currentPage = 1;
      scope.pageSize = 10;
      
      scope.totalServerItems = row.count;
      reportDataSvc.getBindGridRequest(scope.popupURL, scope.pageIndex, scope.pageSize, scope.sortType===undefined?'BASC':scope.sortType,scope.sortBy===undefined?'patientName':scope.sortBy)
       .then(function (response) {
          if (response.data.results) {
            scope.patientSearchData = response.data.results;
            scope.setPagingData(scope.patientSearchData);

          }
        });
      $('.openReportPopUp').modal({
        backdrop: 'static',
        keyboard: false
      });
      window.setTimeout(function () {
          $(window).resize();
          $(window).resize();
        }, 100);
    };

    scope.setPagingData = function (data) {
      scope.gridFilterPatient = data;
      //scope.totalServerItems = data.length;
      if (!scope.$$phase) {
        scope.$apply();
      }
    };

    scope.$watch('pagingOptions', function (newVal, oldVal) {
      var pageSizeCount = parseInt(scope.pagingOptions.pageSize);
      if (newVal !== oldVal) {
        scope.pagingOptions.currentPage = (newVal.currentPage === undefined || newVal.currentPage === null)  ? 1 : scope.pagingOptions.currentPage;
        scope.pageIndex = (newVal.currentPage === undefined || newVal.currentPage === null) ? 1 : newVal.currentPage;
        scope.pageSize = pageSizeCount;
        scope.bindGrid();
      }
    }, true);

    scope.$watch('filterOptions', function (newVal, oldVal) {
      var pageSizeCount = parseInt(scope.pagingOptions.pageSize);
      if (newVal !== oldVal) {
        scope.pageIndex = newVal.currentPage;
        scope.pageSize = pageSizeCount;
        scope.openPatientDetailWindow(scope.rowValue);
      }
    }, true);

    scope.$watch('sortOptions', function (newVal, oldVal) {
      if(newVal !== oldVal){
        if(newVal.directions.length === 0){
          newVal.directions.push('asc');
        }
        scope.sortBy = scope.sortName(newVal.fields[0]);
        scope.sortType = newVal.directions[0]==='asc' ? 'BASC' : 'BDESC';
        if(scope.popupURL!==undefined){
          scope.bindGrid();
        }
      }
    }, true);
 

    app.filter('getBydenseId', function () {
        return function (input, denseId) {
            var objectFound = {};

            angular.forEach(input, function (iData) {
                if (iData.denseId === denseId) {
                  objectFound = iData;
                }
              });
            return objectFound;
          };
      });
    scope.comorbidityReportFilter = {};
    scope.getFilterData = function(){
      scope.clinicsAll = false;
      scope.resultData=[];
      var url = 'reports/comorbidity?key='+ scope.keyValue;

      if(scope.user.role === 'Clinic Administrator'){
        if(scope.list.selectedClinic === null || scope.list.selectedClinic === '')
         {
          scope.clinicsAll = true;
          scope.list.selectedClinic=scope.user.providerId;
        }
      }

      if(scope.list.selectedClinic !== '') {
        url = url + '&clinicId=' + scope.list.selectedClinic;
      }

      if(scope.user.role === 'Physician'){
        url = url + '&physicianId=' + scope.user.providerId;
      }else if(scope.list.selectedPhysician !== '') {
        url = url + '&physicianId=' + scope.list.selectedPhysician;
      }

      if(scope.list.selectedHealthPlan !== '') {
        url = url + '&healthPlanId=' + scope.list.selectedHealthPlan;
      }

      if(scope.list.selectedProduct !== '') {
        url = url + '&productId=' + scope.list.selectedProduct;
      }
      scope.comorbidityReportFilter = {'selectedClinic':scope.list.selectedClinic,'selectedPhysician':scope.list.selectedPhysician,'selectedHealthPlan':scope.list.selectedHealthPlan,'selectedProduct':scope.list.selectedProduct};
      //scope.getConditions();
      scope.clearVennDiagram();

      reportDataSvc.getStaticData(url)
      .then(function(data) {
            if (data) {
              if (data.comorbidities.length > 0) {
                scope.gridData = data.comorbidities.reverse();
                scope.totalActivePatients = data.comorbidities[0].totalPopulation;
                angular.forEach(scope.gridData, function (gData) {
                  switch (gData.sequence){
                    case '1':
                      gData.sequenceTitle = 'One';
                      gData.sequence = '1';
                      break;
                    case '2':
                      gData.sequenceTitle = 'Two';
                      gData.sequence = '2';
                      break;
                    case '3':
                      gData.sequenceTitle = 'Three';
                      gData.sequence = '3';
                      break;
                    case '4':
                      gData.sequenceTitle = 'Four';
                      gData.sequence = '4';
                      break;
                    case '5':
                      gData.sequenceTitle = 'Five';
                      gData.sequence = '5';
                      break;
                    case '6':
                      gData.sequenceTitle = 'Six';
                      gData.sequence = '6';
                      break;
                    case '7':
                      gData.sequenceTitle = 'Seven';
                      gData.sequence = '7';
                      break;
                    case '8':
                      gData.sequenceTitle = 'Eight and More';
                      gData.sequence = '8 and More';
                      break;
                  }
                });
                scope.multipleChronicConditions = scope.gridData;
              }
              else{
                scope.multipleChronicConditions=[];
                scope.totalActivePatients=0;
              }
            }
          });
      scope.list.selectedClinic = (scope.user.role === 'Clinic Administrator' ? scope.clinicsAll === true ? '' : scope.user.providerId : scope.list.selectedClinic);
    };

    scope.clearVennDiagram = function ()
    {
      d3.select('#venn').html('');
      scope.showVennLegends = false;
      scope.selectedConditions = '';
      scope.selectedConditionsTitle = '';
      scope.canFilterConditions = false;
      scope.showVennLegends = false;
      scope.disableFilterIcon = false;
      scope.conditionDataList = [];
      scope.conditionValue = [];
      scope.vennDropToggle = false;
      scope.maxReached = false;
      scope.getConditions();
    };

    scope.openPatientDetailVenn = function (obj) {
      var urlClinicFilter = '';

      if(scope.comorbidityReportFilter.selectedClinic !== '') {
        urlClinicFilter = urlClinicFilter + '&clinicId=' + scope.comorbidityReportFilter.selectedClinic;
      }

      if(scope.comorbidityReportFilter.selectedPhysician !== '') {
        urlClinicFilter = urlClinicFilter + '&physicianId=' + scope.comorbidityReportFilter.selectedPhysician;
      }

      if(scope.comorbidityReportFilter.selectedHealthPlan !== '') {
        urlClinicFilter = urlClinicFilter + '&healthPlanId=' + scope.comorbidityReportFilter.selectedHealthPlan;
      }

      if(scope.comorbidityReportFilter.selectedProduct !== '') {
        urlClinicFilter = urlClinicFilter + '&productId=' + scope.comorbidityReportFilter.selectedProduct;
      }
      
      scope.popupURL ='reports/comorbidity-patients?key=' + scope.keyValue + urlClinicFilter + '&conditions=' + scope.selectedConditions + '&denseId=' + obj.id.split('-')[1] + '&diagram=Venn' ;
      var url = scope.popupURL + '&pageIndex=' + scope.pageIndex + '&pageSize=' + scope.pageSize+ '&sortType='+ scope.sortType+ '&sortName=' +(scope.sortBy===undefined?'patientName':scope.sortBy);

      scope.popupTitle = 'Conditions - ' + obj.id.split('-')[2];
      scope.totalServerItems = obj.textContent.replace('# = ','');
      scope.pageIndex = 1;
      scope.reportPatientGrid.pagingOptions.currentPage = 1;

      reportDataSvc.getStaticData(url)
      .then(function (data) {
        if (data) {
          scope.patientSearchData = data;
          scope.setPagingData(scope.patientSearchData, scope.pagingOptions.currentPage, scope.pagingOptions.pageSize);
        }
      });
      $('.openReportPopUp').modal({
        backdrop: 'static',
        keyboard: false
      });
              //Fix the grid freezing issue.
      window.setTimeout(function () {
                $(window).resize();
                $(window).resize();
              }, 100);
    };

    /* function to get excel data */
    scope.downloadExcel=function(){
      var url ='';
      url = scope.popupURL + '&pageIndex=0&pageSize=' + scope.totalActivePatients+ '&sortType='+ scope.sortType+ '&sortName=' +(scope.sortBy===undefined?'patientName':scope.sortBy);
      reportDataSvc.getStaticData(url)
      .then(function(data) {
        if (data) {
          var fileName = 'Patients';
          var myPatientsTitle = 'My_Patients';
          var myPatientsHeader = ['MRN#','Patient Name','Age','Gender','PCP',
          '# of Conditions','Condition(s) Name','Managed Population'];
          var fields = ['memberNumber','name','age','gender','providerName',
          'totalConditions','conditions','managedPopulation'];
          downloadCsv.toCSV(fileName,data,myPatientsHeader,fields,myPatientsTitle);
        }
      });
    };

    scope.getConditionSelectedValue = function(){
      scope.canFilterConditions = false;
      if(scope.resultData.length === 3) {
        scope.canFilterConditions = true;
      }
      else if(scope.resultData.length > 3){
        scope.ShowNotifications(' Please select 3 conditions.', 'alert-error');
      }
      else if(scope.resultData.length === 0){
        d3.select('#venn').html('');
        scope.showVennLegends = false;
      }
    };

    scope.closePopup = function(){
      $('.openReportPopUp').modal('hide');
      window.setTimeout(function () {
          $(window).resize();
          $(window).resize();
        }, 100);
      scope.pageIndex = 1;
      scope.pageSize = 10;

    };

    scope.getPhysicians = function (selectedClinic) {
      if(scope.user.role!=='Physician')
      {
        scope.list.PhysicianList = null;
        scope.list.selectedPhysician = '';
        if (selectedClinic === '') {
          scope.list.PhysicianList = null;
        }
        else {
          reportDataSvc.getPhysiciansRequest(selectedClinic,scope.keyValue)
          .then(function (response) {
            if (response.data.results) {
              scope.list.PhysicianList = response.data.results.clinicPhysicians;
            }
          },
           function(){
          });
        }
      }
    };

    scope.getHealthPlans = function () {
        reportDataSvc.getInsurancePlansRequest()
        .then(function (response) {
          if (response.data.results) {
            scope.list.healthPlanList = response.data.results;
            if(scope.user.role==='Insurance Group Provider'){
              scope.isInsurance=true;
              scope.list.selectedHealthPlan=scope.list.healthPlanList[0].id;
            }
            scope.getProducts();
          }
        });
      };

    scope.getProducts = function () {
        reportDataSvc.getProductsRequest()
        .then(function (response) {
          if (response.data.results) {
            scope.list.ProductList = response.data.results;
            scope.getFilterData();
          }
        });
      };
    
    /* display error message if failed to get the data from api*/
     //TODO : Need to remove this code since we have notification directive
    scope.ShowNotifications = function (errorMsg, style) {
        window.scrollTo(0, 0);
        scope.alertMessageStyle = style;
        scope.alertMessage = errorMsg;
        scope.checkboxError = true;
        scope.isError = true;
        timeout(function () {
            scope.checkboxError = false;
            scope.isError = false;
          }, 6000);
      };

    scope.initVenn = function () {
      scope.vennDiagramData = [];
      scope.selectedConditions = '';
      scope.selectedConditionsTitle = '';
      scope.vennDropToggle = false;

      var url = 'reports/comorbidity?diagram=Venn&key='+ scope.keyValue;

      angular.forEach(scope.resultData, function (selectedCondition) {
            if (scope.selectedConditions === '')
            {
              scope.selectedConditions = selectedCondition.id;
              scope.selectedConditionsTitle = selectedCondition.name;
            }
            else{
              scope.selectedConditions = scope.selectedConditions + ',' +  selectedCondition.id;
              scope.selectedConditionsTitle = scope.selectedConditionsTitle + ',' +  selectedCondition.name;
            }
          });

      if(scope.comorbidityReportFilter.selectedClinic !== '') {
        url = url + '&clinicId=' + scope.comorbidityReportFilter.selectedClinic;
      }

      if(scope.comorbidityReportFilter.selectedPhysician !== '') {
        url = url + '&physicianId=' + scope.comorbidityReportFilter.selectedPhysician;
      }

      if(scope.comorbidityReportFilter.selectedHealthPlan !== '') {
        url = url + '&healthPlanId=' + scope.comorbidityReportFilter.selectedHealthPlan;
      }

      if(scope.comorbidityReportFilter.selectedProduct !== '') {
        url = url + '&productId=' + scope.comorbidityReportFilter.selectedProduct;
      }

      url = url + '&conditions=' + scope.selectedConditions;
      
      reportDataSvc.getStaticData(url)
        .then(function (data) {
          if (data) {
            scope.vennDiagramData = data.vennDiagramData;
            scope.VennDetails();
            scope.showVennLegends = true;
          }
        });
    };

    
    scope.VennDetails = function () {
              
              var w = 400,
              h = 450,
              buff = 0.33,
              xbuffer = w * buff-20,
              ybuffer = h * buff,
              radius = 81,
              circledelay = 100,
              textdelay = circledelay * 0,
              outopacity = 0.5,
              overopacity = 1,
              clicks = 0;
              var circledata = [], textdata = [], contextdata = [], chart = [], title = [], heading = [], venncircles = [], context = [], contexttext = [];

              circledata = [{ 'color': '#FF0000', 'x': xbuffer-30, 'y': ybuffer + 70, 'id': 'circleOneD', 'delay': circledelay },
                               { 'color': '#008000', 'x': (w - xbuffer)-100, 'y': ybuffer + 70, 'id': 'circleTwoD', 'delay': circledelay * 2 },
                               { 'color': '#E2ED6B', 'x': (w / 2) - 50, 'y': 120, 'id': 'circleThreeD', 'delay': textdelay }];
              
              scope.conditionTitle1 = $filter('getBydenseId')(scope.vennDiagramData, '1').conditionName ;
              scope.conditionTitle2 = $filter('getBydenseId')(scope.vennDiagramData, '2').conditionName ;
              scope.conditionTitle3 = $filter('getBydenseId')(scope.vennDiagramData, '3').conditionName ;
              // Create an object that contains all of the data for diagram's text
              textdata = [
                [
                  {
                      'text': '',
                      'transform': 'rotate(0 ' + (xbuffer - 0) + ' ' + (ybuffer - 0) + ')',
                      'x': xbuffer - 30,
                      'y': h - (ybuffer - 20),
                      'id': 'circleOne',
                      'class': 'venn_text_big'
                    },
                    {
                      'text': '# = ' + $filter('getBydenseId')(scope.vennDiagramData, '1').patientCount,
                      'transform': 'rotate(0 ' + (xbuffer - 0) + ' ' + (ybuffer - 0) + ')',
                      'x': 40,
                      'y': 220,
                      'id': 'circleOne-' + $filter('getBydenseId')(scope.vennDiagramData, '1').denseId + '-' + $filter('getBydenseId')(scope.vennDiagramData, '1').conditionName,
                      'class': 'venn_text_big'
                    }
                  ],
                  [
                    {
                      'text': '',
                      'transform': 'rotate(0 ' + (w - (xbuffer - 0)) + ' ' + (ybuffer - 0) + ')',
                      'x': w - (xbuffer - 50),
                      'y': h - (ybuffer - 10),
                      'id': 'circleTwo',
                      'class': 'venn_text_big'
                    },
                    {
                      'text': '# = ' + $filter('getBydenseId')(scope.vennDiagramData, '2').patientCount,
                      'transform': 'rotate(0 ' + (w - (xbuffer - 0)) + ' ' + (ybuffer - 0) + ')',
                      'x': 180,
                      'y': 220,
                      'id': 'circleTwo-' + $filter('getBydenseId')(scope.vennDiagramData, '2').denseId  + '-' + $filter('getBydenseId')(scope.vennDiagramData, '2').conditionName,
                      'class': 'venn_text_big'
                    }
                  ],
                  [
                    {
                      'text': '',
                      'transform': 'rotate(0 0 0)',
                      'x': w / 2,
                      'y': (ybuffer - 40),
                      'id': 'circleThree',
                      'class': 'venn_text_big'
                    },
                    {
                      'text': '# = ' + $filter('getBydenseId')(scope.vennDiagramData, '3').patientCount,
                      'transform': 'rotate(0 0 0)',
                      'x': (w / 2)-70,
                      'y': (ybuffer - 40),
                      'id': 'circleThree-' + $filter('getBydenseId')(scope.vennDiagramData, '3').denseId + '-' +  $filter('getBydenseId')(scope.vennDiagramData, '3').conditionName,
                      'class': 'venn_text_big'
                    }
                  ],
                // Intersection text
                  [
                    {
                      'text': '# = ' + $filter('getBydenseId')(scope.vennDiagramData, '1,2,3').patientCount,
                      'transform': 'rotate(0 0 0)',
                      'x': (w / 2)-80,
                      'y': 192,
                      'id': 'circleOneISec-' + $filter('getBydenseId')(scope.vennDiagramData, '1,2,3').denseId  + '-' +  $filter('getBydenseId')(scope.vennDiagramData, '1,2,3').conditionName,
                      'class': 'venn_text_big'
                    }
                  ],
                  [
                    {
                      'text': '',
                      'transform': 'rotate(-0 ' + ((xbuffer + (w / 2)) / 2.2) + ' ' + ((h / 2) + 20) + ')',
                      'x': 145 ,
                      'y': 225 ,
                      'id': 'circleThreeISec',
                      'class': 'venn_text_big'
                    },
                    {
                      'text': '# = ' + $filter('getBydenseId')(scope.vennDiagramData, '1,3').patientCount,
                      'transform': 'rotate(-0 ' + ((xbuffer + (w / 2)) / 2.15) + ' ' + ((h / 2) + 40) + ')',
                      'x': 82,
                      'y': 165,
                      'id': 'circleThreeISec-' + $filter('getBydenseId')(scope.vennDiagramData, '1,3').denseId + '-' +  $filter('getBydenseId')(scope.vennDiagramData, '1,3').conditionName,
                      'class': 'venn_text_big'
                    }
                  ],
                  [
                    {
                      'text': '',
                      'transform': 'rotate(30 ' + (w - (w * 0.40)) + ' ' + ((h / 2) + 20) + ')',
                      'x': w - (w * 0.39),
                      'y': (h / 2) + 20,
                      'id': 'circleTwoISec',
                      'class': 'venn_text_big'
                    },
                    {
                      'text': '# = ' + $filter('getBydenseId')(scope.vennDiagramData, '2,3').patientCount,
                      'transform': 'rotate(0 ' + (w - (w * 0.41)) + ' ' + ((h / 2) + 40) + ')',
                      'x': 160,
                      'y': 165,
                      'id': 'circleTwoISec-' + $filter('getBydenseId')(scope.vennDiagramData, '2,3').denseId + '-' +  $filter('getBydenseId')(scope.vennDiagramData, '2,3').conditionName,
                      'class': 'venn_text_big'
                    }
                  ],
                  [
                    {
                      'text': '',
                      'transform': 'rotate(0 0 0)',
                      'x': w / 2,
                      'y': (h / 2) - 40,
                      'id': 'data_science',
                      'class': 'venn_text_big'
                    },
                    {
                      'text': '# = ' + $filter('getBydenseId')(scope.vennDiagramData, '1,2').patientCount,
                      'transform': 'rotate(0 0 0)',
                      'x': (w / 2)-85,
                      'y': 230,
                      'id': 'data_science-' + $filter('getBydenseId')(scope.vennDiagramData, '1,2').denseId + '-' +  $filter('getBydenseId')(scope.vennDiagramData, '1,2').conditionName,
                      'class': 'venn_text_big'
                    }
                  ]
                ];

              contextdata = {
                  'circleOne': '#',
                  'circleTwo': '#',
                  'circleThree': '#',
                  'circleOneISec': '#',
                  'circleTwoISec': '#',
                  'circleThreeISec': '#'
                };

              d3.select('#venn').html('');

              chart = d3.select('#venn')
                  .append('svg:svg')
                  .attr('height', h)
                  .attr('width', w)
                  .attr('xlink:href', '');

              // Add heading
              title = chart.append('svg:text')
                  .attr('class', 'heading')
                  .attr('x', 10)
                  .attr('y', 20)
                  .text('');


              heading = chart.append('svg:text')
                  .attr('class', 'heading')
                  .attr('x', 10)
                  .attr('y', h - 20)
                  .text('');

              // Draw circles
              venncircles = chart.selectAll('circle')
                  .data(circledata)
                .enter().append('svg:circle')
                  .attr('id', function (d) { return d.id; })
                  .attr('cx', function (d) { return d.x; })
                  .attr('cy', function (d) { return d.y; })
                  .attr('r', 0)
                  .style('fill', '#FFFFFF')
                  .style('opacity', 0.0)
                  .on('click', function () { nextText(); })
                .transition()
                  .delay(function (d) { return d.delay; })
                  .attr('r', radius)
                  .style('fill', function (d) { return d.color; })
                  .style('opacity', 0.3)
                  .style('stroke-width', 2)
                  .style('stroke', 'black');

              context = d3.select('#context')
                  .attr('class', 'contexttext');

              contexttext = context.append('p')
                .attr('class', 'contexttext')
                .text('');

              function nextText() {
                  // Add text
                  if (clicks < textdata.length) {
                    chart.selectAll('venn_text' + clicks + '.text')
                            .data(textdata[clicks])
                            .enter().append('svg:text')
                            .attr('class', function (d) { return d.class; })
                            .attr('id', function (d) { return d.id; })
                            .attr('x', function (d) { return d.x; })
                            .attr('y', function (d) { return d.y; })
                            .attr('transform', function (d) { return d.transform; })
                            .text(function (d) { return d.text; })
                            .style('opacity', 0.0)
                            .on('click', function () {
                                scope.openPatientDetailVenn(this);
                              })
                            .transition()
                            .duration(400)
                            .style('opacity', function () {
                                if (clicks < (textdata.length - 1)) {
                                  return outopacity;
                                }
                                else {
                                  return overopacity;
                                }
                              });
                    clicks += 1;
                  }
                }
              window.setInterval(nextText, 100);
            };
  }]);
  
}(window.app));