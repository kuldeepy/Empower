(function (app) {
  'use strict';
  
  app.controller('Vitals', ['$scope','$modalInstance','$window','listStateSvc','populationDefinitionSvc',function(scope,modalInstance,$window,listStateSvc,populationDefinitionSvc){
      var tempModalOptions = {};
      scope.vital={};
      scope.modalOptions = tempModalOptions;
      scope.timeInMs = 0;
      populationDefinitionSvc.populationDefinitionGetData('vitals').then(function(response){
        if(response.data.results){
          scope.lastVitalDD=response.data.results;
        }
      });
      populationDefinitionSvc.populationDefinitionGetData('operators').then(function(response){
        if(response.data.results){
          scope.valueDD=response.data.results;
          scope.valueSymbolsDD=response.data.results;
        }
      });
      scope.lastOperatorDD=[{'id':1,'name':'AND'},{'id':2,'name':'OR'}];
      scope.vital.operator='AND';
      
      scope.modalOptions.close = function () {
        modalInstance.dismiss('cancel');
      };
        
      scope.clickAddVitals=function(item){
       
        scope.insertVitals={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName,'isChecked':!item.ischecked?false:true,'vitalOrAcgName':!item.lastVital?'':item.lastVital.name,'vitalOrAcgId':!item.lastVital?'':item.lastVital.id,'operator1':!item.value?'':item.value,'value1':!item.valueText?'':item.valueText,'oparend':item.operator,'operator2':!item.valuesymbol?'':item.valuesymbol,'value2':!item.valuesymbolText?'':item.valuesymbolText,'days':!item.valuetaken?'':item.valuetaken};
        populationDefinitionSvc.populationDefinitionPostData('population-definition/'+listStateSvc.get().CurrentUIState.populationDefinition.id+'/vital-acg-criteria',scope.insertVitals).then(function(response){
          if(response.data.results){
            if(response.data.results === true)
             {
              modalInstance.dismiss('cancel');
              scope.getBuildedCriteria();
            }
          }
        });
      };
 
    }]);
})(window.app);