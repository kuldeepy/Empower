(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('PopulationPatientsCtrl', ['$scope', 'managedPopulationSvc',
    function (scope, managedPopulationSvc) {

      if (scope.initializeStep) {
        scope.initializeStep('populationPatients', false);
      }

      scope.patientsTable = {
        caption : '',
        columns : ['Patient Name', 'Date Identified', 'Enrollment Date', 'Status']
      };
      scope.itemsPerPage = 10;
      scope.pageIndex = 1;
      scope.pageSize = 10;
      scope.page = 1;
      scope.disableExportToExcel = false;
      var i = 0;
      var getManagedPopulationPatients = function (size, index) {
        managedPopulationSvc.getManagedPopulationPatients(managedPopulationSvc.managedPopulationId, size, index).then(function (response) {
          scope.patentcount = response.data.results.TotalPatients;
          if (scope.patentcount === 0) {
            scope.disableExportToExcel = true;
          }
          if (i === 1) {
            scope.patientsResults = response.data.results;
          }
          if (i === 0) {
            i = 1;
            getManagedPopulationPatients(scope.itemsPerPage, scope.pageIndex);
          }
          scope.completeStep(true, 'populationPatients');
        });
      };

      getManagedPopulationPatients(scope.itemsPerPage, scope.pageIndex);

      scope.pageChanged = function() {
        getManagedPopulationPatients(scope.itemsPerPage, scope.pageIndex);
      };

      scope.downloadExcel = function () {
        if (scope.patientsResults.TotalPatients > 0) {
          managedPopulationSvc.getManagedPopulationPatients(managedPopulationSvc.managedPopulationId, scope.patientsResults.TotalPatients, scope.page).then(function (response) {
            if (response.data.results) {
              var fileName = 'Patients_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
              var myPatientsHeader = ['Patient Name', 'Date Identified', 'Enrollment Date', 'Status'];
              var csvResult = 'Patients' + '\n' + myPatientsHeader.toString() + '\n';
              angular.forEach(response.data.results.Patients, function (patients) {
                var myPatient = [patients.UserName.indexOf(',') === -1?patients.UserName:'"'+patients.UserName+'"', (patients.IdentificationDate !== null) ? moment(patients.IdentificationDate).format('L') : patients.IdentificationDate, (patients.EnrollmentStartDate !== null) ? moment(patients.EnrollmentStartDate).format('L') : patients.EnrollmentStartDate, patients.StatusDescription];
                csvResult = csvResult + myPatient.toString() + '\n';
              });
              var blob = new Blob([csvResult], {type:'data:text/csv'});
              window.saveAs(blob, fileName);
            }
          });
        }
      };
    }]);

  }(window.app));