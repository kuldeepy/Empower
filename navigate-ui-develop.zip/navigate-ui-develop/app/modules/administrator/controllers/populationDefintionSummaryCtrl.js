(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('populationDefintionSummaryCtrl', ['$scope','listStateSvc','$window','$state','populationDefinitionSvc','downloadCsv',
    function (scope,listStateSvc,window,state,populationDefinitionSvc,downloadCsv) {
      if (scope.initializeStep) {
        scope.initializeStep('pdsummary', true);
      }
      scope.summaryCancel='Cancel';
      scope.isSaveAsDraftDisabled = false;
      scope.isSaveDisabled = false;
      scope.getSummarydetails = function(){
        var populationDefinitionDetails = listStateSvc.get();
        var populationDefinitionId = populationDefinitionDetails.CurrentUIState.populationDefinition.id;
        if(populationDefinitionDetails.CurrentUIState.populationDefinition.isDraft === false){
          scope.summaryCancel = 'Close';
        }
        populationDefinitionSvc.populationDefinitionGetData('population-definition/'+populationDefinitionId+'/summary').then(function(response){
          if(response.data.results){
            scope.generalInformation=response.data.results.populationDefinitions[0];
            if(scope.generalInformation.productionStatus === 'Final')
            {
              scope.isSaveAsDraftDisabled = true;
            }
            scope.criteriaTypes=response.data.results.criteriaNames;
            scope.textDefinition = response.data.results.buildCriteriaText;
            scope.eligiblePatientsCount=response.data.results.count;
          }
        });
      };

      scope.refreshbuildCriteria = function(){
        var populationDefinitionDetails = listStateSvc.get();
        var populationDefinitionId = populationDefinitionDetails.CurrentUIState.populationDefinition.id;
        populationDefinitionSvc.populationDefinitionGetData('population-definition/'+populationDefinitionId+'/patients-count').then(function(response){
          if(response.data.results){
            scope.eligiblePatientsCount = response.data.results.count;
          }
        });
      };

      scope.downloadExcel=function(){
        if(scope.eligiblePatientsCount > 0)
        {
          var populationDefinitionDetails = listStateSvc.get();
          var populationDefinitionId = populationDefinitionDetails.CurrentUIState.populationDefinition.id;
          populationDefinitionSvc.populationDefinitionGetData('population-definition/'+populationDefinitionId+'/patients').then(function(response){
            if(response.data.results){
              var fileName = 'Patients';
              var myPatientsTitle = 'Patients';
              var myPatientsHeader = ['Patient Name','Gender','Age','Status','Member No'];
              var fields = ['fullName','gender','age','status','memberNum'];
              downloadCsv.toCSV(fileName,response.data.results,myPatientsHeader,fields,myPatientsTitle);
            }
          });
        }
      };

      scope.$on('wizardonCancel', function() {
        var currentListState = listStateSvc.get();
        currentListState.CurrentUIState.flag = true;
        listStateSvc.set(currentListState);
      });
      scope.getSummarydetails();


    }]);
  }(window.app));
