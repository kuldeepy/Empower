﻿(function (app) {
  'use strict';

  app.controller('assessmentListCtrl', ['$scope', '$location', '$timeout','assessmentBuilderSvc', '$state',
    function (scope,location,timeout,assessmentBuilderSvc,state) {
      
      scope.pageTitle = 'Assessment';
     
      scope.ShowNotifications = function (errorMsg, style) {
        window.scrollTo(0, 0);
        scope.alertMessageStyle = style;
        scope.alertMessage = errorMsg;
        scope.isError = true;
        scope.isSuccessMsg = style === 'alert-success' ? true : false;

        timeout(function () {
          scope.isError = false;
        }, 6000);
      };

      if(assessmentBuilderSvc.saveNotificationMsg){
        scope.ShowNotifications(assessmentBuilderSvc.saveNotificationMsg,'alert-success');
        assessmentBuilderSvc.saveNotificationMsg = null;
      }
      scope.columnsSelected = [{ field: 'name', displayName: 'Assessment Name', columnClass: 'table-column-name' }, { field: 'description', displayName: 'Description', columnClass: 'table-column-assessment-description' }, { field: 'productionStatus', displayName: 'Production', columnClass: 'table-column-status' }, { field: 'status', displayName: 'Status', columnClass: 'table-column-assessment-status', sortable: false }, { field: 'lastModifiedDate', displayName: 'Last Updated', columnClass: 'table-column-status' }, { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false }];

      scope.searchIsOpen = true;
      scope.taskBundleGridData = [];
      scope.isOpen = true;

      scope.assesmentSearch = {
          status: 'Active',
          production: '',
          assesmentName: '',
          description: ''
        };
      scope.page = 1;
      scope.pageSize = 10;

      scope.resetpagination = function () {
        scope.page = 1;
      };

      scope.clearAssesment = function () {
          scope.assesmentSearch.status = 'Active';
          scope.assesmentSearch.production = '';
          scope.assesmentSearch.assesmentName = '';
          scope.assesmentSearch.description = '';
          scope.searchAssessments();
        };


      this.assessmentHeader = 'Add Assessment';
 
      scope.addAssesment = function (row) {

        assessmentBuilderSvc.questionAnswers = [];

        if (row) {
          if(row.id > 0 ){
            localStorage.setItem('assessmentBuilderId',  row.id ? row.id : 0);
            localStorage.setItem('uniqueId', row.uniqueId ? row.uniqueId : 0);
            assessmentBuilderSvc.productionStatus = row.productionStatus;
            localStorage.setItem('isAssessmentBuilderEdit', row.id ? true : false);
            state.go('adminassessmentSummary');
          }
        }else{
          assessmentBuilderSvc.productionStatus = 'D';
          localStorage.removeItem('assessmentBuilderId');
          localStorage.removeItem('isAssessmentBuilderEdit');
          localStorage.removeItem('uniqueId');
        }

        location.url(app.currentRoute + '/library/assessment/add');
      };

      scope.searchAssessments = function(){

        var productionStatus =  scope.assesmentSearch.production === 'Final' ? 'F' : scope.assesmentSearch.production === 'Draft' ? 'D' : '';
        var status =  scope.assesmentSearch.status === 'Active' ? 'A' : 'I';
        scope.page = 1;
        assessmentBuilderSvc.getAssessments(scope.assesmentSearch.assesmentName,scope.assesmentSearch.description,status,productionStatus).then(function(response){
          if(response.data.results){
            scope.assesments = response.data.results;
          }
        });
      };

      scope.searchAssessments();

    }]);

}(window.app));