(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.controller('ManagedPopulationInformationCtrl', ['$scope','_','managedPopulationSvc','$state','$q','careTeamSvc','taskBundleDataSvc','$location','populationDefinitionSvc','$modal',
    function (scope,_,managedPopulationSvc,state,q,careTeamSvc,taskBundleDataSvc,location,populationDefinitionSvc,$modal) {
        scope.ispopulationDefinitionDisabled=false;
        var mapTaskBundlesStep = 'mapTaskBundles';
        var mapCareTeamStep = 'mapCareTeam';
        var mapPopulationDefinitionStep = 'mapPopulationDefinition';
        var managedPopulationInformationStep = 'managedPopulationInformation';
        var conflictWindow;
        scope.currentStep = state.current.name;
        scope.message='Managed population already exists';
        scope.pdselection={status:'Active',productionStatus:'Final'};
        scope.disableCareTeams =[];
        scope.flagTaskbundleChanged = false;
        scope.flagPDChanged = false;

        scope.patientsTable = {
          caption : '',
          columns : ['Patient Name', 'Date Identified', 'Enrollment Date', 'Status']
        };

        scope.itemsPerPage = 10;
        scope.pageIndex = 1;
        scope.pageSize = 10;
        scope.page = 1;
        scope.disableExportToExcel = false;

        if (scope.initializeStep) {
          if(managedPopulationSvc.editSummaryStatus === 'managedPopulationSummary'){
            managedPopulationSvc.editSummaryStatus = '';
            state.go('managedPopulationSummary');
          }
          scope.initializeStep(scope.currentStep, false);
        }

        scope.getAllPopulationDefinition = function (selection) {
          var populationDefinitionSearch={populationDefinitionId:selection.populationDefinitionId,status:selection.status, populationDefinitionName:selection.populationDefinitionName,description:selection.description,productionStatus:selection.productionStatus,refresh:selection.refresh};
          populationDefinitionSvc.populationDefinitionGetData('population-definition?populationDefinitionSearch='+JSON.stringify(populationDefinitionSearch))
          .then(function(response){
              scope.populationDefinitionResults = response.data.results;
              scope.setPopulationDefinition();
            });
        };

        scope.completeForm = function(isComplete,stepname) {
          scope.completeStep(isComplete,stepname);
        };
        //select managed population definition step
        if(state.current.name === mapPopulationDefinitionStep){
          scope.getAllPopulationDefinition(scope.pdselection);
        }

        careTeamSvc.GetActiveCareTeams({IncludeInActive:false}).then(
          function(response){
            scope.allCareTeams  = response.data.results;
            scope.careTeams  = response.data.results;
          }
        );

        taskBundleDataSvc.getActiveTaskBundles().then(
          function(response){
            scope.allTaskBundles  = response.data.results;
            scope.allTaskBundlesall  = response.data.results;
            if(scope.mngpopCtrl.managedPopulation.productionStatus === 'F'){
              scope.disableTaskbundles = managedPopulationSvc.taskBundles;
            }

          });
        


        scope.showErrorMessage = function(error){
          state.go('managedPopulationInformation');
          scope.mngpopCtrl.showNotifications(error, 'alert-error');
        };
       
        scope.closeModal = function(){
          managedPopulationSvc.taskConflicts = [];
          conflictWindow.close();
        };
        scope.showConflicts = function(){
          conflictWindow = $modal.open({
            templateUrl: 'conflicModalContent.html',
            size: 'lg',
            scope: scope,
            backdrop : 'static'
          });
        };

        scope.$watch('generalInformation.$valid', function(val) {
            if (state.current.name === managedPopulationInformationStep) {
              if (scope.editManagedPopulationName !== scope.mngpopCtrl.managedPopulation.name) {
                scope.checkManagedPopulationExist();
              }
              scope.completeStep(val,managedPopulationInformationStep);
            }
          });

        scope.$watch('generalInformation.$pristine', function () {
          if (scope.generalInformation && !scope.generalInformation.$pristine) {
            localStorage.setItem('isWizardFormDirty', true);
          }
        });

        scope.$on('wizardOnClose', function() {
          
          if(app !== undefined && app.currentRoute !== undefined) {
            location.url(app.currentRoute+'/configuration/population');
          }
          else{
            location.url('/admin/configuration/population');
          }
        });

        scope.populationDefinitionSelected = function () {

          if (scope.mngpopCtrl.managedPopulation.populationDefinition === undefined || scope.mngpopCtrl.managedPopulation.populationDefinition.populationDefinitionId === '') {
            scope.showManagedPopulationPatients = false;
            scope.completeForm(false, mapPopulationDefinitionStep);
          }
          if (scope.mngpopCtrl.managedPopulation.populationDefinition.populationDefinitionId !== '') {
            scope.getAllPopulationDefinition(scope.pdselection);
            getManagedPopulationPatients(scope.itemsPerPage, scope.pageIndex);
          }

          scope.setSubStepsClickable(0);
          scope.flagPDChanged = true;
        };
        
        scope.$watch('mngpopCtrl.managedPopulation.taskBundles.length', function () {

            if(state.current.name === mapTaskBundlesStep && scope.flagTaskbundleChanged){
              managedPopulationSvc.taskConflicts = []; // reset taskConflicts to get new task conflicts if any task bundle has changed
              managedPopulationSvc.taskConflictsResolved = [];
              managedPopulationSvc.nonTaskConflicts = [];
              managedPopulationSvc.taskResolvedEdit = false;
              scope.setStepSummaryClickable(false,2);
            }

            if(state.current.name === mapTaskBundlesStep){
              scope.setSubStepsClickable(1);
            }
            scope.flagTaskbundleChanged = true ;
          });

        scope.$watch('mngpopCtrl.managedPopulation.taskBundles', function () {
          

          if(state.current.name === mapTaskBundlesStep){
            if(scope.mngpopCtrl.managedPopulation.taskBundles.length > 0){
              scope.completeForm(true, mapTaskBundlesStep);
            }else{
              scope.completeForm(false, mapTaskBundlesStep);
            }
          }
          
        });

        scope.$watch('mngpopCtrl.managedPopulation.populationId',function() {
          if(scope.mngpopCtrl.managedPopulation.populationId > 0){
            managedPopulationSvc.managedPopulationId = scope.mngpopCtrl.managedPopulation.populationId;
          }
        });
        
        scope.$watch('mngpopCtrl.managedPopulation.careTeams',function() {
          if(state.current.name === mapCareTeamStep){
            if(scope.mngpopCtrl.managedPopulation.careTeams.length > 0){
              scope.completeForm(true,mapCareTeamStep);
            }
            else{
              scope.completeForm(false,mapCareTeamStep);
            }
          }
        });

        scope.checkManagedPopulationExist = function() {
            if (scope.mngpopCtrl.managedPopulation.editManagedPopulationName !== scope.mngpopCtrl.managedPopulation.name) {
              managedPopulationSvc.checkManagedPopulation(scope.mngpopCtrl.managedPopulation.name).then(function(data) {
                scope.isManagedPopulationExist = data;
                if(scope.isManagedPopulationExist)
                {
                  scope.generalInformation.managedPopulationName.$setValidity('required', false);
                }
                if (scope.generalInformation.$valid) {
                  scope.completeStep(!scope.isManagedPopulationExist, managedPopulationInformationStep);
                }
              });
            }else{
              scope.isManagedPopulationExist = false;
            }
          };
        scope.disableExportToExcel = true;
        var getManagedPopulationPatients = function (size, index) {
          var data = {'pageSize':size,'pageIndex':index};
          managedPopulationSvc.getManagedPopulationPatients(scope.mngpopCtrl.managedPopulation.populationDefinition.populationDefinitionId,scope.mngpopCtrl.managedPopulation.id,managedPopulationSvc.productionStatus, data).then(function (response) {
            scope.patentcount = response.data.results.TotalPatients;
            scope.completeForm(true, mapPopulationDefinitionStep);
            scope.showManagedPopulationPatients = true;
            if (scope.patentcount !== 0) {
              scope.disableExportToExcel = false;
            }
            scope.patientsResults = response.data.results;
          });
        };

        scope.pageChanged = function() {
          getManagedPopulationPatients(scope.itemsPerPage, scope.pageIndex);
        };

        scope.downloadExcel = function () {
          if (scope.patientsResults.TotalPatients > 0) {
            var data = {'pageSize':scope.patientsResults.TotalPatients,'pageIndex':scope.page};
            managedPopulationSvc.getManagedPopulationPatients(scope.mngpopCtrl.managedPopulation.populationDefinition.populationDefinitionId,scope.mngpopCtrl.managedPopulation.id,managedPopulationSvc.productionStatus, data).then(function (response) {
              if (response.data.results) {
                var fileName = 'Patients_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
                var myPatientsHeader = ['Patient Name', 'Date Identified', 'Enrollment Date', 'Status'];
                var csvResult = 'Patients' + '\n' + myPatientsHeader.toString() + '\n';
                angular.forEach(response.data.results.Patients, function (patients) {
                  var myPatient = [patients.UserName.indexOf(',') === -1?patients.UserName:'"'+patients.UserName+'"', (patients.IdentificationDate !== null) ? moment(patients.IdentificationDate).format('L') : patients.IdentificationDate, (patients.EnrollmentStartDate !== null) ? moment(patients.EnrollmentStartDate).format('L') : patients.EnrollmentStartDate, patients.StatusDescription];
                  csvResult = csvResult + myPatient.toString() + '\n';
                });
                var blob = new Blob([csvResult], {type:'data:text/csv'});
                window.saveAs(blob, fileName);
              }
            });
          }
        };

        scope.setPopulationDefinition = function () {
          scope.selectedDefinition = scope.mngpopCtrl.managedPopulation.populationDefinition;
          scope.mngpopCtrl.managedPopulation.populationDefinition = _.find(scope.populationDefinitionResults, function (item) {
            return item.populationDefinitionId === scope.selectedDefinition.populationDefinitionId;
          });
          if(scope.mngpopCtrl.managedPopulation.id > 0)
          {
            scope.ispopulationDefinitionDisabled = scope.mngpopCtrl.managedPopulation.productionStatus === 'F' ? true : false;
          }

        };

        scope.init = function () {
          scope.populationDefinitionSelected();
        };

        scope.setStepSummaryClickable = function(flag,startIndex){

          scope.tabDefinitions[2].clickable = flag;
          scope.stepDefinitions[1][2].clickable = flag;
          scope.stepDefinitions[1][3].clickable = flag;
          scope.stepDefinitions[1][4].clickable = flag;

          for(var a = startIndex; a < scope.stepDefinitions[1].length; a=a+1)
            {
            scope.stepDefinitions[1][a].clickable = flag;
            scope.stepDefinitions[1][a].isTabCompleted = flag;
          }

          scope.stepDefinitions[1][2].isTabCompleted = flag;
          scope.stepDefinitions[1][3].isTabCompleted = flag;
          scope.stepDefinitions[1][4].isTabCompleted = flag;

        };

        scope.setSubStepsClickable = function(index) {

          for(var a = index+1; a < scope.stepDefinitions[1].length; a=a+1)
          {
            if(scope.stepDefinitions[1][a].isTabCompleted)
            {
              scope.stepDefinitions[1][a].clickable = true;
            }
          }
        };

        scope.resetConflictStatus = function () {
          managedPopulationSvc.taskConflicts = [];
          managedPopulationSvc.taskConflictsResolved = [];
          managedPopulationSvc.nonTaskConflicts = [];
          scope.setStepSummaryClickable(false,0);
        };

      }]);

  }(window.app));