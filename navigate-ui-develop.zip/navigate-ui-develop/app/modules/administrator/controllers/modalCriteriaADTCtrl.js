(function (app) {
  'use strict';
  
  app.controller('modalCriteriaADTCtrl', ['$scope','$modalInstance','$window','listStateSvc','populationDefinitionSvc',
  function (scope,modalInstance,$window,listStateSvc,populationDefinitionSvc) {
    var tempModalOptions = {};
    //Map modal.html $scope custom properties to defaults defined in service
    scope.modalOptions = tempModalOptions;
    scope.timeInMs = 0;
    scope.ADTData={};
    scope.ADTData.adtType='Admission';

    scope.clickaddADT=function(ADTData){
      var data={'criteriaTypeId':scope.criteriaId,'criteriaTypeName':scope.criteriaName,'adtType':scope.ADTData.adtType,'dischargeDays':!ADTData.days?'':ADTData.days};
      var currentListState = listStateSvc.get();
      scope.Populationid=currentListState.CurrentUIState.populationDefinition.id;
       
      populationDefinitionSvc.populationDefinitionPostData('population-definition/' +scope.Populationid+'/adt-feed-criteria',data).then(function(response){
        if(response.data.results){
          if(response.data.results === true){
            modalInstance.dismiss('cancel');
            scope.getBuildedCriteria();
          }
        }
      });
    };

    scope.showdischarge = function (result) {
      scope.Discharge = false;
      if(result==='D')
      {
        scope.Discharge = true;
        scope.ADTData.adtType = 'Discharge';
      }
      else if(result === 'A')
      {
        scope.ADTData.adtType = 'Admission';
      }
      else
      {
        scope.ADTData.adtType = 'ER';
      }
    };
        
    scope.modalOptions.close = function () {
      modalInstance.dismiss('cancel');
    };

  }]);
})(window.app);