(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('AuditErrorCtrl', ['$scope', 'auditSvc', 'exportSvc', '_',
      function (scope, auditSvc, exportSvc, _) {
      
        function loadMoreErrors() {
          scope.scroller.pause = true;
          if (scope.scroller.dataChunkSize * scope.scroller.dataChunkIndex <= scope.scroller.totalElements) {
            var filters = getErrorFilters();
            auditSvc.errors(filters)
            .then(function(errors) {
              _.forEach(errors.errors, formatDate);
              scope.errors = scope.errors.concat(errors.errors);
              scope.scroller.totalElements = errors.totalErrorCount;
              scope.scroller.pause = false;
            });

            scope.scroller.dataChunkIndex += 1;
          }
        }

        scope.title = 'System Errors';

        scope.errorTable = {
          columns: ['Error Date', 'Username', 'Source', 'Procedure', 'Error Message', 'Error Code'],
        };

        scope.scroller = {
          more: loadMoreErrors,
          totalElements: 0,
          pause: false,
          dataChunkSize: 40,
          dataChunkIndex: 0
        };

        scope.errors = [];

        scope.search = {
          isOpen: true,
          sourceList: [],
          names: [],
          dateFrom: {
            opened: false,
            value: null,
            maxDate: new Date(),
            format: 'MM/dd/yyyy'
          },
          dateTo: {
            opened: false,
            value: null,
            maxDate: new Date(),
            format: 'MM/dd/yyyy'
          }
        };

        scope.openDateFromPopout = function($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateFrom.opened = !scope.search.dateFrom.opened;
        };

        scope.openDateToPopout = function($event) {
          $event.stopPropagation();
          $event.preventDefault();
          scope.search.dateTo.opened = !scope.search.dateTo.opened;
        };

        scope.clearSearchFields = function() {
          scope.search.name = null;
          scope.search.sourceList = null;
          scope.search.dateFrom.value = null;
          scope.search.dateTo.value = null;
          scope.applyFilters();
        };

        scope.applyFilters = function() {
          scope.errors = [];
          scope.scroller.pause = false;
          scope.scroller.totalElements = 0;
          scope.scroller.dataChunkIndex = 0;
          scope.scroller.more();
        };

        scope.$watch('sourceFilter', function(newVal, oldVal) {
          //Ignore initial load.
          if (newVal === oldVal) { return; }
          scope.errors = [];
          scope.scroller.pause = false;
          scope.scroller.dataChunkIndex = 0;
          scope.scroller.more();
        });

        function getErrorFilters() {
          return {
            userName: scope.search.name,
            source: scope.search.sourceList,
            startDate: scope.search.dateFrom.value ? window.moment(scope.search.dateFrom.value).format('YYYY-MM-DD') : undefined,
            endDate:
              //Add a day so the upper limit includes the end date
              scope.search.dateTo.value ?
                window.moment(scope.search.dateTo.value)
                .add(1, 'day')
                .format('YYYY-MM-DD')
              : undefined,
            pageSize: scope.scroller.dataChunkSize,
            pageIndex: scope.scroller.dataChunkIndex
          };
        }

        scope.downloadExcel = function() {
          var filters = getErrorFilters();
          filters.pageSize = undefined;
          filters.pageIndex = undefined;
          filters.isExport = true;
          if(filters.source.length < 1)
          {
            filters.source = undefined;
          }
          auditSvc.errorsExport(filters)
          .then(function() {
          },
          // ERROR
          function (error) {
            var errorData = null;
            var errorObject = null;
            if(error !== null && error.data !== null)
            {
              errorData = String.fromCharCode.apply(null, new Uint16Array(error.data));
              errorObject = angular.fromJson(errorData);
            }

            if(errorData === null || errorObject.developerMessage === 'Timeout expired.  The timeout period elapsed prior to completion of the operation or the server is not responding.')
            {
              scope.ADMainCtrl.errorNotification = 'Query requested is too large. Server timed out. Please select a smaller Date Range.';
            }
          });
        };

        (function populateSearchData() {

          scope.search.sourceLists = [];
          scope.search.sourceLists.push('Database');
          scope.search.sourceLists.push('Services');
          scope.search.sourceLists.push('API');
          scope.search.sourceLists.push('UI');

          auditSvc.userActivityUserNames().then(function(names) {
            _.forEach(names, function(name) {
              scope.search.names.push(name.userLoginName);
            });
          });
        }());

        function formatDate(error) {
          error.errorDate = window.moment(error.errorDate).format('M/D/YYYY h:mm:ss A');
        }
        
      }]);

  }(window.app)
);