(function(app) {
  'use strict';
  
  app.controller('teamManagementCtrl', ['$scope', 'teamManagementSvc','authSvc','$timeout',
		function(scope, teamManagementSvc,authSvc,timeout){
			
			scope.user = authSvc.user();
			scope.notificationAlert = false;
			var programId = 0;

			scope.getSupervisorManagedPopulations = function(){
				teamManagementSvc.getProviderManagedPopulations(scope.user.providerId).then(function(res){
					scope.managedPopulationList = res.data.results;
					scope.getManagedPopulationsDetails(scope.managedPopulationList[0]);
				});
			};

			scope.getManagedPopulationsDetails = function(item){
				if(item.programId !== programId)
				{
					scope.notificationAlert = false;
					item.careManagersTaskList = [];
					programId = item.programId;
					teamManagementSvc.getProviderManagedPopulationDetails(item.programId).then(function(res){
						item.careManagersTaskList = res.data.results;
					});
				}
			};

			scope.activeInactiveCareTeamMember = function(item, val, careManagersTaskList){
				scope.notificationAlert = false;
				if(item.status === 'A' && val === 'close')
				{
					var activeCareTeamMembers = item.status ? _.where(careManagersTaskList, {status : 'A'}) : careManagersTaskList;
					if(activeCareTeamMembers.length > 1)
					{
						teamManagementSvc.putActiveInactiveCareTeamMember(item.providerId, programId);
						item.status = item.status === 'A'?'I':'A';
					}
					else
					{
						scope.notificationAlert = true;
						timeout(function (){
							scope.notificationAlert = false;
						}, 6000);
					}
				}
				else if(item.status === 'I' && val === 'open')
				{
					teamManagementSvc.putActiveInactiveCareTeamMember(item.providerId, programId);
					item.status = item.status === 'A'?'I':'A';
				}
			};
			scope.getSupervisorManagedPopulations();
		}
	]);
})(window.app);