﻿(function(app) {
    'use strict';

    app.controller('PatientSearchCtrl', ['$scope', '$location', 'patientSearchSvc','$window', function(scope, location, patientSearchSvc,window) {
        scope.pageTitle = 'Patients';
        scope.userRoles = [{'name':'care manager','url':'/caremanager'},{'name':'clinic administrator','url':'/clinicAdmin'},{'name':'physician','url':'/physicians'},
                          {'name':'insurance group provider','url':'/insurance'},{'name':'administrator','url':'/admin'}
                         ];
        scope.popUpHeader = {
            conditionClassName: 'Conditions',
            missedOpportunityClassName: 'Missed Opportunity',
            managedPopulationClassName: 'Managed Population',
            lastVisitClassName: 'Past Encounters'
          };

        /*PopUp Class Name*/
        scope.PopUpClassName = {
            ConditionClassName: 'openConditionPopUp',
            MissedOpportunityClassName: 'openMissedOpportunityPopUp',
            ManagedPopulationClassName: 'openManagedPopulationPopUp',
            LastVisitClassName: 'openLastVisitPopUp'
          };

        scope.$watch('pageIndex', function(newVal, oldVal) {
            var pageSizeCount = scope.pageSize;
            if (newVal !== oldVal) {
              scope.pageIndex = newVal;
              scope.pageSize = pageSizeCount;
              scope.bindGrid(scope.pageIndex);
            }
          }, true);

        scope.popupAction = function(className, action) {
            if (action === 'show') {
              $('.' + className + '').modal({
                backdrop: 'static',
                keyboard: false
              });
            } else {
              $('.' + className + '').modal('' + action + '');
            }
          };

        scope.openViewDetailsPopUp = function(row, fieldName, className) {
            scope.httpUrl = '';
            if (fieldName === 'Missed Opp.') {
              scope.httpUrl = 'patients/' + row.PatientId + '/missed-opportunities/care-gaps';
              scope.popupAction(className, 'show');
            } else if (fieldName === 'Managed Pop.') {
              scope.httpUrl = 'patients/' + row.PatientId + '/patient-populations?programIds=' + (scope.filterData.managedPopulations !== null ? scope.filterData.managedPopulations : '');
              scope.popupAction(className, 'show');
            } else if (fieldName === 'Last Visit') {
              scope.httpUrl = 'patients/' + row.PatientId + '/visits';
              scope.popupAction(className, 'show');
            } else if (fieldName === 'Conditions') {
              scope.httpUrl = 'patients/' + row.PatientId + '/conditions?diseaseIds=' + (scope.filterData.conditions !== null ? scope.filterData.conditions : '') + '&type=diseases';
              scope.popupAction(className, 'show');
            }
            window.setTimeout(function() {
                $(window).resize();
              }, 20);
            scope.popupHttpGetCall(scope.httpUrl);
          };

        scope.popupHttpGetCall = function(httpUrl) {
            var requestpath = httpUrl;
            patientSearchSvc.getRequest(requestpath).then(function(response) {
                scope.popupResultData = response.data.results;
                scope.reset = scope.reset === scope.popupResultData.length ? 0 : scope.popupResultData.length;
              });
          };

        scope.closePopup = function(className) {
            scope.popupAction(className, 'hide');
          };

        scope.openPatientPage = function(row) {
            window.location.href = 'patients/' + row.PatientId;
          };

        scope.downloadExcel = function() {
            scope.filterData.pageSize = scope.totalPatientCount;
            scope.filterData.pageIndex = 1;
            patientSearchSvc.getPatientsForExport(scope.filterData).then(function(response) {
                    if (response.data) {
                      var mime = response.headers('Content-Type');
                      var file = new Blob([response.data], {
                          type: mime
                        });

                      var fileName = 'Patients_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
                      saveAs(file, fileName);
                      return true;
                    }
                  },
                function(error) {
                    if (error !== null) {
                      var errorData = String.fromCharCode.apply(null, new Uint8Array(error.data));
                      var errorObject = angular.fromJson(errorData);
                      if (errorObject.developerMessage === 'Timeout expired.  The timeout period elapsed prior to completion of the operation or the server is not responding.') {
                        scope.PSMainCtrl.setErrorNotification = 'Data is too large to export. Please filter the Patients and try again.';
                      }
                    }
                  });
          };

        scope.backToMyTasksPage = function() {
          var urlData = _.where(scope.userRoles,{'name':angular.lowercase(scope.user.role)});
          window.location.href = urlData[0].url;
        };

      }]);
  }(window.app));
