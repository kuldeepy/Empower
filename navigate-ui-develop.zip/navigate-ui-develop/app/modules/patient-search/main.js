(function (app) {
  'use strict';

  /* module root controller */
  app.controller('PatientSearchMainCtrl', ['$scope', '$location', 'authSvc','patientTaskSvc', 'patientSearchSvc','$modal',
    function (scope, location,  authSvc, patientSvc, patientSearchSvc,$modal) {
    scope.model = {
      routeParams: {}
    };
    scope.user = authSvc.user();
    scope.isToOperator = 0;
    scope.sortBy = 'name';
    scope.sortType = 'ASC';
    scope.pageSize = 20;
    scope.pageIndex =1;
    scope.columnsSelected = [
      { field: 'Name',displayName: 'Name',columnClass: 'table-column-Name'},
      { field: 'MrnNumber', displayName: 'MRN',columnClass: 'table-column-MrnNumber'},
      { field: 'Age', displayName: 'Age', columnClass: 'table-column-Age' },
      { field: 'Gender', displayName: 'Gender', columnClass: 'table-column-Gender' },
      { field: 'Conditions', displayName: 'Conditions', columnClass: 'table-column-Conditions',sortable: false},
      { field: 'ManagedPopulations', displayName: 'Managed Pop.', columnClass: 'table-column-ManagedPopulations', sortable: false},
      { field: 'MissedOpportunities', displayName: 'Missed Opp.', columnClass: 'table-column-MissedOpportunities', sortable: false },
      { field: 'LastVisitDate', displayName: 'Last Visit', columnClass: 'table-column-LastVisitDate', sortable: false }
    ];
   
    scope.resetColumnData = function(status){
      _.map(scope.filterData, function(value, key){
        if(status){
          scope.filterData[key] = key.indexOf('selected') > -1 ? undefined : scope.filterData[key];
        }
        else{
          scope.filterData[key] = null;
        }
      });
    };
    scope.reset = function(reset){
      scope.leftSideFilterHeaders = patientSearchSvc.getPatientSearchStaticData();
      _.each(scope.leftSideFilterHeaders,function(item){
        item.isOpen = false;
        item.modalData = '';
        item.mainData = [];
        item.isShow = false;
        item.isBind = false;
        item.leftData = [];
        item.rightData = [];
        item.url = 'getPatient'+item.HeaderText.replace(/ /g, '')+'Filter';
        _.each(item.parms,function(val){
          item[val] = undefined;
        });
      });
      scope.resetColumnData();
      if(reset){
        scope.isToOperator = 0;
        scope.pageIndex = 1;
        scope.isSaveFilterdata =true;
        scope.bindGrid(scope.pageIndex);
      }
    };
    scope.reset();

    scope.isSaveFilterdata =true;
    scope.search = {
      dateFrom: { opened: false, value: null, format: 'YYYY-MM-DD'},
      dateTo: { opened: false, value: null, format: 'YYYY-MM-DD'}
    };

    scope.openDatePicker = function($event,item,name) {
      item = item === '' ? new Date() : item;
      $event.stopPropagation();
      $event.preventDefault();
      scope.search[name].opened = !scope.search[name].opened;
    };

    scope.filterData = {};
    scope.getAppliedFilterData = function(){
      patientSvc.getAppliedFilters(scope.user.providerId).then(function (response) {
        scope.filterData = response.data.results;
        _.each(scope.leftSideFilterHeaders,function(item){
          if(scope.filterData[item.dbColumn] && scope.filterData[item.dbColumn]!==null){
            if(scope.filterData[item.dbColumn].length === undefined){
              item.mainData.push(item.dbColumn === 'selectedProductType'?{Type:scope.filterData[item.dbColumn].productType,Name:scope.filterData[item.dbColumn].productName} : scope.filterData[item.dbColumn]);
              item.modalData = item.mainData[0][item.columnId];
            }
            else if(scope.filterData[item.dbColumn] !== null){
              item.rightData = scope.filterData[item.dbColumn];
              item.mainData = scope.filterData[item.dbColumn];
            }
            scope.isSaveFilterdata=false;
            item.isShow = true;
            item.isOpen = true;
          }
          else{
            _.each(item.parms,function(val){
              item[val]=scope.filterData[val];
              if(item[val] !== null){
                item.isShow = true;
                item.isOpen = true;
                scope.isSaveFilterdata = false;
              }
            });
            scope.isToOperator = (scope.filterData.ageTo === '' || scope.filterData.ageTo === null)? 0 : 1;
          }
        });
        scope.bindGrid(scope.pageIndex);
        scope.resetColumnData(true);
      });
    };

    scope.bindLeftSidefilterData = function(item){
      if(!item.isBind){
        patientSearchSvc[item.url]().then(function(response){
          item.isBind = true;
          if(!item.columnName){
            item.leftData = item.rightData.length > 0? response.data.results:[];
            item.rightData = item.rightData.length === 0? response.data.results:item.rightData;
            item.mainData = response.data.results;
            scope.bindNode(item);
          }
          else{
            item.mainData = response.data.results;
          }
        });
      }
    };

    scope.bindNode = function(item){
      scope.popup ={};
      if(item.isBind){
        scope.modalInstance = $modal.open({
          templateUrl: 'multiSelectPopup.html',
          scope: scope,
          backdrop: 'static',
          keyboard: false,
          action: 'show'
        });
        scope.popup ={popupName:item.HeaderText,selectedData:item.rightData,availableData:item.leftData,closeButtonText:'Cancel',actionButtonText:'Apply'};
      }else{
        scope.bindLeftSidefilterData(item);
      }
    };
    scope.popUpClose = function(){
      scope.modalInstance.close();
      scope.isError = false;
    };

    scope.deleteNode = function(data, item){
      item.rightData = _.without(item.rightData,data);
      item.leftData = item.leftData.concat(data);
      scope.filterData[item.selectedData]= item.isShow === true? (_.map(item.rightData,function(num){return num.id;}).join(',')) : null;
      scope.bindGrid(scope.pageIndex);
      scope.isSaveFilterdata = true;
    };
    scope.bindMultiSelectList = function(data){
      scope.isSaveFilterdata=true;
      _.each(scope.leftSideFilterHeaders,function(item){
        if(item.HeaderText === data.popupName){
          item.leftData = data.availableData;
          item.rightData = data.selectedData;
          item.isShow = item.rightData.length !== item.mainData.length?true:false;
          scope.filterData[item.selectedData]= item.isShow === true? (_.map(item.rightData,function(num){return num.id;}).join(',')) : null;
          return;
        }
      });
      scope.modalInstance.close();
      scope.bindGrid(scope.pageIndex);
    };

    scope.bindGrid = function(pageIndex){
      scope.filterData.providerId = scope.user.providerId;
      scope.filterData.isToOperator = scope.isToOperator;
      scope.filterData.pageIndex = pageIndex;
      scope.filterData.pageSize = scope.pageSize;
      scope.filterData.sortBy = scope.sortBy;
      scope.filterData.sortType = scope.sortType;
      patientSvc.getPatients(scope.filterData).success(function (data) {
        scope.patientGridData = data.results.MyPatients;
        scope.totalPatientCount = data.results.PatientCount;
        scope.isExport = scope.totalPatientCount > 0 ? false : true;
      });
    };
    scope.changedFilterData = function(data,header,column){
      scope.isSaveFilterdata = true;
      if(data.HeaderText !== header){
        scope.filterData[column] = (data[column]!== '' && data[column]!==null) ? (header.indexOf('Date')>-1? ((data[column] === undefined || data[column] === null) ? null : moment(data[column]).format('MM/DD/YYYY')) : data[column]):(header.indexOf('Age') > -1 ? 0 : null);
        if(header.indexOf('Date')>-1 && (data[column] !== undefined || data[column] !== null))
        {
          var minDate = moment('01/01/1753').format('MM/DD/YYYY');
          var maxDate = moment('12/31/9999').format('MM/DD/YYYY');
          
          // date is past
          if(moment(minDate).isAfter(scope.filterData[column]))
          {
            scope.filterData[column] = minDate;
          }
          else if(moment(scope.filterData[column]).isAfter(maxDate))
          {
            scope.filterData[column] = maxDate;
          }
        }
        scope.isToOperator = (scope.filterData.ageTo === '' ||  scope.filterData.ageTo === null) ? 0 : 1;
      }
      else{
        scope.filterData[data.selectedData] = (data.modalData !== null && data.modalData !== '') ? data.modalData: (data.HeaderText === 'Product Type' ? null: 0);
      }
      scope.bindGrid(scope.pageIndex);
    };
    scope.$watch('patientListSortingOptions', function (newVal, oldVal) {
      if (newVal !== oldVal) {
        scope.sortBy = newVal.field;
        scope.sortType = newVal.reverse === false ? 'ASC' : 'DESC';
        scope.bindGrid(scope.pageIndex);
      }
    }, true);
    scope.patientListSortingOptions={
      field: 'name',
      reverse: false
    };
    scope.saveFilterdata = function(){
      patientSvc.postAppliedFilters(scope.user.providerId,scope.filterData);
      scope.isSaveFilterdata = false;
    };
    scope.getAppliedFilterData();
  }]);
}(window.app));
