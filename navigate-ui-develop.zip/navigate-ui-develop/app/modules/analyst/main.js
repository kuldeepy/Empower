(function (app) {
  'use strict';

  /* module root controller */
  app.controller('analystMainCtrl', ['$scope',  function (scope) {
    scope.model = {
      routeParams: {}
    };

  }]);
}(window.app));