(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.controller('analystReportCtrl', ['$scope', '$sce', 'advancedAnalyticsSvc','$timeout','authSvc', function (scope, sce, advancedAnalyticsSvc,timeout,authSvc) {
      
      scope.notification = {
        visible: false,
        message: ''
      };

      scope.createTabclick = function () {
        scope.showcreateReport = false;
      };

      scope.daysLeftChangePassword =  authSvc.getLastChangedPasswordDays();
      scope.daysLeftChangePassword = scope.daysLeftChangePassword.toString();

      scope.createReport = function (reportname) {
        if(typeof reportname === 'undefined') {
          return;
        }
        var reportobj = { name: reportname,};
        var json = JSON.stringify(reportobj);
        advancedAnalyticsSvc.createReports(json).then(function (data) {
          scope.createreporturl = sce.trustAsResourceUrl(data.data.results.reportUrl);
          scope.showcreateReport = true;
          scope.notification = {
            visible: true,
            message: reportname + ' report created successfully'
          };
          timeout(function () {
            scope.notification.visible = false;
          }, 6000);

        });
      };

      scope.hideNotification = function() {
        scope.notification.visible = false;
      };

      scope.viewClick = function () {
        scope.showReport = false;
        scope.getDefaultFolder();
      };

      scope.vwNodeClick = function (viewdata) {
        if(viewdata.name !== 'Shared Folder'){
          scope.showReport = scope.showSpinner = true;
          scope.getReport(viewdata.id, viewdata.name);
        }
      };

      
      scope.getDefaultFolder = function () {

        var finalarry = []; // new Array
        var childNodes = [];
        var objroot = {
            name: 'Shared Folder',
            type: 'folder',
            id: '0'
          };
        advancedAnalyticsSvc.getReports().then(function(reports) {
          _.forEach(reports, function(item){
            childNodes.push(item);
          });
        });
        
        objroot.nodes = childNodes;
        
        finalarry.push(objroot);
        scope.tree = finalarry;
        scope.updatetree = finalarry;
        scope.vwtree = finalarry;

      };

      scope.getReport = function(reportId, reportName) {
        if (scope.reportInstanceId) {
          scope.closeReport(scope.reportInstanceId);
        }
        advancedAnalyticsSvc.getReport(reportId).then(function(report) {
          scope.reportInstanceId = report.reportInstanceId;
          scope.reportUrl = sce.trustAsResourceUrl(report.reportUrl);
          scope.showSpinner = false;
        });

        scope.reportName = reportName;
      };

      scope.closeReport = function(reportInstanceId) {
        advancedAnalyticsSvc.closeReport(reportInstanceId);
      };

      function getReports() {
        advancedAnalyticsSvc.getReports().then(function(reports) {
          scope.reportList = reports;
        });
      }

      getReports();

      scope.$on('$locationChangeStart', function() {
        if (scope.reportInstanceId) {
          scope.closeReport(scope.reportInstanceId);
        }
      });

      scope.title = 'Advanced Analytics';

    }]);

  }(window.app)
);