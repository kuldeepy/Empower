(function (app) {
  'use strict';

  app.controller('enrollmentCtrl', ['$scope', 'enrollmentSvc', '$http', '$filter', 'homeURL', '$location', '$modal', 'populationManagementSvc', 'iuiAlertService', '$state', 'adtNotificationSvc',
    function (scope, enrollmentSvc, http, $filter, homeURL, location, $modal, populationManagementSvc, alertService, state, adtNotificationSvc) {


      scope.enrollmentColumns = [{ field: 'patientName', displayName: 'Name'},
                                { field: 'programName', displayName: 'Managed Population'},
                                { field: 'qualifieddate', displayName: 'Date Qualified'},
                                { field: 'action', displayName: 'Action', columnClass: 'table-column-action', sortable: false}];

      scope.completedEnrollmentColumns = [{ field: 'patientName', displayName: 'Name'},
                                          { field: 'programName', displayName: 'Managed Population'},
                                          { field: 'qualifieddate', displayName: 'Date Qualified'},
                                          { field: 'completedDate', displayName: 'Completed Date'},
                                          { field: 'completedBy', displayName: 'Completed By'},
                                          { field: 'status', displayName: 'Status'},
                                          { field: 'reasonForDisenroll', displayName: 'Reason'}];
      
      scope.isOpen = true;
      scope.isDecline = false;
      scope.selectedDisenrollmentType = '';
      scope.isComment = false;
      scope.disEnrollReason = '';
      scope.openIndex  = scope.completeIndex = 1;
      alertService.add('alert_enroll', { type: 'error' });

      _.each(scope.stepDefinitions,function(item){
          _.each(item,function(newitem)
          {
            if(state.current.name === newitem.name)
            {
              scope.Currentpage = newitem.name;
            }
          });
        });

      if (scope.initializeStep) {
        scope.hideDeclined = true;
        if (state.current.name === scope.Currentpage) {
          scope.initializeStep(state.current.name,state.current.name === ('enrollmentSummary') ? true : false,'Enroll');
        }else{
          scope.initializeStep(state.current.name,false);
        }
        if(state.current.name === 'enrollmentPatientDetails' && scope.patientAccept === 'Y')
        {
          scope.completeStep(true, state.current.name);
          scope.isDecline = false;
        }
      }

      var modalInstance ={};

      scope.popupAction = function () {
        modalInstance = $modal.open({
          templateUrl: 'taskConfirmation.html',
          size: '',
          scope: scope,
          backdrop: 'static'
        });
      };

      scope.continueCancelAlert = function () {
        modalInstance.close(true);
        state.go('enrollmentSummary');
      };
      scope.closeCancelAlert = function () {
        modalInstance.close(true);
      };

      scope.getPatientAcceptance = function(val) {
        alertService.clear('alert_enroll');
        scope.patient.selectedDisenrollment.disenrollReason = undefined;
        if(val === 'Y') {
          scope.completeStep(true, state.current.name);
          scope.isDecline = false;
        }
        else
        {
          scope.isDecline = true;
          scope.completeStep(false, state.current.name);
          populationManagementSvc.getAlldisenrollmentReason().then(function (response) {
              scope.disenrollmentData = response.data.results;
            });
        }
        scope.updateData('patientAccept',val);
      };

      if(state.current.name === 'enrollmentTasks' && scope.groupedConflicts.length === 0)
      {
        enrollmentSvc.getManagedPopulationConflicts(scope.patient.patientId,scope.patient.programId).then(function (response) {
          var conflictsData =  _.groupBy(response.data.results,'typeName');
          _.forEach(conflictsData, function(item) {
            if(item.length > 1){
              var res = [];
              _.forEach(item, function(row){
                res.push({frequency: row.frequency,
                          frequencyNumber: row.frequencyNumber,
                          generalizedId: row.generalizedId,
                          programId: row.programId,
                          programName: row.programName,
                          programTaskBundleId: row.programTaskBundleId,
                          recurrenceType: row.recurrenceType,
                          taskType: row.taskType,
                          typeName: row.typeName,
                          taskDeleted: false,
                          taskBundleName:  row.taskBundleName,
                          frequencyTitration: row.taskType === 'Education Material' ? '' : ('Once every ' + row.frequencyNumber + (row.frequency === 'D' ? ' Day(s)' : (row.frequency === 'W' ? ' Week(s)' : ' Month(s)')))
                        });
              });
              scope.groupedConflicts.push(res);
            }
          });
        });
      }

      scope.$on('wizardOnNext', function() {
        if(state.current.name === 'enrollmentTasks')
        {
          taskConflicts();
        }
      });

      scope.$on('tabClick',function(event,name){
        if(name.name === 'enrollmentSummary')
        {
          taskConflicts();
        }
      });

      var taskConflicts = function() {
        scope.patient.resolvedConflicts = '';
        var conflict = [];
        _.forEach(scope.groupedConflicts, function(item) {
            var tasks = _.where(item, {taskDeleted: false, programId:scope.patient.programId});
            if(tasks.length > 0){
              conflict.push(tasks);
            }
            var deletedTasks = _.where(item, {taskDeleted: true, programId:scope.patient.programId});
            if(scope.patient.resolvedConflicts === '' && deletedTasks.length > 0) {
              scope.patient.resolvedConflicts = _.map(deletedTasks, function(item){ return item.programTaskBundleId; }).join(',');
            }
            else if(deletedTasks.length > 0) {
              scope.patient.resolvedConflicts = scope.patient.resolvedConflicts + ',' + _.map(deletedTasks, function(item){ return item.programTaskBundleId; }).join(',');
            }
          });
        if(conflict.length > 0)
        {
          state.go(state.current.name);
          scope.popupAction();
        }
      };

      scope.$on('wizardOnDecline', function() {
        alertService.clear('alert_enroll');
        if(scope.patient.selectedDisenrollment.disenrollReason !== undefined)
        {
          if(scope.patient.selectedDisenrollment.disenrollReason === 'Other' && scope.patient.disEnrollReason === '')
          {
            alertService.add('alert_enroll', {
              type: 'error',
              activeFor: 6000,
              message: 'Please Enter Disenroll Reason.'
            });
          }
          else
          {
            var patientPopulation = {
              'patientId' : scope.patient.patientId,
              'programId' : scope.patient.programId,
              'patientProgramId' : scope.patient.patientProgramId,
              'reason' : scope.patient.disEnrollReason,
              'reasonId' : scope.patient.selectedDisenrollment.disenrollReasonId,
              'status' : 'D',
              'patientEventId' : scope.patient.patientEventId
            };
            enrollmentSvc.disEnrollment(patientPopulation).then(function(){
              scope.getUnreadNotificationCount();
              scope.changeToWizard(false,0);
              location.path('/enrollments');
            });
          }
        }
        else
        {
          alertService.add('alert_enroll', {
              type: 'error',
              activeFor: 6000,
              message: 'Please select Reason for Disenrollment.'
            });
        }
      });

      scope.$watch('state.current.name', function () {
          if (state.current.name === 'enrollmentTasks') {
            scope.stepComplete(true);
          }
        });

      scope.$on('wizardOnsaveAndClose', function() {
        alertService.clear('alert_enroll');
        var patientPopulation = {
          'patientId' : scope.patient.patientId,
          'programId' : scope.patient.programId,
          'patientProgramId' : scope.patient.patientProgramId,
          'status' : 'E',
          'patientEventId' : scope.patient.patientEventId,
          'programTaskBundleId' : scope.patient.resolvedConflicts
        };
        enrollmentSvc.disEnrollment(patientPopulation).then(function(){
          scope.getUnreadNotificationCount();
          scope.changeToWizard(false,1);
          location.path('/enrollments');
        });
      });

      scope.$on('wizardOnClose', function () {
        scope.changeToWizard(false,-1);
        location.path('/enrollments');
      });

      scope.$watch('openEnrollSorting', function (newVal, oldVal) {
        if (newVal !== oldVal && scope.enrollmentData !== []) {
          scope.filter.sortBy = newVal.field;
          scope.filter.sortType = newVal.reverse === false ? 'ASC' : 'DESC';
          scope.filter.type = 'Open';
          enrollmentSvc.getEnrollments(scope.user.providerId,scope.filter).then(function(res){
            scope.enrollmentData = res.data.results.openEnrollments;
          });
        }
      }, true);

      scope.$watch('completeEnrollSorting', function (newVal, oldVal) {
        if (newVal !== oldVal && scope.completedEnrollmentData !== []) {
          scope.filter.sortBy = newVal.field;
          scope.filter.sortType = newVal.reverse === false ? 'ASC' : 'DESC';
          scope.filter.type = 'Complete';
          enrollmentSvc.getEnrollments(scope.user.providerId,scope.filter).then(function(res){
            scope.completedEnrollmentData = res.data.results.completedEnrollments;
          });
        }
      }, true);

      scope.$on('pageIndexChange', function (event, value, pageChanged) {
        if((value === 'Open' && scope.openIndex !== pageChanged) || (value === 'Complete' && scope.completeIndex !== pageChanged))
        {
          scope.filter.startIndex = pageChanged;
          scope.filter.type = value;
          switch(value){
          case 'Open':{
              scope.openIndex = pageChanged;
              enrollmentSvc.getEnrollments(scope.user.providerId,scope.filter).then(function(res){
                scope.enrollmentData = res.data.results.openEnrollments;
              });
              break;
            }
          case 'Complete':{
              scope.completeIndex = pageChanged;
              enrollmentSvc.getEnrollments(scope.user.providerId,scope.filter).then(function(res){
                scope.completedEnrollmentData = res.data.results.completedEnrollments;
              });
              break;
            }
          }
        }
      });

      scope.validateDisenrollmentType = function (value) {
        scope.isComment = false;
        scope.patient.disEnrollReason = scope.disEnrollReason = '';
        if(value !== undefined)
        {
          var conversionToJSONObj = JSON.parse(value);
          value = conversionToJSONObj;
        }
        if (value !== null) {
          if (value.disenrollReason === 'Other') {
            scope.isComment = true;
          } else {
            scope.isComment = false;
          }
          scope.patient.selectedDisenrollment = value;
        }
      };

      scope.getUnreadNotificationCount = function () {
        var filters = {'status':'Pending','pageSize': 5,'pageIndex': 1,'processType':'F'};
        adtNotificationSvc.getNotificationsRequest(filters,scope.user.providerId).then(function(response){
          response.data.results.notification =_.forEach(response.data.results.notification,function(item){
            item.color ='info';
            item.img = 'General-icon_check_cccccc_30x30';
            item.eventDate = moment(item.eventDate).fromNow();
          });
          scope.adtNotification.adtNotificationData = response.data.results.notification;
          scope.adtNotification.unreadCount = response.data.results.count;
          scope.adtNotification.totalElements= response.data.results.count;
          scope.adtNotification.dataChunkSize=5;
          scope.adtNotification.dataChunkIndex=1;
        });
      };
    }]);
}(window.app));