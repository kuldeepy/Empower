(function (app) {
  'use strict';
  
  app.controller('patientEnrollmentCtrl', ['$scope',
      function (scope) {
      scope.wizardWorkflow = [
        { 'id': 1, 'name': 'enrollmentPatientDetails' },
        { 'id': 2, 'name': 'enrollmentTasks' },
        { 'id': 3, 'name': 'enrollmentSummary' }
      ];

      //Tab and Step Definitions
      scope.tabDefinitions = [
        { name: 'enrollmentPatientDetails', number: '1', title: 'Patient Details and Acceptance', selectionCss: 'first active', completed: false, clickable:false, isTabCompleted:false },
        { name: 'enrollmentTasks', number: '2', title: 'Task(s)', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false },
        { name: 'enrollmentSummary', number: '3', title: 'Summary', selectionCss: 'inactive', completed: false, clickable:false, isTabCompleted:false }
      ];
          
      scope.stepDefinitions = [
        [
          { name: 'enrollmentPatientDetails', letter: 'a', title: 'Patient Details and Acceptance', selectionCss: 'active', completed: false, clickable:false, isTabCompleted:false  },
        ],

        [
          { name: 'enrollmentTasks', letter: 'a', title: 'Task Conflicts', selectionCss: 'active', completed: false, allowStepNavigation: true, clickable:false, isTabCompleted:false  },
        ],

        [
          { name: 'enrollmentSummary', letter: 'a', title: '', selectionCss: 'active', completed: false, allowStepNavigation: true }
        ]
        
      ];
    }]);

})(window.app);
