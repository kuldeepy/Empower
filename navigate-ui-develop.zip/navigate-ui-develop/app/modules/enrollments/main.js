(function (app) {
  'use strict';
  app.controller('enrollmentsMainCtrl', ['$scope', '$modal', 'authSvc', 'httpRequestSvc', 'careTeamSvc', '$filter', 'enrollmentSvc', '$location', '$state', 'iuiAlertService',
    function (scope, modal, authSvc, httpRequestSvc, careTeamSvc, $filter, enrollmentSvc, location, state, alertService) {
      scope.isShow = false;
      scope.careLeadDefault = [];
      scope.groupedConflicts = [];
      scope.taskConflictsCount = 0;
      scope.page = 1;
      scope.pageSize = 10;
      scope.filter = {
        startIndex : 1,
        endIndex : 10,
        type : null,
        sortBy : null,
        sortType : null,
        managedPopulations : '',
        careTeams : '',
        careLeads : '',
        careManagers : '',
        pcps : ''
      };
      scope.patientAccept = '';
      scope.patient = {
        patientId : '',
        programId : '',
        programName : '',
        patientProgramId : '',
        patientDemographics : {},
        tasks : [],
        nonConflictTasks : [],
        conflictTasks : [],
        selectedDisenrollment : {},
        disEnrollReason : '',
        patientEventId : '',
        resolvedConflicts : ''
      };
      scope.disEnrollReason = '';
      scope.actionTitle = 'Enrollments';
      alertService.add('alert_isSucessEnroll', { type: 'success' });

      scope.changeToWizard = function(val,isMessage) {
        scope.groupedConflicts = [];
        var sucessMessage = '';
        alertService.clear('alert_isSucessEnroll');
        scope.isShow = val;
        var patientName = (scope.patient.patientDemographics.firstName !== null ? scope.patient.patientDemographics.firstName : '') +' '+(scope.patient.patientDemographics.middleName !== null ? scope.patient.patientDemographics.middleName : '') +' '+(scope.patient.patientDemographics.lastName !== null ? scope.patient.patientDemographics.lastName : '');
        if(!scope.isShow) { scope.resetFilters(); }
        if(isMessage === 0) { sucessMessage = patientName + ' is been declined of ' + scope.patient.programName; }
        else if(isMessage === 1) { sucessMessage = patientName + ' is successfully enrolled into ' + scope.patient.programName; }
        if(sucessMessage !== '') {
          alertService.add('alert_isSucessEnroll', {
            type: 'success',
            activeFor: 6000,
            message: sucessMessage
          });
        }
      };

      scope.user = authSvc.user();

      var filterOut = function(original, toFilter) {
        var filtered = [];
        angular.forEach(original, function(entity) {
          var match = false;
          for(var i = 0; i < toFilter.length; i = i+1) {
            if(toFilter[i].id === entity.id) {
              match = true;
              break;
            }
          }
          if(!match) {
            filtered.push(entity);
          }
        });
        return filtered;
      };

      var assignPCPAsFirstParameter = function(data){
        var searchValue = _.findWhere(data, {name: 'No PCP Assigned'});
        var index = _.findIndex(data, searchValue);
        data[index].name = ' ' + data[index].name;
        return data;
      };

      scope.openFilterPopUp = function(item) {
        scope.popUpData = {};
        if(item.isInitial)
        {
          var URL = item.url;
          item.isInitial = false;
          httpRequestSvc.getRequest(URL).then(function (result) {
            item.rightSideData = item.modelData;
            item.data = (item.headerText === 'PCP') ? assignPCPAsFirstParameter(modifyParameterName(result.data.results, item.headerText)) : modifyParameterName(result.data.results, item.headerText);
            if(item.rightSideData.length === 0) {
              item.rightSideData = item.data;
            }
            else{
              item.leftSideData = filterOut((item.headerText === 'PCP') ? assignPCPAsFirstParameter(modifyParameterName(result.data.results, item.headerText)) : modifyParameterName(result.data.results, item.headerText), item.rightSideData);
            }
            openPopUpModal(item);
          });
        }
        else
        {
          if(item.modelData.length === 0) {
            item.rightSideData = item.data;
          }
          else{
            item.rightSideData = item.modelData;
            item.leftSideData = filterOut(item.data, item.rightSideData);
          }
          openPopUpModal(item);
        }
      };

      var openPopUpModal = function(item){
        scope.popUpData = item;
        scope.modalPopUp = modal.open({
          templateUrl: 'myModalContent.html',
          scope: scope,
          size: 'lg'
        });
      };

      var modifyParameterName = function(data, type){
        var modifiedData = [];
        switch (type) {
          case 'Managed Population':
            data = _.without(data,_.findWhere(data,{managedPopulationName:'All Patients Managed population'}));
            modifiedData = _.map(data, function (item) {
              return {
                id: item.managedPopulationId,
                name: item.managedPopulationName
              };
            });
            break;
          case 'Care Team':
            modifiedData = _.map(data, function (item) {
              return {
                id: item.careTeamId,
                name: item.careTeamName
              };
            });
            break;
          case 'Care Leads':
          case 'Care Manager':
            modifiedData = _.uniq(_.map(data, function (item) {
              return {
                id: item.userId,
                name: item.firstName + ' ' + item.lastName
              };
            }), 'id');
            break;
          case 'PCP':
            modifiedData = _.map(data, function (item) {
              return {
                id: item.id,
                name: $filter('isNull')(item.lastName) === '' ? $filter('isNull')(item.firstName) : item.lastName + (($filter('isNull')(item.firstName) !== '') ? ',' : '') + ' ' + $filter('isNull')(item.firstName)
              };
            });
            break;
        }
        return modifiedData;
      };

      scope.deleteNode = function(item, headerText){
        _.forEach(scope.leftMenuData, function(row) {
          if(row.headerText === headerText) {
            row.modelData = row.rightSideData = _.without(row.rightSideData,item);
            row.leftSideData.push(item);
            row.isAllStatus = (row.data.length === row.rightSideData.length) ? true : false;
            bindFilters();
          }
        });
      };

      scope.closeModal = function(){ scope.modalPopUp.close(); };

      var validatePCPToTop = function(data){
        var item = _.findWhere(data, {name: ' No PCP Assigned'});
        if(item){
          var element = data[data.indexOf(item)];
          data.splice(data.indexOf(item), 1);
          data.splice(0, 0, element);
        }
        return data;
      };

      scope.applyFilter = function(item, type){
        _.forEach(scope.leftMenuData, function(row) {
          if(row.headerText === type)
          {
            item.isAllStatus = (item.data.length === item.rightSideData.length) ? true : false;
            item.modelData = item.headerText === 'PCP' ? validatePCPToTop(item.rightSideData) : item.rightSideData;
          }
        });
        scope.modalPopUp.close();
        bindFilters();
      };

      var bindFilters = function() {
        scope.openIndex  = scope.completeIndex = scope.page = 1;
        scope.pageSize = 10;
        scope.filter.startIndex = 1;
        scope.filter.endIndex = 10;
        scope.filter.type = scope.filter.sortBy = scope.filter.sortType = null;
        scope.filter.managedPopulations = validingSelection(_.where(scope.leftMenuData,{headerText:'Managed Population'})[0]);
        scope.filter.careTeams = validingSelection(_.where(scope.leftMenuData,{headerText:'Care Team'})[0]);
        scope.filter.careLeads = validingSelection(_.where(scope.leftMenuData,{headerText:'Care Leads'})[0]);
        scope.filter.careManagers = validingSelection(_.where(scope.leftMenuData,{headerText:'Care Manager'})[0]);
        scope.filter.pcps = validingSelection(_.where(scope.leftMenuData,{headerText:'PCP'})[0]);
        scope.enrollment();
      };

      var validingSelection = function(data){
        var result = !data.isAllStatus ? ((data.rightSideData.length > 0) ? _.map(data.rightSideData, function(item){ return item.id; }).join(',') : '') : '';
        return result;
      };
      
      scope.resetFilters = function(){
        scope.openIndex  = scope.completeIndex = scope.page = 1;
        scope.pageSize = 10;
        scope.completeEnrollSorting = {
          field: 'qualifieddate',
          reverse: true
        };
        scope.openEnrollSorting = {
          field: 'qualifieddate',
          reverse: true
        };
        scope.leftMenuData = [
          {
            headerText: 'Managed Population',
            isOpen: false,
            filterText: 'Managed Populations',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/managed-populations',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'Care Team',
            isOpen: false,
            filterText: 'Care Teams',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/care-teams?managedPopulationIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'Care Leads',
            isOpen: false,
            filterText: 'Care Leads',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/care-team-members?careTeamIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'Care Manager',
            isOpen: false,
            filterText: 'Care Managers',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/care-team-members?careTeamIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          },
          {
            headerText: 'PCP',
            isOpen: false,
            filterText: 'PCP',
            isAllStatus: true,
            isInitial: true,
            url: 'providers/' + scope.user.providerId + '/primary-care-physicians?managedPopulationIds=',
            data: [],
            modelData: [],
            leftSideData: [],
            rightSideData: []
          }
        ];
        scope.filter = {
          startIndex : 1,
          endIndex : 10,
          type : null,
          sortBy : null,
          sortType : null,
          managedPopulations : '',
          careTeams : '',
          careLeads : '',
          careManagers : '',
          pcps : ''
        };
        scope.patientAccept = '';
        if(scope.careLeadDefault.length === 0)
        {
          httpRequestSvc.getRequest('providers/' + scope.user.providerId + '/care-team-members?careTeamIds=').then(function (result) {
            var item = _.findWhere(result.data.results, {userId: parseInt(scope.user.providerId)});
            scope.careLeadDefault = [{'userId':item.userId,'name' : item.firstName + ' ' + item.lastName}];
            _.forEach(scope.leftMenuData, function(row) {
              if(scope.careLeadDefault.length > 0 && row.headerText === 'Care Leads'){
                row = generatingSavedData(scope.careLeadDefault, row);
              }
            });
            scope.filter.careLeads = validingSelection(_.where(scope.leftMenuData,{headerText:'Care Leads'})[0]);
            scope.enrollment();
          });
        }
        else
        {
          _.forEach(scope.leftMenuData, function(row) {
              if(scope.careLeadDefault.length > 0 && row.headerText === 'Care Leads'){
                row = generatingSavedData(scope.careLeadDefault, row);
              }
            });
          scope.filter.careLeads = validingSelection(_.where(scope.leftMenuData,{headerText:'Care Leads'})[0]);
          scope.enrollment();
        }
      };

      var generatingSavedData = function(filteredData, item){
        item.rightSideData = [];
        _.forEach(filteredData, function(row) {
          item.rightSideData.push(row);
          item.isAllStatus = (item.data.length === item.rightSideData.length) ? true : false;
          item.isOpen = item.rightSideData.length > 0 ? true : false;
        });
        var modifiedData = [];
        if(item.headerText === 'Care Leads'){
          modifiedData = [];
          _.forEach(filteredData, function(res) {
            modifiedData.push({id: res.userId, name: res.name});
          });
          item.rightSideData = modifiedData;
        }
        item.modelData = item.rightSideData;
        return item;
      };

      scope.init = function(){
        scope.resetFilters();
      };

      scope.patientEnrollment = function(val) {
        scope.actionTitle = 'Enrollments - ' + val.programName;
        scope.patient.programName = val.programName;
        scope.patient.patientId = val.patientId;
        scope.patient.programId = val.programId;
        scope.patient.patientProgramId = val.patientProgramId;
        scope.patient.patientEventId = '';
        enrollmentSvc.getPatientDetails(scope.patient.patientId).then(function(res){
          scope.patient.patientDemographics = res.data.results;
        });
        scope.changeToWizard(true,-1);
        location.path(app.currentRoute+'/enrollmentpatientdetails');
        state.go('enrollmentPatientDetails');
      };

      scope.enrollment = function() {
          enrollmentSvc.getEnrollments(scope.user.providerId,scope.filter).then(function(res){
            scope.completedEnrollmentData = res.data.results.completedEnrollments;
            scope.completedCount = res.data.results.totalCompletedEnrollments;
            scope.enrollmentData = res.data.results.openEnrollments;
            scope.openCount = res.data.results.totalOpenEnrollments;
          });
        };

      scope.updateData = function(val, data){
        switch(val)
        {
          case 'patientAccept':
            scope.patientAccept = data;
            break;
        }
      };

      if(localStorage.getItem('enrollmentData') !== null)
      {
        var value = JSON.parse(localStorage.getItem('enrollmentData'));
        scope.actionTitle = 'Enrollments - ' + value.programName;
        scope.patient.programName = value.programName;
        scope.patient.patientId = value.patientId;
        scope.patient.programId = value.programId;
        scope.patient.patientProgramId = value.patientProgramID;
        scope.patient.patientEventId = value.patientEventId;
        localStorage.removeItem('enrollmentData');
        enrollmentSvc.getPatientDetails(scope.patient.patientId).then(function(res){
          scope.patient.patientDemographics = res.data.results;
        });
        scope.changeToWizard(true,-1);
        location.path(app.currentRoute+'/enrollmentpatientdetails');
        state.go('enrollmentPatientDetails');
      }
    }
  ]);
}(window.app));