﻿(function (app) {
  'use strict';

  app.controller('MessageCenterCtrl', ['$scope', 'modalService', '$location', '$http', '$q', 'authSvc', function (scope, modalService, location, http, q, authSvc) {
    scope.messageGridData = [];
    scope.columnsSelected = [];
    scope.searchGrid = [];
    scope.selectedFiles = [];
    scope.providers = [];
    scope.masterProviders = [];
    scope.careTeams = [];
    scope.readMethod = 'readAsDataURL';
    scope.user = authSvc.user();
    scope.isAdmin = false;
    scope.totalServerItems = 0;
    scope.pagingOptions = {
      pageSizes: [5, 10, 15],
      pageSize: 10,
      currentPage: 1
    };
    scope.attachFiles = [];
    scope.totalPatientCount = 0;

    scope.gridOptions = {
      data: 'gridData',
      multiSelect: false,
      rowHeight: 45,
      showFooter: true,
      enablePaging: true,
      totalServerItems: 'totalServerItems',
      sortInfo: { fields: ['dateSent','dateReceived'], directions: ['desc','desc']},
      pagingOptions: scope.pagingOptions,
      filterOptions: scope.filterOptions,
      columnDefs: 'columnsSelected'
    };

    var getCareCommunity = function () {
        q.all([
          http.get(app.api.root + 'user-providers'),
          http.get(app.api.root + 'care-team-members')
        ]).then(function (responses) {
            scope.providers = responses[0].data.results;
            scope.masterProviders = responses[0].data.results;
            scope.careTeams = responses[1].data.results.members;
            if (scope.moduleData.folderName === 'draft' && scope.headerText !== 'New Message') {
              scope.getProvidersAndCareMembers('draft');
            }
          });
      };

    /* function to reset controlls */
    scope.resetControls = function (isInbox, isViewMessage, isNewMessage) {
      scope.moduleData.isInbox = isInbox;
      scope.moduleData.isViewMessage = isViewMessage;
      scope.moduleData.isNewMessage = isNewMessage;
    };

    /* function to reset new message fields */
    scope.resetNewMessageFields = function () {
      scope.moduleData.isReply = false;
      scope.moduleData.isReplyAll = false;
      scope.moduleData.isForward = false;
      scope.moduleData.isArchive = false;
      scope.messageData.from = '';
      scope.messageData.fromId = 0;
      scope.messageData.to = '';
      scope.messageData.subject = '';
      scope.messageData.sentDate = '';
      scope.messageData.content = '';
      scope.messageData.patientName = '';
      scope.messageData.attachedFiles = [];
      scope.messageData.selectdProviderNames = '';
      scope.messageData.selectdMemberNames = '';
      scope.moduleData.isDraft = false;
      scope.messageData.messageId = 0;
      scope.messageData.patientUserId = 0;
      scope.messageData.providers = [];
      scope.messageData.careTeams = [];
    };

    /* attach selected files comming from db.*/
    /* used in forward and draft messages */
    scope.attachSelectedFiles = function () {
      angular.forEach(scope.messageData.attachedFiles, function (file) {
        var ref = {
          name: file.name + file.extension,
          size: file.fileSize,
          type: file.mimeType
        },
        content = 'data:' + file.mimeType + ';base64,' + file.content;
        scope.selectedFiles.push({ 'ref': ref, 'content': content });
      });
    };

    /* function to send new message */
    scope.newMessage = function (message) {
      if (angular.lowercase(scope.user.role) === 'administrator' || angular.lowercase(scope.user.role) === 'analyst' || angular.lowercase(scope.user.role) === 'clinic administrator' || angular.lowercase(scope.user.role) === 'physician' || angular.lowercase(scope.user.role) === 'insurance group provider') {
        scope.isAdmin = true;
      }
      scope.getCareCommunity = getCareCommunity();
      if (message === 'New Message') {
        scope.resetNewMessageFields();
      }

      scope.resetControls(false, false, true);

      var buildContent = '<div></div><div></div><div></div><div><hr></hr></div><div><span>Original Message Details</span></div>' +
          '<div><span>Sent: ' + scope.messageData.sentDate + '</span></div>' +
          '<div><span>From: ' + scope.messageData.from + '</span></div>' +
          '<div><span>To: ' + scope.messageData.to + '</span></div>' +
          '<div><span>Subject: ' + scope.messageData.subject + '</span></div><div></div>';

      if (scope.moduleData.isReply === true || scope.moduleData.isReplyAll === true) {
        scope.headerText = 'Reply Message';
        scope.messageData.messageId = null;
        scope.messageData.subject = 'Re: ' + scope.messageData.subject;
        scope.messageData.content = buildContent + scope.messageData.content;
      } else if (scope.moduleData.isForward === true) {
        scope.headerText = 'Forward Message';
        scope.messageData.messageId = null;
        scope.messageData.from = '';
        scope.messageData.to = '';
        scope.messageData.selectdProviderNames = '';
        scope.messageData.selectdMemberNames = '';
        scope.messageData.providers = [];
        scope.messageData.careTeams = [];
        scope.messageData.careTeamRecipients = [];
        scope.messageData.providerRecipients = [];
        scope.messageData.subject = 'Fw: ' + scope.messageData.subject;
        scope.messageData.content = buildContent + scope.messageData.content;
        scope.attachSelectedFiles();
      } else if (scope.moduleData.isDraft === true) {
        scope.headerText = 'Draft Message';
        scope.messageData.content = '';
        scope.messageData.content = scope.messageData.draftContent;
        scope.attachSelectedFiles();
      } else {
        scope.headerText = 'New Message';
      }

      location.path('/message/new-message');
    };

    /* function to bind new message screen */
    scope.bindNewMessage = function () {
      scope.newMessage();

    };

    /* build grid columns for inbox and archive */
    scope.inboxAndArchievsColumns = function () {
      scope.columnsSelected = [
        {
          field: 'from',
          displayName: 'From',
          columnClass: 'table-column-name'
        },
        {
          field: 'subject',
          displayName: 'Subject',
          columnClass: 'table-column-msg-name'
        },
        {
          field: 'patientName',
          displayName: 'Patient Name',
          columnClass: 'table-column-msg-name'
        },
        {
          field: 'dateReceived',
          displayName: (scope.moduleData.folderName === 'inbox') ? 'Date Received' : 'Date Archived',
          columnClass: 'table-column-name'
        },
        {
          field: 'isAttachment',
          displayName: '',
          headerCellTemplate: '/modules/message-center/templates/attachment-cell.html',
          columnClass: 'table-column-action'
        }
      ];
    };

    /* build grid columns for sent and drafts */
    scope.sentAndDraftsColumns = function () {
      scope.columnsSelected = [
        {
          field: 'to',
          displayName: 'To',
          columnClass: 'table-column-sentmsg-name'
        },
        {
          field: 'subject',
          displayName: 'Subject',
          columnClass: 'table-column-sentmsg-name'
        },
        {
          field: 'patientName',
          displayName: 'Patient Name',
          columnClass: 'table-column-sentmsg-name'
        },
        {
          field: 'dateSent',
          displayName: (scope.moduleData.folderName === 'sent') ? 'Date Sent' : 'Date Saved',
          columnClass: 'table-column-date'
        },
        {
          field: 'isAttachment',
          displayName: '',
          headerCellTemplate: '/modules/message-center/templates/attachment-cell.html',
          columnClass: 'table-column-action'
        }
      ];
    };

    /* initial function executed for inbox screen */
    scope.inboxInitialize = function (messageStatus) {
      scope.redirectHomePage();
      scope.moduleData.folderName = 'inbox';
      if(scope.$parent && scope.$parent.$parent && scope.$parent.$parent.stateOfMsgBox){
        scope.$parent.$parent.stateOfMsgBox = 'inbox';
      }
      scope.bindGrid();
      scope.inboxAndArchievsColumns();
      scope.getUnreadCount();
      if(messageStatus !== true){
        scope.resetControls(true, false, false);
      }
    };

      /*function for redirect to home page */
    scope.redirectHomePage = function () {
      switch(angular.lowercase(scope.user.role)){
        case 'administrator' :
          scope.user.backURL = 'admin';
          break;
        case 'care manager' :
          scope.user.backURL = 'caremanager';
          break;
        case 'analyst' :
          scope.user.backURL = 'analyst';
          break;
        case 'clinic administrator' :
          scope.user.backURL = 'clinicAdmin';
          break;
        case 'physician' :
          scope.user.backURL = 'physicians';
          break;
        case 'insurance group provider' :
          scope.user.backURL = 'insurance';
          break;
      }
    };

    /* initial function executed for archive screen */
    scope.archiveInitialize = function () {
      scope.redirectHomePage();
      scope.moduleData.folderName = 'archived';
      if(scope.$parent && scope.$parent.$parent && scope.$parent.$parent.stateOfMsgBox){
        scope.$parent.$parent.stateOfMsgBox = 'archived';
      }
      scope.bindGrid();
      scope.inboxAndArchievsColumns();
      scope.resetControls(true, false, false);
    };

    /* initial function executed for sent screen */
    scope.sentInitialize = function () {
      scope.redirectHomePage();
      scope.moduleData.folderName = 'sent';
      if(scope.$parent && scope.$parent.$parent && scope.$parent.$parent.stateOfMsgBox){
        scope.$parent.$parent.stateOfMsgBox = 'sent';
      }
      scope.bindGrid();
      scope.sentAndDraftsColumns();
      scope.resetControls(true, false, false);
    };

    /* initial function executed for draft screen */
    scope.draftInitialize = function () {
      scope.redirectHomePage();
      scope.moduleData.folderName = 'draft';
      if(scope.$parent && scope.$parent.$parent && scope.$parent.$parent.stateOfMsgBox){
        scope.$parent.$parent.stateOfMsgBox = 'draft';
      }
      scope.moduleData.isDraft = true;
      scope.bindGrid();
      scope.sentAndDraftsColumns();
      scope.resetControls(true, false, false);
    };

    scope.modalOpenPatientSearch = function () {

      if (scope.moduleData.isReply === true || scope.moduleData.isReplyAll === true || scope.moduleData.isForward === true) {
        return;
      }

      var modalOptions = {
        closeButtonText: 'Cancel',
        actionButtonText: 'Search',
        resetButtonText: 'Clear',
        headerText: 'Patient Search',
        bodyText: '',
        populations: null,
        selectedPopulations: null
      };
      var modalDefaults = {
        'templateUrl': app.root + 'templates/modalMessagePatientSearch.html',
        'size': 'lg'
      };

      modalDefaults.controller = function ($scope, $modalInstance) {
        $scope.patientSearchGrid = scope.patientSearchGrid;
        var tempModalOptions = {};
        angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
        $scope.modalOptions = tempModalOptions;
        $scope.patientSearchUrl = '';
        $scope.pageIndex = 1;
        $scope.pageSize = 10;
        //$scope.roles = roles; $scope.user = user;

        /* variable declarations */
        $scope.patientSearchData = {
          userType : 'true',
          lastName : '',
          firstName : '',
          phoneNumber : '',
          city : '',
          emailAddress : '',
          state : '',
          zipCode : '',
          status : 'A',
          gender : 'Either',
          memberId : '',
          ageFrom : '',
          ageTo : '',
        };

        //$filterPaginations
        scope.filterPaginations = {
          pageSizes: [5, 10, 15],
          pageSize: 10,
          currentPage: 1
        };

        $scope.patientSearchGrid = {
          data: 'gridPatientData',
          multiSelect: false,
          showFooter: true,
          enablePaging: true,
          rowHeight: 40,
          totalServerItems: 'totalServerItems',
          pagingOptions: scope.filterPaginations,
          filterOptions: scope.filterOption,
          columnDefs: [
            { field: 'userId', displayName: 'id', visible: false },
            { field: 'lastName', displayName: 'Last Name', width: '20%' },
            { field: 'firstName', displayName: 'First Name' },
            { field: 'email', displayName: 'Email', cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">' +
                '<span data-toggle="tooltip" data-placement="top" title="{{row.getProperty(col.field)}}" data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field)}}</span>' +
                '</div>'
            },
            { field: 'address', displayName: 'Address', cellTemplate: '<div class="ngCellText" ng-class="col.colIndex()">' +
                  '<span data-toggle="tooltip" data-placement="top" title="{{row.getProperty(col.field)}}" data="{{row.getProperty(col.headerClass)}}">{{row.getProperty(col.field)}}</span>' +
                  '</div>'
            },
            { field: '', displayName: 'Action', width: '50px',
              cellTemplate: '<div class="ngCellText ngCellIcon">' +
                '<button class="btn no-btn" type="button" ng-click="addPatient(row.entity);">'+
                '<span class="General-icon_add_6fa8dc_30x30"></span>' + '</button>' +
                '</div>'
            }
          ]
        };

        $scope.addPatient = function (row) {
          scope.messageData.patientName = row.fullName;
          scope.messageData.patientUserId = row.userId;
          $modalInstance.dismiss('cancel');
        };

        $scope.getPatientSearchUrl = function () {
            var genderUrl = '';
            if($scope.patientSearchData.gender === 'Either')
            {
              genderUrl = '';
            }
            else
            {
              genderUrl = $scope.patientSearchData.gender;
            }
            
            $scope.patientSearchUrl = 'members?' +
            'isPatient=' + $scope.patientSearchData.userType +
            '&lastName=' + $scope.patientSearchData.lastName +
            '&firstName=' + $scope.patientSearchData.firstName +
            '&city=' + $scope.patientSearchData.city +
            '&state=' + $scope.patientSearchData.state +
            '&zipCode=' + $scope.patientSearchData.zipCode +
            '&status=' + $scope.patientSearchData.status  +
            '&memberId=' + $scope.patientSearchData.memberId +
            '&phone=' + $scope.patientSearchData.phoneNumber +
            '&email=' + $scope.patientSearchData.emailAddress +
            '&gender=' + genderUrl +
            '&minAge=' + ( ($.trim($scope.patientSearchData.ageFrom).length <= 0) ? '0' : $scope.patientSearchData.ageFrom) +
            '&maxAge=' + ( ($.trim($scope.patientSearchData.ageTo).length <= 0) ? '0' : $scope.patientSearchData.ageTo);
          };

          
        $scope.getPatientSearch = function () {
            var getUrl = '';
            

            if($scope.patientSearchUrl !== '')
            {
              getUrl = app.api.root + $scope.patientSearchUrl + '&pageIndex='+$scope.pageIndex+'&pageSize='+$scope.pageSize;
              http({
                method: 'GET',
                url: getUrl
              })
              .success(function (data) {
                $scope.gridPatientData = data.results.members;
                $scope.totalServerItems = data.results.totalCount;
                scope.setPatientSearchPaging($scope.gridPatientData);
              });
            }
          };

        scope.$watch('filterPaginations', function (newVal, oldVal) {
          var pageSizeCount = parseInt(scope.filterPaginations.pageSize);

          if (newVal !== oldVal) {
            scope.filterPaginations.currentPage = (newVal.currentPage === undefined || newVal.currentPage === null) ? 1 : scope.filterPaginations.currentPage;
            $scope.pageIndex = (newVal.currentPage === undefined || newVal.currentPage === null) ? 1 : newVal.currentPage;
            $scope.pageSize = pageSizeCount;
            $scope.getPatientSearch();
          }


        }, true);

        $scope.modalOptions.search = function () {
          $scope.getPatientSearchUrl();
          $scope.getPatientSearch();
          
          //NOT NEEDED WAS RENDERING CONTROLER UNUSABLE
          /*var tempModalOptions = {};
          angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
          $scope.modalOptions = tempModalOptions;*/

          //TO write srach call here
          //$modalInstance.close();
        };
        $scope.modalOptions.phoneInput = function()
        {
          if($scope.patientSearchData.phoneNumber === '')
          {
            $scope.patientSearchForm.phone.$setPristine();
            $scope.patientSearchData.phoneNumber = undefined;
          }
        };

        $scope.modalOptions.reset = function () {
            scope.filterPaginations.currentPage =1;
            $scope.patientSearchUrl ='';
            $scope.patientSearchForm.$setPristine();
            $scope.patientSearchData.userType = 'true';
            $scope.patientSearchData.lastName = '';
            $scope.patientSearchData.firstName = '';
            $scope.patientSearchData.phoneNumber = '';
            $scope.patientSearchData.city = '';
            $scope.patientSearchData.emailAddress = '';
            $scope.patientSearchData.state = '';
            $scope.patientSearchData.zipCode = '';
            $scope.patientSearchData.gender = 'Either';
            $scope.patientSearchData.memberId = '';
            $scope.patientSearchData.ageFrom = '';
            $scope.patientSearchData.ageTo = '';
            $scope.gridPatientData = null;
            $scope.totalServerItems = 0;
            scope.setPatientSearchPaging($scope.gridPatientData);
          };
        $scope.modalOptions.close = function () {
          $modalInstance.dismiss('cancel');
        };
      };

      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);

      modalService.showModal(modalDefaults, modalOptions);

    };

    scope.setPatientSearchPaging = function (data) {
      /*scope.patientList = [];*/
      if (data !== undefined) {
        scope.gridPatientData = data;
      }
      if (scope.totalPatientCount !== undefined) {
        //scope.totalServerItems = countData.results.totalCount;
      }
      else {
        scope.totalServerItems = 0;
        scope.totalPatientCount = 0;
      }
      if (!scope.$$phase) {
        scope.$apply();
      }
    };

    scope.modalOpenSelectProvider = function (selectedProvider) {

      var modalOptions = {
        closeButtonText: 'Cancel',
        actionButtonText: 'Save',
        headerText: 'Select Providers',
        bodyText: '',
        populations: null,
        selectedPopulations: null,
        ProviderSearchClose: true
      };
      var modalDefaults = {
        'templateUrl': app.root + 'templates/modalMessagesSelectProvider.html'
      };

      if(!selectedProvider || (!Array.isArray(selectedProvider))) {
        selectedProvider = [];
      }

      modalDefaults.controller = function ($scope, $modalInstance) {
        var tempModalOptions = {};
        //Map modal.html $scope custom properties to defaults defined in service
        angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
        $scope.modalOptions = tempModalOptions;
        $scope.timeInMs = 0;
        $scope.modalOptions.providerSearchClose = true;

        $scope.modalOptions.ok = function (result) {
          $scope.timeInMs = 0;
          scope.messageData.providers = result;
          scope.messageData.selectdProviderNames = result.map(function (node) {
            return node.providerName;
          }).join();
          scope.messageData.providerRecipients = result.map(function (node) {
            return { 'userId': node.id, 'isProvider': true };
          });
          $modalInstance.close();
        };
        $scope.modalOptions.close = function () {
          $scope.timeInMs = 0;
          $modalInstance.dismiss('cancel');
        };
        $scope.modalOptions.disableProviderSearch = function () {
          $scope.modalOptions.providerSearchClose = false;
          $scope.modalOptions.searchProviders = '';
          $scope.modalOptions.providers = $scope.modalOptions.copyProviders;
          $scope.timeInMs = 0;
        };
        $scope.modalOptions.filterProviders = function () {
          if ($scope.timeInMs === 0) {
            $scope.timeInMs = Date.now();
          } else if (($scope.timeInMs !== 0) && (Date.now() - $scope.timeInMs <= 500) &&
                      ($.trim($scope.modalOptions.searchProviders).length > 0)) {
            return false;
          }

          var checkDuplicateProvier = function (pName) {
            var matched = false;
            angular.forEach($scope.modalOptions.selectedProviders, function (prvd) {
              if (!matched &&
                  ($.trim(prvd.providerName.toLowerCase()).localeCompare($.trim(pName).toLowerCase()) === 0) )
              {
                matched = true;
                return true;
              }
            });
            return matched;
          };

          if ($.trim($scope.modalOptions.searchProviders).length >= 3) {
            $scope.modalOptions.providerSearchClose = true;
            var qString = $.trim($scope.modalOptions.searchProviders);
            var patt = new RegExp($.trim($scope.modalOptions.searchProviders), 'ig');
            

            q.all([
              http.get(app.api.root + 'user-providers?providerName=' + qString)
            ]).then(function (responses) {
              $scope.modalOptions.filteredProviders = responses[0].data.results;
              $scope.modalOptions.providers = $scope.modalOptions.filteredProviders.filter(function (node) {
                if ((checkDuplicateProvier(node.providerName) === false) && (node.providerName.match(patt) !== null)) {
                  return true;
                } else {
                  return false;
                }
                
              });
            });
          } else if ($.trim($scope.modalOptions.searchProviders).length === 0) {
            $scope.timeInMs = 0;
            $scope.modalOptions.providers = $scope.modalOptions.copyProviders.filter(function (node) {
              if ((checkDuplicateProvier(node.providerName) === false)) {
                return true;
              } else {
                return false;
              }
            });
          }

        };

      };
      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
      modalOptions.providers = scope.providers;//dummyProviders;//roles;
      modalOptions.selectedProviders = selectedProvider;
      modalOptions.copyProviders = scope.masterProviders;//modalOptions.providers;
      modalService.showModal(modalDefaults, modalOptions);
    
    };

    scope.modalOpenSelectCareTeamMember = function (selectedMembers) {
      var modalOptions = {
        closeButtonText: 'Cancel',
        actionButtonText: 'Save',
        headerText: 'Select Care Team Members',
        bodyText: '',
        populations: null,
        selectedPopulations: null
      };
      var modalDefaults = {
        'templateUrl': app.root + 'templates/modalMessagesSelectCareTeamMember.html'
      };
      if(!selectedMembers || (!Array.isArray(selectedMembers))) {
        selectedMembers = [];
      }
      modalDefaults.controller = function ($scope, $modalInstance) {
        var tempModalOptions = {};
        angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);
        $scope.modalOptions = tempModalOptions;

        $scope.modalOptions.ok = function (result) {
          scope.messageData.careTeams = result;
          scope.messageData.selectdMemberNames = result.map(function(node){
              return node.name;
            }).join();
          scope.messageData.careTeamRecipients = result.map(function (node) {
            return {'userId' : node.id, 'isProvider' : false };
          });
          $modalInstance.close();
        };
        $scope.modalOptions.close = function () {
          $modalInstance.dismiss('cancel');
        };
      };

      var tempModalOptions = {};
      angular.extend(tempModalOptions, modalService.getSettings('options'), modalOptions);

      modalOptions.members = scope.careTeams;//dummyCareTeamMember;//roles;
      var careTeamIds = selectedMembers.map(function (node) {
        return node.id;
      });
      modalOptions.members = scope.careTeams.filter(function(node){
        if(careTeamIds.indexOf(node.id) !== -1){
          return false;
        }
        else{
          return true;
        }
      });
      modalOptions.selectedMembers = selectedMembers;//roles;
      modalService.showModal(modalDefaults, modalOptions);
    };

    /* function to show the view message block */
    scope.showViewMessage = function (id, to) {
      scope.messageData.messageId = id;
      scope.messageData.to = to;

      var getUrl = '';
      getUrl = app.api.root +'providers/' + scope.user.providerId + '/messages/' + id;
      http({
        method: 'GET',
        url: getUrl
      })
       .success(function (data) {
          scope.messageData.patientUserId = data.results.patientUserId;
          scope.messageData.patientResults = data.results;
          scope.messageData.from = data.results.from ? data.results.from.trim() : '';
          scope.messageData.fromId = data.results.fromUserId;
          scope.messageData.subject = data.results.subject;
          scope.messageData.sentDate = data.results.dateSent || data.results.dateReceived;
          scope.messageData.content = data.results.content;
          scope.messageData.attachedFiles = data.results.attachments;
          scope.messageData.patientName = data.results.patientName;
          scope.messageData.recipients = data.results.recipients;
          getCareCommunity();
          scope.messageData.to = data.results.recipients.map(function (node) {
            return node.fullName;
          });
          scope.messageData.to = scope.messageData.to ? scope.messageData.to.join('; ').trim() : '';

          if (scope.moduleData.folderName !== 'draft') {
            scope.moduleData.isViewMessage = true;
          } else {
            scope.moduleData.isReply = false;
            scope.moduleData.isReplyAll = false;
            scope.moduleData.isForward = false;
            scope.moduleData.isArchive = false;
            scope.messageData.draftContent = data.results.content;
            scope.messageData.recipients = data.results.recipients;
            scope.bindNewMessage();
          }
          var messageData={};
          messageData.messageState = 'V';
          if(angular.equals(scope.moduleData.folderName,'inbox')){
            scope.putMessage(messageData,true);
          }

        });
    };

    scope.getProvidersAndCareMembers = function (action) {
        var careTeamIds=[];
        var providerIds = scope.providers.map(function (node) {
          return { fullName: node.providerName,  userId: node.id };
        });
        if (scope.careTeams !== undefined && scope.careTeams.length > 0) {
          careTeamIds = scope.careTeams.map(function (node) {
              return node.id;
            });
        }
        scope.replyToData = [
          {
            fullName: scope.messageData.from,
            userId: scope.messageData.fromId
          }
        ];
        if (action === 'Reply') {
          scope.messageData.providers = [];
          angular.forEach(providerIds, function (provider) {
            if (provider.userId === scope.replyToData[0].userId) {
              scope.messageData.providers = scope.replyToData;
              scope.messageData.careTeams = [];
            }
          });

          if (scope.messageData.providers.length === 0) {
            if (careTeamIds !== undefined && careTeamIds.indexOf(scope.replyToData[0].userId) !== -1) {
              scope.messageData.careTeams = scope.replyToData;
              scope.messageData.providers = [];
            }
          }
        } else {
          var duplicateRecipient = false;
          angular.forEach(scope.messageData.recipients, function (data) {
            if (data.userId === scope.messageData.fromId && angular.lowercase(scope.messageData.from) === angular.lowercase(data.fullName)) {
              duplicateRecipient = true;
            }
          });

          if (action !== 'draft') {
            if (!duplicateRecipient) {
              scope.messageData.recipients.push({
                fullName: scope.messageData.from,
                userId: scope.messageData.fromId
              });
            }
          }
          
          scope.messageData.providers = [];
          angular.forEach(scope.messageData.recipients, function (data) {
            if (!(data.userId === parseInt(scope.user.providerId) && scope.user.username === angular.lowercase(data.fullName))) {
              angular.forEach(providerIds, function (provider) {
                if (provider.userId === data.userId && data.isProvider === true) {
                  scope.messageData.providers.push(provider);
                }
              });
            }
          });
          if (scope.messageData.recipients !== undefined) {
            scope.messageData.careTeams = scope.messageData.recipients.filter(function (node) {
              if (!(node.userId === parseInt(scope.user.providerId) && scope.user.username === angular.lowercase(node.fullName))) {
                if (careTeamIds !== undefined && (careTeamIds.indexOf(node.userId) !== -1) && node.isProvider === false) {
                  return true;
                } else {
                  return false;
                }
              }
            });
          }
        }
        if (scope.messageData.providers !== undefined) {
          scope.messageData.selectdProviderNames = scope.messageData.providers.map(function (node) {
              return node.fullName;
            }).join();
        }
        if (scope.messageData.careTeams !== undefined) {
          scope.messageData.selectdMemberNames = scope.messageData.careTeams.map(function (node) {
              return node.fullName;
            }).join();
        }
        if (scope.messageData.providers !== undefined) {
          scope.messageData.providerRecipients = scope.messageData.providers.map(function (node) {
              return { 'userId': node.userId, 'isProvider': node.isProvider };
            });
        }
        if (scope.messageData.careTeams !== undefined) {
          scope.messageData.careTeamRecipients = scope.messageData.careTeams.map(function (node) {
              return { 'userId': node.userId, 'isProvider': node.isProvider };
            });
        }
        if (scope.messageData.providers !== undefined) {
          scope.messageData.providers = scope.messageData.providers.map(function (node) {
              return { 'id': node.userId, 'providerName': node.fullName, 'isProvider': node.isProvider };
            });
        }
        if (scope.messageData.careTeams !== undefined) {
          scope.messageData.careTeams = scope.messageData.careTeams.map(function (node) {
              return { 'id': node.userId, 'name': node.fullName, 'isProvider': node.isProvider };
            });
        }
        
        if(scope.isAdmin === true && scope.messageData.careTeamRecipients !== '')
        {
          if(scope.messageData.selectdProviderNames !== '')
          {
            scope.messageData.selectdProviderNames += ',' + scope.messageData.selectdMemberNames;
          }
          else
          {
            scope.messageData.selectdProviderNames = scope.messageData.selectdMemberNames;
          }
        }

        if (scope.headerText === 'New Message') {
          scope.messageData.selectdProviderNames = '';
          scope.messageData.selectdMemberNames = '';
          scope.messageData.providers = [];
          scope.messageData.careTeams = [];
        }
      };

    /* function to navigate to message editor screen  */
    scope.viewMessageAction = function (action) {
      scope.resetControls(false, false, true);
      scope.moduleData.isReply = false;
      scope.moduleData.isReplyAll = false;
      scope.moduleData.isForward = false;
      scope.moduleData.isArchive = false;
      scope.getProvidersAndCareMembers(action);
      if (action === 'Reply') {
        scope.moduleData.isReply = true;
        location.path('/message/new-message');
      } else if (action === 'Reply All') {
        scope.moduleData.isReplyAll = true;
        location.path('/message/new-message');
      } else if (action === 'Forward') {
        scope.moduleData.isForward = true;
        location.path('/message/new-message');
      } else if (action === 'Archive') {
        scope.moduleData.isArchive = true;
        scope.messageState = 'Archived';
        scope.resetControls(true, false, false);
        scope.sendMail();
      }
    };

    /* function to read file  */
    scope.onReaded = function (e, file) {
      scope.selectedFiles.push({ 'ref': file, 'content': e.target.result });
    };

    /* function to remove selected file  */
    scope.removeSelectedFile = function (selected) {
      scope.selectedFiles = scope.selectedFiles.filter(function (removeFile) {
        return (selected.ref.name && (selected.ref.name === removeFile.ref.name)) ? false : true;
      });
    };

    /* redirect to same message window cancel click  */
    scope.cancelMessage = function () {
      if (scope.moduleData.folderName === 'inbox') {
        location.path('/message');
      } else if (scope.moduleData.folderName === 'sent') {
        location.path('/message/sent');
      } else if (scope.moduleData.folderName === 'draft') {
        location.path('/message/draft');
      } else if (scope.moduleData.folderName === 'archived') {
        location.path('/message/archived');
      } else if (scope.moduleData.folderName === '') {
        location.path('/message');
      }
    };

    /* function for save as draft functionality */
    scope.saveDraft = function () {
      scope.isSaveAsDraft = true;
      scope.sendMail();
    };

    /* function to validate files supported as attachments */
    scope.fileExtensionSupported = function (fileExtension) {
      var supportedExtentions = ['pdf', 'doc', 'txt', 'jpg', 'jpeg'];
      return supportedExtentions.indexOf(fileExtension) >= 0 ? 0 : 1;
    };

    /* function to return if validation is true or false */
    scope.validateSentMessage = function () {
      scope.errorValMsg = '';
      var count = 0,
        totalSize = 0;

      if (!scope.messageData.selectdProviderNames && !scope.messageData.selectdMemberNames) {
        if (scope.isAdmin) {
          scope.errorValMsg = 'Please select Providers.';
        }
        else {
          scope.errorValMsg = 'Please select at least one of Provider or Care Team.';
        }
        return false;
      }

      if (!scope.messageData.subject) {
        scope.errorValMsg = 'Subject is required';
        return false;
      }

      angular.forEach(scope.selectedFiles, function (file) {
        count = count + scope.fileExtensionSupported(file.ref.name.substr(file.ref.name.lastIndexOf('.') + 1).toLowerCase());
        totalSize = totalSize + file.ref.size;
      });
      if (count !== 0) {
        scope.errorValMsg = 'Attached file format is not supported. Only following file formats are supported - pdf, doc, txt, jpg, jpeg.';
        return false;
      }

      if ((totalSize > 0) && (totalSize >= 4194304)) {
        scope.errorValMsg = 'Attached files exceeds the file size limit. Maximum allowed file size is 4MB.';
        return false;
      }
      return true;
    };

    /* sendMail get called when Send button clicks  */
    scope.sendMail = function () {
      var attachments = {},
        listAttachments = [],
        messageDetails = {},
        messageData = scope.messageData,
        fileRef = '',
        fileName = '',
        fileExtensionIndex = '',
        recipients = [],
        recipient = {};

      messageData.messageState = 'S';
      if (scope.moduleData.isArchive) {
        messageData.messageState = 'A';
        messageDetails = {
          'messageState': messageData.messageState
        };
        scope.putMessage(messageDetails);
      }
      else if (!scope.validateSentMessage()) {
        scope.ShowNotifications(scope.errorValMsg, 'alert-error');
      }
      else {
        // check for attachments
        if (scope.selectedFiles.length) {
          angular.forEach(scope.selectedFiles, function (file) {

            fileRef = file.ref;
            fileName = fileRef.name;
            fileExtensionIndex = fileName.lastIndexOf('.');

            attachments = {
              'name': fileName.substr(0, fileExtensionIndex),
              'extension': fileName.substr(fileExtensionIndex),
              'content': file.content,
              'fileType': fileName.substr(fileExtensionIndex + 1),
              'mimeType': fileRef.type,
              'fileSize': fileRef.size
            };
            listAttachments.push(attachments);
          });
        }
        /* Insert comma when providerRecipients and careTeamRecipients has values, else select either on which has values*/
        if(messageData.providerRecipients.length > 0){
          angular.forEach(messageData.providerRecipients, function(providerRecipient){
              recipient = {
                'userId' : providerRecipient.userId,
                'IsProvider' : true
              };
              recipients.push(recipient);
            });
        }
        if(messageData.careTeamRecipients.length > 0){
          angular.forEach(messageData.careTeamRecipients, function(careTeamRecipient){
              recipient = {
                'userId' : careTeamRecipient.userId,
                'IsProvider' : false
              };
              recipients.push(recipient);
            });
        }
        messageDetails = {
          'subject': messageData.subject,
          'body': messageData.content,
          'isDraft': scope.isSaveAsDraft, // always false when sent
          'messageState': messageData.messageState,
          'patientUserId': messageData.patientUserId,
          'attachments': listAttachments,
          'recipients': recipients,
          'isMassCommunication': false
        };

        if ((scope.moduleData.isReply === true || scope.moduleData.isReplyAll === true || scope.moduleData.isForward === true) && (scope.isSaveAsDraft === true)) {
          scope.postMessage(messageDetails);
        }
        else if (scope.isSaveAsDraft) {
          scope.putMessage(messageDetails);
        }
        else
        {
          if (scope.messageData.messageId > 0)
          {
            scope.putMessage(messageDetails);
          }
          else
          {
            scope.postMessage(messageDetails);
          }
        }
      }
    };

    /* function for updating message */
    scope.putMessage = function (messageData,messageStatus) {
      if (scope.messageData.messageId === 0) {
        scope.methoStatus = 'POST';
        scope.urlPath = app.api.root + 'providers/' + scope.user.providerId + '/messages/';
      }
      else {
        scope.methoStatus = 'PUT';
        scope.urlPath = app.api.root + 'providers/' + scope.user.providerId + '/messages/' + scope.messageData.messageId;
      }
      http({
        method: scope.methoStatus,
        url: scope.urlPath,
        data: { 'model': messageData }
      }).
        success(function () {
          
          if(messageStatus !== true){
            scope.resetControls(true);
          }
          else{
            scope.getUnreadCount();
            scope.bindGrid();
          }
          if (scope.moduleData.isArchive === true) {
            if (scope.moduleData.folderName === 'inbox') {
              scope.inboxInitialize(messageStatus);
            } else if (scope.moduleData.folderName === 'sent') {
              scope.sentInitialize();
            } else if (scope.moduleData.folderName === 'draft') {
              scope.draftInitialize();
            } else if (scope.moduleData.folderName === 'archived') {
              scope.archiveInitialize();
            }
          } else {
            location.path('/message');
          }
        });
    };

    /* function for posting message */
    scope.postMessage = function (messageData) {


      http({
        method: 'POST',
        url: app.api.root + 'providers/' + scope.user.providerId +'/messages',
        data: { 'model': messageData }
      }).
        success(function () {
          scope.resetControls(true);
          location.path('/message');
        });
    };

    /* function to get grid data from api call */
    scope.bindGrid = function () {
      if (angular.lowercase(scope.user.role) === 'administrator' || angular.lowercase(scope.user.role) === 'analyst' || angular.lowercase(scope.user.role) === 'clinic administrator' || angular.lowercase(scope.user.role) === 'physician' || angular.lowercase(scope.user.role) === 'insurance group provider') {
        scope.isAdmin = true;
      }
      var getUrl = '';
      getUrl = app.api.root + 'providers/' + scope.user.providerId +'/messages?folder=' + scope.moduleData.folderName;

      http({
        method: 'GET',
        url: getUrl
      })
        .success(function (data) {
            scope.messageGridData = data.results;
            scope.messageGridData.forEach(function (data) {
                if (data.messageState === 'Not Viewed') {
                  data.isViewed = false;
                } else {
                  data.isViewed = true;
                }
                data.isAttachment = data.isAttachment.toString();
              });
          });
    };
   
     /* converts base64 to Array buffer */
    scope.base64ToUint8Array=function(base64) {
          var raw = window.atob(base64); //This is a native function that decodes a base64-encoded string.
          var uint8Array = new Uint8Array(new ArrayBuffer(raw.length));
          for(var i = 0; i < raw.length; i = i+1) {
            uint8Array[i] = raw.charCodeAt(i);
          }
          return uint8Array;
        };

    /* function to save attached document */
    scope.saveDocument = function (file) {
      var fileName = file.name;
      var contentType = file.mimeType;
      var content = file.content;
      var test = scope.base64ToUint8Array(content);
      var blob = new Blob([test], {type: contentType});
      saveAs(blob, fileName);
    };

    /* configuration for toolbar editor */
    scope.editorOptions = {
      language: 'en',
      height: 200,
      extraPlugins: 'font,colorbutton',
      toolbar: [
        ['Font'], ['FontSize'], ['Format'], ['BulletedList'], ['NumberedList'], ['Blockquote'], ['Outdent'], ['Indent'],
        ['Bold'], ['Italic'], ['Underline'], ['Strike'], ['Subscript'], ['Superscript'], ['RemoveFormat'],
        ['Link'], ['Unlink'], ['Anchor'], ['Image'], ['Table'], ['HorizontalRule'], ['SpecialChar'],
        ['JustifyLeft'], ['JustifyCenter'], ['JustifyRight'], ['JustifyBlock'],
        ['Undo'], ['Redo'], ['TextColor'], ['BGColor']
      ],
    };

    /* function to get unread message count */
    scope.getUnreadCount = function () {
      

      var getUrl = app.api.root + 'providers/' + scope.user.providerId +'/messages-count?messageState=N';
      http({
        method: 'GET',
        url: getUrl
      })
      .success(function (data) {
        scope.inboxMessage.unreadMsgCount =  parseInt(data.results);
      })
      .error(function () {
        scope.inboxMessage.unreadMsgCount = 0;
      });
    };
  }]);
}(window.app));
