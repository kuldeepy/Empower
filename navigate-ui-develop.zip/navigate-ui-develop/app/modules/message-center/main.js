(function (app) {
  'use strict';

  /* module root controller */
  var modulePath = 'modules/message-center';

  app.controller('messageCenterMainCtrl', ['$scope', '$timeout', function (scope, timeout) {
    scope.model = {
      routeParams: {}
    };

    scope.headerText = '';
    scope.isSaveAsDraft = false;
    scope.stateOfMsgBox = 'inbox';
    scope.moduleData = {
      isInbox: true,
      isNewMessage: false,
      isViewMessage: false,
      isReply: false,
      isReplyAll: false,
      isForward: false,
      isArchive: false,
      isDraft: false,
      folderName: ''
    };

    scope.messageData = {
      sentDate:'',
      from:'',
      to:'',
      subject:'',
      content: '',
      patientName: '',
      draftContent: '',
      messageId: 0,
      patientUserId: 0,
      patientResults: {},
      attachedFiles: [],
      providerRecipients: '',
      careTeamRecipients: '',
      messageState: 'S',
      unreadCount: 0,
      fromId: 0
    };

    scope.sentErrorMessage = 'Unfortunately we are unable to send the message. Please try again later or contact your system administrator if this continues.';

    /* display error message if failed to get the data from api*/
    scope.ShowNotifications = function (errorMsg, style) {
      window.scrollTo(0, 0);
      scope.alertMessageStyle = style;
      scope.alertMessage = errorMsg;
      scope.isError = true;
      timeout(function () {
        scope.isError = false;
      }, 6000);
    };

  }]);

  /* load required controllers */
  $.when(
	$.getScript('/modules/patient/controllers/PatientCtrl.js')
  ).done(function () {
    app.publish('moduleReady', modulePath);
  });

}(window.app));
