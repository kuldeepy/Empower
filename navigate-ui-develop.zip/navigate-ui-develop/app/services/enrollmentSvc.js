(function (app) {
  'use strict';

  app.factory('enrollmentSvc', ['$http',
    function (http) {
        return{
          getEnrollments : function (providerId,filterData) {
            return http.get(app.api.root +'providers/'+ providerId + '/enrollments/',{params: filterData});
          },
          disEnrollment : function (disEnrollData) {
            return http.delete(app.api.root +'disenrollment',{params: disEnrollData});
          },
          getPatientDetails : function (patientId) {
            return http.get(app.api.root +'patient/' + patientId + '/pending-enroll-details');
          },
          getManagedPopulationConflicts : function (patientId,programId) {
            return http.get(app.api.root +'managed-population/' + programId + '/enroll-patient/' + patientId + '/conflicts');
          },
        };
      }
    ]);
})(window.app);