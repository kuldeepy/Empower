(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('chronicCareManagementSvc', ['$http','authSvc', function($http,authSvc) {
    return {
        getDateKey: function () {
            return $http.get(app.api.root + 'reports/chronic-care/date-keys');
          },
        getCareTeamFilter: function (params) {
            return $http.get(app.api.root + 'reports/chronic-care/care-teams', {params: params});
          },
        getCareTeamMembersFilter: function (params) {
            return $http.get(app.api.root + 'reports/chronic-care/care-team-members', {params: params});
          },
        getPhysicianFilter: function (params) {
            return $http.get(app.api.root + 'reports/chronic-care/physicians', {params: params});
          },
        getClinicsFilter: function (params) {
            return $http.get(app.api.root + 'reports/chronic-care/clinics', {params: params});
          },
        getProductTypesFilter: function (params) {
            return $http.get(app.api.root + 'reports/chronic-care/product-types', {params: params});
          },
        getFilterData: function (params) {
            return $http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/chronic-care',{params:params});
          },
      };
  }]);
}(window.app));
