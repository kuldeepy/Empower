(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('reminderScheduleSvc', ['$http', function($http) {
    return {
      reminderScheduleList: function() {
        return $http
        .get(app.api.root + 'reminder-schedule')
        .then(
          // success
          function(response) {
            return response;
          },
          // error
          function(err) {
            if(err){
              return (err);
            }
          });
      },

      updateReminderSchedule: function(reminderscheduleData){
        return $http
        .put(app.api.root +'reminder-schedule/'+reminderscheduleData.taskTypeId,reminderscheduleData)
        .then(
          // success
          function(response) {
            return response;
          },
         // error
         function(err) {
            if(err){
              return (err);
            }
          });
      }
    };
  }
  ]);

}(window.app));