(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('goalsSvc', ['$http', function($http) {
    return {
      getPatientGoals: function(id, status) {
        //return $http.get(app.api.root + 'patients/' + id + '/goals');
        return $http.get(app.api.root + 'patients/' + id + '/goals?status=' + status);
      },

      getPatientNotes: function(id, objectbody) {
        return $http.get(app.api.root + 'patients/' + id + '/notes', objectbody);
      },

      getPatientNotesByNoteId: function(patientId,notesId) {
        return $http.get(app.api.root + 'patients/' + patientId + '/notes/' + notesId);
      },

      postPatientNotes: function(id, objectbody) {
        return $http.post(app.api.root + 'patients/' + id + '/notes',objectbody);
      },

      getPatientPopulations: function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/patient-populations?type=populations');
      },

      postPatientGoals: function(id, objectbody) {
        return $http.post(app.api.root + 'patients/' + id + '/goal',objectbody);
      },

      putPatientGoals: function(patientId, goalId, objectbody) {
        return $http.put(app.api.root + 'patients/' + patientId + '/goals/' + goalId,objectbody);
      },

      deletePatientGoals: function(patientId, goalId) {
        return $http.delete(app.api.root + 'patients/' + patientId + '/goals/' + goalId);
      },

      getActivityTypes: function() {
        return $http.get(app.api.root + 'activity-types');
      },

      postPatientGoalsActivities: function(patientId, goalId, objectbody) {
        return $http.post(app.api.root + 'patients/' + patientId + '/goals/' + goalId + '/activities',objectbody);
      },

      putPatientGoalsActivities: function(patientId, goalId, activityId, objectbody) {
        return $http.put(app.api.root + 'patients/' + patientId + '/goals/' + goalId + '/activities/' + activityId ,objectbody);
      },

      deletePatientGoalsActivities: function(patientId, goalId, activityId) {
        return $http.delete(app.api.root + 'patients/' + patientId + '/goals/' + goalId + '/activities/' + activityId);
      }

    };
  }
  ]);


}(window.app));
