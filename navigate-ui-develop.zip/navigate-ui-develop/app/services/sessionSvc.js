(function (app) {
  'use strict';

  var sessionKeyPrefix = 'user.session.';
  var session = {
    get: function (key) {
      return localStorage.getItem(sessionKeyPrefix + key);
    },
    set: function (key, value) {
      if (value === undefined || value === null) {
        this.clear(key);
      }
      else {
        localStorage.setItem(sessionKeyPrefix + key, value);
      }
    },
    clear: function (key) {
      localStorage.removeItem(sessionKeyPrefix + key);
    }
  };
  //TODO : Have to change the service name since it is using local storage.
  app.factory('sessionSvc', function () {
    return {
      get: session.get,
      set: session.set,
      clear: session.clear
    };
  });

})(window.app);