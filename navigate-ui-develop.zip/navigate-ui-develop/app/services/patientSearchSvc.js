(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('patientSearchSvc', ['$http', 'authSvc', function($http, authSvc) {

      return {

          getPatientsForExport: function(objectbody) {
            var config = {
              responseType: 'arraybuffer',
              timeout: 5 * 60 * 1000
            };
            return $http.post(app.api.root + 'patients-export', objectbody, config);
          },
          getPatientManagedPopulationFilter: function () {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/patients-managed-populations');
          },
          getPatientConditionsFilter: function () {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/conditions');
          },
          getPatientCareTeamFilter: function (objectbody) {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/patients-care-teams', {params: objectbody});
          },
          getPatientCareLeadFilter: function (objectbody) {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/patients-care-leads', {params: objectbody});
          },
          getPatientPCPFilter: function () {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/primarycare-providers');
          },
          getPatientInsurancePlanFilter: function () {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/insurance-plans');
          },
          getPatientClinicFilter: function () {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/clinics');
          },
          getPatientStateFilter: function () {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/states');
          },
          getPatientProductTypeFilter: function () {
            return $http.get(app.api.root + 'providers/' + authSvc.user().providerId + '/product-types');
          },
          getRequest: function(requestpath,params) {
            return $http.get(app.api.root + requestpath, {params: params});
          },
          getPatientSearchStaticData : function() {
            return [{ HeaderText: 'Managed Population',dbColumn : 'selectedManagedPopulations',selectedData :'managedPopulations'},
                    { HeaderText: 'Conditions',dbColumn : 'selectedConditions',selectedData :'conditions'},
                    { HeaderText: 'Care Team',columnName :'careTeamName',columnId :'careTeamId',dbColumn : 'selectedCareTeam',selectedData :'careTeamId'},
                    { HeaderText: 'Care Lead',dbColumn : 'selectedCareLeads',selectedData :'careLeads'},
                    { HeaderText: 'Patient Last Name', selectedData :'patientLastName',parms:['patientLastName']},
                    { HeaderText: 'Age',ageFrom : '',ageTo : '',parms:['ageFrom','ageTo']},
                    { HeaderText: 'Date of Birth',dOBFrom : '',dOBTo : '',parms:['dOBFrom','dOBTo']},
                    { HeaderText: 'PCP',columnName :'name',columnId :'id',dbColumn : 'selectedPcp',selectedData :'pCPId'},
                    { HeaderText: 'Insurance Plan',columnName :'name',columnId :'id',dbColumn : 'selectedInsurancePlan',selectedData :'insurancePlanId'},
                    { HeaderText: 'Clinic',columnName :'clinicName',columnId :'clinicID',dbColumn : 'selectedClinic',selectedData :'clinicId'},
                    { HeaderText: 'State',columnName :'name',columnId :'stateId',dbColumn : 'selectedState',selectedData :'stateId'},
                    { HeaderText: 'Product Type',columnName :'Name',columnId :'Type',dbColumn : 'selectedProductType',selectedData :'productType'}];
          }
        };
    }]);
}(window.app));