﻿(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('marketingSvc', ['$http', function ($http) {

      var service = {
        isSaveFinal : null,
        saveNotificationMsg: null,
        isSpinner: true
      };

      return {
        saveNotificationMsg : service.saveNotificationMsg,
        getCampaigns: function (objectbody) {
          return $http.get(app.api.root + 'campaigns' + objectbody);
        },
        
        getCampaignsDetailsById: function (objectbody) {
          return $http.get(app.api.root + 'campaigns/' + objectbody);
        },
        
        getPatientCount: function (objectbody) {
          return $http.get(app.api.root + 'population-definitions/' + objectbody + '/patients?pageIndex=1&pageSize=10');
        },
        
        postCampaign: function (objectbody) {
          return $http.post(app.api.root + 'campaign', objectbody);
        },
        
        putCampaignByID: function (objectbody) {
          return $http.put(app.api.root + 'campaign' , objectbody);
        },
        
        getExportToExcel: function (objectbody) {
          return $http.get(app.api.root + 'population-definitions/' + objectbody.populationDefinitionId + '/patients?' + '&pageIndex=' + objectbody.pageIndex + '&pageSize=' + objectbody.pageSize);
        }
      };
    }
    ]);
}(window.app));