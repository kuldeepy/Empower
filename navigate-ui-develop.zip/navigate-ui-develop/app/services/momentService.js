/**
 * @author michael.ash
 */
(function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('momemt',['$window', function($window) {
    return $window.moment; // assumes momentjs has already been loaded on the page
  }]);
}(window.app));