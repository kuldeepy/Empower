(function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on

  app.factory('formatService', function() {
    return {

      toTitleCase: function(str) {
        return str.replace(/\w\S*/g, function(str) {
          return str.charAt(0).toUpperCase() + str.substr(1).toLowerCase();
        });
      },

      truncate : function (text, length, end) {
        if (isNaN(length)){
          length = 10;
        }

        if (end === undefined){
          end = '...';
        }
        if (text.length <= length || text.length - end.length <= length) {
          return text;
        }
        else {
          return String(text).substring(0, length-end.length) + end;
        }
      }

    };
  });

}(window.app));