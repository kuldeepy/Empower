(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('httpRequestSvc', ['$http', function($http) {
    return {
      getRequest: function(requestpath,params) {
        return $http.get(app.api.root + requestpath, {params: params});
      },

      postRequest: function(requestpath,objectbody) {
        return $http.post(app.api.root + requestpath,objectbody);
      },

      putRequest: function(requestpath,objectbody) {
        return $http.put(app.api.root + requestpath,objectbody);
      },

      deleteRequest: function(requestpath) {
        return $http.delete(app.api.root + requestpath);
      }
    };
  }
  ]);


}(window.app));
