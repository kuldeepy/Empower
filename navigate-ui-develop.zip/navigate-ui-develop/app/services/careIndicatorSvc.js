(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('careIndicatorSvc', ['$http', function($http) {
    return {
        getCareIndicators: function () {
            return $http.get(app.api.root + 'care-category');
          },
        getPatientCareIndicators: function (patientId) {
            return $http.get(app.api.root + 'patients/' + patientId + '/care-indicators');
          },
        getPatientCareIndicatorHistory: function (patientId, patientCareIndicatorId) {
            return $http.get(app.api.root + 'patients/' + patientId + '/care-indicators/' + patientCareIndicatorId + '/history');
          },
        postPatientCareIndicator: function(patientId, objectbody) {
          return $http.post(app.api.root + 'patients/' + patientId + '/care-indicator',objectbody);
        },
        putPatientCareIndicator: function(patientId, objectbody) {
          return $http.put(app.api.root + 'patients/' + patientId + '/care-indicator',objectbody);
        }
      };
  }]);
}(window.app));
