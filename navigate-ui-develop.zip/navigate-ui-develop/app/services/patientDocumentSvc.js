(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('patientDocumentSvc', ['$http', function($http) {
    return {
      getDocumentCategories: function () {
        return $http.get(app.api.root + 'document-categories');
      },
      getPatientDocuments: function (patientId) {
        return $http.get(app.api.root + 'patients/'+ patientId +'/documents');
      },
      getPatientDocumentDownload: function (patientId,patientDocumentId) {
        return $http.get(app.api.root + 'patients/'+ patientId +'/documents/'+ patientDocumentId);
      },
      savePatientDocuments: function (requestpath,objectbody) {
          return $http.post(app.api.root + requestpath,objectbody);
        },
      getPatientCcdDocuments: function (patientId) {
        return $http.get(app.api.root + 'patients/'+ patientId +'/continuity-care-documents');
      },
      getPatientCcdDocumentDownload: function (patientId,fileId) {
        return $http.get(app.api.root + 'patients/'+ patientId +'/continuity-care-documents/' + fileId);
      },
    };
  }
  ]);

}(window.app));