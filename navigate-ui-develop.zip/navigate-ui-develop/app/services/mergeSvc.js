(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('mergeSvc', ['$http', function($http) {
    return {
      getPatientGeneralInformation: function(notificationId) {
        return $http.get(app.api.root + 'patients-merge/' + notificationId + '/Information');
      },
      getScheduleTasks: function(patientId,mergePatientId) {
        return $http.get(app.api.root + 'patient/' + patientId + '/Schedule-Task/' + mergePatientId);
      },
      getAdhocTasks: function(patientId,mergePatientId) {
        return $http.get(app.api.root + 'patient/' + patientId + '/Adhoc-Task/' + mergePatientId);
      },
      getManagedPopulation: function(patientId,mergePatientId) {
        return $http.get(app.api.root + 'patient/' + patientId + '/Managed-Population/' + mergePatientId);
      },
      updatePatientMerge: function(patientId,providerID,object) {
        return $http.put(app.api.root + 'patient/' + patientId + '/Provider/' + providerID + '/Merge', object);
      },
      status : 0
    };
  }
  ]);
}(window.app));
