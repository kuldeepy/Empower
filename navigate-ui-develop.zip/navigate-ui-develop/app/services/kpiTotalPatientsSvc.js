(function (app) {
  'use strict';

  app.factory('kpiTotalPatientsSvc', ['$http',
    function (http) {
        return{
          getDateKeyRequest : function () {
            return http.get(app.api.root + 'reports/kpi-total-patients/date-keys');
          },
          getkpiTotalPatientsRequest : function (filterData) {
            return http.get(app.api.root + 'reports/kpi-total-patients/patients-details', {params: filterData});
          }
        };
      }
    ]);
})(window.app);