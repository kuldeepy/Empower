/**
 * @author michael.ash
 */
(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on


  app.factory('navMenuService', function () {
    var fac = {};
    function getItemCount(arr) {
      if (arr === undefined) {
        return 0;
      }
      return arr.length;
    }
    fac.getApiUrl = function (apiUrl,id1){
      return app.api.root + apiUrl.replace(/:\w+/,id1);
    };
    fac.getApiUrlReplacePatientID = function (apiUrl,PatientID){
        var URL;
        URL=apiUrl.replace(/patientId=\w+/,'patientId='+PatientID);
        return URL;
      };
    /*
     * @namespace ContextMenu
     */
    fac.menu = {
      /*
       * @name MyTasksContext
       * The filters used for myTasks pages for care managers
       *
       */
      myTasks : [
        {
          id : 'managedPopulationFilter',
          filters : [],
          text : 'Managed Popululation'

        },
        {
          id : 'careTeamFilter',
          filters : [],
          text : 'Care Team'

        },
        {
          id : 'careManagersFilter',
          filters : [],
          text : 'Care Managers'

        },
        {
          id : 'taskTypesFilter',
          filters : [],
          text : 'Task Types'

        },
        {
          id : 'taskNamesFilter',
          filters : [],
          text : 'Task Names'

        },
        {
          id : 'pcpFilter',
          filters : [],
          text : 'PCP'

        }

      ],
      /*
       * @name PatientContextMenu
       */
      patient : [{
          id : 'careIndicators',
          path : '/careindicators',
          text : 'Care Indicators',
          count : getItemCount,
          apiUrl : ['patients/:id/care-indicators'],
          details: true,
          secondline:true,
          line2css:''
        },{
          id : 'conditions',
          path : '/',
          text : 'Conditions',
          count : getItemCount,
          apiUrl : ['patients/:id/conditions'],
          details: false,
          secondline:true,
          line2css:''
        }, {
          id : 'medications',
          path : '/medications',
          text : 'Medications',
          count : getItemCount,
          apiUrl : ['patients/:id/medications'],
          details: true,
          secondline:false,
          line2css:''
        }, {
          id : 'utilizations',
          path : '/utilizations',
          text : 'Utilization',
          count : getItemCount,
          apiUrl : ['patients/:id/utilization-events', 'patients/:id/utilization-encounters'],
          details: true,
          secondline:false,
          line2css:''
        }, {
          id : 'clinicalResults',
          path : '/clinical',
          text : 'Clinical Results',
          count : getItemCount,
          apiUrl : ['patients/:id/clinical-results'],
          details: true,
          secondline:false,
          line2css:''
        }, {
          id : 'managedPopulations',
          path : '/managed',
          text : 'Managed Population',
          count : getItemCount,
          apiUrl : ['patients/:id/patient-populations'],
          details: true,
          secondline:false,
          line2css:''
        }, {
          id : 'careCommunity',
          path : '/carecommunity',
          text : 'Care Community',
          count : getItemCount,
          apiUrl : ['patients/:id/care-teams', 'patients/:id/providers'],
          details: true,
          secondline:true,
          line2css:''
        }, {
          id : 'educationalMaterial',
          path : '/educational',
          text : 'Education Material',
          count : getItemCount,
          apiUrl : ['patients/:id/educational-materials'],
          details: true,
          secondline:true,
          line2css:''
        }, {
          id : 'documents',
          path : '/documents',
          text : 'Documents',
          count : getItemCount,
          apiUrl : ['patients/:id/documents'],
          details: true,
          secondline:false,
          line2css:''
        }, {
          id : 'goals',
          path : '/goals',
          text : 'Goals',
          count : getItemCount,
          apiUrl : ['patients/:id/goals?status=Active'],
          details: true,
          secondline:false,
          line2css:''
        }, {
          id : 'assessements',
          path : '/assessements',
          text : 'Assessments',
          count : getItemCount,
          apiUrl : ['patients/:id/assessments'],
          details: true,
          secondline:false,
          line2css:''
        }
      ]
      };
    return fac;
  });
}(window.app));
