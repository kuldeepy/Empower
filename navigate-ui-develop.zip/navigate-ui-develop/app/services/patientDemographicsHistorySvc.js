(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('patientDemographicsHistorySvc', ['$http', function($http) {
    return {
      getPatientDemographics: function (patientId) {
        return $http.get(app.api.root +'patients/'+ patientId +'/demographic-history');
      },
      putPatientDemographicsFavorite : function(patientId,historyId) {
        return $http.put(app.api.root + 'patients/'+patientId+'/demographic-history/' +historyId);
      },
      getCountries: function () {
        return $http.get(app.api.root + 'countries');
      },
      getStates: function () {
        return $http.get(app.api.root + 'states');
      },
      getPatientDemographicData: function (patientId) {
        return $http.get(app.api.root +'patients/'+ patientId +'/demographics');
      },
      putPatientDemographicsData : function(patientId,object) {
        return $http.put(app.api.root + 'patients/'+patientId+'/demographics',object);
      }
    };
  }
  ]);

}(window.app));