(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('patientAssessmentSvc', ['$http', function($http) {
    return {
      getPatientOpenAssessments: function (patientId) {
        return $http.get(app.api.root + 'patients/'+ patientId +'/assessments?status=Open');
      },
      getPatientClosedAssessments: function (patientId) {
        return $http.get(app.api.root + 'patients/'+ patientId +'/assessments?status=Closed Complete');
      },
      getPatientPastAssessments: function (patientId,assessmentID) {
        return $http.get(app.api.root + 'patients/'+ patientId +'/assessments?status=Closed Complete&assessmentId='+ assessmentID +'');
      },
      getAssessments : function(requestpath,params) {
        return $http.get(app.api.root + requestpath, {params: params});
      },
      getManagedPopulations : function(requestpath,params) {
        return $http.get(app.api.root + requestpath, {params: params});
      },
      getPatientAssessmentSurvey : function(requestpath,params) {
        return $http.get(app.api.root + requestpath, {params: params});
      },
      saveAssessment: function(requestpath,objectbody) {
        return $http.post(app.api.root + requestpath,objectbody);
      },
      savePatientAssessmentSurvey: function(requestpath,objectbody) {
        return $http.post(app.api.root + requestpath,objectbody);
      },
      deleteRequest: function(requestpath) {
        return $http.delete(app.api.root + requestpath);
      },
      getPatientData : function(patientId) {
        return $http.get(app.api.root+'patients/' + patientId);
      }
    };
  }
  ]);

}(window.app));