(function (app) {
  'use strict';

  app.factory('advancedAnalyticsSvc', ['$http', function($http) {

    function getReports() {
      return $http.get(app.api.root + 'analytic-reports', {})
      .then(getResults);
    }

    function getResults(httpResults) {
      return httpResults.data.results;
    }

    function getReport(reportId) {
      return $http.get(app.api.root + 'analytic-reports/' + reportId)
      .then(getResults);
    }

    function closeReport(reportInstanceId) {
      return $http.delete(app.api.root + 'analytic-reports/' + reportInstanceId)
      .then(getResults);
    }

    function createReports(data) {
      return $http.post(app.api.root + 'analytic-reports/', data);
    }

    return {
      getReports: getReports,
      getReport: getReport,
      closeReport: closeReport,
      createReports: createReports
    };
  }]);

})(window.app);