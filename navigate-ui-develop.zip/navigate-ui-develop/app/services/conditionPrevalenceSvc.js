(function (app) {
  'use strict';

  app.factory('conditionPrevalenceSvc', ['$http','authSvc',
    function (http,authSvc) {
        return{
          getLatestDateKeyRequest: function () {
            return http.get(app.api.root + 'latestdatekey?reporttype=conditionprevalence');
          },

          getClinicsRequest: function (dateKey) {
            return http.get(app.api.root + 'clinics?context=report&key=' +dateKey);
          },

          getInsurancePlansRequest : function () {
            return http.get(app.api.root + 'insurance-plans?context=Report');
          },

          getProductsRequest : function () {
            return http.get(app.api.root + 'products?context=Report');
          },

          getGraphDataRequest : function (filterData) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/condition-prevalence?conditionPrevalencereport='+ filterData);
          },

          getAllMetricsRequest : function (populationConditionId,metricType,filterData) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/condition-prevalence/'+populationConditionId+'/metrics?metricType=' +metricType , {params : filterData});
          },

          getPhysiciansRequest : function (filter,dateKey) {
            return http.get(app.api.root + 'clinics/'+filter+'/physicians?key=' +dateKey+ '&context=Report');
          },

          getConditonsTrendRequest : function (filter) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/condition-prevalence/trend?conditionPrevalenceTrend=' +filter);
          },

          getMetricsTrendRequest :  function (filter) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/condition-prevalence/metric-trend?conditionPrevalenceTrend=' +filter);
          },

          getConditionPrevalenceRequest :  function (key,filter) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/condition-prevalence/' +key+ '/drilldown?reportDrilldown=' +filter);
          },

          getHedisRequest :  function (key,filter) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/hedis/' +key+ '/drilldown?reportDrilldown=' +filter);
          },

          getPayForPerformanceRequest :  function (key,filter) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/pay-for-performance/' +key+ '/drilldown?reportDrilldown=' +filter);
          },

          getMergePatient : function(patientId) {
            return http.get(app.api.root + 'patients/' + patientId + '/merge');
          },
          getCronicCareRequest : function(filter){
            if(filter.isExport){
              return http({
                method: 'get',
                url: app.api.root + 'reports/chronic-care/patients',
                responseType: 'arraybuffer',
                params: filter,
                timeout: 5 * 60 * 1000
              }).then(function(response) {
                var mime = response.headers('Content-Type');
                var file = new Blob([response.data], {
                  type: mime
                });
               
                var fileName = 'Patients_'+moment().format('MM-DD-YYYY HH:mm:ss')+'.csv';
                saveAs(file, fileName);
              });
            }
            else{
              return http.get(app.api.root + 'reports/chronic-care/patients',{params:filter});
            }
          }
        };
      }
    ]);
})(window.app);