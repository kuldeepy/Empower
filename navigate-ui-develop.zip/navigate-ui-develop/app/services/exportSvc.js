//window.saveAs from FileSaver script in header.

(function (app) {
  'use strict';

  app.factory('exportSvc', [function() {

    //*** fileName: file to save as, without extension.
    //*** data: Array of Arrays. Top level array is columns, each array inside is a row. 
    function saveTabDelimitedAsExcel(fileName, data) {
      var fileData = data.map(function (row) { return row.join('\t'); }).join('\n');
      var blob = new Blob([fileData], { type: 'application/vnd.ms-excel' });
      window.saveAs(blob, fileName);
    }

    return {
      toExcel: saveTabDelimitedAsExcel
    };
  }]);

})(window.app);