(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('carePlanSvc', ['$http', function ($http) {
    return {
      getRequest: function(requestpath,params) {
        $http.defaults.headers.common['cache-control'] = 'no-cache';
        return $http.get(app.api.root + requestpath, {params: params});
      },
      saveCarePlan: function(id, objectbody) {
        return $http.post(app.api.root + 'patients/' + id + '/careplan', objectbody);
      },
      getCarePlans: function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/careplan-versions');
      },
      getCarePlanPdf: function(patientId, carePlanId) {
        return $http.get(app.api.root + 'patients/' + patientId + '/careplan/'+ carePlanId + '?type=pdf');
      },
      getCarePlan: function(patientId, carePlanId) {
        return $http.get(app.api.root + 'patients/' + patientId + '/careplan/'+ carePlanId);
      },
      sendPdfToEmr:function(id, carePlanId) {
        return $http.post(app.api.root + 'patients/' + id + '/careplan/' + carePlanId);
      },
      getConditions:function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/conditions');
      },
      getMedications:function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/medications');
      },
      getCareTeams:function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/care-teams');
      },
      getPatient:function(id) {
        return $http.get(app.api.root + 'patients/' + id);
      },
      base64toBlob: function(base64Data){
        var sliceSize = 1024;
        var byteCharacters = atob(base64Data);
        var bytesLength = byteCharacters.length;
        var slicesCount = Math.ceil(bytesLength / sliceSize);
        var byteArrays = new Array(slicesCount);
        for (var sliceIndex = 0; sliceIndex < slicesCount; sliceIndex += 1) {
          var begin = sliceIndex * sliceSize;
          var end = Math.min(begin + sliceSize, bytesLength);
          var bytes = new Array(end - begin);
          for (var offset = begin, i = 0 ; offset < end; i += 1, offset += 1) {
            bytes[i] = byteCharacters[offset].charCodeAt(0);
          }
          byteArrays[sliceIndex] = new Uint8Array(bytes);
        }
        return new Blob(byteArrays, { type: 'application/pdf' });
      }
    };
  }
  ]);
}(window.app));