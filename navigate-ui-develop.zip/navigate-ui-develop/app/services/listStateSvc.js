(function (app) {
  'use strict';

  function createNewList() {
    return { 'CurrentUIState': {} };
  }

  app.factory('listStateSvc', ['sessionSvc',
    function (sessionSvc) {
      var currentListState = {
        get: function () {
          var state = sessionSvc.get('listState');
          if (state === undefined || state === null || state === '{}') {
            return createNewList();
          }
          return JSON.parse(state);
        },
        set: function (listState) {
          if (listState === undefined || listState === null) {
            sessionSvc.clear('listState');
          }
          else {
            sessionSvc.set('listState', JSON.stringify(listState));
          }
        },
        clear: function () {
          sessionSvc.clear('listState');
        },

        getSeletectedTaskType: function() {
          var currentTaskState = currentListState.get();
          if(currentTaskState.CurrentUIState !== undefined && currentTaskState.CurrentUIState.currentTaskType !== undefined){
            return currentTaskState.CurrentUIState.currentTaskType;
          }
          return '';
        },

        getSeletectedTaskName : function() {
          var currentTask = currentListState.get();
          if(currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.currentTaskName !== undefined){
            return currentTask.CurrentUIState.currentTaskName;
          }
          return '';
        },

        getSeletectedPopulation : function() {
          var currentPopulation = currentListState.get();
          if(currentPopulation.CurrentUIState !== undefined && currentPopulation.CurrentUIState.currentselectedManagedPopulation !== undefined){
            return currentPopulation.CurrentUIState.currentselectedManagedPopulation;
          }
          return '';
        },

        getPopulationDefinition : function() {
          var currentPopulationDefinition = currentListState.get();
          if(currentPopulationDefinition.CurrentUIState !== undefined && currentPopulationDefinition.CurrentUIState.populationDefinition !== undefined){
            return currentPopulationDefinition.CurrentUIState.populationDefinition;
          }
          return '';
        },
        getpopulationDefinitioncancelflag : function() {
          var currentflag = currentListState.get();
          if(currentflag.CurrentUIState !== undefined && currentflag.CurrentUIState.flag !== undefined){
            return currentflag.CurrentUIState.flag;
          }
          return '';
        },
        getdeletedCriteriaIds :function() {
          var currentflag = currentListState.get();
          if(currentflag.CurrentUIState !== undefined && currentflag.CurrentUIState.criteriaIds !== undefined){
            return currentflag.CurrentUIState.criteriaIds;
          }
          return '';
        }
      };
      return {
        get: currentListState.get,
        set: currentListState.set,
        seletectedTaskType : currentListState.getSeletectedTaskType,
        seletectedTaskName : currentListState.getSeletectedTaskName,
        seletectedPopulation : currentListState.getSeletectedPopulation,
        populationDefintion : currentListState.getPopulationDefinition,
        populationDefinitioncancelflag:currentListState.getpopulationDefinitioncancelflag,
        deletedCriteriaIds : currentListState.getdeletedCriteriaIds,
        clear: currentListState.clear
      };
    }
  ]);

})(window.app);