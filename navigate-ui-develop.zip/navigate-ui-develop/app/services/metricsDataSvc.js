(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('metricsDataSvc',['$http','$q',
    function($http,$q){
      return {
        getStaticData: function (param) {
          param = param || 'procedures';

          return $http.get(app.api.root + param)
              .then(function(response) {
                  //console.log(response);
                  if ( response.data.results ) {
                    return response.data.results;
                  } else {
                    // invalid response
                    return $q.reject(response.data);
                  }

                }, function(response) {
                  // something went wrong
                  return $q.reject(response.data);
                });
        },

        getMetricTypeRequest :function(numeratorId) {
          return $http.get(app.api.root + 'numerators/' + numeratorId + '/values');
        },

        apiCall : function (url,methodType,metricsData){
          return $http({
            method: methodType,
            url: app.api.root + url,
            data: metricsData
          });
        },
        getMetricDataRequest :function(request){
          return $http.get(app.api.root + request);
        },
        getDenominatorDataRequest :function(){
          return $http.get(app.api.root + 'denominators?status=A&context=search');
        },

        getOperatorsRequest :function(){
          return $http.get(app.api.root + 'operators');
        },

        getMetricDetailsRequest :function(metricId){
          return $http.get(app.api.root + 'metrics/' + metricId);
        }
        
      };
    }
      
  ]);
}(window.app));