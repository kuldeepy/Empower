(function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on

  app.factory('homeURL', function() {
    return {

      getURL: function(role) {
        if (angular.lowercase(role) === 'administrator'){
          return  '/admin';
        }else if (angular.lowercase(role) === 'care manager'){
          return  '/caremanager';
        }else if (angular.lowercase(role) === 'clinic administrator'){
          return  '/clinicAdmin';
        }else if (angular.lowercase(role) === 'physician'){
          return  '/physicians';
        }else if (angular.lowercase(role) === 'insurance group provider'){
          return  '/insurance';
        }
      }
    };
  });

}(window.app));