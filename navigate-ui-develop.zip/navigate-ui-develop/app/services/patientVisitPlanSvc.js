﻿(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('patientVisitPlanSvc', ['$http', function($http) {
    return {
      getCompletedAssessments: function (patientId) {
        return $http.get(app.api.root + 'patients/'+ patientId +'/assessments?status=Closed Complete');
      },
    };
  }
  ]);

}(window.app));