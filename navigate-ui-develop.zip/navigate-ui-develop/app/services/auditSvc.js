(function (app) {
  'use strict';

  app.factory('auditSvc', ['$http', function($http) {

    function getErrors(searchFilters) {
      return $http
      .get(app.api.root + 'audits/errors', {
        params: searchFilters
      })
      .then(getResults);
    }

    function getErrorsExport(searchFilters) {
      return $http({
        method: 'get',
        url: app.api.root + 'audits/errors',
        responseType: 'arraybuffer',
        params: searchFilters,
        timeout: 5 * 60 * 1000
      }).then(function(response) {
        var mime = response.headers('Content-Type');
        var file = new Blob([response.data], {
            type: mime
          });
        var fileName = 'User Error_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
        saveAs(file, fileName);
      });
    }

    function getSessions(searchFilters) {
      return $http
      .get(app.api.root + 'audits/sessions', {
        params: searchFilters
      })
      .then(getResults);
    }

    function getSessionsExport(searchFilters) {

      return $http({
        method: 'get',
        url: app.api.root + 'audits/sessions',
        responseType: 'arraybuffer',
        params: searchFilters,
        timeout: 5 * 60 * 1000
      }).then(function(response) {
        var mime = response.headers('Content-Type');
        var file = new Blob([response.data], {
          type: mime
        });
       
        var fileName = 'User Sessions_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
        saveAs(file, fileName);
      });
    }

    function getUserActivities(searchFilters) {
      return $http
      .get(app.api.root + 'audits/user-activities', {
        params: searchFilters
      })
      .then(getResults);
    }

    function getPatientActivitiesExport(searchFilters) {
      return $http({
        method: 'get',
        url: app.api.root + 'audits/user-activities',
        responseType: 'arraybuffer',
        params: searchFilters,
        timeout: 5 * 60 * 1000
      }).then(function(response) {
        var mime = response.headers('Content-Type');
        var file = new Blob([response.data], {
          type: mime
        });
        var fileName = 'Patient Data Access Log_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
        saveAs(file, fileName);
      });
    }

    function getUserActivitiesExport(searchFilters) {
      return $http({
        method: 'get',
        url: app.api.root + 'audits/user-activities',
        responseType: 'arraybuffer',
        params: searchFilters,
        timeout: 5 * 60 * 1000
      }).then(function(response) {
        var mime = response.headers('Content-Type');
        var file = new Blob([response.data], {
          type: mime
        });
        var fileName = 'User Activity Report_' + moment().format('MM-DD-YYYY HH:mm:ss') + '.csv';
        saveAs(file, fileName);
      });
    }

    function getUserActivityResources(searchFilters) {
      return $http
      .get(app.api.root + 'audits/user-activities/resources', {
        params: searchFilters
      })
      .then(getResults);
    }

    function getUserActivityUserNames() {
      return $http
      .get(app.api.root + 'audits/user-activities/users/names')
      .then(getResults);
    }

    function getUserActivityPatientNames() {
      return $http
      .get(app.api.root + 'audits/user-activities/patients/names')
      .then(getResults);
    }

    function getUserActivityPatientMrns() {
      return $http
      .get(app.api.root + 'audits/user-activities/patients/mrns')
      .then(getResults);
    }

    function getResults(httpResults) {
      return httpResults.data.results;
    }

    return {
      errors: getErrors,
      errorsExport: getErrorsExport,
      sessions: getSessions,
      sessionsExport: getSessionsExport,
      userActivities: getUserActivities,
      userActivitiesExport: getUserActivitiesExport,
      patientActivitiesExport: getPatientActivitiesExport,
      userActivityResources: getUserActivityResources,
      userActivityUserNames: getUserActivityUserNames,
      userActivityPatientNames: getUserActivityPatientNames,
      userActivityPatientMrns: getUserActivityPatientMrns
    };
  }]);

})(window.app);