(
  function (app) {
    // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('CareManagerData', ['$q','authSvc',
    function ($q,authSvc) {
      var careManager = {
        id : authSvc.getUserId(),
        filter : {
          userId : authSvc.getUserId(),
          managedPopulations : '',
          taskTypes: '',
          primaryCarePhysicians: '',
          careTeamMembers: '',
          taskSpecificTypes: ''
        },
        filtersReady : $q.defer(),
        requery : false
      };
      return careManager;
    }
  ]);
}(window.app));