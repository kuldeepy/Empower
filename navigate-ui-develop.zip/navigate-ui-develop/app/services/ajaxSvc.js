/*
  Simple wrapper of $.ajax, in an angular service so it can be injected/mocked.
  Only needed when injecting http service would create circular dependency.
*/
app.factory('ajaxSvc', function() {
  'use strict';
  return $.ajax;
});