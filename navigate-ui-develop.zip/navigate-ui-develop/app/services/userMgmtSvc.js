(function (app) {
  'use strict';

  app.factory('userMgmtSvc', ['$http', function($http) {
    return {
      users: function() {
        return $http
          .get(app.api.root + 'users')
          .then(
            // success
            function(response) {
              var data = response.data.results.users;
              return data;
            },
            // error
            function(err) {
              if (err) {
                return err;
              }
            });
      },

      user: function(id) {
        return $http
          .get(app.api.root + 'users/' + id).then(
            function(response) {
              var user = response.data.results;
              return user;
            },
            function(err) {
              if (err) { return err; }
            }
          );
      },

      saveUserPassword: function(id, data) {
        return $http.put(app.api.root+ 'users/' + id + '/password', data);
      },

      editUserId: {}

    };
  }]);

})(window.app);