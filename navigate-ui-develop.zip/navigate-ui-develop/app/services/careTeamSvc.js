(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('careTeamSvc', ['$http', 'authSvc', function ($http, authSvc) {
    return {
      getRequest: function(requestpath,params) {
        $http.defaults.headers.common['cache-control'] = 'no-cache';
        return $http.get(app.api.root + requestpath, {params: params});
      },

      GetActiveCareTeams: function (params) {
        return $http.get(app.api.root + 'care-teams',{params:params});
      },
      getActiveCareTeamsCount: function(id) {
        return $http.get(app.api.root +'care-teams/'+id+'/status');
      },
      getAppliedTaskFilter: function () {
        return $http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/task-filter');
      },
      postAppliedTaskFilter: function (objectbody) {
        return $http.post(app.api.root + 'providers/'+ authSvc.user().providerId+ '/task-filter' , objectbody);
      },

      postRequest: function(requestpath,objectbody) {
        return $http.post(app.api.root + requestpath,objectbody);
      },

      putRequest: function(requestpath,objectbody) {
        return $http.put(app.api.root + requestpath,objectbody);
      },

      deleteRequest: function(requestpath) {
        return $http.delete(app.api.root + requestpath);
      }
    };
  }
  ]);


}(window.app));