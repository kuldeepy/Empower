(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('taskBundleDataSvc',['$http','$q',
    function(http,q){

        var taskBundleData = {

          getStaticData: function (param) {
            param = param || 'procedures';

            return http.get(app.api.root + param)
                .then(function(response) {
                    //console.log(response);
                    if ( response.data.results ) {
                      return response.data.results;
                    } else {
                      // invalid response
                      return q.reject(response.data);
                    }

                  }, function(response) {
                    // something went wrong
                    return q.reject(response.data);
                  });
          },

          getTaskBundlesByName : function(name){
            return http.get(app.api.root + 'task-bundles?name=' + name);
          },
          getInActiveTaskBundles : function(Id){
            return http.get(app.api.root + 'managed-populations/task-bundles/'+Id);
          },
          getActiveTaskBundles : function(){
            return http.get(app.api.root + 'task-bundles?productionStatus=Final&statusCode=' + true);
          }
        };
        return {
          getActiveTaskBundles : taskBundleData.getActiveTaskBundles,
          getTaskBundlesByName : taskBundleData.getTaskBundlesByName,
          getStaticData : taskBundleData.getStaticData,
          getInActiveTaskBundles:taskBundleData.getInActiveTaskBundles
        };
      }
      
  ]);
}(window.app));