(function (app) {
  'use strict';

  app.factory('downloadCsv', [function() {

    function exportToCsv(fileName, data, columnHeaders, columnFields, title) {
      var csvResult = '';
      if(title !== undefined) { csvResult = title + '\n'; }
      csvResult = csvResult + columnHeaders.toString() + '\n';
      if(columnFields.length > 0)
      {
        angular.forEach(data, function (item){
            var row = [];
            angular.forEach(columnFields,  function (field){
              if(item[field] !== null && isNaN(item[field])) {
                row.push(item[field].indexOf(',') === -1 ? item[field] : '"' + item[field] + '"');
              }
              else { row.push(item[field]); }
            });
            csvResult = csvResult + row.toString() + '\n';
          });
      }
      else
      {
        angular.forEach(data, function (record){
          var row = [];
          angular.forEach(record, function (item){
            if(item !== null && isNaN(item)) {
              row.push(item.indexOf(',') === -1 ? item : '"' + item + '"');
            }
            else { row.push(item); }
          });
          csvResult = csvResult + row.toString() + '\n';
        });
      }
      fileName = fileName + '_' + moment().format('MM-DD-YYYY HH:mm:ss') +'.csv';
      var blob = new Blob([csvResult], {type:'data:text/csv'});
      window.saveAs(blob, fileName);
    }

    return {
      toCSV: exportToCsv
    };
  }]);

})(window.app);