(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('programStatusReportSvc', ['$http', function($http) {
    return {
      getCodeSetPrograms: function() {
        return $http.get(app.api.root + 'reports/codeset-programs');
      },
      getProgramStatus: function(objectbody) {
        return $http.get(app.api.root + 'reports/program-status-report',{params: objectbody});
      },
      getProgramStatusDetails: function(objectbody) {
        return $http.get(app.api.root + 'reports/program-status-details',{params: objectbody});
      }
      
    };
  }
  ]);


}(window.app));
