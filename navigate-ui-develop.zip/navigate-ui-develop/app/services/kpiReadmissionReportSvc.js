(function (app) {
  'use strict';

  app.factory('kpiReadmissionReportSvc', ['$http',
    function (http) {
        return{
          getDateKeyRequest : function () {
            return http.get(app.api.root + 'reports/kpi-readmission/date-keys');
          },
          getKpiReadmissionReportRequest : function (filterData) {
            return http.get(app.api.root + 'reports/kpi-readmission/patients', {params: filterData});
          }
        };
      }
    ]);
})(window.app);