(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('missedOpportunityReportSvc', ['$http', function($http) {
    return {
      getManagedPopulationsRequest: function() {
        return $http.get(app.api.root + 'reports/missed-opportunity/managed-populations');
      },
      getTasksRequest: function() {
        return $http.get(app.api.root + 'reports/missed-opportunity/tasks');
      },
      getCareTeamRequest: function() {
        return $http.get(app.api.root + 'reports/missed-opportunity/care-teams');
      },
      getCareTeamMembersRequest: function() {
        return $http.get(app.api.root + 'reports/missed-opportunity/care-team-members');
      },
      getMissedOpportunityRequest: function(params) {
        return $http.get(app.api.root + 'reports/missed-opportunity', {params: params});
      },
      getMissedOpportunityReportRequest: function(patientId,params) {
        return $http.get(app.api.root + 'patient/'+patientId+'/missed-opportunity-report', {params: params});
      }
    };
  }
  ]);


}(window.app));
