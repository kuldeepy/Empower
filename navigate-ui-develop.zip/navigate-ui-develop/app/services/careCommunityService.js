﻿(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('careCommunitySvc', ['$http', 'PatientData', function ($http, PatientData) {
      var patientId = PatientData.id;
      var patientRelations;
      patientRelations = '';

      return {
        getCareCommunities: function (objectbody) {
          return $http.get(app.api.root + 'patients/'+ patientId + '/care-communities?type=' + objectbody);
        },

        getCareCommunity: function (objectbody) {
          return $http.get(app.api.root + 'patients/' + patientId + '/care-communities/' + objectbody);
        },

        postCareCommunity: function (objectbody) {
          return $http.post(app.api.root + 'patients/'+ patientId +'/care-community', objectbody);
        },
        
        putCareCommunity: function (objectbody) {
          return $http.put(app.api.root + 'patients/'+ patientId + '/care-communities', objectbody);
        },

        deleteCareCommunity: function (objectbody) {
          return $http.delete(app.api.root + 'patients/' + patientId + '/care-communities/' + objectbody);
        },

        getRelationShip: function () {
          return $http.get(app.api.root + 'patient-relations');
        }
      };
    }
    ]);
}(window.app));