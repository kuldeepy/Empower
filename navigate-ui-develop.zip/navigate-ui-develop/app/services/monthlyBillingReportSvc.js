(function (app) {
  'use strict';

  app.factory('monthlyBillingReportSvc', ['$http',
    function (http) {
        return{
          getDateKeyRequest : function () {
            return http.get(app.api.root + 'reports/monthly-billing/date-keys');
          },
          getMonthlyBillingRequest : function (filterData) {
            return http.get(app.api.root + 'reports/monthly-billing/patients-details', {params: filterData});
          }
        };
      }
    ]);
})(window.app);