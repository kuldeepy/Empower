(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('modalService',['$modal',
    function($modal){

        var modalDefaults = {
            backdrop: true,
            keyboard: true,
            modalFade: true,
            templateUrl: app.root + 'templates/genericModal.html'
          };

        var modalOptions = {
            closeButtonText: 'Close',
            actionButtonText: 'OK',
            headerText: 'Proceed?',
            bodyText: 'Perform this action?'
          };

        var mdServ = {

          getSettings:function(opt){
              if(opt === 'defaults'){
                return modalDefaults;
              }
              else if (opt === 'options'){
                return modalOptions;
              }
            },

          showModal:function (customModalDefaults, customModalOptions) {
              if (typeof customModalDefaults === 'undefined' || customModalDefaults === false){
                customModalDefaults = {};
              }
              customModalDefaults.backdrop = 'static';
              return this.show(customModalDefaults, customModalOptions);
            },

          show:function (customModalDefaults, customModalOptions) {
              //Create temp objects to work with since we're in a singleton service
              var tempModalDefaults = {};
              var tempModalOptions = {};

              //Map angular-ui modal custom defaults to modal defaults defined in service
              angular.extend(tempModalDefaults, modalDefaults, customModalDefaults);

              //Map modal.html $scope custom properties to defaults defined in service
              angular.extend(tempModalOptions, modalOptions, customModalOptions);

              if (!tempModalDefaults.controller) {
                tempModalDefaults.controller = function ($scope, $modalInstance) {
                      $scope.modalOptions = tempModalOptions;
                      //$scope.roles = roles; $scope.user = user;
                      $scope.modalOptions.ok = function (result) {
                          $modalInstance.close(result);
                        };
                      $scope.modalOptions.close = function () {
                          $modalInstance.dismiss('cancel');
                        };
                    };
              }
              //tempModalOptions.user = user;tempModalOptions.roles = roles;
              return $modal.open(tempModalDefaults).result;
            }

        };

        return mdServ;
      }
  ]);
}(window.app));