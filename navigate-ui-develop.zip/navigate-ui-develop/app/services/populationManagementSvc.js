(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('populationManagementSvc', ['$http', function($http) {
    return {
      getPopulations: function() {
        return $http.get(app.api.root + 'managed-populations?statusCode=A&productionStatus=F');
      },

      getPatientPopulations: function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/patient-populations');
      },

      getPatientDisenrolledPopulations: function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/disenrolled-populations');
      },


      getPatientPopulationsByType: function(id,Type) {
        return $http.get(app.api.root + 'patients/' + id + '/Populations-type/' + Type);
      },

      addPopulation: function(id, objectbody) {
        return $http.post(app.api.root + 'patients/' + id + '/patient-populations',objectbody);
      },

      deletePopulation: function (id, populationId, patientProgramId, reason, disenrollReasonId,disenrollType) {
        return $http.delete(app.api.root + 'patients/' + id + '/patient-populations/' + populationId +'?patientProgramId=' + patientProgramId +'&reasonDetails=' + reason+'&reasonId=' + disenrollReasonId+'&status=' + disenrollType);
      },
      getAlldisenrollmentReason: function () {
        return $http.get(app.api.root + 'disenrollment-reasons',{cache : true});
      },
      getManagedPopulationCareTeamMembers: function(programId) {
        return $http.get(app.api.root + 'managed-populations/'+ programId + '/care-team-members');
      },
      updatePatientCareLead: function(patientId, objectbody){
        return $http.put(app.api.root + 'patients/' + patientId +'/reassign-care-lead', objectbody);
      },
      getCareLeadReassignStatus: function(programId, providerId){
        return $http.get(app.api.root + 'managed-population/' + programId +'/care-lead/' + providerId + '/status');
      }
    };
  }
  ]);


}(window.app));
