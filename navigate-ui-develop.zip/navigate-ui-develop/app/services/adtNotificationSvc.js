(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('adtNotificationSvc', ['$http', function($http) {
    return {
      getFiltersRequest: function() {
        return $http.get(app.api.root + 'filters');
      },
      getNotificationsRequest: function(params,providerId) {
        return $http.get(app.api.root +'Provider/' + providerId + '/notifications',{params:params});
      },
      putAdtNotificationRequest: function(objectbody,providerId) {
        return $http.put(app.api.root +'Provider/' + providerId + '/notifications', objectbody);
      },
      checkMergeNotificationDependencies: function(PatientEventNotificationId) {
        return $http.get(app.api.root + 'patient-event-notifications/'+ PatientEventNotificationId + '/dependencies');
      }
    };
  }
  ]);


}(window.app));
