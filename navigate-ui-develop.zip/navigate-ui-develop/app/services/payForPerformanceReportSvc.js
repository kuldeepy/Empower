(function (app) {
  'use strict';

  app.factory('payForPerformanceReportSvc', ['$http','authSvc',
    function (http,authSvc) {
        return{
          getLatestDateKeyRequest: function () {
            return http.get(app.api.root + 'latestdatekey?reporttype=payforperformance');
          },

          getClinicsRequest: function (dateKey) {
            return http.get(app.api.root + 'clinics?context=report&key=' +dateKey);
          },

          getInsurancePlansRequest : function () {
            return http.get(app.api.root + 'insurance-plans?context=Report');
          },

          getProductsRequest : function () {
            return http.get(app.api.root + 'products?context=Report');
          },

          getGraphDataRequest : function (filterData) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/pay-for-performance?payForPerformanceReport='+ filterData);
          },

          getAllMetricsRequest : function (populationConditionId,metricType,filterData) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/pay-for-performance/'+populationConditionId+'/metrics?metricType=' +metricType , {params : filterData});
          },

          getPhysiciansRequest : function (filter,dateKey) {
            return http.get(app.api.root + 'clinics/'+filter+'/physicians?key=' +dateKey+ '&context=Report');
          },

          getConditonsTrendRequest : function (filter) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/pay-for-performance/trend?payForPerformanceTrend=' +filter);
          },

          getMetricsTrendRequest :  function (params) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/pay-for-performance/metric-trend', {params: params});
          }
        };
      }
    ]);
})(window.app);