(function (app) {
  'use strict';

  function createNewMetricsConfig() {
    return { 'CurrentUIState': {} };
  }
  //metricsConfigStateSvc  taskBundleStateSvc currentMetricsConfigState metricsConfigState
  app.factory('metricsConfigStateSvc', ['sessionSvc',
    function (sessionSvc) {
      var currentMetricsConfigState = {
        get: function () {
          var state = sessionSvc.get('metricsConfigState');
          if (state === undefined || state === null || state === '{}') {
            return createNewMetricsConfig();
          }
          return JSON.parse(state);
        },
        set: function (metricsConfigState) {
          if (metricsConfigState === undefined || metricsConfigState === null) {
            sessionSvc.clear('metricsConfigState');
          }
          else {
            sessionSvc.set('metricsConfigState', JSON.stringify(metricsConfigState));
          }
        },
        clear: function () {
          sessionSvc.clear('metricsConfigState');
        },

        //getGeneralInformation: function () {
        //  var currentGeneralInformationState = currentMetricsConfigState.get();
        //  if (currentGeneralInformationState.CurrentUIState !== undefined && currentGeneralInformationState.CurrentUIState.currentTaskType !== undefined) {
        //    return currentGeneralInformationState.CurrentUIState.currentTaskType;
        //  }
        //  return '';
        //},

        getSeletectedMetricsConfigName: function () {
          var currentTask = currentMetricsConfigState.get();
          if (currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.currentTaskName !== undefined) {
            return currentTask.CurrentUIState.currentTaskName;
          }
          return '';
        },

        getSeletectedMetricsConfigDesc: function () {
          var currentTask = currentMetricsConfigState.get();
          if (currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.currentTaskDesc !== undefined) {
            return currentTask.CurrentUIState.currentTaskDesc;
          }
          return '';
        },
        
        getSeletectedMetricsConfigStatus: function () {
          var currentTask = currentMetricsConfigState.get();
          if (currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.currentTaskStatus !== undefined) {
            return currentTask.CurrentUIState.currentTaskStatus;
          }
          return '';
        },

        getSeletectedEduBundlename: function () {
          var currentTask = currentMetricsConfigState.get();
          if (currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.eduBundleName !== undefined) {
            return currentTask.CurrentUIState.eduBundleName;
          }
          return '';
        },


        //getSeletectedPopulation: function () {
        //  var currentPopulation = currentMetricsConfigState.get();
        //  if (currentPopulation.CurrentUIState !== undefined && currentPopulation.CurrentUIState.currentselectedManagedPopulation !== undefined) {
        //    return currentPopulation.CurrentUIState.currentselectedManagedPopulation;
        //  }
        //  return '';
        //}

      };
      return {
        get: currentMetricsConfigState.get,
        set: currentMetricsConfigState.set,
        selectedTaskBundleName: currentMetricsConfigState.getSeletectedMetricsConfigName,
        selectedTaskBundleDesc: currentMetricsConfigState.getSeletectedMetricsConfigDesc,
        selectedTaskBundleStatus: currentMetricsConfigState.getSeletectedMetricsConfigStatus,
        /*selectedEduBundlename: currentMetricsConfigState.getSeletectedEduBundlename,*/
        //seletectedTaskType: currentMetricsConfigState.getSeletectedTaskType,
        //seletectedTaskName: currentMetricsConfigState.getSeletectedTaskName,
        //seletectedPopulation: currentMetricsConfigState.getSeletectedPopulation,
        clear: currentMetricsConfigState.clear
      };
    }
  ]);

})(window.app);