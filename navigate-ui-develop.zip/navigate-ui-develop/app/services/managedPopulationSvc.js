(function (app) {
  'use strict';

  app.factory('managedPopulationSvc', ['$http',
    function (http) {
      var managedPopulationPath = app.api.root + 'managed-populations/';
      
      var service = {

        assessmentTaskType :'Q',
        otherTaskType :'O',
        procedureTaskType :'P',
        educationTaskType : 'E',
        isAddedSuccesfully : false,
        messageAlert : '',
        managedPopulationId : 0,
        taskConflicts : [],
        editSummaryStatus : '',
        editStatus : false,
        nonTaskConflicts : [],
        taskBundles : [],
        taskConflictsResolved : [],
        taskResolvedGrouped : [],
        taskResolvedGroupedManual : [],
        summarytasks : [],
        hasInitEdit : false,
        taskResolvedEdit : false,
        postManagedPopulation: function (data,url) {
          return http.post(url, data);
        },
       
        savePopulationDefination: function (managedPopulationId,data) {
          var path = managedPopulationPath + managedPopulationId +'/population-definition';
          return service.postManagedPopulation(data,path);
        },

        updateTaskBundleReminders: function (managedPopulationId,data) {
          var path = managedPopulationPath + managedPopulationId +'/task-bundles/reminders';
          return http.put(path, data);
        },

        saveTaskBundles: function (managedPopulationId,data) {
          var path = managedPopulationPath + managedPopulationId +'/task-bundles';
          return service.postManagedPopulation(data,path);
        },
        saveTaskBundleConflictResolution: function (managedPopulationId,data) {
          var path = managedPopulationPath + managedPopulationId + '/task-bundles/conflict-resolutions';
          return service.postManagedPopulation(data,path);
        },
        getmanagedPopulationDefinition: function (managedPopulationId) {
          return http.get(managedPopulationPath + managedPopulationId +'/population-definition');
        },

        getTaskBundleTasks: function (managedPopulationId) {
          return http.get(managedPopulationPath + managedPopulationId +'/task-bundles/tasks');
        },

        getManagedPopulationsById : function(managedPopulationId) {
          return http.get(managedPopulationPath + managedPopulationId);
        },
        getRemindersByManagedPopulationId : function(managedPopulationId) {
          return http.get(managedPopulationPath + managedPopulationId + '/reminders');
        },
        getManagedPopulations: function () {
          return http.get(managedPopulationPath);
        },

        getManagedPopulationCareTeams: function (managedPopulationId) {
          return http.get(managedPopulationPath+ managedPopulationId +'/care-teams');
        },

        getManagedPopulationTaskBundles: function (managedPopulationId) {
          return http.get(managedPopulationPath+ managedPopulationId +'/task-bundles');
        },

        getManagedPopulationPatients: function (populationDefinitionId,managedPopulationId,productionStatus,params) {
          if(managedPopulationId > 0 && productionStatus === 'F' ){
            return http.get(app.api.root + 'managed-populations/'+managedPopulationId+'/patients', {params: params},{cache : true});
          }
          else{
            return http.get(app.api.root + 'population-definitions/'+populationDefinitionId+'/patients', {params: params},{cache : true});
          }
        },

        getTaskBundleReminders: function (taskBundleId) {
          return http.get(managedPopulationPath + 'task-bundles/'+ taskBundleId +'/reminders');
        },

        getcommunicationTypes: function () {
          return http.get(app.api.root + 'communication-types',{cache : true});
        },

        checkManagedPopulation: function (managedPopulationName) {
          return http.get(managedPopulationPath + '?name=' + managedPopulationName)
          .then(
            //success
            function(response) {
              var managedPopulationExists = false;
              var data = response.data.results;
              for(var i = 0; i < data.length; i = i+1)
              {
                if(data[i].name.toUpperCase() === managedPopulationName.toUpperCase())
                {
                  managedPopulationExists = true;
                  break;
                }
              }
              return managedPopulationExists;
            }
          );
        },

        updateGeneralInformation: function (data) {
          if(data.StatusDescription === 'Active'){
            data.statusCode = 'A';
          }
          if(data.StatusDescription === 'Inactive'){
            data.statusCode = 'I';
          }
          return http.put(managedPopulationPath + data.populationId, data);
        },

        saveGeneralInformation: function (data) {
          if(data.StatusDescription === 'Active'){
            data.statusCode = 'A';
          }
          if(data.StatusDescription === 'Inactive'){
            data.statusCode = 'I';
          }
          return http.post(managedPopulationPath, data);
        },
        
        saveManagedPopulation: function (data) {
          if( data.id < 1 )
          {
            return http.post(managedPopulationPath, data);
          }
          else
          {
            return http.put(managedPopulationPath + data.id, data);
          }
        },

        getTaskConflicts: function (taskbundleIds) {
          return http.get(app.api.root + 'task-conflicts?taskBundleIds=' + taskbundleIds);
        }
      };

      return {
        saveGeneralInformation: service.saveGeneralInformation,
        saveManagedPopulation: service.saveManagedPopulation,
        getManagedPopulationCareTeams: service.getManagedPopulationCareTeams,
        getManagedPopulationTaskBundles: service.getManagedPopulationTaskBundles,
        savePopulationDefination: service.savePopulationDefination,
        getManagedPopulationsById: service.getManagedPopulationsById,
        getRemindersByManagedPopulationId: service.getRemindersByManagedPopulationId,
        getTaskBundleReminders:service.getTaskBundleReminders,
        saveTaskBundles: service.saveTaskBundles,
        saveTaskBundleConflictResolution: service.saveTaskBundleConflictResolution,
        getManagedPopulation: service.getManagedPopulation,
        getTaskBundleTasks: service.getTaskBundleTasks,
        getManagedPopulations: service.getManagedPopulations,
        getManagedPopulationPatients  : service.getManagedPopulationPatients,
        updateTaskBundleReminders: service.updateTaskBundleReminders,
        saveTaskBundleReminders: service.saveTaskBundleReminders,
        isAddedSuccesfully : service.isAddedSuccesfully,
        messageAlert : service.messageAlert,
        assessmentTaskType : service.assessmentTaskType,
        managedPopulationId : service.managedPopulationId,
        otherTaskType : service.otherTaskType,
        procedureTaskType : service.procedureTaskType,
        educationTaskType : service.educationTaskType,
        getcommunicationTypes : service.getcommunicationTypes,
        getmanagedPopulationDefinition : service.getmanagedPopulationDefinition,
        updateGeneralInformation : service.updateGeneralInformation,
        taskConflicts : service.taskConflicts,
        editSummaryStatus : service.editSummaryStatus,
        editStatus : service.editStatus,
        nonTaskConflicts : service.nonTaskConflicts,
        taskBundles : service.taskBundles,
        getTaskConflicts : service.getTaskConflicts,
        checkManagedPopulation : service.checkManagedPopulation,
        taskResolvedGrouped : service.taskResolvedGrouped,
        taskResolvedGroupedManual : service.taskResolvedGroupedManual,
        summarytasks : service.summarytasks,
        hasInitEdit : service.hasInitEdit,
      };
    }
  ]);

})(window.app);