(function (app) {
  'use strict';

  app.factory('authInterceptor', ['$rootScope', '$q', '$window', 'authSvc', function ($rootScope, $q, $window, authSvc) {
    return {
      request: function (config) {
        config.headers = config.headers || {};
        var user = authSvc.user();
        if (user.token) {
          config.headers.Authorization = 'Bearer ' + user.token;
        }
        return config;
      },
      responseError: function (rejection) {
        if (rejection.status === 401) {
          // handle the case where the user is not authenticated
        }
        return $q.reject(rejection);
      }
    };
  }]);

  app.factory('authSvc', ['$injector', function($injector) {
    var careManagerRole = 'care manager';
    var adminRole = 'administrator';
    var navigateSessionKeyPrefix = 'Navigate.user.session.';
    var daysLeft = 0;
    // logout() is located in CareManagerCtrl
    function setUser(value) {

      setSession('user.id', value.id);
      setSession('user.sessionId', value.sessionId);
      setSession('user.token', value.token);
      setSession('user.username', value.username);
      setSession('user.role', value.role);
      setSession('user.providerId', value.providerId);
      setSession('user.providerName', value.providerName);
      setSession('user.isAuthenticated', value.isAuthenticated);
      setSession('user.lastPasswordChangedDate', value.lastPasswordChangedDate);
      sessionStorage.setItem('hidePasswordNotification',false);
      setSession('user.sessionExpireMinutes', value.sessionExpireMinutes);
    }

    function getSession(key) {
      return sessionStorage.getItem(navigateSessionKeyPrefix + key);
    }
    
    function setSession(key, value) {
      if (value === undefined || value === null) {
        clearSession(key);
      }
      else {
        sessionStorage.setItem(navigateSessionKeyPrefix + key, value);
      }
    }

    function clearSession(key) {
      sessionStorage.removeItem(navigateSessionKeyPrefix + key);
    }

    function clearUserSession() {
      clearSession('user.id');
      clearSession('user.sessionId');
      clearSession('user.token');
      clearSession('user.username');
      clearSession('user.role');
      clearSession('user.providerId');
      clearSession('user.providerName');
      clearSession('user.isAuthenticated');
      clearSession('user.lastPasswordChangedDate');
      clearSession('user.sessionExpireMinutes');
    }

    function getUser() {
      return {
        id: getSession('user.id'),
        sessionId: getSession('user.sessionId'),
        token: getSession('user.token'),
        username: getSession('user.username'),
        role: getSession('user.role'),
        providerId: getSession('user.providerId'),
        providerName: getSession('user.providerName'),
        isAuthenticated: getSession('user.isAuthenticated'),
        lastPasswordChangedDate: getSession('user.lastPasswordChangedDate'),
        sessionExpireMinutes: getSession('user.sessionExpireMinutes')
      };
    }

    function getLastChangedPasswordDays() {
      
      var date1 = new Date(getSession('user.lastPasswordChangedDate'));
      var date2 = new Date();

      var _MS_PER_DAY = 1000 * 60 * 60 * 24;
      // Discard the time and time-zone information.
      var utc1 = Date.UTC(date1.getFullYear(), date1.getMonth(), date1.getDate());
      var utc2 = Date.UTC(date2.getFullYear(), date2.getMonth(), date2.getDate());

      return (app.changePassword.expireIn - Math.floor((utc2 - utc1) / _MS_PER_DAY));

    }

    function setDaysLeft(noOfDays){
      daysLeft = noOfDays;
    }

    function getChangePasswordReminderDays() {

      return app.changePassword.remind.indexOf(daysLeft.toString()) > -1 ? true : false;
    }
    return {
      user: function(value) {
        if (value) {
          setUser(value);
        }
        return getUser();
      },
      isAuthenticated: function() {
        return !!getSession('user.token');
      },
      getUserId: function () {
        return getSession('user.providerId');
      },
      clearUserSessionDetails: function () {
        return clearUserSession();
      },
      getLastChangedPasswordDays: function () {
        return getLastChangedPasswordDays();
      },
      getChangePasswordReminderDays: function (daysleft) {
        if (daysleft) {
          setDaysLeft(daysleft);
        }
        return getChangePasswordReminderDays();
      },
      hasEditAccess : function(){
        var userDeatils = getUser();
        var hasAccess = (angular.lowercase(userDeatils.role) === adminRole) || (angular.lowercase(userDeatils.role) === careManagerRole);
        return hasAccess;
      },
      logout: function () {
        //Added token headers explicitly.So, clearing the user session details is not dependent on audit API call.
        var authHeaders = { 'Authorization': 'Bearer ' + getUser().token };
        $injector.invoke(function($http) {
          $http.delete(app.api.root + 'session-tokens', { headers: authHeaders });
        });
        clearUserSession();
      },
      login: function(username, password) {
        var body = {
          username: username,
          password: password
        };
        return $injector.invoke(function($http) {
          return $http.post(app.api.root + 'session-tokens', body)
          .then(function(response) {
            if(response.status === 201) {
              return { success: true, response: response.data };
            }
            return { success: false, response: response.data };
          });
        });
      },
      switchRole: function(role, providerId) {
        var body = { role: role, providerId: providerId };
        var authHeaders = { 'Authorization': 'Bearer ' + getUser().token };
        return $injector.invoke(function($http) {
          return $http.put(app.api.root + 'session-tokens', body, { headers: authHeaders })
          .then(function(response) {
            if(response.status === 201) {
              return { success: true, response: response.data };
            }
            return { success: false, response: response.data };
          });
        });
      },
      renewToken: function(){
        var user = getUser();
        if(user && user.isAuthenticated){
          var body = { role: user.role, providerId: parseInt(user.providerId) };
          var authHeaders = { 'Authorization': 'Bearer ' + user.token };
          return $injector.invoke(function($http) {
            return $http.put(app.api.root + 'session-tokens', body, { headers: authHeaders })
            .then(function(response) {
              if(response.status === 201) {
                setSession('user.token', response.data.results.roles[0].token);
                return { success: true, response: response.data };
              }
              return { success: false, response: response.data };
            });
          });
        }
      }
    };
  }]);

  app.ng.config(['$httpProvider', function ($httpProvider) {
    $httpProvider.interceptors.push('authInterceptor');
  }]);

})(window.app);
