(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('userConcurrentLockSvc', ['$http', 'authSvc', function($http, authSvc) {
    return {
      putLockConcurrentTask: function(objectbody) {
        return $http.put(app.api.root + 'users/'+ authSvc.user().id + '/concurrent-locks', objectbody);
      }
    };
  }
  ]);


}(window.app));
