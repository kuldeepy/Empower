(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('reportDataSvc',['$http','$q','authSvc',
    function(http,$q,authSvc){

        return {

          getStaticData: function (param) {
            param = param;

            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId +'/'+ param)
                .then(function(response) {
                    if ( response.data.results ) {
                      return response.data.results;
                    } else {
                      // invalid response
                      return $q.reject(response.data);
                    }

                  }, function(response) {
                    // something went wrong
                    return $q.reject(response.data);
                  });
          },

          getLatestDateKeyRequest: function () {
            return http.get(app.api.root + 'latestdatekey?reporttype=comorbidity');
          },

          getClinicsRequest: function (dateKey) {
            return http.get(app.api.root + 'clinics?context=report&key=' +dateKey);
          },

          getInsurancePlansRequest : function () {
            return http.get(app.api.root + 'insurance-plans?context=Report');
          },

          getProductsRequest : function () {
            return http.get(app.api.root + 'products?context=Report');
          },

          getComorbidityConditionsRequest : function (keyValue,urlClinicFilter) {
            return http.get(app.api.root + 'conditions?context=Report&key='+keyValue + urlClinicFilter);
          },

          getBindGridRequest : function (popupURL, pageIndex, pageSize, sortType, sortName) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/'+ popupURL + '&pageIndex=' + pageIndex + '&pageSize=' + pageSize +'&sortType=' +sortType + '&sortName=' +sortName);
          },

          getPhysiciansRequest : function (filter,dateKey) {
            return http.get(app.api.root + 'clinics/'+filter+'/physicians?context=Report&key=' +dateKey);
          },

          getMergePatient: function (id) {
            return http.get(app.api.root + 'patients/' + id + '/merge');
          }

        };
      }
      
  ]);
}(window.app));