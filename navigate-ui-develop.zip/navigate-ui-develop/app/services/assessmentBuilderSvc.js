(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('assessmentBuilderSvc', ['$http', function($http) {

      var service = {
        questionAnswers :[],
        productionStatus : 'F',
        saveNotificationMsg : null
      };

      return {
        questionAnswers : service.questionAnswers,
        saveNotificationMsg : service.saveNotificationMsg,
        getRequest: function(requestpath,params) {
          $http.defaults.headers.common['cache-control'] = 'no-cache';
          return $http.get(app.api.root + requestpath, {params: params});
        },

        getAssessments: function(name,description,status,productionStatus) {

          var assessmentName = window.encodeURIComponent(name);
          var assessmentDescription = window.encodeURIComponent(description);

          return $http.get(app.api.root + 'questionnaires?name='+ assessmentName + '&description=' + assessmentDescription + '&status=' + status +'&productionStatus=' + productionStatus);
        },

        getAnswerTypeList: function() {
          return $http.get(app.api.root + 'answer-types');
        },

        saveQuestionnaire: function(objectbody) {
          return $http.post(app.api.root + 'questionnaire',objectbody);
        },
        updateQuestionnaire: function(objectbody) {
          return $http.put(app.api.root + 'questionnaire',objectbody);
        },
        putRequest: function(requestpath,objectbody) {
          return $http.put(app.api.root + requestpath,objectbody);
        },

        deleteRequest: function(requestpath) {
          return $http.delete(app.api.root + requestpath);
        },

        getAssessmentDetailsById: function(assessmentId) {
          return $http.get(app.api.root + 'questionnaires/' + assessmentId );
        }
      };
    }
    ]);
}(window.app));