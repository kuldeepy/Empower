(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('populationDefinitionSvc', ['$http', function($http) {
    return {
      populationDefinitionGetData: function(resource) {
        return $http
        .get(app.api.root + resource)
        .then(
          // success
          function(response) {
            return response;
          },
          // error
          function(err) {
            if(err){
              return (err);
            }
          });
      },
      populationDefinitionPutData: function(resource,scopeUpdateData){
        return $http
        .put(app.api.root +resource,scopeUpdateData)
        .then(
          // success
          function(response) {
            return response;
          },
         // error
         function(err) {
            if(err){
              return (err);
            }
          });
      },
      populationDefinitionPostData: function(resource,scopeUpdateData){
        return $http
        .post(app.api.root +resource,scopeUpdateData)
        .then(
          // success
          function(response) {
            return response;
          },
         // error
         function(err) {
            if(err){
              return (err);
            }
          });
      },
      populationDefinitiondeleteRequest: function(requestpath) {
        return $http
        .delete(app.api.root + requestpath)
        .then(
          function(response) {
            return response;
          },
          function(err) {
            if(err){
              return (err);
            }
          });
      },
      isAddedSuccesfully: false,
      messageAlert: ''
    };
  }
  ]);

}(window.app));