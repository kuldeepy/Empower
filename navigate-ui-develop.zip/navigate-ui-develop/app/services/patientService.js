(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('PatientData',[
    function(){
      var patientZero = {
        isTaskAddedSuccesfully : false,//Set this flag to true when patient task is added successfully to notify task controller 
        id : 12,
        isMenuDirty : false,  //Set this flag to true to notify the patient controller it needs to update it's menu
        isFavoriteFlag : true,
        isMenuStatus :true,

        formatName : function(name) {
          var formattedName = '',
          pos;

          if (name === null) { return null; }

          pos = name.lastIndexOf(' ');
          if (pos > 0) {
            formattedName = name.slice(pos + 1) + ' ' + name.slice(0, pos);

          }
          else {
            formattedName = name;
          }

          return formattedName;
        }
      };
      return patientZero;
    }
  ]);
}(window.app));