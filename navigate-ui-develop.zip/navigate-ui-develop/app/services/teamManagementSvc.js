(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('teamManagementSvc', ['$http', function($http) {
    return {
      getSupervisor: function (providerId) {
          return $http.get(app.api.root +'supervisor/'+ providerId);
        },
      getProviderManagedPopulations: function (providerId) {
          return $http.get(app.api.root +'provider/'+ providerId+ '/managed-populations');
        },
      getProviderManagedPopulationDetails: function (programId) {
          return $http.get(app.api.root +'managed-population/'+ programId+ '/care-team-members');
        },
      putActiveInactiveCareTeamMember: function(providerId, programId) {
          return $http.put(app.api.root + 'provider/' + providerId + '/managed-population/' + programId);
        }
    };
  }]);
}(window.app));