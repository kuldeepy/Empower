(function (app) {
  'use strict';

  app.factory('createUserSvc', ['$http', 'authSvc', function($http, authSvc) {
    return {
      roles: function() {
        return $http.get(app.api.root + 'security-roles',{cache : true})
        .then(
          // success
          function(response) {
            var data = response.data.results;
            return data;
          },
          // error
          function(err) {
            if (err) {
              return err;
            }
          }
        );
      },
      insuranceGroups: function() {
        return $http.get(app.api.root + 'insurance-group-providers')
        .then(
          // success
          function(response) {
            var data = response.data.results;
            return data;
          },
          // error
          function(err) {
            if (err) {
              return err;
            }
          }
        );
      },
      clinics: function() {
        return $http.get(app.api.root + 'clinics')
        .then(
          // success
          function(response) {
            var data = response.data.results;
            return data;
          },
          // error
          function(err) {
            if (err) {
              return err;
            }
          }
        );
      },
      physicians: function(id) {
        return $http.get(app.api.root + 'clinics/' + id + '/physicians')
        .then(
          //success
          function(response) {
            var data = response.data.results;
            return data;
          }
        );
      },
      states: function() {
        return $http.get(app.api.root + 'states',{cache : true})
        .then(
          // success
          function(response) {
            var data = response.data.results;
            return data;
          },
          // error
          function(err) {
            if (err) {
              return err;
            }
          }
        );
      },
      countries: function() {
        return $http.get(app.api.root + 'countries' + '?userId=' + authSvc.user().id )
        .then(
          // success
          function(response) {
            var data = response.data.results;
            return data;
          },
          // error
          function(err) {
            if (err) {
              return err;
            }
          }
        );
      },
      getUser: function(id) {
        return $http.get(app.api.root + 'users/' + id)
        .then(
          function(response) {
            var user = response.data.results;
            return user;
          }
        );
      },
      getUserRoles: function(id) {
        return $http.get(app.api.root + 'users/' + id + '/roles')
        .then(
          function(response) {
            var roles = response.data.results;
            return roles;
          }
        );
      },
      getActiveCareManagersCount:function(id){
        return $http.get(app.api.root + 'users/'+ id +'/activeCareManagersCount');
      },
      checkUser: function(username) {
        return $http.get(app.api.root + 'users?userName=' + username)
        .then(
          //success
          function(response) {
            var userExists = false;
            var data = response.data.results;
            if(data.totalCount > 0){
              data.users.forEach(function(user){
                  if(user.userName.toUpperCase() === username.toUpperCase()){
                    userExists = true;
                  }
                });
            }
            return userExists;
          }
        );
      },
      isEmailUnique: function(emailAddress){
        return $http.get(app.api.root + 'users?emailAddress='+ emailAddress)
        .then(
          // success
          function(response) {
            return response.data.results.totalCount > 0 ? false : true;
          }
        );
      },
      isAddedSuccesfully : false,
      messageAlert : ''
    };

  }]);

})(window.app);