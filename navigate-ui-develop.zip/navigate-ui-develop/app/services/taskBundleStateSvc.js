﻿(function (app) {
  'use strict';

  function createNewTaskBundle() {
    return { 'CurrentUIState': {} };
  }

  app.factory('taskBundleStateSvc', ['sessionSvc',
    function (sessionSvc) {
      var currentTaskBundleState = {
        get: function () {
          var state = sessionSvc.get('taskBundleState');
          if (state === undefined || state === null || state === '{}') {
            return createNewTaskBundle();
          }
          return JSON.parse(state);
        },
        set: function (taskBundleState) {
          if (taskBundleState === undefined || taskBundleState === null) {
            sessionSvc.clear('taskBundleState');
          }
          else {
            sessionSvc.set('taskBundleState', JSON.stringify(taskBundleState));
          }
        },
        clear: function () {
          sessionSvc.clear('taskBundleState');
        },

        //getGeneralInformation: function () {
        //  var currentGeneralInformationState = currentTaskBundleState.get();
        //  if (currentGeneralInformationState.CurrentUIState !== undefined && currentGeneralInformationState.CurrentUIState.currentTaskType !== undefined) {
        //    return currentGeneralInformationState.CurrentUIState.currentTaskType;
        //  }
        //  return '';
        //},

        getSeletectedTaskBundleName: function () {
          var currentTask = currentTaskBundleState.get();
          if (currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.currentTaskName !== undefined) {
            return currentTask.CurrentUIState.currentTaskName;
          }
          return '';
        },

        getSeletectedTaskBundleDesc: function () {
          var currentTask = currentTaskBundleState.get();
          if (currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.currentTaskDesc !== undefined) {
            return currentTask.CurrentUIState.currentTaskDesc;
          }
          return '';
        },
        
        getSeletectedTaskBundleStatus: function () {
          var currentTask = currentTaskBundleState.get();
          if (currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.currentTaskStatus !== undefined) {
            return currentTask.CurrentUIState.currentTaskStatus;
          }
          return '';
        },

        getSeletectedEduBundlename: function () {
          var currentTask = currentTaskBundleState.get();
          if (currentTask.CurrentUIState !== undefined && currentTask.CurrentUIState.eduBundleName !== undefined) {
            return currentTask.CurrentUIState.eduBundleName;
          }
          return '';
        },


        //getSeletectedPopulation: function () {
        //  var currentPopulation = currentTaskBundleState.get();
        //  if (currentPopulation.CurrentUIState !== undefined && currentPopulation.CurrentUIState.currentselectedManagedPopulation !== undefined) {
        //    return currentPopulation.CurrentUIState.currentselectedManagedPopulation;
        //  }
        //  return '';
        //}

      };
      return {
        get: currentTaskBundleState.get,
        set: currentTaskBundleState.set,
        selectedTaskBundleName: currentTaskBundleState.getSeletectedTaskBundleName,
        selectedTaskBundleDesc: currentTaskBundleState.getSeletectedTaskBundleDesc,
        selectedTaskBundleStatus: currentTaskBundleState.getSeletectedTaskBundleStatus,
        selectedEduBundlename: currentTaskBundleState.getSeletectedEduBundlename,
        //seletectedTaskType: currentTaskBundleState.getSeletectedTaskType,
        //seletectedTaskName: currentTaskBundleState.getSeletectedTaskName,
        //seletectedPopulation: currentTaskBundleState.getSeletectedPopulation,
        clear: currentTaskBundleState.clear
      };
    }
  ]);

})(window.app);