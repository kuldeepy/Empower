(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('parseToZipFile',[function () {
    return {
      getBase64EncodedZippedFile: function (zippedFileName, htmlContent) {
        /*global JSZip */
        var zip = new JSZip();
        var zippedFile = zip.file(zippedFileName, htmlContent);
        var base64EncodedZippedFile = zippedFile.generate({ type: 'base64' });
        return base64EncodedZippedFile;
      }
    };
  }]);
}(window.app));