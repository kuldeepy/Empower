(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('careManagementReportSvc',['$http','$q',
    function($http,$q){

        var reportData = {

          getStaticData: function (param) {
            param = param;

            return $http.get(app.api.root + param)
                .then(function(response) {
                    if ( response.data.results ) {
                      return response.data.results;
                    } else {
                      // invalid response
                      return $q.reject(response.data);
                    }

                  }, function(response) {
                    // something went wrong
                    return $q.reject(response.data);
                  });
          }
        };

        return reportData;
      }
      
  ]);
}(window.app));