(function (app) {
  'use strict';

  app.factory('hedisReportSvc', ['$http','authSvc',
    function (http,authSvc) {
        return{
          getLatestDateKeyRequest: function () {
            return http.get(app.api.root + 'latestdatekey?reporttype=hedis');
          },

          getClinicsRequest: function (dateKey) {
            return http.get(app.api.root + 'clinics?context=report&key=' +dateKey);
          },

          getInsurancePlansRequest : function () {
            return http.get(app.api.root + 'insurance-plans?context=Report');
          },

          getProductsRequest : function () {
            return http.get(app.api.root + 'products?context=Report');
          },

          getGraphDataRequest : function (filterData) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/hedis?hedisReport='+ filterData);
          },

          getAllMetricsRequest : function (populationConditionId,metricType,filterData) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/hedis/'+populationConditionId+'/metrics?metricType=' +metricType , {params : filterData});
          },

          getPhysiciansRequest : function (filter,dateKey) {
            return http.get(app.api.root + 'clinics/'+filter+'/physicians?key=' +dateKey+ '&context=Report');
          },

          getConditonsTrendRequest : function (filter) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/hedis/trend?hedisTrend=' +filter);
          },

          getMetricsTrendRequest :  function (filter) {
            return http.get(app.api.root + 'providers/'+ authSvc.user().providerId+ '/reports/hedis/metric-trend?hedisTrend=' +filter);
          }
        };
      }
    ]);
})(window.app);