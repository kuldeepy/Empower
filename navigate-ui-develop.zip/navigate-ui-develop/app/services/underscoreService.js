/**
 * @author michael.ash
 */
(function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('_', function() {
    // to extend Underscore with findByValues(utility function)
    // to filter a collection using array of property value (Given an array of IDs, return objects with matching IDs)
      _.mixin({
        'findByValues': function(collection, property, values) {
          return _.filter(collection, function(item) {
            return _.contains(values, item[property]);
          });
        }
      });
      return window._; // assumes underscore has already been loaded on the page
    });
}(window.app));