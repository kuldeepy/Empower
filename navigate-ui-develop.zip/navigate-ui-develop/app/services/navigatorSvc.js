(function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('navigatorSvc', function() {
    return {
        Navigate: function(path) {
            window.location.href = path;
          }
      };
  });
}(window.app));