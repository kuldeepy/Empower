app.factory('errorLogSvc', ['$log', '$window', 'authSvc', 'ajaxSvc',
  function($log, $window, authSvc, ajaxSvc) {
    'use strict';

    function log(exception, cause) {

      $log.error(exception, cause);

      getStackTrace(exception).then(function(stackTrace) {
        var errorInfo = getErrorInfo(exception, stackTrace);
        ajaxSvc({
          type: 'POST',
          url: app.api.root + 'audits/errors',
          contentType: 'application/json',
          headers: {
            Authorization: getAuthHeader()
          },
          data: angular.toJson(errorInfo)
        }).fail(function(ajaxError) {
          $log.error('Unable to log error', ajaxError);
        });
      }).catch(function(loggingError) {
        $log.error('Unable to log error', loggingError);
      });
    }

    function getErrorInfo(exception, stackTrace) {
      var errorInfo = {
        source: 'UI',
        userId: getUserId(),
        stackTrace: (stackTrace || []).toString()
      };

      if (stackTrace && Array.isArray(stackTrace) && stackTrace.length > 0) {
        errorInfo.procedure = stackTrace[0].toString();
      } else {
        errorInfo.procedure = $window.location.href;
      }

      var message = exception.toString();
      var split = message.split(':');
      if (split.length > 1) {
        errorInfo.type = split[0].trim();
        errorInfo.message = split[1].trim();
      } else {
        errorInfo.message = message;
      }
      return errorInfo;
    }

    function getAuthHeader() {
      var user = authSvc.user();
      if (user && user.token) {
        return 'Bearer ' + user.token;
      }
      return '';
    }

    function getUserId() {
      var authUser = authSvc.user();
      if (authUser && authUser.id) {
        return authUser.id;
      }
      return null;
    }

    function getStackTrace(exception) {
      if ($window.StackTrace) {
        return $window.StackTrace.fromError(exception);
      }
      return {
        then: function(f) {
          return f(exception.stack);
        }
      };
    }

    return log;
  }
]);