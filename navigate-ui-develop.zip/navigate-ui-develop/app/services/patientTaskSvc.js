(
  function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.factory('patientTaskSvc', ['$http', function($http) {
    return {
      getPatientTasks: function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/tasks');
      },
      getAppliedFilters: function (providerId) {
        return $http.get(app.api.root +'providers/'+ providerId+ '/patient-filter');
      },
      postAppliedFilters: function (providerId, objectbody) {
        return $http.post(app.api.root + 'providers/'+ providerId + '/patient-filter', objectbody);
      },
      getPatientMissedOpportunity: function(id) {
        return $http.get(app.api.root + 'patients/' + id + '/missed-opportunities');
      },

      getPatientCompletedTasks: function(id,objectbody) {
        return $http.get(app.api.root + 'patients/' + id + '/tasks-completed',{params: objectbody});
      },

      putPatientTask: function(patientId, taskId, objectbody) {
        return $http.put(app.api.root + 'patients/'+ patientId +'/tasks/'+ taskId,objectbody);
      },

      getPatients: function(objectbody) {
        return $http.post(app.api.root + 'patients',objectbody);
      },
      putPatientNote: function (id, objectbody) {
        return $http.put(app.api.root + 'patients/' + id + '/notes', objectbody);
      },
      postPatientNote: function (id, objectbody) {
        return $http.post(app.api.root + 'patients/' + id + '/notes', objectbody);
      },
      getPatientNoteInvalidateReason: function () {
        return $http.get(app.api.root + 'invalidate-reasons');
      }
    };
  }
  ]);


}(window.app));
