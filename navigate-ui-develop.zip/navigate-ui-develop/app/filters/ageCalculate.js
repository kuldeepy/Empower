(function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.filter('ageCalculation', function (){
      return function (birthdate){
        var todayDate = new Date(),
        todayYear = todayDate.getFullYear(),
        todayMonth = todayDate.getMonth(),
        todayDay = todayDate.getDate(),
        age;
        if(birthdate !== undefined && birthdate !== null) {
          var year = moment(birthdate).format('YYYY'),
          month = moment(birthdate).format('MM'),
          day = moment(birthdate).format('DD');
          age = todayYear - year;
          if ((todayMonth < month - 1) || (month - 1 === todayMonth && todayDay < day)) {
            age = age - 1;
          }
        }
        return age;
      };
    });

  }(window.app));