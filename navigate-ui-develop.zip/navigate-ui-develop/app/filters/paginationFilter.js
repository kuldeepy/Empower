(function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.filter('paginationFilter', function (){
      return function (inputArray, pageIndex, pageSize)
      {
        var count = 0;
        if(inputArray !== undefined && inputArray.length > 0)
        {
          var newArray = [];
          for(var x = (pageIndex * pageSize)-pageSize; x < inputArray.length; x=x+1)
          {
            newArray.push(inputArray[x]);
            count = count + 1;
            if(count === pageSize)
            {
              break;
            }
          }
          return newArray;
        }
      };
    });

  }(window.app));