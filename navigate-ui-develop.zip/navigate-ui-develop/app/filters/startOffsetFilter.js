/**
 * @author michael.ash
 */
(
  function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on
    app.filter('startOffset', function (){
      return function (input, start){
        start = Math.abs(parseInt(start,10));
        if(input){
          return input.slice(start);
        }
      };
    });
  }(window.app));
