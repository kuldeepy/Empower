(function (app) {
  /* @fmt: off */
  'use strict';
  // @fmt:on

  // Filter for replacing spaces with dashes. Useful for making ids
	app.filter('nospace', function () {
		return function (value) {
        return (!value) ? '' : value.replace(/ /g, '-');
      };
  });

}(window.app));