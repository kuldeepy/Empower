(function (app) {
    /* @fmt: off */
    'use strict';
    // @fmt:on

    app.filter('maskPassword', function (){
      return function (input){
        return new Array(input.length + 1).join('\u25CF');
      };
    });

  }(window.app));