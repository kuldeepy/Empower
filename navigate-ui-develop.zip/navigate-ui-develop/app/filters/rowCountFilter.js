(function (app) {
  /* @fmt: off */
  'use strict';
  // @fmt:on

  app.filter('SumofColumnsData', function ($filter) {
    return function (rowData,columns,gridData) {
        if (angular.isUndefined(rowData) && angular.isUndefined(columns)) {
          return 0;
        }
        var sum = 0;
        if(rowData.Status!== 'Total'){
          angular.forEach(columns,function(item){
            if(item !== 'Status' && item!== 'Total'){
              sum = sum + (parseInt(rowData[item]));
            }
          });
        }
        else{
          angular.forEach(columns,function(item){
            if(item !== 'Status' && item!== 'Total'){
              sum = sum + $filter('sumOfRowsData')(gridData,item);
            }
          });
        }
        return sum;
      };
  });
  app.filter('sumOfRowsData', function () {
    return function (data, columnName) {
        if (angular.isUndefined(data) && angular.isUndefined(columnName)){
          return 0;
        }
        var sum = 0;
        angular.forEach(data,function(item){
          if(angular.isUndefined(item[columnName])){
            sum = sum;
          }
          else{
            sum = sum + parseInt(item[columnName]);
          }
        });
        return sum;
      };
  });
}(window.app));