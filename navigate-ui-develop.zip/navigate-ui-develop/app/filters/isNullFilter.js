(function (app) {
  /* @fmt: off */
  'use strict';
  // @fmt:on

  // Filter for replacing null with space
	app.filter('isNull', function () {
		return function (value) {
        return (value !== null && value !== undefined) ? value : '';
      };
  });

}(window.app));