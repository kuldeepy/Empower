(function (app) {
	'use strict';
 /* layout controller */
  app.controller('DefaultLayoutCtrl', ['$scope',
    function (scope) {
      scope.version = '0.0.0';
      scope.layout = {basicLayout : true};
      scope.logoText = 'MEDSEEK';
      scope.site = {
        home : 'Home',
        messages : 'Messages',
        task : 'Tasks',
        patients : 'Patients',
        year : new Date().getFullYear()
      };
      scope.year = new Date().getFullYear;
      scope.inboxMessage = {
        unreadMsgCount: 0
      };

      scope.carePlanLocationCtrl = {
        isFormDirty :false,
        isSwitchRole:false,
        isLogout:false
      };

      scope.adtNotification = {
        unreadCount: 0,
        adtNotificationData : [],
        totalElements: 0,
        dataChunkSize: 5,
        dataChunkIndex: 0
      };
    }]);

}(window.app));