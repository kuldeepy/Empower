(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.constant('navConstantsSvc', {
    allPatientsManagedPopulation : 'All Patients Managed population',
    administrator : 'Administrator',
    careManager : 'Care Manager',
    clinicAdministrator : 'Clinic Administrator',
    physician : 'Physician',
    insuranceGroupProvider : 'Insurance Group Provider',
    lockedMessage : 'Currently action is locked as \'UserName\' is performing this task',
    mergeDependenceMessage : 'Another merge request for \'UserName\' is pending, merge will not be initiated until the pending merge request is completed',
    goal : 'Goal',
    noRecords : 'No records to display',
    activity : 'Activity',
    active: 'Active',

    populationDefinitionTable: {
      caption: '',
      columns: ['Population Definition', 'Total Patients', 'Actions']
    },
    myPatientsHeader:['Patient Name', 'Date Identified', 'Enrollment Date', 'Status'],
    numberText:'Text Box (Numbers only)',
    radioButton:'Radio Button',
    textBox:'Text Box',
    checkBox:'Check Box',
    dropDown:'Dropdown',
    dateTime: 'Date and Time',
    familyFriendsTeam: 'familyFriends',
    professionalSupportTeam: 'professionalSupport',
    viewState: 'View',
    editState: 'Edit',
    expiredDeveloperError: 'Reset password link has expired.',
    patientNoteErrorMessage: 'This note cannot be sent to external EMR.',
    otherReasonDescription: 'Other',
    defaultPageParameters : { pageSize: 10, pageNumber: 1 },
    allPatientCareTeamName: 'All Patients Care Team'

  });

}(window.app));
