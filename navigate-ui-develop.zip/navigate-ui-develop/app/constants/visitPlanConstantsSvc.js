(
function (app) {
  // @fmt:off
  'use strict';
  // @fmt:on
  app.constant('visitPlanConstantsSvc', {
    disenrollGridTitle : 'Managed Populations - Disenrolled',
    programName : 'Name',
    enrollmentStartDate : 'Enrollment Date',
    enrollmentEndDate : 'Disenrollment Date',
    disenrolledBy : 'Disenrolled By',
    reason:'Reason for Disenrollment'
  });

}(window.app));
