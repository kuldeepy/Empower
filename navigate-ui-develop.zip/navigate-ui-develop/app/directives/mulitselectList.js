(function (app) {
  'use strict';

  app.directive('multiSelectListFilter', ['$q',function ($q) {
    return {
      restrict: 'E',
      require: 'ngModel',
      scope: {
        selectedLabel: '@',
        availableLabel: '@',
        displayAttr: '@',
        available: '=',
        model: '=ngModel'
      },
      templateUrl: app.root + 'templates/multiSelectList.html',
      link: function(scope,elm, attrs) {
        scope.selected = {
          available: [],
          current: []
        };

        /* Handles cases where scope data hasn't been initialized yet */
        var dataLoading = function(scopeAttr) {
          var loading = $q.defer();
          if(scope[scopeAttr]) {
            loading.resolve(scope[scopeAttr]);
          } else {
            scope.$watch(scopeAttr, function(newValue, oldValue) {
              if(newValue !== undefined && newValue !== oldValue){
                loading.resolve(newValue);
              }
            });
          }
          return loading.promise;
        };

        /* Filters out items in original that are also in toFilter. Compares by reference. */
        var filterOut = function(original, toFilter) {
          var filtered = [];
          angular.forEach(original, function(entity) {
            var match = false;
            for(var i = 0; i < toFilter.length; i = i+1) {
              if(entity.taskTypeId)
              {
                if(toFilter[i].id === entity.id && toFilter[i].taskTypeId === entity.taskTypeId) {
                  match = true;
                  break;
                }
              }
              else
              {
                if(toFilter[i].id){
                  if( toFilter[i].id === entity.id) {
                    match = true;
                    break;
                  }
                }
                else{
                  if(toFilter[i][attrs.displayAttr] === entity[attrs.displayAttr]) {
                    match = true;
                    break;
                  }
                }
              }
            }
            if(!match) {
              filtered.push(entity);
            }
          });
          return filtered;
        };

        var deSerializeSelected = function(ele){
          var deSerialized = ele.map(function (node) {
              return JSON.parse(node);
            });
          return deSerialized;
        };

        scope.refreshAvailable = function() {
          scope.available = filterOut(scope.available, scope.model);
          scope.selected.available = [];
          scope.selected.current = [];
        };

        scope.removeAllFromSelected = function() {
          scope.available = scope.available.concat(scope.model);
          scope.model = [];//filterOut(scope.available, scope.model);
          scope.selected.available = [];
          scope.selected.current = [];
        };

        scope.addAllToSelected = function () {
          scope.model = scope.model.concat(scope.available);
          scope.available = [];//filterOut(scope.available, scope.model);
          scope.selected.available = [];
          scope.selected.current = [];
        };

        scope.add = function() {
          scope.model = scope.model.concat(deSerializeSelected(scope.selected.available));
          scope.refreshAvailable();
        };

        scope.remove = function() {
          scope.available = scope.available.concat(deSerializeSelected(scope.selected.current));
          scope.model = filterOut(scope.model, deSerializeSelected(scope.selected.current));
          scope.refreshAvailable();
        };

        $q.all([dataLoading('model'), dataLoading('available')]).then(function() {
          scope.refreshAvailable();
        });
      }
    };
  }]);

}(window.app));