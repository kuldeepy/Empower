﻿(function (app) {
  'use strict';

  app.directive('patientSearch', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'templates/patientSearch.html',
    };
  }]);

}(window.app));