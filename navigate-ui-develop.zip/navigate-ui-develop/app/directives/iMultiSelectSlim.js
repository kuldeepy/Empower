(function (app) {
  'use strict';

  // Author: morgan.stone
  // this directive creates a slim multi-select box that appears like a dropdown. When clicked you can then filter available results

  app.directive('iMultiSelectSlim', [function () {
    return {
      restrict: 'E',
      replace: true,
      scope: {
        directiveId: '@',
        showSearch: '@',
        buttonLabel: '@',
        buttonClass: '@',
        maxItems: '@',
        inputModel: '=',
        outputModel: '=',
        showDropDown: '=',
        maxReached:'='
      },
      templateUrl: app.root + 'templates/iMultiSelectSlim.html',
      link: function (scope) {
        if (typeof scope.outputModel === 'undefined') {
          scope.outputModel = [];
        }

        scope.changeInOutput = function () {
          scope.outputModel = _.where(scope.inputModel, {ticked: true});
          if (scope.maxItems) {
            scope.maxReached = scope.maxItems <= scope.outputModel.length;
          }
        };
      }
    };
  }]);

}(window.app));