﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msProfilePopup', [function () {
        return {
            restrict: 'E',
            templateUrl: '/modules/user/templates/user_Profile.html'
          };
      }]);
  }(window.app));