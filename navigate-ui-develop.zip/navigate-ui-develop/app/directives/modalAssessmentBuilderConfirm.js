(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msAssessmentBuilderConfirmPopup', function () {
        return {
            restrict: 'E',
            templateUrl: '/templates/assessmentBuilderConfirmPopup.html'
          };
      });
  }(window.app));