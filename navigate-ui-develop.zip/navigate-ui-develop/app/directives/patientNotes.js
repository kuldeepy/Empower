﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('medPatientNotes', [function () {
        return {
            restrict: 'E',
            templateUrl: '/templates/patientNotes.html'
          };
      }]);
  }(window.app));