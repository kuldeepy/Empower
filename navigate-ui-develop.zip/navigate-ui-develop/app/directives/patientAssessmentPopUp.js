﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msPatientAssessmentPopup', [function () {
        return {
            restrict: 'E',
            templateUrl: '/templates/patientAssessment_popup.html'
          };
      }]);
  }(window.app));