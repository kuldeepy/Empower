(function (app) {
  // @fmt:off
  'use strict';
  //@fmt:on

  app.directive('navmultiSelect',[function(){
    return {
      restrict: 'E',
      require: '?ngModel',
      scope: {
        choices: '=',
        placeholdertext:'=',
        selected: '=',
        selectedData:'=',
        multiselect:'=',
        name:'=',
        value:'='
      },
      templateUrl: app.root +'templates/navMultiselect.html',
      replace: true,
      link: function(scope){
        scope.isVisible=false;
        scope.nodata=false;
        scope.isChecked = function(item){
          if(scope.selected.indexOf(item) !== -1){
            return true;
          }
          return false;
        };
        scope.toggleSelect = function(){
          scope.searchText='';
          scope.nodata=false;
          scope.isVisible = false;
        };
        scope.toggleCheck = function(data,item){
          if(!scope.isChecked(item)){
            scope.selected.push(item);
            scope.selectedData.push(data);
          }else{
            scope.selected.splice(scope.selected.indexOf(item), 1);
            scope.selectedData.splice(scope.selectedData.indexOf(data), 1);
          }
        };
        scope.$watch('searchText', function(searchdata) {
          scope.isVisible=false;
          scope.nodata=false;
          if(searchdata.length>2){
            scope.multiselect.http.get(app.api.root +scope.multiselect.url+'/?'+(angular.equals(scope.multiselect.url,'clinics') ? 'context=' : 'searchText=')+searchdata+(!scope.multiselect.Type?'':'&codeType='+scope.multiselect.Type))
                  .success (function (data){
                    if(data.results.length===0){
                      scope.choices=[];
                      scope.filterChoices=[];
                      scope.nodata=true;
                      scope.isVisible=false;
                    }
                    else{
                      scope.choices=data.results;
                      scope.filterChoices=scope.choices;
                      scope.nodata=false;
                      scope.isVisible=true;
                    }
                    
                  })
                  .error(function(){
            });

          }
          else{
            scope.filterChoices=[];
          }
        });
        scope.addSelected=function(){
          scope.multiselect.checkeddata.forEach(function(data){
            if(scope.multiselect.availabledata.length===0){
              var status=0;
              scope.multiselect.selectedavailabledata.forEach(function(existingData){
                if(existingData.id===data.id){
                  status=1;
                }
              });
              if(status===0)
              {
                scope.multiselect.availabledata.push(data);
              }
            }
            else
            {
              var flag=0;
              scope.multiselect.availabledata.forEach(function(selectedData){
                if(selectedData.id===data.id)
                {
                  flag=1;
                }
              });
              scope.multiselect.selectedavailabledata.forEach(function(existingData){
                if(existingData.id===data.id)
                {
                  flag=1;
                }
              });
              if(flag===0)
              {
                scope.multiselect.availabledata.push(data);
              }
            }
          });
          scope.toggleSelect();
        };
      }
    };
  }]);

}(window.app));