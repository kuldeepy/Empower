/**
 * @author morgan.stone
 */
( function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on
    app.directive('equalsNotEquals', function () {
      return {
        restrict : 'E',
        replace : true,
        templateUrl : '/templates/equals-not-equals.html',
        scope : {
          ngModel : '='
        },
        link : function (scope) {
          scope.version = '0.0.0';
        }
      };
    });
    app.directive('timesInLastDays', function () {
      return {
        restrict : 'E',
        replace : true,
        templateUrl : '/templates/times-in-last-days.html',
        scope : {
          ngModel : '=',
          disabled: '='
        },
        link : function (scope) {
          scope.version = '0.0.0';
        }
      };
    });
    app.directive('criteriaTypeForm', function () {
      return {
        restrict : 'E',
        replace : true,
        templateUrl : '/templates/criteria-type-form.html',
        scope : {
          ngModel : '=',
          modalOptions: '=',
          multiselect: '='
        },
        link : function (scope) {
          scope.version = '0.0.0';
        }
      };
    });
  }(window.app));
