(function (app) {
  // @fmt:off
  'use strict';
  //@fmt:on

  app.directive('scrollToTop', function(){
      return {
          restrict: 'A',
          scope: {
              trigger: '=scrollToTop'
            },
            link: function postLink(scope, elem) {
                scope.$watch('trigger', function() {
                    elem[0].scrollTop = 0;
                  });
              }
          };
    });
}(window.app));
