﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msLastVisitPopup', function () {
        return {
            restrict: 'E',
            templateUrl: '/modules/patient-search/templates/patient-last-Visit-popup.html'
          };
      });
  }(window.app));