/**
 * @author michael.ash
 */
( function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on
    app.directive('medExpandableMenu', function () {
      return {
        restrict : 'A',
        replace : true,
        templateUrl : '/templates/navExpandableMenu.html',
        scope : {
          menu : '='
        },
        link : function (scope) {
          scope.version = '0.0.0';
        }
      };
    });
  }(window.app));
