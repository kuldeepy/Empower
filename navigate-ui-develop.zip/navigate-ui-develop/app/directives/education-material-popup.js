﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msEducationMaterialPopup', [function () {
        return {
            restrict: 'E',
            templateUrl: '/templates/education_material_popup.html'
          };
      }]);
  }(window.app));