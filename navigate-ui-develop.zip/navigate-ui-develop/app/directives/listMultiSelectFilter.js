(function (app) {
  'use strict';

  app.directive('listMultiSelectFilter', ['$q',function ($q) {
    return {
      restrict: 'E',
      require: 'ngModel',
      scope: {
        selectedLabel: '@',
        availableLabel: '@',
        displayAttr: '@',
        available: '=',
        model: '=ngModel'
      },
      templateUrl: app.root + 'templates/listSelectFilterTpl.html',
      link: function(scope, elm, attrs) {
        scope.selected = {
          available: [],
          current: []
        };

        /* Handles cases where scope data hasn't been initialized yet */
        var dataLoading = function(scopeAttr) {
          var loading = $q.defer();
          if(scope[scopeAttr]) {
            loading.resolve(scope[scopeAttr]);
          } else {
            scope.$watch(scopeAttr, function(newValue, oldValue) {
              if(newValue !== undefined && newValue !== oldValue){
                loading.resolve(newValue);
              }
            });
          }
          return loading.promise;
        };

        /* Filters out items in original that are also in toFilter. Compares by reference. */
        var filterOut = function(original, toFilter) {
          var filtered = [];
          angular.forEach(original, function(entity) {
            var match = false;
            for(var i = 0; i < toFilter.length; i = i+1) {
              if(toFilter[i][attrs.displayAttr] === entity[attrs.displayAttr]) {
                match = true;
                break;
              }
            }
            if(!match) {
              filtered.push(entity);
            }
          });
          return filtered;
        };

        var deSerializeSelected = function(ele){

            var deSerialized = ele.map(function (node) {
                return JSON.parse(node);
              });
            return deSerialized;

          };

        scope.moveItem =  function (arr, fromIndex, toIndex) {
          var element = arr[fromIndex];
          arr.splice(fromIndex, 1);
          arr.splice(toIndex, 0, element);
        };
        
        scope.refreshAvailable = function() {
          scope.available = filterOut(scope.available, scope.model);
          scope.selected.available = [];
          scope.selected.current = [];
        };

        scope.removeAllFromSelected = function() {
          scope.available = scope.available.concat(scope.model);
          scope.available = _.sortBy(scope.available, 'lastName');
          scope.model     = [];//filterOut(scope.available, scope.model);
          scope.selected.available = [];
          scope.selected.current = [];
          var item =_.findWhere(scope.available, {firstName: 'No PCP Assigned'});
          if(item !== undefined && scope.availableLabel === 'Available PCP'){
            scope.moveItem(scope.available, scope.available.indexOf(item), 0);
          }
        };

        scope.addAllToSelected = function() {
          scope.model     = scope.model.concat(scope.available);
          scope.model = _.sortBy(scope.model, 'lastName');
          scope.available = [];//filterOut(scope.available, scope.model);
          scope.selected.available = [];
          scope.selected.current = [];
          var item =_.findWhere(scope.model, {firstName: 'No PCP Assigned'});
          if(item !== undefined && scope.availableLabel === 'Available PCP'){
            scope.moveItem(scope.model, scope.model.indexOf(item), 0);
          }
        };

        scope.add = function() {
          scope.model = scope.model.concat(deSerializeSelected(scope.selected.available));
          scope.refreshAvailable();
          scope.model = _.sortBy(scope.model, 'lastName');
          var item =_.findWhere(scope.model, {firstName: 'No PCP Assigned'});
          if(item !== undefined && scope.availableLabel === 'Available PCP'){
            scope.moveItem(scope.model, scope.model.indexOf(item), 0);
          }
        };

        scope.remove = function() {
          scope.available = scope.available.concat(deSerializeSelected(scope.selected.current));
          scope.model = filterOut(scope.model, deSerializeSelected(scope.selected.current));
          scope.refreshAvailable();
          var itemModel =_.findWhere(scope.model, {firstName: 'No PCP Assigned'});
          if(itemModel !== undefined && scope.availableLabel === 'Available PCP'){
            scope.moveItem(scope.model, scope.model.indexOf(itemModel), 0);
          }
          scope.available = _.sortBy(scope.available, 'lastName');
          var itemAvailable =_.findWhere(scope.available, {firstName: 'No PCP Assigned'});
          if(itemAvailable !== undefined && scope.availableLabel === 'Available PCP'){
            scope.moveItem(scope.available, scope.available.indexOf(itemAvailable), 0);
          }
        };

        $q.all([dataLoading('model'), dataLoading('available')]).then(function() {
          scope.refreshAvailable();
        });
      }
    };
  }]);

}(window.app));