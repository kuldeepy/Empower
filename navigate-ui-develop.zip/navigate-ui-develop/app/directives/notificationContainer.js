(function (app) {
  'use strict';

  app.directive('medNotificationContainer', ['$timeout','$window',
    function (timeout, window) {
      var displayTime = 9000;
      return {
        restrict: 'E',
        replace: true,
        scope: { setErrorNotification: '=bind', notificationVisible: '=reset' },
        templateUrl: '/templates/notificationContainer.html',

        link: function (scope) {
          scope.notification = {};
          scope.notification.visible = false;

          scope.$watch('notificationVisible', function (value) {
              if (!value) {
                return;
              }
              scope.notificationVisible = '';
              scope.notification.visible = false;
            });

          scope.$watch('setErrorNotification', function (errorMessage) {
              if (!errorMessage) {
                return;
              }
              scope.setErrorNotification = '';
              showNotification('alert-danger', errorMessage);
            });

          function showNotification(type, message) {
            scope.notification.message = message;
            scope.alertClass = type;
            scope.notification.visible = true;
            window.scrollTo(0, 0);
            timeout(function () {
              scope.notification.visible = false;
            }, displayTime);
          }

          scope.$on('notify-error', function () {
            var defaultErrorMessage = 'Unfortunately, we are not able to process your request at this time. Please try again later or contact your system administrator if this continues.';
            showNotification('alert-danger', defaultErrorMessage);
          });

          scope.$on('notify-success', function (context, args) {
            var defaultSuccessMessage = 'Your request was processed successfully.';
            showNotification('alert-success', args.message || defaultSuccessMessage);
          });

          scope.$on('unauthorizedPatientDataAccessError', function (event) {
            var unauthorizedPatientDataAccessErrorMessage = 'You don\'t have access to the Patient';
            showNotification('alert-danger', unauthorizedPatientDataAccessErrorMessage);
            event.stopPropagation();
          });

          scope.$on('lockedError', function () {
            var lockedErrorMessage = 'Your account has been locked. Please contact system administrator.';
            showNotification('alert-danger', lockedErrorMessage);
          });
        }
      };
    }
  ]);

})(window.app);