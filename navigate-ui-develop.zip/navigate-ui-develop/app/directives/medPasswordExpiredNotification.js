(function (app) {
  'use strict';

  app.directive('medExpiredPassword', ['$timeout','$window', 'authSvc',
    function (timeout, window,authSvc) {

      return {
        restrict: 'E',
        replace: false,
        scope: { setExpiredNotification: '=bind', notificationVisible: '=reset', isMyProfile: '=myprofile' },
        templateUrl: '/templates/passwordExpiredNotification.html',

        link: function (scope) {

          scope.notification = {};
          scope.notification.visible = false;
          scope.notification.isMyProfile = false;
          scope.viaMyProfile = false;
          scope.setClosePasswordNotification = function(){
            sessionStorage.setItem('hidePasswordNotification',true);
          };
          scope.$watch('isMyProfile', function (value) {

              if (!value) {
                return;
              }
              scope.notification.isMyProfile = value;
              scope.viaMyProfile = value;
            });

          scope.$watch('notificationVisible', function (value) {

              if (!value) {
                return;
              }
              scope.notificationVisible = null;
              scope.notification.visible = false;
              scope.viaMyProfile = false;
            });

          scope.$watch('setExpiredNotification', function (errorMessage) {

            if (errorMessage === 'hide') {
              scope.notification.visible = false;
            }
 
            if (errorMessage === '') {
              return;
            }

            scope.setExpiredNotification = '';
            scope.viaMyProfile = false;
            showNotification('alert-danger', errorMessage);
          });

          function showNotification(type, daysLeft) {

            var msg = 'Your password will expire';
            if(parseInt(daysLeft) === 0){
              msg = msg + ' today.';
            }else if(parseInt(daysLeft) === 1){
              msg = msg + ' in ' + daysLeft + ' day.';
            } else{
              msg = msg + ' in ' + daysLeft + ' days.';
            }

            scope.notification.message = msg;
            scope.notification.visible = authSvc.getChangePasswordReminderDays(daysLeft);
            if(scope.notification.visible && sessionStorage.getItem('hidePasswordNotification')  ===  'true' ){
              scope.notification.visible = false;
            }
            window.scrollTo(0, 0);

          }

          scope.closePasswordNotification = function () {
            scope.$broadcast('passwordNotificationClose');
          };

        }
      };
    }
  ]);

})(window.app);