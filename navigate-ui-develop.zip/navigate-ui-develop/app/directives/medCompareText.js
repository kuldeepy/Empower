﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on
    app.directive('medCompareText', function () {
        return {
            require: 'ngModel',
            link: function (scope, elem, attrs, model) {
                if (!attrs.medCompareText) {
                  return;
                }
                scope.$watch(attrs.medCompareText, function (value) {
                  model.$setValidity('medCompareText', value === model.$viewValue);
                });
                model.$parsers.push(function (value) {
                  var isValid = value === scope.$eval(attrs.medCompareText);
                  model.$setValidity('medCompareText', isValid);
                  return isValid ? value : undefined;
                });
              }
          };
      });
  }(window.app));