/**
 * @author michael.ash
 */
( function (app) {
    'use strict';
    app.directive('medAdminMenuItem', ['$window', '$timeout',
    function ($window, $timeout) {
      return {
        restrict : 'E',
        replace : false,
        scope : {
          menu : '='
        },
        templateUrl : '/templates/admin-menu-item.html',
        link : function (scope, element) {
          var pop = element.find('.popover'),
          heading = element.find('section'),
          listParent = heading.closest('ul');
          scope.isSelected = false;
          scope.closePopout = function(){
            scope.isSelected = false;
            listParent.find('.admin-menu > section').removeClass('highlight');
            heading.addClass('highlight');
          };
          scope.showPopout = function () {
            scope.isSelected = !scope.isSelected;
            function doDomStuff (x) {
              $timeout(function () {
                var list = element.find('ul'),
                    topValue,
                    listHeight = parseInt($window.getComputedStyle(list[0]).getPropertyValue('height'), 10);
                if (listHeight) {
                  topValue = ((-1) * (listHeight / 2) + 5) + 'px';
                  scope.cssProperties = {
                    top : topValue
                  };
                  pop.css({top : topValue, visibility : 'visible'});
                }
                if (x < 0) {
                  doDomStuff(x - 1);
                }
              }, 200);
            }

            doDomStuff(10);

          };
          scope.close = function(){
            scope.isSelected = false;

          };
        }
      };
    }]);
  }(window.app));