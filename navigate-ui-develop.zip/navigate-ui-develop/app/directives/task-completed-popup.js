﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msTaskCompletedPopup', ['patientAssessmentSvc', 'PatientData', '$timeout', function (patientAssessmentSvc, patientData, $timeout) {
        return {
            restrict: 'E',
            replace: true,
            scope: { attributeAssessment: '=bind', saveAssessment: '=save', enter: '&', alertMessage: '&' },
            templateUrl: '/templates/task_Completed_popup.html',
            link: function (scope) {
                var selectedAnswers = [];
                var patientAssessmentSurvey = [];
                scope.assessmentName='';
                scope.pageIndex = 1;
                scope.pageSize = 5;
                scope.lastPageIndex = 0;
                scope.showMandatoryErrorMessage = false;
                

                scope.$watch('attributeAssessment', function (atrAssessment) {
                    if (!atrAssessment) {
                      return;
                    }
                    scope.attributeAssessment = '';
                    scope.openAssessmentSurvey(atrAssessment);
                  });

                scope.$watch('saveAssessment', function (addAssessment) {
                    if (!addAssessment) {
                      return;
                    }
                    scope.saveAssessment = '';
                    scope.saveAssessmentSurvey(addAssessment);
                  });

                scope.openAssessmentSurvey = function (assessment) {
                    scope.pageIndex = 1;
                    scope.assessmentSets = [];
                    scope.questions = [];
                    scope.answers = [];

                    if (assessment.Name === undefined) {
                      scope.assessmentName = assessment.assessmentName;
                    }
                    else {
                      scope.assessmentName = assessment.Name;
                    }
                    
                    if (assessment.TypeId === undefined) {
                      scope.assessmentId = assessment.assessmentId;
                    }
                    else {
                      scope.assessmentId = assessment.TypeId;
                    }

                    if (assessment.TaskSpecificId === undefined) {
                      scope.userAssessmentID = assessment.patientAssessmentId;
                    }
                    else {
                      scope.userAssessmentID = assessment.TaskSpecificId;
                    }

                    if (assessment.status !== 'Closed Complete') {
                      scope.isOpenClicked = true;
                    }
                    else {
                      scope.isOpenClicked = false;
                    }
                    var requestpath = 'patients/' + patientData.id + '/assessmentsurvey/' + scope.assessmentId + '/' + scope.userAssessmentID;
                    patientAssessmentSvc.getPatientAssessmentSurvey(requestpath).then(function (response) {
                      if (response.data.results) {
                        scope.assessmentSets = [];
                        scope.questions = [];
                        scope.answers = [];
                        
                        scope.data = response.data.results;
                        var assessmentSets = scope.data.Assessmentset;
                        angular.forEach(assessmentSets, function (assessment) {
                          if (angular.equals(assessment.isShow, true)) {
                            scope.assessmentSets.push(assessment);
                          }
                        });

                        var questions = scope.data.Questions;
                        var count =0;
                        angular.forEach(questions, function (question) {
                          question.isDatePickerOpen = false;
                          question.defaultTime = new Date('00');

                          if (angular.equals(question.answerControlType, 'Checkbox')) {
                            question.selectedAns = [];
                          }
                          else {
                            question.selectedAns = [];
                          }
                          question.questionIndex = (count = count + 1);
                          scope.questions.push(question);
                        });

                        var answers = scope.data.Answers;
                        angular.forEach(answers, function (answer) {
                          answer.enteredAnswer = '';
                          scope.answers.push(answer);
                        });
                        scope.saveAssessmentButtonDisable = true;
                        selectedAnswers = scope.data.SelectedAnswers;
                        angular.forEach(selectedAnswers, function (selectedAnswer) {
                          angular.forEach(scope.questions, function (question) {
                            if (selectedAnswer.assessmentSetQuestionId === question.assessmentSetQuestionId) {
                              switch (question.answerControlType) {
                                case 'Text':
                                  if(selectedAnswer.answerString !== null && selectedAnswer.answerString !== undefined && selectedAnswer.answerString !== '')
                                  {
                                    question.selectedAns = selectedAnswer.answerString;
                                    scope.saveAssessmentButtonDisable = false;
                                  }
                                  break;
                                case 'DateTime':
                                  if (selectedAnswer.answerString !== null && selectedAnswer.answerString !== undefined && selectedAnswer.answerString !== '') {
                                    question.selectedAns = selectedAnswer.answerString;
                                    scope.saveAssessmentButtonDisable = false;
                                    scope.value = new Date(question.selectedAns);
                                    question.defaultTime = new Date(question.selectedAns);
                                    question.selectedAns = scope.value;
                                  }
                                  break;
                                case 'Radio.Text':
                                case 'Radio.Text.Label':
                                  angular.forEach(scope.answers, function (answer) {
                                    if (answer.answerId === selectedAnswer.answerId) {
                                      if(selectedAnswer.answerId !== null && selectedAnswer.answerId !== undefined && selectedAnswer.answerId !== '')
                                      {
                                        answer.enteredAnswer = selectedAnswer.answerString;
                                        question.selectedAns = selectedAnswer.answerId;
                                        scope.saveAssessmentButtonDisable = false;
                                      }
                                    }
                                  });
                                  break;
                                case 'Checkbox':
                                  if(selectedAnswer.answerId !== null && selectedAnswer.answerId !== undefined && selectedAnswer.answerId !== '')
                                  {
                                    question.selectedAns.push(selectedAnswer.answerId);
                                    scope.saveAssessmentButtonDisable = false;
                                  }
                                  break;
                                case 'Checkbox.Text':
                                case 'Checkbox.Text.Label':
                                  angular.forEach(scope.answers, function (answer) {
                                    if (answer.answerId === selectedAnswer.answerId) {
                                      if(selectedAnswer.answerId !== null && selectedAnswer.answerId !== undefined && selectedAnswer.answerId !== '')
                                      {
                                        question.selectedAns.push(selectedAnswer.answerId);
                                        answer.enteredAnswer = selectedAnswer.answerString;
                                        scope.saveAssessmentButtonDisable = false;
                                      }
                                    }
                                  });
                                  break;
                                case 'Radio':
                                case 'DropDown':
                                case 'Gridview':
                                  if(selectedAnswer.answerId !== null && selectedAnswer.answerId !== undefined && selectedAnswer.answerId !== '')
                                  {
                                    question.selectedAns = selectedAnswer.answerId;
                                    scope.saveAssessmentButtonDisable = false;
                                  }
                                  break;
                              }
                            }
                          });
                        });
                     
                        if (scope.questions.length > 0) {
                          scope.questionsLength = scope.questions.length - 1;
                          scope.completeTaskPopup = true;
                          scope.cancelPopup = false;

                          //calculate the last page index                         
                          var pages = Math.floor(scope.questions.length / scope.pageSize);
                          var remaining = scope.questions.length % scope.pageSize;
                          scope.lastPageIndex = pages + (remaining > 0 ? 1 : 0);
                          scope.openModal('openTaskPopUp', 'show');
                        }
                        else {
                          scope.questionsLength = 0;
                        }
                      }
                    });
                  };
                scope.saveButtonDisableForText = function (inputValue, type) {
                    if (type === 'Text') {
                      scope.transformedInput = inputValue.toLowerCase().replace(/ /g, '');
                      if (scope.transformedInput === '') {
                        scope.saveAssessmentButtonDisable = true;
                        return true;
                      } else {
                        scope.saveButtonDisable(false);
                        return false;
                      }
                    }
                    else if (type === undefined)
                    {
                      scope.saveButtonDisable(false);
                      return false;
                    }
                  };

                scope.saveButtonDisable = function (value) {
                  scope.cancelPopup = true;
                  if(validateAtLeastOneQuestionIsAnswered() === true)
                  {
                    scope.saveAssessmentButtonDisable = value;
                  }
                  else
                  {
                    scope.saveAssessmentButtonDisable = true;
                  }
                };

                var validateAnswerArray = function(ans){
                  if(angular.isArray(ans)){
                    if(ans.length > 0){
                      return true;
                    }else{
                      return  false;
                    }
                  }else{
                    return true;
                  }
                };

                var validateAtLeastOneQuestionIsAnswered = function() {
                  var isAtLeastOneQuestionAnswered = false;
                  angular.forEach(scope.questions, function (ans) {
                    if(!isAtLeastOneQuestionAnswered)
                    {
                      if (ans.selectedAns !== null && ans.selectedAns !== undefined && ans.selectedAns !== '' && ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns))
                      {
                        isAtLeastOneQuestionAnswered = true;
                      }
                    }
                  });
                  return isAtLeastOneQuestionAnswered;
                };

                scope.saveAssessmentSurvey = function (type) {
                  var popupid = type === 'save' ? 'saveConfirm' : 'completeConfirm';
                  var TypeName = type === 'complete' ? 'Complete' : 'Pending';
                  patientAssessmentSurvey = [];
                  angular.forEach(scope.questions, function (ans) {
                    switch (ans.answerControlType) {
                      case 'Radio':
                      case 'DropDown':
                      case 'Gridview':
                        var surveyAnswered = {
                          assessmentId: scope.assessmentId,
                          userAssessmentId: scope.userAssessmentID,
                          assessmentSetQuestionId: ans.assessmentSetQuestionId,
                          answerId: (ans.selectedAns === undefined || (ans.selectedAns !== null && ans.selectedAns.length === 0) ) ? null : ans.selectedAns,
                          answerComments: TypeName,
                          answerString: ''
                        };
                        if((ans.answerControlType === 'Radio' || ans.answerControlType === 'Gridview') && ans.selectedAns !== '' && ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns))
                        {
                          patientAssessmentSurvey.push(surveyAnswered);
                        }
                        else if(ans.answerControlType === 'DropDown')
                        {
                          if(ans.selectedAns === '' || (ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns)))
                          {
                            patientAssessmentSurvey.push(surveyAnswered);
                          }
                        }
                        break;
                      case 'Text':
                        if(ans.selectedAns === '' || (ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns)))
                        {
                          angular.forEach(scope.data.Answers, function (testAns) {
                            if (testAns.assessmentSetQuestionId === ans.assessmentSetQuestionId) {
                              var surveyAnsweredText = {
                                assessmentId: scope.assessmentId,
                                userAssessmentId: scope.userAssessmentID,
                                assessmentSetQuestionId: ans.assessmentSetQuestionId,
                                answerId: testAns.answerId,
                                answerComments: TypeName,
                                answerString: ans.selectedAns
                              };
                              patientAssessmentSurvey.push(surveyAnsweredText);
                            }
                          });
                        }
                        break;
                      case 'DateTime':
                        if (ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns)) {
                          if (ans.selectedAns !== null) {
                            var year = ans.selectedAns.getFullYear();
                            var month = ans.selectedAns.getMonth() + 1;
                            if (month < 10) {
                              month = '0' + month;
                            }
                            var day = ans.selectedAns.getDate();
                            var hours = ans.defaultTime.getHours();
                            var minutes = ans.defaultTime.getMinutes();
                            scope.dateTime = month + '/' + day + '/' + year + ' ' + hours + ':' + minutes;
                          } else {
                            scope.dateTime = '';
                          }
                          angular.forEach(scope.data.Answers, function(testAns) {
                            if (testAns.assessmentSetQuestionId === ans.assessmentSetQuestionId) {
                              var surveyAnsweredText = {
                                assessmentId: scope.assessmentId,
                                userAssessmentId: scope.userAssessmentID,
                                assessmentSetQuestionId: ans.assessmentSetQuestionId,
                                answerId: testAns.answerId,
                                answerComments: TypeName,
                                answerString: scope.dateTime
                              };
                              patientAssessmentSurvey.push(surveyAnsweredText);
                            }
                          });
                        }
                        break;
                      case 'Radio.Text':
                      case 'Radio.Text.Label':
                        var selectId = parseInt(ans.selectedAns, 10);
                        angular.forEach(scope.answers, function (radioAns) {
                          if (radioAns.answerId === selectId) {
                            var surveyAnsweredRadioText = {
                              assessmentId: scope.assessmentId,
                              userAssessmentId: scope.userAssessmentID,
                              assessmentSetQuestionId: ans.assessmentSetQuestionId,
                              answerId: ans.selectedAns,
                              answerComments: TypeName,
                              answerString: radioAns.enteredAnswer
                            };
                            patientAssessmentSurvey.push(surveyAnsweredRadioText);
                          }
                        });
                        break;
                      case 'Checkbox':
                        if(ans.selectedAns.length === 0)
                        {
                          var surveyAnsweredCheckBox = {
                              assessmentId: scope.assessmentId,
                              userAssessmentId: scope.userAssessmentID,
                              assessmentSetQuestionId: ans.assessmentSetQuestionId,
                              answerId: null,
                              answerComments: TypeName,
                              answerString: ''
                            };
                          patientAssessmentSurvey.push(surveyAnsweredCheckBox);
                        }
                        angular.forEach(ans.selectedAns, function (checkboxAns) {
                          if(ans.selectedAns !== '' && ans.selectedAns !== [] && validateAnswerArray(ans.selectedAns))
                          {
                            var surveyAnsweredCheckBox = {
                              assessmentId: scope.assessmentId,
                              userAssessmentId: scope.userAssessmentID,
                              assessmentSetQuestionId: ans.assessmentSetQuestionId,
                              answerId: checkboxAns,
                              answerComments: TypeName,
                              answerString: ''
                            };
                            patientAssessmentSurvey.push(surveyAnsweredCheckBox);
                          }
                        });
                        break;
                      case 'Checkbox.Text':
                      case 'Checkbox.Text.Label':
                        angular.forEach(ans.selectedAns, function (checkboxid) {
                          var selectId = parseInt(checkboxid, 10);
                          angular.forEach(scope.answers, function (checkboxString) {
                            if (checkboxString.answerId === selectId) {
                              var surveyAnswered = {
                                assessmentId: scope.assessmentId,
                                userAssessmentId: scope.userAssessmentID,
                                assessmentSetQuestionId: ans.assessmentSetQuestionId,
                                answerId: checkboxid,
                                answerComments: TypeName,
                                answerString: checkboxString.enteredAnswer
                              };
                              patientAssessmentSurvey.push(surveyAnswered);
                            }
                          });
                        });
                        break;
                    }
                    
                  });
                  if (patientAssessmentSurvey.length > 0) {
                    angular.forEach(patientAssessmentSurvey, function (answer) {
                      if (selectedAnswers.length > 0) {
                        angular.forEach(selectedAnswers, function (previousAns) {
                          if (previousAns.assessmentSetQuestionId === answer.assessmentSetQuestionId) {
                            answer.userAssessmentAnswersId = previousAns.userAssessmentAnswersId;
                          }
                        });
                      }
                      else {
                        answer.userAssessmentAnswersId = 0;
                      }
                    });
                    patientAssessmentSvc.savePatientAssessmentSurvey('patients/' + patientData.id + '/assessmentssurvey', { patientAssessmentSurvey: patientAssessmentSurvey }).then(function (response) {
                      if (response.data.results) {
                        if (response.data.results.status === true) {

                          if (type === 'save') {
                            scope.UnlockConcurrentTask();
                            scope.alertMessage({alertmessage: 'Successfully saved your Assessment Task', alerttype: 'alert-success'});
                          }
                          else {
                            scope.$emit('updateCompletTask');
                            scope.alertMessage({alertmessage: 'Task has been completed successfully.', alerttype: 'alert-success'});
                          }
                          scope.assessmentSurveyComplete = true;
                          $timeout(function () {
                            scope.assessmentSurveyComplete = false;
                          }, 8000);
                          scope.closeModal('openTaskPopUp', 'hide');
                          scope.closeModal('cancelConfirm', 'hide');
                          scope.closeModal('saveConfirm', 'hide');
                          scope.closeModal('completeConfirm', 'hide');
                          scope.enter();
                        }
                        else {
                          scope.closeModal(popupid);
                          scope.closeModal('saveConfirm', 'hide');
                          scope.enter();
                        }
                      }
                      else {
                        scope.closeModal(popupid);
                        scope.closeModal('saveConfirm', 'hide');
                      }
                    });
                  }
                  else {
                    scope.closeModal('openTaskPopUp', 'hide');
                    scope.closeModal('saveConfirm', 'hide');
                    scope.closeModal('completeConfirm', 'hide');
                  }
                };

                scope.openModal = function (className, action) {
                 
                  if (action === 'show') {

                    $('.' + className + '').modal({
                      backdrop: 'static',
                      keyboard: false
                    });
                  }
                  else {
                    $('.' + className + '').modal('' + action + '');
                  }
                };
               
                scope.closeModal = function (className) {
                  $('.' + className + '').modal('hide');
                };

                scope.closeAssessemtModel = function () {
                  scope.closeModal('cancelConfirm', 'hide');
                  scope.closeModal('openTaskPopUp', 'hide');
                  scope.UnlockConcurrentTask();
                };

                scope.UnlockConcurrentTask= function(){
                  scope.data={'lockType':'task'};
                  patientAssessmentSvc.putLockConcurrentTask(scope.data).then(function(){
                  });
                };

                scope.openDatePicker = function ($event, question) {
                    $event.stopPropagation();
                    $event.preventDefault();
                    angular.forEach(scope.data.Questions, function (q) {
                      q.isDatePickerOpen = false;
                    });
                    question.isDatePickerOpen = !question.isDatePickerOpen;
                  };
                scope.disabled = function (date, mode) {
                    return (mode === 'year' && (date.getDay() === 6 || date.getDay() === 0));
                  };
                
                scope.hstep = 1;
                scope.mstep = 15;

                scope.ismeridian = true;
            
                scope.openConfirmation = function (id) {
                  var target = $('#assessmentSurveyDiv');
                  target.scrollTop(0);
                  switch (id) {
                    case 'saveConfirm':
                      scope.openModal('saveConfirm', 'show');
                      break;
                    case 'cancelConfirmPopup':
                      scope.closeAssessemtModel();
                      break;
                    case 'cancelConfirm':
                      if (scope.cancelPopup === true) {
                        scope.openModal('cancelConfirm', 'show');
                      }
                        else {
                        scope.closeAssessemtModel();
                      }
                      break;
                    case 'completeConfirm':
                      checkIfAllTheMandatoryQuestionsAnswered();
                      if(scope.showMandatoryErrorMessage === false)
                      {
                        scope.openModal('completeConfirm', 'show');
                      }
                      break;
                  }
                };

                scope.prevPage = function ()
                {
                  if (scope.pageIndex-1 >= 1)
                  {
                    scope.showMandatoryErrorMessage = false;
                    scope.pageIndex = scope.pageIndex - 1;
                  }
                };

                scope.nextPage = function ()
                {
                  checkIfAllTheMandatoryQuestionsAnswered();
                  if (scope.questions.length > (scope.pageIndex * scope.pageSize) && scope.showMandatoryErrorMessage === false)
                  {
                    scope.pageIndex = scope.pageIndex + 1;
                  }
                };

                var checkIfAllTheMandatoryQuestionsAnswered = function()
                {
                  // form validation - all the mandatory questions should be answered before 
                  // navigating to next page
                  var count = 0;
                  scope.showMandatoryErrorMessage = false;
                  for(var x=(scope.pageIndex * scope.pageSize) - scope.pageSize; x < scope.questions.length; x=x+1)
                  {
                    if(scope.questions[x].isRequired === true)
                    {
                      if (scope.questions[x].selectedAns === null || scope.questions[x].selectedAns === undefined || scope.questions[x].selectedAns === '' || scope.questions[x].selectedAns === [] || !validateAnswerArray(scope.questions[x].selectedAns) || scope.saveButtonDisableForText(scope.questions[x].selectedAns, scope.questions[x].answerControlType))
                      {
                        scope.showMandatoryErrorMessage = true;
                        scope.setErrorNotification = 'Please answer all the mandatory questions';
                        break;
                      }
                    }
                    count = count + 1;
                    if(count === scope.pageSize)
                    {
                      break;
                    }
                  }
                };

              }
          };
      }]);
  }(window.app));