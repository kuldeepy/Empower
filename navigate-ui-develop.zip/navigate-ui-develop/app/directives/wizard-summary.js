﻿(function (app) {
  // @fmt:off
  'use strict';
  //@fmt:on

  app.directive('wizardSummaryStep', function () {
    return {
      restrict : 'E',
      replace: true,
      scope: {
        stepTitle: '@',
        editurl: '@',
        success: '='
      },
      templateUrl : '/templates/wizardSummaryStep.html',
      transclude: true
    };
  });
  app.directive('wizardSummarySubStep', function () {
    return {
      restrict : 'E',
      replace: true,
      scope: {
        stepTitle: '@',
        editurl: '@',
        success: '='
      },
      templateUrl : '/templates/wizardSummarySubStep.html',
      transclude: true
    };
  });
  app.directive('wizardSummarySubSteps', function () {
    return {
      restrict : 'E',
      replace: true,
      templateUrl : '/templates/wizardSummarySubSteps.html',
      transclude: true
    };
  });
  app.directive('wizardSummary', function () {
    return {
      restrict : 'E',
      scope: {
        stepTitle: '@'
      },
      replace: true,
      templateUrl : '/templates/wizardSummary.html',
      transclude: true
    };
  });
}(window.app));