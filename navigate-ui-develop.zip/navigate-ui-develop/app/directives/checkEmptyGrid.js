(function (app) {
  // @fmt:off
  'use strict';
  //@fmt:on

  app.directive('checkEmptyGrid', function ($compile, $timeout) {
    return function (scope, element, attrs) {
      var msg = 'No data to display';
      var template = '<p ng-hide=' + attrs.checkEmptyGrid + '.length>' + msg + '</p>';
      var tmpl = angular.element(template);
      $compile(tmpl)(scope);
      $timeout(function () {
        element.find('.ngViewport').append(tmpl);
      }, 0);
    };
  });
}(window.app));