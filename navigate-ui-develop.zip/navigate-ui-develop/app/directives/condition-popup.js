﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msConditionPopup', function () {
        return {
            restrict: 'E',
            templateUrl: '/modules/patient-search/templates/patient-conditions-popup.html'
          };
      });
    
  }(window.app));