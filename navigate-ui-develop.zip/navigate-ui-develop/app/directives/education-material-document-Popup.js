﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msEducationMaterialDocumentPopup', [function () {
        return {
            restrict: 'E',
            templateUrl: '/templates/education_material_document_popup.html'
          };
      }]);
  }(window.app));