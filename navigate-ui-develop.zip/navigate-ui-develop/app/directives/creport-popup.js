(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msCreportPopup', function () {
        return {
            restrict: 'E',
            templateUrl: '/templates/patient-filter-popup.html'
          };
      });
    
  }(window.app));