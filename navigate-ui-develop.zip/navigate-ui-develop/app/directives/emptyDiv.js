( function (app) {
    'use strict';
    app.directive('emptyDiv', function() {
      return {
        link: function(scope, elt) {
            scope.remove = function(status) {
                elt.html('');
                if(angular.equals(status,'cancel')){
                  scope.clickCancel();
                }
                else{
                  scope.TrendType();
                }
              };
          }
      };
    });
  }(window.app));