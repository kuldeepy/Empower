(function (app){
  'use strict';
  app.directive('medWizard', [ '_', '$state', 'formatService','$timeout','$modal',

  function (_, state, formatService, $timeout, $modal) {
    return {
      restrict : 'E',
      replace: true,
      scope : true,
      templateUrl : '/templates/wizard.html',
      link : function (scope,ele,attr) {

        scope.wizardtabdefinition = scope.$eval(attr.wizardtabdefinition);
        scope.wizardflow = scope.$eval(attr.wizardflow);
        scope.hideCancel = scope.$eval(attr.hideCancel);
        scope.wizardstepdefinition = scope.$eval(attr.wizardstepdefinition);
        scope.beforeNext = scope.$eval(attr.beforeNext);
        //scope.onWizardSave = scope.$eval(attr.onWizardSave);
        //scope.onWizardClose = scope.$eval(attr.onWizardClose);
        scope.wizardHeader = scope.$eval(attr.wizardHeader);
        localStorage.setItem('isWizardFormDirty', false);

        if(scope.isSaveAsDraftDisabled === undefined){ //if not initialized set it to true
          scope.isSaveAsDraftDisabled = true;
        }

        if(scope.isSaveDisabled === undefined){ //if not initialized set it to true
          scope.isSaveDisabled = false;
        }

        if(scope.hideSaveAsDraft === undefined){ //if not initialized set it to true
          scope.hideSaveAsDraft = true;
        }

        if(scope.hideDeclined === undefined){ //if not initialized set it to true
          scope.hideDeclined = true;
        }

        var wizardWorkflowFilterValue;
        var resetState = function () {
          scope.isNotFirstStepInFlow = false;
          scope.isStepComplete = false;
          scope.isNextDisabled = true;
          scope.isPreviousDisabled = false;
          scope.isSaveAndCloseDisabled = false;
          scope.isCancelDisabled = false;
          scope.isCancelAlertVisible = false;
          scope.isSavePromptVisible = false;
          scope.isDeclinedDisabled = true;
        };

        resetState();
        var firstStep = {};
        firstStep = _.findWhere(scope.wizardflow,{id : 1});

        //var isFormDirty;
        scope.modalInstance = {};

        scope.close = function () {
          if (scope.isFormDirty !== 'false') {
            scope.modalInstance.close(true);
          }
          scope.isFormDirty ='';
          $timeout(function () {
            scope.$broadcast('wizardOnClose');
          }, 500);
        };

        scope.stepComplete = function (complete) {
          scope.isStepComplete = complete;
          enableNextButton(complete);
        };

        scope.saveAndClose = function () {
          scope.$broadcast('wizardOnsaveAndClose');
        };

        scope.saveDraftAndClose = function () {
          scope.$broadcast('wizardOnsaveDraftAndClose');
        };

        scope.updateButtonVisibility = function () {
          scope.isNotFirstStepInFlow = state.current.name !== firstStep.name;
        };


        scope.decline = function ()  {
          scope.$broadcast('wizardOnDecline');
        };
        scope.setBeforeNext= function(fn){
          scope.beforeNext = fn;
        };

        scope.goToNext = function () {
          var proceed = true;
          if (scope.beforeNext) {
            var retVal = scope.beforeNext();
            proceed = (retVal !== undefined ? retVal : true);
          }
          if (proceed) {
            state.go(getState(true));
            scope.$broadcast('wizardOnNext');
          }
        };

        scope.goToPrevious = function () {
          state.go(getState(false));
          scope.$broadcast('wizardOnPrev');
        };

        var getState = function (isForward) {
          //All STEPS (not tabs) need to be in this array for the 'next' button to correctly navigate through the flow.
          var workflow = scope.wizardflow;
          var currentIndex = 0;
          for (var i = 0; i < workflow.length; i = i + 1) {
            if (workflow[i].name === state.current.name ) {
              currentIndex = i;
              break;
            }
            else{
              if(workflow[i].routeBasedOnFilter !== undefined)
              {
                for(var c = 0; c < workflow[i].routeBasedOnFilter.length; c = c + 1 ){
                  if(workflow[i].routeBasedOnFilter[c].routeToControl === state.current.name){
                    currentIndex = i;
                    break;
                  }
                }
              }
            }
          }
          
          if (isForward) {
            
            if(workflow[currentIndex + 1].routeBasedOnFilter !== undefined){
                          
              for(var r = 0; r < workflow[1].routeBasedOnFilter.length; r = r + 1 ){
                if(workflow[currentIndex + 1].routeBasedOnFilter[r].filterName === wizardWorkflowFilterValue){
                  return workflow[currentIndex + 1].routeBasedOnFilter[r].routeToControl;
                }
              }
            }
            return currentIndex < workflow.length ? workflow[currentIndex + 1].name : workflow[currentIndex].name;
          }
          else {

            return currentIndex > 0 ? workflow[currentIndex - 1].name : workflow[currentIndex].name;
          }
        };

        var getStep = function(stepName){
          var step =_.findWhere(scope.steps,{name : stepName});
          return step;
        };

        scope.completeStep = function (complete,stepName,title) {
          scope.isStepComplete = complete;
          var stepElement = getStep(stepName);
          if(stepElement){

            stepElement.completed = complete;
          
            if(title !== undefined){
              wizardWorkflowFilterValue = title;
              stepElement.title = formatService.truncate(title,23);
            }
            enableNextButton(complete);
            if(stepName === 'enrollmentPatientDetails')
            {
              scope.isDeclinedDisabled = complete;
              scope.hideDeclined = complete;
            }
          }
        };

        var enableNextButton = function (enable) {

          var curSubStep = 0;
          var flag = false;
          var currentTabIndex = -1;

          for (var i = 0; i < scope.wizardstepdefinition.length; i = i + 1) {
            currentTabIndex = currentTabIndex + 1;
            flag =false;
            for (var j = 0; j < scope.wizardstepdefinition[currentTabIndex].length; j = j + 1) {
              curSubStep = j;
              if (scope.wizardstepdefinition[currentTabIndex][j].name === state.current.name) {
                if (curSubStep <= scope.wizardstepdefinition[currentTabIndex].length) {
                  flag =true;
                  break;
                }
              }
            }
            if(flag === true)
            {
              break;
            }
          }
          
          scope.wizardstepdefinition[currentTabIndex][curSubStep].isTabCompleted = enable;
          var isAllSubStepsCompleted = enable;
          for (var p = 0; p < scope.wizardstepdefinition[currentTabIndex].length; p = p + 1)
          {
            if(!scope.wizardstepdefinition[currentTabIndex][p].isTabCompleted)
            {
              isAllSubStepsCompleted = false;
            }
          }
          scope.wizardtabdefinition[currentTabIndex].isTabCompleted = isAllSubStepsCompleted;
         
          if (enable === true) {
            scope.isNextDisabled = !scope.isStepComplete;

            // find the step which has next button enabled
            // loop through the wizard step definition
            // enable the current and next tab
            for (var x = 0; x <= currentTabIndex+1; x = x + 1) {

              if( x < currentTabIndex ) // previous tabs clickable
              {
                scope.wizardtabdefinition[x].clickable = true; // previous tabs will be clickable
                scope.wizardtabdefinition[x].isTabCompleted = true; // set previous is completed to true
                // make previous sub tabs of tab scope.wizardtabdefinition[x] also be clickable
                for(var t=scope.wizardstepdefinition[x].length -1; t>=0;t=t-1)
                {
                  scope.wizardstepdefinition[x][t].clickable = true;
                  scope.wizardstepdefinition[x][t].isTabCompleted = true;
                }
              }
              else if (x === currentTabIndex ){ //if current tab
                for(var m=0; m<scope.wizardstepdefinition[currentTabIndex].length;m=m+1)
                {
                  // current tab is clickable
                  scope.wizardtabdefinition[currentTabIndex].clickable = true;
                  // if current sub step / previous sub steps - make it clickable 
                  if( m <= curSubStep){
                    scope.wizardstepdefinition[currentTabIndex][m].clickable = true;
                    // if the current sub step is the last step in the current tab then make 
                    // next tab and first sub step in the next tab clickable
                    if ( curSubStep === scope.wizardstepdefinition[currentTabIndex].length-1){
                      if(scope.wizardtabdefinition.length-1 > x){
                        scope.wizardtabdefinition[x+1].clickable = true;
                        scope.wizardstepdefinition[x+1][0].clickable = true;
                        break;
                      }
                    }
                    // else make the next sub step clickable
                    else{
                      scope.wizardstepdefinition[currentTabIndex][m+1].clickable = true;
                      if(m === curSubStep)
                      {
                        break;
                      }
                    }

                  }
                  // next sub steps - clickable false
                  else if( m > curSubStep){
                    scope.wizardstepdefinition[currentTabIndex][m].clickable = false;
                  }
                }
              }
            }//end for loop

            // all the steps should be clickable if the status is completed. this should be executed only after the above loops are over
            var isTabClickable = true;
            for(var k = 0; k < scope.wizardtabdefinition.length; k=k+1){
              if(scope.wizardtabdefinition[k].isTabCompleted === true)
              {
                scope.wizardtabdefinition[k].clickable = isTabClickable;
                for (var l = 0; l < scope.wizardstepdefinition[k].length; l = l + 1)
                {
                  if(!scope.wizardstepdefinition[k][l].isTabCompleted)
                  {
                    isTabClickable = false;
                    if(l === scope.wizardstepdefinition[k].length-1)
                    {
                      scope.wizardstepdefinition[k][l].clickable = true;
                    }
                  }
                  else
                  {
                    scope.wizardstepdefinition[k][l].clickable = true;
                  }
                }
              }
              else
              {
                break;
              }
            }
          }
          // this loop should execute when user fills all the steps / some of the steps and coming back to one of the 
          // completed step and removes the mandatory information. We need to restrict the forward movement
          else
          {
            for(var g=currentTabIndex; g<scope.wizardtabdefinition.length;g=g+1)
              {
              if(g !== currentTabIndex){
                scope.wizardtabdefinition[g].clickable = false;
              }
              for(var h=curSubStep;h<scope.wizardstepdefinition[g].length;h=h+1)
              {
                if(curSubStep === h && currentTabIndex === g )
                {
                  scope.wizardstepdefinition[g][h].clickable = true;
                }else{
                  scope.wizardstepdefinition[g][h].clickable = false;
                }
              }
              curSubStep = 0;
            }//here
            scope.isNextDisabled = true;
          }
        };
        var enablePreviousButton = function (enable) {
          scope.isPreviousDisabled = !enable;
        };
        
        scope.showSaveAndClose = function (show) {

          scope.showSaveAndCloseButton = show;
          scope.showNextButton = !show;
          scope.showWizardSteps = !show;
          
        };

        var enableCancelButton = function (enable) {
          scope.isCancelDisabled = !enable;
        };

        scope.closeCancelAlert = function () {
          scope.modalInstance.close(true);
          scope.isCancelAlertVisible = false;
          enableCancelButton(true);
          enablePreviousButton(true);
          if(scope.isStepComplete)
          {
            scope.stepComplete(true);
          }
        };

        scope.showCancelAlert = function (show) {
          scope.enableButtons(!show);
          scope.isFormDirty = localStorage.getItem('isWizardFormDirty');
          if (scope.isFormDirty !== null && scope.isFormDirty === 'false') {
            scope.isCancelAlertVisible = !show;
            scope.close();
          }
          else {
            scope.popupAction();
          }
        };
          
        scope.popupAction = function () {
          scope.modalInstance = $modal.open({
            templateUrl: 'wizardCancelPopup.html',
            size: '',
            scope: scope,
            backdrop: 'static'
          });
        };

        scope.enableButtons = function (enable) {
          enableNextButton(enable);
          enableCancelButton(enable);
          enablePreviousButton(enable);
        };

        function getSteps() {
          return _.map(scope.wizardstepdefinition[scope.tabIndex], function (step, index) {
            return _.extend({}, step, {
              completed: index <= scope.stepIndex,
              selectionCss: scope.getSelectionCss(index, scope.stepIndex)
            });
          });
        }

        scope.steps = getSteps();
        scope.tabs = scope.wizardtabdefinition;

        function getWidth() {
          var tabWidth = {};
          var width = 100 / scope.tabs.length;
          tabWidth = {
            width: width + '%'
          };
          return tabWidth;
        }

        scope.tabWidth = getWidth();

        var updateWizardHeaders = function (currentStepName) {
          var tabIndex = 0;
          var stepIndex = 0;
          var tempTabs = [];
          var tempSteps = [];
            
          for (var i = 0; i < scope.wizardstepdefinition.length; i = i + 1) {
            for (var j = 0; j < scope.wizardstepdefinition[i].length; j = j + 1) {
              if (scope.wizardstepdefinition[i][j].name === currentStepName) {
                tabIndex = i;
                stepIndex = j;
              }
            }
          }

          for (var k = 0; k < scope.wizardtabdefinition.length; k = k + 1) {
            tempTabs.push(scope.wizardtabdefinition[k]);
          }
          for (var l = 0; l < scope.wizardstepdefinition[tabIndex].length; l = l + 1) {
            tempSteps.push(scope.wizardstepdefinition[tabIndex][l]);
          }

          for (var m = 0; m < scope.wizardtabdefinition.length; m = m + 1) {
            if (m === tabIndex) {
              tempTabs[m].completed = false;
              tempTabs[m].selectionCss = 'active';
              tempTabs[m].active = true;
            } else {
              tempTabs[m].active = false;
            }
            if (m < tabIndex) {
              tempTabs[m].completed = true;
              tempTabs[m].selectionCss = 'success';
            }
            if (m > tabIndex) {
              tempTabs[m].completed = false;
              tempTabs[m].selectionCss = 'inactive';
            }
            _.first(tempTabs).selectionCss += ' first';
            _.last(tempTabs).selectionCss += ' last';
          }

          for (var n = 0; n < scope.wizardstepdefinition[tabIndex].length; n = n + 1) {
            if (n === stepIndex) {
              tempSteps[n].completed = false;
              tempSteps[n].active = true;
              tempSteps[n].selectionCss = 'active';
            }
            else{
              tempSteps[n].active = false;
              tempSteps[n].completed = scope.wizardstepdefinition[tabIndex][n].completed;
              tempSteps[n].selectionCss = (tempSteps[n].completed) ? 'success' : 'inactive';
            }
          }

          while (scope.steps.length > 0) { scope.steps.pop(); }
          while (scope.tabs.length > 0) { scope.tabs.pop(); }
        
          for (var x = 0; x < tempTabs.length; x = x + 1) {
            scope.tabs.push(tempTabs[x]);
          }
          for (var y = 0; y < tempSteps.length; y = y + 1) {
            scope.steps.push(tempSteps[y]);
          }
        };
        scope.tabRedirect = function(name) {
          state.go(name);
          scope.$broadcast('tabClick',{'name':name});
        };

        scope.initializeStep = function (stepName, stepComplete, name) {
          scope.save = name ? name : 'Save';
          if (stepName === 'CampaignSummary') {
            scope.save = 'Save and Export';
          }
          scope.updateButtonVisibility();
          scope.stepComplete(stepComplete);
          updateWizardHeaders(stepName);
          scope.showSaveAndClose(stepComplete);
        };
        
        scope.initializeStep(firstStep.name,false);
        state.go(firstStep.name);
      }

    };
  }]);
}(window.app));