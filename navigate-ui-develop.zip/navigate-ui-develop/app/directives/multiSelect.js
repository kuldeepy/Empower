( function (app) {
  'use strict';
  app.directive('medMultiSelect', [ '$q','$filter',
    function($q,$filter) {
      return {
        restrict: 'E',
        require: 'ngModel',
        scope: {
          selectedLabel: '@',
          availableLabel: '@',
          displayAttr: '@',
          filterAttr: '@',
          available: '=',
          availableall: '=',
          disabledselected: '=',
          model: '=ngModel'
        },
        templateUrl : '/templates/multiSelect.html',
         
        link: function(scope, elm, attrs) {
          scope.selected = {
            available: [],
            current: []
          };

          scope.recordsCount=false;

          /* Handles cases where scope data hasn't been initialized yet */
          var dataLoading = function(scopeAttr) {
            var loading = $q.defer();
            if(scope[scopeAttr]) {
              loading.resolve(scope[scopeAttr]);
            } else {
              scope.$watch(scopeAttr, function(newValue) {
                if(newValue !== undefined){
                  loading.resolve(newValue);
                }
              });
            }
            return loading.promise;
          };

          /* Filters out items in original that are also in toFilter. Compares by reference. */
          var filterOut = function(original, toFilter) {
            var filtered = [];
            angular.forEach(original, function(entity) {
              var match = false;
              for(var i = 0; i < toFilter.length; i = i + 1) {
                if(toFilter[i][attrs.filterAttr] === entity[attrs.filterAttr]) {
                  match = true;
                  break;
                }
              }
              if(!match) {
                filtered.push(entity);
              }
            });
            return filtered;
          };

          scope.diasableEditData = function(toFilter){
            if(toFilter.length > 0){
              scope.model = scope.model.concat(toFilter);
              var unique = [];
              var blocked = [];
              unique.push(scope.model[0]);
              blocked.push(scope.model[0].id);
              for (var i = 1, j = scope.model.length; i < j; i = i+ 1){
                if (blocked.indexOf(scope.model[i].id) <= -1) {
                  unique.push(scope.model[i]);
                  blocked.push(scope.model[i].id);
                }
              }
              scope.model = unique;
            }
          };

          scope.refreshAvailable = function() {
            scope.availableall = filterOut(scope.availableall, scope.model);
            scope.selected.available = [];
            scope.selected.current = [];
          };

          var convertingStringObjecttoJSONObject = function(data){
            var modifiedData = [];
            _.each(data, function(item){
              modifiedData.push(JSON.parse(item));
            });
            return modifiedData;
          };

          scope.add = function() {
            scope.selected.available = convertingStringObjecttoJSONObject(scope.selected.available);
            scope.model = scope.model.concat(scope.selected.available);
            scope.diasableEditData(scope.selected.available);
            scope.refreshAvailable();
          };

          scope.addAll = function() {
            scope.model = scope.model.concat(scope.availableall);
            scope.diasableEditData(scope.availableall);
            scope.refreshAvailable();
          };

          scope.remove = function() {
            scope.selected.current = convertingStringObjecttoJSONObject(scope.selected.current);
            scope.availableall = scope.availableall.concat(scope.selected.current);
            scope.model = filterOut(scope.model, scope.selected.current);
            scope.diasableEditData(scope.disabledselected);
            scope.refreshAvailable();
          };

          scope.removeAll = function() {
            scope.availableall = scope.availableall.concat(scope.model);
            scope.model = filterOut(scope.model, scope.model);
            scope.diasableEditData(scope.disabledselected);
            scope.refreshAvailable();
          };

          scope.$watch('search', function(searchdata) {
            var data = $filter('filter')(scope.available, searchdata);
            scope.availableall = data;
            scope.refreshAvailable();
            if(data){
              scope.recordsCount = data.length===0 ? true:false;
            }
          });

          $q.all([dataLoading('model'), dataLoading('available')]).then(function() {
            scope.refreshAvailable();
          });
        }
      };
    }]);
}(window.app));