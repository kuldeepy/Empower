/**
 * @author michael.ash
 */
( function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on
    app.directive('medMessagesLeftNav', function () {
      return {
        restrict : 'E',
        replace : true,
        templateUrl : '/templates/navMessagesLeftMenu.html',
        scope : {
          count : '=',
          state : '@'
        },
        link : function (scope,element) {
          scope.version = '0.0.0';

          scope.switch = function(target) {
            element.find('div.menuitem').removeClass('active');
            element.find('div.menuitem'+'.'+target).addClass('active');
          };

        }
      };
    });
  }(window.app));
