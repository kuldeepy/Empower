/**
 * @author Andrew Searles
 * A button to show all results
 * 
 */
( function (app) {
  'use strict';
  app.directive('showAll', function () {
    return {
      restrict : 'E',
      replace : true,
      scope : {
          display :  '=',
          collection : '=',
          type : '=',
          limit : '=',
          refreshCallback : '=',
          params : '=',
          totalCollectionLength : '='
        },
        templateUrl : '/templates/showAll.html',
        link : function(scope) {
          
          scope.showAll = false;
          scope.limit = scope.display;
          var totalRecords = 0;
          
          scope.$watch('collection', function(){
            if(scope.totalCollectionLength) {
              totalRecords = scope.totalCollectionLength;
            }
          });
          
          scope.show = function() {
            scope.showAll = true;
            scope.$emit(scope.refreshCallback,  { pageSize: scope.display, pageNumber: null, params: scope.params });
            scope.limit = totalRecords;
          };
          
          scope.hide = function() {
            scope.showAll = false;
            scope.$emit(scope.refreshCallback,  { pageSize: scope.display, pageNumber: 1, params: scope.params });
            scope.limit = scope.display;
          };
          
          
        }
      };
  });
}(window.app));