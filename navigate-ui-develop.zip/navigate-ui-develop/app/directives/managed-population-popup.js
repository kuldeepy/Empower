﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msManagedPopulationPopup', function () {
        return {
            restrict: 'E',
            templateUrl: '/modules/patient-search/templates/patient-managed-population-popup.html'
          };
      });
  }(window.app));