(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msCareManagerPatientDetailsPopup', function () {
        return {
            restrict: 'E',
            templateUrl: '/templates/careManagerPatientDetail-Popup.html'
          };
      });
    
  }(window.app));