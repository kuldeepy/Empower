﻿(function (app) {
  // @fmt:off
  'use strict';
  //@fmt:on

  app.directive('frequencyOperator', function () {
    return {
      restrict : 'E',
      replace: true,
      scope: {
        title: '=',
        operators: '=',
        ngModel: '=',
        required: '=',
        ngChange : '='
      },
      templateUrl : '/templates/frequency-operator.html',
      transclude: true
    };
  });
}(window.app));