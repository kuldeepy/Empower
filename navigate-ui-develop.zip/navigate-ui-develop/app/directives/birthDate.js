(function(app){
  'use strict';
  app.controller('BirthdateController',['$scope',function(scope){
    var today = new Date();
    scope.dateOfBirth = {
      year : today.getFullYear(),
      month: today.getMonth(),
      day : today.getDate()
    };
    scope.spouseDOB= {
      year : today.getFullYear(),
      month: today.getMonth(),
      day : today.getDate()
    };
  }]).directive('medBirthdate',['$timeout',function(timer){

    var yearRange = (function () {
                var thisYear = new Date().getFullYear(),
                    minYear = thisYear - 120,
                    years = [],
                    x;
                for (x = minYear; x <= thisYear; x = x + 1) {
                  years.push({
                    key: x.toString(10),
                    value: x.toString(10)
                  });
                }
                return years;
              }());
    return {
        restrict: 'A',
        replace: true,
        scope: {
          dobModel : '=dob',
          componentId : '@id'

        },
        templateUrl: '/templates/birth-date.html',
        link: function (scope, element) {

          var sDay = element.find('.dob_day'),
              sMonth = element.find('.dob_month'),
              sYear = element.find('.dob_year'),
              today = new Date(),
              yl;
          function isLeapYear (year) {
            return (((year % 400) === 0) || (((year % 4) === 0) && ((year % 100) !== 0)));
          }

          scope.checkLeapYear = function () {
            var leapYearOption,
              x=0,
              years = sYear.find('option'),
              day = parseInt(sDay.val(), 10),
              month = parseInt(sMonth.val(), 10),
              selectedYear = sYear.val();
            years.show().removeAttr('disabled');
            if ((day === 29) && (month === 2)) {
              leapYearOption = years.filter(function () {
                var year = parseInt(this.label, 10);
                return isLeapYear(year);
              });
              years.hide().attr('disabled', 'disabled');
              leapYearOption.show().removeAttr('disabled');

              if ((selectedYear === undefined) || (sYear.find('option[value=' + selectedYear + ']').css('display') === 'none')) {
                while (isLeapYear(scope.options[x].value) === false) {
                  x = x + 1;
                }
                scope.dobModel.year = scope.options[x].value;
                leapYearOption.eq(0).prop('selected', true);

              }

            }

          };

          scope.showDays = function () {
            if (!sDay.val()) {
              return;
            }
            sDay.find('option').show().removeAttr('disabled');
            switch(sMonth.val()) {
              case '2':
                sDay.find('> option:nth-of-type(1n+30)').hide().attr('disabled', 'disabled');
                if ((scope.dobModel.day > '29')) {
                  scope.dobModel.day = '1';
                }
                if ((scope.dobModel.day === '29')){
                  scope.checkLeapYear();
                }
                break;
              case '4':
              case '6':
              case '9':
              case '11':
                sDay.find('option:nth-last-of-type(1)').hide().attr('disabled', 'disabled');
                if (scope.dobModel.day === '31') {
                  scope.dobModel.day = '1';
                }
                sYear.find('option').show().removeAttr('disabled');
                break;
              default :
                sYear.find('option').show().removeAttr('disabled');
                break;
            }
          };

          scope.options = yearRange;
          yl = scope.options.length - 1;
          scope.dobModel = {
            year : scope.options[yl].value,
            month : today.getMonth() + 1,
            day : today.getDate()
          };
          timer(scope.showDays,1);
        }

      };
  }]);
}(window.app));