(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on
    app.directive('printDiv',[function(){
      return {
        restrict: 'A',
        link: function(scope, element, attrs) {
          element.bind('click', function(evt){
            evt.preventDefault();
            var data = $(attrs.printDiv).html();
            if ($('iframe#printf').size() === 0) {
              $('html').append('<iframe id="printf" name="printf"></iframe>');
              var printf='printf';
              var mywindow = window.frames[printf];
              mywindow.document.write('<html><head><title></title><style> </style>' + '</head><body><div>' + data + '</div></body></html>');
              $(mywindow.document).ready(function(){
                mywindow.print();
                setTimeout(function(){
                  $('iframe#printf').remove();
                },
              2000);
              });
            }
            return true;
          });
        }
      };
    }
  ]);

    app.directive('pdfDiv',[function(){
      return {
        restrict: 'A',
        link: function(scope, element, attrs) {
          element.bind('click', function(evt){
            evt.preventDefault();
            var pdf = new jsPDF('p', 'pt', 'letter');
            var source = $(attrs.pdfDiv).html();
            var specialElementHandlers = {
              '#bypassme': function () {
                return true;
              }
            };
            var margins = {top: 80,bottom: 60,left: 40,width: 522};
            pdf.fromHTML(
              source,
              margins.left,
              margins.top, {
                'width': margins.width,
                'elementHandlers': specialElementHandlers
              },
              function () {
                pdf.save('VisitPlan.pdf');
              },
              margins);
            return true;
          });
        }
      };
    }
    ]);
  }(window.app));