/**
 * @author michael.ash
 */
( function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on
    app.directive('medModal', function () {
      return {
        restrict : 'E',
        replace : true,
        transclude : true,
        scope : {
          activate : '=',
          id : '@'
        },
        templateUrl : '/templates/modalAlpha.html',
        link : function (scope, element) {
          scope.$watch('activate', function (val) {
            if (val === true) {
              element.addClass('active').attr('aria-hidden','false').closest('body').addClass('dialogIsOpen');
            } else {
              element.removeClass('active').attr('aria-hidden','true').closest('body').removeClass('dialogIsOpen');
            }
          });

        }
      };
    });
  }(window.app));
