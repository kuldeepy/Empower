﻿(function (app){
      'use strict';
      app.directive('scrollTo', ['$window', function ($window) {
        return {
          restrict: 'AC',
          compile: function () {
            var document = $window.document;
            function scrollInto(idOrName)
            {
              if (!idOrName){
                $window.scrollTo(0, 0);
              }
              var elementNameOrId = document.getElementById(idOrName);
              if (!elementNameOrId) {
                elementNameOrId = document.getElementsByName(idOrName);
                if (elementNameOrId && elementNameOrId.length) {
                  elementNameOrId = elementNameOrId[0];
                }
                else {
                  elementNameOrId = null;
                }
              }
              if (elementNameOrId) {
                elementNameOrId.scrollIntoView();
              }
            }
            return function (scope, element, attr) {
              element.bind('click', function () {
                scrollInto(attr.scrollTo);
              });
            };
          }
        };
      }]);
    }(window.app));