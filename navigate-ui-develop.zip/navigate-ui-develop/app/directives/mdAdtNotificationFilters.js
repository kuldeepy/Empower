(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('mdAdtNotificationfilters', [function () {
        return {
            restrict: 'E',
            templateUrl: '/modules/notifications/templates/mdAdtNotificationFilters.html'
          };
      }]);
  }(window.app));