(function (app) {
	'use strict';

	app.directive('equalizer', function () {

		return function (scope) {
			var col1 = $('.content-body .main .view'),
					col2 = $('.content-body .nav-secondary'),
					col1Inner = $('.content-body .main .view'),
					col2Inner = $('.content-body .nav-secondary');

			scope.monitorHeight = function () {
				return {
					'col1Height': col1Inner.outerHeight(true),
					'col2Height': col2Inner.outerHeight(true)
				};
			};

			var changeHeight = function () {

				col1.css('min-height', '800px');
				col2.css('min-height', '800px');

				var biggestHeight = (col1.outerHeight(true) > col2.outerHeight(true)) ? col1.outerHeight(true) : col2.outerHeight(true);

				if (col1.outerHeight(true) > col2.outerHeight(true)) {
					col1.css('min-height', '800px');
					col2.css('min-height', biggestHeight+'px');
				} else {
					col1.css('min-height', biggestHeight+'px');
					col2.css('min-height', '800px');
				}

			};

			scope.$watch(scope.monitorHeight, function () {
				changeHeight();
			}, true);

		};
	});
})(window.app);
