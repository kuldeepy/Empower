( function (app) {
    'use strict';
    app.directive('rangeSlider', function(){
      return {
        restrict: 'A',
        scope: {
          values: '=ngModel',
          boundaries : '=',
          handles : '='
        },
        link: function(scope, element, attr){
          scope.slider = null;
          var create = function () {
            scope.slider = document.createElement('div');
            $(scope.slider).noUiSlider({
              range: scope.boundaries,
              start: scope.values,
              step: attr.step,
              handles : scope.handles
            })
            .change(function(){
              var values = $(this).val();
              scope.$apply(function(){
                scope.values[0] = values[0];
                scope.values[1] = values[1];
              });
            });
            element[0].appendChild(scope.slider);
          };
          var remove = function() {
            element[0].removeChild(scope.slider);
            scope.slider = null;
          };
          var update =  function() {
            if(scope.slider !== null) {
              remove();
            }
            create();
          };
          scope.$watch('boundaries',update);
          scope.$watch('handles',update);
        }
      };
    });
  }(window.app));