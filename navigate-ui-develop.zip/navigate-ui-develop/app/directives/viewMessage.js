﻿(function (app) {
  'use strict';

  /* directive for blue button popup */
  app.directive('msViewMessage', [function () {
    return {
      restrict: 'E',
      templateUrl: app.root + 'modules/message-center/templates/view-message.html'
    };
  }]);

}(window.app));