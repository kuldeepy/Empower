(function (app) {
  // @fmt:off
  'use strict';
  //@fmt:on

  app.directive('angClick', function ($parse)
  {
    return {
      restrict: 'A',
      compile: function ($element, attr) {
        var fn;
        fn = $parse(attr.angClick);
        return function (scope, element) {
          return element.on('click', function (event) {
            return scope.$apply(function () {
              return fn(scope, {
                $event: event
              });
            });
          });
        };
      }
    };
  });
}(window.app));