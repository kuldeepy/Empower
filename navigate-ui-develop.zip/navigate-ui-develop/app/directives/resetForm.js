( function (app) {
    'use strict';
    app.directive('resetField', [function() {
      return {
        require: 'ngModel',
        scope: {},
        link: function(scope, el, attrs, ctrl) {
          el.bind('input', function() {
            scope.enabled = !ctrl.$isEmpty(el.val());
          })
          .bind('focus', function() {
            scope.enabled = !ctrl.$isEmpty(el.val());
            scope.$apply();
          })
          .bind('blur', function() {
            if(ctrl.$modelValue === ''){
              ctrl.$setPristine();
            }
            if(ctrl.$viewValue === ''){
              ctrl.$setPristine();
            }
            scope.enabled = true;
            scope.$apply();
          });
        }
      };
    }]);
  }(window.app));