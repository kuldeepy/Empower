/**
 * @author michael.ash
 */
( function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on
    app.directive('medExpandableMenuItem', function () {
      return {
        restrict : 'E',
        replace : true,
        templateUrl : '/templates/navExpandableMenuItem.html',
        scope : {
          item : '='
        },
        link : function (scope, element) {
          scope.isCollapsed = true;
          scope.showList = function () {
            element.find('>ul').toggleClass('hidden');
            element.addClass('selected');
          };
        }
      };
    });
  }(window.app));
