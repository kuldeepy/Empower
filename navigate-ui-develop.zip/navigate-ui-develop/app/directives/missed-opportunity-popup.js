﻿(function (app) {
    // @fmt:off
    'use strict';
    //@fmt:on

    app.directive('msMissedOpportunityPopup', [function () {
        return {
            restrict: 'E',
            templateUrl: '/modules/patient-search/templates/patient-missedOpportunity-popup.html'
          };
      }]);
  }(window.app));