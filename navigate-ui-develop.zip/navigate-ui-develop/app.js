// require dependencies
var ui = require('ui-core')();

// include extensions
ui.use({
  app: function(app, conf) {
    var gzip = require('connect-gzip').gzip(conf.server.gzip);
    app.use(gzip);
  }
});

ui.use(require('iui-table'));
ui.use(require('iui-alerts'));

// start the UI server
ui.start();
