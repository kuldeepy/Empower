'use strict';
var fs = require('fs');
var path = require('path');

var appDir = process.cwd().replace('node_modules/ui-core', '').replace('node_modules\\ui-core', '');
var targetFile = path.join(appDir, 'newrelic.js');
console.log('ensuring', targetFile);

if (!fs.existsSync(targetFile)) {
  var sourceFile = path.join(process.cwd(), 'newrelic.js');
  console.log('copy', sourceFile, targetFile);
  fs.createReadStream(sourceFile).pipe(fs.createWriteStream(targetFile));
}