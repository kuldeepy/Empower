var gulp = require('gulp');
var concat = require('gulp-concat');
var minify = require('gulp-uglify');
var rename = require('gulp-rename');

gulp.task('default', function(){
  gulp.src('./lib/main/**/*.js')
    .pipe(concat('main.js'))
    .pipe(gulp.dest('./lib/content/js'))
    .pipe(rename('main.min.js'))
    .pipe(minify())
    .pipe(gulp.dest('./lib/content/js'));
});