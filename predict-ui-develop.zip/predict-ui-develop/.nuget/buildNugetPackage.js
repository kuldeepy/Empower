var fs = require('fs');
var exec = require('child_process').exec;
var packageJson = require('../package.json');

var name = packageJson.name;
var version = packageJson.version;
version = version.replace('+','.');

var description = packageJson.description;
var author = packageJson.author;

var template = fs.readFileSync('.nuget/predict-ui.nuspec.template', 'UTF-8');

var nuspec = template.replace("#VERSION#", version)
                     .replace("#ID#", name)
                     .replace("#DESCRIPTION#", description)
                     .replace("#AUTHORS#", author);

fs.writeFileSync('predict-ui.nuspec', nuspec);

var child = exec('.nuget\\nuget.exe pack predict-ui.nuspec -OutputDirectory packages', function(error, stdout, stderr) {
  console.log('stdout: ' + stdout);
  if(stderr !== null) {
    console.log('stderr: ' + stderr);
    if(error === null) {
      error = new Error(stderr);
    }
  }
  if(error !== null) {
    console.log('exec error: ' + error);
    //process.exit(error.code);
  }
});