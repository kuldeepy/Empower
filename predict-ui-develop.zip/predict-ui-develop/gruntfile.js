/**
 * @author Michael.Ash
 */
module.exports = function (grunt) {
  //@fmt:off
  'use strict';
  //@fmt:on
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
    execute: {
      app: {
        src: ['app.js']
      }
    },
    express: {
      dev: {
        options: {
          script: 'app.js',
          port: 4444
        }
      }
    },
    jshint: {
      jshintrc: 'true',
      dev: {
        files: {
          src: ['gruntfile.js', 'karma.conf.js', 'config/**/*.js',
            'app/**/*.js', '!app/bower_components/**',
            '!app/js/angular-animate.js', '!app/js/lodash.js', '!app/js/FileSaver.js', '!app/js/leaflet-PruneCluster.js']
        },
        options: {
          jshintrc: 'config/.jshintrc'
        }
      },
      test: {
        files: {
          src: ['test/**/*.js']
        },
        options: {
          jshintrc: 'config/.jshintrc',
          ignores: ['test/angular-mocks.js', 'test/test-helper.js']

        }
      }
    },
    karma: {
      unit: {
        configFile: 'karma.conf.js'
      },
      continuous: {
        configFile: 'karma.conf.js',
        singleRun: true,
        browsers:['PhantomJS']
      }
    },
    jsdoc: {
      dist: {
        src: ['app/layouts/**/*.js', 'app/modules/**/*.js', 'app/services/**/*.js'],
        options: {
          destination: 'doc'
        }
      }
    },
    csslint: {
      options: {
        csslintrc: 'config/.csslintrc'
      },
      src: ['/app/themes/default/main.css']
    },
    sass: {
      dist: {
        options: {
          compass: true,
          style: 'expanded'
        },
        files: {
          'app/themes/default/main.css': 'app/themes/styles-sass/main.scss'
        }
      }
    },
    watch: {
      scripts: {
        files: ['<%= jshint.dev.files.src %>','!**/node_modules/**'],
        tasks: ['jshint:dev']
      },
      styles: {
        files: ['app/themes/styles-sass/**/**/*.scss'],
        tasks: ['sass:dist']
      },
      tests: {
        files: ['<%= jshint.test.files.src %>'],
        tasks: ['jshint:test', 'karma']
      },
      express: {
        files: ['**/*.js','!**/node_modules/**'],
        tasks: ['express:dev'],
        options: {
          spawn: false // Without this option specified express won't be
          // reloaded
        }
      }
    }

  });
  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-karma');
  grunt.loadNpmTasks('grunt-contrib-jasmine');
  grunt.loadNpmTasks('grunt-contrib-sass');
  grunt.loadNpmTasks('grunt-contrib-csslint');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-express-server');
  grunt.loadNpmTasks('grunt-jsdoc');
  grunt.loadNpmTasks('grunt-execute');


  // on watch events configure jshint:all to only run on changed file
  grunt.event.on('watch', function (action, filepath) {
    grunt.config(['jshint', 'dev'], filepath);
  });
  grunt.registerTask('forceOn', 'turns the --force option ON', function () {
    if (!grunt.option('force')) {
      grunt.config.set('forceStatus', true);
      grunt.option('force', true);
    }
  });

  grunt.registerTask('forceOff', 'turns the --force option Off', function () {
    if (grunt.config.get('forceStatus')) {
      grunt.option('force', false);
    }
  });
  grunt.registerTask('full', ['jshint:dev', 'forceOn', 'csslint', 'forceOff', 'karma']);
  grunt.registerTask('default', ['jshint:dev']);
  grunt.registerTask('build', ['jshint:dev', 'jshint:test', 'sass:dist', 'karma']);
  grunt.registerTask('test', ['jshint:test', 'karma']);
  grunt.registerTask('devrefresh', ['watch']);
  grunt.registerTask('server', ['express:dev', 'watch']);
  grunt.registerTask('run', ['jshint:dev', 'jshint:test', 'sass:dist', 'execute:app']);
  grunt.registerTask('postinstall', ['sass:dist']);
};
