﻿(function () {
  'use strict';

  describe('BaseLayoutCtrl controller tests', function () {
    var ctrl, scope, location, authFactory, sessionToken, userContextService, window;

    var testToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwcm9maWxlIjp7IklkZW50aXR5U2VydmVySWQiOiJhdXRoMHw1NGRkOWNhNmQyMWUwNzJlNWFjODRlZmYiLCJVc2VybmFtZSI6InVzZXIyQHVuaXZlcnNpdHljb2xvcmFkby5jb20iLCJOZXdQYXNzd29yZCI6bnVsbCwiRW1haWwiOiJ1c2VyMkB1bml2ZXJzaXR5Y29sb3JhZG8uY29tIiwiRmlyc3ROYW1lIjoiQ2FtcGFpZ24iLCJMYXN0TmFtZSI6Ik1hbmFnZXIiLCJSb2xlcyI6WyJDYW1wYWlnbk1hbmFnZXIiLCJBbGxMb2NhdGlvbnMiLCJMaXN0RXhwb3J0ZXIiXSwiRmFpbGVkTG9nSW5BdHRlbXB0IjowLCJJc0xvY2tlZCI6ZmFsc2UsIkRheXNMZWZ0Rm9yUGFzc3dvcmRFeHBpcnkiOjU5LCJPcmdhbml6YXRpb25zIjpbeyJPcmdLZXkiOiJwcmltYXJ5IiwiTmFtZSI6IlByaW1hcnkifV0sIkNsaWVudEtleSI6bnVsbCwiQWNjb3VudERpc2FibGVkIjpmYWxzZSwiSXNTdXBlckFkbWluIjpmYWxzZSwiSXNDbGllbnRBZG1pbiI6ZmFsc2UsIlZhbGlkVXNlciI6ZmFsc2UsIlBhc3N3b3JkVGltZVN0YW1wIjoiNjM1NzM5MTgzMjc4NDc4Mzg2IiwiQWNjb3VudExvY2tvdXRUaW1lU3RhbXAiOiIiLCJQYXNzd29yZEhpc3RvcnkiOiI3MDgyN2Y3NzIxZWYwNGFjNDE5NmZmM2MyYzRiOWM2ZiIsIkZvcmdvdFBhc3N3b3JkVmVyaWZpY2F0aW9uQ29kZSI6bnVsbCwiRm9yZ290UGFzc3dvcmRWZXJpZmljYXRpb25Db2RlVGltZVN0YW1wIjpudWxsLCJUb2tlbkxpZmV0aW1lSW5TZWNvbmRzIjoxODAwLCJNYXhpbXVtRmFpbGVkTG9naW5BdHRlbXB0cyI6MywiQWNjb3VudExvY2tvdXRNaW51dGVzIjoxMCwiTGVnYWN5VXNlcklkIjpudWxsLCJBbGxvd2VkTG9jYXRpb25JZHMiOlsyMzYsMjM3LDIzOF0sIkNhbkFjY2Vzc0FsbExvY2F0aW9ucyI6dHJ1ZSwiVXNlckNsaWVudEtleXMiOlt7IkNsaWVudEtleSI6InVuaXZlcnNpdHljb2xvcmFkbyIsIkxlZ2FjeVVzZXJJZCI6IjEyMyJ9XX0sIm9hdXRoVG9rZW4iOnsiaWRfdG9rZW4iOiJleUowZVhBaU9pSktWMVFpTENKaGJHY2lPaUpJVXpJMU5pSjkuZXlKbGJXRnBiQ0k2SW5WelpYSXlRSFZ1YVhabGNuTnBkSGxqYjJ4dmNtRmtieTVqYjIwaUxDSndhV04wZFhKbElqb2lhSFIwY0hNNkx5OXpMbWR5WVhaaGRHRnlMbU52YlM5aGRtRjBZWEl2TVRJNE9EZzRaalkzWVRnMk5EWTBORE00WVRGaU5XWTRZV1ZsTnpnME4ySV9jejAwT0RBbWNqMXdaeVprUFdoMGRIQnpKVE5CSlRKR0pUSkdZMlJ1TG1GMWRHZ3dMbU52YlNVeVJtRjJZWFJoY25NbE1rWjFjeTV3Ym1jaUxDSnVZVzFsSWpvaWRYTmxjakpBZFc1cGRtVnljMmwwZVdOdmJHOXlZV1J2TG1OdmJTSXNJbTVwWTJ0dVlXMWxJam9pZFhObGNqSWlMQ0pzWVhOMFgzQmhjM04zYjNKa1gzSmxjMlYwSWpvaU1qQXhOUzB3Tnkwek1WUXhNRG8wTkRveE9DNDROamhhSWl3aVlYQndYMjFsZEdGa1lYUmhJanA3SW1Oc2FXVnVkRXRsZVNJNklpSXNJbVpwY25OMFRtRnRaU0k2SWtOaGJYQmhhV2R1SWl3aWJHRnpkRTVoYldVaU9pSk5ZVzVoWjJWeUlpd2ljbTlzWlhNaU9sc2lRMkZ0Y0dGcFoyNU5ZVzVoWjJWeUlpd2lRV3hzVEc5allYUnBiMjV6SWl3aVRHbHpkRVY0Y0c5eWRHVnlJbDBzSW05eVowdGxlWE1pT2xzaWNISnBiV0Z5ZVNKZExDSnBjMHh2WTJ0bFpDSTZabUZzYzJVc0ltRmpZMjkxYm5SRWFYTmhZbXhsWkNJNlptRnNjMlVzSW1GalkyOTFiblJNYjJOcmIzVjBWR2x0WlZOMFlXMXdJam9pSWl3aWNHRnpjM2R2Y21SSWFYTjBiM0o1SWpvaU56QTRNamRtTnpjeU1XVm1NRFJoWXpReE9UWm1aak5qTW1NMFlqbGpObVlpTENKd1lYTnpkMjl5WkZScGJXVlRkR0Z0Y0NJNklqWXpOVGN6T1RFNE16STNPRFEzT0RNNE5pSXNJbVpoYVd4bFpFeHZaMmx1Y3lJNk1Dd2lZV05qYjNWdWRFeHZZMnR2ZFhSTmFXNTFkR1Z6SWpveE1Dd2liV0Y0YVcxMWJVWmhhV3hsWkV4dloybHVRWFIwWlcxd2RITWlPak1zSW5SdmEyVnVUR2xtWlhScGJXVkpibE5sWTI5dVpITWlPakU0TURBc0lteGxaMkZqZVZWelpYSkpaQ0k2SWlJc0ltRnNiRzkzWldSTWIyTmhkR2x2Ymtsa2N5STZXekl6Tml3eU16Y3NNak00WFN3aVkyeHBaVzUwUzJWNWN5STZXM3NpWTJ4cFpXNTBTMlY1SWpvaWRXNXBkbVZ5YzJsMGVXTnZiRzl5WVdSdklpd2liR1ZuWVdONVZYTmxja2xrSWpvaU1USXpJbjFkTENKd1lYTnpkMjl5WkVWNGNHbHlZWFJwYjI1RVlYbHpJam81TUN3aVptOXlaMjkwVUdGemMzZHZjbVJXWlhKcFptbGpZWFJwYjI1RGIyUmxJanB1ZFd4c0xDSm1iM0puYjNSUVlYTnpkMjl5WkZabGNtbG1hV05oZEdsdmJrTnZaR1ZVYVcxbFUzUmhiWEFpT201MWJHeDlMQ0pqYkdsbGJuUkxaWGtpT2lJaUxDSm1hWEp6ZEU1aGJXVWlPaUpEWVcxd1lXbG5iaUlzSW14aGMzUk9ZVzFsSWpvaVRXRnVZV2RsY2lJc0luSnZiR1Z6SWpwYklrTmhiWEJoYVdkdVRXRnVZV2RsY2lJc0lrRnNiRXh2WTJGMGFXOXVjeUlzSWt4cGMzUkZlSEJ2Y25SbGNpSmRMQ0p2Y21kTFpYbHpJanBiSW5CeWFXMWhjbmtpWFN3aWFYTk1iMk5yWldRaU9tWmhiSE5sTENKaFkyTnZkVzUwUkdsellXSnNaV1FpT21aaGJITmxMQ0poWTJOdmRXNTBURzlqYTI5MWRGUnBiV1ZUZEdGdGNDSTZJaUlzSW5CaGMzTjNiM0prU0dsemRHOXllU0k2SWpjd09ESTNaamMzTWpGbFpqQTBZV00wTVRrMlptWXpZekpqTkdJNVl6Wm1JaXdpY0dGemMzZHZjbVJVYVcxbFUzUmhiWEFpT2lJMk16VTNNemt4T0RNeU56ZzBOemd6T0RZaUxDSm1ZV2xzWldSTWIyZHBibk1pT2pBc0ltRmpZMjkxYm5STWIyTnJiM1YwVFdsdWRYUmxjeUk2TVRBc0ltMWhlR2x0ZFcxR1lXbHNaV1JNYjJkcGJrRjBkR1Z0Y0hSeklqb3pMQ0owYjJ0bGJreHBabVYwYVcxbFNXNVRaV052Ym1Seklqb3hPREF3TENKc1pXZGhZM2xWYzJWeVNXUWlPaUlpTENKaGJHeHZkMlZrVEc5allYUnBiMjVKWkhNaU9sc3lNellzTWpNM0xESXpPRjBzSW1Oc2FXVnVkRXRsZVhNaU9sdDdJbU5zYVdWdWRFdGxlU0k2SW5WdWFYWmxjbk5wZEhsamIyeHZjbUZrYnlJc0lteGxaMkZqZVZWelpYSkpaQ0k2SWpFeU15SjlYU3dpY0dGemMzZHZjbVJGZUhCcGNtRjBhVzl1UkdGNWN5STZPVEFzSW1admNtZHZkRkJoYzNOM2IzSmtWbVZ5YVdacFkyRjBhVzl1UTI5a1pTSTZiblZzYkN3aVptOXlaMjkwVUdGemMzZHZjbVJXWlhKcFptbGpZWFJwYjI1RGIyUmxWR2x0WlZOMFlXMXdJanB1ZFd4c0xDSmZhV1FpT2lJd1lXWXlaV00wWTJObE1XUTRabVE0Wm1FNE4ySXhZbUl6Wldaak9ESTNOQ0lzSW1WdFlXbHNYM1psY21sbWFXVmtJanAwY25WbExDSmpiR2xsYm5SSlJDSTZJbXR1WW5GM1kwSjFhbTlJVlhOeVVYaHlSMjlvV0VzMlNFNVpSVmd4TVVsWElpd2lkWE5sY2w5cFpDSTZJbUYxZEdnd2ZEVTBaR1E1WTJFMlpESXhaVEEzTW1VMVlXTTROR1ZtWmlJc0ltbGtaVzUwYVhScFpYTWlPbHQ3SW5WelpYSmZhV1FpT2lJMU5HUmtPV05oTm1ReU1XVXdOekpsTldGak9EUmxabVlpTENKd2NtOTJhV1JsY2lJNkltRjFkR2d3SWl3aVkyOXVibVZqZEdsdmJpSTZJbkZoTFhWdWFYWmxjbk5wZEhsamIyeHZjbUZrYnlJc0ltbHpVMjlqYVdGc0lqcG1ZV3h6WlgxZExDSmpjbVZoZEdWa1gyRjBJam9pTWpBeE5TMHdNaTB4TTFRd05qbzBNVG8wTWk0NE1UbGFJaXdpZFhCa1lYUmxaRjloZENJNklqSXdNVFV0TURndE16RlVNVFU2TXpVNk1EUXVOREF6V2lJc0ltZHNiMkpoYkY5amJHbGxiblJmYVdRaU9pSnViR05sZVRVNVVXTlFObWhKVDFGWVdEaHdlbUo1U1d0WGFUaFRSRVpZY3lJc0ltbHpjeUk2SW1oMGRIQnpPaTh2Y0hKbFpIRmhMbUYxZEdnd0xtTnZiUzhpTENKemRXSWlPaUpoZFhSb01IdzFOR1JrT1dOaE5tUXlNV1V3TnpKbE5XRmpPRFJsWm1ZaUxDSmhkV1FpT2lKcmJtSnhkMk5DZFdwdlNGVnpjbEY0Y2tkdmFGaExOa2hPV1VWWU1URkpWeUlzSW1WNGNDSTZNVFEwTVRBek56RXdOQ3dpYVdGMElqb3hORFF4TURNMU16QTBmUS5yYzVJVm13cjVlRV9nMS1idzZ1dUhWcXJpYk1MdGt1LVdBQUQxczhuT2FBIiwiYWNjZXNzX3Rva2VuIjoiVm1xTmRVNFYyaHNDR1FPcyIsInRva2VuX3R5cGUiOiJiZWFyZXIifSwiaWF0IjoxNDQxMDM1MzAxLCJleHAiOjE0NDEwMzcxMDF9.NClo7FSwqK9KU8LfF9EDPWFkDgQb2Dcz0ysAb1Ucnqo';
    var expectedLoginUrl = '/session/login';
    var expectedClientKey = 'promedica';
    var authServiceSpy, userContextServiceSpy;
    var clienkKeys = [
      { ClientKey: 'promedica', LeagacyUserId: 'userid' }
    ];
    beforeEach(function () {
      module('app', function ($provide) {
        userContextServiceSpy = jasmine.createSpyObj('userContextSvc', ['getUserLoginUrl', 'getApiClientKey', 'getUserLandingUrl', 'getClientKey', 'getOrgKey', 'getUserOrganizations', 'getOrganizationName']);
        userContextServiceSpy.getUserLoginUrl.and.returnValue(expectedLoginUrl);
        userContextServiceSpy.getClientKey.and.returnValue(expectedClientKey);
        userContextServiceSpy.getOrgKey.and.returnValue('');
        userContextServiceSpy.getApiClientKey.and.returnValue('prod');
        userContextServiceSpy.getUserOrganizations.and.returnValue('test1', 'test2');
        userContextServiceSpy.getOrganizationName.and.returnValue('test1', 'test2');
        $provide.value('userContextSvc', userContextServiceSpy);

        authServiceSpy = jasmine.createSpyObj('authSvc', ['getAdminClientKeys', 'setToken', 'getToken', 'hasToken', 'getUserClientKey', 'getUsername', 'getFullName', 'getRoles', 'getTokenExpirationDate', 'getTokenIssueDate', 'isSystemAdministrator', 'hasExternalTokens', 'isClientAdministrator', 'getClientKeys']);
        authServiceSpy.getUsername.and.returnValue('user1');
        authServiceSpy.getFullName.and.returnValue('user1@southeast.com');
        authServiceSpy.getRoles.and.returnValue('Executive');
        authServiceSpy.getTokenExpirationDate.and.returnValue('01/07/2014');
        authServiceSpy.getTokenIssueDate.and.returnValue('01/06/2014');
        authServiceSpy.isSystemAdministrator.and.returnValue(false);
        authServiceSpy.isClientAdministrator.and.returnValue(false);
        authServiceSpy.getUserClientKey.and.returnValue(null);
        authServiceSpy.getClientKeys.and.returnValue(clienkKeys);
        authServiceSpy.hasToken.and.returnValue(true);
        authServiceSpy.getToken.and.returnValue(testToken);
        authServiceSpy.setToken.and.callThrough();
        authServiceSpy.getAdminClientKeys.and.returnValue(clienkKeys);
        authServiceSpy.hasExternalTokens.and.returnValue(false);
        $provide.value('authSvc', authServiceSpy);

        var longTaskSvcSpy = jasmine.createSpyObj('longTaskSvc', ['update']);
        longTaskSvcSpy.update.and.returnValue('');
        $provide.value('longTaskSvc', longTaskSvcSpy);

        window = { history: { go: jasmine.createSpy() }, location: { href: '' }, attachEvent: function (x, y) { x = y; }, localStorage: { setItem: function (key, value) { key = value; }, removeItem: function (key) { key = false; } } };
        $provide.value('$window', window);
        app.sessionExpiryAlertSeconds = 120;
      });
      angular.mock.inject(function ($rootScope, $location, $controller, authSvc, sessionSvc, userContextSvc, $httpBackend) {
        scope = $rootScope.$new();
        app.routing = { routeParams: jasmine.createSpy() };
        ctrl = $controller('BaseLayoutCtrl', {
          $scope: scope
        });
        $httpBackend.whenGET('/api/clients/promedica/listclients?Id=' + expectedClientKey).respond(200, '');
        $httpBackend.whenGET('/api/clients/promedica/listclients').respond(200, '');

        location = $location;
        authFactory = authSvc;
        sessionToken = sessionSvc;
        userContextService = userContextSvc;
        app.generic = {};
      });
    });

    describe('check if controller functions exists', function () {

      it('should have a BaseLayoutCtrl Controller', function () {
        expect(ctrl).not.toBeUndefined();
      });

      it('should redirect to login page when not authenticated', function () {
        authServiceSpy.hasToken.and.returnValue(false);
        scope.$apply(location.path('/'));
        expect(window.location.href).toEqual('/session/login');
      });

      it('when authenticated should go to the specific page', function () {
        authFactory.setToken('temp-token');
        scope.$apply(location.path('/lists'));
        expect(location.path()).toEqual('/lists');
      });

      it('should have a logout() function', function () {
        expect(scope.logout).not.toBeUndefined();
      });

      it('should have a clearSession() function', function () {
        expect(scope.clearSession).not.toBeUndefined();
      });

      it('should have a year() function', function () {
        expect(scope.year).not.toBeUndefined();
      });
      it('should have a openManageListsModal function', function () {
        expect(scope.openManageListsModal).not.toBeUndefined();
      });
      it('should give organizations when onClientValueChange ', function () {
        scope.model = { clients: [{ Key: 'northwest', Organizations: [{ Key: 'section1', Name: 'section1' }] }, { Key: 'southwest', Organizations: [{ Key: 'southwest1', Name: 'southwest1' }] }] };
        scope.defaultClientSelected = 'southwest~southwest Health Systems';
        scope.onClientValueChange();
        expect(scope.onClientValueChange).not.toBeUndefined();
        expect(scope.model.userOrgs[0].OrgKey).toBe('southwest1');
      });
      it('OK button should get enabled if organization is selected', function () {
        scope.defaultOrgSelected = 'section1';
        scope.onOrganizationValueChange();
        expect(scope.isOkDisabled).toBe(false);
      });
      it('OK button should get disabled if organization is  not selected', function () {
        scope.defaultOrgSelected = 'SELECT ORGANIZATION';
        scope.onOrganizationValueChange();
        expect(scope.isOkDisabled).toBe(true);
      });
      it('OK button should get disabled if client is not selected', function () {
        scope.defaultClientSelected = 'SELECT CLIENT';
        scope.onClientValueChange();
        expect(scope.isOkDisabled).toBe(true);
      });
      it('securityTrim to return true if user is authorized', function () {
        var roles = ['admin', 'executive'];
        scope.model = { roles: ['admin'] };
        var found = scope.securityTrim(roles);
        expect(found).toBe(true);
      });
      it('securityTrim to return false if user is unauthorized', function () {
        var roles = ['executive'];
        scope.model = { roles: ['campaigner'] };
        var found = scope.securityTrim(roles);
        expect(found).toBe(false);
      });
      it('securityTrim to return true if user is admin', function () {
        var roles = ['admin'];
        scope.model = { roles: ['campaigner', 'SysAdmin'] };
        var found = scope.securityTrim(roles);
        expect(found).toBe(true);
      });
      it('should return client and organization for admin user', function () {
        authServiceSpy.isSystemAdministrator.and.returnValue(true);
        scope.model = { roles: ['campaigner', 'SysAdmin'], clients: [{ Key: 'southeast', IsSilverpopConfigured: true, Organizations: [{ Key: 'section1', Name: 'section1' }] }] };
        scope.defaultClientSelected = 'southeast';
        scope.defaultOrgSelected = 'section1';
        scope.clientKeyValue = 'southeast';
        scope.linkType = 'LIST';
        scope.onClick();
        expect(scope.selectedClient).toBe('southeast');
        expect(scope.selectedOrg).toBe('section1');
      });
      it('should return only organization for other than admin user', function () {
        scope.model = { roles: ['campaigner'] };
        scope.defaultClientSelected = 'southeast';
        scope.defaultOrgSelected = 'section1';
        scope.linkType = 'LIST';
        scope.onClick();
        expect(scope.selectedClient).toBe('');
        expect(scope.selectedOrg).toBe('section1');
      });
      it('openManageListsModal should be defined', function () {
        expect(scope.openManageListsModal).not.toBeUndefined();
      });
      it('onContextChange should be defined', function () {
        expect(scope.onContextChange).not.toBeUndefined();
      });
      it('onContextChange should be defined', function () {
        scope.onContextChange();
      });
      it('onContextChange should be defined', function () {
        scope.checkUserContextValidationOrganization('');
      });
      it('onContextChange should be defined', function () {
        scope.checkUserContextValidationClient('');
      });
      it('onContextChange should be defined', function () {
        scope.clientKey = '';
      });
      it('showMarketAutomationLink method should exist', function () {
        expect(scope.loadClientInfo).not.toBeUndefined();
      });
    });
  });
})(window.app);
