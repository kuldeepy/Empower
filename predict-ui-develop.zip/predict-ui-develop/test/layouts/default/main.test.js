﻿(function() {
  'use strict';

  describe('DefaultLayoutCtrl controller tests', function() {
    var ctrl, scope, location, authFactory, sessionToken, userContextService;

    var expectedLoginUrl = '/session/login';

    beforeEach(function() {

      module('app', function($provide) {
        var userContextServiceSpy = jasmine.createSpyObj('userContextSvc', ['getUserLoginUrl', 'getApiClientKey']);
        userContextServiceSpy.getUserLoginUrl.and.returnValue(expectedLoginUrl);
        $provide.value('userContextSvc', userContextServiceSpy);
      });
      
      angular.mock.inject(function($rootScope, $location, $controller, authSvc, sessionSvc, userContextSvc) {
        scope = $rootScope.$new();
        ctrl = $controller('DefaultLayoutCtrl', {
          $scope: scope
        });
        location = $location;
        authFactory = authSvc;
        sessionToken = sessionSvc;
        userContextService = userContextSvc;
      });

    });

    describe('check if controller functions exists', function() {

      it('should have a DefaultLayoutCtrl Controller', function() {
        expect(ctrl).not.toBeUndefined();
      });

      it('should redirect to login page when not authenticated', function() {
        if (authFactory.hasToken) {
          scope.redirectToLoginPage();
        }
        expect(location.path()).toEqual(expectedLoginUrl);
      });

      it('when authenticated should go to the specific page', function() {
        authFactory.setToken('temp-token');
        if (authFactory.hasToken) {
          scope.$apply(location.path('/lists'));
        }
        expect(location.path()).toEqual('/lists');
      });

      it('should have a redirectToLoginPage() function', function() {
        expect(scope.redirectToLoginPage).not.toBeUndefined();
      });
    });
  });
})(window.app);