/* global describe, beforeEach, inject, it */

(function () {

	'use strict';

	describe('calculationSvc', function () {
		var BASE_API_URL = '/api/medseek/';
		beforeEach(module('app', function ($provide) {
			var mockFactory = function () {
				return BASE_API_URL;
			};
			$provide.value('baseApiUrl', mockFactory);
		}));
		describe('error response', function () {
			var res, list;

			beforeEach(function () {
				inject(function ($httpBackend, calculationSvc) {
					$httpBackend.whenPOST(BASE_API_URL + 'calculation')
					.respond(500, '');
					list = {};
					res = calculationSvc.calculate(list);

					$httpBackend.flush();
				});
			});

			it('should log error', function (done) {
				res
				.then(function () {
					throw new Error('should not resolve');
				})
				.finally(done);

				inject(function ($rootScope) {
					$rootScope.$digest();
				});
			});
		});
	});

})(window.app);
