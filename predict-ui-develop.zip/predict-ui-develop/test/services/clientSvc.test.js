(function () {
  'use strict';
  describe('clientSvc', function () {

    var clientService, http, q, userContextService;

    beforeEach(function () {
      module('app', function ($httpProvider, $provide) {
        var userContextServiceSpy = jasmine.createSpyObj('userContextSvc', ['getApiClientKey', 'getOrgKey']);
        userContextServiceSpy.getApiClientKey.and.returnValue('x');
        userContextServiceSpy.getOrgKey.and.returnValue('a');
        $provide.value('userContextSvc', userContextServiceSpy);
        $httpProvider.interceptors.pop('authInterceptor');
        $httpProvider.interceptors.pop('errorInterceptor');
      });

      inject(function ($httpBackend, $q, clientSvc, userContextSvc) {
        http = $httpBackend;
        q = $q;
        userContextService = userContextSvc;
        clientService = clientSvc;
      });

    });

    it('exists', function () {
      expect(clientService).not.toBeUndefined();
    });

    describe('loadClients', function () {

      it('exists', function () {
        expect(clientService.loadClients).not.toBeUndefined();
      });

      describe('when called', function () {
        var resourceUrl, expectedResult;
        afterEach(function () {
          http.verifyNoOutstandingExpectation();
        });

        it('returns all clients', function () {
          resourceUrl = '/api/clients/x/listclients';
          expectedResult = {
            results: {
              Clients: [{
                'Key': 'southeast'
              }, {
                'Key': 'southwest'
              }]
            }
          };
          http.expectGET(resourceUrl).respond(expectedResult);
          var retVal;
          clientService.loadClients().then(function (data) {
            retVal = data;
          });
          http.flush();
          expect(retVal).toBe(expectedResult.results.Clients);
        });

        it('returns one client', function () {
          resourceUrl = '/api/clients/southeast/listclients?Id=southeast';
          var result = {
            results: {
              Clients: [{
                'Key': 'southeast'
              }]
            }
          };
          http.expectGET(resourceUrl).respond(result);
          var retVal;
          clientService.loadClients('southeast').then(function (data) {
            retVal = data;
          });
          http.flush();
          expect(retVal).toBe(result.results.Clients[0]);
        });
      });
    });
  });
})(window.app);