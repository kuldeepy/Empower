﻿(function () {
  'use strict';

  describe('authSvc', function () {

    var authService, http, q, userContextService, sessionService;

    var resourceUrl = '/api/clients/system/authToken';

    var validCredentials = {
      Username: 'user2@universitycolorado.com',
      Password: 'Medseek123'
    };

    var validPostResult = {
      'href': '/predict/v1/clients/system/authToken',
      'results': {
        'IsAuthorized': true,
        'Token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwcm9maWxlIjp7IklkZW50aXR5U2VydmVySWQiOiJhdXRoMHw1NGRkOWNhNmQyMWUwNzJlNWFjODRlZmYiLCJVc2VybmFtZSI6InVzZXIyQHVuaXZlcnNpdHljb2xvcmFkby5jb20iLCJOZXdQYXNzd29yZCI6bnVsbCwiRW1haWwiOiJ1c2VyMkB1bml2ZXJzaXR5Y29sb3JhZG8uY29tIiwiRmlyc3ROYW1lIjoiQ2FtcGFpZ24iLCJMYXN0TmFtZSI6Ik1hbmFnZXIiLCJSb2xlcyI6WyJDYW1wYWlnbk1hbmFnZXIiLCJBbGxMb2NhdGlvbnMiLCJMaXN0RXhwb3J0ZXIiXSwiRmFpbGVkTG9nSW5BdHRlbXB0IjowLCJJc0xvY2tlZCI6ZmFsc2UsIkRheXNMZWZ0Rm9yUGFzc3dvcmRFeHBpcnkiOjU5LCJPcmdhbml6YXRpb25zIjpbeyJPcmdLZXkiOiJwcmltYXJ5IiwiTmFtZSI6IlByaW1hcnkifV0sIkNsaWVudEtleSI6bnVsbCwiQWNjb3VudERpc2FibGVkIjpmYWxzZSwiSXNTdXBlckFkbWluIjpmYWxzZSwiSXNDbGllbnRBZG1pbiI6ZmFsc2UsIlZhbGlkVXNlciI6ZmFsc2UsIlBhc3N3b3JkVGltZVN0YW1wIjoiNjM1NzM5MTgzMjc4NDc4Mzg2IiwiQWNjb3VudExvY2tvdXRUaW1lU3RhbXAiOiIiLCJQYXNzd29yZEhpc3RvcnkiOiI3MDgyN2Y3NzIxZWYwNGFjNDE5NmZmM2MyYzRiOWM2ZiIsIkZvcmdvdFBhc3N3b3JkVmVyaWZpY2F0aW9uQ29kZSI6bnVsbCwiRm9yZ290UGFzc3dvcmRWZXJpZmljYXRpb25Db2RlVGltZVN0YW1wIjpudWxsLCJUb2tlbkxpZmV0aW1lSW5TZWNvbmRzIjoxODAwLCJNYXhpbXVtRmFpbGVkTG9naW5BdHRlbXB0cyI6MywiQWNjb3VudExvY2tvdXRNaW51dGVzIjoxMCwiTGVnYWN5VXNlcklkIjpudWxsLCJBbGxvd2VkTG9jYXRpb25JZHMiOlsyMzYsMjM3LDIzOF0sIkNhbkFjY2Vzc0FsbExvY2F0aW9ucyI6dHJ1ZSwiVXNlckNsaWVudEtleXMiOlt7IkNsaWVudEtleSI6InVuaXZlcnNpdHljb2xvcmFkbyIsIkxlZ2FjeVVzZXJJZCI6IjEyMyJ9XX0sIm9hdXRoVG9rZW4iOnsiaWRfdG9rZW4iOiJleUowZVhBaU9pSktWMVFpTENKaGJHY2lPaUpJVXpJMU5pSjkuZXlKbGJXRnBiQ0k2SW5WelpYSXlRSFZ1YVhabGNuTnBkSGxqYjJ4dmNtRmtieTVqYjIwaUxDSndhV04wZFhKbElqb2lhSFIwY0hNNkx5OXpMbWR5WVhaaGRHRnlMbU52YlM5aGRtRjBZWEl2TVRJNE9EZzRaalkzWVRnMk5EWTBORE00WVRGaU5XWTRZV1ZsTnpnME4ySV9jejAwT0RBbWNqMXdaeVprUFdoMGRIQnpKVE5CSlRKR0pUSkdZMlJ1TG1GMWRHZ3dMbU52YlNVeVJtRjJZWFJoY25NbE1rWjFjeTV3Ym1jaUxDSnVZVzFsSWpvaWRYTmxjakpBZFc1cGRtVnljMmwwZVdOdmJHOXlZV1J2TG1OdmJTSXNJbTVwWTJ0dVlXMWxJam9pZFhObGNqSWlMQ0pzWVhOMFgzQmhjM04zYjNKa1gzSmxjMlYwSWpvaU1qQXhOUzB3Tnkwek1WUXhNRG8wTkRveE9DNDROamhhSWl3aVlYQndYMjFsZEdGa1lYUmhJanA3SW1Oc2FXVnVkRXRsZVNJNklpSXNJbVpwY25OMFRtRnRaU0k2SWtOaGJYQmhhV2R1SWl3aWJHRnpkRTVoYldVaU9pSk5ZVzVoWjJWeUlpd2ljbTlzWlhNaU9sc2lRMkZ0Y0dGcFoyNU5ZVzVoWjJWeUlpd2lRV3hzVEc5allYUnBiMjV6SWl3aVRHbHpkRVY0Y0c5eWRHVnlJbDBzSW05eVowdGxlWE1pT2xzaWNISnBiV0Z5ZVNKZExDSnBjMHh2WTJ0bFpDSTZabUZzYzJVc0ltRmpZMjkxYm5SRWFYTmhZbXhsWkNJNlptRnNjMlVzSW1GalkyOTFiblJNYjJOcmIzVjBWR2x0WlZOMFlXMXdJam9pSWl3aWNHRnpjM2R2Y21SSWFYTjBiM0o1SWpvaU56QTRNamRtTnpjeU1XVm1NRFJoWXpReE9UWm1aak5qTW1NMFlqbGpObVlpTENKd1lYTnpkMjl5WkZScGJXVlRkR0Z0Y0NJNklqWXpOVGN6T1RFNE16STNPRFEzT0RNNE5pSXNJbVpoYVd4bFpFeHZaMmx1Y3lJNk1Dd2lZV05qYjNWdWRFeHZZMnR2ZFhSTmFXNTFkR1Z6SWpveE1Dd2liV0Y0YVcxMWJVWmhhV3hsWkV4dloybHVRWFIwWlcxd2RITWlPak1zSW5SdmEyVnVUR2xtWlhScGJXVkpibE5sWTI5dVpITWlPakU0TURBc0lteGxaMkZqZVZWelpYSkpaQ0k2SWlJc0ltRnNiRzkzWldSTWIyTmhkR2x2Ymtsa2N5STZXekl6Tml3eU16Y3NNak00WFN3aVkyeHBaVzUwUzJWNWN5STZXM3NpWTJ4cFpXNTBTMlY1SWpvaWRXNXBkbVZ5YzJsMGVXTnZiRzl5WVdSdklpd2liR1ZuWVdONVZYTmxja2xrSWpvaU1USXpJbjFkTENKd1lYTnpkMjl5WkVWNGNHbHlZWFJwYjI1RVlYbHpJam81TUN3aVptOXlaMjkwVUdGemMzZHZjbVJXWlhKcFptbGpZWFJwYjI1RGIyUmxJanB1ZFd4c0xDSm1iM0puYjNSUVlYTnpkMjl5WkZabGNtbG1hV05oZEdsdmJrTnZaR1ZVYVcxbFUzUmhiWEFpT201MWJHeDlMQ0pqYkdsbGJuUkxaWGtpT2lJaUxDSm1hWEp6ZEU1aGJXVWlPaUpEWVcxd1lXbG5iaUlzSW14aGMzUk9ZVzFsSWpvaVRXRnVZV2RsY2lJc0luSnZiR1Z6SWpwYklrTmhiWEJoYVdkdVRXRnVZV2RsY2lJc0lrRnNiRXh2WTJGMGFXOXVjeUlzSWt4cGMzUkZlSEJ2Y25SbGNpSmRMQ0p2Y21kTFpYbHpJanBiSW5CeWFXMWhjbmtpWFN3aWFYTk1iMk5yWldRaU9tWmhiSE5sTENKaFkyTnZkVzUwUkdsellXSnNaV1FpT21aaGJITmxMQ0poWTJOdmRXNTBURzlqYTI5MWRGUnBiV1ZUZEdGdGNDSTZJaUlzSW5CaGMzTjNiM0prU0dsemRHOXllU0k2SWpjd09ESTNaamMzTWpGbFpqQTBZV00wTVRrMlptWXpZekpqTkdJNVl6Wm1JaXdpY0dGemMzZHZjbVJVYVcxbFUzUmhiWEFpT2lJMk16VTNNemt4T0RNeU56ZzBOemd6T0RZaUxDSm1ZV2xzWldSTWIyZHBibk1pT2pBc0ltRmpZMjkxYm5STWIyTnJiM1YwVFdsdWRYUmxjeUk2TVRBc0ltMWhlR2x0ZFcxR1lXbHNaV1JNYjJkcGJrRjBkR1Z0Y0hSeklqb3pMQ0owYjJ0bGJreHBabVYwYVcxbFNXNVRaV052Ym1Seklqb3hPREF3TENKc1pXZGhZM2xWYzJWeVNXUWlPaUlpTENKaGJHeHZkMlZrVEc5allYUnBiMjVKWkhNaU9sc3lNellzTWpNM0xESXpPRjBzSW1Oc2FXVnVkRXRsZVhNaU9sdDdJbU5zYVdWdWRFdGxlU0k2SW5WdWFYWmxjbk5wZEhsamIyeHZjbUZrYnlJc0lteGxaMkZqZVZWelpYSkpaQ0k2SWpFeU15SjlYU3dpY0dGemMzZHZjbVJGZUhCcGNtRjBhVzl1UkdGNWN5STZPVEFzSW1admNtZHZkRkJoYzNOM2IzSmtWbVZ5YVdacFkyRjBhVzl1UTI5a1pTSTZiblZzYkN3aVptOXlaMjkwVUdGemMzZHZjbVJXWlhKcFptbGpZWFJwYjI1RGIyUmxWR2x0WlZOMFlXMXdJanB1ZFd4c0xDSmZhV1FpT2lJd1lXWXlaV00wWTJObE1XUTRabVE0Wm1FNE4ySXhZbUl6Wldaak9ESTNOQ0lzSW1WdFlXbHNYM1psY21sbWFXVmtJanAwY25WbExDSmpiR2xsYm5SSlJDSTZJbXR1WW5GM1kwSjFhbTlJVlhOeVVYaHlSMjlvV0VzMlNFNVpSVmd4TVVsWElpd2lkWE5sY2w5cFpDSTZJbUYxZEdnd2ZEVTBaR1E1WTJFMlpESXhaVEEzTW1VMVlXTTROR1ZtWmlJc0ltbGtaVzUwYVhScFpYTWlPbHQ3SW5WelpYSmZhV1FpT2lJMU5HUmtPV05oTm1ReU1XVXdOekpsTldGak9EUmxabVlpTENKd2NtOTJhV1JsY2lJNkltRjFkR2d3SWl3aVkyOXVibVZqZEdsdmJpSTZJbkZoTFhWdWFYWmxjbk5wZEhsamIyeHZjbUZrYnlJc0ltbHpVMjlqYVdGc0lqcG1ZV3h6WlgxZExDSmpjbVZoZEdWa1gyRjBJam9pTWpBeE5TMHdNaTB4TTFRd05qbzBNVG8wTWk0NE1UbGFJaXdpZFhCa1lYUmxaRjloZENJNklqSXdNVFV0TURndE16RlVNVFU2TXpVNk1EUXVOREF6V2lJc0ltZHNiMkpoYkY5amJHbGxiblJmYVdRaU9pSnViR05sZVRVNVVXTlFObWhKVDFGWVdEaHdlbUo1U1d0WGFUaFRSRVpZY3lJc0ltbHpjeUk2SW1oMGRIQnpPaTh2Y0hKbFpIRmhMbUYxZEdnd0xtTnZiUzhpTENKemRXSWlPaUpoZFhSb01IdzFOR1JrT1dOaE5tUXlNV1V3TnpKbE5XRmpPRFJsWm1ZaUxDSmhkV1FpT2lKcmJtSnhkMk5DZFdwdlNGVnpjbEY0Y2tkdmFGaExOa2hPV1VWWU1URkpWeUlzSW1WNGNDSTZNVFEwTVRBek56RXdOQ3dpYVdGMElqb3hORFF4TURNMU16QTBmUS5yYzVJVm13cjVlRV9nMS1idzZ1dUhWcXJpYk1MdGt1LVdBQUQxczhuT2FBIiwiYWNjZXNzX3Rva2VuIjoiVm1xTmRVNFYyaHNDR1FPcyIsInRva2VuX3R5cGUiOiJiZWFyZXIifSwiaWF0IjoxNDQxMDM1MzAxLCJleHAiOjE0NDEwMzcxMDF9.NClo7FSwqK9KU8LfF9EDPWFkDgQb2Dcz0ysAb1Ucnqo'
      }
    };

    var invalidCredentials = {
      Username: 'x',
      Password: 'y'
    };

    var invalidPostResult = {
      'href': '/predict/v1/clients/system/authToken',
      'results': {
        'IsAuthorized': false,
        'Token': '',
        'Message': null,
        'ExceptionMessage': null,
        'StackTrace': null
      }
    };

    beforeEach(function () {
      module('app', function ($httpProvider, $provide) {
        //remove auth interceptor for testing since it interferes with tokens
        $httpProvider.interceptors.pop('authInterceptor');
        $httpProvider.interceptors.pop('errorInterceptor');
        $httpProvider.interceptors.pop('requestLogInterceptor');

        var sessionServiceSpy = jasmine.createSpyObj('sessionSvc', ['set', 'get', 'clear']);
        $provide.value('sessionSvc', sessionServiceSpy);

        var userContextServiceSpy = jasmine.createSpyObj('userContextSvc', ['getClientKey', 'getApiClientKey', 'getUserLoginUrl']);
        userContextServiceSpy.getClientKey.and.returnValue('system');
        userContextServiceSpy.getApiClientKey.and.returnValue('system');
        userContextServiceSpy.getUserLoginUrl.and.returnValue('/session/login');
        $provide.value('userContextSvc', userContextServiceSpy);

      });

      inject(function ($httpBackend, $q, authSvc, userContextSvc, sessionSvc) {
        http = $httpBackend;
        q = $q;
        userContextService = userContextSvc;
        sessionService = sessionSvc;
        authService = authSvc;
      });

    });

    it('exists', function () {
      expect(authService).not.toBeUndefined();
    });

    describe('createToken', function () {

      it('exists', function () {
        expect(authService.createToken).not.toBeUndefined();
      });

      describe('when called', function () {

        afterEach(function () {
          http.verifyNoOutstandingExpectation();
        });

        it('returns true when credentials are valid', function () {
          http.expectPOST(resourceUrl, validCredentials).respond(validPostResult);
          var result;
          authService.createToken(validCredentials).then(function (data) {
            result = data;
          });
          http.flush();
          expect(result.IsAuthorized).toEqual(true);
        });

        it('saves the token to session if credentials are valid', function () {
          http.expectPOST(resourceUrl, validCredentials).respond(validPostResult);
          authService.createToken(validCredentials);
          http.flush();
          expect(sessionService.set).toHaveBeenCalledWith('auth.token', validPostResult.results.Token);
        });

        it('saves the username to session when creating a token', function () {
          http.expectPOST(resourceUrl, validCredentials).respond(validPostResult);
          authService.createToken(validCredentials);
          http.flush();
          expect(sessionService.set).toHaveBeenCalledWith('auth.username', validCredentials.Username);
        });

        it('returns false when credentials are invalid', function () {
          http.expectPOST(resourceUrl, invalidCredentials).respond(invalidPostResult);
          var result;
          authService.createToken(invalidCredentials).then(function (data) {
            result = data;
          });
          http.flush();
          expect(result.IsAuthorized).toEqual(false);
        });

        it('does not save the token to session when invalid credentials', function () {
          http.expectPOST(resourceUrl, invalidCredentials).respond(invalidPostResult);
          authService.createToken(invalidCredentials);
          http.flush();
          expect(sessionService.set).not.toHaveBeenCalled();
        });

        it('returns error if resource URL fails to load', function () {
          var error = {};
          error.data = {};
          error.data.message = 'error';
          http.expectPOST(resourceUrl, validCredentials).respond(404, error);
          var result;
          authService.createToken(validCredentials).then(function (data) {
            result = data;

          }, function (value) {
            result = value;
          });
          http.flush();
          expect(result).toBeUndefined();
        });
      });
    });

    describe('getToken', function () {
      it('exists', function () {
        expect(authService.getToken).not.toBeUndefined();
      });

      describe('when called', function () {
        it('retrieves the token from session', function () {
          authService.getToken();
          expect(sessionService.get).toHaveBeenCalledWith('auth.token');
        });
      });
    });

    describe('setToken', function () {
      it('exists', function () {
        expect(authService.setToken).not.toBeUndefined();
      });
    });
    /*
    describe('logOut', function () {
    it('exists', function () {
    expect(authService.logOut).not.toBeUndefined();
    });
    describe('when called', function () {
    it('removes the token from session', function () {
    http.expectDELETE(resourceUrl).respond(200, {
    results: {
    IsRevoked: true
    }
    });
    authService.logOut();
    http.flush();
    expect(sessionService.clear).toHaveBeenCalledWith('auth.token');
    });
    });
    });
    */
    describe('hasToken', function () {
      it('exists', function () {
        expect(authService.hasToken).not.toBeUndefined();
      });
      describe('when called', function () {
        it('retrieves the token from session', function () {
          authService.hasToken();
          expect(sessionService.get).toHaveBeenCalledWith('auth.token');
        });
      });
    });

    describe('getUsername', function () {
      it('exists', function () {
        expect(authService.getUsername).not.toBeUndefined();
      });
      describe('when called', function () {
        it('retrieves the username from session', function () {
          authService.getUsername();
          expect(sessionService.get).toHaveBeenCalledWith('auth.username');
        });
      });
    });

    describe('getFullName', function () {
      it('exists', function () {
        expect(authService.getFullName).not.toBeUndefined();
      });
      describe('when called', function () {
        it('retrieves the fullname from session', function () {
          authService.getFullName();
          expect(sessionService.get).toHaveBeenCalledWith('auth.fullname');
        });
      });
    });

    describe('getRoles', function () {
      it('exists', function () {
        expect(authService.getRoles).not.toBeUndefined();
      });
      describe('when called', function () {
        it('retrieves the roles from session', function () {
          authService.getRoles();
          expect(sessionService.get).toHaveBeenCalledWith('auth.roles');
        });
      });
    });

    describe('showAllListCriteria', function() {
      it('exists', function () {
        expect(authService.showAllListCriteria).not.toBeUndefined();
      });
      describe('when called', function() {
        it('returns limited criteria when AllListCriteria role is not present and user is not sysAdmin', function () {
          spyOn(authService, 'isSystemAdministrator').and.returnValue(false);
          spyOn(authService, 'getRoles').and.returnValue(['CampaignManager', 'AllLocations']);
          var showAll = authService.showAllListCriteria();
          expect(showAll).toEqual(false);
        });
      });
    });

    describe('getTokenExpirationDate', function () {
      it('exists', function () {
        expect(authService.getTokenExpirationDate).not.toBeUndefined();
      });
      describe('when called', function () {
        it('retrieves the exp date from session', function () {
          authService.getTokenExpirationDate();
          expect(sessionService.get).toHaveBeenCalledWith('auth.expiresAt');
        });
      });
    });

    describe('getTokenIssueDate', function () {
      it('getTokenIssueDate', function () {
        expect(authService.getTokenIssueDate).not.toBeUndefined();
      });
      describe('when called', function () {
        it('retrieves the issue date from session', function () {
          authService.getTokenIssueDate();
          expect(sessionService.get).toHaveBeenCalledWith('auth.issuedAt');
        });
      });
    });

    describe('refreshToken', function () {
      it('exists', function () {
        expect(authService.refreshToken).not.toBeUndefined();
      });
      describe('when called', function () {
        it('calls the API to refresh the token', function () {

          sessionService.get.and.returnValue(null);
          http.expectPUT(resourceUrl).respond(validPostResult);

          authService.refreshToken();
          http.flush();
          expect(sessionService.clear).toHaveBeenCalledWith('auth.isRefreshing');
        });

        it('fail to call the API to refresh the token ', function () {
          var error = {};
          error.data = {};
          error.data.message = 'error';
          sessionService.get.and.returnValue(null);
          http.expectPUT(resourceUrl).respond(404, error); //validPostResult);
          authService.refreshToken();
          http.flush();
          expect(sessionService.clear).toHaveBeenCalled();
        });


        afterEach(function () {
          http.verifyNoOutstandingExpectation();
        });
      });
    });

    describe('forgotPassword', function () {

      it('exists', function () {
        expect(authService.forgotPassword).not.toBeUndefined();
      });

      describe('when called', function () {

        afterEach(function () {
          http.verifyNoOutstandingExpectation();
        });

      });
    });

  });
})(window.app);
