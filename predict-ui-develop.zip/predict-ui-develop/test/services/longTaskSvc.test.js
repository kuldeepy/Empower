﻿(function () {
  'use strict';
  describe('longTaskSvc', function () {

    var longTaskService, http, q, userContextService, notificationService;
    var notification = { task: {} };
    beforeEach(function () {
      module('app', function ($httpProvider, $provide) {
        var userContextServiceSpy = jasmine.createSpyObj('userContextSvc', ['getApiClientKey', 'getClientKey', 'getOrgKey']);
        userContextServiceSpy.getApiClientKey.and.returnValue('x');
        userContextServiceSpy.getClientKey.and.returnValue('x');
        userContextServiceSpy.getOrgKey.and.returnValue('a');
        $provide.value('userContextSvc', userContextServiceSpy);
        var notificationServiceSpy = jasmine.createSpyObj('notificationSvc', ['remove','add','get']);
        $provide.value('notificationSvc', notificationServiceSpy);
        $httpProvider.interceptors.pop('authInterceptor');
        $httpProvider.interceptors.pop('errorInterceptor');
      });

      inject(function ($httpBackend, $q, longTaskSvc, userContextSvc, notificationSvc) {
        http = $httpBackend;
        q = $q;
        userContextService = userContextSvc;
        longTaskService = longTaskSvc;
        notificationService = notificationSvc;
      });

    });

    afterEach(function () {
      http.verifyNoOutstandingExpectation();
      http.verifyNoOutstandingRequest();
    });

    it('exists', function () {
      expect(longTaskService).not.toBeUndefined();
    });

    describe('processTask for ListExport', function () {
      notification.task = {
        'id': 'lrt1',
        'UserId': 'auth0|user1',
        'Description': 'List Pull - Test',
        'PercentComplete': 100,
        'Status': 'Success.',
        'IsError': false,
        'NotificationBehavior': 53,
        'NotificationMetadata': [
          {
            Broadcast: 'listExport:started',
            Description: 'List Export - Test',
            ListId: 'list1',
            Name: 'Test',
            NotificationTitle: 'Export To Text File',
            RequestBody: {
              Id: 'list1',
              IsTextExport: true
            },
            Id: 'list1',
            IsTextExport: true,
            RequestType: 'post'
          },
          {
            Broadcast: 'listExport:started',
            Description: 'List Export - Test',
            ListId: 'list1',
            Name: 'Test',
            NotificationTitle: 'Export To Market Automation',
            RequestBody: {
              Id: 'list1',
              IsTextExport: false
            },
            Id: 'list1',
            IsTextExport: false,
            RequestType: 'post'
          }
        ],
        'NotificationLink': [
            'clients/x/orgs/a/listexport',
            'clients/x/orgs/a/listexport'
          ]
        };

      it('process long running task for text Export', function () {
        var resourceUrl = '/api/clients/x/orgs/a/listexport';
        var requestBody = { Id: 'list1', IsTextExport: true };
        var expectedResult = {
          data: {
            success:true
          }
        };
        http.expectPOST(resourceUrl, requestBody).respond(expectedResult);
        http.expectDELETE('/api/longRunningTasks/lrt1').respond(expectedResult);
        longTaskService.processTask(notification, 0);
        http.flush();
        expect(notificationService.remove).toHaveBeenCalled();
        expect(longTaskService.get().length).toBe(0);
      });

      it('process long running task for text Export generates error', function () {
        var resourceUrl = '/api/clients/x/orgs/a/listexport';
        var requestBody = { Id: 'list1', IsTextExport: true };
        http.expectPOST(resourceUrl, requestBody).respond(500);
        longTaskService.processTask(notification, 0);
        http.flush();
        expect(longTaskService.get()[0].Status).toBe('Failed.');
      });

      it('process long running with placeholders', function () {
        var resourceUrl = '/api/clients/x/orgs/a/listexport';
        var requestBody = { Id: 'list1', IsTextExport: true };
        var expectedResult = {
          data: {
            success: true
          }
        };
        notification.task.NotificationLink = [
          'clients/ClientKey/orgs/OrgKey/listexport',
          'clients/ClientKey/orgs/OrgKey/listexport'
        ];
        http.expectPOST(resourceUrl, requestBody).respond(expectedResult);
        http.expectDELETE('/api/longRunningTasks/lrt1').respond(expectedResult);
        longTaskService.processTask(notification, 0);
        http.flush();
        expect(notificationService.remove).toHaveBeenCalled();
      });
    });

    describe('updateLongRunningTasks updates the LRT', function () {
      var response = {
        data:
          {
            results:
              {
                Tasks: []
              }
            }
          };
      response.data.results.Tasks.push({
        'id': 'lrt1',
        'UserId': 'auth0|user1',
        'Description': 'List Export - Test',
        'PercentComplete': 100,
        'Status': 'Success.',
        'IsError': false,
        'NotificationBehavior': 53,
        'NotificationMetadata': [
          '{\"RequestType\":\"get\", \"NotificationTitle\":\"Download\",\"DocumentType\":\"Text\", \"ResponseType\":\"arraybuffer\", \"ResponseTimeout\":\"2 * 60 * 1000\"}'
        ],
        'NotificationLink': [
            'clients/x/orgs/a/listexport/lrt1'
          ]
        });
      response.data.results.Tasks.push({
        'id': 'lrt1',
        'UserId': 'auth0|user1',
        'Description': 'List Pull - Test',
        'PercentComplete': 100,
        'Status': 'Success.',
        'IsError': false,
        'NotificationBehavior': 53,
        'NotificationMetadata': [
          '{\"RequestType\":\"post\",\"RequestBody\": {\"Id\":\"list1\",\"IsTextExport\":true},\"Description\":\"List Export - Test\",\"NotificationTitle\":\"Export To Text File\", \"Broadcast\": \"listExport:started\",\"ListId\":\"list1\", \"Name\":\"Test\"}',
          '{\"RequestType\":\"post\",\"RequestBody\": {\"Id\":\"list1\",\"IsTextExport\":false},\"Description\":\"List Export - Test\",\"NotificationTitle\":\"Export To Market Automation\", \"Broadcast\": \"listExport:started\",\"ListId\":\"list1\", \"Name\":\"Test\"}'
        ],
        'NotificationLink': [
            'clients/x/orgs/a/listexport',
            'clients/x/orgs/a/listexport'
          ]
        });
      it('get long running tasks', function () {
        var resourceUrl = '/api/longRunningTasks';
        http.expectGET(resourceUrl).respond(response.data);
        longTaskService.update(true);
        http.flush();
        expect(longTaskService.get().length).toBe(2);
      });
    });
  });
})(window.app);