﻿(function () {
  'use strict';

  describe('userContextSvc Testing Suite', function () {

    var userContextService, clients, oneClient;

    beforeEach(function () {
      module('app');

      inject(function (userContextSvc) {
        userContextService = userContextSvc;
      });

    });
    describe('when userContextSvc is called', function() {
      it('should exist', function () {
        expect(userContextService).not.toBeUndefined();
      });
      describe('IsSilverpopConfigured test', function() {
        var clientInfo = {
          Key: 'southeast',
          ETLDate: null,
          IsSilverpopConfigured: false
        };

        it('should get IsSilverpopConfigured value', function () {
          expect(clientInfo.IsSilverpopConfigured).toBe(false);
        });
      });
      describe('expand or collapse ui tree nodes', function() {
        clients = [
          'Birmingham',
          'Huntsville',
          'Montgomery'
        ];
        oneClient = ['Bham'];
        it('should call the expandOrCollapseNodes method', function() {
          expect(userContextService.expandOrCollapseNodes(clients)).not.toBeUndefined();
        });
        it('should set isSingleClient to false if clients.length !== 1', function() {
          expect(userContextService.expandOrCollapseNodes(clients).isSingleClient).toBe(false);
        });
        it('should set isSingleClient to true if clients.length === 1', function() {
          expect(userContextService.expandOrCollapseNodes(oneClient).isSingleClient).toBe(true);
        });
      });
    });
  });
})(window.app);
