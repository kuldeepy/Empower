﻿(function () {
	'use strict';

	describe('pastListSvc', function () {
		var pastListService, http, q, userContextService, expectedResult, retVal;

		beforeEach(function () {
			module('app', function ($httpProvider, $provide) {

				//remove auth interceptor for testing since it interferes with tokens
				$httpProvider.interceptors.pop('authInterceptor');
				$httpProvider.interceptors.pop('errorInterceptor');

				var userContextServiceSpy = jasmine.createSpyObj('userContextSvc', ['getApiClientKey', 'getOrgKey']);
				userContextServiceSpy.getApiClientKey.and.returnValue('x');
				userContextServiceSpy.getOrgKey.and.returnValue('a');
				$provide.value('userContextSvc', userContextServiceSpy);

			});

			inject(function ($httpBackend, $q, userContextSvc, pastListSvc) {
				http = $httpBackend;
				q = $q;
				userContextService = userContextSvc;
				pastListService = pastListSvc;
			});

		});

		it('checks for the pastListSvc to be exists', function () {
			expect(pastListService).not.toBeUndefined();
		});

		it('checks for the pastListData() to be  exists', function () {
			expect(pastListService.pastListData).not.toBeUndefined();
		});


		it('returns pastlist object when success', function () {
			var resourceUrl = '/api/clients/x/orgs/a/pastList?ApplyExclusionPeriod=true';
			expectedResult = {
				results: {
					PastList: [{
						'Name': 'list1'
					}]
				}
			};
			http.expectGET(resourceUrl).respond(expectedResult);

			pastListService.pastListData(true).then(function (data) {
				retVal = data;
			});
			http.flush();

			expect(retVal).toBe(expectedResult.results.PastList);
		});


		it('check callback error for pastListData method', function () {
			var resourceUrl = '/api/clients/x/orgs/a/pastList?ApplyExclusionPeriod=true';
			expectedResult = {
				error: {
					data: {
						'message': 'list2'
					}
				}
			};
			http.whenGET(resourceUrl).respond(500, expectedResult.error.data);
			pastListService.pastListData(true).then(function (data) {
				retVal = data;
			},
			function (error) {
				error.data = { message: 'error' };
				retVal = error;
			});
			http.flush();
			expect(retVal).toBe(pastListService.errorText);
		});

	});
})(window.app);