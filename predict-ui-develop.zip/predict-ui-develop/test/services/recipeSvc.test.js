(function () {
	'use strict';

	describe('recipeSvc', function () {

		var BASE_API_URL = '/api/medseek/';

		var recipeService, http, q;



		beforeEach(function () {
			module('app', function ($provide, $httpProvider) {
				var mockFactory = function () {
					return BASE_API_URL;
				};
				$provide.value('baseApiUrl', mockFactory);

				$httpProvider.interceptors.pop('authInterceptor');
				$httpProvider.interceptors.pop('errorInterceptor');
			});

			inject(function ($httpBackend, $q, recipeSvc) {
				http = $httpBackend;
				q = $q;
				recipeService = recipeSvc;
			});

		});

		it('exists', function () {
			expect(recipeService).not.toBeUndefined();
		});

		describe('getRecipe', function () {
			it('exists', function () {
				expect(recipeService.getRecipe).not.toBeUndefined();
			});

			describe('when called', function () {
				var recipeId, recipe, res;

				beforeEach(function () {
					recipeId = '44442';
					recipe = {
						RecipeId: recipeId
					};

					http
						.expectGET(BASE_API_URL+'recipes/'+recipeId)
						.respond({ results: { Recipe: recipe } });

					recipeService.getRecipe(recipeId)
						.then(function (result) {
							res = result;
						});

					http.flush();
				});

				afterEach(function () {
					http.verifyNoOutstandingExpectation();
				});

				it('returns recipe', function () {
					expect(res).toBe(recipe);
				});
			});
		});

		describe('getRecipesForOrganization', function () {

			it('exists', function () {
				expect(recipeService.getRecipesForOrganization).not.toBeUndefined();
			});

			describe('when called', function () {

				var expectedResult;


				afterEach(function () {
					http.verifyNoOutstandingExpectation();
				});

				it('returns recipes for organization A', function () {
					expectedResult = {
						results: {
							Recipes: [{
								'Name': 'Recipe2'
							}]
						}
					};
					http.expectGET(BASE_API_URL+'recipes').respond(expectedResult);
					var retVal;
					recipeService.getRecipesForOrganization().then(function (data) {
						retVal = data;
					});
					http.flush();
					expect(retVal).toBe(expectedResult.results.Recipes);
				});

				it('returns recipes for organization B', function () {
					expectedResult = {
						results: {
							Recipes: [{
								'Name': 'Recipe1'
							}]
						}
					};
					http.expectGET(BASE_API_URL+'recipes').respond(expectedResult);
					var retVal;
					recipeService.getRecipesForOrganization().then(function (data) {
						retVal = data;
					});
					http.flush();
					expect(retVal).toBe(expectedResult.results.Recipes);
				});

			});
		});

	});
})(window.app);