
(function () {
  'use strict';
  describe('alertSvc', function () {
    var notificationService;
    var sampleItem = {Message: 'test', Type: 'Fatal', Source: 'recipe' };
    beforeEach(function () {
      module('app', function () { });
      inject(function (alertSvc) {
        notificationService = alertSvc;
      });
    });
    it('exists', function () {
      expect(notificationService).not.toBeUndefined();
    });
    
    describe('add notificationList', function () {
      it('exists', function () {
        expect(notificationService.add).not.toBeUndefined();
      });
      it('add to list', function () {
        notificationService.removeAll();
        notificationService.add(sampleItem);
        var result = notificationService.get();
        expect(result[0]).toEqual(sampleItem);
      });
      it('add with code', function () {
        notificationService.removeAll();
        notificationService.add({Code:1000, Message: 'test'});
        var result = notificationService.get();
        expect(result[0]).toEqual({ Code: 1000, Type: 'Fatal', Title: 'Internal Server Error', Message: 'test' });
      });
    });
    describe('get notificationList', function () {
      it('exists', function () {
        expect(notificationService.get).not.toBeUndefined();
      });
      it('get List', function () {
        notificationService.removeAll();
        notificationService.add(sampleItem);
        var result = notificationService.get();
        expect(result[0]).toEqual(sampleItem);
      });

    });
    describe('removeAll from notificationList', function () {
      it('exists', function () {
        expect(notificationService.removeAll).not.toBeUndefined();
      });
      it('remove all from List', function () {
        notificationService.add(sampleItem);
        notificationService.removeAll();
        var result = notificationService.get();
        expect(result.length).toEqual(0);
      });
    });
    describe('remove one from notificationList', function () {
      it('exists', function () {
        expect(notificationService.remove).not.toBeUndefined();
      });
      it('remove one from List', function () {
        notificationService.add(sampleItem);
        notificationService.add({ Code: 1000, Type: 'Fatal', Title: 'Internal Server Error', Message: 'test' });
        notificationService.remove(sampleItem);
        var result = notificationService.get();
        expect(result.length).toEqual(1);
      });
    });
  });

})(window.app);
