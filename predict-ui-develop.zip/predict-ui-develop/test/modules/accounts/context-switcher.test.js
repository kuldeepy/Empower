(function () {
  'use strict';

  describe('Context Switcher Test Suite: ', function () {
    var scope,
      element,
      el,
      tree,
      treeItem,
      treeItemName,
      treeItemChild;
    beforeEach(function () {
      module('app');
      module('ui.tree');
      module('templates');
    });
    beforeEach(inject(function ($compile, $rootScope) {
      scope = $rootScope.$new();
      scope.clients = [
        {
          Name: 'Northwest Health Systems',
          Organizations: [
            {
              Name: 'NW Primary'
            },
            {
              Name: 'NW Secondary'
            }
          ]
        },
        {
          Name: 'University of Colorado',
          Organizations: [
            {
              Name: 'Primary'
            },
            {
              Name: 'Secondary'
            },
            {
              Name: 'Alegent'
            }
          ]
        }
      ];
      tree = '<div ui-tree data-drag-enabled="false" data-max-depth="1">' +
        '<ol ui-tree-nodes ng-model="clients" class="angular-ui-tree-nodes">' +
          '<li ng-repeat="client in clients | orderBy:\'Name\' " ui-tree-node id="tree-root">' +
            '<a href="" data-nodrag ng-click="toggle(this)" class="tree-item">' +
              '{{client.Name}}' +
            '</a>' +
            '<ol ui-tree-nodes="" ng-model="client.Organizations" ng-class="{hidden: collapsed}">' +
              '<li ng-repeat="org in client.Organizations | orderBy:\'Name\' " ui-tree-node>' +
                '<a href="" class="tree-item-child" data-nodrag ng-click="setUserContext(client, org)">' +
                  '{{org.Name}}' +
                '</a>' +
              '</li>' +
            '</ol>' +
          '</li>' +
        '</ol>' +
      '</div>';
      element = angular.element(tree);
      el = $compile(element)(scope);
      scope.$digest();
      treeItem = el.find('ol > li');
      treeItemName = el.find('ol > li > .tree-item');
      treeItemChild = el.find('ol > li > .tree-item-child');
    }));
    describe('Clients Testing: ', function () {
      it('should output 2 clients ', function () {
        expect(treeItemName.length).toBe(2);
      });
      it('should alphabetize the client list ', function () {
        expect(treeItemName.eq(0).text().trim()).toBe('Northwest Health Systems');
      });
    });
    describe('Organizations Testing: ', function () {
      it('should output 5 orgs', function () {
        expect(treeItemChild.length).toBe(5);
      });
      it('should alphabetize the orgs list ', function () {
        expect(treeItemChild.eq(0).text().trim()).toBe('NW Primary');
      });
    });
  });
}(window.app));
