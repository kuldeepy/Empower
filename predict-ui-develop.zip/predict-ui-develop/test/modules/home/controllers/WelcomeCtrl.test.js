﻿(function () {
  'use strict';
  describe('HomeWelcomeCtrl', function () {
    var scope, ctrl, def;
    var authServiceSpy, clientServiceSpy;
    var clienkKeys = [
      { ClientKey: 'southeast', LeagacyUserId: 'userid' }
    ];
    var clients = [{
      'Key': 'southeast'
    }, {
      'Key': 'southwest'
    }];
    beforeEach(function () {
      module('app', function ($httpProvider, $provide) {
        //remove auth interceptor for testing since it interferes with tokens
        $httpProvider.interceptors.pop('authInterceptor');
        $httpProvider.interceptors.pop('errorInterceptor');

        authServiceSpy = jasmine.createSpyObj('authSvc', ['getToken', 'getAdminClientKeys', 'getUsername', 'getFullName', 'getRoles', 'getTokenExpirationDate', 'getTokenIssueDate', 'isSystemAdministrator', , 'isClientAdministrator']);
        authServiceSpy.getUsername.and.returnValue('user1');
        authServiceSpy.getFullName.and.returnValue('user1@southeast.com');
        authServiceSpy.getRoles.and.returnValue('Executive');
        authServiceSpy.getTokenExpirationDate.and.returnValue('01/07/2014');
        authServiceSpy.getTokenIssueDate.and.returnValue('01/06/2014');
        authServiceSpy.isSystemAdministrator.and.returnValue(true);
        authServiceSpy.isClientAdministrator.and.returnValue(false);
        authServiceSpy.getAdminClientKeys.and.returnValue(clienkKeys);
        authServiceSpy.getToken.and.returnValue('token');
        $provide.value('authSvc', authServiceSpy);

        var userContextServiceSpy = jasmine.createSpyObj('userContextSvc', ['getApiClientKey', 'getClientKey', 'getUserOrganizations', 'getOrganizationName']);
        userContextServiceSpy.getApiClientKey.and.returnValue('x');
        userContextServiceSpy.getUserOrganizations.and.returnValue('primary');
        userContextServiceSpy.getOrganizationName.and.returnValue('primary');
        userContextServiceSpy.getClientKey.and.returnValue('a');
        $provide.value('userContextSvc', userContextServiceSpy);

        clientServiceSpy = jasmine.createSpyObj('clientSvc', ['loadClients']);
        $provide.value('clientSvc', clientServiceSpy);
      });

      inject(function (_$rootScope_, $controller, $q) {
        def = $q.defer();
        def.resolve(clients);
        clientServiceSpy.loadClients.and.returnValue(def.promise);
        scope = _$rootScope_.$new();
        ctrl = $controller('HomeWelcomeCtrl', {
          $scope: scope
        });
      });
    });
    it('controller exists', function () {
      expect(ctrl).not.toBeUndefined();
    });

    it('securityTrim to return true if user is authorized', function () {
      authServiceSpy.isSystemAdministrator.and.returnValue(false);
      var roles = ['admin', 'Executive'];
      scope.model = { roles: ['admin'] };
      var found = scope.securityTrim(roles);
      expect(found).toBe(true);
    });
    it('securityTrim to return false if user is unauthorized', function () {
      authServiceSpy.isSystemAdministrator.and.returnValue(false);
      var roles = ['executive'];
      scope.model = { roles: ['campaigner'] };
      var found = scope.securityTrim(roles);
      expect(found).toBe(false);
    });
    it('should have a openManageListsModal function', function () {
      expect(scope.openManageListsModal).not.toBeUndefined();
    });
    it('should give organizations when onClientValueChange ', function () {
      scope.model = { clients: [{ Key: 'northwest', Organizations: [{ Key: 'section1', Name: 'section1' }] }, { Key: 'southwest', Organizations: [{ Key: 'southwest1', Name: 'southwest1' }] }] };
      scope.defaultClientSelected = 'southwest~southwest Health Systems';
      scope.onClientValueChange();
      expect(scope.onClientValueChange).not.toBeUndefined();
      expect(scope.model.userOrgs[0].OrgKey).toBe('southwest1');
    });
    it('OK button should get enabled if organization is selected', function () {
      scope.defaultOrgSelected = 'section1';
      scope.onOrganizationValueChange();
      expect(scope.isOkDisabled).toBe(false);
    });
    it('OK button should get disabled if organization is  not selected', function () {
      scope.defaultOrgSelected = 'SELECT ORGANIZATION';
      scope.onOrganizationValueChange();
      expect(scope.isOkDisabled).toBe(true);
    });
    it('OK button should get disabled if client is not selected', function () {
      scope.defaultClientSelected = 'SELECT CLIENT';
      scope.onClientValueChange();
      expect(scope.isOkDisabled).toBe(true);
    });
    it('should return only organization for other than admin user', function () {
      authServiceSpy.isSystemAdministrator.and.returnValue(false);
      scope.model = { roles: ['campaigner'] };
      scope.defaultClientSelected = 'southeast';
      scope.defaultOrgSelected = 'section1';
      scope.linkType = 'LIST';
      scope.onOKClick();
      expect(scope.selectedClient).toBe('');
      expect(scope.selectedOrg).toBe('section1');
    });
  });
})(window.app);