﻿(function () {
  'use strict';

  describe('LoginCtrl controller tests', function () {
    var ctrl, scope, location, authFactory, q;

    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $location, $controller, authSvc, $q) {
        scope = $rootScope.$new();
        ctrl = $controller('LoginCtrl', {
          $scope: scope
        });
        location = $location;
        authFactory = authSvc;
        q = $q;
      });

    });

    describe('check if controller functions exists', function () {

      it('should have a LoginCtrl Controller', function () {
        expect(ctrl).not.toBeUndefined();
      });

      it('should have a login() function', function () {
        expect(scope.login).not.toBeUndefined();
      });

      it('should have a checkCapsLockOn() function', function () {
        expect(scope.checkCapsLockOn).not.toBeUndefined();
      });

      it('should have a submitForgotPasswordRequest() function', function () {
        expect(scope.submitForgotPasswordRequest).not.toBeUndefined();
      });

      it('should have a closeForgotPasswordRequest() function', function () {
        expect(scope.closeForgotPasswordRequest).not.toBeUndefined();
      });

      it('should have a cancelForgotPasswordRequest() function', function () {
        expect(scope.cancelForgotPasswordRequest).not.toBeUndefined();
      });

      it('should have a onForgotPasswordFieldChange() function', function () {
        expect(scope.onForgotPasswordFieldChange).not.toBeUndefined();
      });

      it('should have a resetExpiredPassword() function', function () {
        expect(scope.resetExpiredPassword).not.toBeUndefined();
      });

      it('should have a continueWithExpiredPassword() function', function () {
        expect(scope.continueWithExpiredPassword).not.toBeUndefined();
      });

      it('should have a resetPasswordSubmit() function', function () {
        expect(scope.resetPasswordSubmit).not.toBeUndefined();
      });

      it('should have a verifyConfirmationCode() function', function () {
        expect(scope.verifyConfirmationCode).not.toBeUndefined();
      });

      it('should have a changePassword() function', function () {
        expect(scope.changePassword).not.toBeUndefined();
      });

      it('should have a showResetPasswordPopup() function', function () {
        expect(scope.showResetPasswordPopup).not.toBeUndefined();
      });

      it('Username and Password should not be undefined', function () {
        scope.model = { Username: undefined, Password: undefined };
        scope.login();
        expect(scope.model.Username).toBeUndefined();
        expect(scope.model.Password).toBeUndefined();
      });

      it('should call createToken() function', function () {
        var defer = q.defer();
        var data = {};
        scope.layout = { loading: true };
        defer.resolve(data);
        spyOn(authFactory, 'createToken').and.returnValue(defer.promise);
        scope.model = { Username: 'test', Password: 'test' };
        scope.login();
        expect(authFactory.createToken).toHaveBeenCalled();
      });

    });
  });
})(window.app);

