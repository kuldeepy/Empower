﻿(function () {
  'use strict';

  describe('SessionCtrl controller tests', function () {
    var ctrl, scope, location, q, browserDetector, alertFactory;

    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $location, $controller, $q, alertSvc) {
        /*jshint camelcase: false */
        browserDetector = {
          browser: 'ie',
          browser_version: '9'
        };
        scope = $rootScope.$new();
        location = $location;
        q = $q;
        alertFactory = alertSvc;
        var defer = q.defer();
        var data = {};
        defer.resolve(data);
        spyOn(alertFactory, 'add').and.returnValue(defer.promise);
        ctrl = $controller('SessionCtrl', {
          $scope: scope,
          deviceDetector: browserDetector
        });
      });

    });

    describe('check if controller functions exists', function () {

      it('should have a SessionCtrl Controller', function () {
        expect(ctrl).not.toBeUndefined();
      });

      it('should check browser is supported or not', function () {
        expect(alertFactory.add).toHaveBeenCalled();
      });

    });
  });
})(window.app);

