﻿(function () {
  'use strict';

  describe('listNameAndChannelCtrl', function () {

    var ctrl, def, scope, listStateSvc, val, listState, stepComplete, stepName, lookupSvc, lookupDataFromService;

    beforeEach(function () {
      module('app');

      listStateSvc = {
        get: function () {
          return val;
        }
      };

      listState = {
        Id: 'abc123',
        RecipeId: 'ABC123',
        Name: 'Josh List',
        MarketingChannelId: '1',
        Segments:[{
          FilterValueSelections: [{ FilterName: 'ValidAddress', ExcludeValues: ['False'], IncludeValues: ['True'] }]
        }],
        FilterValueSelections: [{ FilterName: 'ValidAddress', ExcludeValues: ['False'], IncludeValues: ['True'] }]
      };

      lookupDataFromService = [{ MediaTypeName: 'Direct Mail', MediaTypeID: '1' }, { MediaTypeName: 'Email', MediaTypeID: '2' }];

      spyOn(listStateSvc, 'get').and.returnValue(listState);
      angular.mock.inject(function ($rootScope, $controller, $q) {
        scope = $rootScope.$new();
        scope.loading = $q.when();
        scope.initializeStep = function (stepN, stepC) { stepName = stepN; stepComplete = stepC; };
        scope.completeStep = function (val) { stepComplete = val; };
        scope.listItem = {};
        scope.listItem.Name = 'ABC';
        scope.currentList = listState;
        scope.marketingChannel = {};
        scope.marketingChannel.value = 1;
        spyOn(scope, 'initializeStep');

        lookupSvc = {
          getLookupDataById: function () {
            def = $q.defer();
            def.resolve(lookupDataFromService);
            return def.promise;
          }
        };
        spyOn(lookupSvc, 'getLookupDataById').and.callThrough();
        ctrl = $controller('listNameAndChannelCtrl', {
          $scope: scope,
          listStateSvc: listStateSvc,
          lookupSvc: lookupSvc
        });
      });
    });

    it('check if listNameAndChannelCtrl  exist and defined', function () {
      expect(ctrl).not.toBeUndefined();
    });

    it('it should contain a method getMarketingChannels ', function () {
      expect(scope.getMarketingChannels).not.toBeUndefined();
    });

    it('initalize listName step is called', function () {
      scope.$apply();
      spyOn(scope, 'completeStep').and.callThrough();
      expect(scope.initializeStep).toHaveBeenCalledWith('listName', false);
    });

    it('it should get the Marketing Channels', function () {
      spyOn(scope, 'completeStep').and.callThrough();
      scope.getMarketingChannels();
      scope.$digest();
      expect(lookupSvc.getLookupDataById).toHaveBeenCalled();
      expect(scope.channelOptions).toEqual(lookupDataFromService);
    });

    it('it should test filterValueSelections object direct email ', function () {
      scope.updateFilterValueSelection();
      expect(scope.currentList.FilterValueSelections).toContain({ FilterName: 'ValidAddress', ExcludeValues: ['False'], IncludeValues: [] });
    });

    it('it should contain both the object for email ', function () {
      scope.currentList.MarketingChannelId = 2;
      scope.updateFilterValueSelection();
      expect(scope.currentList.FilterValueSelections.length).toBe(2);
      expect(scope.currentList.FilterValueSelections).toContain({ FilterName: 'ValidAddress', ExcludeValues: [], IncludeValues: ['False', 'True'] });
    });
  });
})(window.app);