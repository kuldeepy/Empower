(function() {
  'use strict';

  describe('selectRecipeCtrl', function() {

    var ctrl, scope, recipeService, personRecipeCountService, def, personRecipeCountsPromise;

    beforeEach(function() {
      module('app');
      angular.mock.inject(function($rootScope, $controller, $q, listStateSvc) {

        listStateSvc.set({
          'Id': '1',
          'LocationDescriptors': [],
          'FilterValueSelections': [],
          'ExcludedPastListIds': [],
          'RecipeId': 0,
          'Segments': [],
          'IsEditable': true,
          'IsTransient': true,
          'CurrentUIState': {
            'CurrentLocationIndex': -1,
            'hasVisited': {}
          }
        });

        recipeService = {
          getRecipesForOrganization: function() {
            def = $q.defer();
            return def.promise;
          }
        };
        spyOn(recipeService, 'getRecipesForOrganization').and.callThrough();

        personRecipeCountService = {
          getPersonRecipeCounts: function() {
            personRecipeCountsPromise = $q.defer();
            personRecipeCountsPromise.resolve([]);
            return personRecipeCountsPromise.promise;
          }
        };
        spyOn(personRecipeCountService, 'getPersonRecipeCounts').and.callThrough();

        scope = $rootScope.$new();
        scope.loading = $q.when();

        ctrl = $controller('selectRecipeCtrl', {
          $scope: scope,
          recipeSvc: recipeService,
          personRecipeCountSvc: personRecipeCountService
        });

      });
    });

    it('exists', function() {
      expect(ctrl).not.toBeUndefined();
    });

    describe('when created', function() {

      var recipesFromService = [];

      it('it should get the recipes', function() {
        def.resolve(recipesFromService);
        scope.$digest();
        expect(recipeService.getRecipesForOrganization).toHaveBeenCalled();
        expect(scope.recipes).toBe(recipesFromService);
      });

      it('it should set the grid options', function() {
        expect(scope.gridOptions).not.toBeUndefined();
      });

    });
  });
})(window.app);