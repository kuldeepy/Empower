(function () {
  'use strict';

  describe('manageSeedListCtrl', function () {

    var ctrl, scope, seedListSvc, def, result, seedListFromService;

    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $controller, $q, listStateSvc) {
        seedListFromService = [{ ClientKey: '', Id: '1', IsMandatory: true }, { ClientKey: null, Id: '3', IsMandatory: true }, { ClientKey: 'southeast', Id: '2', IsMandatory: false }];
        seedListSvc = {
          getSeedListData: function () {
            def = $q.defer();
            def.resolve(seedListFromService);
            return def.promise;
          }
        };

        spyOn(seedListSvc, 'getSeedListData').and.callThrough();

        var list = [];
        spyOn(listStateSvc, 'get').and.returnValue(list);

        scope = $rootScope.$new();
        ctrl = $controller('manageSeedListCtrl', {
          $scope: scope,
          seedListSvc: seedListSvc,
          listStateSvc: listStateSvc
        });
      });
    });

    it('exists', function () {
      expect(ctrl).not.toBeUndefined();
    });

    describe('when created', function () {

      it('it should contain a method getSeedLists ', function () {
        expect(scope.getSeedLists).not.toBeUndefined();
      });

      it('it should get the seedLists', function () {
        result = [{ ClientKey: 'southeast', Id: '2', IsMandatory: false, selected: false }];
        scope.completeStep = function () {
        };
        spyOn(scope, 'completeStep').and.callThrough();
        scope.getSeedLists();
        scope.$digest();
        expect(seedListSvc.getSeedListData).toHaveBeenCalled();
        expect(scope.seedLists).toEqual(result);
      });

      it('it should contain a method removeInfluenceHealthSeedId', function () {
        expect(scope.removeInfluenceHealthSeedId).not.toBeUndefined();
      });

      it('it should contain a method disabledRow ', function () {
        expect(scope.disabledRow).not.toBeUndefined();
      });

      it('it should set the column defs', function () {
        expect(scope.controllerData.gridColumns).not.toBeUndefined();
      });

      it('it should call addSelectedSeedList', function () {
        scope.addSelectedSeedList();
        expect(scope.addSelectedSeedList).toBeTruthy();
      });

      it('it should filter out ClientKey as null and empty string in seedList', function () {
        scope.completeStep = function () {
        };
        spyOn(scope, 'completeStep').and.callThrough();
        scope.removeInfluenceHealthSeedId();
        scope.$digest();
        expect(scope.seedLists.length).toEqual(1);
      });
    });
  });
})(window.app);
