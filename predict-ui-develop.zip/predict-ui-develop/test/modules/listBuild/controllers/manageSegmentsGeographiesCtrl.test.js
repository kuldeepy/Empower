///* global expect, beforeEach, describe, jasmine, it */
(function() {
	'use strict';

	describe('manageSegmentsGeographiesCtrl', function() {

		var ctrl, scope, sessionSvc, listStateSvc, listState;

		beforeEach(function() {
			module('app');
			angular.mock.inject(function($rootScope, $controller) {

				sessionSvc = jasmine.createSpyObj('SessionSvc', [ 'get', 'set', 'clear' ]);
				
				listState = {
					'CurrentUIState': {
						'selectedSegment': {
							'LocationDescriptorIndices': [ 0 ]
						}
					},
					'LocationDescriptors': [{
						'Name': 'East Side',
						'Type': 'LocationServiceArea',
						'LocationId': '53713b6e1b3054d3585532a2',
						'Address':null,
						'RadiusInMiles':null,
						'PrimaryArea': true,
						'SecondaryArea': false,
						'TertiaryArea': false,
						'PrimaryServiceAreaZipCodes': [
							'71834',
							'71837',
							'71854',
							'75501',
							'75503'
						],
						'RadiusDescriptors': []
					}]
				};

				listStateSvc = jasmine.createSpyObj('listStateSvc', [ 'get' ]);
				listStateSvc.get.and.returnValue(listState);

				scope = $rootScope.$new();

				ctrl = $controller('manageSegmentsGeographiesCtrl', {
					$scope: scope,
					sessionSvc: sessionSvc,
					listStateSvc: listStateSvc
				});
			});
		});

		it('it should set the grid options', function() {
			expect(scope.gridOptions).not.toBeUndefined();
		});

		it('should set correct data source for grid options', function () {
			expect(scope.gridOptions.data).toBe('locations');
		});

		it('should have new scope.segment', function () {
			expect(scope.segment).not.toBeUndefined();
		});

		describe('afterSelectionChange given selected location', function () {
			beforeEach(function () {
				scope.segment.LocationDescriptors = [{
					'Name': 'East Side',
					'Type': 'LocationServiceArea',
					'LocationId': '53713b6e1b3054d3585532a2',
					'Address':null,
					'RadiusInMiles':null,
					'PrimaryArea': true,
					'SecondaryArea': false,
					'TertiaryArea': false,
					'PrimaryServiceAreaZipCodes': [
						'71834',
						'71837',
						'71854',
						'75501',
						'75503'
					]
				}];

				scope.locations = [ { __index: 0 } ];

				scope.selectedLocations = [ { __index: 0 } ];

				scope.completeStep = jasmine.createSpy('completeStep');

				scope.gridOptions.afterSelectionChange();
			});

			it('should complete step', function () {
				expect(scope.completeStep).toHaveBeenCalledWith(true);
			});

			it('should have correct location descriptor indices', function () {
				expect(scope.segment.LocationDescriptorIndices).toEqual([ 0 ]);
			});
		});

		describe('afterSelectionChange not given selected location', function () {
			beforeEach(function () {
				scope.segment.LocationDescriptors = [];
				scope.selectedLocations = [];

				scope.completeStep = jasmine.createSpy();

				scope.gridOptions.afterSelectionChange();
			});

			it('should complete step', function () {
				expect(scope.completeStep).toHaveBeenCalledWith(false);
			});
		});
	});
})(window.app);