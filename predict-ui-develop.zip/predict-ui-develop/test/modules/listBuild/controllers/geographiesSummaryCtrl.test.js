﻿(function () {
  'use strict';

  describe('geographiesSummaryCtrl', function () {
    var ctrl, q, def, scope, facilities, dataJson;
    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $controller, $q, listStateSvc, sessionSvc, geographyHelper) {
        var locationDescriptors = [{ 'Address': [{ 'Address1': 'Nashvile', 'city': 'City1' }], 'LocationId': 81, 'Id': 3000, 'Type': 'Radius' }, { 'Address': [{ 'Address1': 'Nashvile', 'city': 'City1' }], 'LocationId': 9, 'Id': 4000, 'Type': 'Radius' }];
        q = $q;
        spyOn(listStateSvc, 'get').and.returnValue(locationDescriptors);
        facilities = {
          'Facilities': [{
            'Address': {
              'Address1': 'Nashvile',
              'State': 'IA',
              'City': 'Nashvile',
              'Zip': '12345'
            },
            'LocationId': 26262,
            'Name': 'Hackensack University Medical Center',
            'Id': 3000
          }
          ]
        };
        dataJson = JSON.stringify(facilities);
        spyOn(geographyHelper, 'mapLocationDescriptorsForGrid').and.returnValue(locationDescriptors);
        var facilitySvc = {
          getFacilities: function () {
            def = q.defer();
            def.resolve(dataJson);
            return def.promise;
          }
        };
        spyOn(facilitySvc, 'getFacilities').and.callThrough();
        spyOn(sessionSvc, 'get').and.returnValue(JSON.stringify(facilities));
        spyOn(sessionSvc, 'set').and.returnValue(JSON.stringify(facilities));
        scope = $rootScope.$new();
        ctrl = $controller('geographiesSummaryCtrl', {
          $scope: scope,
          listStateSvc: listStateSvc,
          facilitySvc: facilitySvc
        });
      });
    });
    it('exists', function () {
      expect(ctrl).not.toBeUndefined();
    });
    describe('when created', function () {
      it('it should set the grid options', function () {
        expect(scope.gridOptions).not.toBeUndefined();
      });
      it('getFacilitiesWithlocationDescriptors', function () {
        var locationDescriptors = [{ 'Address': [{ 'Address1': 'Nashvile', 'city': 'City1' }], 'LocationId': 81, 'Id': 3000, 'Type': 'Radius' }, { 'Address': [{ 'Address1': 'Nashvile', 'city': 'City1' }], 'LocationId': 9, 'Id': 4000, 'Type': 'Radius' }];
        scope.getFacilities(locationDescriptors);
        expect(scope.loadingFacilities).not.toBeUndefined();
        
      });

      it('Load current Facilities', function () {
        var locationDescriptors = [{ 'Address': [{ 'Address1': 'Nashvile', 'city': 'City1' }], 'LocationId': 81, 'Id': 3000, 'Type': 'Radius' }, { 'Address': [{ 'Address1': 'Nashvile', 'city': 'City1' }], 'LocationId': 9, 'Id': 4000, 'Type': 'Radius' }];
        scope.completeStep = function () {
        };
        scope.getFacilities(locationDescriptors);
        spyOn(scope, 'completeStep').and.callThrough();
        scope.$apply();
        scope.locations = locationDescriptors;
        console.log(scope.locations);
        expect(scope.loadingFacilities).not.toBeUndefined();
        expect(scope.locations).not.toBeUndefined();
      });
    });
  });
})(window.app);