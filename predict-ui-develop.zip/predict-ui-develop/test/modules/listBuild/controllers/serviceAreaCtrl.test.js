﻿(function () {
  'use strict';

  describe('serviceAreaCtrl', function () {
    var ctrl, scope, stepName, stepComplete, val, listState, rootScope, go, zipCodes, def, q, geographiesLookupSvc, counties, states, area;
    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $q, $controller, listStateSvc) {
        listStateSvc = {
          get: function () {
            return val;
          }
        };

        listState = {
          Id: 'abc123',
          RecipeId: 'ABC123',
          CurrentUIState: {
            CurrentLocationIndex: 0
          },
          LocationDescriptors: [
            {
              Type: 'ServiceArea',
              LocationId: 236,
              Address: {
                Address1: '1400 E BOULDER ST',
                City: 'COLORADO SPRINGS',
                State: 'CO',
                Zip: '80909',
                GeoJson: {
                  Type: 'Point',
                  Coordinates: [
                    '-104.8',
                    '38.8388'
                  ]
                }
              },
              RadiusDescriptors: [

              ],
              PrimaryServiceAreaZipCodes: [
                '80106',
                '80132'
              ],
              SecondaryServiceAreaZipCodes: [
                '80813',
                '80814'
              ],
              TertiaryServiceAreaZipCodes: [
                '80101',
                '81039'
              ],
              SelectedZipCodes: [
                '80106',
                '80132',
                '80101'
              ],
              UsePrimaryServiceArea: true,
              UseSecondaryServiceArea: true,
              UseTertiaryServiceArea: true
            }
          ]
        };

        zipCodes =
          [
            {
              Id : '80106',
              State : 'CO',
              CountyIds : [
                '08035',
                '08039',
                '08041'
              ]
            },
            {
              Id: '80132',
              State : 'CO',
              CountyIds : [
                '08041'
              ]
            },
            {
              Id: '80813',
              State : 'CO',
              CountyIds : [
                '08119'
              ]
            },
            {
              Id: '80814',
              State : 'CO',
              CountyIds : [
                '08119'
              ]
            },
            {
              Id: '80101',
              State : 'CO',
              CountyIds : [
                '08039',
                '08101'
              ]
            },
            {
              Id: '81039',
              State: 'CO',
              CountyIds: [
                '08025',
                '08089',
                '08101'
              ]
            }
          ];

        counties = [
          {
            Id: '08035',
            State : 'CO',
            Name : 'Douglas'
          },
          {
            Id: '08039',
            State : 'CO',
            Name : 'Elbert'
          },
          {
            Id: '08041',
            State : 'CO',
            Name : 'El Paso'
          },
          {
            Id: '08119',
            State : 'CO',
            Name : 'Teller'
          },
          {
            Id: '08089',
            State : 'CO',
            Name : 'Otero'
          },
          {
            Id: '08101',
            State : 'CO',
            Name : 'Pueblo'
          },
          {
            Id: '08025',
            State: 'CO',
            Name: 'Crowley'
          }
        ];

        states = [
          {
            Id: 'CO',
            Name: 'Colorado'
          }
        ];

        area = [
					{ name: 'Primary' },
					{ name: 'Secondary' },
					{ name: 'Tertiary' }
        ];
        q = $q;
        spyOn(listStateSvc, 'get').and.returnValue(listState);

        geographiesLookupSvc = {
          getZipCodesByLocation: function () {
            def = q.defer();
            def.resolve(zipCodes);
            return def.promise;
          },
          getStatesById: function(){
            return val;
          },
          getCountiesById: function () {
            def = q.defer();
            def.resolve(counties);
            return def.promise;
          }
        };
        spyOn(geographiesLookupSvc, 'getZipCodesByLocation').and.callThrough();
        spyOn(geographiesLookupSvc, 'getStatesById').and.returnValue(states);
        spyOn(geographiesLookupSvc, 'getCountiesById').and.callThrough();
        scope = $rootScope.$new();
        scope.zipCodesLoading = [];
        rootScope = $rootScope;
        scope.initializeStep = function (stepN, stepC) { stepName = stepN; stepComplete = stepC; };
        go = jasmine.createSpy('go');
        spyOn(scope, 'initializeStep');
        spyOn(rootScope, '$broadcast').and.callThrough();
        ctrl = $controller('serviceAreaCtrl', {
          $scope: scope,
          listStateSvc: listStateSvc,
          geographiesLookupSvc: geographiesLookupSvc
        });
      });
    });

    it('it should contain a method initialize ServiceArea ', function () {
      expect(scope.initializeServiceArea).not.toBeUndefined();
    });

    it('check if serviceAreaCtrl exist and defined', function () {
      expect(ctrl).not.toBeUndefined();
    });

    it('it should Initialize the ZipCodes, Counties and States', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      expect(geographiesLookupSvc.getZipCodesByLocation).toHaveBeenCalled();
      expect(scope.listBoxData.zipCodes).toEqual(zipCodes);
      expect(scope.listBoxData.counties).toEqual(counties);
      expect(scope.listBoxData.states).toEqual(states);
    });

    it('it should Initialize the ServiceArea', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.initializeServiceArea();
      scope.$digest();
      expect(geographiesLookupSvc.getZipCodesByLocation).toHaveBeenCalled();
      expect(scope.areas[0].checked).toEqual(true);
      expect(scope.areas[1].checked).toEqual(false);
      expect(scope.areas[2].checked).toEqual(false);
    });

    it('it should Check the ServiceArea', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      expect(geographiesLookupSvc.getZipCodesByLocation).toHaveBeenCalled();
      expect(scope.areas[0].checked).toEqual(true);
      expect(scope.areas[1].checked).toEqual(false);
      expect(scope.areas[2].checked).toEqual(false);
      expect(scope.areas[0].indeterminate).toEqual(false);
      expect(scope.areas[1].indeterminate).toEqual(false);
      expect(scope.areas[2].indeterminate).toEqual(true);
    });

    it('it should Check the States', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      expect(geographiesLookupSvc.getZipCodesByLocation).toHaveBeenCalled();
      expect(scope.listBoxData.states).toEqual(states);
      expect(scope.listBoxData.states[0].checked).toEqual(false);
      expect(scope.listBoxData.states[0].indeterminate).toEqual(true);
    });

    it('it should Check the Counties', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      expect(geographiesLookupSvc.getZipCodesByLocation).toHaveBeenCalled();
      expect(scope.listBoxData.counties).toEqual(counties);
      expect(scope.listBoxData.counties[0].checked).toEqual(true);
      expect(scope.listBoxData.counties[0].indeterminate).toEqual(false);
      expect(scope.listBoxData.counties[1].checked).toEqual(true);
      expect(scope.listBoxData.counties[1].indeterminate).toEqual(false);
      expect(scope.listBoxData.counties[2].checked).toEqual(true);
      expect(scope.listBoxData.counties[2].indeterminate).toEqual(false);
      expect(scope.listBoxData.counties[3].checked).toEqual(false);
      expect(scope.listBoxData.counties[3].indeterminate).toEqual(false);
      expect(scope.listBoxData.counties[4].checked).toEqual(false);
      expect(scope.listBoxData.counties[4].indeterminate).toEqual(false);
      expect(scope.listBoxData.counties[5].checked).toEqual(false);
      expect(scope.listBoxData.counties[5].indeterminate).toEqual(true);
      expect(scope.listBoxData.counties[6].checked).toEqual(false);
      expect(scope.listBoxData.counties[6].indeterminate).toEqual(false);
    });

    it('it should Check the ZipCodes', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      expect(geographiesLookupSvc.getZipCodesByLocation).toHaveBeenCalled();
      expect(scope.listBoxData.zipCodes).toEqual(zipCodes);
      expect(scope.listBoxData.zipCodes[0].checked).toEqual(true);
      expect(scope.listBoxData.zipCodes[1].checked).toEqual(true);
      expect(scope.listBoxData.zipCodes[2].checked).toEqual(false);
      expect(scope.listBoxData.zipCodes[3].checked).toEqual(false);
      expect(scope.listBoxData.zipCodes[4].checked).toEqual(true);
      expect(scope.listBoxData.zipCodes[5].checked).toEqual(false);
    });

    it('it should update the ServiceArea', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.serviceAreaUpdated(area);
      scope.$digest();
      expect(geographiesLookupSvc.getZipCodesByLocation).toHaveBeenCalled();
      expect(scope.listBoxData.zipCodes).toEqual(zipCodes);
    });

    it('initalize serviceAreaCtrl step is called', function () {
      expect(scope.initializeStep).toHaveBeenCalledWith('serviceArea', false);
    });

    it('call serviceAreaCtrl tab on next', function () {
      rootScope.$broadcast('next', go);
      expect(go).toHaveBeenCalledWith('geographiesSummary');
    });
  });
})(window.app);
