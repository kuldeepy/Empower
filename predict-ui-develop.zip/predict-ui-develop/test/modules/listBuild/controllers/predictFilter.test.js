(function () {
  'use strict';

  describe('Predict Filter Directive', function () {
    var $compile, $rootScope, filterTypeSvc, element;

    beforeEach(module('app', function ($provide) {
      filterTypeSvc = jasmine.createSpyObj('filterTypeSvc', ['loadFilterTypeData']);

      $provide.value('filterTypeSvc', filterTypeSvc);
    }));

    beforeEach(module('templates'));

    beforeEach(inject(function (_$compile_, _$rootScope_, $q) {
      $compile = _$compile_;
      $rootScope = _$rootScope_;

      var deferred = $q.defer();
      deferred.resolve(JSON.stringify({}));

      filterTypeSvc.loadFilterTypeData.and.returnValue(deferred.promise);


      var html = '<predict-filter recipe-filter-value-selections="{}" criteria="{}" list-filter-value-selections="{}"></predict-filter>';
      element = $compile(html)($rootScope);
      $rootScope.$digest();
    }));

    it('replaces the element with content', function () {
      expect(element.html()).not.toBeUndefined();
    });
  });

})(window.app);
