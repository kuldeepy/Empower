/* global beforeEach, inject, describe, jasmine, it, expect */
(function () {

  'use strict';

  describe('checkboxlist directive', function () {
    var $compile, $rootScope, element, items, model, changedCallback;

    beforeEach(module('app'));

    beforeEach(module('templates'));

    beforeEach(inject(function (_$compile_, _$rootScope_) {
      $compile = _$compile_;
      $rootScope = _$rootScope_;

      changedCallback = jasmine.createSpy('changedCallback');

      items = [
        {
          text: 'Hello',
          checked: false,
          changed: changedCallback
        }
      ];

      model = [];

      $rootScope.items = items;
      $rootScope.model = model;

      var html = '<checkboxlist ng-model="items"></checkboxlist>';
      element = $compile(html)($rootScope);
      $rootScope.$digest();
    }));

    it('should have items', function () {
      expect(element.find('li').eq(0).text().trim()).toBe(items[0].text);
    });

    it('should call changedCallback', function () {
      element.find('li input').eq(0).click();
      expect(changedCallback).toHaveBeenCalled();
    });

    it('should set checked to `true`', function () {
      element.find('li input').eq(0).click();
      expect(items[0].checked).toBe(true);
    });
    it('replaces the element with content', function () {
      expect(element.html()).not.toBeUndefined();
    });
    it('onClick function should be defined in directive', function () {
      expect(element.isolateScope().onClick).not.toBeUndefined();
    });
    it('checked function should be defined  in directive', function () {
      expect(element.isolateScope().checked).not.toBeUndefined();
    });

  });

})(window.app);
