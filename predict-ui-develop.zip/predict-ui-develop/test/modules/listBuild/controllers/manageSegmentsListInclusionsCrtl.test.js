///* global expect, beforeEach, describe, jasmine, it */
(function () {
  'use strict';

  describe('manageSegmentsListInclusionsCrtl', function () {

    var ctrl, scope, sessionSvc, listState, newList, def, list, callbackCalculationData, listStateSvc, calculationSvc;

    newList = {
      'Id': '53713b6e1b3054d358553234',
      'LocationDescriptors': [],
      'FilterValueSelections': [{ FilterName: 'ValidAddress', ExcludeValues: ['False'], IncludeValues: [] }],
      'ExcludedPastListIds': [],
      'IncludedPastListIds': [],
      'SeedListIds': [],
      'Segments': [],
      'IsEditable': true,
      'IsTransient': true,
      'ExcludeHoldouts': true,
      'LastCalculation': [],
      'CurrentUIState': {
        'CurrentLocationIndex': 0,
        'hasVisited': {}
      }
    };
    callbackCalculationData = { 'seedListCount': 0, 'segments': [{ 'familyMemberCountForHousehold': 64143, 'familyMemberCountForIndividual': 87669, 'newMoversCountForHousehold': 3430, 'newMoversCountForIndividual': 5811, 'patientCountForHousehold': 312603, 'patientCountForIndividual': 417231, 'prospectCountForHousehold': 987258, 'prospectCountForIndividual': 1353402, 'qualifiedProspectCountForHousehold': 4072, 'qualifiedProspectCountForIndividual': 5550, 'segmentName': 'Available Count', 'totalCountForHousehold': 1371506, 'totalCountForIndividual': 1869663 }] };


    listState = {
      'CurrentUIState': {
        'selectedSegment': {
          'IncludedPastListIds': ['53713b6e1b3054d358553231'],
          'LocationDescriptorIndices': [0]
        }
      },
      'IncludedPastListIds': ['53713b6e1b3054d3585532a2'],
      'LocationDescriptors': [{
        'Name': 'East Side',
        'Type': 'LocationServiceArea',
        'LocationId': '53713b6e1b3054d3585532a2',
        'Address': null,
        'RadiusInMiles': null,
        'PrimaryArea': true,
        'SecondaryArea': false,
        'TertiaryArea': false,
        'PrimaryServiceAreaZipCodes': [
          '71834',
          '71837',
          '71854',
          '75501',
          '75503'
        ],
        'RadiusDescriptors': []
      }]
    };

    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $controller, $q) {
        scope = $rootScope.$new();
        
        sessionSvc = jasmine.createSpyObj('SessionSvc', ['get', 'set']);

        def = $q.defer();
        
        list = [{'CanDisplay': true,'DateCreated': '2015-03-20T14:19:55.2702569Z', 'DatePulled': '2015-01-25T10:56:46.024Z', 'InExclusionPeriod': false, 'ListId': '550c2c44f4f17316b8dbf578', 'Name': 'Test_1261', 'actionValue': 'Include'}];
        
        sessionSvc.get.and.returnValue(JSON.stringify(list));
        
        listStateSvc = {
          createList: function () {
            def.resolve(newList);
            return def.promise;
          },
          get: function () {
            return listState;
          }
        };
       
        calculationSvc = {
          calculate: function () {
            def.resolve(callbackCalculationData);
            return def.promise;
          }
        };

        scope.addListRefIdsToSelection = function (obj, item) { obj.push(item); };
        spyOn(scope, 'addListRefIdsToSelection').and.callThrough();
        spyOn(listStateSvc, 'createList').and.callThrough();
        spyOn(listStateSvc, 'get').and.callThrough();
        spyOn(calculationSvc, 'calculate').and.callThrough();
        ctrl = $controller('manageSegmentsListInclusionsCrtl', {
          $scope: scope,
          q: $q,
          sessionSvc: sessionSvc,
          listStateSvc: listStateSvc,
          calculationSvc: calculationSvc
        });
      });
    });

    it('it should set the grid options', function () {
      expect(scope.gridOptions).not.toBeUndefined();
    });

    it('should set correct data source for grid options', function () {
      expect(scope.gridOptions.data).toBe('pastLists');
    });

    it('should have new scope.segment', function () {
      expect(scope.segment).not.toBeUndefined();
    });
    describe('when created', function () {

      it('should call calculateListCount', function () {
        scope.$digest();
        scope.calculatePastListCount('53713b6e1b3054d358553234');
        expect(scope.loading).not.toBeUndefined();
      });

      it('it should call rowChangeEvent', function () {
        scope.rowChangeEvent();
        expect(scope.rowChangeEvent).toBeTruthy();
      });

      it('it should call individualTotalCount', function () {
        var entity = { ListId: '123' };
        scope.pastLists = { ListId: '123', targetedCount: 123 };
        expect(scope.individualTotalCount(entity)).toBeUndefined();
        expect(scope.individualTotalCount).toBeTruthy();
      });

      it('it should call getincludedPastList', function () {
        scope.getIncludedPastLists();
        expect(scope.includedPastLists).not.toBeUndefined();
      });
      it('it should call beforeSelectionChange', function () {
        var row = { 'entity': { 'CanDisplay': true, 'DateCreated': '2015-03-20T14:19:55.2702569Z', 'DatePulled': '2015-01-25T10:56:46.024Z', 'InExclusionPeriod': false, 'ListId': '550c2c44f4f17316b8dbf578', 'Name': 'Test_1261', 'actionValue': true, 'targetedCount': 1869663 } };
        scope.gridOptions.beforeSelectionChange(row);
        expect(scope.gridOptions.beforeSelectionChange).toBeTruthy();
      });
      it('it should call afterSelectionChange', function () {
        scope.gridOptions.afterSelectionChange();
        expect(scope.gridOptions.afterSelectionChange).toBeTruthy();

      });
    });
  });
})(window.app);