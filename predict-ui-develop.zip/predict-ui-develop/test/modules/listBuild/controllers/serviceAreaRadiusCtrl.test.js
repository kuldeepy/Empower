﻿(function () {
  'use strict';

  describe('serviceAreaRadiusCtrl', function () {
    var ctrl, scope, stepName, stepComplete, val, listState, listStateSvc, rootScope, go;
    beforeEach(function () {
      module('app');

      listStateSvc = {
        get: function () {
          return val;
        }
      };

      listState = {
        Id: 'abc123',
        RecipeId: 'ABC123',
        CurrentUIState: {
          CurrentLocationIndex: 0
        },
        LocationDescriptors: [{
          Type: 'Radius'
        }]

      };

      spyOn(listStateSvc, 'get').and.returnValue(listState);

      console.log(listState.LocationDescriptors[0]);
      angular.mock.inject(function ($rootScope, $controller) {
        scope = $rootScope.$new();
        rootScope = $rootScope;
        scope.initializeStep = function (stepN, stepC) { stepName = stepN; stepComplete = stepC; };

        go = jasmine.createSpy('go');
        spyOn(scope, 'initializeStep');
        spyOn(rootScope, '$broadcast').and.callThrough();
        ctrl = $controller('serviceAreaRadiusCtrl', {
          $scope: scope,
          listStateSvc: listStateSvc
        });
      });
    });


    it('check if serviceAreaRadiusCtrl exist and defined', function () {
      expect(ctrl).not.toBeUndefined();
    });

    it('initalize serviceAreaRadius step is called', function () {
      expect(scope.initializeStep).toHaveBeenCalledWith('serviceAreaRadius', true);
    });

    it('call radius tab on next', function () {
      rootScope.$broadcast('next', go);
      expect(go).toHaveBeenCalledWith('radius');
    });
  });
})(window.app);