﻿(function () {
  'use strict';

  describe('prioritizeCountTypeCtrl', function () {
    var scope, ctrl, listState, val, stepName, stepComplete;

    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $controller, listStateSvc) {
        listStateSvc = {
          get: function () {
            return val;
          }
        };

        listState = {
          'Id': 'abc123',
          'RecipeId': 'ABC123',
          'CurrentUIState': {
            'CurrentLocationIndex': 0
          }
        };

        spyOn(listStateSvc, 'get').and.returnValue(listState);
        scope = $rootScope.$new();
        scope.initializeStep = function (stepN, stepC) { stepName = stepN; stepComplete = stepC; };
        spyOn(scope, 'initializeStep');
        ctrl = $controller('prioritizeCountTypeCtrl', {
          $scope: scope,
          listStateSvc: listStateSvc
        });
      });
    });

    it('check controller exists', function () {
      expect(ctrl).not.toBeUndefined();
    });

    it('initalize prioritizeCountTypeCtrl step is called', function () {
      expect(scope.initializeStep).toHaveBeenCalledWith('prioritizeCountType', true);
    });

    it('should check for values if listState.ExcludeHoldouts is undefined', function () {
      expect(scope.controlGroupSelected).toEqual('Yes');
      expect(listState.ExcludeHoldouts).toBe(true);
    });

    it('should check for values if listState.DistributeByHousehold is undefined', function () {
      expect(scope.prioritizeCountTypeSelected).toEqual('Household');
      expect(listState.DistributeByHousehold).toBe(true);
    });

    it('check countTypeSelection method exists', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      scope.countTypeSelection();
      expect(scope.countTypeSelection).not.toBeUndefined();
    });

    it('check confirmControlGroupSelection method exist', function () {
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      scope.confirmControlGroupSelection();
      expect(scope.confirmControlGroupSelection).not.toBeUndefined();
    });

    it('check confirmControlGroupSelection get called if controlGroupSelection is Yes', function () {
      var controlGroupSelection = true;
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      scope.confirmControlGroupSelection(controlGroupSelection);
    });

    it('check confirmControlGroupSelection get called if controlGroupSelection is No', function () {
      var controlGroupSelection = false;
      scope.completeStep = function (val) { stepComplete = val; };
      spyOn(scope, 'completeStep').and.callThrough();
      scope.$digest();
      scope.confirmControlGroupSelection(controlGroupSelection);
    });

  });
})(window.app);