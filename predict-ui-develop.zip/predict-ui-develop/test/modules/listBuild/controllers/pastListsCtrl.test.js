﻿(function () {
  'use strict';

  describe('pastListCtrl', function () {

    var ctrl, scope, pastListSvc, def, marketingOption;

    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $controller, $q, listStateSvc, lookupSvc) {
        var pastListDataArray = [{ 'CanDisplay': true, 'DateCreated': '2015-03-10T20:41:32.8259044Z', 'DatePulled': '2015-03-10T20:42:31.462Z', 'InExclusionPeriod': false, 'ListId': '54ff5684030ba32e9c4156ae', 'Name': '1556', 'actionValue': 'Default' }, { 'CanDisplay': true, 'DateCreated': '2015-03-10T20:41:32.8259044Z', 'DatePulled': '2015-03-10T20:42:31.462Z', 'InExclusionPeriod': true, 'ListId': '54ff5685030ba32e9c2156av', 'ListRefId':'12345_666', 'Name': '1557', 'actionValue': 'Default' }];
        marketingOption = { 'Name': 'Direct Mail', 'Id': 1 };
        scope = $rootScope.$new();
        pastListSvc = {
          pastListData: function () {
            def = $q.defer();
            def.resolve(pastListDataArray);
            return def.promise;
          }
        };
        lookupSvc = {
          getLookupDataById: function () {
            def = $q.defer();
            def.resolve(marketingOption);
            return def.promise;
          }
        };
        spyOn(lookupSvc, 'getLookupDataById').and.callThrough();
        spyOn(pastListSvc, 'pastListData').and.callThrough();
        var list = { excludedList: ['1', '2'], ExcludedPastListIds: undefined, IncludedPastListIds: undefined };
        spyOn(listStateSvc, 'get').and.returnValue(list);
        scope.addListRefIdsToSelection = function (obj, item) { obj.push(item); };
        spyOn(scope, 'addListRefIdsToSelection').and.callThrough();
        ctrl = $controller('pastListsCtrl', {
          $scope: scope,
          pastListSvc: pastListSvc,
          listStateSvc: listStateSvc,
          lookupSvc: lookupSvc
        });
      });
    });

    it('exists', function () {
      expect(ctrl).not.toBeUndefined();
    });

    describe('when created', function () {

      it('it should get the pastLists', function () {
        scope.$digest();
        expect(marketingOption.Name).toBe('Direct Mail');
        expect(pastListSvc.pastListData).toHaveBeenCalled();
      });
      it('it should set the iui-table data', function () {
        expect(scope.controllerData.gridData).not.toBeUndefined();
      });
      it('it should test updateList', function () {
        var selectedValue = 'Exclude';
        scope.updateList(selectedValue);
        expect(scope.updateList).not.toBeUndefined();
      });
    });
  });
})(window.app);
