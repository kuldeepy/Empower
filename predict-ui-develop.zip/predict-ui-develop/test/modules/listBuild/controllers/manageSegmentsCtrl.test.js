(function() {
  'use strict';

  describe('manageSegmentsCtrl', function() {

    var ctrl, scope, sessionSvc, $rootScope, mostRecentCalculationSvc;

    beforeEach(function() {
      module('app');
      angular.mock.inject(function(_$rootScope_, $controller, listStateSvc) {
        $rootScope = _$rootScope_;

        sessionSvc = jasmine.createSpyObj('SessionSvc', ['get', 'set', 'clear']);
        mostRecentCalculationSvc = jasmine.createSpy();

        listStateSvc.set({
          'Id': '1',
          'LocationDescriptors': [],
          'FilterValueSelections': [],
          'ExcludedPastListIds': [],
          'Segments': [],
          'IsEditable': true,
          'IsTransient': true,
          'UseLocationLogic': true,
          'CurrentUIState': {
            'CurrentLocationIndex': -1,
            'hasVisited': {}
          }
        });
        listStateSvc.get().LocationDescriptors.push({
          serviceArea: true
        });

        scope = $rootScope.$new();
        scope.currentListState = listStateSvc.get();

        ctrl = $controller('manageSegmentsCtrl', {
          $scope: scope,
          sessionSvc: sessionSvc,
          mostRecentCalculation: mostRecentCalculationSvc
        });
      });
    });

    it('exists', function() {
      expect(ctrl).not.toBeUndefined();
    });

    describe('when created', function() {

      it('it should set the grid data', function() {
        expect(scope.controllerData.gridData).not.toBeUndefined();
      });

    });

    // need to write a better function using quick counts
    // describe('individual total', function () {
    //   it('should return ?', function () {
    //     expect(scope.individualTotal()).toBe('');
    //   });

    //   it('given segment should return individaul total', function () {
    //     var segmentName = 'my-segment';
    //     var totalCountForIndividual = 101;

    //     mostRecentCalculationSvc.and.returnValue([{
    //       segmentName: segmentName,
    //       totalCountForIndividual: totalCountForIndividual
    //     }]);

    //     expect(scope.individualTotal({ Name: segmentName })).toBe(totalCountForIndividual);
    //   });
    // });

    // describe('household total', function () {
    //   it('should return ?', function () {
    //     expect(scope.householdTotal()).toBe('');
    //   });

    //   it('given segment should return household total', function () {
    //     var segmentName = 'my-segment';
    //     var totalCountForHousehold = 2020;

    //     mostRecentCalculationSvc.and.returnValue([{
    //       segmentName: segmentName,
    //       totalCountForHousehold: totalCountForHousehold
    //     }]);

    //     expect(scope.householdTotal({ Name: segmentName })).toBe(totalCountForHousehold);
    //   });
    // });

    describe('given `next` event', function() {
      var go;

      beforeEach(function() {
        go = jasmine.createSpy('go');

        $rootScope.$broadcast('next', go);
      });

      it('should go to to `prioritizeCountType`', function() {
        expect(go).toHaveBeenCalledWith('prioritizeCountType');
      });
    });
  });
})(window.app);