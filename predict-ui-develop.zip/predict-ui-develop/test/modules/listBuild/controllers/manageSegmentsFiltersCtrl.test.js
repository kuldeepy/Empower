(function () {
  'use strict';

  describe('manageSegmentsFiltersCtrl', function () {

    var ctrl, $scope, $rootScope, listStateSvc, listState, recipeSvc;

    beforeEach(function () {
      module('app');

      listState = {
        Id: 'abc123',
        RecipeId: 'ABC123',
        FilterValueSelections: [{
          FilterName: 'Gender',
          ExcludeValues: [10]
        }, {
          FilterName: 'AgeRange',
          ExcludeValues: [200]
        }, {
          FilterName: 'ValidAddress',
          ExcludeValues: ['False']
        }],
        Segments: [{
          LocationIndicies: [],
          FilterValueSelections: [{ FilterName: 'Gender', ExcludeValues: [5] }]
        }],
        CurrentUIState: {


        }
      };

      listStateSvc = {
        get: jasmine.createSpy('listStateSvc#get')
      };

      listStateSvc.get.and.returnValue(listState);

      angular.mock.inject(function (_$rootScope_, $controller, $q, $httpBackend) {
        $rootScope = _$rootScope_;

        $scope = $rootScope.$new();

        recipeSvc = {
          getRecipe: jasmine.createSpy('recipeSvc#getRecipe')
        };
        recipeSvc.getRecipe.and.returnValue($q.when({
          Filters: [
            {
              FilterName: 'Gender',
              Values: [5, 10, 15, 20]
            }
          ]
        }));

        $httpBackend.when('GET', '/api/clients/undefined/orgs//filterTypes/filters')
        .respond({
          results: {
            filterTypeData: '{"AgeOfChildren":[{"_id":5901,"ChildrenAgeGroupMinVal":0,"ChildrenAgeGroupMaxVal":3,"Name":"0 - 3"}],"AgeRange":[{"_id":430,"AgeGroupMinVal":65,"AgeGroupMaxVal":66,"Name":"65 - 66"},{"_id":465,"AgeGroupMinVal":"","AgeGroupMaxVal":"","Name":"Unknown"}],"BeehiveCluster":[{"_id":1465,"Name":"Aging in Pairs","Value":23},{"_id":1500,"Name":"Alone Again and Aging","Value":30}],"DateRangeEncounter":[{"_id":1,"From":"2010","To":"2014"}],"DwellingType":[{"_id":5953,"Name":"Marginal Multi-Family"}],"EducationLevel":[{"_id":5504,"Name":"Bachelor Degree"}],"ERUtilization":[{"_id":1,"Name":"Emergency"}],"FinancialClass":[{"_id":205,"Name":"Blue Cross / Blue Shield","Value":9010}],"Gender":[{"_id":310,"Name":"Female","Value":"F"}],"HomeOwnership":[{"_id":5302,"Name":"Extremely Likely Home Owner"}],"HomeValue":[{"_id":5401,"HomeValueMinVal":0,"HomeValueMaxVal":49999,"Name":"0 to 49,999"}],"HouseholdIncomeGroup":[{"_id":805,"IncomeGroupMinVal":"","IncomeGroupMaxVal":"","Name":"0 - 14,999"}],"MaritalStatus":[{"_id":510,"Name":"Married","Value":"M"}],"MedicalServiceVisits":[{"_id":"0","Name":"0 Visits"}],"Occupation":[{"_id":5128,"Name":"Accountants/CPA"}],"PatientType":[{"_id":1005,"Name":"Inpatient"}],"PayerType":[{"_id":105,"Name":"Medicare-Inferred"}],"PersonType":[{"_id":25,"Name":"Family Member of Patients","Value":"F"}],"PhysicianType":[{"_id":1810,"Name":"Admitting"}],"PrimaryLanguage":[{"_id":4104,"Name":"Afrikaans"}],"Race":[{"_id":565,"Name":"Asian"}],"Religion":[],"Specialty":[{"_id":34,"Name":"Hospitalist","Value":"HPL"}],"WealthLevel":[{"_id":5601,"WealthLevelMinVal":0,"WealthLevelMaxVal":9,"Name":"First/Bottom Decile (0-9th Percentile)"}],"RecipeScore":[],"HealthSystemEmployee":[{"_id":"true","Name":"Yes"}],"DonateToCharity":[{"_id":"true","Name":"Yes"}],"ValidEmail":[{"_id":"true","Name":"Yes"}],"ValidAddress":[{"_id":"true","Name":"Yes"}]}'
          }
        });
        $rootScope.$digest();

        ctrl = $controller('manageSegmentsFiltersCtrl', {
          $scope: $scope,
          listStateSvc: listStateSvc,
          recipeSvc: recipeSvc
        });

        $httpBackend.flush();
      });
    });

    describe('when created', function () {

      it('should select first segment', function () {
        expect($scope.selectedSegment).toBe(listState.Segments[0]);
      });

      it('should have correct listFilterValueSelections', function () {
        expect($scope.listFilterValueSelections).toBe(listState.Segments[0].FilterValueSelections);
      });

      it('should have correct parentFilterValueSelections', function (done) {
        var self = this;

        $scope.parentFilterValueSelections.then(function (parentFilterValueSelections) {
          expect(parentFilterValueSelections).toEqual([
            { FilterName: 'Gender', Values: ['5', '15', '20'] },
            { FilterName: 'AgeRange', Values: ['430', '465'] },
            { FilterName: 'ValidAddress', Values: ['true'] }
          ]);
        })
        .then(done, function (err) {
          self.fail(err);
          done();
        });

        $rootScope.$digest();

      });

    });

  });
})();