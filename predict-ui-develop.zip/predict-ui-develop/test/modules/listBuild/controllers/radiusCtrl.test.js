﻿(function () {
  'use strict';

  describe('radiusCtrl', function () {
    var ctrl, scope, stepName, stepComplete, val, listState, rootScope, go, zipCodes, def, q, geographiesLookupSvc, locationSvc, locations, geocodeResponse, geocodeSvc, facilities, sessionSvc, locationsJSON;
    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $q, $controller, listStateSvc) {
        listStateSvc = {
          get: function () {
            return val;
          }
        };

        listState = {
          'Id': 'abc123',
          'RecipeId': 'ABC123',
          'CurrentUIState': {
            'CurrentLocationIndex': 0
          },
          'LocationDescriptors': [
            {
              'Type': 'Radius',
              'LocationId': 236,
              'Name': 'Memorial Hospital Central',
              'Address': {
                'Address1': '1400 E BOULDER ST',
                'City': 'COLORADO SPRINGS',
                'State': 'CO',
                'Zip': '80909',
                'GeoJson': {
                  'Type': 'Point',
                  'Coordinates': [
                    '-104.8',
                    '38.8388'
                  ]
                }
              },
              'RadiusDescriptors': [
                {
                  'LocationName': 'Mary Lou Beshears Breast Care Center',
                  'LocationId': 236,
                  'Address': {
                    'Address1': '175 S UNION BLVD STE 340',
                    'City': 'COLORADO SPRINGS',
                    'State': 'CO',
                    'Zip': '80910',
                    'GeoJson': {
                      'Type': 'Point',
                      'Coordinates': [
                        '-104.8',
                        '38.8388'
                      ]
                    }
                  },
                  'RadiusInMiles': 12,
                  'AdditionalZipCodeIds': [

                  ],
                  'ExcludedZipCodeIds': [

                  ],
                  'RadiusZipCodeIds': [

                  ],
                  'AllLocations': [
                    {
                      'Id': 'customAddress',
                      'Name': 'Custom Address'
                    },
                    {
                      'Id': 236,
                      'Name': 'Memorial Hospital'
                    },
                    {
                      'Id': 2000,
                      'Name': 'Vascular and Endovascular Clinic'
                    }
                  ],
                  'SelectedLocationId': 236,
                  'IsCustomAddress': false
                },
                {
                  'LocationId': 'customAddress',
                  'Address': {
                    'Address1': '1400 E',
                    'City': 'COLORADO',
                    'State': 'CO',
                    'Zip': '80909',
                    'GeoJson': {
                      'Type': 'Point',
                      'Coordinates': [
                        '-104.8',
                        '38.8388'
                      ]
                    }
                  },
                  'RadiusInMiles': 12,
                  'AdditionalZipCodeIds': [

                  ],
                  'ExcludedZipCodeIds': [

                  ],
                  'RadiusZipCodeIds': [

                  ],
                  'AllLocations': [
                    {
                      'Id': 'customAddress',
                      'Name': 'Custom Address'
                    },
                    {
                      'Id': 236,
                      'Name': 'Memorial Hospital'
                    },
                    {
                      'Id': 2000,
                      'Name': 'Vascular and Endovascular Clinic'
                    }
                  ],
                  'SelectedLocationId': 'customAddress',
                  'IsCustomAddress': true
                },
                {
                  'LocationId': 2000,
                  'Address': {
                    'Address1': '10010 KENNERLY RD',
                    'City': 'SAINT LOUIS',
                    'State': 'MO',
                    'Zip': '63128',
                    'GeoJson': {
                      'Type': 'Point',
                      'Coordinates': [
                        '-90.2539836',
                        '38.66486580'
                      ]
                    }
                  },
                  'RadiusInMiles': 50,
                  'AdditionalZipCodeIds': [

                  ],
                  'ExcludedZipCodeIds': [

                  ],
                  'RadiusZipCodeIds': [

                  ],
                  'AllLocations': [
                    {
                      'Id': 'customAddress',
                      'Name': 'Custom Address'
                    },
                    {
                      'Id': 236,
                      'Name': 'Memorial Hospital'
                    },
                    {
                      'Id': 2000,
                      'Name': 'Vascular and Endovascular Clinic'
                    }
                  ],
                  'SelectedLocationId': 2000,
                  'IsCustomAddress': false
                }
              ],
              'PrimaryServiceAreaZipCodes': [
                '80106',
                '80132'
              ],
              'SecondaryServiceAreaZipCodes': [
                '80813',
                '80814'
              ],
              'TertiaryServiceAreaZipCodes': [
                '80101',
                '81039'
              ],
              'SelectedZipCodes': [
              ],
              'UsePrimaryServiceArea': true,
              'UseSecondaryServiceArea': true,
              'UseTertiaryServiceArea': true
            }
          ]
        };

        zipCodes = [
          '80106',
          '80132',
          '80813',
          '80814',
          '80101',
          '81039'
        ];

        locations = [
          {
            'Id': 236,
            'Name': 'Memorial Hospital Central',
            'PrimaryServiceAreaZipCodes': [
                '80106',
                '80132'
              ],
              'SecondaryServiceAreaZipCodes': [
                '80813',
                '80814'
              ],
              'TertiaryServiceAreaZipCodes': [
                '80101',
                '81039'
              ],
              'ClientKey': 'southeast',
              'OrgKey': 'section1',
              'Address': {
                'Address1': '1400 E BOULDER ST',
                'Address2': '',
                'City': 'COLORADO SPRINGS',
                'State': 'CO',
                'Zip': '80909',
                'GeoJson': {
                  'Type': 'Point',
                  'Coordinates': [
                    '-104.8',
                    '38.8388'
                  ]
                }
              },
              'AvailableZipCodes': [
                '80106',
                '80132',
                '80813',
                '80814',
                '80101',
                '81039'
              ],
              'RefId': 'Memorial Hospital'
            }
          ];

        facilities = '{\"Facilities\" : [{\"Id\": 2000.0,\"RefId\": \"STANTHONY MED\",\"Name\": \"Vascular and Endovascular Clinic\",\"LocationId\": 236,\"PrimaryServiceAreaZipCodes\": [],\"SecondaryServiceAreaZipCodes\": [],\"TertiaryServiceAreaZipCodes\": [],\"ClientKey\": \"southeast\",\"OrgKey\": \"section1\",\"Address\": {\"Address1\": \"10010 KENNERLY RD\",\"Address2\": \"\",\"City\": \"SAINT LOUIS\",\"State\": \"MO\",\"Zip\": \"63128\",\"GeoJson\": {\"Type\": \"Point\",\"Coordinates\": [\"-90.2539836\",\"38.66486580\"]}},\"AvailableZipCodes\": []}]}';
        locationsJSON = '[{"Id":236,"Name":"Memorial Hospital Central","Address":{"Address1":"1400 E BOULDER ST","Address2":"","City":"COLORADO SPRINGS","State":"CO","Zip":"80909","GeoJson":{"Type":"Point","Coordinates":["-104.8","38.8388"]}},"ClientKey":"southeast","OrgKey":"section1","AvailableZipCodes":["80106","80132","80133","80808","80809","80817","80819","80829","80831","80832"],"PrimaryServiceAreaZipCodes":["80106","80132","80133","80808","80809","80817","80819","80829","80831","80832"],"SecondaryServiceAreaZipCodes":["80813","80814","80816","80860","80863","80866","81001","81002","81003","81004"],"TertiaryServiceAreaZipCodes":["80101","80107","80117","80420","80421","80432"],"OutsideServiceAreaZipCodes":null,"RefId":"Memorial Hospital"}]';
        geocodeResponse = [
          {
            'coordinates': {
              'lat': '19.3162013',
              'lng': '-99.12148100000002'
            },
            'resolvedAddress': 'Calle G, Alianza Popular Revolucionaria, 04800 Ciudad de México, D.F., Mexico',
            'success': true
          }
        ];

        q = $q;
        spyOn(listStateSvc, 'get').and.returnValue(listState);

        geographiesLookupSvc = {
          getZipCodesByLocationRadius: function () {
            def = q.defer();
            def.resolve(zipCodes);
            return def.promise;
          }
        };
        locationSvc = {
          listLocations: function () {
            def = q.defer();
            def.resolve(locations);
            return def.promise;
          }
        };
        geocodeSvc = {
          geocodeAddress: function () {
            return val;
          }
        };
        sessionSvc = {
          get: function () {
            return val;
          }
        };
        spyOn(geographiesLookupSvc, 'getZipCodesByLocationRadius').and.callThrough();
        spyOn(locationSvc, 'listLocations').and.callThrough();
        spyOn(geocodeSvc, 'geocodeAddress').and.returnValue(geocodeResponse);
        spyOn(sessionSvc, 'get').and.callFake(function (input) {
          if (input === 'selectLocation.locations'){
            return locationsJSON;
          }
          else {
            return facilities;
          }
        });

        scope = $rootScope.$new();
        rootScope = $rootScope;
        scope.radiiForm = {};
        scope.radiiForm.$valid = true;
        scope.completeStep = function (val) { stepComplete = val; };
        spyOn(scope, 'completeStep').and.callThrough();
        scope.initializeStep = function (stepN, stepC) { stepName = stepN; stepComplete = stepC; };
        go = jasmine.createSpy('go');
        spyOn(scope, 'initializeStep');
        spyOn(rootScope, '$broadcast').and.callThrough();
        ctrl = $controller('radiusCtrl', {
          $scope: scope,
          listStateSvc: listStateSvc,
          geographiesLookupSvc: geographiesLookupSvc,
          locationSvc: locationSvc,
          geocodeSvc: geocodeSvc,
          sessionSvc: sessionSvc
        });
      });
    });

    it('it should contain a method initialize radius ', function () {
      expect(scope.radii).not.toBeUndefined();
    });

    it('check if radiusCtrl exist and defined', function () {
      expect(ctrl).not.toBeUndefined();
    });

    it('it should Initialize the Locations', function () {
      expect(scope.locations).toEqual(listState.LocationDescriptors);
    });

    it('Check location change', function () {
      scope.locationChange(listState.LocationDescriptors[0].RadiusDescriptors[0], 2000);
      scope.locationChange(listState.LocationDescriptors[0].RadiusDescriptors[1], 236);
    });

    it('initalize radiusCtrl step is called', function () {
      expect(scope.initializeStep).toHaveBeenCalledWith('radius', false);
    });

    it('check radius miles updated', function () {
      scope.radiusMilesUpdated(listState.LocationDescriptors[0].RadiusDescriptors[0], true);
    });

    it('check radius increment', function () {
      scope.radiusIncrement(listState.LocationDescriptors[0].RadiusDescriptors[0], 10);
      scope.radiusIncrement(listState.LocationDescriptors[0].RadiusDescriptors[2], 10);
    });

    it('check radius decrement', function () {
      scope.radiusDecrement(listState.LocationDescriptors[0].RadiusDescriptors[0], 10);
    });

    it('add another radius', function () {
      scope.addAnotherRadius(listState.LocationDescriptors[0].RadiusDescriptors[0]);
    });

    it('if custom address changed', function () {
      scope.addressChanged(listState.LocationDescriptors[0].RadiusDescriptors[0]);
    });

    it('check geocode address', function () {
      scope.geocodeRadiusAddress(listState.LocationDescriptors[0].RadiusDescriptors[0]);
    });

    it('edit custom address', function () {
      scope.editCustomAddress(listState.LocationDescriptors[0].RadiusDescriptors[0]);
    });

    it('remove radius', function () {
      scope.removeRadius(listState.LocationDescriptors[0].RadiusDescriptors[0]);
    });

    it('apply radius in miles to all radius', function () {
      listState.LocationDescriptors[0].RadiusDescriptors[0].ApplyToAll = true;
      scope.applyRadiusInMilesToAll(listState.LocationDescriptors[0].RadiusDescriptors[0]);
      expect(listState.LocationDescriptors[0].RadiusDescriptors[2].RadiusInMiles).toEqual(listState.LocationDescriptors[0].RadiusDescriptors[0].RadiusInMiles);
    });

    it('check is baseLocation', function () {
      scope.isBaseLocation(236);
    });

    it('should get the Base Location Name', function () {
      expect(listState.LocationDescriptors[0].Name).toBe('Memorial Hospital Central');
    });

    it('should get the Radius Location Name', function () {
      expect(listState.LocationDescriptors[0].RadiusDescriptors[0].LocationName).toBe('Mary Lou Beshears Breast Care Center');
    });

    it('should return customAddress if custom address is used', function () {
      expect(listState.LocationDescriptors[0].RadiusDescriptors[1].LocationId).toBe('customAddress');
    });

    it('length of radius', function () {
      expect(scope.radiiLength).toEqual(scope.radii.length);
    });

    it('call radiusCtrl tab on previous', function () {
      rootScope.$broadcast('previous', go);
      expect(go).toHaveBeenCalledWith('serviceAreaRadius');
    });
  });
})(window.app);
