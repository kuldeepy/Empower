﻿(function() {
  'use strict';

  describe('prioritizeCtrl', function() {

    var ctrl, scope, listStateSvc, distributionSvc, svcDef;

    var distributionData = {
      'AvailableCount': 45,
      'DesiredCount': 45,
      'Segments': [{
        'Name': 'New Segment',
        'AvailableCount': 23,
        'DesiredCount': 23,
        'PersonTypeDistributions': [{
          'PersonTypeId': 5,
          'PersonTypeName': 'Patients',
          'AvailableCount': 1,
          'DesiredCount': 1,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0CY'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0CZ'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0D0'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0D1'
          }]
        }, {
          'PersonTypeId': 10,
          'PersonTypeName': 'New Movers',
          'AvailableCount': 4,
          'DesiredCount': 4,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0DA'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 2,
            'DesiredCount': 2,
            '$$hashKey': '0DB'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0DC'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0DD'
          }]
        }, {
          'PersonTypeId': 15,
          'PersonTypeName': 'Prospects',
          'AvailableCount': 4,
          'DesiredCount': 4,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0DM'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0DN'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0DO'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 3,
            'DesiredCount': 3,
            '$$hashKey': '0DP'
          }]
        }, {
          'PersonTypeId': 20,
          'PersonTypeName': 'Qualified Prospects',
          'AvailableCount': 6,
          'DesiredCount': 6,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0DY'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 2,
            'DesiredCount': 2,
            '$$hashKey': '0DZ'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 2,
            'DesiredCount': 2,
            '$$hashKey': '0E0'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 2,
            'DesiredCount': 2,
            '$$hashKey': '0E1'
          }]
        }, {
          'PersonTypeId': 25,
          'PersonTypeName': 'Family Member of Patients',
          'AvailableCount': 8,
          'DesiredCount': 8,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 2,
            'DesiredCount': 2,
            '$$hashKey': '0EA'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 3,
            'DesiredCount': 3,
            '$$hashKey': '0EB'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0EC'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 2,
            'DesiredCount': 2,
            '$$hashKey': '0ED'
          }]
        }],
        '$$hashKey': '0CE'
      }, {
        'Name': 'Non-segmented List',
        'AvailableCount': 16,
        'DesiredCount': 16,
        'PersonTypeDistributions': [{
          'PersonTypeId': 5,
          'PersonTypeName': 'Patients',
          'AvailableCount': 3,
          'DesiredCount': 3,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0EW'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0EX'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0EY'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0EZ'
          }]
        }, {
          'PersonTypeId': 10,
          'PersonTypeName': 'New Movers',
          'AvailableCount': 2,
          'DesiredCount': 2,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0F8'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0F9'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0FA'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0FB'
          }]
        }, {
          'PersonTypeId': 15,
          'PersonTypeName': 'Prospects',
          'AvailableCount': 3,
          'DesiredCount': 3,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0FK'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0FL'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0FM'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0FN'
          }]
        }, {
          'PersonTypeId': 20,
          'PersonTypeName': 'Qualified Prospects',
          'AvailableCount': 3,
          'DesiredCount': 3,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0FW'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0FX'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0FY'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0FZ'
          }]
        }, {
          'PersonTypeId': 25,
          'PersonTypeName': 'Family Member of Patients',
          'AvailableCount': 5,
          'DesiredCount': 5,
          'ScoreDistributions': [{
            'Score': 0,
            'ScoreName': 'Behavior',
            'AvailableCount': 1,
            'DesiredCount': 1,
            '$$hashKey': '0G8'
          }, {
            'Score': 1,
            'ScoreName': 'Best',
            'AvailableCount': 2,
            'DesiredCount': 2,
            '$$hashKey': '0G9'
          }, {
            'Score': 2,
            'ScoreName': 'Better',
            'AvailableCount': 2,
            'DesiredCount': 2,
            '$$hashKey': '0GA'
          }, {
            'Score': 3,
            'ScoreName': 'Good',
            'AvailableCount': 0,
            'DesiredCount': 0,
            '$$hashKey': '0GB'
          }]
        }],
        '$$hashKey': '0CF'
      }],
      'SeedListCount': 6
    };
    var listState = {
      'Distribution': undefined
    };
    beforeEach(function() {
      module('app', function($httpProvider) {
        $httpProvider.interceptors.pop('authInterceptor');
        $httpProvider.interceptors.pop('errorInterceptor');

        listStateSvc = jasmine.createSpyObj('listStateSvc', ['get']);
        listStateSvc.get.and.returnValue(listState);

        // distributionSvc = jasmine.createSpyObj('distributionSvc', ['createDistribution']);
        // distributionSvc.createDistribution.and.returnValue(distributionData);

      });
    });
    beforeEach(inject(function($rootScope, $controller, $q) {
      scope = $rootScope.$new();

      distributionSvc = {
        createDistribution: function() {
          svcDef = $q.defer();
          return svcDef.promise;
        }
      };
      spyOn(distributionSvc, 'createDistribution').and.callThrough();
      ctrl = $controller('prioritizeCtrl', {
        $scope: scope,
        listStateSvc: listStateSvc,
        distributionSvc: distributionSvc
      });

      svcDef.resolve(distributionData);
      scope.$digest();

    }));
    // Morgan TO DO : write a proper test
    // it('exists', function() {
    //   expect(ctrl).not.toBeUndefined();
    // });
    // it('distributionData Exists', function() {
    //   expect(scope.distribution).not.toBeUndefined();
    // });

  });
})(window.app);