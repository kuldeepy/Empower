(function (app) {
	'use strict';
	
	var listsResponse = {
		'href': '/predict/v1/clients/southeast/orgs/section1/lists',
		'results': {
			'Lists': [
				{
					'Name': 'NateList',
					'OrgId': '53626585c597cf5eeea77032',
					'ClientKey': null,
					'RecipeId': '23000',
					'LocationDescriptors': [
						{
							'Type': null,
							'LocationId': '53713b6e1b3054d3585532a4',
							'Address': {
								'Address1': '3600 Gates Blvd',
								'City': 'Port Arthur',
								'State': 'TX',
								'Zip': '77642',
								'GeoJson': {
									'Type': 'Point',
									'Coordinates': [
										'29.909283',
										'-93.923906'
									]
								}
							},
							'RadiusInMiles': null,
							'PrimaryServiceAreaZipCodes': null,
							'SecondaryServiceAreaZipCodes': null,
							'TertiaryServiceAreaZipCodes': null
						}
					],
					'FilterValueSelections': null,
					'Segments': [],
					'CurrentUIState': {
						'LocationDescriptorIndex': 0,
						'currentLocationId': '53713b6e1b3054d3585532a4',
						'LocationType': 'LocationRadius',
						'RadiusLocationType': '',
						'RadiusMiles': '',
						'RadiusLocationId': '',
						'RadiusAddress': '',
						'RadiusAddressValidated': false,
						'RadiusAddressCoordinates': '',
						'currentStep': 'viewMap',
						'isComplete': false
					},
					'CreatedBy': 'user2@southeast.com',
					'CreatedOn': '2014-06-09T16:09:15.9467254Z',
					'UpdatedBy': null,
					'UpdatedOn': null,
					'Id': '5395dc2bf4f1720da8922cb1'
				},
				{
					'Name': 'NateList',
					'OrgId': '53626585c597cf5eeea77032',
					'ClientKey': null,
					'RecipeId': '23000',
					'LocationDescriptors': [
						{
							'Type': null,
							'LocationId': '53713b6e1b3054d3585532a4',
							'Address': {
								'Address1': '3600 Gates Blvd',
								'City': 'Port Arthur',
								'State': 'TX',
								'Zip': '77642',
								'GeoJson': {
									'Type': 'Point',
									'Coordinates': [
										'29.909283',
										'-93.923906'
									]
								}
							},
							'RadiusInMiles': null,
							'PrimaryServiceAreaZipCodes': null,
							'SecondaryServiceAreaZipCodes': null,
							'TertiaryServiceAreaZipCodes': null
						}
					],
					'FilterValueSelections': null,
					'Segments': [],
					'CurrentUIState': {
						'LocationDescriptorIndex': 0,
						'currentLocationId': '53713b6e1b3054d3585532a4',
						'LocationType': 'LocationRadius',
						'RadiusLocationType': '',
						'RadiusMiles': '',
						'RadiusLocationId': '',
						'RadiusAddress': '',
						'RadiusAddressValidated': false,
						'RadiusAddressCoordinates': '',
						'currentStep': 'viewMap',
						'isComplete': false
					},
					'CreatedBy': 'user2@southeast.com',
					'CreatedOn': '2014-06-09T16:26:05.5625454Z',
					'UpdatedBy': null,
					'UpdatedOn': null,
					'Id': '5395e01df4f1720da8922cb2'
				},
				{
					'Name': 'NateList3',
					'OrgId': '53626585c597cf5eeea77032',
					'ClientKey': null,
					'RecipeId': '33000',
					'LocationDescriptors': [
						{
							'Type': null,
							'LocationId': '53713b6e1b3054d3585532a3',
							'Address': {
								'Address1': '455 St. Michaels Dr.',
								'City': 'Santa Fe',
								'State': 'NM',
								'Zip': '87505',
								'GeoJson': {
									'Type': 'Point',
									'Coordinates': [
										'35.659811',
										'-105.945804'
									]
								}
							},
							'RadiusInMiles': null,
							'PrimaryServiceAreaZipCodes': null,
							'SecondaryServiceAreaZipCodes': null,
							'TertiaryServiceAreaZipCodes': null
						}
					],
					'FilterValueSelections': null,
					'Segments': [],
					'CurrentUIState': {
						'LocationDescriptorIndex': 0,
						'currentLocationId': '53713b6e1b3054d3585532a3',
						'LocationType': 'LocationServiceArea',
						'currentStep': 'serviceArea',
						'isComplete': false
					},
					'CreatedBy': 'user2@southeast.com',
					'CreatedOn': '2014-06-09T19:23:06.9715612Z',
					'UpdatedBy': null,
					'UpdatedOn': null,
					'Id': '5396099af4f1720cc0c8812d'
				}
			],
			'Message': null,
			'ExceptionMessage': null,
			'StackTrace': null
		}
	
	};
	var listStateResponse = {
		'Name': 'NateList3',
		'OrgId': '53626585c597cf5eeea77032',
		'ClientKey': 'southeast',
		'RecipeId': '33000',
		'LocationDescriptors': [
			{
				'Name': 'abc',
				'LocationId': '53713b6e1b3054d3585532a3',
				'Address': {
					'Address1': '455 St. Michaels Dr.',
					'City': 'Santa Fe',
					'State': 'NM',
					'Zip': '87505',
					'GeoJson': {
						'Type': 'Point',
						'Coordinates': [
							'35.659811',
							'-105.945804'
						]
					}
				},
				'RadiusInMiles': '1000',
				'PrimaryServiceAreaZipCodes': '531',
				'SecondaryServiceAreaZipCodes': '1521',
				'TertiaryServiceAreaZipCodes': '456'
			}
		],
		'FilterValueSelections': null,
		'Segments': [],
		'CurrentUIState': {
			'LocationDescriptorIndex': 0,
			'currentLocationId': '53713b6e1b3054d3585532a3',
			'LocationType': 'LocationServiceArea',
			'currentStep': 'serviceArea',
			'isComplete': false,
			'hasVisited': {'geographiesSummary':'10'}
		},
		'CreatedBy': 'user2@southeast.com',
		'CreatedOn': '2014-06-09T19:23:06.9715612Z',
		'UpdatedBy': null,
		'UpdatedOn': null,
		'Id': '5396099af4f1720cc0c8812d'
	};


	describe('listBuildCtrl', function() {

		describe('cancel', function () {
			var scope, ctrl, rootScope, location, modal, createController, modalResult, httpBackend, listSvc, listStateService;

			beforeEach(function (done) {
				
				var self = this;

				module('app', function ($httpProvider, $provide) {
					//remove auth interceptor for testing since it interferes with tokens
					$httpProvider.interceptors.pop('authInterceptor');
					$httpProvider.interceptors.pop('errorInterceptor');
					$httpProvider.interceptors.pop('requestLogInterceptor');

					//var sessionServiceSpy = jasmine.createSpyObj('sessionSvc', ['set', 'get', 'clear']);
					//$provide.value('sessionSvc', sessionServiceSpy);

					listStateService = jasmine.createSpyObj('listStateSvc', ['clear', 'set', 'get', 'isLocationDefined']);
					listStateService.get.and.returnValue(listStateResponse);
					$provide.value('listStateSvc', listStateService);

				});
				app.routeParams = ['foo'];
				angular.mock.inject(function($rootScope, $location, $q, $controller, $httpBackend) {
					location = $location;
					rootScope = $rootScope;
					httpBackend = $httpBackend;

					scope = $rootScope.$new();

					$httpBackend.whenGET('/modules/listBuild/Views/summary.html').respond(200, '');
					$httpBackend.whenPOST('/api/clients/undefined/orgs//calculation').respond(200, '');
					$httpBackend.expectGET('/api/clients/undefined/listclients').respond(200, '');
					modalResult = $q.defer();

					listSvc = jasmine.createSpyObj('listSvc', [ 'getList' ]);

					var listResponseDeferred = $q.defer();
					listResponseDeferred.resolve(listsResponse);

					listSvc.getList.and.returnValue(listResponseDeferred.promise);

					

					modal = jasmine.createSpyObj('$modal', [ 'open' ]);
					modal.open.and.returnValue({ result: modalResult.promise });

					createController = function () {
						return $controller('listBuildCtrl', {
							'$scope': scope,
							'$location': location,
							'$modal': modal,
							'listSvc': listSvc
						});
					};

					ctrl = createController();
					scope.loading
						.then(function () {
							spyOn(scope, 'close');
						})
						.catch(function (err) {
							self.fail(err);
						})
						.finally(function () {
							done();
						});

					rootScope.$apply();
				});
			});

			it('should open modal', function () {
				scope.steps=[[]];
				scope.confirmCancel();
				expect(modal.open).toHaveBeenCalled();
			});

			it('should call scope.close when resolved', function (done) {
				scope.confirmCancel();

				setTimeout(function () {
					modalResult.resolve();
					scope.$apply();

					expect(scope.close).toHaveBeenCalled();

					done();
				}, 0);
			});

			it('should not call scope.close when rejected', function (done) {
				scope.confirmCancel();

				setTimeout(function () {
					modalResult.reject();
					scope.$apply();

					expect(scope.close).not.toHaveBeenCalled();
					done();
				});
			});
		});
	});
})(window.app);