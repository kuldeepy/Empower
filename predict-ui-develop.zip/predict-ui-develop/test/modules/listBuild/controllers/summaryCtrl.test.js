﻿(function () {
  'use strict';

  describe('summaryCtrl', function () {
    var ctrl, scope, stepName, stepComplete, listStateSvc, listState, val;
    beforeEach(function () {
      module('app');
      listStateSvc = {
        get: function () {
          return val;
        }
      };
      listState = {
        Id: '55b09820f4f1730460e79f2e',
        PullDate: '2015-07-22T09:35:46.356Z'
      };
      spyOn(listStateSvc, 'get').and.returnValue(listState);
      angular.mock.inject(function ($rootScope, $controller, $q) {
        scope = $rootScope.$new();
        scope.loading = $q.when();
        scope.initializeStep = function (stepN, stepC) { stepName = stepN; stepComplete = stepC; };
        spyOn(scope, 'initializeStep');
        ctrl = $controller('summaryCtrl', {
          $scope: scope,
          listStateSvc: listStateSvc
        });
      });
    });
    it('check if summaryCtrl  exist and defined', function () {
      expect(ctrl).not.toBeUndefined();
    });

    it('initalize summary step is called', function () {
      scope.$apply();
      expect(scope.initializeStep).toHaveBeenCalledWith('summary', true);
    });
  });
})(window.app);