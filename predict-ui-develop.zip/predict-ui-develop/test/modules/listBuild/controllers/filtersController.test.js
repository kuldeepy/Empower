﻿(function () {
	'use strict';

	describe('Filter Controller Test', function () {
		var $compile, $rootScope, ctrl, scope, filterTypeSvc, listStateSvc, listState, def, data, q;
		listState = {
			'CurrentUIState': {},
			'RecipeId': 1000,
			'LocationDescriptors': [{
				'Name': 'East Side',
				'Type': 'LocationServiceArea',
				'LocationId': '53713b6e1b3054d3585532a2',
				'Address': null,
				'RadiusInMiles': null,
				'PrimaryArea': true,
				'SecondaryArea': false,
				'TertiaryArea': false,
				'PrimaryServiceAreaZipCodes':
				[
					'71834',
					'71837',
					'71854',
					'75501',
					'75503'
				]
			}]
		};
		beforeEach(function () {
			module('app', function ($httpProvider, $provide) {
				//remove auth interceptor for testing since it interferes with tokens
				$httpProvider.interceptors.pop('authInterceptor');
				$httpProvider.interceptors.pop('errorInterceptor');

				var filterTypeSvc = jasmine.createSpyObj('filterTypeSvc', ['loadFilterTypeData']);
				//userContextServiceSpy.getApiClientKey.and.returnValue('system');
				$provide.value('filterTypeSvc', filterTypeSvc);

				listStateSvc = jasmine.createSpyObj('listStateSvc', ['get']);
				listStateSvc.get.and.returnValue(listState);

			});

			inject(function ($q, _$compile_, _$rootScope_, $controller) {
				q = $q;
				$compile = _$compile_;
				$rootScope = _$rootScope_;
				scope = _$rootScope_.$new();
				data = { Filters: [{ 'Filtername': 'gender', 'Values': 'M' }, { 'Filtername': 'persontype', 'Values': 'C' }] };
				var recipeService = {
					getRecipe: function () {
						def = q.defer();
						def.resolve(data);
						return def.promise;
					}
				};
				spyOn(recipeService, 'getRecipe').and.callThrough();
				ctrl = $controller('filtersController', {
					$scope: scope,
					filterTypeSvc: filterTypeSvc,
					listStateSvc: listStateSvc,
					recipeSvc: recipeService
				});

			});

		});
		it('Controller to be defined', function () {
			expect(ctrl).not.toBeUndefined();
		});
		it('loadCurrentRecipe function should be defined', function () {
			expect(scope.loadCurrentRecipe).not.toBeUndefined();
		});
		it('Load current Recipe', function () {
			scope.loadCurrentRecipe();
			$rootScope.$apply();
			expect(scope.filterData).toBeTruthy();
		});
	});

})(window.app);
