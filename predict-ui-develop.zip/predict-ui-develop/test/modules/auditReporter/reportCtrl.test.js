﻿(function () {
	'use strict';

	describe('reportCtrl', function () {
		var http, ctrl, scope;
		beforeEach(function () {
			module('app', function ($httpProvider, $provide) {
				//remove auth interceptor for testing since it interferes with tokens
				$httpProvider.interceptors.pop('authInterceptor');
				$httpProvider.interceptors.pop('errorInterceptor');

				var userContextServiceSpy = jasmine.createSpyObj('userContextSvc', ['getApiClientKey', 'getOrgKey', 'getClientKey']);
				userContextServiceSpy.getApiClientKey.and.returnValue('southeast');
				userContextServiceSpy.getOrgKey.and.returnValue('section1');
				userContextServiceSpy.getClientKey.and.returnValue('southeast');
				$provide.value('userContextSvc', userContextServiceSpy);

			});

			inject(function ($httpBackend, _$rootScope_, $controller) {
				http = $httpBackend;
				scope = _$rootScope_.$new();
				ctrl = $controller('reportCtrl', {
					$scope: scope
				});

			});

		});
		it('report controller should exist', function () {
			expect(ctrl).not.toBeUndefined();
		});
		it('reportHandler function should exist', function () {
			expect(scope.reportHandler).not.toBeUndefined();
		});
		it('exportAuditList function should exist', function () {
			expect(scope.exportAuditList).not.toBeUndefined();
		});
		it('exportAuditList to have been called', function () {
			spyOn(scope, 'exportAuditList');
			scope.startDate = '01/01/2010';
			scope.endDate = '01/01/2014';
			scope.reportHandler();
			expect(scope.exportAuditList).toHaveBeenCalled();
		});
	});
})(window.app);