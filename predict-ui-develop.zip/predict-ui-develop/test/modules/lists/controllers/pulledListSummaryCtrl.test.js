﻿
(function () {
  'use strict';

  describe('pulledListSummaryCtrl', function () {
    var ctrl, scope, q, clientKey, orgKey, listState, data, calculationSvc;

    beforeEach(function () {
      module('app');
      angular.mock.inject(function ($rootScope, $controller, $q, listStateSvc, userContextSvc) {
        clientKey = 'southeast';
        orgKey = 'section1';
        listState = {
          Name: '',
          Id: '',
          PullDate: '',
          PullStartDate: '',
          PullSyncDate: '',
          PullToSqlDate: '',
          ExportDate: '',
          ExportStartDate: '',
          UpdatedOn: '',
          BWExportDate: '',
          UpdatedBy: '',
          ListRefId: ''
        };
        userContextSvc = {
          getClientKey: function () {
            return clientKey;
          },
          getOrgKey: function () {
            return orgKey;
          }
        };
        listStateSvc = {
          get: function () {
            return listState;
          }
        };
        data = {
          segments: [ ]
        };
        calculationSvc = {
          calculate: function () {
            return {
              then: function (callback) { return callback({}); }
            };
          }
        };
        spyOn(userContextSvc, 'getClientKey').and.returnValue(clientKey);
        spyOn(userContextSvc, 'getOrgKey').and.returnValue(orgKey);
        spyOn(listStateSvc, 'get').and.returnValue(listState);
        spyOn(calculationSvc, 'calculate').and.callFake(function () {
          return {
            then: function (callback) { return callback(data); }
          };
        });
        q = $q;
        scope = $rootScope.$new();
        ctrl = $controller('pulledListSummaryCtrl', {
          $scope: scope,
          listStateSvc: listStateSvc,
          calculationSvc: calculationSvc
        });
      });
    });

    it('controller should exist', function () {
      expect(ctrl).not.toBeUndefined();
    });

    it('it should check calculationSvc is called', function () {
      expect(calculationSvc.calculate).toHaveBeenCalled();
      expect(scope.quickCounts).toEqual(data.segments);
    });
  });

})(window.app);