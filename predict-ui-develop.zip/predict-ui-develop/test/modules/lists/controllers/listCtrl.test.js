﻿
(function () {
  'use strict';

  describe('listCtrl', function () {
    var ctrl, scope, q, location, listid, listName, clientSvc, clientInfo;

    beforeEach(function () {

      clientInfo = {
        client: { ETLDate: null }
      };

      clientSvc = {
        loadClients: function () {
          return clientInfo;
        }
      };
      spyOn(clientSvc, 'loadClients').and.returnValue(clientInfo);

      module('app');
      angular.mock.inject(function ($rootScope, $controller, $q, $location) {
        q = $q;
        scope = $rootScope.$new();
        ctrl = $controller('listCtrl', { $scope: scope });
        location = $location;
      });
    });

    it('controller should exist', function () {
      expect(ctrl).not.toBeUndefined();
    });

    describe('copy list methods', function () {
      it('should have a saveCopiedList() function', function () {
        expect(scope.saveCopiedList).not.toBeUndefined();
      });

      it('should have a copyListPopUp() function', function () {
        expect(scope.copyListPopUp).not.toBeUndefined();
      });

      it('should have a close() function', function () {
        expect(scope.close).not.toBeUndefined();
      });

      it('should get lists', function () {
        listid = '53713b6e1b3054d3585532a2';
        listName = 'Copy of testlist_1';
        var defer = q.defer();
        var data = ['a', 'b'];
        defer.resolve(data);
        spyOn(q, 'all').and.returnValue(defer.promise);
        scope.copyListPopUp(listid, listName);
        //scope.$apply();
        //expect(scope.copiedListName).tobe('Copy of testlist_2')
      });
      it('locationDescriptorsForEmpty', function () {
        var locationDescriptorsEmpty = [];
        var parameterForEmpty = scope.canDisplayListItem(locationDescriptorsEmpty);
        expect(parameterForEmpty).toEqual(true);
      });
      it('locationDescriptorsForValue', function () {
        var locationDescriptors = [{ 'Address': [{ 'Address1': 'Nashvile', 'city': 'City1' }], 'LocationId': 81, 'Type': 'Radius' }];
        var parameter = scope.canDisplayListItem(locationDescriptors);
        expect(parameter).toEqual(true);
      });
      it('locationDescriptorsForNull', function () {
        var locationDescriptors = null;
        var parameter = scope.canDisplayListItem(locationDescriptors);
        expect(parameter).toEqual(true);
      });

      it('pulll the list', function () {
        listid = '53713b6e1b3054d3585532a2';
        listName = 'Copy of testlist_1';
        scope.pullList(listid, listName, new Date('01/01/2000'), new Date());
      });
      it('it should delete the list', function () {
        listid = '53713b6e1b3054d3585532a2';
        listName = 'Copy of testlist_1';
        scope.deleteList(listid, listName);
      });
      it('it should copy the list', function () {
        scope.currentListState = {
          Name: '',
          Id: '',
          PullDate: '',
          PullStartDate: '',
          PullSyncDate: '',
          PullToSqlDate: '',
          ExportDate: '',
          ExportStartDate: '',
          UpdatedOn: '',
          BWExportDate: '',
          UpdatedBy: '',
          ListRefId:''
        };
        scope.newListName = 'Copy1 of testlist_1';
        scope.saveCopiedList();
      });
      it('should have formatList method ', function () {
        expect(scope.formatList).not.toBeUndefined();
      });
      it('should make list incomplete if Marketing channel is not there', function () {
        var list = [{
          CurrentUIState: { isComplete: true },
          PullDate: null,
          CreatorName: undefined,
          CreatedOn: undefined,
          UpdatedOn: '',
          IsExported: true,
          IsPulled: true,
          LocationNames: '',
          LocationNamesTooltip: '<ul class="grid-list-tooltip">',
          PullStartDate: undefined,
          IsDisabled: false,
          disabledClassName: '',
          IsBWExportAllowed: false,
          BWExportDate:null
        }];
        var test = scope.formatList(list);
        expect(test[0].CurrentUIState.isComplete).toEqual(false);
      });
      it('Download pivot table counts', function () {
        listid = '53713b6e1b3054d3585532a2';
        scope.pivotTableCounts(listid);
      });
    });
  });

})(window.app);