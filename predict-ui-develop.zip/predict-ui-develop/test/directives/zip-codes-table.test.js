﻿(function () {
  'use strict';

  describe('zip-codes-table directive', function () {
    var scope, element, el;

    beforeEach(module('app'));

    beforeEach(module('templates'));

    beforeEach(inject(function ($rootScope, $compile) {
      scope = $rootScope.$new();

      scope.radiusData = {
        'LocationId': 236,
        'Address': {
          'Address1': '1400 E BOULDER ST',
          'City': 'COLORADO SPRINGS',
          'State': 'CO',
          'Zip': '80909',
          'GeoJson': {
            'Type': 'Point',
            'Coordinates': [
              '-104.8',
              '38.8388'
            ]
          }
        },
        'RadiusInMiles': 12,
        'AdditionalZipCodeIds': [
          '81039'
        ],
        'ExcludedZipCodeIds': [
          '80106'
        ],
        'RadiusZipCodeIds': [
          '80132',
          '80813',
          '80814',
          '80101'
        ],
        'AllLocations': [
          {
            'Id': 'customAddress',
            'Name': 'Custom Address'
          },
          {
            'Id': 236,
            'Name': 'Memorial Hospital'
          },
          {
            'Id': 2000,
            'Name': 'Vascular and Endovascular Clinic'
          }
        ],
        'SelectedLocationId': 236,
        'IsCustomAddress': false
      };

      scope.availableZips = [
          '81039'
        ];

      scope.excludedZips = [
          '80106'
        ];

      scope.radiusZips = [
          '80132',
          '80813',
          '80814',
          '80101'
        ];

      element = angular.element('<zip-codes-table radius-data="radiusData" available-zips="availableZips" radius-zips="radiusZips" excluded-zips="excludedZips"></zip-codes-table>');

      el = $compile(element)(scope);
      scope.$digest();
    }));

    it('check changeStatus method exists', function () {
      expect(el.isolateScope().changeStatus).not.toBeUndefined();
    });

    it('check status changed to included', function () {
      el.isolateScope().changeStatus('80101','included');
    });

    it('check status changed to excluded', function () {
      el.isolateScope().changeStatus('80101', 'excluded');
    });

    it('check status changed to in radius', function () {
      el.isolateScope().changeStatus('80106', 'inradius');
    });

    it('check restoreDefaultStatus method exists', function () {
      el.isolateScope().restoreDefaultStatus();
    });

  });
})();