/* global beforeEach, inject, describe */
(function () {

  'use strict';

  describe('distributeCountsTables directive', function () {
    var $compile, $rootScope, element, scope;

    beforeEach(module('app'));

    beforeEach(module('templates'));

    beforeEach(inject(function (_$compile_, _$rootScope_) {
      $compile = _$compile_;
      $rootScope = _$rootScope_;

      var distributionData = {
        'AvailableCount': 45,
        'DesiredCount': 45,
        'Segments': [{
          'Name': 'New Segment',
          'AvailableCount': 23,
          'DesiredCount': 23,
          'PersonTypeDistributions': [{
            'PersonTypeId': 5,
            'PersonTypeName': 'Patients',
            'AvailableCount': 1,
            'DesiredCount': 1,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0CY'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0CZ'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0D0'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0D1'
            }]
          }, {
            'PersonTypeId': 10,
            'PersonTypeName': 'New Movers',
            'AvailableCount': 4,
            'DesiredCount': 4,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0DA'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 2,
              'DesiredCount': 2,
              '$$hashKey': '0DB'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0DC'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0DD'
            }]
          }, {
            'PersonTypeId': 15,
            'PersonTypeName': 'Prospects',
            'AvailableCount': 4,
            'DesiredCount': 4,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0DM'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0DN'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0DO'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 3,
              'DesiredCount': 3,
              '$$hashKey': '0DP'
            }]
          }, {
            'PersonTypeId': 20,
            'PersonTypeName': 'Qualified Prospects',
            'AvailableCount': 6,
            'DesiredCount': 6,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0DY'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 2,
              'DesiredCount': 2,
              '$$hashKey': '0DZ'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 2,
              'DesiredCount': 2,
              '$$hashKey': '0E0'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 2,
              'DesiredCount': 2,
              '$$hashKey': '0E1'
            }]
          }, {
            'PersonTypeId': 25,
            'PersonTypeName': 'Family Member of Patients',
            'AvailableCount': 8,
            'DesiredCount': 8,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 2,
              'DesiredCount': 2,
              '$$hashKey': '0EA'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 3,
              'DesiredCount': 3,
              '$$hashKey': '0EB'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0EC'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 2,
              'DesiredCount': 2,
              '$$hashKey': '0ED'
            }]
          }],
          '$$hashKey': '0CE'
        }, {
          'Name': 'Non-segmented List',
          'AvailableCount': 16,
          'DesiredCount': 16,
          'PersonTypeDistributions': [{
            'PersonTypeId': 5,
            'PersonTypeName': 'Patients',
            'AvailableCount': 3,
            'DesiredCount': 3,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0EW'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0EX'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0EY'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0EZ'
            }]
          }, {
            'PersonTypeId': 10,
            'PersonTypeName': 'New Movers',
            'AvailableCount': 2,
            'DesiredCount': 2,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0F8'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0F9'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0FA'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0FB'
            }]
          }, {
            'PersonTypeId': 15,
            'PersonTypeName': 'Prospects',
            'AvailableCount': 3,
            'DesiredCount': 3,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0FK'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0FL'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0FM'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0FN'
            }]
          }, {
            'PersonTypeId': 20,
            'PersonTypeName': 'Qualified Prospects',
            'AvailableCount': 3,
            'DesiredCount': 3,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0FW'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0FX'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0FY'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0FZ'
            }]
          }, {
            'PersonTypeId': 25,
            'PersonTypeName': 'Family Member of Patients',
            'AvailableCount': 5,
            'DesiredCount': 5,
            'ScoreDistributions': [{
              'Score': 0,
              'ScoreName': 'Behavior',
              'AvailableCount': 1,
              'DesiredCount': 1,
              '$$hashKey': '0G8'
            }, {
              'Score': 1,
              'ScoreName': 'Best',
              'AvailableCount': 2,
              'DesiredCount': 2,
              '$$hashKey': '0G9'
            }, {
              'Score': 2,
              'ScoreName': 'Better',
              'AvailableCount': 2,
              'DesiredCount': 2,
              '$$hashKey': '0GA'
            }, {
              'Score': 3,
              'ScoreName': 'Good',
              'AvailableCount': 0,
              'DesiredCount': 0,
              '$$hashKey': '0GB'
            }]
          }],
          '$$hashKey': '0CF'
        }],
        'SeedListCount': 6
      };

      scope.distribution = distributionData;

      var html = '<distribute-counts-tables distribution="distribution"></distribute-counts-tables>';
      element = $compile(html)($rootScope);
      $rootScope.$digest();
    }));
    // Need to build a unit test - Morgan
    // it('segmentDesiredCountChanged Exists', function() {
    //   expect(scope.segmentDesiredCountChanged).not.toBeUndefined();
    // });
    // it('personTypeChange Exists', function() {
    //   expect(scope.personTypeChange).not.toBeUndefined();
    // });
    // it('clearZeroOnFocusForSegment Exists', function() {
    //   expect(scope.clearZeroOnFocusForSegment).not.toBeUndefined();
    // });
    // it('clearBlankOnBlurForSegment Exists', function() {
    //   expect(scope.clearBlankOnBlurForSegment).not.toBeUndefined();
    // });
    // it('clearZeroOnFocusForPersonType Exists', function() {
    //   expect(scope.clearZeroOnFocusForPersonType).not.toBeUndefined();
    // });
    // it('clearBlankOnBlurForPersonType Exists', function() {
    //   expect(scope.clearBlankOnBlurForPersonType).not.toBeUndefined();
    // });
    // it('Distribution is undefined', function() {
    //   expect(scope.distribution.Segments[0].AvailableCount).not.toBeUndefined();
    // });
    // it('DesiredCountChanged will change the totalDesiredCount', function() {
    //   var data = scope.distribution.Segments[0];
    //   data.DesiredCount = 22;
    //   scope.segmentDesiredCountChanged(data);
    //   expect(scope.distribution.DesiredCount).toEqual(44);
    // });

    // it('personTypeChange will change the totalDesiredCount', function() {
    //   var data = scope.distribution.Segments[0];
    //   var personType = data.PersonTypeDistributions[0];
    //   personType.DesiredCount = 0;
    //   scope.personTypeChange(data, personType);
    //   expect(scope.distribution.DesiredCount).toEqual(43);
    // });
    // it('updatesIfPersonTypeCountIsLess will get called for adjusting the total count', function() {
    //   var data = scope.distribution.Segments[0];
    //   data.DesiredCount = 22;
    //   scope.segmentDesiredCountChanged(data);
    //   expect(scope.distribution.DesiredCount).toEqual(44);
    // });
    // it('DesiredCountChanged will not take more than 23', function() {
    //   var data = scope.distribution.Segments[0];
    //   data.DesiredCount = 24;
    //   scope.segmentDesiredCountChanged(data);
    //   expect(scope.distribution.DesiredCount).toEqual(45);
    // });
    // it('DesiredCountChanged with empty data', function() {
    //   scope.distribution.Segments[0].DesiredCount = '';
    //   var data = scope.distribution.Segments[0];
    //   scope.segmentDesiredCountChanged(data);
    //   expect(scope.distribution.DesiredCount).toEqual(45);
    // });
    // it('personTypeChange with empty data', function() {
    //   scope.distribution.Segments[0].PersonTypeDistributions[0].DesiredCount = '';
    //   var data = scope.distribution.Segments[0];
    //   var personType = data.PersonTypeDistributions[0];
    //   scope.personTypeChange(data, personType);
    //   expect(scope.distribution.DesiredCount).toEqual(45);
    // });
    // it('clearZeroOnFocusForSegment with empty data', function() {
    //   scope.distribution.Segments[0].DesiredCount = 0;
    //   var data = scope.distribution.Segments[0];
    //   scope.clearZeroOnFocusForSegment(data);
    //   expect(scope.distribution.Segments[0].DesiredCount).toEqual('');
    // });

    // it('clearBlankOnBlurForSegment with empty data', function() {
    //   scope.distribution.Segments[0].DesiredCount = '';
    //   var data = scope.distribution.Segments[0];
    //   scope.clearBlankOnBlurForSegment(data);
    //   expect(scope.distribution.Segments[0].DesiredCount).toEqual(0);
    // });

    // it('clearZeroOnFocusForPersonType with empty data', function() {
    //   scope.distribution.Segments[0].PersonTypeDistributions[0].DesiredCount = 0;
    //   var data = scope.distribution.Segments[0].PersonTypeDistributions[0];
    //   scope.clearZeroOnFocusForPersonType(data);
    //   expect(scope.distribution.Segments[0].PersonTypeDistributions[0].DesiredCount).toEqual('');
    // });

    // it('clearBlankOnBlurForPersonType with empty data', function() {
    //   scope.distribution.Segments[0].PersonTypeDistributions[0].DesiredCount = '';
    //   var data = scope.distribution.Segments[0];
    //   var personType = scope.distribution.Segments[0].PersonTypeDistributions[0];
    //   scope.clearBlankOnBlurForPersonType(personType, data);
    //   expect(scope.distribution.Segments[0].PersonTypeDistributions[0].DesiredCount).toEqual(0);
    // });

  });

})(window.app);