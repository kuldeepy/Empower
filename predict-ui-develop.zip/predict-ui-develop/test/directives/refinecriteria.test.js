(function () {
  'use strict';

  describe('refinecriteria directive', function () {
    var $rootScope, $compile, element;
    var providerSearch = {
      NPINumber: 'Y',
      FirstName: 'N',
      LastName: 'M',
      Specialties: [
        {
          'Id': '1',
          'Name': 'A',
          'Value': 'B'
        },
        {
          'Id': '2',
          'Name': 'B',
          'Value': 'A'
        }
      ],
      SelectedSpecialties: [
        {
          'Id': '1',
          'Name': 'A',
          'Value': 'B'
        }
      ]
    };


    beforeEach(module('app'));

    beforeEach(module('templates'));

    beforeEach(inject(function (_$rootScope_, _$compile_, $q) {
      $rootScope = _$rootScope_;
      $compile = _$compile_;

      $rootScope.criteria = $q.when({
        Gender: [
          { Name: 'Male', _id: 'M' },
          { Name: 'Female', _id: 'F' },
          { Name: 'Unknown', _id: 'U' },
        ]
      });

      $rootScope.providerSearch = {
        NPINumber: 'Y',
        FirstName: 'N',
        LastName: 'M',
        Specialties: [
          {
            'Id': '1',
            'Name': 'A',
            'Value': 'B'
          },
          {
            'Id': '2',
            'Name': 'B',
            'Value': 'A'
          }
        ],
        SelectedSpecialties: [
          {
            'Id': '1',
            'Name': 'A',
            'Value': 'B'
          }
        ]
      };
      $rootScope.providerSpecialties = $q.when([]);

      $rootScope.parentFilterValueSelections = $q.when([]);
      $rootScope.listFilterValueSelections = [
        {
          'ExcludeValues': ['M'],
          'FilterName': 'Gender',
          'IncludeValues': [],
          'fromDate': null,
          'toDate': null
        },
        {
          'ExcludeValues': ['H'],
          'FilterName': 'EncounterSourceType',
          'IncludeValues': [],
          'fromDate': null,
          'toDate': null
        },
        {
          'ExcludeValues': ['Y'],
          'FilterName': 'ERUtilization',
          'IncludeValues': [],
          'fromDate': null,
          'toDate': null
        },
        {
          'ExcludeValues': ['Y'],
          'FilterName': 'PatientType',
          'IncludeValues': [],
          'fromDate': null,
          'toDate': null
        },
        {
          'ExcludeValues': ['Y'],
          'FilterName': 'PhysicianType',
          'IncludeValues': [],
          'fromDate': null,
          'toDate': null
        }
      ];

      var html = '<refinecriteria criteria="criteria" parent-filter-value-selections="parentFilterValueSelections" filter-value-selections="listFilterValueSelections" provider-specialties="providerSpecialties"></refinecriteria>';
      element = $compile(html)($rootScope);
      $rootScope.$digest();
    }));

    it('should have loading property', function () {
      expect(element.isolateScope().loading).not.toBeUndefined();
    });
    it('should have enableButton', function () {
      expect(element.isolateScope().enableButton).not.toBeUndefined();
    });

    it('enableButton should be return true', function () {
      element.isolateScope().providerSearch = providerSearch;
      element.isolateScope().enableButton();
      expect(element.isolateScope().isFieldDirty).toEqual(true);
    });

    it('scope.toggleSpecialties should be set true for toggleSelectAll', function () {
      element.isolateScope().toggleSpecialties = false;
      element.isolateScope().providerSearch = providerSearch;
      element.isolateScope().toggleSelectAll();
      expect(element.isolateScope().toggleSpecialties).toEqual(true);
    });

    it('scope.toggleSpecialties should be set false for toggleSelectAll and SelectedSpecialties should be empty', function () {
      element.isolateScope().toggleSpecialties = true;
      element.isolateScope().providerSearch = providerSearch;
      element.isolateScope().toggleSelectAll();
      expect(element.isolateScope().toggleSpecialties).toEqual(false);
      expect(element.isolateScope().providerSearch.SelectedSpecialties.length).toEqual(0);
    });

    it('applyPatientDateRange for source type', function () {
      element.isolateScope().selection.PatientDateRange = ['Mon Jul 06 2015 00:00:00 GMT-0500 (Central Daylight Time)', 'Mon Jul 06 2015 00:00:00 GMT-0500 (Central Daylight Time)'];
      element.isolateScope().applyPatientDateRange();
      expect(element.isolateScope().filterValueSelections[1].fromDate).not.toEqual(null);
    });

    it('should have gender selection', function () {
      expect(element.isolateScope().selection.Gender).not.toBeUndefined();
    });

    describe('deselecting a gender', function () {

      var genderSelection, genderFilterValueSelection;

      beforeEach(function () {
        genderSelection = element.isolateScope().selection.Gender;

        genderSelection[0].changed(false);

        genderFilterValueSelection = element.isolateScope().filterValueSelections[0];
      });

      it('should have correct filterValueSelection ExcludeValues', function () {
        expect(genderFilterValueSelection.ExcludeValues).toEqual(['M']);
      });

      it('should have correct filterValueSelection FilterName', function () {
        expect(genderFilterValueSelection.FilterName).toBe('Gender');
      });

      describe('reselecting gender', function () {
        beforeEach(function () {
          genderSelection[0].changed(true);
        });

        it('should remove filterValueSelection', function () {
          expect(element.isolateScope().filterValueSelections.length).toBe(4);
        });
      });
    });

  });
})();