(function () {

  'use strict';

  describe('simpleSearch Directive Test Suite', function () {
    var scope, element, el;

    beforeEach(module('app'));

    beforeEach(module('templates'));

    beforeEach(inject(function ($rootScope, $compile) {
      scope = $rootScope.$new();
      element = angular.element('<simple-search search-model="searchModel" search-id="search_test_id"></simple-search>');
      el = $compile(element)(scope);
      scope.$digest();
    }));

    // Semantic Testing
    describe('Directive elements should have semantic structure &', function() {
      it('input should have a label', function () {
        expect(el.find('label').length).toBe(1);
      });
      it('label should have a for attribute', function () {
        expect(el.find('label').attr('for')).not.toBe(null);
      });
      it('input should have a type search defined', function () {
        expect(el.find('input').attr('type')).toEqual('search');
      });
    }); // End Semantic Testing

    it('directive should output svg icon', function () {
      expect(el.find('svg').length).toBe(1);
    });
    it('input should have id defined and should match id of directive', function () {
      var searchId = el.find('simple-search').attr('search-id');
      expect(el.find('input').attr('id')).toMatch(searchId);
    });
  });
})(window.app);
