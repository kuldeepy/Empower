(function () {

  'use strict';

  describe('list summary directive', function () {
    var $rootScope, $compile, element, listStateSvc, $timeout, clientSvc;
    var $filter;
    var listStateItem = {
      'Id': '1234567890',
      'PullDate':'2015-07-13T11:23:26.614Z',
      'LocationDescriptors': [],
      'FilterValueSelections': [],
      'ExcludedPastListIds': [],
      'IncludedPastListIds': [],
      'SeedListIds': [],
      'Segments': [],
      'IsEditable': true,
      'IsTransient': true,
      'ExcludeHoldouts': true,
      'CurrentUIState':
        {
          'CurrentLocationIndex': -1,
          'hasVisited': {}
        }
      };

    var clientData = {
      'Key': 'southeast',
      'Name': 'Southeast Health Systems',
      'Organizations': [
        {
          'ClientKey': 'southeast',
          'Key': 'section1',
          'Name': 'Section 1',
          'ExclusionPeriod': 30,
          'RecipeIds': [99],
          'Id': '53626585c597cf5eeea77032'
        }
      ],
      'AppId': 999,
      'IsSilverpopConfigured': true,
      'ETLDate': '2015-08-07T00:00:00.611Z',
      'PulledDate': '2015-09-09T06:54:00.287Z',
      'Id': '53626585c597cf5eeea77031'
    };

    beforeEach(function () {
      module('app', function ($httpProvider, $provide) {

        listStateSvc = jasmine.createSpyObj('listStateSvc', ['get']);
        clientSvc = jasmine.createSpyObj('clientSvc', ['loadClients']);

        listStateSvc.get.and.returnValue(listStateItem);

        $provide.value('listStateSvc', listStateSvc);

        clientSvc.loadClients.and.returnValue(clientData);
      });
    });

    beforeEach(module('templates'));

    beforeEach(inject(function (_$rootScope_, _$compile_, $httpBackend, _$timeout_, _$filter_) {
      $rootScope = _$rootScope_;
      $compile = _$compile_;
      $timeout = _$timeout_;
      $filter = _$filter_;
      var html = '<list-summary enable-edit="true" list-item="{Name:\'abc\'}" breadcrumb="breadcrumb"></list-summary>';
      $httpBackend.whenGET('/templates/alertContainer.html').respond(200, '');
      $httpBackend.whenGET('/api/clients/undefined/lookupData/marketing-channel').respond(200, '');
      $httpBackend.whenGET('/api/clients/undefined/orgs//locations//facilities').respond(200, '');
      $httpBackend.whenGET('/api/clients/undefined/orgs//pastList').respond(200, '');
      $httpBackend.whenGET('/api/clients/undefined/orgs//seedLists').respond(200, '');
      $httpBackend.whenGET('/api/clients/undefined/orgs//filterTypes/filters').respond(200, '');
      $httpBackend.whenGET('/api/clients/undefined/providerSpecialties').respond(200, '');
      $httpBackend.whenGET('/templates/alertContainer.html').respond(200, '');
      $httpBackend.whenGET('/api/clients/undefined/listclients').respond(200, '');
      element = $compile(html)($rootScope);
      $rootScope.$digest();
    }));
    it('should have enableEdit property', function () {
      expect(element.isolateScope().enableEdit).not.toBeUndefined();
    });
    it('should have locations property', function () {
      expect(element.isolateScope().locations).not.toBeUndefined();
    });
    it('should have includedPastList property', function () {
      expect(element.isolateScope().includedPastList).not.toBeUndefined();
    });
    it('should have selectedSeedLists property', function () {
      expect(element.isolateScope().selectedSeedLists).not.toBeUndefined();
    });
    it('should have segments property', function () {
      expect(element.isolateScope().segments).not.toBeUndefined();
    });
    it('should have canShowSummarySection', function () {
      expect(element.isolateScope().canShowSummarySection).not.toBeUndefined();
    });
    it('should have individualTotal', function () {
      expect(element.isolateScope().individualTotal).not.toBeUndefined();
    });
    it('should have householdTotal', function () {
      expect(element.isolateScope().householdTotal).not.toBeUndefined();
    });
    it('should have gridOptionsForLocations property', function () {
      expect(element.isolateScope().gridOptionsForLocations).not.toBeUndefined();
    });
    it('should have gridDataForPastList property', function () {
      expect(element.isolateScope().summaryTablePastListsData.gridData).not.toBeUndefined();
    });
    it('should have summaryTableSeedListsData property', function () {
      expect(element.isolateScope().summaryTableSeedListsData.gridData).not.toBeUndefined();
    });
    it('should have gridDataForManageSegments property', function () {
      expect(element.isolateScope().summaryTableManageSegmentsData.gridData).not.toBeUndefined();
    });
    it('should have getTab', function () {
      expect(element.isolateScope().getTab).not.toBeUndefined();
    });
    it('should have dataAvailable', function () {
      expect(element.isolateScope().dataAvailable).not.toBeUndefined();
    });
    it('should have called dataAvailable and set the incompleteStep data', function () {
      $timeout.flush();
      expect(element.isolateScope().incompleteSteps).not.toBeUndefined();
    });
    it('should have a breadcrumb instance', function () {
      expect(element.isolateScope().breadcrumb).not.toBe(null);
    });
  });
})();
