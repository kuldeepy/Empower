(function (app) {
  'use strict';

  // This directive converts the existing jQuery plugin, jquery-circle-progress, to an Angular-usable directive.
  // Value determines the progress value, while size is the stroke weight of the circle, which is set to 50.
  // Documentation for the jQuery plugin can be found here: https://github.com/kottenator/jquery-circle-progress 

  app.directive('circleProgress', function () {
    return {
      restrict: 'A',
      scope: {
        value: '=',
        size: '='
      },
      link: function (scope, element) {
        var primaryColor = '#0072bc';
        scope.getDecimalValue = function() {
          scope.decimalValue = 0;
          if (scope.value === 100) {
            scope.decimalValue = 100;
          } else {
            scope.decimalValue = '.' + scope.value;
          }
          return scope.decimalValue;
        };
        var circle = $(element);
        circle.circleProgress({
          value: scope.getDecimalValue(),
          size: scope.size,
          lineCap: 'round',
          animation: false,
          fill: {
            color: primaryColor
          },
          emptyFill: 'rgba(0,114,188,0.2)'
        });
      }
    };
  });
})(window.app);
