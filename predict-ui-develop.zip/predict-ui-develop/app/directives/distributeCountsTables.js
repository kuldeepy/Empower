(function (app) {
	'use strict';

  app.filter('titlecase', function() {
    return function(s) {
        s = ( s === undefined || s === null ) ? '' : s;
        return s.toString().toLowerCase().replace( /\b([a-z])/g, function(ch) {
            return ch.toUpperCase();
          });
      };
  });

	app.directive('distributeCountsTables', function () {
		return {
			restrict: 'E',
			replace: true,
			scope: {
				distribution: '=',
				displayOnly: '='
			},
			templateUrl: '/modules/listBuild/Views/distributeCountsTables.html',
			link: function (scope) {
				//calls when user changes segment desire count textbox
				scope.segmentDesiredCountChanged = function(segment) {
					//checking for empty value
					if (segment.DesiredCount === '') {
						return;
					}
					//checking : value should not exceeed the limit
					if (segment.AvailableCount < segment.DesiredCount) {
						segment.DesiredCount = segment.AvailableCount;
					}
					
					//update all personTypeCount
					updateSegmentPersonTypeCount(segment);
          updateTotalDesiredCount();
          scope.$emit('distributionTables.$valid');
				};

				scope.quickCountLoading = scope.$parent.quickCountLoading;

				//calls when user changes personType textbox
				scope.personTypeChange = function(segment, person) {
					if (person.DesiredCount === '') {
						return;
					}
					//checking : value should not exceeed the limit
					if (person.DesiredCount > person.AvailableCount) {
						person.DesiredCount = person.AvailableCount;
					}
          updateTotalSegmentCount(segment);
          updateTotalDesiredCount();
          scope.$emit('distributionTables.$valid');
				};

				//clear zero value when user clicks on textbox
				scope.clearZeroOnFocus = function(population) {
					if (population.DesiredCount === 0) {
						population.DesiredCount = '';
					}
				};

				//change blank to zero when user leave the textbox
				scope.clearBlankOnBlurForSegment = function(segment) {
					if (segment.DesiredCount === '') {
						segment.DesiredCount = 0;
						scope.segmentDesiredCountChanged(segment);
					}
				};

				//change blank to zero when user leave the textbox
				scope.clearBlankOnBlurForPersonType = function(personType, segment) {
					if (personType.DesiredCount === '') {
						personType.DesiredCount = 0;
						scope.personTypeChange(segment, personType);
					}
				};

				//update total desired count
				function updateTotalDesiredCount() {
					scope.distribution.DesiredCount = 0;
					_.each(scope.distribution.Segments, function(segment) {
						if (segment.DesiredCount === '') {
							segment.DesiredCount = 0;
						}
						scope.distribution.DesiredCount = parseInt(scope.distribution.DesiredCount) + parseInt(segment.DesiredCount);
					});
				}

				//update total segment count
				function updateTotalSegmentCount(segment) {
					segment.DesiredCount = 0;
					_.each(segment.PersonTypeDistributions, function(personType) {
						segment.DesiredCount = parseInt(segment.DesiredCount) + parseInt(personType.DesiredCount);
					});
				}

				//update all persontype count 
				function updateSegmentPersonTypeCount(segment) {
          var totalCount = 0;

					_.each(segment.PersonTypeDistributions, function(personType) {
						var percentOfTotal = parseFloat(personType.AvailableCount) / parseInt(segment.AvailableCount);
						var countFloat = parseFloat(segment.DesiredCount) * parseFloat(percentOfTotal);
						var personTypeCount = Math.round(countFloat);

						if (personType.AvailableCount > 0) {
							if (personTypeCount <= personType.AvailableCount) {
								personType.DesiredCount = personTypeCount;
							} else {
								personType.DesiredCount = personType.AvailableCount;
							}
						}

						totalCount = totalCount + parseInt(personType.DesiredCount);
					});

					//Counts don't match up due to rounding, refine them to match
					if (totalCount !== segment.DesiredCount) {
						refinePersonTypeCounts(segment);
					}
				}

				function getCurrentTotalCount(segment) {
					return _.reduce(segment.PersonTypeDistributions, function(total, personType) {
						return total + parseInt(personType.DesiredCount);
					}, 0);
				}

				function refinePersonTypeCounts(segment, adjustedTypes) {
					var currentTotalCount = getCurrentTotalCount(segment);
					if (segment.DesiredCount === currentTotalCount) { return; }
					if (!adjustedTypes) {
						adjustedTypes = [];
					}

					var personTypeFractions = _.map(segment.PersonTypeDistributions, function(personType) {
						var percentage = parseFloat(personType.AvailableCount) / parseInt(segment.AvailableCount);
						var countFloat = parseFloat(segment.DesiredCount) * percentage;
						var countInt = parseInt(countFloat);
						return {
							fraction: countFloat - countInt,
							personType: personType
						};
					});

					var sortedFractions = _.sortBy(personTypeFractions, 'fraction');
					//Count is less than desired, add 1 to the highest fraction that was rounded down
					if (currentTotalCount < segment.DesiredCount) {
						var closestMiss = _.findLast(sortedFractions, function(frac) {
							return frac.fraction < 0.5 && frac.personType.DesiredCount < frac.personType.AvailableCount && !_.contains(adjustedTypes, frac.personType.PersonTypeName);
						});
						if (closestMiss) {
							segment.PersonTypeDistributions[_.indexOf(segment.PersonTypeDistributions, closestMiss.personType)].DesiredCount += 1;
							adjustedTypes.push(closestMiss.personType.PersonTypeName);
						}
					}

					currentTotalCount = getCurrentTotalCount(segment);

					//Count is greater than desired, remove 1 from the lowest fraction that was rounded up
					if (currentTotalCount > segment.DesiredCount) {
						var worstMatch = _.find(sortedFractions, function(frac) {
							return frac.fraction >= 0.5 && frac.personType.DesiredCount > 0 && !_.contains(adjustedTypes, frac.personType.PersonTypeName);
						});
						if (worstMatch) {
							segment.PersonTypeDistributions[_.indexOf(segment.PersonTypeDistributions, worstMatch.personType)].DesiredCount -= 1;
							adjustedTypes.push(worstMatch.personType.PersonTypeName);
						}
					}

					refinePersonTypeCounts(segment, adjustedTypes);
				}
			}
		};
	});
})(window.app);
