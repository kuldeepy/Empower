(function (app) {
  'use strict';

  app.directive('alertContainer', function ($compile, $timeout, alertSvc, tabAndStepDefinitions) {
    return {
      restrict: 'E',
      scope: true,
      replace: true,
      templateUrl: '/templates/alertContainer.html',
      link: function (scope, element, attrs) {
        var tabDefinitions = tabAndStepDefinitions();
        scope.alertItems = alertSvc.get();
        var source = attrs.source.split(',');
        scope.isSourceMatch = function (sourceItem) {
          return _.contains(source, sourceItem);
        };
        scope.removeAlert = function (item) {
          alertSvc.remove(item);
        };
        scope.getTab = function (name) {
          return _.find(tabDefinitions.tabs, {
            name: name
          });
        };
        scope.updateCount = function () {
          scope.$emit('updateCount', true);
        };
      }
    };
  });

})(window.app);