(function (app) {
  'use strict';

  app.directive('exportListPopover', function ($compile) {
    var itemsTemplate = '<div class="popover-label-container"><ul class="popover-links"><li><a href="" class="sub_links" ng-click="onSelection(false)">Export to Marketing Automation</a></li>' +
    '<li><a href="" ng-click="onSelection(true)" class="sub_links">Export to Text File</a></li></ul></div>';
    return {
      restrict: 'A',
      transclude: true,
      template: '<span ng-transclude></span>',
      link: function ($scope, element) {
        var popOverContent;

        var removeHandlers = function (popOverElement) {
          $(popOverElement).off('mouseleave');
          $('.popover').off('mouseleave');
          $(popOverElement).popover('destroy');
        };

        var createPopOver = function (popOverElement) {
          removeHandlers(popOverElement);
          popOverContent = $compile(itemsTemplate)($scope);
          var options = {
            content: popOverContent,
            template:'<div class="export popover purple"><div class="arrow"></div><div class="popover-content"></div></div>',
            placement: 'left',
            html: true,
            container: 'body'
          };

          $(popOverElement).popover(options)
          .on('mouseleave', function () {
            $scope._this = this;
            $('.popover')
            .on('mouseleave', function () {
              setTimeout(function () {
                $($scope._this).popover('hide');
                createPopOver($scope._this);
              }, 200);
            });

            setTimeout(function () {
              if (!$('.popover:hover').length) {
                $($scope._this).popover('hide');
                createPopOver($scope._this);
              }
            }, 200);
          });
        };

        createPopOver(element);

        $scope.onSelection = function (isTextExport) {
          $($scope._this).popover('hide');
          createPopOver($scope._this);
          $scope.$parent.exportList($scope.listItem, isTextExport);
        };
      },
      scope: {
        listItem: '='
      }
    };
  });

})(window.app);
