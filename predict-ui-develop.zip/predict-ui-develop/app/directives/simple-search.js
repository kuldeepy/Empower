(function (app) {
  'use strict';

  app.directive('simpleSearch', function () {
    return {
      restrict: 'E',
      scope: {
        searchModel: '=',
        searchId: '@'
      },
      templateUrl: '/templates/simple-search.html'
    };
  });
}(window.app));
