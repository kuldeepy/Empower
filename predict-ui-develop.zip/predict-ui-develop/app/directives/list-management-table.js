﻿(function (app) {
  'use strict';

  app.directive('listManagementTable', [function () {
    return {
      restrict: 'E',
      templateUrl: '/templates/list-management-table.html',
      scope: true,
      link: function (scope, element, attrs) {
        scope.listManagementTable = {};
        scope.listManagementTable.settings = {};
        scope.listManagementTable.settings.defaultRowTemplate = '/templates/list-management-table-row.html';
        scope.listManagementTable.emptyMessage = scope.$parent.$eval(attrs.emptyDataMessage) ? scope.$parent.$eval(attrs.emptyDataMessage) : 'No records to display';
        scope.listManagementTable.pagingOption = {
          currentPage: 1,
          itemsPerPage: 10
        };
        scope.listManagementTable.pagingOption.currentPage = 1;

        scope.$watch(attrs.displayColumns, function (newVal) {
          scope.listManagementTable.displayColumns = newVal;
        });
        scope.$watch(attrs.searchData, function (newVal) {
          scope.listManagementTable.searchData = newVal;
          scope.listManagementTable.rowData = newVal;
        });
        scope.$watch(attrs.tableCaption, function (newVal) {
          scope.listManagementTable.tableCaption = newVal;
        });
        scope.$watch(attrs.hideTableCaption, function (newVal) {
          scope.listManagementTable.hideTableCaption = newVal;
        });
        scope.$watch(attrs.hideTablePager, function (newVal) {
          scope.listManagementTable.hideTablePager = newVal;
        });
        scope.$watch(attrs.rowTemplate, function (newVal) {
          scope.listManagementTable.rowTemplate = newVal;
        });
        scope.$watch(attrs.tableClass, function (newVal) {
          scope.listManagementTable.tableClass = newVal;
        });

        scope.$watch(attrs.filterText, function (newVal) {
          scope.filterText = newVal;
          scope.listManagementTable.rowData = scope.determineSearchItems();
          scope.listManagementTable.pagingOption.currentPage = 1;
        });

        scope.listManagementTable.sortingOptions = scope.$parent.$eval(attrs.sortingOptions);

        scope.$watch(attrs.serverSideSorting, function (newVal) {
          scope.listManagementTable.serverSideSorting = newVal;
        });

        scope.listManagementTable.selectedItems = scope.$parent.$eval(attrs.selectedItems);
        // Selected items array builder
        scope.determineSelectedItems = function () {
          scope.listManagementTable.selectedItems = [];
          _.each(scope.listManagementTable.rowData, function (column) {
            if (column.selected === true) {
              scope.listManagementTable.selectedItems.push(column);
            }
          });
        };

        scope.determineSearchItems = function () {
          var rowFound = false;
          scope.listManagementTable.searchDataOutput = [];
          _.each(scope.listManagementTable.searchData, function (row) {
            rowFound = false;
            _.each(scope.listManagementTable.displayColumns, function (column) {
              if (row[column.field] && row[column.field] !== null) {
                if (angular.lowercase(row[column.field]).indexOf(angular.lowercase(scope.filterText) || '') !== -1) {
                  rowFound = true;
                  return;
                }
              }
            });
            if (rowFound)
            {
              scope.listManagementTable.searchDataOutput.push(row);
            }
          });
          return scope.listManagementTable.searchDataOutput;
        };

        // Add checkbox functionality. This function iterates through the
        // gridColumn data and finds the ng-model of column.selected and
        // assigns truth to the selectedAll object.
        scope.checkAll = function () {
          scope.selectedAll = !scope.selectedAll;
          _.filter(scope.listManagementTable.rowData, function (column) {
            column.selected = scope.selectedAll;
          });
          scope.determineSelectedItems();
        };
        //  If all checkboxes are selected, then check the table header checkbox
        scope.isAllSelected = function () {
          scope.selectedAll = _.every(scope.listManagementTable.rowData, function (column) {
            return column.selected;
          });
          scope.determineSelectedItems();
        };

      }
    };
  }]);
}(window.app));
