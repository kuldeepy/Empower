(function (app) {
  'use strict';

  app.directive('scrollTop', function () {
    return {
      restrict: 'E',
      replace: 'true',
      templateUrl: '/templates/scrollTop.html'
    };
  });
})(window.app);