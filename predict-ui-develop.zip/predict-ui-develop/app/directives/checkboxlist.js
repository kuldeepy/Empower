(function (app) {
  'use strict';

  app.filter('spaceslashes', function () {
    return function (input) {
      if (input) {
        return input.replace('/',' / ');
      }
    };
  });

  app.filter('convertspaces', function () {
    return function (input) {
      if (input) {
        return input.replace('/','').replace(' ', '_').replace(' ', '').replace('\\','').replace('.','').replace('selection','');
      }
    };
  });

  app.directive('checkboxlist', function () {
    return {
      restrict: 'E',
      require: '^ngModel',
      scope: {
        ngModel: '=',
        listName: '@ngModel'
      },
      templateUrl: '/templates/checkbox-list.html',
      link: function (scope) {
        scope.uniqueId = scope.listName;
        scope.onClick = function (item) {
          item.checked = !item.checked;
          if (item.changed) {
            item.changed(item.checked);
          }
        };

        scope.checked = function (item) {
          return item.checked;
        };
      }
    };
  });
})(window.app);
