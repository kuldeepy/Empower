(function (app) {

  'use strict';

  app.directive('refinecriteria', ['$q', '_', 'providerSvc', 'listStateSvc', 'authSvc', function ($q, _, providerSvc, listStateSvc, authSvc) {
    return {
      restrict: 'E',
      scope: {
        filterValueSelections: '=filterValueSelections',
        parentFilterValueSelections: '=parentFilterValueSelections',
        criteria: '=criteria',
        displayOnly: '=displayOnly',
        providerSpecialties: '=providerSpecialties',
        disableCheckbox: '=disablecheckbox'
      },
      templateUrl: '/modules/listBuild/Views/predictFilter.html',
      link: function (scope) {
        scope.booleanValues = [{ '_id': true, 'Name': 'Yes' }, { '_id': false, 'Name': 'No' }, { '_id': 'null', 'Name': 'Unknown' }];
        scope.yesNoValues = [{ '_id': true, 'Name': 'Yes' }, { '_id': false, 'Name': 'No' }];
        scope.dateRangeValue = '';
        scope.providersLoading = false;
        scope.isFieldDirty = false;
        scope.toggleSpecialties = false;

        scope.enableButton = function () {
          if (scope.providerSearch.NPINumber !== '' || scope.providerSearch.SelectedSpecialties.length > 0 ||
            (scope.providerSearch.FirstName !== '' && scope.providerSearch.NPINumber !== '') ||
            (scope.providerSearch.LastName !== '' && scope.providerSearch.NPINumber !== '') ||
            (scope.providerSearch.FirstName !== '' && scope.providerSearch.SelectedSpecialties.length > 0) ||
            (scope.providerSearch.LastName !== '' && scope.providerSearch.SelectedSpecialties.length > 0)
            ) {
            scope.isFieldDirty = true;
          } else {
            scope.isFieldDirty = false;
          }
          scope.toggleSpecialties = (scope.providerSearch.SelectedSpecialties.length === scope.providerSearch.Specialties.length);
        };

        scope.providerSearch = {
          NPINumber: '',
          FirstName: '',
          LastName: '',
          Specialties: [],
          SelectedSpecialties: []
        };
        scope.selection = {};
        scope.showAllListCriteria = authSvc.showAllListCriteria();

        scope.loading = $q.all([
          $q.when(scope.parentFilterValueSelections),
          $q.when(scope.criteria),
          $q.when(scope.providerSpecialties)
        ]);
        scope.applySliderSettings = function (data) {
          var lookUpData = data;
          var sliderScale = [];
          scope.sliderConfig = {};

          if (lookUpData.DateRangeEncounter) {
            scope.sliderConfig.sliderStartingPoint = parseInt(lookUpData.DateRangeEncounter[0].From);
            scope.sliderConfig.sliderEndPoint = parseInt(lookUpData.DateRangeEncounter[0].To);
            scope.sliderConfig.sliderdefaultStartingPoint = parseInt(lookUpData.DateRangeEncounter[0].From);
            scope.sliderConfig.sliderdefaultEndPoint = parseInt(lookUpData.DateRangeEncounter[0].To);

            for (var i = scope.sliderConfig.sliderStartingPoint; i <= scope.sliderConfig.sliderEndPoint; i = i + 1) {
              sliderScale.push(i);
            }

            scope.sliderConfig.sliderScale = sliderScale;
            scope.sliderConfig.sliderStep = 1;
            scope.sliderConfig.sliderSmooth = false;
            scope.sliderConfig.sliderRound = 0;
            scope.sliderConfig.sliderDimension = '&nbsp;';
          }
        };

        scope.addProvider = function (provider) {
          provider.used = true;
          scope.selection.SelectedProviders.push(provider);
          scope.providerFilterChanged();
        };

        scope.removeProvider = function (provider) {
          var providerInResult = _.findWhere(scope.providerResults, { Id: provider.Id });
          if (providerInResult !== undefined) {
            providerInResult.used = false;
          }
          var index = scope.selection.SelectedProviders.indexOf(_.findWhere(scope.selection.SelectedProviders, { Id: provider.Id }));
          scope.selection.SelectedProviders.splice(index, 1);
          scope.providerFilterChanged();
        };

        scope.loading
        .then(function (results) {
          var filterValueSelections = scope.filterValueSelections;
          var parentFilterValueSelections = results[0];
          var criteria = results[1];
          var providerSpecialties = results[2];

          scope.applySliderSettings(criteria);
          populateBooleanTypeLookUps(criteria);
          setupProviderSpecialties(providerSpecialties);
          scope.listState = listStateSvc.get();
          setDateRangeSelections();
          setSelectedProviders(filterValueSelections);
          console.log('setSelectedProviders');
          setRecipeDefaultValueSelections(criteria, parentFilterValueSelections);

          var checkedInRecipe = checkedInRecipeFactory(parentFilterValueSelections);
          var uncheckedByList = uncheckedByListFactory(filterValueSelections);

          Object.keys(criteria).forEach(function (key) {
            scope.selection[key] = _.map(criteria[key], function (choice) {
              var checkboxlistModel = {
                checked: checkedInRecipe(key, choice) && !uncheckedByList(key, choice),
                disabled: scope.disableCheckbox || !checkedInRecipe(key, choice),
                text: choice.Name,
                value: choice._id,
                changed: function (checked) {
                  var listFilterValueSelection =
                    _.find(filterValueSelections, { FilterName: key });

                  if (!listFilterValueSelection) {
                    listFilterValueSelection = { FilterName: key };
                    filterValueSelections.push(listFilterValueSelection);
                  }

                  listFilterValueSelection = _.defaults(listFilterValueSelection, {
                    ExcludeValues: [],
                    IncludeValues: []
                  });

                  if (checked) {
                    listFilterValueSelection.ExcludeValues = _.filter(listFilterValueSelection.ExcludeValues, function (val) {
                      return val !== buildChoiceId(choice._id);
                    });

                    if (listFilterValueSelection.ExcludeValues.length === 0) {
                      filterValueSelections.splice(_.findIndex(filterValueSelections, function (x) {
                        return x === listFilterValueSelection;
                      }), 1);
                    }
                  } else if (!_.contains(listFilterValueSelection.ExcludeValues, choice._id)) {
                    listFilterValueSelection.ExcludeValues.push(buildChoiceId(choice._id));
                  }
                }
              };
              return checkboxlistModel;
            });
          });
        });

        function setupProviderSpecialties(providerSpecialties) {
          scope.providerSearch.Specialties = _.map(providerSpecialties, function (ps) {
            return _.extend(ps, {
              'value': ps.Id,
              'text': ps.Name,
              'checked': false,
              'changed': function () {
                scope.providerSearch.SelectedSpecialties = _.where(scope.providerSearch.Specialties, { 'checked': true });
              }
            });
          });
        }

        function checkedInRecipeFactory(parentFilterValueSelections) {

          var findByName = function (name) {
            return _.find(parentFilterValueSelections, function (valueSelection) {
              return valueSelection.FilterName === name;
            });
          };

          return function (criteriaName, choice) {
            var recipeFilterValueSelection = findByName(criteriaName);

            if (choice._id !== null) {
              return !recipeFilterValueSelection || ((recipeFilterValueSelection.Values === null ||
                (_.isArray(recipeFilterValueSelection.Values) &&
                (recipeFilterValueSelection.Values.length === 0 ||
                recipeFilterValueSelection.Values.indexOf(choice._id) !== -1 || recipeFilterValueSelection.Values.indexOf(choice._id.toString()) !== -1))));
            }
            return !recipeFilterValueSelection || ((recipeFilterValueSelection.Values === null ||
              (_.isArray(recipeFilterValueSelection.Values) &&
              (recipeFilterValueSelection.Values.length === 0 ||
              recipeFilterValueSelection.Values.indexOf(choice._id) !== -1))));
          };
        }

        /**
        * Returns a function that takes a criteria name and a choice.
        * The function returns `true` if the `filterValueSelections`
        * contains an entry excluding this filter.
        */
        function uncheckedByListFactory(filterValueSelections) {

          return function (criteriaName, choice) {
            var listFilterValueSelection =
            _.find(filterValueSelections, { FilterName: criteriaName });

            return listFilterValueSelection && !_.isEmpty(listFilterValueSelection.ExcludeValues) &&
            _.contains(listFilterValueSelection.ExcludeValues, buildChoiceId(choice._id));
          };
        }

        scope.showProviderSpecialty = function (ProviderSpecialtyId) {
          var specialty = _.findWhere(scope.providerSearch.Specialties, { value: ProviderSpecialtyId }).text;
          if (specialty) {
            return specialty;
          }
        };

        scope.toggleSelectAll = function () {
          scope.toggleSpecialties = !scope.toggleSpecialties;
          _.each(scope.providerSearch.Specialties, function (checkbox) {
            if (checkbox.disabled !== true) {
              checkbox.checked = scope.toggleSpecialties;
            }
          });
          if (scope.toggleSpecialties) {
            scope.providerSearch.SelectedSpecialties = scope.providerSearch.Specialties;
          }
          else {
            scope.providerSearch.SelectedSpecialties = [];
          }
          scope.enableButton();
        };

        var buildChoiceId = function (id) {

          var retVal;
          switch (typeof (id)) {
            case 'number':
              retVal = id.toString();
              break;
            case 'boolean':
              retVal = (id === true) ? 'True' : 'False';
              break;
            default:
              retVal = id;

          }
          return retVal;
        };


        scope.getValue = function (collection) {
          var valueItems = [];
          if (collection) {
            for (var i = 0; i < collection.length; i = i + 1) {
              valueItems.push(buildChoiceId(collection[i]._id));
            }
          }
          return valueItems;
        };

        var markIfProviderUsed = function (providerResults) {
          var excluedProviderIds = _.pluck(scope.selection.SelectedProviders, 'Id');
          _.each(providerResults, function (provider) {
            if (provider) {
              provider.used = _.contains(excluedProviderIds, provider.Id);
            }
          });
          return providerResults;
        };

        function setRecipeDefaultValueSelections(criteria, parentFilterValueSelections) {
          parentFilterValueSelections.PrimaryLanguage = scope.getValue(criteria.PrimaryLanguage);
          parentFilterValueSelections.HealthSystemEmployee = scope.getValue(criteria.HealthSystemEmployee);
          parentFilterValueSelections.Occupation = scope.getValue(criteria.Occupation);
          parentFilterValueSelections.ValidEmail = scope.getValue(criteria.ValidEmail);
          parentFilterValueSelections.ValidAddress = scope.getValue(criteria.ValidAddress);
          parentFilterValueSelections.HomeOwnership = scope.getValue(criteria.HomeOwnership);
          parentFilterValueSelections.HomeValue = scope.getValue(criteria.HomeValue);
          parentFilterValueSelections.EducationLevel = scope.getValue(criteria.EducationLevel);
          parentFilterValueSelections.HasPrimaryCarePhysician = scope.getValue(criteria.HasPrimaryCarePhysician);
          parentFilterValueSelections.DonateToCharity = scope.getValue(criteria.DonateToCharity);
          parentFilterValueSelections.PatientType = scope.getValue(criteria.PatientType);
          parentFilterValueSelections.ERUtilization = scope.getValue(criteria.ERUtilization);
          parentFilterValueSelections.EncounterSourceType = scope.getValue(criteria.EncounterSourceType);
          parentFilterValueSelections.DwellingType = scope.getValue(criteria.DwellingType);
          parentFilterValueSelections.HouseholdIncomeGroup = scope.getValue(criteria.HouseholdIncomeGroup);
          parentFilterValueSelections.MedicalServiceVisits = scope.getValue(criteria.MedicalServiceVisits);
          parentFilterValueSelections.PresenceOfChildren = scope.getValue(criteria.PresenceOfChildren);
          parentFilterValueSelections.PhysicianType = [];
          parentFilterValueSelections.Specialty = [];
        }

        function populateBooleanTypeLookUps(criteria) {
          criteria.PresenceOfChildren = scope.booleanValues;
          criteria.HealthSystemEmployee = scope.booleanValues;
          criteria.HasPrimaryCarePhysician = scope.booleanValues;
          criteria.DonateToCharity = scope.booleanValues;
          criteria.ValidAddress = scope.yesNoValues;
          criteria.ValidEmail = scope.yesNoValues;
        }
        scope.getFilterValueByName = function (FilterName) {
          var filterValues = {};
          var listStateFilterValues = {};
          if (scope.filterValueSelections) {
            filterValues = _.find(scope.filterValueSelections, { FilterName: FilterName });
          }
          if (scope.listState) {
            listStateFilterValues = _.find(scope.listState.FilterValueSelections, { FilterName: FilterName });
          }
          return filterValues ? filterValues : listStateFilterValues;
        };

        function setDateRangeSelections() {
          var filterValueSelection = scope.getFilterValueByName('PatientDateRange');
          if (filterValueSelection && filterValueSelection.IncludeValues) {
            scope.selection.PatientDateRange = filterValueSelection.IncludeValues;
          }

          filterValueSelection = scope.getFilterValueByName('ProviderDateRange');
          if (filterValueSelection && filterValueSelection.ExcludeValues) {
            scope.selection.ProviderDateRange = filterValueSelection.ExcludeValues;
          }

          if (!scope.selection.PatientDateRange) { scope.selection.PatientDateRange = ['', '']; }
          if (!scope.selection.ProviderDateRange) { scope.selection.ProviderDateRange = ['', '']; }
        }

        function setSelectedProviders(filterValueSelections) {
          var filterValueSelection = _.find(filterValueSelections, { FilterName: 'ProviderEncounters' });
          if (filterValueSelection) {
            var selectedProviders = filterValueSelection.ExcludeValues || [];

            scope.selection.ProviderDateRange[0] = filterValueSelection.toDate;
            scope.selection.ProviderDateRange[1] = filterValueSelection.fromDate;

            var message = {
              Ids: selectedProviders
            };
            providerSvc.getProvidersById(message).then(function (providersData) {
              scope.selection.SelectedProviders = providersData;
            });
          }
          if (!scope.selection.SelectedProviders) { scope.selection.SelectedProviders = []; }
        }

        var filtersThatRequirePatientDateRange = ['ERUtilization', 'PatientType', 'PhysicianType', 'EncounterSourceType'];

        scope.applyPatientDateRange = function () {
          _.each(scope.filterValueSelections, function (filter) {
            if (_.contains(filtersThatRequirePatientDateRange, filter.FilterName) && scope.selection.PatientDateRange) {
              filter.fromDate = scope.selection.PatientDateRange[0];
              filter.toDate = scope.selection.PatientDateRange[1];
            }
          });
        };

        scope.patientDateRangeChanged = function () {
          dateRangeChanged('PatientDateRange', scope.selection.PatientDateRange, true);
        };

        var dateRangeChanged = function (filterName, selectionDateRange, doInclude) {
          var filterValueSelection = _.find(scope.filterValueSelections, { FilterName: filterName });
          if ((!selectionDateRange[0] || selectionDateRange[0] === '') &&
            (!selectionDateRange[1] || selectionDateRange[1] === '')) {
            if (filterValueSelection) {
              scope.filterValueSelections.splice(_.indexOf(scope.filterValueSelections, filterValueSelection), 1);
              return;
            }
          } else {
            if (filterValueSelection) {
              if (doInclude) {
                filterValueSelection.IncludeValues = [selectionDateRange[0], selectionDateRange[1]];
              } else {
                filterValueSelection.ExcludeValues = [selectionDateRange[0], selectionDateRange[1]];
              }
            } else {
              var newFilter = {
                IncludeValues: doInclude ? [selectionDateRange[0], selectionDateRange[1]] : [],
                ExcludeValues: doInclude ? [] : [selectionDateRange[0], selectionDateRange[1]],
                FilterName: filterName
              };
              scope.filterValueSelections.push(newFilter);
            }
          }
        };

        scope.providerFilterChanged = function () {
          var filterName = 'ProviderEncounters';
          var selectionDateRange = scope.selection.ProviderDateRange;
          var selectedProviderIds = _.pluck(scope.selection.SelectedProviders, 'Id');

          var filterValueSelection = _.find(scope.filterValueSelections, { FilterName: filterName });
          if ((!selectionDateRange[0] || selectionDateRange[0] === '') &&
            (!selectionDateRange[1] || selectionDateRange[1] === '') &&
            (selectedProviderIds.count === 0)) {
            if (filterValueSelection) {
              scope.filterValueSelections.splice(_.indexOf(scope.filterValueSelections, filterValueSelection), 1);
              return;
            }
          } else {
            if (filterValueSelection) {
              filterValueSelection.ExcludeValues = selectedProviderIds;
              filterValueSelection.toDate = selectionDateRange[1];
              filterValueSelection.fromDate = selectionDateRange[0];
            } else {
              var newFilter = {
                IncludeValues: [],
                FilterName: filterName,
                ExcludeValues: selectedProviderIds,
                toDate: selectionDateRange[1],
                fromDate: selectionDateRange[0]
              };
              scope.filterValueSelections.push(newFilter);
            }
          }
        };

        scope.doProviderSearch = function () {
          scope.providersLoading = providerSvc.findProviders({
            'ProviderInfo': {
              'Id': scope.providerSearch.NPINumber === '' ? 0 : scope.providerSearch.NPINumber,
              'FirstName': scope.providerSearch.FirstName === '' ? '' : scope.providerSearch.FirstName,
              'MiddleName': '',
              'LastName': scope.providerSearch.LastName,
              'ProviderSpecialtyId': 0
            },
            'SpecialtyIds': _.pluck(scope.providerSearch.SelectedSpecialties, 'Id')
          }).then(function (providersData) {
            scope.providerResults = markIfProviderUsed(providersData);
          });
        };

        scope.isPatientDateRange = function () {
          var ERUtilization = scope.getFilterValueByName('ERUtilization');
          var PatientType = scope.getFilterValueByName('PatientType');
          var PhysicianType = scope.getFilterValueByName('PhysicianType');
          var EncounterSourceType = scope.getFilterValueByName('EncounterSourceType');

          if (angular.isUndefined(ERUtilization) && angular.isUndefined(PatientType) && angular.isUndefined(PhysicianType) && angular.isUndefined(EncounterSourceType)) {
            scope.isPatientDateRangeDisabled = true;
          }
          else {
            scope.isPatientDateRangeDisabled = false;
          }
        };

        scope.$watch('selection', function () {
          scope.$emit('selectionsChanged', scope.filterValueSelections);
          scope.applyPatientDateRange();
          scope.isPatientDateRange();
        }, true);
      }
    };
  }]);

})(window.app);
