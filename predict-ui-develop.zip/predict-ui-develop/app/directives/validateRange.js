﻿(function (app) {
  'use strict';

  app.directive('validateRange', function () {
    return {
      require: '?ngModel',
      restrict: 'A',
      link: function (scope, element, attrs, ngModel) {
        if (!ngModel) {
          return;
        }
        var validate = function (value) {
          if (typeof (value) !== 'undefined' && value > 0 && value <= 50) {
            ngModel.$setValidity('validrange', true);
          } else {
            ngModel.$setValidity('validrange', false);
          }
        };
        scope.$watch(attrs.ngModel, function (newValue) {
          validate(newValue);
        });
        element.bind('blur keydown keyup change', function () {
          validate(element[0].value);
        });
       
      }
    };
  });

})(window.app);