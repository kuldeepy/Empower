(function (app) {
  'use strict';

  app.directive('zipCodesTable', function () {
    return {
      restrict: 'E',
      scope: {
        radiusData: '=',
        availableZips: '=',
        excludedZips: '=',
        radiusZips: '='
      },
      templateUrl: '/templates/zip-codes-table.html',
      link: function (scope) {
        var radius = scope.radiusData;

        scope.changeStatus = function (zipId, action) {
          if (action.toUpperCase() === 'INCLUDED') {
            scope.markZipIncluded(zipId);
          }
          else if (action.toUpperCase() === 'EXCLUDED') {
            scope.markZipExcluded(zipId);
          }
          else if (action.toUpperCase() === 'INRADIUS') {
            scope.markZipRadius(zipId);
          }
        };

        scope.markZipExcluded = function (ZipId) {
          radius.SelectedAvailableZipCodeId = ZipId;
          radius.ExcludedZipCodeIds.push(ZipId);
          radius.ExcludedZipCodeIds = _.union(radius.ExcludedZipCodeIds, [radius.SelectedAvailableZipCodeId]);
          if (_.contains(radius.AdditionalZipCodeIds, radius.SelectedAvailableZipCodeId)) {
            radius.AdditionalZipCodeIds = _.difference(radius.AdditionalZipCodeIds, radius.ExcludedZipCodeIds);
          }
          radius.SelectedAvailableZipCodeId = [];
          scope.removeUsedZipCodes();
        };

        scope.markZipIncluded = function (ZipId) {
          radius.SelectedAvailableZipCodeId = ZipId;
          radius.AdditionalZipCodeIds.push(ZipId);
          radius.AdditionalZipCodeIds = _.union(radius.AdditionalZipCodeIds, [radius.SelectedAvailableZipCodeId]);
          if (_.contains(radius.ExcludedZipCodeIds, radius.SelectedAvailableZipCodeId)) {
            radius.ExcludedZipCodeIds = _.difference(radius.ExcludedZipCodeIds, radius.AdditionalZipCodeIds);
          }
          radius.SelectedAvailableZipCodeId = [];
          scope.removeUsedZipCodes();
        };

        scope.markZipRadius = function (ZipId) {
          radius.SelectedZipCodeId = ZipId;
          radius.AvailableZipCodeIds = _.union(radius.AvailableZipCodeIds, [radius.SelectedZipCodeId]);
          if (_.contains(radius.AdditionalZipCodeIds, radius.SelectedZipCodeId)) {
            radius.AdditionalZipCodeIds = _.difference(radius.AdditionalZipCodeIds, radius.AvailableZipCodeIds);
          }
          else if (_.contains(radius.ExcludedZipCodeIds, radius.SelectedZipCodeId)) {
            radius.ExcludedZipCodeIds = _.difference(radius.ExcludedZipCodeIds, radius.AvailableZipCodeIds);
          }
          radius.SelectedAdditionalZipCodeId = [];
          scope.removeUsedZipCodes();
        };

        scope.removeUsedZipCodes = function () {
          radius.AvailableZipCodeIds = _.difference(radius.AvailableZipCodeIds, radius.AdditionalZipCodeIds, radius.ExcludedZipCodeIds);
        };

        scope.restoreDefaultStatus = function () {
          radius.AvailableZipCodeIds = _.union(radius.AvailableZipCodeIds, radius.ExcludedZipCodeIds, radius.AdditionalZipCodeIds);
          radius.ExcludedZipCodeIds = _.difference(radius.ExcludedZipCodeIds, radius.AvailableZipCodeIds);
          radius.AdditionalZipCodeIds = _.difference(radius.AdditionalZipCodeIds, radius.AvailableZipCodeIds);
          scope.removeUsedZipCodes();
        };
      }
    };
  });
})(window.app);
