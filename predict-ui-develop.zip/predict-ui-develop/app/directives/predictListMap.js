(function (app) {
  'use strict';
  /* global L */
  var BASE_CLUSTER_SIZE = 120;
  var CLUSTER_SCATTER = 3;
  app.directive('predictListMap', [ '_', 'listStateSvc', 'geographiesLookupSvc', 'listSvc', '$timeout', '$q',
    function (_, listStateSvc, geographiesLookupSvc, listSvc, $timeout, q) {
    return {
      restrict: 'E',
      replace: true,
      scope: {
        locationDescriptors: '=',
        drawPersonMarkers: '='
      },
      template: '<div><div id="map" class="lb-map-container" cg-busy="mapLoading"></div></div>',
      link: function (scope) {
        scope.mapLoading = false;
        var map = {};
        var locationPinIconSrc = '/images/icons/map-location-pin.png';
        var locationPinIcon = getLocationIcon();
        var legend = L.control({ position: 'bottomright' });
        var metersPerMile = 1609.34;
        var drawnGeoJsonPoints = [];
        var clusterGroups = [];
        var zipCodeData = [];
        var geoLayer = {
          radiusDescriptors: [],
          zipCodes: [],
          locations: []
        };
        var mapColors = {
          green: '#6AA84F',
          yellow: '#FFCD5D',
          red: '#E06666',
          blue: '#6FA8DC',
          purple: '#8E7CC3',
          orange: '#FF9900',
          boldBlue: '#526E83',
          gray: '#333333'
        };
        var excludedZipColor = mapColors.gray;
        var polygonStyle = {
          stroke: true,
          weight: 1,
          opacity: 1,
          fill: true,
          fillOpacity: 0.4,
          className: 'radius'
        };
        var personTypes = [
          'Patient',
          'Family Member',
          'Qualified Prospect',
          'Prospect',
          'New Mover',
          'Orphaned Record'
        ];
        var mapStyles = [
          {
            featureType: 'poi',
            stylers: [
              { visibility: 'off' }
            ]
          },
          {
            featureType: 'poi.medical',
            stylers: [
              { visibility: 'on' }
            ]
          },
          {
            featureType: 'transit',
            stylers: [
              { visibility: 'off' }
            ]
          },
          {
            featureType: 'road.highway',
            elementType: 'geometry',
            stylers: [
              { saturation: -100 },
              { lightness: 55 }
            ]
          },
          {
            featureType: 'road',
            elementType: 'labels.icon',
            stylers: [
              { visibility: 'off' }
            ]
          },
          {
            featureType: 'water',
            stylers: [
              { saturation: -60 }
            ]
          }
        ];

        function getLocationIcon() {
          return L.icon({
            iconUrl: locationPinIconSrc,
            iconSize: [20, 25],
            iconAnchor: [10, 20]
          });
        }

        var initializeGeoLayer = function () {
          _.forEach(scope.locationDescriptors, function (loc) {
            if (loc) {
              //Add locations
              geoLayer.locations.push( {
                'Name': loc.Name,
                'Address': loc.Address,
                'Type': loc.Type
              });
              //Add radii
              _.forEach(loc.RadiusDescriptors, function (radius) {
                if (radius) { geoLayer.radiusDescriptors.push(radius); }
              });
              //Add zip codes
              var arrSelectedZipCodes = [];
              if (loc.SelectedZipCodes.length > 0) {

                arrSelectedZipCodes = loc.SelectedZipCodes;

                _.forEach(arrSelectedZipCodes, function (zipCode) {
                  if (zipCode) {
                    var zipWithArea = {
                      'id': zipCode,
                      'serviceArea': getZipServiceArea(zipCode, loc)
                    };
                    geoLayer.zipCodes.push(zipWithArea);
                  }
                });
              }
            }
          });
        };

        var getZipServiceArea = function (zipCode, loc) {
          var servArea = '';
          if (_.contains(loc.PrimaryServiceAreaZipCodes, zipCode)) { servArea = 'Primary'; }
          else if (_.contains(loc.SecondaryServiceAreaZipCodes, zipCode)) { servArea = 'Secondary'; }
          else if (_.contains(loc.TertiaryServiceAreaZipCodes, zipCode)) { servArea = 'Tertiary'; }
          return servArea;
        };

        var addZipCodeGeoJson = function (zipsWithGeoJson) {
          _.forEach(geoLayer.zipCodes, function (zip) {
            var zipWithGeoJson = _.find(zipsWithGeoJson, { 'Id': zip.id });
            if (zipWithGeoJson) { _.extend(zip, { 'GeoJSON': zipWithGeoJson.GeoJSON }); }
          });
        };

        var createMap = function () {
          var googleLayer = new L.Google('ROADMAP', { mapOptions: { styles: mapStyles }});
          map = L.map('map', {
            attributionControl: false,
            zoomControl: false,
            panControl: false,
            center: reverseCoordinates(scope.locationDescriptors[0].Address.GeoJson.Coordinates),
            layers: googleLayer,
            zoom: 10
          });
        };

        var initializeMap = function () {
          initializeGeoLayer();
          new L.control.zoom({ position: 'topleft' }).addTo(map);
          legend.addTo(map);
          var allZips = [];
          var includedZips = [];
          var excludedZips = [];

          if (geoLayer.radiusDescriptors && geoLayer.radiusDescriptors.length > 0) {
            addRadii();
            _.forEach(geoLayer.radiusDescriptors, function (radDesc) {
              allZips = _.union(allZips, radDesc.AdditionalZipCodeIds, radDesc.ExcludedZipCodeIds);
              includedZips = _.union(includedZips, radDesc.AdditionalZipCodeIds);
              excludedZips = _.union(excludedZips, radDesc.ExcludedZipCodeIds);
            });
          }
          if (geoLayer.zipCodes && geoLayer.zipCodes.length > 0) {
            allZips = _.union(allZips, _.pluck(geoLayer.zipCodes, 'id'));
          }

          addLocationPins();
          addRadiusPins();
          configurePersonLayers();

          scope.mapLoading = getZipCodeData(allZips)
          .then(function(zipCodeData) {
            addZipCodeGeoJson(zipCodeData);
            addZipCodes();
            addRadiusZipCodes(includedZips, excludedZips);
            setMapBounds();
          });
          
          if (scope.drawPersonMarkers) {
            var listCopy = _.extend({}, listStateSvc.get(), { 'LocationDescriptors': scope.locationDescriptors });
            var markers = listSvc.scrollPersonMarkersInBatches(listCopy, 1000000, addPersonMarkers);
            scope.mapLoading = q.all([scope.mapLoading, markers]);
          }

          $timeout(function() {
            angular.element('.map-legend').on('click', function(){
              if(angular.element('#legend-toggle-inner').hasClass('rotate-down')) {
                angular.element('.map-legend-content').slideUp('slow');
                angular.element('#legend-toggle-inner').removeClass('rotate-down');
                angular.element('.map-legend-header').css('background-color', 'rgba(255, 255, 255, 0.7)');
              }
              else {
                angular.element('.map-legend-content').slideDown('slow');
                angular.element('#legend-toggle-inner').addClass('rotate-down');
                angular.element('.map-legend-header').css('background-color', 'rgba(255, 255, 255, 1)');
              }
            });
          }, 1000);
        };

        function getZipCodeData(allZips) {
          if (allZips.length) {
            return geographiesLookupSvc.getZipCodesById({
              'ZipCodes': allZips,
              'IncludeGeoJSON': true
            });
          }
          var emptyResponse = q.defer();
          emptyResponse.resolve([]);
          return emptyResponse.promise;
        }

        function configurePersonLayers() {
          if (!scope.drawPersonMarkers) { return; }

          PruneCluster.Cluster.ENABLE_MARKERS_LIST = true;
          //Create cluster groups
          _.forEach(personTypes, function (personType, i) {
            //Random size scatter to fend off overlapping markers
            var clusterSize = BASE_CLUSTER_SIZE + (i * CLUSTER_SCATTER);
            clusterGroups.push(createClusterGroup(personType, clusterSize));
          });
          _.forEach(clusterGroups, function (clusterGroup) {
            map.addLayer(clusterGroup);
          });
        }

        var addPersonMarkers = function (personHits) {
          if (!scope.drawPersonMarkers) { return; }
          //Add markers
          _.forEach(personHits, function (hit) {
            var personType = getPersonTypeString(hit._source.personType);
            var clusterMarker = new PruneCluster.Marker(hit._source.location.lat, hit._source.location.lon, { icon: createIcon }, personType);
            var clusterIndex = personTypes.indexOf(personType);
            clusterGroups[clusterIndex].RegisterMarker(clusterMarker);
          });
          _.forEach(clusterGroups, function (clusterGroup) {
            clusterGroup.ProcessView();
          });
        };

        //This method assumes any geoJson points from radii or service area polygons have already
        //been added to drawnGeoJsonPoints.
        var setMapBounds = function () {
          if (drawnGeoJsonPoints && drawnGeoJsonPoints.length > 0) {
            map.fitBounds(drawnGeoJsonPoints, {
              paddingBottomRight: [20, 20],
              paddingTopLeft: [20, 20]
            });
          }
          map.invalidateSize();
        };

        var milesToMeters = function (miles) {
          return miles * metersPerMile;
        };

        var getZipColor = function (serviceArea) {
          switch(serviceArea) {
            case 'Primary':
              return mapColors.green;
            case 'Secondary':
              return mapColors.purple;
            case 'Tertiary':
              return mapColors.orange;
            default:
              return mapColors.yellow;
          }
        };
        var getZipPopoverColor = function (serviceArea) {
          switch(serviceArea) {
            case 'Primary':
              return 'green';
            case 'Secondary':
              return 'purple';
            case 'Tertiary':
              return 'orange';
            default:
              return 'yellow';
          }
        };

        var getZipClassName = function (serviceArea) {
          switch(serviceArea) {
            case 'Primary':
              return 'primary';
            case 'Secondary':
              return 'secondary';
            case 'Tertiary':
              return 'tertiary';
            default:
              return 'unknown-service-area';
          }
        };

        var getPersonTypeString = function (personTypeId) {
          switch(personTypeId) {
            case 'C': //Patients
              return 'Patient';
            case 'N': //New Movers
              return 'New Mover';
            case 'P': //Prospects
              return 'Prospect';
            case 'Q': //Qualified Prospects
              return 'Qualified Prospect';
            case 'F': //Family Member
              return 'Family Member';
            case '': //Orphaned Record
              return 'Orphaned Record';
            default:
              return 'Unknown Person';
          }
        };

        var addRadii = function () {
          if (geoLayer.radiusDescriptors === undefined || geoLayer.radiusDescriptors === null || geoLayer.radiusDescriptors.length === 0) { return; }
          if (geoLayer.radiusDescriptors.length > 1) {
            geoLayer.radiusDescriptors = _.sortBy(geoLayer.radiusDescriptors, 'RadiusInMiles');
          }
          _.forEachRight(geoLayer.radiusDescriptors, function (radiusDescriptor) {
            if (radiusDescriptor) { addRadius(radiusDescriptor); }
          });
        };

        var reverseCoordinates = function (coords) {
          return [ coords[1], coords[0] ];
        };

        var addRadius = function (radiusDescriptor) {
          var coords = radiusDescriptor.Address.GeoJson.Coordinates;
          if (coords && radiusDescriptor.RadiusInMiles) {
            var latLng = reverseCoordinates(coords); //GeoJSON uses LngLat format, need LatLng for leaflet
            var circle = L.circle(latLng, milesToMeters(radiusDescriptor.RadiusInMiles), _.extend({}, polygonStyle, { 'color': mapColors.red, 'fillOpacity': 0.3 }));
            circle.bindPopup(radiusDescriptor.RadiusInMiles.toString() + ' mile radius.', {className: 'red' });
            circle.addTo(map);
            drawnGeoJsonPoints.push(circle.getBounds());
          }
        };

        var addRadiusZipCodes = function (AdditionalZipCodeIds, excludedZipCodeIds) {
          addExcludedZipCodes(excludedZipCodeIds);
          addIncludedZipCodes(AdditionalZipCodeIds);
        };

        var addExcludedZipCodes = function (excludedZipCodeIds) {
          _.forEach(excludedZipCodeIds, function (zipId) {
            var zipObject = _.find(zipCodeData, { 'Id': zipId });
            if (!zipObject) { return; }
            var popupText = '' + zipObject.Id + ' - Excluded from Radius';
            addGeoJsonLayer(zipObject.GeoJSON, popupText, _.extend({}, polygonStyle, { 'color': excludedZipColor, 'fillOpacity': 0.5, 'className': 'zip excluded' }), 'red');
          });
        };

        var addIncludedZipCodes = function (AdditionalZipCodeIds) {
          _.forEach(AdditionalZipCodeIds, function (zipId) {
            var zipObject = _.find(zipCodeData, { 'Id': zipId });
            if (!zipObject) { return; }
            var popupText = '' + zipObject.Id + ' - Included in Radius';
            addGeoJsonLayer(zipObject.GeoJSON, popupText, _.extend({}, polygonStyle, { 'color': mapColors.red, 'className': 'zip included' }), 'red');
          });
        };

        var addZipCodes = function () {
          _.forEach(geoLayer.zipCodes, function (zip) {
            if (zip.GeoJSON) { addZipCode(zip); }
          });
        };

        var addZipCode = function (zipCode) {
          if (zipCode.GeoJSON.geometry.coordinates[0] && zipCode.serviceArea) {
            var popupText = '' + zipCode.id + ' - ' + zipCode.serviceArea + ' Service Area';
            addGeoJsonLayer(zipCode.GeoJSON, popupText, _.extend({}, polygonStyle, { 'color': getZipColor(zipCode.serviceArea), 'className': 'zip service-area '+getZipClassName(zipCode.serviceArea) }), getZipPopoverColor(zipCode.serviceArea));
          }
        };

        var addGeoJsonLayer = function (geoJSON, popupText, style, popoverColor) {
          var geoLayer = L.geoJson(geoJSON, {
            style: _.extend({}, style, { 'fillColor': style.color })
          });
          geoLayer.bindPopup(popupText, {className: popoverColor });
          drawnGeoJsonPoints.push(geoLayer.getBounds());
          geoLayer.addTo(map);
        };

        function createIcon(data, category, cnt) {
          return L.divIcon({ html: cnt || 1, className: getClusterMarkerClass(category), iconSize: L.point(25, 25) });
        }

        var createClusterGroup = function (personType, clusterSize) {
          var pruneCluster = new PruneClusterForLeaflet(clusterSize || BASE_CLUSTER_SIZE);
          pruneCluster.BuildLeafletClusterIcon = function(cluster) {
            return createIcon(null, personType, cluster.population);
          };

          pruneCluster.BuildLeafletCluster = function(cluster, position) {
            var marker = PruneClusterForLeaflet.prototype.BuildLeafletCluster.call(pruneCluster, cluster, position);
            //Show and hide bounds hull
            marker.on('mouseover', function() {
              var hull = L.QuickHull.getConvexHull(_.map(cluster._clusterMarkers, 'position'));
              marker._shownPolygon = new L.Polygon(hull, _.extend({}, polygonStyle, { 'color': mapColors.blue }));
              map.addLayer(marker._shownPolygon);
            });

            marker.on('mouseout', function() {
              map.removeLayer(marker._shownPolygon);
            });

            return marker;
          };
          return pruneCluster;
        };

        var getClusterMarkerClass = function (personType) {
          switch (personType) {
            case 'Patient':
              return 'cluster-marker patient';
            case 'Family Member':
              return 'cluster-marker family-member';
            case 'Qualified Prospect':
              return 'cluster-marker qualified-prospect';
            case 'Prospect':
              return 'cluster-marker prospect';
            case 'New Mover':
              return 'cluster-marker new-mover';
            case 'Orphaned Record':
              return 'cluster-marker orphaned-record';
            default:
              return '';
          }
        };

        var addLocationPins = function () {
          _.forEach(geoLayer.locations, function (location) {
            if (location && location.Address && location.Type.toUpperCase()==='SERVICEAREA') {
              var coords = reverseCoordinates(location.Address.GeoJson.Coordinates);
              drawPin(coords, location.Name);
              drawnGeoJsonPoints.push(coords);
            }
          });
        };
        var addRadiusPins = function () {
          _.forEach(geoLayer.radiusDescriptors, function (radius) {
            if (radius && radius.Address) {
              var coords = reverseCoordinates(radius.Address.GeoJson.Coordinates);
              if (radius.IsCustomAddress) {
                drawPin(coords, radius.FormattedAddress);
              } else {
                drawPin(coords, radius.Name);
              }
              drawnGeoJsonPoints.push(coords);
            }
          });
        };

        var drawPin = function (latLng, popupMessage) {
          var marker = L.marker(latLng, {icon: locationPinIcon});
          marker.bindPopup(popupMessage, {
            offset: [0, -10],
            className: 'orange'
          });
          marker.addTo(map);
        };

        legend.onAdd = function () {
          var htmlString = '';
          var div = L.DomUtil.create('div', 'map-legend'),
            items = [
              { 'label':'Patient', 'color': mapColors.green },
              { 'label':'Family Member', 'color': mapColors.yellow },
              { 'label':'Qualified Prospect', 'color': mapColors.red },
              { 'label':'Prospect', 'color': mapColors.blue },
              { 'label':'New Mover', 'color': mapColors.purple }
            ];

          htmlString += '<div class="map-legend-header">Legend<span id="legend-toggle-button" class="pull-right"><span class="round-icon small"><span class="border"></span><img src="/images/icons/icon_arrow-down.png" id="legend-toggle-inner" alt="arrow" class="icon may-rotate" /></span></span></div><div class="map-legend-content"><ul class="map-legend-list">';
          htmlString += '<li class="legend-separator-bottom"><img src="' + locationPinIconSrc + '" class="map-legend-location-image"/><span class="map-legend-item-label">Location</span></li>';
          for (var i = 0; i < items.length; i=i+1) {
            htmlString +=
              '<li><div class="map-legend-circle" style="background-color:' + items[i].color + '"></div><span class="map-legend-item-label">' + items[i].label + '</span></li>';
          }
          htmlString += '<li class="legend-separator-top"><div class="map-legend-square primary"></div><span class="map-legend-item-label">Primary</span></li>';
          htmlString += '<li><div class="map-legend-square secondary"></div><span class="map-legend-item-label">Secondary</span></li>';
          htmlString += '<li><div class="map-legend-square tertiary"></div><span class="map-legend-item-label">Tertiary</span></li>';
          htmlString += '<li><div class="map-legend-square excluded"></div><span class="map-legend-item-label">Excluded</span></li>';
          htmlString += '<li><div class="map-legend-square radius"></div><span class="map-legend-item-label">Radius</span></li>';
          htmlString += '</ul></div>';
          div.innerHTML = htmlString;
          return div;
        };

        createMap();
        initializeMap();
      }
    };
  }]);
})(window.app);