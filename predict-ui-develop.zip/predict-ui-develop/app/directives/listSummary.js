(function (app) {
  'use strict';

  app.directive('listSummary', ['$http', 'baseApiUrl', 'listStateSvc', 'filterTypeSvc', 'providerSvc', '$timeout', 'recipeSvc', 'tabAndStepDefinitions', 'geographyHelper', 'targetAreasColumn', 'pastListSvc', 'seedListSvc', '$filter', '_', 'facilitySvc', 'sessionSvc', 'lookupSvc', 'alertSvc', 'listSvc', 'userContextSvc', 'clientSvc', 'etlDataUpdateSvc', '$rootScope',
  function ($http, baseApiUrl, listStateSvc, filterTypeSvc, providerSvc, $timeout, recipeSvc, getTabAndStepDefinitions, geographyHelper, targetAreasColumn, pastListSvc, seedListSvc, filter, _, facilitySvc, sessionSvc, lookupSvc, alertSvc, listSvc, userContextSvc, clientSvc, etlDataUpdateSvc, $rootScope) {
    return {
      restrict: 'E',
      scope: { enableEdit: '=', quickCounts: '=', listItem: '=', breadcrumb: '=', quickCountLoading:'=' },
      templateUrl: '/modules/listBuild/Views/listSummary.html',
      link: function (scope) {

        var pastListInclusions = 'pastLists.included';
        var tabAndStepDefinitions = getTabAndStepDefinitions();
        var tabDefinitions = tabAndStepDefinitions.tabs;
        var listState = {};
        scope.clientKey = userContextSvc.getClientKey();
        scope.incompleteSteps = [];
        scope.warningData = undefined;
        scope.isSummaryStep = true;

        var loading = function (list) {
          listState = list;
          listState.InExclusionPastListIds = [];

          if (listState.UseLocationLogic === false) {
            scope.isLimitToGeography = false;
          } else {
            scope.isLimitToGeography = true;
          }
          if (listState.Name || listState.MarketingChannelId !== 0 || scope.listItem.Name) {
            getMarketingChannels();
            getSelectedRecipeName();
            getMetaData();
            getFacilityData();
            manageListdata();
            refineCriteriaData();
            manageSegmentData();
            getPrioritizeData();
          }
          getlistName();
          
          scope.ControlGroup = ((!listState.CurrentUIState.isControlGroupDirty && listState.ExcludeHoldouts) || listState.CurrentUIState.isControlGroupDirty) ? 'Control Group Used' : 'Control Group Not Used';
          scope.selectedPrioritizeCountType = listState.DistributeByHousehold ? 'Households' : 'Individuals';
          scope.pulledDate = listState.PullDate;
          scope.hasVisitedStep = listState.CurrentUIState.hasVisited;

          //Handling warnings for incomplete steps
          showWarningForIncompleteSteps(listState);
        };

        scope.$watch('listItem.Name', function () {
          getlistName();
          scope.dataAvailable(true);
        });

        var getlistName = function () {
          if (scope.enableEdit) {
            if (scope.listItem.Name) {
              scope.listMetaName = scope.listItem.Name;
            }
          }
          else {
            scope.listMetaName = listState.Name;
          }
          listSvc.currentListName.set(scope.listMetaName);
        };

        //Handling warnings for incomplete steps
        var showWarningForIncompleteSteps = function (listState) {
          alertSvc.removeAll();
          var promise = etlDataUpdateSvc.handleETLUpdates(listState, userContextSvc.getClientKey());
          promise.then(function (hasCountUpdated) {
            if (hasCountUpdated && !listStateSvc.isMarketingChannelNotDefined) {
              angular.extend(listState.CurrentUIState, {
                countUpdateStatus: 'Update'
              });
              alertSvc.add({ Type: 'Error', Title: 'Required steps have not been completed.', Source: 'UpdateCount', Message: 'Your data has been updated since this list was saved. The counts are no longer valid. Please update the counts and revise the Targeting step to complete this list.' });
            }
            else
            {
              hasStepscompleted();
            }
          });
        };

        $rootScope.$on('stepscompleted', function () {
          hasStepscompleted();
        });

        var hasStepscompleted = function () {
          scope.incompleteSteps = [];
          alertSvc.removeAll();
          if ((listState.CurrentUIState && listState.CurrentUIState.isComplete === true && (!listState.MarketingChannelId || listState.MarketingChannelId === 0)) && listState.PullDate === null && scope.listMetaName) {
            scope.incompleteSteps = [{
              index: '1',
              TargetUrl: 'listName',
              TargetPage: 'Define List'
            }];
            alertSvc.add({ Type: 'Error', Title: 'Required steps have not been completed.', Source: 'marketingChannelNotSelected', Message: 'The marketing channel is now a required field for all lists. Please select a marketing channel and revise Targeting to complete this list:', IncompleteSteps: scope.incompleteSteps });
            listStateSvc.isMarketingChannelNotDefined = true;
          }
          else if ((!listState.PullDate && listState.CurrentUIState && (!listState.CurrentUIState.isComplete || listState.CurrentUIState.isComplete === false)) || !scope.listMetaName) {
            scope.incompleteSteps = _.filter(tabDefinitions, function (tab) {
              return tab.completed() !== true && tab.name !== 'summary';
            });
            if (scope.incompleteSteps.length > 0) {
              alertSvc.add({ Type: 'StepIncompleteWarning', Title: 'Required steps have not been completed.', Source: 'IncompleteSteps', Message: 'The following steps are required to complete this list:', IncompleteSteps: scope.incompleteSteps });
            }
          }
        };

        scope.locations = [];
        scope.includedPastList = [];
        scope.pastListInclusion = [];
        scope.selectedSeedLists = [];
        scope.segments = [];
        scope.waiting = [];
        scope.listCountDocLoading = false;

        // PAST LIST IUI-TABLE
        scope.summaryTablePastListsData = {
          gridData: [],
          gridColumn: [
            {
              field: 'actionValue',
              displayName: 'Action'
            },
            {
              field: 'campaignId',
              displayName: 'Campaign ID'
            },
            {
              field: 'Name',
              displayName: 'List Name'
            },
            {
              field: 'DatePulled',
              displayName: 'Start Date'
            }
          ],
          emptyDataMessage: 'No Past Lists used'
        };

        // SEED LIST IUI-TABLE
        scope.summaryTableSeedListsData = {
          gridData: [],
          gridColumns: [
            {
              field: 'SeedListName',
              displayName: 'Seed List'
            },
            {
              field: 'DateModified',
              displayName: 'Date Modified'
            }
          ],
          emptyDataMessage: 'No Seed Lists were used.'
        };

        // MANAGE SEGMENTS IUI-TABLE
        scope.summaryTableManageSegmentsData = {
          gridData: [],
          gridColumn: [
            {
              field: 'Name',
              displayName: 'Segment Name'
            },
            {
              field: 'UpdatedOn',
              displayName: 'Date Modified'
            },
            {
              field: 'HouseholdTotalCount',
              displayName: 'Households'
            },
            {
              field: 'IndividualTotalCount',
              displayName: 'Individuals'
            }
          ],
          emptyDataMessage: 'No segment created'
        };

        scope.canShowSummarySection = function (serviceAreaText) {
          return serviceAreaText && serviceAreaText.toString().toUpperCase() !== 'NO';
        };
        scope.individualTotal = function (segment) {

          var calculation = scope.quickCounts;

          if (!calculation) {
            return '?';
          }

          var calculationForSegment = _.find(calculation, { segmentName: segment.Name });
          if (!calculationForSegment) {
            return '?';
          }

          return calculationForSegment.totalCountForIndividual;
        };

        scope.householdTotal = function (segment) {
          var calculation = scope.quickCounts;

          if (!calculation) {
            return '?';
          }

          var calculationForSegment = _.find(calculation, { segmentName: segment.Name });
          if (!calculationForSegment) {
            return '?';
          }
          return calculationForSegment.totalCountForHousehold;
        };

        function getMarketingChannels() {
          scope.loadingMarketingChannels = lookupSvc.getLookupDataById('marketing-channel')
          .then(function (data) {
            var marketingOption = _.find(data, { Id: listState.MarketingChannelId });
            if (marketingOption) {
              scope.marketingChannelName = marketingOption.Name;
            }
          });
        }

        scope.disableAllCriteriaCheckbox = function () {
          $timeout(function () {
            if ($('.pretty-chkbx').length > 0) {
              $('.pretty-chkbx').attr('disabled', 'disabled');
            }
            else {
              scope.disableAllCriteriaCheckbox();
            }
          }, 1000);
        };

        function getSelectedRecipeName() {
          if (listState.RecipeId) {
            recipeSvc.getRecipe(listState.RecipeId).then(function (data) {
              scope.selectedRecipe = data.Name;
            });
          }
        }
        function getFacilityData() {
          var locationIds = [];
          _.forEach(listState.LocationDescriptors, function (data) {
            return locationIds.push(data.LocationId);
          });
          locationIds = _.uniq(locationIds);
          facilitySvc.getFacilities({
            'locationids': locationIds.join(',')
          }).then(function (facilityData) {
            sessionSvc.set('selectedLocation.facilities', JSON.stringify(facilityData));
            getLocationData();
          });
        }
        function getLocationData() {
          scope.locations = geographyHelper.mapLocationDescriptorsForGrid(listState.LocationDescriptors);
        }
        function manageListdata() {
          var pastLists = [];
          lookupSvc.getLookupDataById('marketing-channel').then(function (data) {
            var marketingOption = _.find(data, { Id: listState.MarketingChannelId });
            var shouldApplyExclusionPeriod = function () {
              return marketingOption.Name === 'Direct Mail';
            };
            pastListSvc.pastListData(shouldApplyExclusionPeriod()).then(function (data) {
              pastLists = data;
              _.each(pastLists, function (pastList) {
                pastList.getCampaignID = function () {
                  if (this.ListRefId) {
                    var listRefId = this.ListRefId.split('_');
                    return listRefId.length === 2 ? listRefId[0] : this.ListId;
                  }
                  else {
                    return this.ListId;
                  }
                };

                if (_.contains(listState.ExcludedPastListIds, pastList.ListId)) {
                  if (pastList.InExclusionPeriod) {
                    listState.InExclusionPastListIds.push(pastList.ListId);
                    pastList.actionValue = 'Exclude';
                    scope.includedPastList.push(pastList);
                  }
                  else {
                    if (_.contains(listState.InExclusionPastListIds, pastList.ListId)) {
                      _.remove(listState.ExcludedPastListIds, function (item) {
                        return item === pastList.ListId;
                      });
                      _.remove(listState.InExclusionPastListIds, function (item) {
                        return item === pastList.ListId;
                      });
                    }
                    else {
                      pastList.actionValue = 'Exclude';
                      scope.includedPastList.push(pastList);
                    }
                  }
                }
                else if (_.contains(listState.IncludedPastListIds, pastList.ListId)) {
                  if (pastList.InExclusionPeriod) {
                    _.remove(listState.IncludedPastListIds, function (item) {
                      return item === pastList.ListId;
                    });
                    listState.ExcludedPastListIds.push(pastList.ListId);
                    if (pastList.ListRefId && listState.ExcludedPastListIds.indexOf(pastList.ListRefId) === -1) {
                      listState.ExcludedPastListIds.push(pastList.ListRefId);
                    }
                    listState.InExclusionPastListIds.push(pastList.ListId);
                    pastList.actionValue = 'Exclude';
                    scope.includedPastList.push(pastList);
                  }
                  else {
                    if (_.contains(listState.InExclusionPastListIds, pastList.ListId)) {
                      _.remove(listState.InExclusionPastListIds, function (item) {
                        return item === pastList.ListId;
                      });
                    }
                    else {
                      pastList.actionValue = 'Include';
                      scope.pastListInclusion.push(pastList);
                      scope.includedPastList.push(pastList);
                    }
                  }
                }
                else {
                  if (pastList.InExclusionPeriod) {
                    listState.ExcludedPastListIds.push(pastList.ListId);
                    if (pastList.ListRefId && listState.ExcludedPastListIds.indexOf(pastList.ListRefId) === -1) {
                      listState.ExcludedPastListIds.push(pastList.ListRefId);
                    }
                    listState.InExclusionPastListIds.push(pastList.ListId);
                    pastList.actionValue = 'Exclude';
                    scope.includedPastList.push(pastList);
                  }
                  else {
                    if (_.contains(listState.InExclusionPastListIds, pastList.ListId)) {
                      _.remove(listState.InExclusionPastListIds, function (item) {
                        return item === pastList.ListId;
                      });
                    }
                  }
                }
              });
              //Adding Included past lists to Session
              //which will be used to bind List Inclusion Grid
              if (scope.pastListInclusion.length > 0) {
                sessionSvc.set(pastListInclusions, JSON.stringify(scope.pastListInclusion));
              }
              else {
                sessionSvc.clear(pastListInclusions);
              }
              _.each(scope.includedPastList, function (val) {
                angular.extend(val, {
                  campaignId: val.getCampaignID()
                });
              });
              scope.summaryTablePastListsData.gridData = scope.includedPastList;
            });
          });
          //Seed List
          seedListSvc.getSeedListData().then(function (data) {
            if (data.length <= 0) { return; }
            var seedLists = _.filter(data, function (seedList) { return seedList.ClientKey !== '' && seedList.ClientKey !== null; });
            angular.forEach(seedLists, function (seedList) {
              if (_.contains(listState.SeedListIds, seedList.Id)) {
                scope.selectedSeedLists.push(seedList);
                seedList.actionValue = true;
              }
            });
            console.log('stepname:' + listStateSvc.get().CurrentUIState.currentStep);
            scope.summaryTableSeedListsData.gridData = scope.selectedSeedLists;
          });
        }

        function updateIndividualHouseholdTotal() {
          if (scope.segments && scope.segments.length > 0) {
            _.each(scope.segments, function (val) {
              angular.extend(val, {
                HouseholdTotalCount: scope.householdTotal(val)
              });
              angular.extend(val, {
                IndividualTotalCount: scope.individualTotal(val)
              });
            });
          }
        }

        function manageSegmentData() {
          scope.segments = listState.Segments;
          updateIndividualHouseholdTotal();
          scope.summaryTableManageSegmentsData.gridData = scope.segments;
        }

        scope.$watch('quickCounts', function () {
          updateIndividualHouseholdTotal();
          scope.summaryTableManageSegmentsData.gridData = scope.segments;
        });

        //RefineCriteria
        function refineCriteriaData() {
          scope.criteria = filterTypeSvc.loadFilterTypeData('filters').then(function (data) {
            data = JSON.parse(data);
            data = scope.setDefaultOrderForFilterTypes(data);
            return data;
          });
          scope.providerSpecialties = providerSvc.getAllProviderSpecialties().then(function (psData) {
            return scope.applyCustomSort(psData, 'Name');
          });
          if (listState.RecipeId) {
            scope.recipeFilterValueSelections = recipeSvc.getRecipe(listState.RecipeId).then(function (recipe) {
              scope.isRecipeLoaded = true;
              return recipe.Filters;
            });
          }
          scope.listFilterValueSelections = listState.FilterValueSelections;
          scope.disableAllCriteriaCheckbox();
          scope.disableAllCriteriaCheckbox();

        }

        scope.setDefaultOrderForFilterTypes = function (data) {
          data.MaritalStatus = scope.applyCustomSort(data.MaritalStatus, 'Name');
          data.Gender = scope.applyCustomSort(data.Gender, 'Name');
          data.AgeOfChildren = scope.applyCustomSort(data.AgeOfChildren, '_id');
          data.AgeRange = scope.applyCustomSort(data.AgeRange, '_id');
          data.Occupation = scope.applyCustomSort(data.Occupation, 'Name');
          data.Race = scope.applyCustomSort(data.Race, 'Name');
          data.PrimaryLanguage = scope.applyCustomSort(data.PrimaryLanguage, 'Name');
          data.PayerType = scope.applyCustomSort(data.PayerType, 'Name');
          data.BeehiveCluster = scope.applyCustomSort(data.BeehiveCluster, 'Name');
          data.HomeOwnership = scope.applyCustomSort(data.HomeOwnership, 'Name');
          data.EducationLevel = scope.applyCustomSort(data.EducationLevel, 'Name');
          data.DwellingType = scope.applyCustomSort(data.DwellingType, 'Name');
          data.HouseholdIncomeGroup = scope.applyCustomSort(data.HouseholdIncomeGroup, '_id');
          data.HomeValue = filter('orderBy')(data.HomeValue, '_id', false);
          data.WealthLevel = scope.applyCustomSort(data.WealthLevel, 'WealthLevelMinVal');
          data.FinancialClass = scope.applyCustomSort(data.FinancialClass, 'Name');
          data.PhysicianType = filter('orderBy')(data.PhysicianType, 'Name', false);
          data.PatientType = filter('orderBy')(data.PatientType, 'Name', false);
          data.EncounterSourceType = scope.applyCustomSort(data.EncounterSourceType, 'Name');

          //Custom Order for Person Types
          var personTypesTemp = [];
          personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Patients' }));
          personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Family Member of Patients' }));
          personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Qualified Prospects' }));
          personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Prospects' }));
          personTypesTemp.push(_.find(data.PersonType, { 'Name': 'New Movers' }));
          data.PersonType = personTypesTemp;

          return data;
        };

        scope.applyCustomSort = function (data, sortColumn) {
          var result = _.groupBy(data, function (currentObject) {
            return currentObject.Name.toUpperCase() !== 'UNKNOWN';
          });

          return _.flatten([_.sortBy(result.true, sortColumn), result.false ? result.false : []]);
        };

        function getPrioritizeData() {
          scope.distribution = getDistributionByPriority(listState.Distribution);
        }

        function getDistributionByPriority(distribution) {
          if (distribution) {
            if (listState.Segments && listState.Segments.length > 0) {

              var prioritizeDisrtibution = [];
              _.each(listState.Segments, function (segment) {

                _.find(distribution.Segments, function (distSegment) {

                  if (distSegment.Name.toUpperCase() === segment.Name.toUpperCase()) {
                    prioritizeDisrtibution.push(distSegment);
                  }
                });
              });

              _.each(distribution.Segments, function (segment) {
                var foundSegment = _.find(listState.Segments, { 'Name': segment.Name });

                if (!foundSegment) {
                  prioritizeDisrtibution.push(segment);
                }
              });

              if (prioritizeDisrtibution.length > 0) {
                distribution.Segments = prioritizeDisrtibution;
              }
            }
            return distribution;
          }
        }

        function getMetaData() {
          scope.listMetaId = listState.Id;
          scope.listMetaCreatedOn = listState.CreatedOn;
          if (scope.listMetaCreatedOn) {
            scope.listMetaUpdatedOn = (listState.UpdatedOn) ? listState.UpdatedOn : new Date();
          }
          scope.listMetaCreatedBy = listState.CreatedBy;
          if (listState.CreatedBy !== listState.UpdatedBy) {
            scope.listMetaUpdatedBy = listState.UpdatedBy;
          }
        }

        //Grid
        scope.gridOptionsForLocations = {
          data: 'locations',
          rowHeight: 45,
          multiSelect: false,
          /* jshint ignore:start */
          plugins: [new ngGridFlexibleHeightPlugin()],
          /* jshint ignore:end */
          columnDefs: [
            {
              field: 'Name',
              displayName: 'Location'
            },
            targetAreasColumn
          ]
        };

        scope.getTab = function (name) {
          return _.find(tabDefinitions, {
            name: name
          });
        };
        scope.dataAvailable = function (hasListNameChanged) {
          $timeout(function () {
            if (listStateSvc.get()) {
              scope.pageReady = true;
              if (hasListNameChanged) {
                showWarningForIncompleteSteps(listStateSvc.get());
              }
              else {
                loading(listStateSvc.get());
              }
            }
            else {
              scope.dataAvailable(hasListNameChanged);
            }
          }, 100);
        };
        scope.dataAvailable();
      }
    };
  }]);
})(window.app);
