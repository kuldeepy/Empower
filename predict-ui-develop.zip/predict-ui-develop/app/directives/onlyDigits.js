﻿(function (app) {
  'use strict';

  app.directive('onlyDigits', function () {
    return {
      require: 'ngModel',
      restrict: 'A',
      link: function (scope, element, attrs, ngModel) {
        if (!ngModel) {
          return;
        }
        ngModel.$parsers.unshift(function (inputValue) {
          var digits = inputValue.split('').filter(function (s) {
            return (!isNaN(s) && s !== ' ');
          }).join('');
         
          ngModel.$viewValue = digits;
          ngModel.$render();
          return digits;
        });
      }
    };
  });

})(window.app);