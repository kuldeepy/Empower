﻿(function (app) {
  'use strict';

  app.directive('adjustResolution',['$window','userContextSvc', function (window,userContextSvc) {
    return {
      restrict: 'A',
      scope:{
        leftNavExpanded:'='
      },
      link: function (scope) {
        window.onresize = function () {
          changeResolution();
        };

        function changeResolution() {
          var screenWidth = window.innerWidth;
          if (screenWidth <= 768) {
            scope.leftNavExpanded = false;
          } else if (screenWidth > 768 && location.pathname === userContextSvc.getUserLandingUrl()) {
            scope.leftNavExpanded = true;
          }
        }
        changeResolution();
      }
    };
  }]);
})(window.app);