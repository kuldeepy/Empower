(function (app) {
  'use strict';

  app.directive('mConfirm', function () {
    return {
      link: function (scope, element, attr) {
        var msg = attr.mConfirm || 'Are you sure?';
        var clickAction = attr.afterConfirm;
        element.bind('click', function () {
          if (window.confirm(msg)) {
            scope.$eval(clickAction);
          }
        });
      }
    };
  });
})(window.app);
