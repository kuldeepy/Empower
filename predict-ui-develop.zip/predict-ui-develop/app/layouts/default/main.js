(function () {
	'use strict';

	app.controller('DefaultLayoutCtrl', ['$scope', '$location', 'authSvc', 'userContextSvc',
	function (scope, location, authSvc, userContextSvc) {
		scope.layout = {
			alert: ''
		};

		scope.$watch(function () {
			return location.path();
		}, function (val) {
			if (authSvc.hasToken()) {
				scope.currentView = val.substr(app.currentRoute.length + 1);
			} else {
				scope.redirectToLoginPage();
			}
		});

		scope.redirectToLoginPage = function () {
			location.path(userContextSvc.getUserLoginUrl());
		};

	}
	]);

	app.publish('moduleReady', 'layouts/default');

})();