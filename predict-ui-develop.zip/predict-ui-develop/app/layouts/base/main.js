﻿(function (app) {
  'use strict';
  app.controller('BaseLayoutCtrl', ['$scope', '$location', '$http', 'clientSvc', 'authSvc', 'sessionSvc', '$timeout', 'listExportSvc',
                'userContextSvc', '$window', '$rootScope', 'alertSvc', 'notificationSvc', 'longTaskSvc', 'pivotTableSvc', 'listSvc','Idle','selectedContext',
  function (scope, location, http, clientSvc, authSvc, sessionSvc, timeout, listExportSvc,
            userContextSvc, window, rootScope, alertSvc, notificationSvc, longTaskSvc, pivotTableSvc, listSvc, idle, selectedContext) {
    /* variable declarations */
    //var lastAPICallTimeKey = 'lastAPICallTime';
    var expiresInKey = 'auth.expiresIn';
    var remainingAlertSecondsKey = 'remainingAlertSeconds';
    var passwordExpiresBy = 'auth.passwordExpiresBy';
    var clientDataAvailThroughDate = 'dataAvailThroughDate';
    var oldTitle = document.title;
    var daysLeftForPasswordExpire = sessionSvc.get(passwordExpiresBy);
    var lrtInterval;
    var lrtIntervalActive = false;
    var notificationTaskType = {
      listExport: 'ListExport',
      listPull: 'ListPull'
    };

    scope.formatDataAvailThroughDate = function (dataAvailThroughDate) {
      var newDataAvailThroughDate = new Date(dataAvailThroughDate);
      return (parseInt(newDataAvailThroughDate.getUTCMonth()) + 1) + '/' + newDataAvailThroughDate.getUTCDate() + '/' + newDataAvailThroughDate.getUTCFullYear();
    };

    scope.isSilverpopConfigured = userContextSvc.isSilverpopConfigured;
    scope.dataAvailThroughDate = undefined;
    scope.org = '';
    scope.fullName = authSvc.getFullName();
    var selectedContextSvc = selectedContext;

    // Sidebar Nav Toggle
    scope.layout = { toggleOffcanvasSubNav: false };

    scope.onContextChange = function () {
      window.location.href = '/' + authSvc.getUserClientKey();
    };
    scope.checkUserContextValidationClient = function (clientKey) {
      console.log('User Client Key:' + authSvc.getUserClientKey());
      if (authSvc.getUserClientKey() !== null && authSvc.getUserClientKey() !== clientKey &&
        !authSvc.isSystemAdministrator() && !authSvc.isClientAdministrator()) {
        return null;
      }
      else {
        return clientKey;
      }
    };

    scope.checkUserContextValidationOrganization = function (OrgKey) {
      if (OrgKey === '') {
        return '';
      }
      return OrgKey;
    };

    scope.clientKey = scope.checkUserContextValidationClient(userContextSvc.getClientKey());

    if (scope.clientKey === null) {
      $('#userContextChangeModal').modal('show');
    }

    scope.OrgKey = scope.checkUserContextValidationOrganization(userContextSvc.getOrgKey());

    if (scope.OrgKey === '' && app.routing.routeParams.orgKey) {
      $('#userContextChangeModal').modal('show');
    }

    scope.notifications = notificationSvc.get();
    scope.notificationCount = scope.notifications.length;

    scope.showContent = true;
    if (!authSvc.hasToken()) {
      scope.showContent = false;
    }

    scope.canLoginToPersuade = false;
    if (authSvc.hasExternalTokens()){
      scope.canLoginToPersuade = !!authSvc.getExternalTokens().persuade;
    }

    if (!scope.clientNameValue) {
      scope.clientNameValue = sessionSvc.get('clientName');
    }

    if (!scope.orgNameValue) {
      scope.orgNameValue = sessionSvc.get('orgName');
    }

    if (!scope.dataAvailThroughDate) {
      scope.dataAvailThroughDate = sessionSvc.get(clientDataAvailThroughDate);
    }

    rootScope.$on('$stateChangeStart', function () {
      alertSvc.removeAll();
    });

    scope.$on('getClientValue', function () {
      scope.clientNameValue = sessionSvc.get('clientName');
    });

    scope.$on('getOrgValue', function () {
      scope.orgNameValue = sessionSvc.get('orgName');
    });

    scope.$on('getdataAvailThroughDate', function () {
      scope.dataAvailThroughDate = sessionSvc.get(clientDataAvailThroughDate);
    });

    scope.$on('longRunningTasks:updated', function (message) {
      var scopedMessage = message.currentScope;
      if (scopedMessage.notifications.length > 0 && _.some(scopedMessage.notifications, function (note) {
        return note.task.percentComplete < 100;
      })) {
        if (lrtIntervalActive === false) {
          lrtIntervalActive = true;
          lrtInterval = setInterval(updateLongRunningTasks, 10000);
        }
      } else if (typeof (lrtInterval) !== 'undefined' && lrtIntervalActive === true) {
        clearInterval(lrtInterval);
        lrtIntervalActive = false;
      }
    });

    scope.$on('longRunningTasks:completed', function () {
      if (typeof (lrtInterval) !== 'undefined') {
        clearInterval(lrtInterval);
      }
    });

    //Need to set the flag when context is changes from welcome control
    //args[0] carries boolean flag indicating if silverpop is configured
    scope.$on('loadClientInfo', function (event, args) {
      scope.isSilverpopConfigured = args[0];
      scope.dataAvailThroughDate = args[1];
    });

    //Sending parameter as true will fire the broadcast longRunningTasks:updated
    function updateLongRunningTasks() {
      longTaskSvc.update(true);
    }

    scope.loadClientInfo = function () {
      var allowedClients = _.pluck(authSvc.getClientKeys(),  'ClientKey');
      var allowedOrgs = _.pluck(userContextSvc.getUserOrganizations(), 'OrgKey');
      scope.loading = clientSvc.loadClients().then(function (clients) {
        scope.model.clients = _.filter(clients, function (client) {
          client.Organizations = _.filter(client.Organizations, function (org){
            return authSvc.isSystemAdministrator() || _.contains(allowedOrgs, org.Key);
          });
          return authSvc.isSystemAdministrator() || _.contains(allowedClients, client.Key);
        });
      });
    };

    var setScopeData = function () {
      scope.model = {};
      scope.model.clients = {};
      scope.model.username = authSvc.getUsername();
      scope.model.fullName = authSvc.getFullName();
      scope.model.roles = authSvc.getRoles();
      scope.showClient = false;
      scope.roleNames = authSvc.getRoles();
      scope.roleName = getRoleName();
      if (authSvc.isSystemAdministrator() || authSvc.isClientAdministrator()) {
        scope.showClient = true;
        scope.loading = clientSvc.getAllowedClientOrg().then(function(clients) {
          scope.model.clients = clients;
          userContextSvc.expandOrCollapseNodes(scope.model.clients);
          scope.contextDropdownHeading = userContextSvc.expandOrCollapseNodes(scope.model.clients).heading;
        });
      }
      else {
        scope.loading = clientSvc.getAllowedClientOrg().then(function(clients) {
          scope.model.clients = clients;
          userContextSvc.expandOrCollapseNodes(scope.model.clients);
          scope.contextDropdownHeading = userContextSvc.expandOrCollapseNodes(scope.model.clients).heading;
        });
        scope.model.userOrgs = getOrganizationModels();
      }
    };
    var getRoleName = function () {
      if (scope.roleNames.indexOf('Demo') > -1) {
        return 'Marketing Manager';
      }
      else if (scope.roleNames.indexOf('SysAdmin') > -1) {
        return 'System Administrator';
      }
      else if (scope.roleNames.indexOf('ClientAdministrator') > -1) {
        return 'Administrator';
      }
      else if (scope.roleNames.indexOf('CampaignManager') > -1) {
        return 'Campaign Manager';
      }
      else if (scope.roleNames.indexOf('Auditor') > -1) {
        return 'Auditor';
      }
      else if (scope.roleNames.indexOf('ListExporter') > -1) {
        return 'ListExporter';
      }
      else if (scope.roleNames.indexOf('Executive') > -1) {
        return 'Executive';
      }
      else {
        return scope.roleNames[0];
      }
    };

    var getOrganizationModels = function () {
      var orgs = userContextSvc.getUserOrganizations();
      for (var i = orgs.length - 1; i >= 0; i -= 1) {
        orgs[i].ListManagementLinkLabel = (orgs.length === 1 ? 'Manage Lists' : orgs[i].Name);
      }
      return orgs;
    };

    scope.$watchCollection('notifications', function (notifications) {
      scope.notificationCount = notifications.length;
    });

    scope.securityTrim = function (rolesArray) {
      var found = false;
      if (scope.model.roles.indexOf('SysAdmin') !== -1) {
        return true;
      }
      else {
        angular.forEach(rolesArray, function (role) {
          if (!found) {
            if (scope.model.roles.indexOf(role) !== -1) {
              found = true;
            }
          }
        });
      }
      return found;
    };

    scope.onClientValueChange = function () {
      var selectedClient = scope.defaultClientSelected;
      scope.model.userOrgs = [];

      if (selectedClient.toUpperCase() !== 'SELECT CLIENT') {
        var arrClient = selectedClient.toString().split('~');
        if (arrClient.length > 1) {
          scope.clientKeyValue = arrClient[0];
          scope.clientNameValue = arrClient[1];
          sessionSvc.set('clientName', scope.clientNameValue);
          scope.$emit('getClientValue');
        }

        var client = _.find(scope.model.clients, { 'Key': scope.clientKeyValue.toLowerCase() });

        angular.forEach(client.Organizations, function (org) {
          scope.model.userOrgs.push({ 'OrgKey': org.Key, 'ListManagementLinkLabel': org.Name });
        });
      }
      else {
        scope.isOkDisabled = true;
      }
    };

    scope.onOrganizationValueChange = function () {
      var selectedOrganization = scope.defaultOrgSelected;

      if (selectedOrganization.toUpperCase() === 'SELECT ORGANIZATION') {
        scope.isOkDisabled = true;
      }
      else {
        var arrOrg = selectedOrganization.toString().split('~');
        if (arrOrg.length > 1) {
          scope.orgKeyValue = arrOrg[0];
          scope.orgNameValue = arrOrg[1];
          sessionSvc.set('orgName', scope.orgNameValue);
        }
        scope.isOkDisabled = false;
      }
    };
    scope.selectUserClients = function (client) {
      scope.model.userOrgs = [];
      scope.orgNameValue = '';
      if (client) {
        scope.clientNameValue = client.Name;
        sessionSvc.set('clientName', scope.clientNameValue);
        scope.$emit('getClientValue');

        angular.forEach(client.Organizations, function (org) {
          scope.model.userOrgs.push({ 'OrgKey': org.Key, 'ListManagementLinkLabel': org.Name });
        });
      }
    };

    scope.selectUserOrgs = function (organization) {
      if (organization) {
        scope.orgNameValue = organization.ListManagementLinkLabel;
        sessionSvc.set('orgName', scope.orgNameValue);
        scope.$emit('getOrgValue');
      }
    };

    // Broadcast client and organization as a global event
    scope.setUserContext = function(client, organization) {
      if(app.routing.data.isWizardMode === true) {
        var contextChangeInfo = { Client: client, Organization: organization };
        scope.$broadcast('saveMeOnly', contextChangeInfo);
      } else {
        userContextSvc.setUserContext(client, organization);
      }
    };

    scope.goToListManagementPage = function() {
      location.path('/' + selectedContextSvc.client + '/' + selectedContextSvc.organization + '/lists');
    };
    scope.goToAuditPage = function() {
      location.path('/' + selectedContextSvc.client + '/' + selectedContextSvc.organization + '/auditReport');
    };

    scope.removeNotification = function (notification) {
      longTaskSvc.remove(notification.task);
      notificationSvc.remove(notification);
    };

    scope.commonNotificationAction = function (notification, linkIndex) {
      var task = notification.task;
      if (scope['downloading' + task.id] === undefined) {
        scope['downloading' + task.id] = [];
      }
      scope['downloading' + task.id].push(longTaskSvc.processTask(notification, linkIndex));
    };

    scope.exportToMarketAutomation = function (notification) {
      var notificationMetadata = notification.task.NotificationMetadata;
      notificationMetadata.RequestBody = { Id: notificationMetadata.ListId, IsTextExport: false };
      scope.commonNotificationAction(notification);
    };

    scope.$on('longRunningTask:remove', function (event, args) {
      var taskId = args[0];
      if (typeof (task) === undefined) { return; }
      var notification = _.find(notificationSvc.get(), function (note) {
        return typeof (note.task) !== undefined && note.task.id === taskId;
      });
      if (typeof (notification !== undefined)) {
        scope.removeNotification(notification);
      }
    });

    function hideNavDropDown(element) {
      if (element === undefined) {
        element = $('.nav-container li.expanded');
      }

      if (element.length) {
        element.removeClass('expanded');
      }
    }

    scope.openManageListsModal = function (linkType) {
      hideNavDropDown();
      scope.linkType = linkType;
      scope.canShowClientOption = true;
      if (linkType.toUpperCase() === 'LIST') {
        location.path('/' + scope.model.clients[0].Key + '/' + scope.model.clients.Organizations[0].Key + '/lists');
      }
      else {
        location.path('/' + scope.model.clients[0].Key + '/' + scope.model.clients.Organizations[0].Key + '/auditReport');
      }
    };

    scope.openBrightWhistle = function (path) {
      if ( scope.canLoginToPersuade ){
        if ( path === undefined ){
          path = '/dashboard';
        }
        var userEmail = authSvc.getExternalTokens().persuade.email;
        var authToken = authSvc.getExternalTokens().persuade.token;

        var server = 'https://console.brightwhistle.com';
        //var server = 'http://localhost:3000';
        http.get( server + '/whistler/v1/bw/bw_users/show?email=' + userEmail + '&callback=parseData', {
          headers: {
            'X-API-EMAIL': userEmail,
            'X-API-TOKEN': authToken,
            'X-API-AGENCY-ID': 1,
            'X-API-CLIENT-ID': 3
          }
        }).then(function(){
          window.location = server + path;
        });

      }else{
        location.path('/' + scope.clientKey + '/channelperformance' + '/bright-whistle');
      }
    };

    scope.openSpotfirePrint = function () {
      location.path('/' + scope.clientKey + '/channelperformance' + '/print');
    };

    scope.openMarketingIntelligence = function () {
      location.path('/' + scope.clientKey + '/marketingintelligence');
    };

    scope.openMyCampaigns = function () {
      location.path('/' + scope.clientKey + '/mycampaigns');
    };

    scope.openMarketIntelligenceItems = function (modulepath) {
      location.path('/' + scope.clientKey + '/marketingintelligence' + '/' + modulepath);
    };

    scope.onClick = function () {
      scope.selectedClient = '';
      if (authSvc.isClientAdministrator() || authSvc.isSystemAdministrator()) {
        scope.selectedClient = scope.clientKeyValue;
        var client = _.find(scope.model.clients, { 'Key': scope.clientKeyValue.toLowerCase() });
        scope.isSilverpopConfigured = client.IsSilverpopConfigured;
        scope.dataAvailThroughDate = client.DATDate;
        scope.$emit('loadClientInfo', [scope.isSilverpopConfigured, scope.dataAvailThroughDate]);
      }
      sessionSvc.clear('selectLocation.locations');
      scope.selectedOrg = scope.defaultOrgSelected.toString().split('~')[0];
      if (scope.selectedClient !== '') {
        if (scope.linkType.toUpperCase() === 'LIST') {
          location.path('/' + scope.selectedClient + '/' + scope.selectedOrg + '/lists');
        }
        else {
          location.path('/' + scope.selectedClient + '/' + scope.selectedOrg + '/auditreport');
        }
      }
      else {
        location.path(getListManagementUrl(scope.selectedOrg, scope.linkType));
      }
    };

    var getListManagementUrl = function (orgKey, linkType) {
      var clientKey = userContextSvc.getClientKey();
      scope.orgNameValue = userContextSvc.getOrganizationName(orgKey);
      if (linkType.toUpperCase() === 'LIST') {
        return '/' + clientKey + '/' + orgKey + '/lists';
      }
      else {
        return '/' + clientKey + '/' + orgKey + '/auditreport';
      }
      return '';
    };

    setScopeData();

    if (daysLeftForPasswordExpire && daysLeftForPasswordExpire < 1) {
      location.path('/' + userContextSvc.getClientKey() + '/session/login').search('id', authSvc.getUsername());
    }

    /* method to watch authentication */
    scope.$watch(function () {
      return location.path();
    }, function () {
      if (!authSvc.hasToken()) {
        if (location.path().indexOf(app.baseLoginUrl) === -1) {
          app.generic.location = location.path();
          //location.path is replaced -  mechanism used to delete history could not find angular way to do it
          var url = userContextSvc.getUserLoginUrl();
          window.history.go(-window.history.length);
          window.location.href = url;
        }
        return;
      } else {
        if (app.generic.timeoutPromise !== null) {
          timeout.cancel(app.generic.timeoutPromise);
        }
      }
    });

    /* method to logout*/
    scope.logout = function () {
      if (app.generic.timeoutPromise !== null) {
        timeout.cancel(app.generic.timeoutPromise);
      }
      //Log out function is not been called in Microservice.
      //Will check with IUS team and to make changes accordingly
      authSvc.logOut().then(function () {
        //mechanism used to delete history could not find angular way to do it
        var url = userContextSvc.getUserLoginUrl();
        window.history.go(-window.history.length);
        window.location.href = url;
      });
      scope.clearSession();
    };

    /* method to clearsession */
    scope.clearSession = function () {
      authSvc.clearAuthSession();
      location.path(userContextSvc.getUserLoginUrl());
    };

    /*year on footer*/
    scope.year = new Date().getFullYear().toString();

    sessionSvc.set(remainingAlertSecondsKey, app.sessionExpiryAlertSeconds);

    scope.$on('IdleStart', function () {
      $('#sessionTimeoutModal').modal('show');
    });

    scope.$on('IdleTimeout', function () {
        scope.logout();
      });

    scope.$on('Keepalive', function () {
      authSvc.refreshToken();
    });

    scope.intializeNgIdle = function () {
      idle.setIdle(parseInt(sessionSvc.get(expiresInKey)));// time to wait for user to activate the user session
      idle.setTimeout(app.sessionExpiryAlertSeconds); // time for which countdown will run and wait for user to respond
      idle.watch();
    };
    scope.intializeNgIdle();

    scope.$on('$destroy', function () {
      if (app.generic.timeoutPromise !== null) {
        timeout.cancel(app.generic.timeoutPromise);
      }
    });

    scope.$watch('countdown', function (newVal) {
      var minutes = parseInt(newVal / 60);
      var seconds = ('0' + parseInt(newVal % 60)).slice(-2);
      scope.expDate = minutes + ':' + seconds;
    });

    /* method to continue the session */
    scope.continue = function () {
      idle.watch();
      document.title = oldTitle;
      sessionSvc.set(remainingAlertSecondsKey, app.sessionExpiryAlertSeconds);
      authSvc.refreshToken();
    };
    scope.layout = {
      alert: '',
      loading: null
    };
    if (scope.clientKey !== '') {
      scope.listsUrl = '/' + scope.clientKey + '/' + userContextSvc.getOrgKey() + '/lists';
    }
    scope.homeLink = userContextSvc.getUserLandingUrl();

    scope.isDemo = function () {
      if (scope.model.roles.indexOf('Demo') !== -1) {
        return true;
      }
      else {
        return false;
      }
    };

    scope.isListExporter = function (taskType) {
      if (taskType.toUpperCase() === notificationTaskType.listExport.toUpperCase() || taskType.toUpperCase() === notificationTaskType.listPull.toUpperCase()) {   // Enabling the Pivot Table download button does not require to check for the roles
        return scope.model.roles.indexOf('ListExporter') !== -1 || scope.model.roles.indexOf('SysAdmin') !== -1;
      }
      return true;
    };

    // Angular ui.tree logic

    // Pertains to searching nodes
    scope.visible = function (item) {
      return !(scope.query && scope.query.length > 0 && item.title.indexOf(scope.query) === -1);
    };
    scope.findNodes = function () {};

    scope.toggle = function (scope) {
      scope.toggle();
    };



    $(function () {
      $('.nav-parent').on('mouseenter', function (e) {
        e.preventDefault();
        var element = $(this);
        if (element.hasClass('expanded')) {
          hideNavDropDown(element);
        }
        else {
          hideNavDropDown();
          element.addClass('expanded');
        }
      });
      $('.nav-parent').on('mouseleave', function (e) {
        e.preventDefault();
        var element = $(this);
        if (element.hasClass('expanded')) {
          element.removeClass('expanded');
        } else {
        }
      });
      $('html').on('click touchStart', function () {
        hideNavDropDown();
      });
      $('.nav-container').on('click touchStart', function (e) {
        e.stopPropagation();
      });
    });

    updateLongRunningTasks();
  }
  ]);

  app.directive('showEmptyMessage', function ($compile) {
    return {
      restrict: 'A',
      link: function (scope, element, attrs) {
        var message = (attrs.showEmptyMessage) ? attrs.showEmptyMessage : 'No records to display';
        var template = '<p class=\"empty-grid-message-wrap\">' + message + '</p>';
        var tmpl = angular.element(template);
        $compile(tmpl)(scope);
        scope.$watchCollection('gridData', function () {
          if (_.size(scope.gridData) === 0) {
            angular.element('.ngViewport').append(tmpl);
          }
          else {
            angular.element('.empty-grid-message-wrap').remove();
          }
        });
      },
      scope: {
        gridData: '='
      }
    };
  });

  app.directive('selectStyle', function () {
    return {
      restrict: 'C',
      link: function () {
        $(function () {
          var checkCounter = 1;
          styleSelect(checkCounter);

          function styleSelect(checkCounter) {
            if (checkCounter === 1) {
              setTimeout(
              function () {
                $('.select-style').selectpicker();
                verifySelectStyle();
              },
              100
              );
            }
            else {
              $('.select-style').selectpicker('refresh');
              verifySelectStyle();
            }
          }

          function verifySelectStyle() {
            if ($('div.select-style li').length === 1 && checkCounter < 10) {
              checkCounter = checkCounter + 1;
              setTimeout(
              function () {
                styleSelect(checkCounter);
              },
              200
              );
            }
          }
        });
      }
    };
  });
}(window.app));
