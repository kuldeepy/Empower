﻿'use strict';

$(document).ready(function () {

  $(window).bind('capsOn', function () {
    $('#caps-alert').html('<div class="alert alert-danger alert-small pad-top">Caps Lock is on.</div>');
    if ($('#id_pass:focus').length > 0) {
      $('#caps-alert').css('display', 'block');
    }
    if ($('#id_username:focus').length > 0) {
      $('#caps-alert').css('display', 'none');
    }
    if ($('#id_pass_new:focus').length > 0) {
      $('#caps-alert').css('display', 'none');
    }
    if ($('#id_pass_confirm:focus').length > 0) {
      $('#caps-alert').css('display', 'none');
    }
  });
  $(window).bind('capsOff', function () {
    $('#caps-alert').css('display', 'none');
  });
  $(window).capslockstate();
  $('#id_pass').click(function () {
    $('#caps-alert').css('display', 'block');
  });

});