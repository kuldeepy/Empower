﻿'use strict';

(function (app) {

  app.ng.config(['$httpProvider', function(httpProvider) {
    //enable httpProvider sending cookies
    httpProvider.defaults.withCredentials = true;
  }]);

	// container for data to be used for generic purpose
	var generic = {};
	app.generic = generic;

	/* declaration of variables */
	generic.location = '';
	generic.timeoutPromise = '';

}(window.app));