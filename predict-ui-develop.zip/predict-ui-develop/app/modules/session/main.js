(function (app) {
  'use strict';

  var modulePath ='modules/session',
    ctrlRoot = app.root + modulePath + '/controllers/';

  /* module root controller */
  app.controller('SessionCtrl', ['$scope', 'deviceDetector', 'alertSvc', function (scope, deviceDetector, alertSvc) {
    /*jshint camelcase: false */
    scope.hasError = false;
    if (deviceDetector.browser === 'ie' && parseInt(deviceDetector.browser_version) < 11) {
      alertSvc.add({ Type: 'Error', Title: '', Source: 'BrowserError', Message: '' });
      scope.hasError = true;
    }
    scope.modulePath = modulePath;
    scope.model = {
      routeParams: {}
    };
  }]);

  /* load required controllers */
  $.when(
    $.getScript(ctrlRoot + 'RouteCtrl.js'),
    $.getScript(ctrlRoot + 'LoginCtrl.js'),
    $.getScript(ctrlRoot + 'LogoutCtrl.js')
    ).done(function () {
      app.publish('moduleReady', modulePath);
    });

  /* set focus on either Username or Password when page loads */
  app.directive('focusOnLoad', function($timeout) {
    return {
      restrict: 'A',
      link: function (scope, elem) {

        /* disable IE native Caps Lock warning */
        document.msCapsLockWarningOff = true;

        /* use timeout to delay until local storage has a chance to populate userName input */
        $timeout(function() {
          var userName = elem[0].querySelector('#id_username');
          if(userName.value.length===0){
            userName.focus();
          }
          else{
            /* if userName has been populated by Remember Me local storage, set focus on password input */
            var password = elem[0].querySelector('#id_pass');
            password.focus();
          }
        });
      }
    };
  });

  /* set focus on NewPassword when modal reset modal  pop-up loads */
  app.directive('focusMe', function ($timeout, $parse) {
    return {
      link: function (scope, element, attrs) {
        var model = $parse(attrs.focusMe);
        scope.$watch(model, function (value) {
          if (value === true) {
            $timeout(function () {
              element[0].focus();
            });
          }
        });

      }
    };
  });

  /* handle toggling of Forgot Password? link */
  app.directive('slideIn', function($timeout) {
    return {
      restrict: 'A',
      link: function (scope, elem) {
        scope.$watch('isForgotPasswordDetailsVisible',
          function(newValue) {
            if(newValue){
              /* init variables to provide a clean form */
              scope.isForgotPasswordUsernameEmpty = false;
              scope.popError = '';

              /* set link to active so it will push down and allow room for forgot password details form */
              $('.forgot-password-link').addClass('active');
              elem.stop(true,true).fadeIn('slow');

              /* set focus on username field in forgot password form */
              $timeout(function() {
                $('#id_forgotPasswordUsername').select().focus();
              });
            }
            else{
              elem.stop(true,true).hide();
              $('.forgot-password-link').removeClass('active');
              $('.forgot-password-link').removeClass('error');
            }
          }
        );

        scope.$watch('isForgotPasswordUsernameError',
          function(newValue) {
            if(newValue){
              $('.forgot-password-link').addClass('error');
              $('#id_forgotPasswordUsername').select().focus();
            }
            else {
              $('.forgot-password-link').removeClass('error');
            }
          }
        );

        scope.$watch('isSuccess',
          function(newValue) {
            if(newValue){
              $('.forgot-password-link').addClass('success');
            }
            else {
              $('.forgot-password-link').removeClass('success');
            }
          }
        );

        scope.$watch('clearForgotPasswordError',
          function(newValue) {
            if(newValue){
              scope.popError = '';
              $('.forgot-password-link').removeClass('error');
            }
          }
        );
      }
    };
  });
})(window.app);
