(function (app) {
  'use strict';

  app.controller('RouteCtrl', ['$scope', '$location', 'authSvc',
  function (scope, location, auth) {

    /* logical routing */
    location.replace();
    if (auth.hasToken()) {
      location.path(app.currentRoute + '/logout');
    } else {
      location.path(app.currentRoute + '/login');
    }

  }]);

})(window.app);