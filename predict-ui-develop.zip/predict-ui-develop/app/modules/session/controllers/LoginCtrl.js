(function (app) {
  'use strict';

  app.controller('LoginCtrl', ['$scope', '$q', '$location', 'authSvc', 'userContextSvc', 'usersSvc', 'accountRecoverySvc',
    function (scope, $q, location, auth, userContextSvc, usersSvc, accountRecoverySvc) {

      if (localStorage.storedName) {
        scope.model.Username = localStorage.storedName;
        scope.RememberMe = '1';
      }

      scope.forgotPasswordForm = false;
      scope.toggleAlert = false;
      scope.isSuccess = false;
      scope.isLoginError = false;
      scope.isUsernameFieldEmpty = false;
      scope.isPasswordFieldEmpty = false;
      scope.isSuccessfullySent = false;
      scope.isLocked = false;
      scope.isForgotPasswordDetailsVisible = false;
      scope.isForgotPasswordUsernameEmpty = false;
      scope.isPasswordExpiredMessageForOneDay = false;
      scope.popError = '';
      scope.isForgotPasswordUsernameError = false;
      scope.clearForgotPasswordError = false;
      scope.isResetPasswordModalOpen = false;
      scope.accountDisabled = true;
      scope.newPasswordRequirementsHelpText = 'Requirements: 8-12 characters containing at least one lowercase, one uppercase and one numeric character.';
      scope.login = function () {
        scope.isAuthenticated = false;
        scope.isLoginError = false;
        scope.loginError = '';
        if (!scope.fieldValidation()) {
          return;
        }

        if (scope.RememberMe === '1') {
          localStorage.storedName = scope.model.Username;
        }
        else {
          localStorage.storedName = '';
        }

        var loginPromise = auth.createToken(scope.model);
        scope.layout.loading = $q.all([loginPromise]).then(function (result) {
          if (result[0].IsLocked) {
            scope.isLocked = true;
            scope.minutesLeftToUnlockAccount = result[0].AccountLockoutMinutes;
            $('#is-locked-out').modal('show');
          }
          else if (result[0].IsVerifiedUser && result[0].FailedLogInAttempt > 0) {
            scope.failedLogInAttempt = result[0].MaximumFailedLoginAttempts - result[0].FailedLogInAttempt;
            if (scope.failedLogInAttempt === 1) {
              $('#is-locked-out').modal('show');
            }
            else {
              scope.isLoginError = true;
              scope.loginError = 'The username and/or password you entered is invalid. Please try again.';
            }
          }
          else if (!result[0].IsAuthorized) {
            scope.isLoginError = true;
            scope.loginError = 'The username and/or password you entered is invalid. Please try again.';
          }
          else if (result[0].AccountDisabled) {
            scope.isLoginError = true;
            scope.accountDisabled = true;
            scope.loginError = 'Your account has been disabled. Please contact your system administrator.';
          }
          else {
            scope.loginError = '';
            if (result[0].DaysLeftForPasswordExpiry !== null) {
              if (result[0].DaysLeftForPasswordExpiry <= 7 && result[0].DaysLeftForPasswordExpiry >= 1) {
                if (scope.shouldSuppressWarning(scope.model.Username)) {
                  if (result[0].DaysLeftForPasswordExpiry === 1) {
                    scope.isPasswordExpiredMessageForOneDay = true;
                  }
                  else {
                    scope.isPasswordExpiredMessageForOneDay = false;
                  }
                  scope.daysLeftForPasswordExpiry = result[0].DaysLeftForPasswordExpiry;
                  scope.isPasswordExpired = true;
                  $('#password-expire-modal').modal('show');
                }
                else {
                  scope.navigateToSelectContextPage();
                }
              }
              else if (result[0].DaysLeftForPasswordExpiry < 1) {
                scope.showResetPasswordPopup();
              }
              else {
                scope.navigateToSelectContextPage();
              }
            }
            else {
              scope.navigateToSelectContextPage();
            }
          }
          app.generic.location = null;
        });
      };

      scope.navigateToUserLandingPage = function () {
        if (app.generic.location !== null && app.generic.location !== '') {
          location.path(app.generic.location);
        } else {
          location.path(userContextSvc.getUserLandingUrl());
        }
      };
      scope.navigateToSelectContextPage = function () {
        if (app.generic.location !== null && app.generic.location !== '') {
          location.path(app.generic.location);
          // If mutliple clients are available
        } else if (userContextSvc.getUserLandingUrl() === null) {
          location.path('/accounts');
          // If only one client is available
        }  else {
          location.path(userContextSvc.getUserLandingUrl() + '/accounts');
        }
      };

      scope.closeForgotPasswordDetails = function () {
        scope.model.UsernameForgotPassword = '';
        scope.isForgotPasswordUsernameEmpty = false;
        scope.popError = '';
        scope.isForgotPasswordUsernameError = false;
      };

      scope.closeForgotPasswordRequest = function () {
        scope.loginError = '';
        scope.forgotPasswordForm = false;
        scope.isSuccess = false;
        scope.popError = '';
      };

      scope.cancelForgotPasswordRequest = function () {
        scope.loginError = '';
        scope.model.UsernameForgotPassword = '';
        scope.isForgotPasswordUsernameEmpty = false;
        scope.popError = '';
        scope.isForgotPasswordUsernameError = false;
      };

      scope.showForgotPasswordRequest = function () {
        scope.forgotPasswordForm = true;
        scope.model.UsernameForgotPassword = '';
        scope.showForgotPasswordDetails = !scope.showForgotPasswordDetails;
        scope.isForgotPasswordUsernameEmpty = false;
        scope.popError = '';
        scope.isForgotPasswordUsernameError = false;
      };

      scope.submitForgotPasswordRequest = function (formToSubmit) {

        scope.popError = '';
        scope.isForgotPasswordUsernameError = false;
        if (!scope.model.UsernameForgotPassword) {
          scope.isForgotPasswordUsernameEmpty = true;
          return;
        }
        if (!formToSubmit.$valid) {
          scope.popError = 'The username you entered is invalid. Please try again.';
          scope.clearForgotPasswordError = false;
          scope.isForgotPasswordUsernameError = true;
          return;
        }

        var forgotPasswordPromise = auth.forgotPassword(scope.model.UsernameForgotPassword);
        scope.layout.forgotpasswordloading = $q.all([forgotPasswordPromise]).then(function (data) {
          scope.isSuccess = true;
          scope.popError = '';
          scope.isForgotPasswordUsernameError = false;
          if (data[0].results.IsNotificationSent && !data[0].results.IsEmailSent) {
            scope.isSuccess = false;
            scope.popError = 'Error sending email, Please contact your system administrator.';
            scope.clearForgotPasswordError = false;
            scope.isForgotPasswordUsernameError = true;
          }
        });
      };

      scope.cancelOnLockedOutPopUp = function () {
        //scope.model.Username = '';
        scope.model.Password = '';
        scope.isSuccess = false;
        scope.isSuccessfullySent = false;
        scope.isLocked = false;
      };

      scope.resetPasswordRequest = function () {
        var resetPasswordRequestPromise = auth.forgotPassword(scope.model.Username);
        scope.layout.resetpasswordloading = $q.all([resetPasswordRequestPromise]).then(function (data) {
          if (data[0].results.IsNotificationSent) {
            scope.isSuccessfullySent = true;
          }
        });
      };

      scope.fieldValidation = function () {
        var fieldsValid = true;
        if (!scope.model.Username) {
          scope.isUsernameFieldEmpty = true;
          fieldsValid = false;
        }
        if (!scope.model.Password) {
          scope.isPasswordFieldEmpty = true;
          fieldsValid = false;
        }
        return fieldsValid;
      };

      scope.onFieldChange = function () {
        scope.isLoginError = false;
        scope.loginError = '';

        if (scope.model.Username) {
          scope.isUsernameFieldEmpty = false;
        }
        if (scope.model.Password) {
          scope.isPasswordFieldEmpty = false;
        }
      };

      scope.onForgotPasswordFieldChange = function () {
        if (scope.model.UsernameForgotPassword) {
          scope.isForgotPasswordUsernameEmpty = false;
        }
      };

      scope.checkCapsLockOn = function (e) {
        var keycode = e.keyCode ? e.keyCode : e.which;
        var shiftkeycode = e.shiftKey ? e.shiftKey : ((keycode === 16) ? true : false);
        if (((keycode >= 65 && keycode <= 90) && !shiftkeycode) || ((keycode >= 97 && keycode <= 122) && shiftkeycode)) {
          $('#caps-alert').css('display', 'block');
        }
        else {
          $('#caps-alert').css('display', 'none');
        }
      };

      scope.resetExpiredPassword = function () {
        $('#password-expire-modal').modal('hide');
        scope.addRemoveWarningSuppression(scope.model.Username, scope.DontShowWarning);
        scope.showResetPasswordPopup();
      };

      scope.continueWithExpiredPassword = function () {
        location.$$search = {};
        scope.addRemoveWarningSuppression(scope.model.Username, scope.DontShowWarning);
        if (app.generic.location !== null && app.generic.location !== '') {
          location.path(app.generic.location);
        } else {
          location.path(userContextSvc.getAccountsPage());
        }
      };

      scope.addRemoveWarningSuppression = function (username, showWaringMessage) {
        var hideExpireWarningMsg = JSON.parse(localStorage.getItem('warningSuppressionList'));
        if (!hideExpireWarningMsg) {
          hideExpireWarningMsg = [];
        }
        var index = hideExpireWarningMsg.indexOf(username);

        if (showWaringMessage && index < 0) {
          hideExpireWarningMsg.push(username);
        }
        else if (!showWaringMessage && index > -1) {
          hideExpireWarningMsg.splice(index, 1);
        }

        localStorage.setItem('warningSuppressionList', JSON.stringify(hideExpireWarningMsg));
      };

      scope.shouldSuppressWarning = function (username) {
        var hideExpireWarningMsg;
        if (localStorage.getItem('warningSuppressionList')) {
          hideExpireWarningMsg = JSON.parse(localStorage.getItem('warningSuppressionList'));
          var index = hideExpireWarningMsg.indexOf(username);
          if (index > -1) {
            return false;
          }
        }
        else {
          hideExpireWarningMsg = [];
          localStorage.setItem('warningSuppressionList', JSON.stringify(hideExpireWarningMsg));
        }
        return true;
      };


      scope.toggle = function (target) {
        switch (target) {
          case 'forgotPasswordDetails':
            scope.isForgotPasswordDetailsVisible = !scope.isForgotPasswordDetailsVisible;
            scope.model.UsernameForgotPassword = scope.model.Username;
            scope.isSuccess = false;
            break;
          default:
        }
      };

      /*Code START for password reset pop up*/
      scope.showResetPasswordPopup = function () {
        scope.resetPasswordError = '';
        if (location.search().id) {
          scope.restPasswordUsername = location.search().id;
        }
        else {
          scope.restPasswordUsername = scope.model.Username;
        }
        scope.isResetPasswordSuccess = false;
        $('#forgot-password-modal').modal('show');
        scope.isResetPasswordModalOpen = true;
        scope.model.NewPassword = '';
        scope.model.ConfirmPassword = '';
      };

      scope.closeResetPasswordPopUp = function () {
        auth.clearAuthSession();
        //location.$$search = {};
        $('#forgot-password-modal').modal('hide');
        scope.isResetPasswordSuccess = false;
        scope.verificationKey = null;
        scope.isNewPasswordFieldEmpty = false;
        scope.isConfirmPasswordFieldEmpty = false;
        scope.resetPasswordError = '';
        scope.model.NewPassword = '';
        scope.model.ConfirmPassword = '';
        scope.isResetPasswordModalOpen = false;

      };


      scope.showMessage = function () {
        $('.success-info').slideDown('slow');
      };

      scope.hideMessage = function () {
        $('.success-info').slideUp('slow');
        scope.resetPasswordError = '';
      };

      scope.resetPasswordSubmit = function () {
        if (scope.validate()) {
          if (scope.verificationKey) {
            scope.changePassword(scope.verificationKey, location.search().id, scope.model.NewPassword);
          }
          else {
            var changePasswordPromise = usersSvc.changeUserPassword(scope.model.NewPassword, scope.model.Username);

            changePasswordPromise.then(function (data) {
              if (data.results.IsSuccess) {
                scope.isResetPasswordSuccess = true;
                scope.addRemoveWarningSuppression(scope.model.Username, false);
                scope.hideMessage();
              } else if (data.results.IsPasswordRepeated) {
                scope.isResetPasswordSuccess = false;
                scope.resetPasswordError = 'The password entered has already been used. Please enter a new password.';
                scope.showMessage();
              }
              else {
                scope.resetPasswordError = 'Password change failed';
                scope.showMessage();
              }
            });
          }
        }
        return false;
      };

      scope.verifyConfirmationCode = function () {

        var message = {
          'ConfirmationCode': location.search().confirmation,
          'Username': location.search().id
        };
        var changePasswordPromise = accountRecoverySvc.verifyConfirmationCode(message);
        changePasswordPromise.then(function (data) {
          if (data.results.VerificationKey) {
            scope.verificationKey = data.results.VerificationKey;
          }
          else {
            scope.resetPasswordError = 'Invalid request. Password link has expired.';
            scope.showMessage();
            scope.model.isResetPasswordbtnDisabled = true;
          }
        });
      };

      scope.changePassword = function (verificationKey, username, newPassword) {
        var message = {
          'VerificationKey': verificationKey,
          'NewPassword': newPassword
        };

        var changePasswordPromise = accountRecoverySvc.changePassword(message, username);
        changePasswordPromise.then(function (data) {
          if (data.results.IsSuccess) {
            scope.isResetPasswordSuccess = true;
            scope.addRemoveWarningSuppression(username, false);
            scope.hideMessage();
          }
          else if (data.results.IsPasswordRepeated) {
            scope.isResetPasswordSuccess = false;
            scope.resetPasswordError = 'The password entered has already been used. Please enter a new password.';
            scope.showMessage();
          }
          else {
            scope.resetPasswordError = 'Password change failed';
            scope.showMessage();
          }
        });
      };

      scope.validate = function () {
        scope.isNewPasswordFieldEmpty = false;
        scope.isConfirmPasswordFieldEmpty = false;
        if (!scope.model.NewPassword) {
          scope.isNewPasswordFieldEmpty = true;
          scope.hideMessage();
          return false;
        }
        else if (!scope.model.ConfirmPassword) {
          scope.isConfirmPasswordFieldEmpty = true;
          scope.hideMessage();
          return false;
        }
        else if (scope.model.NewPassword !== scope.model.ConfirmPassword) {
          scope.resetPasswordError = 'The passwords entered do not match. Please try again.';
          scope.model.NewPassword = '';
          scope.model.ConfirmPassword = '';
          scope.showMessage();
          return false;
        }
        else if (!scope.passwordrPattern.test(scope.model.NewPassword)) {
          scope.resetPasswordError = 'The password entered does not meet the minimum security requirements. Please try again.';
          scope.showMessage();
          return false;
        }
        return true;
      };

      scope.onResetPasswordFieldChange = function () {
        scope.resetPasswordError = '';
        if (scope.model.NewPassword) {
          scope.isNewPasswordFieldEmpty = false;
        }
        if (scope.model.ConfirmPassword) {
          scope.isConfirmPasswordFieldEmpty = false;
        }
      };

      scope.passwordrPattern = (function () {
        var regexp = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{8,12}$/;
        return {
          test: function (value) {
            return regexp.test(value);
          }
        };
      })();


      if (location.search().confirmation && location.search().id) {
        scope.showResetPasswordPopup();
        scope.verifyConfirmationCode();
      }
      /*Code END for password reset pop up*/
    }]);
})(window.app);
