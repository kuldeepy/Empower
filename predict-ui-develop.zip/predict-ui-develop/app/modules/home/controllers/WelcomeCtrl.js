(function (app) {
  'use strict';
  app.controller('HomeWelcomeCtrl', ['$scope', 'clientSvc', 'authSvc', 'userContextSvc', '$location', 'sessionSvc', 'longTaskSvc', 'selectedContext',
  function (scope, clientSvc, authSvc, userContextSvc, location, sessionSvc, longTaskSvc, selectedContext) {

    scope.model = {};
    var selectedContextSvc = selectedContext;
    scope.isSilverpopConfigured = userContextSvc.isSilverpopConfigured;

    scope.$on('Authenticated', function () {
      setScopeData();
    });

    function getUserNotifications() {
      longTaskSvc.update(false);
    }

    if (authSvc.isSystemAdministrator() || authSvc.isClientAdministrator()) {
      var allowedClients = _.pluck(authSvc.getAdminClientKeys(), 'ClientKey');
      scope.$emit('loadClientInfo', [scope.isSilverpopConfigured, scope.dataAvailThroughDate]);
      scope.loading = clientSvc.loadClients().then(function (clients) {
        scope.model.clients = _.filter(clients, function (client) {
          return _.contains(allowedClients, client.Key) || authSvc.isSystemAdministrator();
        });
      });
    }

    var setScopeData = function () {
      scope.model.username = authSvc.getUsername();
      scope.model.fullName = authSvc.getFullName();
      scope.model.roles = authSvc.getRoles();
      scope.model.expDate = authSvc.getTokenExpirationDate();
      scope.model.issuedAt = authSvc.getTokenIssueDate();
      scope.model.clientContext = userContextSvc.getApiClientKey();
      if (!authSvc.isSystemAdministrator() && !authSvc.isClientAdministrator()) {
        scope.model.userOrgs = getOrganizationModels();
      }
    };

    var getOrganizationModels = function () {
      var orgs = userContextSvc.getUserOrganizations();
      for (var i = orgs.length - 1; i >= 0; i -= 1) {
        orgs[i].ListManagementLinkLabel = (orgs.length === 1 ? 'Manage Lists' : orgs[i].Name);
      }
      return orgs;
    };

    var getListManagementUrl = function (orgKey) {
      var clientKey = userContextSvc.getClientKey();
      scope.orgNameValue = userContextSvc.getOrganizationName(orgKey);
      scope.$emit('getOrgValue');
      if (clientKey !== '') {
        if (scope.linkType.toUpperCase() === 'LIST') {
          return '/' + clientKey + '/' + orgKey + '/lists';
        }
        else {
          return '/' + clientKey + '/' + orgKey + '/auditreport';
        }
      }
      return '';
    };

    scope.securityTrim = function (rolesArray) {
      var found = false;
      if (authSvc.isSystemAdministrator()) {
        return true;
      }
      else {
        angular.forEach(rolesArray, function (role) {
          if (!found) {
            if (scope.model.roles.indexOf(role) !== -1) {
              found = true;
            }
          }
        });
      }
      return found;
    };

    scope.onClientValueChange = function () {
      var selectedClient = scope.defaultClientSelected;
      scope.model.userOrgs = [];
      console.log('selectedClient ', selectedClient);
      if (selectedClient.toUpperCase() !== 'SELECT CLIENT') {
        var arrClient = selectedClient.toString().split('~');
        console.log('arrClient ', arrClient);
        if (arrClient.length > 1) {
          scope.clientKeyValue = arrClient[0];
          scope.clientNameValue = arrClient[1];
          sessionSvc.set('clientName', scope.clientNameValue);
          scope.$emit('getClientValue');
        }

        var client = _.find(scope.model.clients, { 'Key': scope.clientKeyValue.toLowerCase() });
        console.log('client .find', client);
        scope.isSilverpopConfigured = client.IsSilverpopConfigured;
        scope.dataAvailThroughDate = client.DATDate;
        scope.$emit('loadClientInfo', [scope.isSilverpopConfigured, scope.dataAvailThroughDate]);
        angular.forEach(client.Organizations, function (org) {
          scope.model.userOrgs.push({ 'OrgKey': org.Key, 'ListManagementLinkLabel': org.Name });
        });
        scope.defaultOrgSelected = 'Select Organization';
      }
      else {
        scope.isOkDisabled = true;
      }
    };

    scope.onOrganizationValueChange = function () {
      var selectedOrganization = scope.defaultOrgSelected;

      if (selectedOrganization.toUpperCase() === 'SELECT ORGANIZATION') {
        scope.isOkDisabled = true;
      }
      else {
        var arrOrg = selectedOrganization.toString().split('~');
        console.log('arrOrg: ', arrOrg);
        if (arrOrg.length > 1) {
          scope.orgKeyValue = arrOrg[0];
          scope.orgNameValue = arrOrg[1];
          sessionSvc.set('orgName', scope.orgNameValue);
          scope.$emit('getOrgValue');
        }
        scope.isOkDisabled = false;
      }
    };

    scope.openManageListsModal = function (linkType) {
      var clients;
      scope.linkType = linkType;
      clients = scope.model.clients;
      var org = clients[0].Organizations[0];
      if (authSvc.isSystemAdministrator() || authSvc.isClientAdministrator()) {
        scope.canShowClientOption = true;
        scope.defaultClientSelected = 'Select Client';
        scope.defaultOrgSelected = 'Select Organization';
        scope.isOkDisabled = true;
        $('#manageListsModal').modal('show');
        if (linkType.toUpperCase() === 'LIST') {
          location.path('/' + clients[0].Key + '/' + org.Key + '/lists');
        }
        else {
          location.path('/' + clients[0].Key + '/' + org.Key + '/auditReport');
        }
      } else {
        var orgs = scope.model.userOrgs;
        location.path(getListManagementUrl(orgs[orgs.length - 1].OrgKey, linkType));
      }
    };
    scope.goToListManagementPage = function() {
      location.path('/' + selectedContextSvc.client + '/' + selectedContextSvc.organization + '/lists');
    };
    scope.goToAuditPage = function() {
      location.path('/' + selectedContextSvc.client + '/' + selectedContextSvc.organization + '/auditReport');
    };
    var getauditManagementUrl = function (orgKey) {
      var clientKey = userContextSvc.getClientKey();
      if (clientKey !== '') {
        return '/' + clientKey + '/' + orgKey + '/auditReport';
      }
      return '';
    };

    scope.goToAuditReporting = function () {
      var orgs = scope.model.userOrgs;
      location.path(getauditManagementUrl(orgs[orgs.length - 1].OrgKey));
    };

    scope.onOKClick = function () {
      scope.selectedClient = '';
      if (authSvc.isSystemAdministrator() || authSvc.isClientAdministrator()) {
        scope.selectedClient = scope.clientKeyValue;
        scope.$emit('loadClientInfo', [scope.isSilverpopConfigured, scope.dataAvailThroughDate]);
      }
      sessionSvc.clear('selectLocation.locations');

      scope.selectedOrg = scope.defaultOrgSelected.toString().split('~')[0];

      $('.modal-backdrop').remove();

      if (scope.selectedClient !== '') {
        if (scope.linkType.toString().toUpperCase() === 'LIST') {
          location.path('/' + scope.selectedClient + '/' + scope.selectedOrg + '/lists');
        }
        else {
          location.path('/' + scope.selectedClient + '/' + scope.selectedOrg + '/auditreport');
        }
      }
      else {
        location.path(getListManagementUrl(scope.selectedOrg, scope.linkType));
      }
    };
    setScopeData();
    getUserNotifications();
  }
  ]);
})(window.app);
