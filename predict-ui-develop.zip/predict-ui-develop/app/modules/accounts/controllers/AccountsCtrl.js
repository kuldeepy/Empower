(function (app) {
  'use strict';

  app.controller('AccountsCtrl', ['$scope', 'authSvc', 'userContextSvc', 'clientSvc',
    function(scope, authSvc, userContextSvc, clientSvc) {
    scope.model = {
      routeParams: {}
    };
    var authClients = authSvc.getClientKeys();
    scope.selectContextInstructions = userContextSvc.expandOrCollapseNodes(authClients).description;
    scope.headingText = userContextSvc.expandOrCollapseNodes(authClients).heading;

    scope.loading = clientSvc.getAllowedClientOrg().then(function(clients) {
      if (clients.length === 1 && clients[0].Organizations.length === 1){
        scope.setUserContext(clients[0], clients[0].Organizations[0]);
      }
      scope.model.clients = clients;
    });

    userContextSvc.expandOrCollapseNodes(authClients);

    // Broadcast client and organization as a global event
    scope.setUserContext = function(client, organization) {
      userContextSvc.setUserContext(client, organization);
    };
  }]);

})(window.app);
