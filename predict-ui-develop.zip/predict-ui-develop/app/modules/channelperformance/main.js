(function (app) {
  'use strict';

  var modulePath = 'modules/channelperformance',
	ctrlRoot = app.root + modulePath + '/controllers/';
	app.controller('ChannelPerformanceCtrl', ['$scope', function (scope) {
    scope.modulePath = modulePath;
		scope.model = {
			routeParams: {}
		};
	}]);

	$.when(
		$.getScript(ctrlRoot + 'BrightWhistleCtrl.js'),
    $.getScript(ctrlRoot + 'PrintCtrl.js'))
    .done(function () {
			app.publish('moduleReady', modulePath);
		});

})(window.app);