﻿(function (app) {
  'use strict';
  app.controller('BrightWhistleCtrl', ['$scope', 'userContextSvc',
	function (scope, userContextSvc) {
    scope.homelink = userContextSvc.getUserLandingUrl();
    scope.header = 'DashBoard';
    scope.imageUrl = '../../../images/Dashboard.png';
    scope.toogleButton = function (changedValue) {
      switch (changedValue) {
        case 'DashBoard':
          scope.header = 'DashBoard';
          scope.imageUrl = '../../../images/Dashboard.png';
          return;
        case 'ControlPanel':
          scope.header = 'ControlPanel';
          scope.imageUrl = '../../../images/ControlPanel.png';
          return;
        case 'Stats':
          scope.header = 'Stats';
          scope.imageUrl = '../../../images/Stats.png';
          return;
      }
    };
	}
  ]);
})(window.app);