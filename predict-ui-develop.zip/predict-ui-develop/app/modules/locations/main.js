(function (app) {
  'use strict';

  /* module root controller */
  app.controller('LocationsCtrl', ['$scope', '$http', 'userContextSvc', function (scope, http, userContextSvc) {
    // shared data
    scope.model = {
      routeParams: {}
    };

    var logError  = function(error){
      console.log(error.data.message);
      console.log(error);
    };

    scope.getLocations = function() {
      return http({
        cache: true,
        method: 'GET',
        url: app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/orgs/' + userContextSvc.getOrgKey() + '/locations'
      }).then(
        function(response) {
          return response.data.results.Locations;
        },
        function(error) {
          logError(error);
        });
    };
  }]);

})(window.app);