(function (app) {
	'use strict';

	app.controller('selectCtrl', ['$scope', function (scope) {
		scope.getLocations().then(function (data) {
			scope.model.locations = data;
		});
	}]);
})(window.app);
