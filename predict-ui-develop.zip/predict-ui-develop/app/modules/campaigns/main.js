(function (app) {
  'use strict';

	var modulePath ='modules/campaigns',
		ctrlRoot = app.root + modulePath + '/controllers/';

	app.controller('campaignsCtrl', ['$scope', function (scope){
		
		scope.modulePath = modulePath;
		
		scope.model = {
			routeParams: {}
		};

	}]);

	$.when(
		$.getScript(ctrlRoot + 'listCtrl.js'),
		$.getScript(ctrlRoot + 'detailCtrl.js'))
	.done(function(){
			app.publish('moduleReady', modulePath);
		});

})(window.app);