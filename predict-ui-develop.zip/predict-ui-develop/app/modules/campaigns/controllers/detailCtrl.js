(function (app) {
  'use strict';

	app.controller('detailCtrl', ['$scope', 'campaignSvc', function (scope, campaignSvc) {
		var campaignId = scope.model.routeParams.id;
		campaignSvc.getCampaign(campaignId).then(function (data) {
			scope.model.campaign = data;
		});
	}]);
})(window.app);
