(function (app) {
  'use strict';

	app.controller('listCtrl', ['$scope', 'campaignSvc', function (scope, campaignSvc) {
		campaignSvc.listCampaigns().then(function (data) {
			scope.model.campaigns = data;
		});
	}]);
})(window.app);
