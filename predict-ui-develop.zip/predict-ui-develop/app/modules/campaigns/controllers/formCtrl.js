﻿(function (app) {
  'use strict';

	app.controller('formCtrl', ['$scope', 'campaignSvc', function (scope, campaignSvc) {

		var campaignId = scope.model.routeParams.id;

		if(campaignId !== null){
			campaignSvc.getCampaign(campaignId).then(function (data) {
				scope.model.campaign = data;

			});
		}

		scope.save = function () {

		};

	}]);
})(window.app);
