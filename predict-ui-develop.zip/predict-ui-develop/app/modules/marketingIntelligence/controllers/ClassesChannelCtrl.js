﻿(function (app) {
  'use strict';
  app.controller('ClassesChannelCtrl', ['$scope', 'userContextSvc',
  function (scope, userContextSvc) {
    scope.homelink = userContextSvc.getUserLandingUrl();
  }
  ]);
})(window.app);