﻿(function (app) {
  'use strict';
  app.controller('FacebookUserCtrl', ['$scope', 'userContextSvc',
  function (scope, userContextSvc) {
    scope.homelink = userContextSvc.getUserLandingUrl();
  }
  ]);
})(window.app);