﻿(function (app) {
  'use strict';
  app.controller('NewMoversCtrl', ['$scope', 'userContextSvc',
  function (scope, userContextSvc) {
    scope.homelink = userContextSvc.getUserLandingUrl();
  }
  ]);
})(window.app);