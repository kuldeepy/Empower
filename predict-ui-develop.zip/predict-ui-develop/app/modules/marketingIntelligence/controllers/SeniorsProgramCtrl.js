﻿(function (app) {
  'use strict';
  app.controller('SeniorsProgramCtrl', ['$scope', 'userContextSvc',
  function (scope, userContextSvc) {
    scope.homelink = userContextSvc.getUserLandingUrl();
  }
  ]);
})(window.app);