(function (app) {
  'use strict';

  var modulePath = 'modules/marketingIntelligence',
  ctrlRoot = app.root + modulePath + '/controllers/';
  app.controller('MarketingIntelligenceCtrl', ['$scope', function (scope) {
    scope.modulePath = modulePath;
    scope.model = {
      routeParams: {}
    };
  }]);

  $.when(
    $.getScript(ctrlRoot + 'MarketingIntelligenceCtrl.js'),
    $.getScript(ctrlRoot + 'ClassesChannelCtrl.js'),
    $.getScript(ctrlRoot + 'FacebookUserCtrl.js'),
    $.getScript(ctrlRoot + 'MultiChannelCtrl.js'),
    $.getScript(ctrlRoot + 'NewMoversCtrl.js'),
    $.getScript(ctrlRoot + 'SeniorsProgramCtrl.js'))
    .done(function () {
      app.publish('moduleReady', modulePath);
    });

})(window.app);