(function(app) {
  'use strict';
  var modulePath = 'modules/listBuild';
  app.controller('listBuildCtrl', ['$scope', '$state', '$http', '$location', '$injector', '$modal', '$q', '$timeout', 'sessionSvc',
    'util', 'userContextSvc', 'listStateSvc', 'listSvc', 'workflow', 'tabAndStepDefinitions', '_', 'calculationSvc','listNameSvc', 'alertSvc', 'etlDataUpdateSvc', '$rootScope',
    function(scope, state, http, location, injector, $modal, $q, $timeout, sessionSvc,
      util, userContextSvc, listStateSvc, listSvc, workflow, getTabAndStepDefinitions, _, calculationSvc, listNameSvc, alertSvc, etlDataUpdateSvc, rootScope) {

      scope.resetState = function() {
        sessionSvc.clear('calc.personTypeCounts');
        listStateSvc.clear();
        scope.modulePath = modulePath;
        scope.isFirstStepInFlow = false;
        scope.isLastStepInFlow = false;
        scope.isStepComplete = false;
        scope.isNextDisabled = true;
        scope.isPreviousDisabled = false;
        scope.isSaveAndCloseDisabled = false;
        scope.isCancelDisabled = false;
        scope.isCancelAlertVisible = false;
        scope.isSavePromptVisible = false;
        scope.isInvalidNameVisible = false;
        scope.isSaveOnly=false;
        scope.listName = null;
        scope.stepDefinitions = [];
        scope.tabDefinitions = [];
        scope.tabs = [];
        scope.steps = [];
        scope.quickCounts = [];
        scope.listNameValidationError = false;
        scope.listItem = {};
        scope.listItem.Name = '';
      };

      var hasCountUpdated=false;
      scope.resetState();

      (function() {
        function adjustQuickCountSelection(adjustment) {
          var newIndex = _.findIndex(scope.quickCounts, {
            selected: true
          }) + adjustment;

          if (newIndex >= scope.quickCounts.length) {
            newIndex = 0;
          } else if (newIndex < 0) {
            newIndex = scope.quickCounts.length - 1;
          }

          _.forEach(scope.quickCounts, function(quickCount, index) {
            quickCount.selected = newIndex === index;
          });
        }

        scope.nextQuickCount = _.bind(adjustQuickCountSelection, {}, 1);
        scope.previousQuickCount = _.bind(adjustQuickCountSelection, {}, -1);
      })();

      var tabAndStepDefinitions = getTabAndStepDefinitions();

      scope.tabDefinitions = tabAndStepDefinitions.tabs;
      scope.stepDefinitions = tabAndStepDefinitions.steps;

      var summaryStepName = 'summary';
      var processPage = function() {
        console.log('process page');
        scope.currentListState = listStateSvc.get();
        if (scope.currentListState.Name){
          scope.listItem.Name = scope.currentListState.Name;
        }
        if (app.routeParams.length > 0 && app.routeParams[0]) {

          var promise = etlDataUpdateSvc.handleETLUpdates(scope.currentListState,userContextSvc.getClientKey());

          promise.then(function(countUpdated){
            hasCountUpdated= countUpdated;
            if(!hasCountUpdated)
            {
              getQuickCount();
            }
          });
        }

        scope.model = {
          routeParams: {}
        };

        scope.close = function() {
          location.path('/' + userContextSvc.getClientKey() + '/' + userContextSvc.getOrgKey() + '/lists');
        };

        //This is to update the count and show the count table in summary page.
        scope.$on('updateCount', function () {
          scope.showQuickCount=true;
          getQuickCount();
        });

        scope.hasSaved = false;

        function continueSave() {
          scope.currentListState.CurrentUIState.currentStep = state.current.name;
          scope.currentListState.CurrentUIState.isComplete = isWizardComplete();
          if(scope.currentListState.CurrentUIState.countUpdateStatus)
          {
            if(scope.currentListState.CurrentUIState.countUpdateStatus.toUpperCase()==='UPDATED')
            {
              scope.currentListState.CurrentUIState.countUpdateStatus = 'Saved';
            }
          }
          if (!scope.currentListState.Name) {
            scope.currentListState.Name = scope.listName;
            return listSvc.createList(scope.currentListState);
          } else {
            scope.currentListState.Name = scope.listName;
            return listSvc.updateList(scope.currentListState)
              .then(function(success) {
                if (success) {
                  return 'Update Succeeded';
                } else {
                  return $q.reject('Update Failed');
                }
              });
          }
        }

        function resetSaveFlag() {
          $timeout(function() {
            scope.hasSaved = false;
          }, 1000);
        }
        scope.save = function() {
          if (!scope.currentListState.Name && !scope.listName) {
            return $q.reject('List must have a name');
          }
          return listNameSvc.checkListNameExist(scope.currentListState, scope.listName).then(function () {
            return continueSave();
          }, function(){
            return $q.reject('Exists');
          });
        };

        scope.saveAndClose = function() {
          if (!scope.hasSaved) {
            scope.hasSaved = true;
            var promise = scope.save();
            return promise.then(function() {
              listStateSvc.isMarketingChannelNotDefined = undefined;
              if(!scope.isSaveOnly){
                location.path('/' + userContextSvc.getClientKey() + '/' + userContextSvc.getOrgKey() + '/lists');
              }
            }, function() {
              scope.isInvalidNameVisible = true;
              resetSaveFlag();
              scope.isSaveOnly=false;
              return $q.reject('Exists');
            });
          }
        };
        scope.get = function(Id) {
          if (Id === undefined || Id === null) {
            return listStateSvc.get();
          } else {
            return listSvc.get(Id);
          }
        };
        scope.goToNext = function() {
          var nextStepOverride;

          var override = function(nextStepName) {
            console.log('override', nextStepName);
            nextStepOverride = nextStepName;
          };

          scope.$broadcast('next', override);

          scope.stepViewTransitionClass = 'next';

          if (nextStepOverride) {
            workflow.go(nextStepOverride);
          } else {
            workflow.next();
          }
        };
        scope.go = _.bind(workflow.go, workflow);
        scope.goToPrevious = function() {
          var nextStepOverride;

          var override = function(nextStepName) {
            nextStepOverride = nextStepName;
          };

          scope.$broadcast('previous', override);

          scope.stepViewTransitionClass = 'previous';

          if (nextStepOverride) {
            workflow.go(nextStepOverride);
          } else {
            workflow.previous();
          }
        };
        scope.completeStep = function(complete) {
          scope.isStepComplete = complete;
          scope.enableNextButton(complete);
        };
        scope.updateButtonVisibility = function() {
          scope.isFirstStepInFlow = state.current.name === 'listName';
          scope.isLastStepInFlow = state.current.name === 'summary';
          if (state.current.name === 'summary') {
            scope.isFirstStepInFlow = !listStateSvc.get().CurrentUIState.hasVisited.prioritizeCountType;
          }
        };
        scope.enableNextButton = function(enable) {
          if (enable === true) {
            scope.isNextDisabled = !scope.isStepComplete;
          } else {
            scope.isNextDisabled = true;
          }
        };
        scope.enablePreviousButton = function(enable) {
          scope.isPreviousDisabled = !enable;
        };
        scope.enableSaveAndCloseButton = function(enable) {
          scope.isSaveAndCloseDisabled = !enable;
        };
        scope.enableCancelButton = function(enable) {
          scope.isCancelDisabled = !enable;
        };
        scope.showCancelAlert = function(show) {
          scope.enableButtons(!show);
          scope.isCancelAlertVisible = show;
        };

        scope.confirmCancel = function() {
          var modalDialog = $modal.open({
            templateUrl: 'confirmCancel.html',
            controller: function($scope, $modalInstance) {
              $scope.yes = function() {
                $modalInstance.close('yes');
              };

              $scope.no = function() {
                $modalInstance.dismiss('no');
              };
            }
          });

          modalDialog.result.then(function() {
            scope.close();
          });
        };

        scope.enableButtons = function(enable) {
          scope.enableNextButton(enable);
          scope.enableCancelButton(enable);
          scope.enableSaveAndCloseButton(enable);
          scope.enablePreviousButton(enable);
        };

        scope.$on('saveMeOnly', function(event,contextInfo){
          scope.contextChangeInfo = contextInfo;
          scope.checkPromptForName(contextInfo);
        });

        scope.checkPromptForName = function(contextInfo) {
          //$scope and scope varaiable are using here to differentiate the parent and child scope.
          $modal.open({
            templateUrl: 'saveAndClose.html',
            controller: saveAndCloseController
          });

          function saveAndCloseController($scope, $modalInstance) {
            $scope.isInvalidNameVisible = false;
            if(!scope.listItem.Name){
              scope.listItem.Name = listSvc.currentListName.get();
            }
            $scope.showSaveAndCloseButton = contextInfo ? false : true;
            $scope.listItem = angular.copy(scope.listItem);  // copying it to local variable will prevent changing of name if pressed cancel
            $scope.isSaveDisabled = $scope.listItem.Name ? false : true;
            setTimeout(function() {
              $scope.focus();
            }, 100);

            $scope.save = function() {
              $scope.listNameForm.$setDirty();
              if (!$scope.listNameForm.$valid) {
                return;
              }
              scope.listName = $scope.listItem.Name;
              listSvc.currentListName.set(scope.listName);
              var promise = scope.saveAndClose();
              promise.then(function() {
                scope.listItem.Name = $scope.listItem.Name; // writing back to global variable
                if(scope.isSaveOnly){
                  $modalInstance.dismiss('cancel');
                  scope.isSaveOnly=false;
                  scope.hasSaved = false;
                }
                else{
                  $modalInstance.close();
                  scope.close();
                }
                if(contextInfo) {
                  userContextSvc.setUserContext(contextInfo.Client, contextInfo.Organization);
                }
              }, function(reason) {
                listSvc.currentListName.clear();
                if (reason === 'Exists') {
                  $scope.isInvalidNameVisible = true;
                  $scope.focus();
                } else {
                  console.log('Error saving list: ', reason);
                }
              });
            };

            $scope.saveOnly=function(){
              scope.isSaveOnly=true;
              $scope.save();
            };

            $scope.cancel = function() {
              $modalInstance.dismiss('cancel');
            };

            $scope.focus = function() {
              angular.element('#list-name').focus();
            };

            $scope.listNameChanged = function() {
              if (typeof($scope.listItem.Name) === 'undefined' || $scope.listItem.Name === null) {
                $scope.isSaveDisabled = true;
              } else {
                $scope.isSaveDisabled = $scope.listItem.Name.length === 0;
              }

              $scope.isInvalidNameVisible = false;
            };
          }
        };

        scope.initializeStep = function(stepName, stepComplete) {
          scope.updateButtonVisibility();
          scope.completeStep(stepComplete);
          app.publish('afterChangeStep', stepName);
          scope.updateWizardHeaders(stepName);
          scope.stepName = stepName;
        };

        scope.getTab = function(name) {
          return _.find(scope.tabDefinitions, {
            name: name
          });
        };

        scope.tabIndex = 0;
        scope.stepIndex = 0;
        scope.tabsLength = scope.tabDefinitions.length;

        scope.$watch('tabIndex', function() {
          scope.steps = getSteps();

          scope.updateWizardHeaders(scope.stepName);
        });

        function getSteps() {
          console.log('tabindex', scope.tabIndex);
          return _.map(scope.stepDefinitions[scope.tabIndex], function(step) {
            return _.extend({}, step, {

              //completed: index <= scope.stepIndex,
              //selectionCss: getSelectionCss(index, scope.stepIndex)
            });
          });
        }

        scope.updateWizardHeaders = function(currentStepName) {
          if (currentStepName === 'radius' || currentStepName === 'serviceArea' || currentStepName === 'anotherRadius') {
            currentStepName = 'serviceAreaRadius';
          }
          canShowQuickCount(currentStepName);

          for (var i = 0; i < scope.stepDefinitions.length; i = i + 1) {
            for (var j = 0; j < scope.stepDefinitions[i].length; j = j + 1) {
              if (scope.stepDefinitions[i][j].name === currentStepName) {
                scope.tabIndex = i;
                scope.stepIndex = j;
                break;
              }
            }
          }

          if (!scope.tabs || scope.tabs.length === 0) {
            scope.tabs = scope.tabDefinitions;
            _.first(scope.tabs).selected = true;
            scope.updateButtonVisibility();

          } else {
            _.forEach(scope.tabs, function(tab, index) {
              tab.selected = index === scope.tabIndex;
            });
          }

          if (!scope.steps || scope.steps.length === 0) {
            scope.steps = getSteps();
          } else {
            _.forEach(scope.steps, function(step, index) {
              step.selected = index === scope.stepIndex;
            });
          }
        };

        function isWizardComplete() {
          return _.every(scope.tabs, function(e) {
            return e.completed();
          });
        }

        var makeTargetingUndefined=function(){
          console.log('resetting Distribution');
          scope.currentListState.Distribution = undefined;
          alertSvc.add({ Type: 'Error', Title: 'Revise Targeting.', Source: 'TargetingChange', Message: '' });
        };

        scope.resetDistributeCounts = function(lastKnownCounts) {
          if (scope.currentListState !== undefined) {
            var lastCalc = _.first(lastKnownCounts);
            if (scope.currentListState.DistributeByHousehold && scope.currentListState.Distribution !== undefined && lastCalc !== undefined) {
              if (scope.currentListState.Distribution.AvailableCount !== lastCalc.totalCountForHousehold) {
                makeTargetingUndefined();
              }
            } else if (scope.currentListState.Distribution !== undefined && lastCalc !== undefined) {
              if (scope.currentListState.Distribution.AvailableCount !== lastCalc.totalCountForIndividual) {
                makeTargetingUndefined();
              }
            }
          }
        };

        var markDirty = function() {
          //"Update Count" link needs to be displayed only when a location has been selected and there is a change in available count.
          //marking list Distribution as undefined whenever there is a change in available count. Summary page doesn't impact available count.
          if(listStateSvc.isLocationDefined() && scope.stepName !== summaryStepName){
            scope.quickCountDirty = true;
            var listStateChanges = listStateSvc.get();
            listStateChanges.CurrentUIState.isComplete = false;
            listStateChanges.IsCountDirty = true;
            listStateSvc.set(listStateChanges);
          }
          scope.$broadcast('list dirty');
        };

        var markLocPrefDirty = function() {
          //We only want to recalculate location preferencing when necessary, set isLocPrefDirty to true to force recalculation
          if (listStateSvc.isLocationDefined() && scope.stepName !== summaryStepName) {
            var listStateChanges = listStateSvc.get();
            listStateChanges.IsLocPrefDirty = true;
            listStateSvc.set(listStateChanges);
          }
        };

        var markCountAndLocPrefDirty = function() {
          markDirty();
          markLocPrefDirty();
        };

        var hideCountsFromSteps = function(stepName){
          return (((stepName.toUpperCase() === 'RECIPE' || stepName.toUpperCase() === 'LISTNAME') && !listStateSvc.isLocationDefined()) ||
            stepName.toUpperCase() === 'SELECTLOCATION' || stepName.toUpperCase() === 'SERVICEAREARADIUS');
        };

        var canShowQuickCount = function(stepName){
          if(stepName){
            if(hideCountsFromSteps(stepName)){
              scope.quickCountReady = false;
            }
            else if(!listStateSvc.isLocationDefined()){
              scope.showQuickCount = false;
              scope.quickCountDirty = false;
            }
            else{
              if(hasCountUpdated && stepName.toUpperCase()==='SUMMARY')
              {
                scope.showQuickCount = false;
                scope.quickCountDirty = true;
              }
              else if(hasCountUpdated && stepName.toUpperCase()!=='SUMMARY')
              {
                scope.quickCountDirty = true;
                scope.showQuickCount = true;
                getQuickCount();
                scope.currentListState.CurrentUIState.countUpdateStatus='Updated';
              }
              else
              {
                scope.showQuickCount = true;
              }
              scope.quickCountReady = true;
            }
          }
        };

        app.subscribe('afterChangeStep', function(stepName) {
          console.log('afterChangeStep', stepName);
          canShowQuickCount(stepName);
          scope.currentListState.CurrentUIState.hasVisited =
            scope.currentListState.CurrentUIState.hasVisited || {};
          scope.currentListState.CurrentUIState.hasVisited[stepName] = true;
          scope.currentListState.CurrentUIState.currentSubStepName = stepName;
        });

        //Watches the values returned by the function and marks the listcount as dirty if they change.
        scope.$watch(function() {
          var listState = scope.currentListState;
          if (!listState) {
            return;
          }

          return {
            recipeId: listState.RecipeId,
            filterValueSelections: listState.FilterValueSelections,
            segments: listState.Segments,
            seedListIds: listState.SeedListIds,
            excludedPastListIds: listState.ExcludedPastListIds,
            includedPastListIds: listState.IncludedPastListIds,
            excludeHoldouts: listState.ExcludeHoldouts
          };
        }, markDirty, true);

        //Watches the values returned by the function and marks location preferencing as dirty if they change.
        scope.$watch(function() {
          var listState = scope.currentListState;
          if (!listState) {
            return;
          }

          return {
            recipeId: listState.RecipeId,
            locationDescriptors: listState.LocationDescriptors,
            filterValueSelections: listState.FilterValueSelections,
            seedListIds: listState.SeedListIds,
            excludedPastListIds: listState.ExcludedPastListIds,
            includedPastListIds: listState.IncludedPastListIds,
            excludeHoldouts: listState.ExcludeHoldouts
          };
        }, markLocPrefDirty, true);

        //Watches the value changes in service area and marks the listcount as dirty if they change.
        scope.$watch('currentListState.LocationDescriptors[currentListState.CurrentUIState.CurrentLocationIndex].SelectedZipCodes', markCountAndLocPrefDirty);

        //Watches the value changes in radius and marks the listcount as dirty if they change.
        scope.$watch('currentListState.LocationDescriptors[currentListState.CurrentUIState.CurrentLocationIndex].RadiusDescriptors', function (newValue, oldValue) {
          if(newValue === undefined || oldValue === undefined || newValue.length === 0){
            return;
          }
          var radiusValue = oldValue;
          if(newValue.length > oldValue.length){
            radiusValue = newValue;
          }
          if(newValue.length !== oldValue.length){
            markCountAndLocPrefDirty();
            return;
          }
          for(var i = 0; i < radiusValue.length; i+=1) {
            if(newValue[i].SelectedLocationId!==oldValue[i].SelectedLocationId){
              markCountAndLocPrefDirty();
              return;
            }
            if(newValue[i].RadiusInMiles !== oldValue[i].RadiusInMiles){
              markCountAndLocPrefDirty();
              return;
            }
            if(newValue[i].IsValidRadius && newValue[i].IsCustomAddress && newValue[i].EditCustomAddressEnable){
              if(newValue[i].Address !== oldValue[i].Address){
                markCountAndLocPrefDirty();
                return;
              }
            }
            markCheckDirty(newValue[i].AvailableZipCodeIds, oldValue[i].AvailableZipCodeIds);
            markCheckDirty(newValue[i].AdditionalZipCodeIds, oldValue[i].AdditionalZipCodeIds);
            markCheckDirty(newValue[i].ExcludedZipCodeIds, oldValue[i].ExcludedZipCodeIds);
          }
        }, true);

        //This method checks changes in zipcodes and marks the listcount as dirty if they change.
        var markCheckDirty = function(newZipCodeIds, oldZipCodeIds) {
          if(newZipCodeIds && oldZipCodeIds){
            var zipCodeIds = oldZipCodeIds;
            if(newZipCodeIds.length > oldZipCodeIds.length){
              zipCodeIds = newZipCodeIds;
            }
            if(zipCodeIds.length === 0){
              return;
            }
            for(var j=0; j < zipCodeIds.length;j+=1){
              if(newZipCodeIds[j] !== oldZipCodeIds[j]){
                markCountAndLocPrefDirty();
                return;
              }
            }
          }
        };

        (function() {
          // Set service area text for location descriptors

          var addComma = function(text) {
            if (text === '') {
              return text;
            }
            text += ', ';
            return text;
          };

          var addServiceAreaText = function(loc, areaName) {
            loc.ServiceAreaText = addComma(loc.ServiceAreaText);
            loc.ServiceAreaText += areaName;
          };

          scope.$watch('currentListState.LocationDescriptors', function() {
            if (!scope.currentListState) {
              return;
            }

            _.forEach(scope.currentListState.LocationDescriptors, function(loc) {
              loc.ServiceAreaText = '';
              if (loc.UsePrimaryServiceArea) {
                addServiceAreaText(loc, 'Primary');
              }
              if (loc.UseSecondaryServiceArea) {
                addServiceAreaText(loc, 'Secondary');
              }
              if (loc.UseTertiaryServiceArea) {
                addServiceAreaText(loc, 'Tertiary');
              }
              if (loc.ServiceAreaText === '') {
                loc.ServiceAreaText = 'No';
              }
            });
          }, true);

          scope.$watch('currentListState.CurrentUIState.LocationDescriptor', function(loc) {
            if (!loc) {
              return;
            }

            loc.ServiceAreaText = '';
            if (loc.UsePrimaryServiceArea) {
              addServiceAreaText(loc, 'Primary');
            }
            if (loc.UseSecondaryServiceArea) {
              addServiceAreaText(loc, 'Secondary');
            }
            if (loc.UseTertiaryServiceArea) {
              addServiceAreaText(loc, 'Tertiary');
            }
            if (loc.ServiceAreaText === '') {
              loc.ServiceAreaText = 'No';
            }
          }, true);
        })();

        scope.$on('update quick count', function() {
          if (scope.quickCountDirty) {
            getQuickCount();
          }
        });

        scope.$on('getQuickCount', function(){
          getQuickCount();
        });

        if (app.routeParams.length > 0) {
          state.go('summary',{},{reload: true});
        } else {
          state.go('listName');
        }
      };

      scope.location = location;

      scope.$watch('location.hash()', function(newValue) {
        console.log('newValue', newValue);

        //Check for null locations in listState before switching views if not going to location view
        if (newValue !== 'selectLocation') {
          if(scope.currentListState)
          {
            var badDescriptor = _.find(scope.currentListState.LocationDescriptors, function (loc) {
              return !loc.LocationId || loc.LocationId === '';
            });

            if (badDescriptor) {
              var index = scope.currentListState.LocationDescriptors.indexOf(badDescriptor);
              scope.currentListState.LocationDescriptors.splice(index, 1);
              if (scope.currentListState.LocationDescriptors.length > 0) {
                scope.currentListState.CurrentUIState.CurrentLocationIndex = scope.currentListState.LocationDescriptors.length - 1;
              }
            }
          }
        }

        if (newValue) {
          state.go(newValue);
        }
      });

      scope.$watch('currentListState.CurrentUIState.selectedSegment', selectQuickCount);
      scope.$on('quick count refreshed', function() {
        selectQuickCount(scope.currentListState.CurrentUIState.selectedSegment);
      });

      scope.quickCountLoading = [];

      var setCalcDirtyFlags = function(isDirty) {
        scope.quickCountDirty = isDirty;
        scope.currentListState.IsLocPrefDirty = isDirty;
        scope.currentListState.IsCountDirty = isDirty;
      };

      var getQuickCount = scope.getQuickCount = function() {
        console.log('getQuickCount');
        if (!scope.currentListState || !scope.currentListState.Segments || !scope.currentListState.RecipeId) {
          return;
        }

        scope.lastQuickCountAt = new Date();

        scope.quickCountReady = true;
        scope.showQuickCount = true;
        var listCalculating = calculationSvc.calculate(scope.currentListState)
          .then(function(data) {
            var lastKnownCounts = [];
            angular.copy(data.segments,lastKnownCounts);
            scope.quickCounts.length = 0; // Empty the array
            scope.quickCounts = data.segments;
            scope.$broadcast('quick count refreshed', scope.quickCounts);
            if(scope.quickCountDirty)
            {
              if(hasCountUpdated){
                if(listStateSvc.hasDistribution()){
                  console.log('resetting Distribution');
                  scope.currentListState.Distribution = undefined;
                  updateListState();
                  scope.currentListState.CurrentUIState.isComplete = false;
                  alertSvc.add({ Type: 'Error', Title: 'Revise Targeting.', Source: 'TargetingChange', Message: '' });
                }
                else
                {
                  updateListState();
                  if(scope.stepName.toUpperCase() ==='SUMMARY')
                  {
                    rootScope.$broadcast('stepscompleted');
                  }
                }
              }
              else
              {
                if(listStateSvc.hasDistribution()){
                  scope.resetDistributeCounts(lastKnownCounts);
                  setCalcDirtyFlags(false);
                  if(!scope.currentListState.Distribution){
                    scope.currentListState.CurrentUIState.isComplete = false;
                  }
                }
                else{
                  updateListState();
                }
              }
            }
            else if(!hasCountUpdated)
            {
              setCalcDirtyFlags(false);
            }
            app.publish('calculation', data);
          }).
          catch(function (err) {
            console.log('calculation err', err);
            scope.quickCountError = 'Error in calculation of counts';
          });
        scope.quickCountLoading.push(listCalculating);

        var updateListState = function(){
          setCalcDirtyFlags(false);
          scope.currentListState.CurrentUIState.countUpdateStatus='Updated';
          if(hasCountUpdated)
          {
            hasCountUpdated = false;
            alertSvc.removeAll();
          }
        };
      };

      scope.quickCountReady = false;

      //Get the list before you process the rest of the page.
      if (app.routeParams[0]) {
        scope.loading = listSvc.getList(app.routeParams[0])
          .then(function(data) {
            if (!data) {
              throw new Error('List data unavailable.');
            }
            listStateSvc.set(data);
            return data;
          });
      } else {
        scope.loading = listStateSvc.createList()
          .then(function(data) {
            listStateSvc.set(data);
            return data;
          });
      }

      scope.loading = scope.loading.then(processPage);

      function selectQuickCount(selectedSegment) {
        if (_.isEmpty(scope.quickCounts)) {
          return;
        }

        if (!selectedSegment) {
          _.first(scope.quickCounts).selected = true;
          _.forEach(_.rest(scope.quickCounts), function(quickCount) {
            quickCount.selected = false;
          });

          return;
        }

        var quickCountExists = false;

        _.forEach(scope.quickCounts, function(quickCount) {
          quickCount.selected = quickCount.segmentName === selectedSegment.Name;
          quickCountExists = (quickCount.selected) ? true : quickCountExists;
        });

        if (quickCountExists === false) {
          _.first(scope.quickCounts).selected = true;
          return;
        }
      }
      scope.addListRefIdsToSelection = function (obj, item) {
        if (item.length > 0) {
          angular.forEach(item, function (data) {
            if (data.ListRefId && obj.indexOf(data.ListRefId) === -1) {
              obj.push(data.ListRefId);
            }
          });
        }
      };
    }
  ]);
})(window.app);
