(function (app) {
	'use strict';

	app.directive('equalizer', function () {

		return function (scope) {
			var col1 = $('.lb-body-content'),
					col2 = $('.lb-body-left-nav'),
					col1Inner = $('.lb-body-content .ui-view-container'),
					col2Inner = $('.lb-body-left-nav .inner');

			scope.monitorHeight = function () {
				return {
					'col1Height': col1Inner.outerHeight(true),
					'col2Height': col2Inner.outerHeight(true)
				};
			};

			scope.changeHeight = function () {

				col1.css('min-height', 0);
				col2.css('min-height', 0);

				var biggestHeight = (col1.outerHeight(true) > col2.outerHeight(true)) ? col1.outerHeight(true) : col2.outerHeight(true);

				if (col1.outerHeight(true) > col2.outerHeight(true)) {
					col1.css('min-height', 0);
					col2.css('min-height', biggestHeight+'px');
				} else {
					col1.css('min-height', biggestHeight+'px');
					col2.css('min-height', 0);
				}

			};

			scope.$watch(scope.monitorHeight, function () {
				scope.changeHeight();
			}, true);

		};
	});
})(window.app);
