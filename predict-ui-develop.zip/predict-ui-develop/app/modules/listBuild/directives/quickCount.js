(function (app) {
	'use strict';

	app.directive('quickcount', function () {
		return {
			restrict: 'E',
			replace: true,
			scope: {
				quickCount: '=data',
				title: '@'
			},
			templateUrl: '/modules/listBuild/Views/quickCount.html'
		};
	});
})(window.app);
