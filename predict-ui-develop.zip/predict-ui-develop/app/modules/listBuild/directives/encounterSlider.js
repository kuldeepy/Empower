﻿(function (app) {
	'use strict';

	app.directive('encounterslider', function () {

		return {
			restrict: 'E',
			scope: {
				config: '=config',
				rangeValue: '=model'
			},
			link: function (scope, elem) {
				$(elem).slider({
					from: scope.config.sliderStartingPoint,
					to: scope.config.sliderEndPoint,
					step: scope.config.sliderStep,
					smooth: scope.config.sliderSmooth,
					round: scope.config.sliderRound,
					scale: scope.config.sliderScale,
					dimension: scope.config.sliderDimension,
					onstatechange: function (value) {
						scope.rangeValue = value;
					}
				});
				$(elem).slider('value', scope.config.sliderdefaultStartingPoint, scope.config.sliderdefaultEndPoint);
			}
		};
	});

})(window.app);