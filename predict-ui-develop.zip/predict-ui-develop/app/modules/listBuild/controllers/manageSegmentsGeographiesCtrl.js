(function (app) {
	'use strict';

	app.controller('manageSegmentsGeographiesCtrl', [ '$scope', 'listStateSvc', '_', 'targetAreasColumn', 'geographyHelper',
	function (scope, listStateSvc, _, targetAreasColumn, geographyHelper) {
		var listState = listStateSvc.get();
		
		scope.segment = listState.CurrentUIState.selectedSegment =
			listState.CurrentUIState.selectedSegment || _.first(listState.Segments);
		
		if (!scope.segment) {
			throw new Error('selectedSegment is a prerequisite for manage segment geographies step');
		}

		var hasSelectedGeographies = function () {
			return scope.segment.LocationDescriptorIndices.length > 0;
		};

		if (scope.initializeStep) {
			scope.initializeStep('manageSegmentsGeographies', hasSelectedGeographies());
		}

		scope.locations = geographyHelper.mapLocationDescriptorsForGrid(listState.LocationDescriptors);

		scope.selectedLocations = _.map(scope.segment.LocationDescriptorIndices, function (locationDescriptorIndex) {
			return scope.locations[locationDescriptorIndex];
		});

		scope.gridOptions = {
			data: 'locations',
			//showSelectionCheckbox: true,
			//checkboxCellTemplate: '<div class="ngSelectionCell"><input tabindex="-1" type="checkbox" ng-checked="row.selected" ng-disabled="checkMandatory(row.entity.IsMandatory,row.selected)"  style="margin:0px"  /></div>',
			selectedItems: scope.selectedLocations,
			headerRowHeight: 30,
			rowHeight: 45,
			columnDefs: [
				{
          field: '',
          width: 30,
          cellTemplate: '<div class="ngCellText ngSelectionCell" ng-class="col.colIndex()"><span class="pretty-chkbx"></span></div>'
        },
				{
					minWidth: 100,
					field: 'Name',
					displayName: 'Location'
				},
				targetAreasColumn
			],
			afterSelectionChange: function () {
				scope.segment.LocationDescriptorIndices = _.map(scope.selectedLocations, function (selectedLocation) {
					return  _.findIndex(scope.locations, selectedLocation);
				});
				scope.completeStep(hasSelectedGeographies());
			}
		};
	}]);

})(window.app);
