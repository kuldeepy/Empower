(function (app) {
    'use strict';
    //directive for showing 'Nothing to display' message when ng grid has no records to display.
    //In ng grid div, add check-empty-grid="nameOfBindingModel" attribute to use this directive.
    //Also add message which has to be displayed in grid (msg="Record not found")
    app.directive('checkEmptyGrid', function ($compile, $timeout) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var msg = attrs.msg;
                var template = '<div class="no-record-found-div" ng-if="' + attrs.checkEmptyGrid + '.length==0">' + msg + '</div>';
                var tmpl = angular.element(template);
                $compile(tmpl)(scope);
                $timeout(function () {
                    element.find('.ngViewport').append(tmpl);
                  }, 200);
              }
          };
      });

  })(window.app);