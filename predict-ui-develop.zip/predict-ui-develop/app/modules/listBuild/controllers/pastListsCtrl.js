(function (app) {
  'use strict';

  app.controller('pastListsCtrl', ['$scope', 'pastListSvc', 'listStateSvc', 'sessionSvc', 'lookupSvc',
  function (scope, pastListSvc, listStateSvc, sessionSvc, lookupSvc) {
    var pastListInclusions = 'pastLists.included';

    if (scope.initializeStep) {
      scope.initializeStep('pastLists', true);
    }

    scope.pastListsLoading = [];
    var listState = listStateSvc.get();

    if (listState.ExcludedPastListIds === undefined) {
      listState.ExcludedPastListIds = [];
    }
    if (listState.IncludedPastListIds === undefined) {
      listState.IncludedPastListIds = [];
    }
    scope.pastListsFilterResult = [];

    scope.controllerData = {
      gridData: [],
      gridColumn: [
        {
          field: 'campaignId',
          displayName: 'Campaign ID'
        },
        {
          field: 'Name',
          displayName: 'List Name'
        },
        {
          field: 'DatePulled',
          displayName: 'Start Date'
        },
        {
          field: 'actionValue',
          displayName: ''
        }
      ],
      filterText: '',
      emptyDataMessage: 'Sorry, no Past Lists were found.'
    };

    console.log('past lists: loading');
    scope.pastListsLoading.push(lookupSvc.getLookupDataById('marketing-channel').then(function (data) {
      var marketingOption = _.find(data, { Id: listState.MarketingChannelId });
      var shouldApplyExclusionPeriod = function () {
        return marketingOption.Name === 'Direct Mail';
      };
      pastListSvc.pastListData(shouldApplyExclusionPeriod()).then(function (pastLists) {
        scope.pastLists = pastLists;
        scope.pastListsFilterResult = scope.pastLists;
        scope.getCampaignID = function (row) {
          if (row.ListRefId) {
            var listRefId = row.ListRefId.split('_');
            return listRefId.length === 2 ? parseInt(listRefId[0]) : row.ListId;
          }
          else {
            return row.ListId;
          }
        };
        _.each(scope.pastListsFilterResult, function (val) {
          angular.extend(val, {
            campaignId: scope.getCampaignID(val)
          });
        });
        scope.controllerData.gridData = scope.pastListsFilterResult;

        console.log('past lists: loaded');
        if (listState.ExcludedPastListIds.length === 0 && listState.IncludedPastListIds.length === 0) {
          listState.InExclusionPastListIds = [];
          _.each(scope.pastLists, function (pastList) {
            if (pastList.InExclusionPeriod) {
              listState.ExcludedPastListIds.push(pastList.ListId);
              if (pastList.ListRefId && listState.ExcludedPastListIds.indexOf(pastList.ListRefId) === -1) {
                listState.ExcludedPastListIds.push(pastList.ListRefId);
              }
              listState.InExclusionPastListIds.push(pastList.ListId);
              pastList.actionValue = 'Exclude';
            }
            else {
              pastList.actionValue = 'Default';
            }
          });
        }
        else {
          _.each(scope.pastLists, function (pastList) {
            if (_.contains(listState.ExcludedPastListIds, pastList.ListId)) {
              if (pastList.InExclusionPeriod) {
                listState.InExclusionPastListIds.push(pastList.ListId);
                pastList.actionValue = 'Exclude';
              }
              else {
                if (_.contains(listState.InExclusionPastListIds, pastList.ListId)) {
                  _.remove(listState.ExcludedPastListIds, function (item) {
                    return item === pastList.ListId;
                  });
                  _.remove(listState.InExclusionPastListIds, function (item) {
                    return item === pastList.ListId;
                  });
                  pastList.actionValue = 'Default';
                }
                else {
                  pastList.actionValue = 'Exclude';
                }
              }
            }
            else if (_.contains(listState.IncludedPastListIds, pastList.ListId)) {
              if (pastList.InExclusionPeriod) {
                _.remove(listState.IncludedPastListIds, function (item) {
                  return item === pastList.ListId;
                });
                listState.ExcludedPastListIds.push(pastList.ListId);
                if (pastList.ListRefId && listState.ExcludedPastListIds.indexOf(pastList.ListRefId) === -1){
                  listState.ExcludedPastListIds.push(pastList.ListRefId);
                }
                listState.InExclusionPastListIds.push(pastList.ListId);
                pastList.actionValue = 'Exclude';
              }
              else {
                if (_.contains(listState.InExclusionPastListIds, pastList.ListId)) {
                  _.remove(listState.InExclusionPastListIds, function (item) {
                    return item === pastList.ListId;
                  });
                  pastList.actionValue = 'Default';
                }
                else {
                  pastList.actionValue = 'Include';
                }
              }
            }
            else {
              if (pastList.InExclusionPeriod) {
                listState.ExcludedPastListIds.push(pastList.ListId);
                if (pastList.ListRefId && listState.ExcludedPastListIds.indexOf(pastList.ListRefId) === -1){
                  listState.ExcludedPastListIds.push(pastList.ListRefId);
                }
                listState.InExclusionPastListIds.push(pastList.ListId);
                pastList.actionValue = 'Exclude';
              }
              else {
                if (_.contains(listState.InExclusionPastListIds, pastList.ListId)) {
                  _.remove(listState.InExclusionPastListIds, function (item) {
                    return item === pastList.ListId;
                  });
                }
                pastList.actionValue = 'Default';
              }
            }
          });
        }
      });
    }));

    scope.$watch('controllerData.filterText', function (searchText, oldSearchText) {
      if (searchText !== oldSearchText) {
        scope.controllerData.gridData = _.filter(scope.pastLists, function (pastList) {
          return scope.getCampaignID(pastList).toLowerCase().indexOf(searchText.toLowerCase()) !== -1 || pastList.Name.toLowerCase().indexOf(searchText.toLowerCase()) !== -1;
        });
      }
    });

    scope.updateList = function (selectedValue) {

      console.log('Selected Value: ', selectedValue);
      var excludedItem = _.filter(scope.pastLists, function (pastList) { return pastList.actionValue === 'Exclude'; });
      var includedItems = _.filter(scope.pastLists, function (pastList) { return pastList.actionValue === 'Include'; });
      listState.ExcludedPastListIds = _.pluck(excludedItem, 'ListId');
      scope.addListRefIdsToSelection(listState.ExcludedPastListIds, excludedItem);
      listState.IncludedPastListIds = _.pluck(includedItems, 'ListId');

      scope.addListRefIdsToSelection(listState.IncludedPastListIds, includedItems);
      //Adding Included past lists to Session
      //which will be used to bind List Inclusion Grid
      if (includedItems.length > 0) {
        sessionSvc.set(pastListInclusions, JSON.stringify(includedItems));
      }
      else {
        sessionSvc.clear(pastListInclusions);
      }
    };

    scope.statuses = {
      'Default': '',
      'Include': 'Include',
      'Exclude': 'Exclude'
    };

  }]);
})(window.app);
