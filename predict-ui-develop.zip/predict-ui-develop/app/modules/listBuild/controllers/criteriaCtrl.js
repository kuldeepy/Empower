(function (app) {
  'use strict';

  app.controller('criteriaCtrl', ['$scope', 'listStateSvc', 'filterTypeSvc', 'providerSvc',
  'recipeSvc', '$filter',
  function ($scope, listStateSvc, filterTypeSvc, providerSvc, recipeSvc, filter) {
    if ($scope.initializeStep) {
      $scope.initializeStep('criteria', true);
    }

    $scope.locations = listStateSvc.get().LocationDescriptors;

    var listState = listStateSvc.get();

    $scope.listFilterValueSelections = listState.FilterValueSelections;

    $scope.recipeFilterValueSelections = recipeSvc.getRecipe(listState.RecipeId)
    .then(function (recipe) {
      return recipe.Filters;
    });

    $scope.criteria = filterTypeSvc.loadFilterTypeData('filters').then(function (data) {
      data = JSON.parse(data);
      data = $scope.setDefaultOrderForFilterTypes(data);
      return data;
    });

    $scope.providerSpecialties = providerSvc.getAllProviderSpecialties().then(function (psData) {
      return $scope.applyCustomSort(psData, 'Name');
    });

    var customSortFilters = [
      { name: 'MaritalStatus', field: 'Name' },
      { name: 'Gender', field: 'Name' },
      { name: 'AgeOfChildren', field: '_id' },
      { name: 'AgeRange', field: '_id' },
      { name: 'Occupation', field: 'Name' },
      { name: 'Race', field: 'Name' },
      { name: 'PrimaryLanguage', field: 'Name' },
      { name: 'PayerType', field: 'Name' },
      { name: 'BeehiveCluster', field: 'Name' },
      { name: 'HomeOwnership', field: 'Name' },
      { name: 'EducationLevel', field: 'Name' },
      { name: 'DwellingType', field: 'Name' },
      { name: 'HouseholdIncomeGroup', field: '_id' },
      { name: 'WealthLevel', field: 'WealthLevelMinVal' },
      { name: 'FinancialClass', field: 'Name' },
      { name: 'EncounterSourceType', field: 'Name' }
    ];

    var standardSortFilters = [
      { name: 'HomeValue', field: '_id' },
      { name: 'PhysicianType', field: 'Name' },
      { name: 'PatientType', field: 'Name' },
    ];

    $scope.setDefaultOrderForFilterTypes = function (data) {

      _.forEach(customSortFilters, function (customSortFilter) {
        if (data[customSortFilter.name]) {
          data[customSortFilter.name] = $scope.applyCustomSort(data[customSortFilter.name], customSortFilter.field);
        }
      });

      _.forEach(standardSortFilters, function (standardSortFilter) {
        if (data[standardSortFilter.name]) {
          data[standardSortFilter.name] = filter('orderBy')(data[standardSortFilter.name], standardSortFilter.field, false);
        }
      });

      //Custom Order for Person Types
      var personTypesTemp = [];
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Patients' }));
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Family Member of Patients' }));
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Qualified Prospects' }));
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Prospects' }));
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'New Movers' }));
      data.PersonType = personTypesTemp;

      return data;
    };

    $scope.applyCustomSort = function (data, sortColumn) {
      var result = _.groupBy(data, function (currentObject) {
        return currentObject.Name.toUpperCase() !== 'UNKNOWN';
      });

      return _.flatten([_.sortBy(result.true, sortColumn), result.false ? result.false : []]);
    };

  }]);
})(window.app);
