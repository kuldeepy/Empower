(function (app) {
	'use strict';

	app.directive('carouselTabs', [ '_', '$window', function (_,$window) {

		var TABS_TO_SHOW = 4;

		return {
			restrict: 'E',
			scope: {
				tabs: '=tabs',
				tabIndex: '=tabIndex'
			},
			link: function (scope) {

				var position = 0;

				var canScrollRight = function () {
					return position + TABS_TO_SHOW < scope.tabs.length;
				};

				var canScrollLeft = function () {
					return position > 0;
				};

				var scrollRight = function () {
					scope.scrolling = true;

					if (canScrollRight()) {
						position += 1;
					}

					adjustTabsToPosition();
				};

				var scrollLeft = function () {
					scope.scrolling = true;

					if (canScrollLeft()) {
						position -= 1;
					}

					adjustTabsToPosition();
				};

				var adjustTabsToPosition = function () {
					angular.forEach(scope.tabs, function (tab, index) {
						var number = index + 1;
						tab.visible = position < number  && number <= position + TABS_TO_SHOW;
					});

					var visibleTabWidthPercentage = 100/TABS_TO_SHOW;
					var margin = position*visibleTabWidthPercentage;
					$('.tabs-holder').css('margin-left','-'+margin+'%');
					
				};

				scope.$watch('tabIndex', function () {
					position = (scope.tabIndex > scope.tabs.length-TABS_TO_SHOW) ? scope.tabs.length-TABS_TO_SHOW : scope.tabIndex;
				}, true);
				
				scope.$watch('tabs', function () {
					if (!scope.scrolling) {
						var selectedTabIndex = _.findIndex(scope.tabs, function (tab) {
							return tab.selected;
						});

						if (selectedTabIndex !== -1 && selectedTabIndex === position + TABS_TO_SHOW - 1 && canScrollRight()) {
							position += 1;
						} else if (selectedTabIndex !== -1 && selectedTabIndex === position && canScrollLeft()) {
							position -= 1;
						}
					} else {
						scope.scrolling = false;
					}

					var visibleTabWidth = $('.lb-top-cell-wrap').width()/TABS_TO_SHOW;
					var tabHolderWidth = scope.tabs.length*visibleTabWidth;
					$('.tabs-holder').css('width',tabHolderWidth+'px');

					var visibleTabWidthPercentage = 100/scope.tabs.length;
					$('.tabs-holder .lb-top-cell').css('width',visibleTabWidthPercentage+'%');
					adjustTabsToPosition();

					scope.leftArrowInactive = position === 0;
					scope.rightArrowInactive = position + TABS_TO_SHOW >= scope.tabs.length;

				}, true);

				var win = angular.element($window);
				win.bind('resize',function(){
					var visibleTabWidth = $('.lb-top-cell-wrap').width()/TABS_TO_SHOW;
					var tabHolderWidth = scope.tabs.length*visibleTabWidth;
					$('.tabs-holder').css('width',tabHolderWidth+'px');

				});
        

				scope.scrollRight = scrollRight;
				scope.scrollLeft = scrollLeft;
			},
			templateUrl: '/modules/listBuild/Views/carouselTabs.html',
		};
	} ]);

})(window.app);