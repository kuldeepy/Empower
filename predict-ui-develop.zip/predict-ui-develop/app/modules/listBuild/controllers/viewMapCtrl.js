(function (app) {
	'use strict';
	app.controller('viewMapCtrl', ['$rootScope', '$scope', 'listStateSvc',
		function (rootScope, scope, listStateSvc) {
			if (scope.initializeStep) {
				scope.initializeStep('viewMap', true);
			}

			scope.$emit('update quick count');

			if (rootScope.ShowCloseMapButton === true) {
				scope.canShowCloseMapButton = true;
				rootScope.ShowCloseMapButton = false;
			}
			else {
				scope.canShowCloseMapButton = false;
			}

			var listState = listStateSvc.get();

			var currentLocationIndex = listState.CurrentUIState.CurrentLocationIndex;
			scope.locationDescriptors = [];

			scope.locationDescriptors.push(listStateSvc.get().LocationDescriptors[currentLocationIndex]);

			scope.onCloseMapClick = function () {
				rootScope.$state.go('manageSegmentsFilters');
			};
			
			scope.$on('previous', function (event, go) {
				if (listStateSvc.get().LocationDescriptors[currentLocationIndex].Type === 'ServiceArea') {
					go('serviceArea');
				}
			});
		}
	]);
})(window.app);