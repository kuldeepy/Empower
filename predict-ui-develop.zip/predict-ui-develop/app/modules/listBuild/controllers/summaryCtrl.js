﻿(function (app) {
  'use strict';
  app.controller('summaryCtrl', ['$scope', '$location', 'userContextSvc', 'listStateSvc',
    function (scope, location, userContextSvc, listStateSvc) {
      scope.loading.then(function () {
        if (scope.initializeStep) {
          scope.initializeStep('summary', true);
        }
        var list = listStateSvc.get();
        if (list.PullDate)
        {
          var listSummaryPath = '/' + scope.clientKey + '/' + userContextSvc.getOrgKey() + '/lists/listsummary';
          location.path(listSummaryPath);
        }
      });
    }
  ]);
})(window.app);