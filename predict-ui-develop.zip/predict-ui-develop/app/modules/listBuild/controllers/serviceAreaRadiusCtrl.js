(function(app) {
	'use strict';

	app.controller('serviceAreaRadiusCtrl', ['$scope', 'listStateSvc',
		function(scope, listStateSvc) {
			//Constant strings
			var serviceArea = 'Service Area';
			var radius = 'Radius';
			
			if (scope.initializeStep) {
				scope.initializeStep('serviceAreaRadius', true);
			}
			
			scope.scopeOptions = [
				{ 'text': serviceArea, 'value': 'ServiceArea' },
				{ 'text': radius, 'value': 'Radius' },
			];
						
			scope.locationDescriptor = listStateSvc.get().LocationDescriptors[listStateSvc.get().CurrentUIState.CurrentLocationIndex];

			scope.$on('next', function (event, go) {
				if (scope.locationDescriptor.Type === 'Radius') {
					go('radius');
				}
			});
		}
	]);
})(window.app);