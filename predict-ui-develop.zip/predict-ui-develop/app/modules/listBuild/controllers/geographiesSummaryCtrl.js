(function (app) {
  'use strict';

  app.controller('geographiesSummaryCtrl', ['$scope', '$state', 'listStateSvc', 'workflow', 'targetAreasColumn', 'geographyHelper', 'sessionSvc', 'facilitySvc', '_',
  function (scope, state, listStateSvc, workflow, targetAreasColumn, geographyHelper, sessionSvc, facilitySvc, _) {
    if (scope.initializeStep) {
      scope.initializeStep('geographiesSummary', true);
    }
    scope.isMapVisible = false;
    scope.isGridVisible = true;
    scope.canShowCloseMapButton = true;
    scope.locations = [];

    scope.getFacilities = function (locationDescriptors) {
      var locationIds = [];
      //Add check to see if facilities already fetched and if not then only call 
      var facilities = JSON.parse(sessionSvc.get('selectedLocation.facilities'));
      var ids = _.pluck(locationDescriptors, 'LocationId');
      _.forEach(ids, function (id) {
        if (_.findIndex(facilities.Facilities, { 'LocationId': id }) < 0) {
          if (!angular.isUndefined(id)) {
            locationIds.push(id);
          }
        }
      });

      if (locationIds.length > 0) {
        ids = _.uniq(ids);
        scope.loadingFacilities = facilitySvc.getFacilities({ //fetching locations with facitity data
          'locationids': ids.join(',')
        }).then(function (facilityData) {
          sessionSvc.set('selectedLocation.facilities', JSON.stringify(facilityData));
          locationDescriptors = geographyHelper.mapLocationDescriptorsForGrid(listStateSvc.get().LocationDescriptors);
          scope.locations = locationDescriptors;
        });
      }
      else {
        locationDescriptors = geographyHelper.mapLocationDescriptorsForGrid(listStateSvc.get().LocationDescriptors);
        scope.locations = locationDescriptors;
      }
    };

    if (listStateSvc.get().LocationDescriptors) {
      var locationDescriptors = listStateSvc.get().LocationDescriptors;
      scope.getFacilities(locationDescriptors);
    }



    scope.editLocation = function (location) {
      var facilityPromise = facilitySvc.getFacilities({
        'locationids': location.LocationId
      });
      scope.geographiesLoading = facilityPromise.then(function (facilityData) {
        sessionSvc.set('selectedLocation.facilities', JSON.stringify(facilityData));
        listStateSvc.get().CurrentUIState.CurrentLocationIndex = _.indexOf(scope.locations, location);
        workflow.go('selectLocation');
      });
    };

    scope.removeLocation = function (location) {
      var indexToRemove = _.indexOf(scope.locations, location);
      synchronizeSegments(indexToRemove);

      scope.locations.splice(indexToRemove, 1);
      if (listStateSvc.get().CurrentUIState.CurrentLocationIndex && listStateSvc.get().CurrentUIState.CurrentLocationIndex > 0) {
        listStateSvc.get().CurrentUIState.CurrentLocationIndex = (listStateSvc.get().CurrentUIState.CurrentLocationIndex - 1);
      }
    };

    var synchronizeSegments = function (indexToRemove) {
      var segments = listStateSvc.get().Segments;
      if (segments) {
        segments.forEach(function (seg) {
          if (seg.LocationDescriptorIndices) {
            // remove the locationDescriptor index being removed
            _.remove(seg.LocationDescriptorIndices, function (i) {
              return i === indexToRemove;
            });
            // lower the value of any entries pointing to higher indexes so they stay in sync.
            for (var i = 0; i < seg.LocationDescriptorIndices.length; i += 1) {
              var indexValue = seg.LocationDescriptorIndices[i];
              if (indexValue > indexToRemove) {
                seg.LocationDescriptorIndices[i] = indexValue - 1;
              }
            }
          }
        });
      }
    };

    scope.$on('previous', function (event, go) {
      var locationDescriptor = listStateSvc.get().LocationDescriptors[listStateSvc.get().CurrentUIState.CurrentLocationIndex];
      if (locationDescriptor.Type === 'ServiceArea') {
        go('serviceArea');
      }
    });

    scope.addNewLocation = function () {
      var locationDescriptors = listStateSvc.get().LocationDescriptors;
      listStateSvc.get().CurrentUIState.CurrentLocationIndex = locationDescriptors.length;
      locationDescriptors.push({
        'Type': 'ServiceArea',
        'UsePrimaryServiceArea': true,
        'UseSecondaryServiceArea': true,
        'UseTertiaryServiceArea': true
      });

      workflow.go('selectLocation');
    };

    scope.gridOptions = {
      data: 'locations',
      rowHeight: 45,
      multiSelect: false,
      /* jshint ignore:start */
      plugins: [new ngGridFlexibleHeightPlugin()],
      /* jshint ignore:end */
      columnDefs: [
        {
          field: 'Name',
          displayName: 'Location'
        },
        targetAreasColumn,
        {
          field: 'Actions',
          width: 90,
          cellTemplate: '<div class="ngCellText geographic-text-wrap" style="padding-top: 3px;"><a ng-click="editLocation(row.entity)" class="yellow">' +
          '<span class="round-icon" popover-placement="top yellow" popover-append-to-body="true" popover-trigger="mouseenter" popover="Edit Location">' +
          '<span class="border"></span><img src="/images/icons/icon_edit.png" class="icon" alt="Edit" /></span></a>' +
          '<a ng-show="locations.length>1" ng-click="removeLocation(row.entity)" class="red">' +
          '<span class="round-icon" popover-placement="top red" popover-append-to-body="true" popover-trigger="mouseenter" popover="Remove Location">' +
          '<span class="border"></span><img src="/images/icons/icon_trash.png" class="icon" alt="Remove" /></span></a></div>'
        }
      ]
    };

    scope.$watchCollection('locations', function (locations) {
      scope.completeStep(locations.length > 0);
    });
  }
  ]);
})(window.app);