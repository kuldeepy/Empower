(function (app) {
  'use strict';

  app.controller('manageSegmentsListInclusionsCrtl', ['$scope', '$q', 'listStateSvc', '_', 'sessionSvc', 'calculationSvc',
  function (scope, $q, listStateSvc, _, sessionSvc, calculationSvc) {

    var listState = listStateSvc.get();
    scope.includedPastLists = [];
    scope.loading = [];

    var pastListInclusions = 'pastLists.included';

    scope.segment = listState.CurrentUIState.selectedSegment =
    listState.CurrentUIState.selectedSegment || _.first(listState.Segments);

    if (!scope.segment) {
      throw new Error('selectedSegment is a prerequisite for manage segment geographies step');
    }

    if (scope.initializeStep) {
      scope.initializeStep('manageSegmentsListInclusions', true);
    }

    scope.calculatePastListCount = function (listId) {
      return listStateSvc.createList().then(function (newList) {
        //Adding Lists ID as part of IncludedPastListIds for new list
        newList.IncludedPastListIds.push(listId);

        //Adding LocationDescriptors as part of new List
        _.each(listState.LocationDescriptors, function (geography, index) {
          if (scope.segment.LocationDescriptorIndices && _.contains(scope.segment.LocationDescriptorIndices, index)) {
            newList.LocationDescriptors.push(geography);
          }
        });

        var loadingPromise = calculationSvc.calculate(newList)
        .then(function (data) {
          var foundSegment = _.find(data.segments, { 'segmentName': 'Available Count' });
          if (foundSegment) {
            _.each(scope.pastLists, function (pastList) {
              if (pastList.ListId === newList.IncludedPastListIds[0]) {
                //Assigning Individual total for past list tageted count
                pastList.targetedCount = foundSegment.totalCountForIndividual;
              }
            });
          }
        })
        .catch(function (err) {
          console.log('calculation err', err);
          scope.calculationError = 'Error in calculation of counts';
        });
        scope.loading.push(loadingPromise);
      });
    };

    scope.getIncludedPastLists = function () {
      try {
        var sessionPastLists = sessionSvc.get(pastListInclusions);
        if (sessionPastLists) {
          scope.includedPastLists = JSON.parse(sessionPastLists);
          _.each(scope.includedPastLists, function (list) {
            //extending a property to have tageted counts
            _.extend(list, {
              'targetedCount': 0
            });
            //Making checkbox checked based on the saved value
            list.actionValue = true;
            if ((listState.Name && !_.contains(scope.segment.IncludedPastListIds, list.ListId)) || _.contains(scope.segment.ExcludedPastListIds, list.ListId)) {
              list.actionValue = false;
            }
            //Call calculation service to get targeted count 
            scope.loading.push(scope.calculatePastListCount(list.ListId));
          });
          scope.pastLists = scope.includedPastLists;
        }
      } catch (err) {
        scope.pastLists = undefined;
      }
    };
    scope.getIncludedPastLists();

    scope.individualTotalCount = function (entity) {
      return _.result(_.find(scope.pastLists, { 'ListId': entity.ListId }), 'targetedCount');
    };

    scope.rowChangeEvent = function () {
      var includedItems = _.filter(scope.pastLists, function (pastList) { return pastList.actionValue === true; });
      scope.segment.IncludedPastListIds = _.pluck(includedItems, 'ListId');
      scope.addListRefIdsToSelection(scope.segment.IncludedPastListIds, includedItems);
      var excludedItems = _.filter(scope.pastLists, function (pastList) { return pastList.actionValue === false; });
      scope.segment.ExcludedPastListIds = _.pluck(excludedItems, 'ListId');
      scope.addListRefIdsToSelection(scope.segment.ExcludedPastListIds, excludedItems);
    };

    scope.$on('ngGridEventData', function () {
      angular.forEach(scope.pastLists, function (data, index) {
        scope.gridOptions.selectRow(index, data.actionValue);
      });
    });

    scope.gridOptions = {
      data: 'pastLists',
      rowHeight: 45,
      enableRowSelection: true,
      multiSelect: true,
      selectedItems: [],
      rowTemplate: '<div ng-style="{ \'cursor\': row.cursor }" ng-repeat="col in renderedColumns" ng-class="col.colIndex()" class="ngCell {{col.cellClass}}"><div class="ngVerticalBar" ng-style="{height: rowHeight}" ng-class="{ ngVerticalBarVisible: !$last }">&nbsp;</div><div ng-cell></div></div>',
      filterOptions: {
        filterText: '',
      },
      /* jshint ignore:start */
      plugins: [new ngGridFlexibleHeightPlugin()],
      /* jshint ignore:end */
      columnDefs: [
        {
          field: 'actionValue',
          displayName: '',
          width: 50,
          cellTemplate: '<div class="ngCellText ngSelectionCell" ng-class="col.colIndex()"><span class="pretty-chkbx" ng-input="COL_FIELD" ng-model="COL_FIELD"></span></div>',
          headerClass: 'text-center',
          sortable: false,
          cellClass: 'text-center'
        },
        {
          field: 'Name',
          displayName: 'List Name'
        },
        {
          displayName: 'Count',
          cellTemplate: '<div class="ngCellText text-center" cg-busy="loading"><span ng-bind="individualTotalCount(row.entity) | number"></span></div>',
          enableCellEdit: false
        }
      ],
      beforeSelectionChange: function (row) {
        row.entity.actionValue = !row.entity.actionValue;
        return true;
      },
      afterSelectionChange: function () {
        scope.rowChangeEvent();
      }
    };
  }]);

})(window.app);
