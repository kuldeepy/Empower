(function (app) {
  'use strict';

  app.filter('markifbaselocation', function () {
    return function (locationName, isBaseLocation) {
      return (isBaseLocation) ? locationName + ' (Base Location)' : locationName;
    };
  });

  app.controller('radiusCtrl', ['$scope', 'locationSvc', 'geographyHelper', 'listStateSvc', 'sessionSvc', 'geographiesLookupSvc', '_', '$filter', 'geocodeSvc', '$timeout',
  function (scope, locationSvc, geographyHelper, listStateSvc, sessionSvc, geographiesLookupSvc, _, $filter, geocodeSvc, $timeout) {
    if (scope.initializeStep) {
      scope.initializeStep('radius', false);
    }

    var locationsList = [];
    scope.radiusLoading = [];
    scope.radiusLabelIndicator = 'You can enter a Radius by clicking on the \'+\' or \'-\' buttons, or by inputting a number in the text field. The number must be between 1 and 50.';
    scope.applyToAllLabelIndicator = 'Clicking \"Apply to All\" will apply the radius miles to all of the defined radius locations';

    scope.isEnableApplyToAll = true;
    scope.locations = listStateSvc.get().LocationDescriptors;

    var location = scope.locations[listStateSvc.get().CurrentUIState.CurrentLocationIndex];

    if (scope.locations.length === 1) {
      scope.$emit('getQuickCount');
    }
    scope.enableNextButton = true;
    // The map needs to be refactored to look at Type before rendering the location.
    // Currently it displays Primary, Secondary, & Tertiary zips reguardless if the location type has been selected as a radius
    // This next line corrects that issue by deleting the SelectedZipCodes
    location.SelectedZipCodes = [];
    scope.isCustomAddress = false;

    var getBaseLocation = function (radius) {
      return _.findWhere(radius.AllLocations, function (loc) {
        return loc.Id === location.LocationId && loc.LocationId === undefined; //Check to see if Locationd is undefined, if so it is a base location, if not it is a facility
      });
    };

    scope.locationChange = function (radius, id) {
      radius.filterLocation = { FormattedAddress: '' };
      radius.geocodeAlertCss = 'hide';
      radius.SelectedLocationId = id;
      var newLocation = _.findWhere(radius.AllLocations, { Id: radius.SelectedLocationId });
      if (radius.SelectedLocationId === 'customAddress') {
        newLocation.Address = {
          Address1: '',
          Address2: '',
          City: '',
          State: '',
          Zip: '',
          GeoJson: {
            Coordinates: [],
            Type: ''
          }
        };
        radius.isRadiusInEditMode = true;
        radius.IsValidRadius = false;
      }
      var radiusBaseLocation = getBaseLocation(radius);
      radius.Name = newLocation.Name;
      radius.Address = newLocation.Address;
      radius.AdditionalZipCodeIds = [];
      radius.ExcludedZipCodeIds = [];
      if (radius.SelectedLocationId !== null && radius.SelectedLocationId !== 'customAddress') {
        radius.LocationAvailableZipCodes = radiusBaseLocation.AvailableZipCodes;
        radius.isRadiusInEditMode = false;
        radius.IsCustomAddress = false;
        scope.radiiForm.$valid = scope.isRadiusValid(radius.RadiusInMiles);
        radius.IsValidRadius = scope.radiiForm.$valid;
        radius.EnableCancelbutton = false;
        radius.geocodeButtonDisabled = false;
        radius.LocationId = radius.SelectedLocationId;
      } else {
        radius.AdditionalZipCodes = [];
        radius.AvailableZipCodeIds = [];
        radius.AvailableZipCodes = [];
        radius.ExcludedZipCodes = [];
        radius.RadiusZipCodeIds = [];
        radius.LocationAvailableZipCodes = [];
        radius.IsCustomAddress = true;
        radius.EditCustomAddressEnable = false;
        radius.EnableCancelbutton = false;
        scope.radiusLoading = [];
      }
      radius.zipCodesLoading = true;
      if (radius.SelectedLocationId !== 'customAddress') {
        getZipCodesInRadius(radius);
      }
    };

    scope.isBaseLocation = function (selectLocationId) {
      return selectLocationId === location.LocationId;
    };

    var getBaseLocationAndFacility = function () {
      var facilitiesAndLocationList;
      var rawFacilities = sessionSvc.get('selectedLocation.facilities');
      if (rawFacilities !== null) {
        var facilities = JSON.parse(rawFacilities);
        facilities.Facilities = _.where(facilities.Facilities, { 'LocationId': location.LocationId });
        facilitiesAndLocationList = facilities;
      }
      for (var i = 0; i < locationsList.length; i = i + 1) {
        if (locationsList[i].Id === location.LocationId) {
          facilitiesAndLocationList.Facilities.push(locationsList[i]);
        }
      }
      locationsList = facilitiesAndLocationList.Facilities;
      locationsList.push({
        Name: 'Custom Address',
        Id: 'customAddress',
        Address: {
          Address1: '',
          Address2: '',
          City: '',
          State: '',
          Zip: '',
          GeoJson: {
            Coordinates: [],
            Type: ''
          }
        }
      });
      for (i = 0; i < locationsList.length; i = i + 1) {
        angular.extend(locationsList[i], {
          FormattedAddress: locationsList[i].Name + ' ' + locationsList[i].Address.Address1 + ' ' + locationsList[i].Address.City + ' ' + locationsList[i].Address.State + ' ' + locationsList[i].Address.Zip
        });
      }
      locationsList = applyCustomSort(locationsList, 'Name');
      return locationsList;
    };

    scope.radiusMilesUpdated = function (radius) {
      radius.ApplyToAll = false;
      if (scope.isRadiusValid(radius.RadiusInMiles)) {
        getZipCodesInRadius(radius);
      }
    };

    scope.isRadiusValid = function (radiusInMiles) {
      if (radiusInMiles && radiusInMiles > 0 && radiusInMiles <= 50) {
        return true;
      }
      else {
        return false;
      }
    };

    scope.formatAddress = function (location) {
      if (location.Id !== 'customAddress') {
        return location.Address.Address1 + ', ' + location.Address.City + ', ' + location.Address.State + ' ' + location.Address.Zip;
      }
      else {
        return '';
      }
    };

    scope.radiusIncrement = function (radius, radiusChangeBy) {
      radius.RadiusInMiles = (radius.RadiusInMiles ? radius.RadiusInMiles : 0) + ((radiusChangeBy) ? radiusChangeBy : 1);
      scope.radiusMilesUpdated(radius);
    };

    scope.radiusDecrement = function (radius, radiusChangeBy) {
      radius.RadiusInMiles = (radius.RadiusInMiles ? radius.RadiusInMiles : 0) - ((radiusChangeBy) ? radiusChangeBy : 1);
      scope.radiusMilesUpdated(radius);
    };

    scope.applyRadiusInMilesToAll = function (selectedRadius) {
      if (selectedRadius.ApplyToAll) {
        _.forEach(listStateSvc.get().LocationDescriptors, function (locationToChangeRadius) {
          _.forEach(locationToChangeRadius.RadiusDescriptors, function (radiusDesc) {
            if (radiusDesc.RadiusInMiles !== selectedRadius.RadiusInMiles) {
              radiusDesc.RadiusInMiles = selectedRadius.RadiusInMiles;
              getZipCodesInRadius(radiusDesc);
            }
            radiusDesc.ApplyToAll = false;
          });
        });
        selectedRadius.ApplyToAll = true;
      }
    };

    scope.getLocationName = function (radius) {
      var radiusBaseLocation = _.findWhere(radius.AllLocations, function (loc) {
        return loc.Id === location.LocationId && loc.LocationId === undefined;
      });
      if (radius.SelectedLocationId !== 'customAddress') {
        return radius.Name;
      }
      return radiusBaseLocation.Name;
    };

    scope.addAnotherRadius = function () {

      var baseLocationLookup = _.findWhere(locationsList, { Id: location.LocationId });
      // Making an unrefereced copy of the baseLocationLookup object
      var baseLocation = JSON.parse(JSON.stringify(baseLocationLookup));
      scope.radii.push({
        'LocationId': baseLocation.Id,
        'Name': baseLocation.Name,
        'SelectedLocationId': baseLocation.Id,
        'Address': baseLocation.Address,
        'RadiusAddress': baseLocation.Address,
        'RadiusInMiles': 15,
        'AdditionalZipCodeIds': [],
        'ExcludedZipCodeIds': [],
        'RadiusZipCodeIds': [],
        'LocationAvailableZipCodes': baseLocation.AvailableZipCodes,
        'AllLocations': getBaseLocationAndFacility(),
        'IsValidRadius': true,
        'isRadiusInEditMode': false,
        'filterLocation': { 'FormattedAddress': '' },
        'ApplyToAll': false,
        'toggleExpandedPanel': false
      });
      var radiusIndex = scope.radii.length - 1;
      getZipCodesInRadius(scope.radii[radiusIndex]);
      scope.radiiLength = scope.radii.length;
      enableApplyToAll();
    };

    var prepRadiusDescriptors = function (radiusDescriptors) {
      _.each(radiusDescriptors, function (radius) {
        radius.AllLocations = getBaseLocationAndFacility();
        radius.RadiusInMiles = parseInt(radius.RadiusInMiles);
        var locationLookup = _.findWhere(radius.AllLocations, { Id: radius.LocationId });
        var radiusLocationLookup = _.findWhere(locationsList, { Id: location.LocationId });
        if (radius.IsCustomAddress) {
          radius.SelectedLocationId = 'customAddress';
          radius.Name = 'Custom Address';
        } else {
          radius.SelectedLocationId = locationLookup.Id;
          radius.Name = locationLookup.Name;
        }
        radius.Address = (radius.Address) ? radius.Address : locationLookup.Address;
        radius.RadiusAddress = radius.Address;
        radius.LocationAvailableZipCodes = radiusLocationLookup.AvailableZipCodes;
        radius.filterLocation = { FormattedAddress: '' };
        radius.toggleExpandedPanel = false;
        getZipCodesInRadius(radius);
        enableApplyToAll();
      });

      return radiusDescriptors;
    };

    var enableApplyToAll = function () {
      var totalRadius = 0;
      _.each(scope.locations, function (location) {
        _.each(location.RadiusDescriptors, function () {
          totalRadius = totalRadius + 1;
        });
      });
      scope.isEnableApplyToAll = totalRadius > 1 ? false : true;
      if (totalRadius === 1) {
        _.each(scope.locations, function (location) {
          _.each(location.RadiusDescriptors, function (radius) {
            radius.ApplyToAll = false;
          });
        });
      }
    };

    var getZipCodesInRadius = function (radius) {
      scope.completeStep(false);
      var zipRadLocationId = !scope.isBaseLocation(radius.LocationId) ? getBaseLocation(radius).Id : radius.LocationId;
      // We're going to eliminate some unecessary parts of the query string to shorten it
      if ((radius.RadiusInMiles && radius.RadiusInMiles > 0) && (radius.Address.GeoJson && radius.Address.GeoJson.Coordinates && radius.Address.GeoJson.Coordinates.length > 0)) {
        radius.zipCodesLoading = geographiesLookupSvc.getZipCodesByLocationRadius({
          'Id': zipRadLocationId,
          'RadiusDescriptor': {
            'LocationId': zipRadLocationId,
            'Address': radius.Address,
            'RadiusInMiles': radius.RadiusInMiles
          }
        }).then(function (radZipData) {
          radius.RadiusZipCodeIds = radius.AvailableZipCodeIds = radZipData;
          radius.IsValidRadius = true;
          scope.radiusLoading = radius.AvailableZipCodeIds;
          removeUsedZipCodes(radius);
          radiusValidator();
        });
      }
    };

    var removeUsedZipCodes = function (radius) {
      radius.AdditionalZipCodeIds = _.intersection(radius.AdditionalZipCodeIds, radius.RadiusZipCodeIds);
      radius.ExcludedZipCodeIds = _.intersection(radius.ExcludedZipCodeIds, radius.RadiusZipCodeIds);
      radius.AvailableZipCodeIds = _.difference(radius.AvailableZipCodeIds, radius.AdditionalZipCodeIds, radius.ExcludedZipCodeIds);
    };
    var getOtherLocations = function () {
      if (!scope.otherLocations) {
        try {
          scope.otherLocations = JSON.parse(sessionSvc.get('selectLocation.locations'));
          locationsList = _.map(scope.otherLocations, function (loc) { return loc; });
          filterSelectedLocations();
        } catch (err) {
          scope.otherLocations = undefined;
        }
      }
      if (!scope.otherLocations) {
        locationSvc.listLocations().then(function (data) {
          scope.otherLocations = data;
          locationsList = _.map(scope.otherLocations, function (loc) { return loc; });
          sessionSvc.set('selectLocation.locations', JSON.stringify(scope.otherLocations));
          filterSelectedLocations();
        });
      } else {
        filterSelectedLocations();
      }
    };

    var filterSelectedLocations = function () {
      var indexOfPreviouslySelectedLocation = -1;
      for (var i = 0; i < scope.otherLocations.length; i = i + 1) {
        if (scope.otherLocations[i].Id === location.LocationId) {
          indexOfPreviouslySelectedLocation = i;
        }
      }
      if (indexOfPreviouslySelectedLocation > -1) {
        scope.otherLocations.splice(indexOfPreviouslySelectedLocation, 1);
      }
    };

    var updateGeocodeAlert = function (radius, show, address) {
      if (show) {
        if (radius.AddressValidated) {
          var customAddress = address.Address1 + ',' + address.City + ',' + address.State + ',' + address.Zip;
          radius.geocodeAlertCss = 'alert alert-small alert-success';
          radius.geocodeAlertText = 'Address Validated As:\n' + customAddress;
          radius.Address.Address1 = address.Address1;
          radius.Address.City = address.City;
          radius.Address.State = address.State;
          radius.Address.Zip = address.Zip;
          getZipCodesInRadius(radius);
          $timeout(function () {
            radius.geocodeAlertCss = 'hide';
          }, 5000);

        } else {
          radius.geocodeAlertCss = 'alert alert-small alert-danger';
          radius.geocodeAlertText = 'Invalid Address';
          radius.geocodeButtonDisabled = false;
          radius.IsValidRadius = false;
          $timeout(function () {
            radius.geocodeAlertCss = 'hide';
          }, 5000);
        }
      } else {
        radius.geocodeAlertCss = 'hide';
      }
    };

    scope.addressChanged = function (radius) {
      radius.RadiusAddress = {
        Address1: radius.Address.Address1,
        City: radius.Address.City,
        State: radius.Address.State,
        Zip: radius.Address.Zip
      };
      radius.AddressValidated = false;
      updateGeocodeAlert(radius, false, '');
      radius.geocodeAddressDisabled = true;
      if (radius.RadiusAddress.Address1 !== undefined && radius.RadiusAddress.City !== undefined && radius.RadiusAddress.State !== undefined && radius.RadiusAddress.Zip !== undefined) {
        if (radius.RadiusAddress.Address1.length && radius.RadiusAddress.City.length && radius.RadiusAddress.State.length && radius.RadiusAddress.Zip.length) {
          radius.geocodeAddressDisabled = false;
        }
      }
      radiusValidator();
    };

    //Custom Address
    scope.geocodeRadiusAddress = function (radius) {
      radius.AddressValidated = false;
      radius.geocodeButtonDisabled = true;
      var formattedAddress = getFormattedAddress(radius.Address);
      console.log(formattedAddress);
      geocodeSvc.geocodeAddress(formattedAddress,
      function (geocodeResponse) {
        var alertText = '';
        if (geocodeResponse !== null && geocodeResponse !== undefined && geocodeResponse.success === true) {
          var resolvedValidatedAddress = angular.copy(geocodeResponse.resolvedAddress);
          radius.Address = resolvedValidatedAddress;
          radius.IsValidRadius = true;
          radius.isRadiusInEditMode = false;
          radius.AddressValidated = true;
          radius.geocodeButtonDisabled = true;
          radius.EditCustomAddressEnable = true;
          radius.EnableCancelbutton = false;
          alertText = geocodeResponse.resolvedAddress;
          radius.ValidatedAddress = geocodeResponse.resolvedAddress;
        } else {
          radius.EnableCancelbutton = false;
          radius.AddressValidated = false;
          alertText = '';
        }
        updateGeocodeAlert(radius, true, alertText);
      }
      );
    };

    // Enhancing Radius UI
    scope.editCustomAddress = function (radius) {
      radius.isRadiusInEditMode = true;
      radius.EditCustomAddressEnable = false;
      radius.geocodeButtonDisabled = false;
      radius.EnableCancelbutton = true;
      radiusValidator();
    };

    scope.cancelEditingCustomAddress = function (radius) {
      radius.isRadiusInEditMode = false;
      radius.EditCustomAddressEnable = true;
      radius.geocodeButtonDisabled = true;
      radius.EnableCancelbutton = false;
      var lastValidAddress = angular.copy(radius.ValidatedAddress);
      radius.Address = lastValidAddress;
      getZipCodesInRadius(radius);
    };

    function getFormattedAddress(address) {
      var formattedAddress = address.Address1;
      formattedAddress = formattedAddress + ', ' + address.City + ', ' + address.State + ' ' + address.Zip;
      return formattedAddress;
    }

    scope.removeRadius = function (radiusDescriptor) {
      //TODO: Prompt user if they are sure they want to remove
      var index = scope.radii.indexOf(radiusDescriptor);
      if (index !== undefined) { scope.radii.splice(index, 1); }
      scope.radiiLength = scope.radii.length;
      enableApplyToAll();
    };

    getOtherLocations();

    var applyCustomSort = function (data) {
      var result = _.groupBy(data, function (currentObject) {
        return currentObject.Name.toUpperCase() !== 'CUSTOM ADDRESS';
      });

      return _.flatten([result.false ? result.false : [], _.sortBy(result.true, function (item) { return item.Name.toLowerCase(); })]);
    };

    scope.radii = prepRadiusDescriptors(location.RadiusDescriptors);

    if (location.RadiusDescriptors.length < 1) {
      scope.addAnotherRadius();
    } else if (location.RadiusDescriptors[0].SelectedLocationId !== 'customAddress') {
      location.RadiusDescriptors[0].isRadiusInEditMode = false;
      location.RadiusDescriptors[0].IsValidRadius = true;
    }

    scope.radiiLength = scope.radii.length;

    scope.$watch('radiusLoading', function () {
      return radiusValidator();
    });

    scope.$watch('radiiLength', function () {
      return radiusValidator();
    });

    var radiusValidator = function () {

      // Check if Radius in Edit Mode
      var validateRadiiForEditMode = _.filter(scope.radii, function (radius) {
        return !radius.isRadiusInEditMode;
      });

      // Check For Invalid radius
      var validRadii = _.filter(scope.radii, function (radius) {
        return radius.IsValidRadius && scope.isRadiusValid(radius.RadiusInMiles);
      });
      scope.radiiForm.$valid = validRadii && validRadii.length === scope.radiiLength;

      // Check if there is No zip
      var validateRadiiIfNoZip = _.filter(scope.radii, function (radius) {
        return radius.RadiusZipCodeIds && radius.RadiusZipCodeIds.length>0;
      });

      return scope.completeStep(validateRadiiForEditMode && validateRadiiForEditMode.length === scope.radiiLength && scope.radiiForm.$valid && (validateRadiiIfNoZip && validateRadiiIfNoZip.length === scope.radiiLength));
    };

    scope.$on('previous', function (event, go) {
      go('serviceAreaRadius');
    });

    scope.$watch('radiiForm.$valid', function () {
      listStateSvc.get().CurrentUIState.radiusValid = scope.radiiForm.$valid;
      if (scope.radiusLoading.length > 0) {
        scope.completeStep(scope.radiiForm.$valid);
      }
    });
  }
  ]);
})(window.app);
