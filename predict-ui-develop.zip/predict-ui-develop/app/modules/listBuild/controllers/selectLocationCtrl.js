(function (app) {
  'use strict';

  app.controller('selectLocationCtrl', ['$scope', 'locationSvc', 'sessionSvc', 'listStateSvc', '_', 'facilitySvc', 'authSvc', 'alertSvc',
  function (scope, locationSvc, sessionSvc, listStateSvc, _, facilitySvc, authSvc, alertSvc) {
    if (scope.initializeStep) {
      scope.initializeStep('selectLocation', false);
    }

    // DEFINE GEOS DEMO
    location.demoLocationAdded = false;
    scope.demoEditLocation = false;
    scope.demoAddLocation = function(location) {
      location.demoLocationAdded = true;
    };
    scope.demoRemoveLocation = function(location) {
      location.demoLocationAdded = false;
    };
    location.targetArea = {
      serviceArea: false,
      radius: false
    };
    location.serviceArea = {
      primary: true,
      secondary: false,
      tertiary: false
    };

    var getUserLocations = function (locations) {
      var userLocations = [];
      if (locations) {
        var userAllowedLocationIds = authSvc.getAllowedUserLocationIds();
        if (userAllowedLocationIds.length > 0) {
          _.forEach(locations, function (location) {
            if (userAllowedLocationIds.indexOf(location.Id) !== -1) {
              userLocations.push(location);
            }
          });
        }

        if (userLocations.length <= 0) {
          alertSvc.add({ Type: 'Error', Title: 'No Data Found', Source: 'baseLocation', Message: 'You have not been granted access to any base locations.  Please contact your System Administrator to request access.' });
        }

        return userLocations;
      }
    };

    if (!scope.locations) {
      var rawLocations = sessionSvc.get('selectLocation.locations');
      if (rawLocations !== null) {
        scope.locations = getUserLocations(JSON.parse(rawLocations));
      } else {
        scope.locationsLoading = locationSvc.listLocations().then(function (data) {
          scope.locations = getUserLocations(data);
          sessionSvc.set('selectLocation.locations', JSON.stringify(scope.locations));
        });
      }
    }

    if (listStateSvc.get().LocationDescriptors) {
      var locationIndex = listStateSvc.get().CurrentUIState.CurrentLocationIndex;

      if (listStateSvc.get().CurrentUIState && listStateSvc.get().LocationDescriptors[locationIndex] && listStateSvc.get().LocationDescriptors[locationIndex].LocationId) {
        scope.selectedLocationId = listStateSvc.get().LocationDescriptors[locationIndex].LocationId;
      }

      if (scope.selectedLocationId !== null && scope.selectedLocationId !== undefined && scope.selectedLocationId !== '') {
        scope.completeStep(true);
      }

      scope.locationChanged = function () {
        if (scope.selectedLocationId !== null && scope.selectedLocationId !== undefined && scope.selectedLocationId !== '') {
          var location = _.find(scope.locations, { 'Id': scope.selectedLocationId });
          if (location) {

            if (listStateSvc.get().LocationDescriptors.length < 1) {
              listStateSvc.get().LocationDescriptors.push({
                'Type': 'ServiceArea',
                'UsePrimaryServiceArea': true,
                'UseSecondaryServiceArea': true,
                'UseTertiaryServiceArea': true
              });
            }

            _.extend(listStateSvc.get().LocationDescriptors[locationIndex], {
              'Type': 'ServiceArea', //extending and overriding the properties while editing the base location
              'UsePrimaryServiceArea': true,
              'UseSecondaryServiceArea': true,
              'UseTertiaryServiceArea': true,
              'LocationId': location.Id,
              'Name': location.Name,
              'Address': location.Address,
              'PrimaryServiceAreaZipCodes': location.PrimaryServiceAreaZipCodes,
              'SecondaryServiceAreaZipCodes': location.SecondaryServiceAreaZipCodes,
              'TertiaryServiceAreaZipCodes': location.TertiaryServiceAreaZipCodes,
              'SelectedZipCodes': _.union(location.PrimaryServiceAreaZipCodes, location.SecondaryServiceAreaZipCodes, location.TertiaryServiceAreaZipCodes),
              'RadiusDescriptors': [{'LocationId': location.Id, 'Address': location.Address, 'RadiusInMiles': 15, 'SelectedLocationId': location.Id, 'AdditionalZipCodeIds': [], 'ExcludedZipCodeIds': [], 'RadiusZipCodeIds': [], 'LocationAvailableZipCodes': _.union(location.PrimaryServiceAreaZipCodes, location.SecondaryServiceAreaZipCodes, location.TertiaryServiceAreaZipCodes) }]
            });
            //Add check to avoid multiple call for facilities
            var locationIds = [];
            var facilities = JSON.parse(sessionSvc.get('selectedLocation.facilities'));
            if (facilities !== null) {
              _.forEach(facilities.Facilities, function (data) {
                locationIds.push(data.LocationId);
              });
            }
            if (locationIds.indexOf(location.Id) < 0) {
              locationIds.push(location.Id);
              locationIds = _.uniq(locationIds);
              facilitySvc.getFacilities({
                'locationids': locationIds.join(',')
              }).then(function (facilityData) {
                sessionSvc.set('selectedLocation.facilities', JSON.stringify(facilityData));
              });
            }
            scope.completeStep(true);
          }
        } else {
          scope.completeStep(false);
        }
      };
    }
  }
  ]);
})(window.app);
