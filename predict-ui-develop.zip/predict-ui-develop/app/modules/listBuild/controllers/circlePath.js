(function (app) {
  'use strict';

  app.factory('circlePath', function () {
    return function (center, radius, completePath) {
      completePath = !!completePath;

      var re = 6378137.0;
      var d2r = d2r || Math.PI / 180;
      var multipliers = [];

      var segments = 32;
      var dRad = 2 * Math.PI / segments;
			
      for (var i = 0; i < (segments + (completePath ? 1 : 0)); i+=1) {
        var rads = dRad * i;
        var y = Math.sin(rads);
        var x = Math.cos(rads);
        var pair = [];
        pair.push(Math.abs(y) < 0.01 ? 0.0 : y);
        pair.push(Math.abs(x) < 0.01 ? 0.0 : x);
				multipliers.push(pair);
      }

      var centerLng = center[0];
      var centerLat = center[1];

      var dLat = radius / (re * d2r);
      var dLng = radius / (re * Math.cos(d2r * centerLat) * d2r);
			
			var truncateCoord = function (coord) {
				var decIndex = coord.toString().indexOf('.');
				if (decIndex > -1) {
					coord = coord.toString().slice(0, (decIndex + 6));
				}
				return parseFloat(coord);
			};
			
      return _.map(multipliers, function (x) {
				var lat = parseFloat(centerLat) + x[0] * dLat;
				var lng = parseFloat(centerLng) + x[1] * dLng;
				return [ truncateCoord(lng), truncateCoord(lat) ];
      });
    };
  });
  
})(window.app);
