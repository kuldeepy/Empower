(function (app) {
  'use strict';

  app.controller('serviceAreaCtrl', ['$scope', 'listStateSvc', 'geographiesLookupSvc',
    function (scope, listStateSvc, geographiesLookupSvc) {
      if (scope.initializeStep) {
        scope.initializeStep('serviceArea', false);
      }
      scope.zipCodesLoading = [];
      scope.toggleExpandedPanel = true; // Open expandable panel by default
      scope.serviceAreasInfoIndicator = 'Choose service areas by checking the boxes on the right. You can also further refine the selected areas if needed.';
      var listState = listStateSvc.get();
      if (listState.LocationDescriptors) {
        // only force a refresh of the counts for the first location.
        if (listState.LocationDescriptors.length === 1) {
          scope.$emit('getQuickCount');
        }
        var location = listState.LocationDescriptors[listState.CurrentUIState.CurrentLocationIndex];
        // Attach scope to parts of location object to make available to the view
        scope.location = {
          Name: location.Name,
          Address: {
            Address1: location.Address.Address1,
            City: location.Address.City,
            State: location.Address.State,
            Zip: location.Address.Zip
          }
        };
        if (location.RadiusDescriptors.length > 0 && location.SelectedZipCodes.length === 0) {
          location.SelectedZipCodes = _.union(location.PrimaryServiceAreaZipCodes, location.SecondaryServiceAreaZipCodes, location.TertiaryServiceAreaZipCodes);
        }
        location.RadiusDescriptors = [];
        scope.areas = [
          {name: 'Primary'},
          {name: 'Secondary'},
          {name: 'Tertiary'}
        ];
        scope.listBoxData = {
          zipCodes: [],
          counties: [],
          states: []
        };

        //Get zip code data
        var zipCodesByLocationPromise = geographiesLookupSvc.getZipCodesByLocation({
          'Id': location.LocationId,
          'IncludeGeoJSON': false
        }).then(function (zipData) {
          scope.listBoxData.zipCodes = zipData;

          //Get State Data
          var stateIds = _.chain(scope.listBoxData.zipCodes).pluck('State').uniq().value();
          scope.listBoxData.states = geographiesLookupSvc.getStatesById({'Ids': stateIds});

          //Get county data
          var countyIds = _.chain(scope.listBoxData.zipCodes).pluck('CountyIds').flatten().uniq().value();
          var countiesByIdPromise = geographiesLookupSvc.getCountiesById({
            'CountyIds': countyIds
          }).then(function (countiesData) {
            scope.listBoxData.counties = countiesData;
            initializeListBoxes();
            disableUnpopulatedAreas();
            updateAllAreas();
            scope.completeStep(true);
          });
          scope.zipCodesLoading.push(countiesByIdPromise);
        });
        scope.zipCodesLoading.push(zipCodesByLocationPromise);

        var isChecked = function (x) {
          return x.checked;
        };

        var shouldZipBeChecked = function (id) {
          if (!id) {
            return false;
          }
          //Check current UI state for values first
          return _.contains(location.SelectedZipCodes, id);
        };

        var shouldAreaBeChecked = function (area) {
          return _.chain(scope.listBoxData.zipCodes)
            .filter(function (zipCode) {
              return _.contains(area, zipCode.Id);
            })
            .every(isChecked)
            .value();
        };

        var shouldAreaBeIndeterminate = function (area) {
          return _.chain(scope.listBoxData.zipCodes)
            .filter(function (zipCode) {
              return _.contains(area, zipCode.Id);
            })
            .any(isChecked)
            .value();
        };

        var shouldCountyBeChecked = function (countyId) {
          return _.chain(scope.listBoxData.zipCodes)
            .filter(function (zipCode) {
              return _.contains(zipCode.CountyIds, countyId);
            })
            .every(isChecked)
            .value();
        };

        var shouldCountyBeIndeterminate = function (countyId) {
          return _.chain(scope.listBoxData.zipCodes)
            .filter(function (zipCode) {
              return _.contains(zipCode.CountyIds, countyId);
            })
            .any(isChecked)
            .value();
        };

        var shouldStateBeChecked = function (stateId) {
          return _.chain(scope.listBoxData.zipCodes)
            .filter(function (zipCode) {
              return _.contains(zipCode.State, stateId);
            })
            .every(isChecked)
            .value();
        };

        var shouldStateBeIndeterminate = function (stateId) {
          return _.chain(scope.listBoxData.zipCodes)
            .filter(function (zipCode) {
              return _.contains(zipCode.State, stateId);
            })
            .any(isChecked)
            .value();
        };

        var initializeListBoxes = function () {
          initializeZipCodes();
          initializeCounties();
          initializeStates();
        };

        var checkArea = function (zipCodes, area, zip) {
          if (_.contains(zipCodes, zip.Id)) {
            updateArea(zipCodes, area);
          }
        };

        var areaBeChecked = function (zipCode) {
          checkArea(location.PrimaryServiceAreaZipCodes, scope.areas[0], zipCode);
          checkArea(location.SecondaryServiceAreaZipCodes, scope.areas[1], zipCode);
          checkArea(location.TertiaryServiceAreaZipCodes, scope.areas[2], zipCode);
        };

        var updateArea = function (zipCodes, area) {
          if (!area.disabled) {
            area.checked = shouldAreaBeChecked(zipCodes);
            area.indeterminate = (!area.checked) ? shouldAreaBeIndeterminate(zipCodes) : false;
          }
        };

        var initializeZipCodes = function () {
          _.forEach(scope.listBoxData.zipCodes, function (zipCode) {
            _.extend(zipCode, {'text': zipCode.Id, 'checked': shouldZipBeChecked(zipCode.Id),
              'changed': function (checked) {
                zipCode.checked = checked;
                areaBeChecked(zipCode);
                //Check county if necessary
                _.forEach(zipCode.CountyIds, function (countyId) {
                  var zipCounty = _.find(scope.listBoxData.counties, {'Id': countyId});

                  if (zipCounty) {
                    zipCounty.checked = shouldCountyBeChecked(countyId);
                    zipCounty.indeterminate = (!zipCounty.checked) ? shouldCountyBeIndeterminate(countyId) : false;
                  }
                });

                var zipState = _.find(scope.listBoxData.states, {'Id': zipCode.State});
                zipState.checked = shouldStateBeChecked(zipCode.State);
                zipState.indeterminate = (!zipState.checked) ? shouldStateBeIndeterminate(zipCode.State) : false;
                updateView();
              }
            });
          });
        };

        var initializeCounties = function () {
          _.forEach(scope.listBoxData.counties, function (county) {
            _.extend(county, {'text': county.Name, 'checked': shouldCountyBeChecked(county.Id),
              'changed': function (checked) {
                county.indeterminate = false;

                //Check zips if they are not excluded by another unchecked county
                _.forEach(scope.listBoxData.zipCodes, function (zip) {
                  if (_.contains(zip.CountyIds, county.Id)) {
                    zip.checked = checked;
                    areaBeChecked(zip);
                  }
                });

                var zipState = _.find(scope.listBoxData.states, {'Id': county.State});
                zipState.checked = shouldStateBeChecked(county.State);
                zipState.indeterminate = (!zipState.checked) ? shouldStateBeIndeterminate(county.State) : false;

                updateView();
              }
            });
          });
        };

        var initializeStates = function () {
          _.forEach(scope.listBoxData.states, function (state) {
            _.extend(state, {'text': state.Name, 'checked': shouldStateBeChecked(state.Id),
              'changed': function (checked) {
                state.indeterminate = false;

                _.chain(scope.listBoxData.zipCodes)
                  .filter(function (zip) {
                    return zip.State === state.Id;
                  })
                  .forEach(function (zip) {
                    zip.checked = checked;
                    areaBeChecked(zip);
                  });
                updateView();
              }
            });
          });
        };

        var checkAreaZips = function (checked, areaZips) {
          _.forEach(scope.listBoxData.zipCodes, function (zip) {
            zip.checked = _.contains(areaZips, zip.Id) ? checked : zip.checked;
          });
        };

        var updateView = function () {
          var uncheckedZips = _.filter(scope.listBoxData.zipCodes, function (zip) {
            return !zip.checked;
          });

          if (uncheckedZips.length === 0) {
            _.forEach(scope.listBoxData.states, function (state) {
              state.checked = true;
              state.indeterminate = false;
            });

            _.forEach(scope.listBoxData.counties, function (county) {
              county.checked = true;
              county.indeterminate = false;
            });

            _.forEach(scope.areas, function (area) {
              if (!area.disabled) {
                area.checked = true;
              }
            });
          }
          updateAllAreas();
        };

        var updateCounties = function () {
          _.forEach(scope.listBoxData.counties, function (county) {
            county.checked = shouldCountyBeChecked(county.Id);
            county.indeterminate = (!county.checked) ? shouldCountyBeIndeterminate(county.Id) : false;
          });
        };

        var updateStates = function () {
          _.forEach(scope.listBoxData.states, function (state) {
            state.checked = shouldStateBeChecked(state.Id);
            state.indeterminate = (!state.checked) ? shouldStateBeIndeterminate(state.Id) : false;
          });
        };

        var updateAreas = function () {
          updateArea(location.PrimaryServiceAreaZipCodes, scope.areas[0]);
          updateArea(location.SecondaryServiceAreaZipCodes, scope.areas[1]);
          updateArea(location.TertiaryServiceAreaZipCodes, scope.areas[2]);
        };

        var disableUnpopulatedAreas = function () {
          scope.areas[0].disabled = !location.PrimaryServiceAreaZipCodes || location.PrimaryServiceAreaZipCodes.length === 0;
          scope.areas[1].disabled = !location.SecondaryServiceAreaZipCodes || location.SecondaryServiceAreaZipCodes.length === 0;
          scope.areas[2].disabled = !location.TertiaryServiceAreaZipCodes || location.TertiaryServiceAreaZipCodes.length === 0;
          _.forEach(scope.areas, function (area) {
            if (area.disabled) {
              area.checked = false;
            }
          });
        };

        scope.serviceAreaUpdated = function (area) {
          updateAllZips(area);
          updateAllAreas();
        };

        var updateAllZips = function (area) {
          if (!area.disabled) {
            if (area.name === 'Primary') {
              checkAreaZips(area.checked, location.PrimaryServiceAreaZipCodes);
            }
            if (area.name === 'Secondary') {
              checkAreaZips(area.checked, location.SecondaryServiceAreaZipCodes);
            }
            if (area.name === 'Tertiary') {
              checkAreaZips(area.checked, location.TertiaryServiceAreaZipCodes);
            }
          }
        };

        var updateAllAreas = function () {
          updateCounties();
          updateStates();
          updateAreas();
          location.UsePrimaryServiceArea = (scope.areas[0].checked || scope.areas[0].indeterminate) && (!scope.areas[0].disabled);
          location.UseSecondaryServiceArea = (scope.areas[1].checked || scope.areas[1].indeterminate) && (!scope.areas[1].disabled);
          location.UseTertiaryServiceArea = (scope.areas[2].checked || scope.areas[2].indeterminate) && (!scope.areas[2].disabled);
          scope.$watch('listBoxData.zipCodes', function () {
            syncSelectedZips();
          }, true);
          scope.location.UsePrimaryServiceArea = location.UsePrimaryServiceArea;
          scope.location.UseSecondaryServiceArea = location.UseSecondaryServiceArea;
          scope.location.UseTertiaryServiceArea = location.UseTertiaryServiceArea;
        };

        scope.initializeServiceArea = function () {
          scope.areas[0].checked = location.UsePrimaryServiceArea === false || location.UsePrimaryServiceArea === '' ? false : true;
          scope.areas[1].checked = location.UseSecondaryServiceArea === false || location.UseSecondaryServiceArea === '' ? false : true;
          scope.areas[2].checked = location.UseTertiaryServiceArea === false || location.UseTertiaryServiceArea === '' ? false : true;
        };

        var getSelectedZips = function () {
          var selectedZips = [];
          _.forEach(scope.listBoxData.zipCodes, function (zip) {
            if (zip.checked) {
              selectedZips.push(zip.Id);
            }
          });
          return selectedZips;
        };

        var syncSelectedZips = function () {
          location.SelectedZipCodes = getSelectedZips();
          listState.CurrentUIState.zipsSelectedValid = location.SelectedZipCodes.length > 0;
          scope.completeStep(listState.CurrentUIState.zipsSelectedValid);
        };
      }

      scope.$on('next', function (event, go) {
        go('geographiesSummary');
      });
    }
  ]);
})(window.app);
