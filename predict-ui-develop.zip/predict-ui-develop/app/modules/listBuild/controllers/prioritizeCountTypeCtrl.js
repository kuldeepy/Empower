(function (app) {
  'use strict';

  app.controller('prioritizeCountTypeCtrl', ['$scope', 'listStateSvc',
  function (scope, listStateSvc) {
    if (scope.initializeStep) {
      scope.initializeStep('prioritizeCountType', true);
    }
    var listState = listStateSvc.get();
    if (listState.ExcludeHoldouts === undefined || listState.CurrentUIState.isControlGroupDirty) {
      scope.controlGroupSelected = 'Yes';
      listState.CurrentUIState.isControlGroupDirty = false;
      listState.ExcludeHoldouts = true;
    }
    else {
      scope.controlGroupSelected = listState.ExcludeHoldouts ? 'Yes' : 'No';
    }

    if (listState.DistributeByHousehold === undefined) {
      scope.prioritizeCountTypeSelected = 'Household';
      listState.DistributeByHousehold = true;
    }
    else {
      scope.prioritizeCountTypeSelected = listState.DistributeByHousehold ? 'Household' : 'Individual';
    }

    scope.countTypeSelection = function () {
      var disableNext = (scope.controlGroupSelected !== 'No');
      listState.ExcludeHoldouts = scope.controlGroupSelected === 'Yes';
      listState.DistributeByHousehold = scope.prioritizeCountTypeSelected === 'Household';
      scope.showConrtolGroupWarning = listState.CurrentUIState.isControlGroupDirty = (!disableNext);
      scope.completeStep(disableNext);
    };

    scope.confirmControlGroupSelection = function (controlGroupSelection) {
      if (controlGroupSelection) {
        listState.ExcludeHoldouts = scope.controlGroupSelected === 'Yes';
      } else {
        scope.controlGroupSelected = 'Yes';
        listState.ExcludeHoldouts = true;
      }
      listState.CurrentUIState.isControlGroupDirty = scope.showConrtolGroupWarning = false;
      scope.completeStep(true);
    };

    scope.$on('previous', function (event, override) {
      scope.confirmControlGroupSelection();
      override('manageSegments');
    });
  }]);

})(window.app);