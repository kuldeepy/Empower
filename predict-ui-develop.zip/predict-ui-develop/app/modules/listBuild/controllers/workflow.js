(function (app) {
  'use strict';

  app.factory('workflow', ['$state', function ($state) {
    return {
      steps: [
        { 'name': 'listName' },
        { 'name': 'recipe' },
        { 'name': 'selectLocation' },
        { 'name': 'serviceAreaRadius' },
        { 'name': 'serviceArea' },
        { 'name': 'radius' },
        { 'name': 'geographiesSummary' },
        { 'name': 'pastLists' },
        { 'name': 'manageSeedList' },
        { 'name': 'criteria' },
        { 'name': 'manageSegments' },
        { 'name': 'manageSegmentsGeographies' },
        { 'name': 'manageSegmentsListInclusions' },
        { 'name': 'manageSegmentsFilters' },
        { 'name': 'prioritizeCountType' },
        { 'name': 'managePrioritize' },
        { 'name': 'summary' }
      ],
      hasStep: function (stepName) {
        return !_.contains(this.steps, function (step) {
          return step.name === stepName;
        });
      },
      go: function (stepName) {
        if (!this.hasStep(stepName)) {
          throw new Error('No step named ' + stepName + ' found');
        }

        app.publish('beforeChangeStep', stepName);

        $state.go(stepName);

        app.publish('afterChangeStep', stepName);
      },
      next: function () {
        this.go(this.changeToStep(true));
      },
      previous: function () {
        this.go(this.changeToStep(false));
      },
      changeToStep: function (isForward) {
        var currentIndex = _.findIndex(this.steps, function (workflowItem) {
          return workflowItem.name === $state.current.name;
        });

        if (currentIndex < 0) {
          throw new Error('Could not find current state in workflow');
        }

        if (isForward) {
          return currentIndex < this.steps.length ? this.steps[currentIndex + 1].name : this.steps[currentIndex].name;
        }
        else {
          return currentIndex > 0 ? this.steps[currentIndex - 1].name : this.steps[currentIndex].name;
        }
      }
    };
  }]);

})(window.app);
