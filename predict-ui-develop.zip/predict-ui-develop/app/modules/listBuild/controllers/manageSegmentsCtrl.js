(function (app) {
  'use strict';

  app.controller('manageSegmentsCtrl', ['$scope', '_', 'util', 'sessionSvc',
  'listStateSvc', 'mostRecentCalculation', '$timeout', 'pivotTableSvc',
  function (scope, _, util, sessionSvc, listStateSvc, mostRecentCalculation, $timeout, pivotTableSvc) {
    if (scope.initializeStep) {
      scope.initializeStep('manageSegments', true);
      scope.hasDuplicateSegmentNames = false;
      scope.orphanedHouseholds = 0;
      scope.orphanedIndividuals = 0;
      scope.currentListState.UseLocationLogic = scope.currentListState.UseLocationLogic === null || scope.currentListState.UseLocationLogic === undefined ? true : scope.currentListState.UseLocationLogic;
      quickCountRefresh(scope.quickCounts);
    }

    scope.pivotTableWaiting = false;
    scope.limitGeoIndicator = 'When checked, targets must live within the geographies of the location(s) selected for a segment.  When unchecked, targets must prefer the location(s) selected for each segment.';

    var listState = scope.listState = listStateSvc.get();
    if (!listState) { return; }

    scope.listMetaName = listState.Name;

    scope.$watchCollection('listState.LocationDescriptors', ensureLocationDescriptors);

    ensureLocationDescriptors(listState.LocationDescriptors);

    if (scope.noGeographies) {
      return;
    }

    scope.controllerData = {
      gridData: [],
      gridColumn: [
        {
          field: 'Priority',
          displayName: 'Priority',
          sortable: false
        },
        {
          field: 'Name',
          displayName: 'Segment Name',
          enableCellEdit: true,
        },
        {
          field: 'UpdatedOn',
          displayName: 'Date Modified'
        },
        {
          field: 'HouseholdTotalCount',
          displayName: 'Households'
        },
        {
          field: 'IndividualTotalCount',
          displayName: 'Individuals'
        },
        {
          field: 'Actions',
          displayName: ''
        }
      ]
    };

    scope.$emit('update quick count');

    scope.currentSegment = listState.CurrentUIState.selectedSegment;

    scope.useLocationGeographies = scope.currentListState.UseLocationLogic === null || scope.currentListState.UseLocationLogic === undefined ? false : !scope.currentListState.UseLocationLogic;

    scope.individualTotal = function (segment) {
      var calculation = scope.quickCounts;
      if (!calculation) {
        return '?';
      }
      var calculationForSegment = _.find(calculation, { segmentName: segment.Name });
      if (!calculationForSegment) {
        return '?';
      }
      return calculationForSegment.totalCountForIndividual;
    };

    scope.householdTotal = function (segment) {
      var calculation = scope.quickCounts;
      if (!calculation) {
        return '?';
      }
      var calculationForSegment = _.find(calculation, { segmentName: segment.Name });
      if (!calculationForSegment) {
        return '?';
      }
      return calculationForSegment.totalCountForHousehold;
    };

    function updateIndividualHouseholdTotal() {
      if (scope.listState && scope.listState.Segments && scope.listState.Segments.length > 0) {
        _.each(scope.listState.Segments, function (val) {
          angular.extend(val, {
            HouseholdTotalCount: scope.householdTotal(val)
          });
          angular.extend(val, {
            IndividualTotalCount: scope.individualTotal(val)
          });
        });
      }
      return null;
    }

    scope.$watch('sortingOptions.field', function () {
        scope.listState.Segments = setPriority(scope.listState.Segments);
      });

    scope.$watch('sortingOptions.reverse', function () {
        scope.listState.Segments = setPriority(scope.listState.Segments);
      });

    scope.sortingOptions = {
        field: 'Priority',
        reverse: false
      };

    scope.changePriority = function (rowIndex, direction) {
        var copiedRow = scope.listState.Segments[rowIndex];
        scope.listState.Segments.splice(rowIndex, 1);
        scope.listState.Segments.splice(rowIndex + direction, 0, copiedRow);
        _.each(scope.listState.Segments, function (row, rowIndex) {
            row.Priority = rowIndex;
          });
      };

    var setPriority = function (rowData) {
        rowData = _.sortBy(rowData, scope.sortingOptions.field);
        if (scope.sortingOptions.reverse) {
          rowData.reverse();
        }
        _.each(rowData, function (row, rowIndex) {
            row.Priority = rowIndex;
          });
        rowData = _.sortBy(rowData, 'Priority');
        return rowData;
      };

    updateIndividualHouseholdTotal();

    scope.$watch('listState.Segments', function () {
      if (scope.listState.Segments && scope.listState.Segments.length > 1) {
        var segmentNames = _.pluck(scope.listState.Segments, 'Name');
        if (segmentNames && segmentNames.length > 1) {
          scope.hasDuplicateSegmentNames = _.uniq(segmentNames).length !== segmentNames.length;
        }
      }
      updateIndividualHouseholdTotal();
      scope.controllerData.gridData = scope.listState.Segments;
    }, true);

    scope.$watch('hasDuplicateSegmentNames', function (val) {
      scope.completeStep(!val);
    });

    var newSegmentIndex = 1;

    function displayNewSegmentIndex(newSegmentIndex) {
      return (newSegmentIndex > 1) ? ' ' + newSegmentIndex : '';
    }

    scope.addSegment = function () {
      var segment = {
        Name: 'New Segment' + displayNewSegmentIndex(newSegmentIndex),
        FilterValueSelections: [],
        IncludedPastListIds: [],
        ExcludedPastListIds: [],
        targetedCount: 0,
        LocationDescriptorIndices: _.map(listState.LocationDescriptors,
        function (x, index) { return index; }),
        UpdatedOn: new Date(),
        Editable: true,
        Priority : listState.Segments.length
      };
      newSegmentIndex = newSegmentIndex + 1;
      listState.Segments.push(segment);
      focusNewRowName();
    };

    scope.editSegmentName = function (segment) {
      if (segment.Editable) {
        segment.Editable = false;
      }
      else {
        segment.Editable = true;
      }
    };

    scope.saveSegmentName = function (segment) {
      if (segment.Editable) {
        segment.Editable = false;
      }
      else {
        segment.Editable = true;
      }
    };

    scope.editSegment = function (segment) {
      scope.completeStep(false /* do not enable next button */);
      listStateSvc.get().CurrentUIState.selectedSegment = segment;
      scope.go('manageSegmentsGeographies');
    };

    scope.copySegment = function (segment) {
      var copyOfSegment = angular.copy(JSON.parse(JSON.stringify(segment)));
      copyOfSegment.Name = util.generateUniqueCopyOfName(scope.listState.Segments, copyOfSegment.Name, 'Name');
      copyOfSegment.UpdatedOn = new Date();
      copyOfSegment.Priority = scope.listState.Segments.length;
      listState.Segments.push(copyOfSegment);
      focusNewRowName();
    };

    scope.deleteSegment = function (segment) {
      $('#delete-segmentlist').modal('show');
      $('#submitBtn').focus();
      $('#segmentName').val(segment.Name.toString());
    };

    scope.deleteSegmentOnClose = function () {
      $('#delete-segmentlist').modal('hide');
    };

    scope.deleteSegmentOnOk = function () {
      var segmentName = $('#segmentName').val();

      _.remove(listState.Segments, function (seg) {
        return seg.Name === segmentName;
      });
    //for clearing deleted segment from quickcounts
      if (scope.quickCounts) {
        _.remove(scope.quickCounts, function (seg) {
          return seg.segmentName === segmentName;
        });
      }
      $('#delete-segmentlist').modal('hide');
      setPriority(scope.listState.Segments);
    };

    scope.getListCountDocument = function (list, listName) {
      scope.pivotTableWaiting = pivotTableSvc.getListCountDocument(list, listName);
    };

    scope.setLocSegmentationType = function () {
      scope.currentListState.UseLocationLogic = !scope.useLocationGeographies;
      scope.$emit('getQuickCount');
    };

    scope.quickCountLoading = scope.$parent.quickCountLoading;

    scope.$on('next', function (event, go) {
      scope.$emit('update quick count');
      go('prioritizeCountType');
    });

    scope.$on('quick count refreshed', function (event, quickCount) {
      quickCountRefresh(quickCount);
    });

    function quickCountRefresh(quickCount) {
      var sum = function (a, b) { return a + b; };

      if (_.isArray(quickCount)) {
        quickCount = _.first(quickCount);
      }

      if (!quickCount) { return 0; }

      var segmentHouseholdTotal = _.chain(quickCount.segments)
      .pluck('totalCountForHousehold')
      .reduce(sum, 0)
      .value();

      var segmentIndividaulTotal = _.chain(quickCount.segments)
      .pluck('totalCountForIndividual')
      .reduce(sum, 0)
      .value();

      scope.orphanedHouseholds = quickCount.totalCountForHousehold - segmentHouseholdTotal;
      scope.orphanedIndividuals = quickCount.totalCountForIndividual - segmentIndividaulTotal;
      updateIndividualHouseholdTotal();
    }

    function ensureLocationDescriptors(locationDescriptors) {
      scope.noGeographies = _.isEmpty(locationDescriptors);
    }

    function focusNewRowName() {
      $timeout(function () {
        $('div[ng-row]').last().find('.segment-name').click();
      });
    }
  }]);
})(window.app);
