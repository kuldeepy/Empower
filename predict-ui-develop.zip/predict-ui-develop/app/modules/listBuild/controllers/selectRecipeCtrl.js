(function(app) {
  'use strict';

  app.controller('selectRecipeCtrl', ['$scope', '$q', 'recipeSvc', 'filterFilter', 'listStateSvc', 'sessionSvc',
    function(scope, $q, recipeSvc, filterFilter, listStateSvc) {
      if (scope.initializeStep) {
        scope.initializeStep('recipe', false);
      }

      scope.filterValue = '';
      scope.filteredRecipes = [];
      scope.currentList = {};


      console.log ('recipes: loading');
      scope.recipesLoading = recipeSvc.getRecipesForOrganization().then(function (data) {
        console.log('recipes: loaded');
        scope.recipes = data;
        scope.filteredRecipes = data;
      });

      scope.loading.then(function() {
        scope.currentList = listStateSvc.get();
      });

      scope.gridOptions = {
        data: 'filteredRecipes',
        multiSelect: false,
        rowHeight: 45,
        headerRowHeight: 30,
        selectedItems: scope.selectedRows,
        /* jshint ignore:start */
        plugins: [new ngGridFlexibleHeightPlugin()],
        /* jshint ignore:end */
        columnDefs: [{
          field: '',
          width: 30,
          cellTemplate: '<div class="ngCellText ngSelectionCell" ng-class="col.colIndex()">' +
            '<input type="radio" name="recipeGroup" value="{{row.getProperty(\'Id\')}}" style="vertical-align: middle" ng-checked="row.selected"/></div>'
        }, {
          field: 'Name',
          displayName: 'Ideal Target'
        }],
        afterSelectionChange: function(newValue) {
          if (scope.currentList) {
            scope.currentList.RecipeId = newValue.entity.Id;
          }
          scope.completeStep(true);
          scope.test();
        }
      };

      scope.$on('ngGridEventData', function() {
        angular.forEach(scope.filteredRecipes, function(data, index) {
          if (data.Id === scope.currentList.RecipeId) {
            scope.gridOptions.selectItem(index, true);
            //scrolls the ngGrid to show a newly-selected row as close to the middle row as possible
            //run it the next event loop turn to allow the grid to draw.
            setTimeout(function() {
              scope.gridOptions.ngGrid.$viewport.scrollTop(Math.max(0, (index - 3)) * scope.gridOptions.ngGrid.config.rowHeight);
            }, 10);
          }
        });
      });

      //Selected recipe keeping in scope.
      scope.test = function() {
        angular.forEach(scope.selectedRows, function(item) {
          scope.model.selectedRecipeId = item.Id;
        });
      };

      scope.$watch('filterValue', function() {
        scope.filteredRecipes = filterFilter(scope.recipes, scope.filterValue);
      });

      scope.selectNone = function() {
        scope.gridOptions.selectAll(false);
      };
    }
  ]);
})(window.app);