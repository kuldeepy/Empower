(function (app) {
  'use strict';

  app.controller('manageSegmentsFiltersCtrl', ['$rootScope', '$scope', '$q', 'listStateSvc', '$filter',
  'recipeSvc', 'filterTypeSvc', 'calculationSvc',
  function (rootScope, scope, $q, listStateSvc, filter, recipeSvc, filterTypeSvc) {
    if (scope.initializeStep) {
      scope.initializeStep('manageSegmentsFilters', true);
    }

    scope.locations = listStateSvc.get().LocationDescriptors;
    scope.listState = listStateSvc.get();
    scope.selectedSegment = (scope.listState.CurrentUIState.selectedSegment) ? scope.listState.CurrentUIState.selectedSegment : _.first(scope.listState.Segments);
    scope.listFilterValueSelections = scope.selectedSegment.FilterValueSelections;

    scope.criteria = filterTypeSvc.loadFilterTypeData('filters').then(function (data) {
      data = JSON.parse(data);
      data = scope.setDefaultOrderForFilterTypes(data);
      return data;
    });

    scope.setDefaultOrderForFilterTypes = function (data) {

      data.MaritalStatus = scope.applyCustomSort(data.MaritalStatus, 'Name');
      data.Gender = scope.applyCustomSort(data.Gender, 'Name');
      data.AgeOfChildren = scope.applyCustomSort(data.AgeOfChildren, '_id');
      data.AgeRange = scope.applyCustomSort(data.AgeRange, '_id');
      data.Occupation = scope.applyCustomSort(data.Occupation, 'Name');
      data.Race = scope.applyCustomSort(data.Race, 'Name');
      data.PrimaryLanguage = scope.applyCustomSort(data.PrimaryLanguage, 'Name');
      data.PayerType = scope.applyCustomSort(data.PayerType, 'Name');
      data.BeehiveCluster = scope.applyCustomSort(data.BeehiveCluster, 'Name');
      data.HomeOwnership = scope.applyCustomSort(data.HomeOwnership, 'Name');
      data.EducationLevel = scope.applyCustomSort(data.EducationLevel, 'Name');
      data.DwellingType = scope.applyCustomSort(data.DwellingType, 'Name');
      data.HouseholdIncomeGroup = scope.applyCustomSort(data.HouseholdIncomeGroup, '_id');
      data.HomeValue = filter('orderBy')(data.HomeValue, '_id', false);
      data.WealthLevel = scope.applyCustomSort(data.WealthLevel, 'WealthLevelMinVal');
      data.FinancialClass = scope.applyCustomSort(data.FinancialClass, 'Name');
      data.PhysicianType = filter('orderBy')(data.PhysicianType, 'Name', false);
      data.PatientType = filter('orderBy')(data.PatientType, 'Name', false);
      data.EncounterSourceType = scope.applyCustomSort(data.EncounterSourceType, 'Name');

      //Custom Order for Person Types
      var personTypesTemp = [];
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Patients' }));
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Family Member of Patients' }));
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Qualified Prospects' }));
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'Prospects' }));
      personTypesTemp.push(_.find(data.PersonType, { 'Name': 'New Movers' }));
      data.PersonType = personTypesTemp;
      return data;
    };

    scope.applyCustomSort = function (data, sortColumn) {
      var result = _.groupBy(data, function (currentObject) {
        return currentObject.Name.toUpperCase() !== 'UNKNOWN';
      });
      return _.flatten([_.sortBy(result.true, sortColumn), result.false ? result.false : []]);
    };

    scope.parentFilterValueSelections = $q.all([recipeSvc.getRecipe(scope.listState.RecipeId), scope.criteria])
    .then(function (arr) {
      return [arr[0].Filters, arr[1]];
    })
    .then(function (arr) {
      var filters = arr[0];
      var criteria = arr[1];

      var listFilterValueSelections = _.map(scope.listState.FilterValueSelections, _.cloneDeep);

      listFilterValueSelections = _.map(listFilterValueSelections,
      function (listFilterValueSelection) {
        listFilterValueSelection.ExcludeValues = _.map(listFilterValueSelection.ExcludeValues,
        function (x) {
          var num = parseInt(x);

          if (_.isNaN(num) && x && x.toLowerCase) {
            x = x.toLowerCase();
          }
          return _.isNaN(num) ? x : num;
        });
        return listFilterValueSelection;
      });

      _.chain(listFilterValueSelections)
      .filter(function (x) {
        return !_.find(filters, { FilterName: x.FilterName });
      })
      .forEach(function (x) {
        filters.push({
          FilterName: x.FilterName,
          Values: _.pluck(criteria[x.FilterName], '_id')
        });
      });

      return _.map(filters, function (filter) {
        filter = _.cloneDeep(filter);
        var listFilter = _.find(listFilterValueSelections, { FilterName: filter.FilterName });
        if (listFilter && listFilter.ExcludeValues) {
          filter.Values = _.filter(filter.Values, function (val) {
            if (_.isNumber(val)) {
              return !_.contains(listFilter.ExcludeValues, val);
            }
            if (_.isString(val)) {
              var intVal = val.toLowerCase();
              return !_.contains(listFilter.ExcludeValues, intVal);
            }
          });
          filter.Values = _.map(filter.Values, function (x) { return x.toString(); });
        }
        return filter;
      });
    });

    scope.onViewMapClick = function () {
      rootScope.ShowCloseMapButton = true;
      rootScope.$state.go('viewMap');
    };

    scope.$on('next', function (event, override) {
      override('manageSegments');
    });

  }]);
})(window.app);