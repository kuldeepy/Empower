﻿(function (app) {
  'use strict';

  app.controller('listNameAndChannelCtrl', ['$scope','listStateSvc', '$rootScope', 'lookupSvc', 'listSvc', '$timeout', 'listNameSvc',
  function (scope, listStateSvc, rootscope, lookupSvc, listSvc, $timeout, listNameSvc) {
    if (scope.initializeStep) {
      scope.initializeStep('listName', false);
    }
    scope.marketingChannel = { value: '' };
    scope.layout = {
      loading: false
    };
    scope.loading.then(function () {
      scope.currentList = listStateSvc.get();
      scope.$watch('listItem.Name', function (newValue, oldValue) {
        scope.listNameValidationError = false;
        listSvc.currentListName.clear();
        scope.completeStep(false);
        if (newValue === oldValue) {
          return;
        }
        if (scope.listItem.Name && !scope.hasSaved) {
          if (scope.layout.loading) {
            $timeout.cancel(scope.layout.loading);
          }
          scope.layout.loading = $timeout(function () {
            if (scope.listItem.Name) {
              return listNameSvc.checkListNameExist(scope.currentList, scope.listItem.Name).then(function () {
                scope.listNameValidationError = false;
                scope.enableNext();
              }, function () {
                scope.listNameValidationError = true;
                scope.enableNext();
              });
            }
          }, 350);
        }
      });
      scope.$watch('currentList.MarketingChannelId', function () {
        scope.enableNext();
      });
    });

    scope.enableNext = function () {
      if (scope.listItem) {
        if (!scope.listItem.Name) {
          scope.listNameValidationError = false;
          return;
        }
        if (scope.listItem.Name && !scope.listNameValidationError && scope.currentList.MarketingChannelId && scope.currentList.MarketingChannelId !== 0) {
          listSvc.currentListName.set(scope.listItem.Name);
          if (scope.stepIndex === 0 && scope.tabIndex === 0) {
            scope.completeStep(true);
          }
        }
        else {
          listSvc.currentListName.clear();
          scope.completeStep(false);
        }
      }
    };

    scope.getMarketingChannels = function () {
      scope.loadingMarketingChannels = lookupSvc.getLookupDataById('marketing-channel')
      .then(function (data) {
        scope.channelOptions = data;
      });
    };

    scope.getMarketingChannels();

    var changingFilterValueSelection = function (filterValueSelections) {
      var emailMediaTypeId = 2;
      var emailFilter = 'ValidEmail';
      var addressFilter = 'ValidAddress';
      _.remove(filterValueSelections, function (item) {
        return item.FilterName === emailFilter || item.FilterName === addressFilter;
      });
      if (scope.currentList.MarketingChannelId !== emailMediaTypeId) {
        filterValueSelections.push({ FilterName: addressFilter, ExcludeValues: ['False'], IncludeValues: [] });
      }
      else {
        filterValueSelections.push({ FilterName: emailFilter, ExcludeValues: ['False'], IncludeValues: ['True'] });
        filterValueSelections.push({ FilterName: addressFilter, ExcludeValues: [], IncludeValues: ['False', 'True'] });
      }
      if (scope.showQuickCount) {
        scope.$emit('getQuickCount');
      }
    };

    scope.updateFilterValueSelection = function () {
      changingFilterValueSelection(scope.currentList.FilterValueSelections);
      if (scope.currentList.Segments.length > 0){
        _.forEach(scope.currentList.Segments, function (segment) {
          changingFilterValueSelection(segment.FilterValueSelections);
        });
      }
    };

  }
  ]);
})(window.app);