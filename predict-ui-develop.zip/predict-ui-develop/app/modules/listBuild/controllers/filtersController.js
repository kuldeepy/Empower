(function (app) {
	'use strict';

	app.controller('filtersController', ['$scope', 'filterTypeSvc', 'recipeSvc', 'listStateSvc',
	function (scope, filterTypeSvc, recipeSvc, listStateSvc) {
		if (scope.initializeStep) {
			scope.initializeStep('filters', true);
		}

		scope.sliderConfig = {};
		scope.loadFilterTypeData = {};
		scope.filterData = {};

		var listState = scope.listState = listStateSvc.get();

		if (!listState.FilterValueSelections) {
			listState.FilterValueSelections = {};
		}
		
		function mapFilterDescriptorToFilterCollection(filterDescriptor) {
			var filterObject = {};
			if (filterDescriptor && filterDescriptor.length > 0) {
				angular.forEach(filterDescriptor, function (item) {
					filterObject[item.FilterName] = item.Values;
				});
			}
			return filterObject;
		}

		scope.loadCurrentRecipe = function () {
			recipeSvc.getRecipe(listStateSvc.get().RecipeId).then(function (data) {
				scope.filterData = mapFilterDescriptorToFilterCollection(data.Filters);
			});
		};

		scope.loadCurrentRecipe();
	}
	]);

})(window.app);