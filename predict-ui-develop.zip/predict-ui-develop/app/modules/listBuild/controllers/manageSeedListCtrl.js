﻿(function (app) {
  'use strict';

  app.controller('manageSeedListCtrl', ['$scope', 'seedListSvc', 'listStateSvc',
  function (scope, seedListSvc, listStateSvc) {
    if (scope.initializeStep) {
      scope.initializeStep('manageSeedList', true);
    }
    scope.seedLists = [];
    scope.filterValue = '';
    scope.selectedRows = [];
    scope.controllerData = {
      mainTabHeader: 'Seed Lists',
      mainTabDesc: 'Any lists associated to a mandatory seed type for the organization will be selected. To add additional seed lists, select the checkbox beside the list name.',
      selectedItems: [],
      gridData: [],
      gridColumns: [
        {
          field: 'actionValue',
          displayName: 'Add',
          sortable: false
        },
        {
          field: 'SeedListName',
          displayName: 'Seed List'
        },
        {
          field: 'DateModified',
          displayName: 'Date Modified'
        }
      ],
      emptyDataMessage: 'No Seed Lists are available.'
    };
    var listState = listStateSvc.get();
    if (!listState.SeedListIds) {
      listState.SeedListIds = [];
    }
    scope.getSeedLists = function () {
      var mandatoryItems = [];
      console.log('seed lists: loading');
      scope.seedListLoading = seedListSvc.getSeedListData().then(function (data) {
        console.log('seed lists: loaded');
        scope.filteredSeedLists = data;
        scope.influenceHealthSeedListIds = [];
        angular.forEach(scope.filteredSeedLists, function (data) {
          data.selected = false;

          //Get Influence Seed lists Ids
          if (!data.ClientKey) {
            scope.influenceHealthSeedListIds.push(data.Id);
            return;
          }

          if (listState.SeedListIds.length === 0) {
            if (data.IsMandatory) {
              data.selected = true;
              mandatoryItems.push(data.Id);
            }
          } else {
            if (_.contains(listState.SeedListIds, data.Id)) {
              data.selected = true;
            }
          }
        });
        if (listState.SeedListIds.length === 0) {
          listState.SeedListIds = mandatoryItems;
        }
        scope.removeInfluenceHealthSeedId();
        scope.controllerData.gridData = scope.filteredSeedLists;
      });
    };
    scope.getSeedLists();
    scope.removeInfluenceHealthSeedId = function () {
      scope.filteredSeedLists = _.filter(scope.filteredSeedLists, function (seedList) { return (seedList.ClientKey !== '' && seedList.ClientKey !== null); });
      scope.seedLists = scope.filteredSeedLists;
    };

    scope.$watch('seedLists', function () {
      return scope.completeStep(scope.seedLists !== undefined);
    });
    scope.addSelectedSeedList = function() {
      var selectedItems =
        _.filter(scope.filteredSeedLists, function (seedList) {
          return seedList.selected === true;
        });
      listState.SeedListIds = _.union(_.pluck(selectedItems, 'Id'), scope.influenceHealthSeedListIds);
    };

    scope.disabledRow = function (IsMandatory) {
      return (IsMandatory === true) ? ' disabled' : '';
    };

    scope.$watch('filterValue', function (searchText, oldSearchText) {
      if (searchText !== oldSearchText) {
        scope.controllerData.gridData = _.filter(scope.filteredSeedLists, function (seedList) {
          return seedList.SeedListName.toLowerCase().indexOf(searchText.toLowerCase()) !== -1;
        });
      }
    });
  }]);

})(window.app);
