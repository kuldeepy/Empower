(function (app) {
  'use strict';

  app.controller('prioritizeCtrl', ['$scope', 'listStateSvc', 'mostRecentCalculation', '$q',
    function (scope, listStateSvc, mostRecentCalculation, q) {
      if (scope.initializeStep) {
        scope.initializeStep('managePrioritize', true);
      }

      var patientsName = 'Patients';
      var prospectsName = 'Prospects';
      var qualifiedProspectsName = 'Qualified Prospects';
      var newMoversName = 'New Movers';
      var familyMembersName = 'Family Member of Patients';

      var listState = listStateSvc.get();
      scope.completeStep(false);

      app.subscribe('calculation', function () {
        getDistribution();
        if (listStateSvc.get().LocationDescriptors[listStateSvc.get().CurrentUIState.CurrentLocationIndex].Type === 'Radius') {
          scope.completeStep(scope.distributionTables.$valid && listState.CurrentUIState.radiusValid);
        } else {
          scope.completeStep(scope.distributionTables.$valid);
        }
      });
   
      scope.$emit('update quick count');

      getDistribution();

      function getDistributionByPriority(distribution) {

        if (listState.Segments && listState.Segments.length > 0) {

          var prioritizeDisrtibution = [];
          _.each(listState.Segments, function (segment) {

            _.find(distribution.Segments, function (distSegment) {

              if (distSegment.Name.toUpperCase() === segment.Name.toUpperCase()) {
                prioritizeDisrtibution.push(distSegment);
              }
            });
          });

          _.each(distribution.Segments, function (segment) {
            var foundSegment = _.find(listState.Segments, { 'Name': segment.Name });

            if (!foundSegment) {
              prioritizeDisrtibution.push(segment);
            }
          });

          if (prioritizeDisrtibution.length > 0) {
            distribution.Segments = prioritizeDisrtibution;
          }
        }

        return distribution;
      }

      scope.$watch('distributionTables.$valid', function () {
        listState.CurrentUIState.distributionTablesValid = scope.distributionTables.$valid;
        if (scope.quickCountLoading) {
          q.all(scope.quickCountLoading).then(function() {
            scope.completeStep(scope.distributionTables.$valid && scope.distribution.DesiredCount > 0);
          });
        } else {
          scope.completeStep(scope.distributionTables.$valid && scope.distribution.DesiredCount > 0);
        }
      });

      scope.$watch('distribution.DesiredCount', function () {
        scope.completeStep(scope.distributionTables.$valid && scope.distribution.DesiredCount > 0);
      });

      function getDistribution() {
        scope.distLoading = true;
        var calc = mostRecentCalculation();
        if (calc) {
          scope.distribution = listState.Distribution = mapQuickCountsToDistribution(calc);
        }
        scope.distLoading = false;
      }

      function mapQuickCountsToDistribution(quickCounts) {
        if (!quickCounts) { return; }
        if (quickCounts.segments.length > 1) {
          quickCounts.segments = _.filter(quickCounts.segments, function (s) { return s.segmentName !== 'Available Count'; });
        }
        var distribution = {
          SeedListCount: quickCounts.seedListCount ? quickCounts.seedListCount : 0,
          Segments: _.map(quickCounts.segments, function (segmentQuickCount) {
            var personTypeDistributions = mapQuickCountToPersonTypeDistribution(segmentQuickCount);
            var segment = listState.Distribution ? _.find(listState.Distribution.Segments, { 'Name': segmentQuickCount.segmentName }) : null;
            var seg = {
              Name: segmentQuickCount.segmentName,
              PersonTypeDistributions: personTypeDistributions,
              AvailableCount: _.reduce(personTypeDistributions, function (total, item) { return total + item.AvailableCount; }, 0),
              DesiredCount: segment ? segment.DesiredCount : 0
            };
            return seg;
          }),
          DesiredCount: listState.Distribution ? listState.Distribution.DesiredCount : 0
        };
        distribution.AvailableCount = _.reduce(distribution.Segments, function (total, item) { return total + item.AvailableCount; }, 0);
        console.log('distribution', distribution);
        return getDistributionByPriority(distribution);
      }

      function getDistributionByPersonType(segmentDistribution, typeID, typeName, availableCount) {
        return {
          AvailableCount: availableCount,
          DesiredCount: segmentDistribution ? getDesiredCountByPersonType(segmentDistribution, typeID) : 0,
          PersonTypeId: typeID,
          PersonTypeName: typeName
        };
      }

      function getDesiredCountByPersonType(segmentDistribution, typeID) {
        var ptDistribution = _.find(segmentDistribution.PersonTypeDistributions, { 'PersonTypeId': typeID });

        return ptDistribution.DesiredCount;
      }

      function mapQuickCountToPersonTypeDistribution(quickCount) {
        var ptDistributions = [];
        var segmentDistribution = listState.Distribution ? _.find(listState.Distribution.Segments, { 'Name': quickCount.segmentName }) : null;
        var dbh = listState.DistributeByHousehold;

        ptDistributions.push(getDistributionByPersonType(segmentDistribution, 'C', patientsName, dbh ? quickCount.patientCountForHousehold : quickCount.patientCountForIndividual));
        ptDistributions.push(getDistributionByPersonType(segmentDistribution, 'F', familyMembersName, dbh ? quickCount.familyMemberCountForHousehold : quickCount.familyMemberCountForIndividual));
        ptDistributions.push(getDistributionByPersonType(segmentDistribution, 'Q', qualifiedProspectsName, dbh ? quickCount.qualifiedProspectCountForHousehold : quickCount.qualifiedProspectCountForIndividual));
        ptDistributions.push(getDistributionByPersonType(segmentDistribution, 'P', prospectsName, dbh ? quickCount.prospectCountForHousehold : quickCount.prospectCountForIndividual));
        ptDistributions.push(getDistributionByPersonType(segmentDistribution, 'N', newMoversName, dbh ? quickCount.newMoversCountForHousehold : quickCount.newMoversCountForIndividual));

        return ptDistributions;
      }
    }
  ]);

})(window.app);