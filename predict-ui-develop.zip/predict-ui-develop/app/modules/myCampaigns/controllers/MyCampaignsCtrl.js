(function (app) {
  'use strict';
  app.controller('MyCampaignsCtrl', ['$scope', 'userContextSvc',
  function (scope, userContextSvc) {
    scope.homelink = userContextSvc.getUserLandingUrl();
  }
  ]);
})(window.app);