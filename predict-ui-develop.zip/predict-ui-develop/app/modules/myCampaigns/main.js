(function (app) {
  'use strict';

  var modulePath = 'modules/myCampaigns',
  ctrlRoot = app.root + modulePath + '/controllers/';
  app.controller('MyCampaignsCtrl', ['$scope', function (scope) {
    scope.modulePath = modulePath;
    scope.model = {
      routeParams: {}
    };
  }]);

  $.when(
    $.getScript(ctrlRoot + 'MyCampaignsCtrl.js'))
    .done(function () {
      app.publish('moduleReady', modulePath);
    });

})(window.app);