﻿(function (app) {
  'use strict';

  app.controller('pulledListSummaryCtrl', ['$scope', 'userContextSvc', 'calculationSvc', 'listStateSvc',
    function (scope, userContextSvc, calculationSvc, listStateSvc) {

      scope.listLink = '/' + userContextSvc.getClientKey() + '/' + userContextSvc.getOrgKey() + '/lists';

      scope.quickCounts = [];
      scope.quickCountLoading = [];
      var listState = listStateSvc.get();
      var listCalculating = calculationSvc.calculate(listState)
        .then(function (data) {
          scope.quickCounts = data.segments;
        });
      scope.quickCountLoading.push(listCalculating);
      // List Summary iui-page-header breadcrumb
      scope.breadcrumb = [
        {
          name: 'List Management',
          url: scope.listLink
        }
      ];
    }]);
})(window.app);
