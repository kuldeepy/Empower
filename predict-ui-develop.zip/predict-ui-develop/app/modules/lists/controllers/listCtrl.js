(function (app) {
  'use strict';

  app.controller('listCtrl', ['$scope', '$q', 'locationSvc', 'filterFilter', 'listSvc', 'baseApiUrl', 'userContextSvc', '$location',
                '$timeout', '$modal', '$http', 'util', '$state', 'authSvc', 'listStateSvc', 'alertSvc', 'sessionSvc', 'longTaskSvc',
                'listExportSvc', 'clientSvc', '_', '$filter', 'pivotTableSvc',
  function (scope, $q, locationSvc, filterFilter, listSvc, baseApiUrl, userContextSvc, location,
            timeout, $modal, $http, util, state, authSvc, listStateSvc, alertSvc, sessionSvc, longTaskSvc,
            listExportSvc, clientSvc, _, $filter, pivotTableSvc) {

    var pastListInclusions = 'pastLists.included';
    var isSilverpopConfigured = false;
    var etlDate;
    scope.clientKey = userContextSvc.getClientKey();
    scope.exportListLinkImg = false;
    scope.isGridShow = true;
    scope.listSearchResults = [];
    scope.filteredResults = [];
    scope.locations = [];
    scope.layout = [];
    scope.listExporting = [];
    scope.roles = authSvc.getRoles();
    scope.enableExportIcon = false;
    scope.pullListDisabledMessage = 'You have not been granted permission to pull lists. If you need to pull a list, please contact your System Administrator.';
    scope.controllerData = {
      gridData: [],
      gridColumn: [
        {
          field: 'Name',
          displayName: 'Name',
          headerCellTemplate: '<span class="tc-grid-Action">Name</span>'
        },
        {
          field: 'LocationNames',
          displayName: 'Location(s)'
        },
        {
          field: 'CreatorName',
          displayName: 'Created By'
        },
        { field: 'UpdatedOn', displayName: 'Updated' },
        { field: 'actions', displayName: '' }
      ],
      pendingRequestSortingOption: {
        field: 'CreatedOn',
        reverse: true
      },
      filterText: '',
      emptyDataMessage: 'No lists currently exist. Click \'Build New List\' above to create a new one.',
      isLegacyUser: authSvc.isLegacyUser(),
      isAdminRole: sessionSvc.get('auth.adminrole'),
      getUserName: authSvc.getUsername()
    };

    scope.doSearch = function () {
      var params = { 'IncludeFields': '', 'ExcludeFields': '' };
      params.IncludeFields = 'Id,Name,LocationDescriptors,IsEditable,MarketingChannelId,CurrentUIState,PullDate,PullStartDate,ExportDate,ExportStartDate,CreatedBy,CreatedOn,UpdatedOn,OrgId,BWExportDate,IsCountDirty';
      var p1 = listSvc.searchLists(params);
      var p2 = locationSvc.listLocations();
      var p3 = clientSvc.loadClients(scope.clientKey);
      scope.layout.loading = $q.all([p1, p2, p3]).then(function (results) {
        scope.locations = results[1];
        var data = results[0];
        isSilverpopConfigured = results[2].IsSilverpopConfigured;
        etlDate = results[2].ETLDate;
        scope.listSearchResults = scope.formatList(data);
        scope.filteredResults = scope.listSearchResults;
        scope.controllerData.gridData = angular.copy(scope.filteredResults);
      });
    };

    //Clearing Past List Inclusion
    sessionSvc.clear(pastListInclusions);

    scope.showListSummary = function (id) {
      listStateSvc.set(undefined);
      listSvc.getList(id)
      .then(function (data) {
        if (!data) {
          alertSvc.add({ Type: 'Error', Title: 'No Data Found', Source: 'listSummary', Message: 'No list data found' });
        }
        listStateSvc.set(data);
        var listSummaryPath = '/' + scope.clientKey + '/' + userContextSvc.getOrgKey() + '/lists/listsummary';
        location.path(listSummaryPath);
      });
    };

    scope.$on('listExport:started', function () {
      scope.doSearch();
    });

    scope.exportList = function (list, exportToText) {
      scope.layout.loading = listSvc.getList(list.Id).then(function (list) {
        var timestamp = new Date();
        list.ExportStartDate = timestamp.toUTCString();
        listSvc.updateList(list).then(function () {
          scope.listExporting = listExportSvc.createListExportDocument(list, exportToText)
         .then(function () {
            console.log('exporting list ' + list.Id);
            deletePullNotification(list.Id);
            scope.$emit('listExport:started');
          });
        });
      });
    };

    function deletePullNotification(listId) {
      var task = _.find(longTaskSvc.get(), function (task) {
        if (task && task.SuccessBody && task.SuccessBody !== '') {
          var successBody = JSON.parse(task.SuccessBody);
          return typeof (successBody.ListId) !== undefined && successBody.ListId === listId;
        }
      });
      if (task === undefined) { return; }
      scope.$emit('longRunningTask:remove', [task.Id]);
    }

    scope.saveCopiedList = function () {
      if (!scope.newListName) {
        return;
      }
      if (!validateDuplicateEntry(scope.newListName)) {
        scope.currentListState.Name = scope.newListName;
      } else {
        scope.currentListState.Name = util.generateUniqueCopyOfName(scope.filteredResults, scope.newListName, 'Name');
      }
      scope.currentListState.Id = null;
      scope.currentListState.PullDate = null;
      scope.currentListState.PullStartDate = null;
      scope.currentListState.PullSyncDate = null;
      scope.currentListState.PullToSqlDate = null;
      scope.currentListState.ExportDate = null;
      scope.currentListState.ExportStartDate = null;
      scope.currentListState.UpdatedOn = null;
      scope.currentListState.BWExportDate = null;
      scope.currentListState.UpdatedBy = null;
      scope.currentListState.ListRefId = null;
      listSvc.createList(scope.currentListState).then(function () {
        scope.doSearch();
        scope.close();
      });
    };

    function validateDuplicateEntry(listName) {
      var pluckedNames = _.chain(scope.filteredResults).pluck('Name').value();
      return (_.any(pluckedNames, function (item) {
        return item.toUpperCase() === listName.toUpperCase();
      }));
    }

    scope.copyListPopUp = function (listId, listName) {
      if (listId && listName) {
        var params = { 'IncludeFields': '', 'ExcludeFields': '' };
        params.IncludeFields = 'Id,Name';
        var p1 = listSvc.searchLists(params);
        var p2 = listSvc.getList(listId);
        scope.layout.loading = $q.all([p1, p2]).then(function (results) {
          var lists = results[0];
          scope.currentListState = results[1];
          scope.newListName = util.generateUniqueCopyOfName(lists, listName, 'Name');
          $('#copy-list').modal('show');
          $('#copyListNameInput').focus();
        });
      }
    };

    scope.close = function () {
      $('#copy-list').modal('hide');
    };

    scope.canDisplayListItem = function (locationDescriptors) {
      if (locationDescriptors && locationDescriptors > 0) {
        var userAllowedLocationIds = authSvc.getAllowedUserLocationIds();
        var locationIds = _.pluck(locationDescriptors, 'LocationId');
        var uniqueLocationIds = _.intersection(userAllowedLocationIds, locationIds);
        return uniqueLocationIds.length > 0;
      }
      return true;
    };
    //list.CurrentUIState.countUpdateStatus will have three status Update, Updated & Saved.
    //Update : When ETL Data is updated and list will be in incomplete state and .
    //Updated : Once the Count is updated from List summary with Update Count Link button
    //Saved : Update the count from Link button and saved the list.
    var hasETLDataUpdated = function (etlDate, list) {
      var hasETLUpdated = (list.UpdatedOn ? new Date(list.UpdatedOn) : new Date(list.CreatedOn)) < new Date(etlDate);
      if (hasETLUpdated && list.PullDate === null) {
        list.IsCountDirty = true;
      }
      return (hasETLUpdated && ((list.CurrentUIState.isComplete === true &&
        list.CurrentUIState.countUpdateStatus !== 'Updated' && list.PullDate === null) ||
        (list.CurrentUIState.countUpdateStatus === 'Update')));
    };

    scope.formatList = function (lists) {
      var listsToBeShown = [];
      var emailMediaTypeId = 2;
      if (lists) {
        for (var i = 0; i < lists.length; i = i + 1) {
          if (scope.canDisplayListItem(lists[i].LocationDescriptors)) {
            if (hasETLDataUpdated(etlDate, lists[i])) {
              lists[i].CurrentUIState.isComplete = false;
              lists[i].IsCountsUpdated = true;
            }
            else
            {
              lists[i].IsCountsUpdated = false;
            }
            lists[i].CreatorName = lists[i].CreatorName;
            lists[i].CreatedOn = lists[i].CreatedOn;
            if (!lists[i].UpdatedOn) {
              lists[i].UpdatedOn = lists[i].CreatedOn;
            }
            else {
              lists[i].UpdatedOn = lists[i].UpdatedOn;
            }
            lists[i].IsExported = (lists[i].ExportDate !== null || lists[i].BWExportDate !== null);
            lists[i].IsPulled = (lists[i].PullDate !== null);
            lists[i].IsExportStarted = lists[i].ExportStartDate && !(lists[i].ExportDate || lists[i].BWExportDate);
            lists[i].PullDate = $filter('date')(lists[i].PullDate, 'MM/dd/yyyy');
            lists[i].LocationNames = '';
            lists[i].LocationNamesTooltip = '<ul class="grid-list-tooltip">';
            lists[i].PullStartDate = lists[i].PullStartDate;
            lists[i].IsDisabled = lists[i].PullStartDate && !lists[i].PullDate ? true : false;
            lists[i].disabledClassName = lists[i].PullStartDate && !lists[i].PullDate ? 'disable' : '';
            if ((!lists[i].MarketingChannelId || lists[i].MarketingChannelId === 0) && lists[i].IsPulled === false) {
              lists[i].CurrentUIState.isComplete = false;
            }
            if (lists[i].LocationDescriptors) {
              for (var k = 0; k < lists[i].LocationDescriptors.length; k = k + 1) {

                var userAllowedLocationIds = authSvc.getAllowedUserLocationIds();
                if (lists[i].disabledClassName === '' && userAllowedLocationIds.indexOf(lists[i].LocationDescriptors[k].LocationId) === -1) {
                  lists[i].disabledClassName = 'disable';
                  lists[i].IsDisabled = true;
                  lists[i].IsLocationPermission = true;
                }
                var loc = getMatchingLocation(lists[i].LocationDescriptors[k]);
                if (loc) {
                  if (k > 0) {
                    lists[i].LocationNames += ', ';
                  }
                  lists[i].LocationNames += loc.Name;
                  lists[i].LocationNamesTooltip += '<li>' + loc.Name + '</li>';
                }
              }
              lists[i].LocationNamesTooltip += '</ul>';
            }
            lists[i].IsBWExportAllowed = lists[i].MarketingChannelId === emailMediaTypeId && isSilverpopConfigured;
            listsToBeShown.push(lists[i]);
          }
        }
      }
      return listsToBeShown;
    };

    if (scope.clientKey !== '') {
      scope.homeLink = '/' + scope.clientKey;
      scope.buildNewList = '/' + scope.clientKey + '/' + userContextSvc.getOrgKey() + '/lists/build';
    }

    if (scope.roles.indexOf('ListExporter') !== -1 || scope.roles.indexOf('SysAdmin') !== -1) {
      scope.enableExportIcon = true;
    }
    scope.baseApiUrl = baseApiUrl();

    function getMatchingLocation(locationDescriptor) {
      return _.find(scope.locations, function (location) {
        return location.Id.toString() === locationDescriptor.LocationId.toString();
      });
    }

    scope.editList = function (listId) {
      location.path(scope.buildNewList + '/' + listId);
      state.go('summary', {}, { reload: true });
    };

    scope.$on('longRunningTasks:pullCompleted', function () {
      scope.doSearch();
    });

    scope.goToListbuild = function () {
      scope.isGridShow = false;
      timeout(function () {
        location.path(scope.buildNewList);
        state.go('listName', {}, { reload: true });
      }, 10);
    };

    scope.pivotTableCounts = function (listId) {
      scope.layout.loading = listSvc.getList(listId).then(function (list) {
        pivotTableSvc.getListCountDocument(list);
      });
    };

    scope.pullList = function (listId, listName) {
      var modalDialog;
      modalDialog = $modal.open({
        templateUrl: 'confirmPull.html',
        controller: function ($scope, $modalInstance) {
          $scope.listToPullName = listName;
          $scope.onPullListYes = function () {
            $modalInstance.close('yes');
          };
          $scope.onPullListNo = function () {
            $modalInstance.dismiss('no');
          };
          $scope.close = function () {
            $modalInstance.dismiss('no');
          };
        }
      });

      modalDialog.result.then(function () {
        console.log('pulling list ' + listId);
        var legacyUserId = authSvc.getLegacyUserId();

        scope.layout.loading = listSvc.getList(listId).then(function (list) {
          var timestamp = new Date();
          list.pullStartDate = timestamp.toUTCString();
          var listPullFunction = listSvc.pullList(listId, legacyUserId, listName);
          var updateListFunction = listSvc.updateList(list);

          scope.layout.loading = $q.all([listPullFunction, updateListFunction]).then(function () {
            console.log('pulled list ' + listId);
            scope.doSearch();
          });
        });
      });
    };

    scope.deleteList = function (listId, listName) {
      var modalDialogDelete;
      modalDialogDelete = $modal.open({
        templateUrl: 'confirmDelete.html',
        controller: function ($scope, $modalInstance) {
          $scope.listName = listName;
          $scope.onDeleteListYes = function () {
            $modalInstance.close('yes');
          };
          $scope.onDeleteListNo = function () {
            $modalInstance.dismiss('no');
          };
          $scope.close = function () {
            $modalInstance.dismiss('no');
          };
        }
      });

      modalDialogDelete.result.then(function () {
        scope.layout.loading = listSvc.deleteList(listId).then(function () {
          console.log('deleted list ' + listId);
          scope.doSearch();
        });
      });
    };

    $(function () {
      $('#nav-campaign-manager').addClass('active');
    });

    //clear all facilities
    sessionSvc.clear('selectedLocation.facilities');

    // this will get the locations before going to geography helper
    if (!scope.Locations) {
      locationSvc.listLocations().then(function (data) {
        scope.Locations = data;
        sessionSvc.set('selectLocation.locations', JSON.stringify(scope.Locations));
      });
    }
    // Calling the method after assigning ng-grid options.
    scope.doSearch();
  }]);
})(window.app);
