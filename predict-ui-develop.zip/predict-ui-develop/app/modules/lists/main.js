'use strict';

(function(app) {
	app.controller('listsCtrl', ['$scope',
		function(scope) {
			scope.model = {
				routeParams: {}
			};
			scope.alert = '';
		}
	]);
})(window.app);