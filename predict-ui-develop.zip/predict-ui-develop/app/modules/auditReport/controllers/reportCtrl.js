﻿(function (app) {
	'use strict';

	app.controller('reportCtrl', ['$scope', '$http', 'baseApiUrl', 'userContextSvc', 'alertSvc', function (scope, $http, baseApiUrl, userContextSvc, alertSvc) {

		scope.listExporting = [];
		scope.clientKey = userContextSvc.getClientKey();
		scope.homeLink = '/' + scope.clientKey;

		scope.currentDate = new Date().toLocaleDateString();
    alertSvc.removeAll();

		scope.reportHandler = function () {
			if (!scope.startDate) {
				scope.isStartDateFieldEmpty = true;
			}
			if (!scope.endDate) {
				scope.isEndDateFieldEmpty = true;
			}
			if (scope.startDate && scope.endDate) {
        scope.exportAuditList(new Date(scope.startDate).toLocaleDateString(), new Date(scope.endDate).toLocaleDateString());
			}
		};
		var logError = function (error) {
			console.log(error.data.message);
			console.log(error);
		};
		scope.onFieldChange = function () {
      alertSvc.removeAll();
			if (scope.startDate) {
				scope.isStartDateFieldEmpty = false;
			}
			if (scope.endDate) {
				scope.isEndDateFieldEmpty = false;
			}
		};

		scope.exportAuditList = function (startDate, endDate) {
			scope.listExporting.push($http({
				method: 'post',
				url: baseApiUrl() + 'auditReport',
				data: { 'fromDate': startDate, 'toDate': endDate }
			}).then(function (res) {
            if (res.data.results.auditLog !== 'NO DATA')
            {
              var mime = res.headers('Content-Type');
              var file = new Blob([res.data.results.auditLog], { type: mime });
              saveAs(file, 'AuditReport' + '.csv');
            }
            else
            {
              alertSvc.add({ Type: 'Error', Title: 'No Data Found', Source: 'report', Message: 'Audit logs are not available for the given date range ' });
            }
          }, function (error) {
				alertSvc.add({ Type: 'Error', Title: 'No Data Found', Source: 'report', Message: error.data.message });
				logError(error);
			}));
		};
	}]);
})(window.app);