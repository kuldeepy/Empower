﻿(function (app) {
	'use strict';

	var modulePath = 'modules/auditReport',
		ctrlRoot = app.root + modulePath + '/controllers/';

	app.controller('auditReportCtrl', ['$scope', function (scope) {
		scope.modulePath = modulePath;
		scope.model = {
			routeParams: {}
		};
	}]);

	$.when(
		$.getScript(ctrlRoot + 'reportCtrl.js'))
		.done(function () {
			app.publish('moduleReady', modulePath);
		});

})(window.app);