(function (app) {
  'use strict';

  var notifications = [];

  app.factory('notificationSvc', function () {
    var notificationManager = {
      get: function () {
        return notifications;
      },
      add: function (value) {
        notifications.push(value);
      },
      remove: function (item) {
        notifications.splice(notifications.indexOf(item), 1);
      }
    };
    return {
      get: notificationManager.get,
      add: notificationManager.add,
      remove: notificationManager.remove
    };
  });

})(window.app);
