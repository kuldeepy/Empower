(function (app) {
  'use strict';

  app.factory('baseApiUrl', ['userContextSvc', function (userContextSvc) {
    return function (isClientScoped, clientKey) {
      if (isClientScoped) {
        if (clientKey) {
          return app.api.root + 'clients/' + clientKey + '/';
        }
        return app.api.root + 'clients/' +
          userContextSvc.getApiClientKey() + '/';
      }

      return app.api.root + 'clients/' +
        userContextSvc.getApiClientKey() +
        '/orgs/' + userContextSvc.getOrgKey() + '/';
    };
  }]);

})(window.app);
