'use strict';

(function(app) {

	//app.config(['$httpProvider', function ($httpProvider) {
	//	$httpProvider.defaults.useXDomain = true;
	//	delete $httpProvider.defaults.headers.common['X-Requested-With'];
	//}]);

	app.factory('campaignSvc', ['$http', 'envConfig',
		function(http, envConfig) {

			http.defaults.headers.post['Content-Type'] = 'application/json';

			var listCampaigns = function() {
				return http({
					method: 'GET',
					url: envConfig.baseApiUri + 'REST/Campaign'
				}).then(
					function(response) {
						return response.data.Campaigns;
					},
					function(error) {
						console.log(error);
					});
			},

				getCampaign = function(campaignId) {
					return http({
						method: 'GET',
						url: envConfig.baseApiUri + 'REST/Campaign/' + campaignId
					}).then(
						function(response) {
							return response.data.Campaign;
						},
						function(error) {
							console.log(error);
						});
				};

			return {
				listCampaigns: listCampaigns,
				getCampaign: getCampaign
			};
		}
	]);
})(window.app);