(function (app) {
  'use strict';

  var calculation;

  app.subscribe('calculation', function (data) {
    calculation = _.extend({}, data);
  });

  app.factory('mostRecentCalculation', function () {
    return function () {
      return calculation;
    };
  });
  
})(window.app);
