(function (app) {
  'use strict';

  var longRunningTasks = [];

  app.factory('longTaskSvc', ['$rootScope', '$http', 'baseApiUrl', 'notificationSvc', 'userContextSvc',
  function (rootScope, http, baseApiUrl, notificationSvc, userContextSvc) {

    var logError = function (error) {
      if (error) {
        console.log(error);
        if (error.data) {
          console.log(error.data.message);
        }
      }
    };

    var notificationBehaviorEnum = {
      /*jshint bitwise:false */
      AutoDeleteAfterLinkClick: 1,
      ShowWaiting: 1 << 1,
      Broadcast: 1 << 2,
      LinkRestricted: 1 << 3,
      AddNewLrt: 1 << 4,
      DeleteLrt: 1 << 5
    };
    function parseNotifcationMetadata(notificationMetadata) {
      var metadata = [];
      _.forEach(notificationMetadata, function (data) {
        metadata.push(JSON.parse(data));
      });
      return metadata;
    }
    var interval = setInterval(updateLongRunningTasks, 10000);
    clearInterval(interval);

    function updateLongRunningTasks(broadcastUpdate) {
      http({
        headers: {
          'Pragma': 'no-cache',
          'Cache-Control': 'no-cache'
        },
        method: 'GET',
        url: app.api.root + 'longRunningTasks'
      }).then(
      function (response) {
        longRunningTasks = response.data.results.Tasks;
        var lrts = _.where(notificationSvc.get(), { 'type': 'LongRunningTask' });
        var lrtNotifications = _.map(longRunningTasks, function (note) {
          return {
            type: 'LongRunningTask',
            task: {
              id: note.Id,
              status: note.Status,
              description: note.Description,
              percentComplete: note.PercentComplete,
              isError: note.IsError,
              NotificationBehavior: note.NotificationBehaviorOutput,
              NotificationMetadata: parseNotifcationMetadata(note.NotificationMetadata),
              NotificationLink: note.NotificationLink
            }
          };
        });
        //Needed to update UI when a list pull completes
        handleCompletedListPulls(lrtNotifications);

        _.forEach(lrts, function (lrtNote) {
          notificationSvc.remove(lrtNote);
        });
        _.forEach(lrtNotifications, function (lrTask) {
          notificationSvc.add(lrTask);
        });
        if (broadcastUpdate) {
          rootScope.$broadcast('longRunningTasks:updated', longRunningTasks);
        }
      },
      function (error) {
        logError(error);
      }
      );
    }

    function handleCompletedListPulls(newLrtNotes) {
      var oldListPullNotes = _.where(notificationSvc.get(), function (oldLrt) {
        if (oldLrt.task.NotificationMetadata) {
          return oldLrt.task.description.indexOf('List Pull') >= 0 && oldLrt.task.percentComplete < 100;
        }
      });
      if (_.some(oldListPullNotes, function (oldPullNote) {
        var newPullNote = _.find(newLrtNotes, function (note) {
          return note.task && note.task.id === oldPullNote.task.id;
        });
        return typeof (newPullNote) !== undefined && typeof (newPullNote.task) !== undefined && newPullNote.task.percentComplete === 100;
      })) {
        rootScope.$broadcast('longRunningTasks:pullCompleted', longRunningTasks);
      }
    }

    var longTaskManager = {
      get: function () {
        return longRunningTasks;
      },
      add: function (value) {
        longRunningTasks.push(value);
        notificationSvc.add({
          type: 'LongRunningTask',
          task: {
            status: value.Status,
            description: value.Description,
            percentComplete: value.PercentComplete,
            isError: value.IsError,
            taskType: value.TaskType
          }
        });
        rootScope.$broadcast('longRunningTasks:updated', longRunningTasks);
      },
      remove: function (task) {
        var lrt = _.find(longRunningTasks, function (localTask) {
          return task.id === localTask.Id;
        });
        longRunningTasks.splice(longRunningTasks.indexOf(lrt), 1);
        http({
          method: 'DELETE',
          url: app.api.root + 'longRunningTasks/' + task.id
        });
      },
      update: function (broadcastUpdate) {
        updateLongRunningTasks(broadcastUpdate);
      }
    };

    var createNewLrt = function (description) {
      longTaskManager.add({
        Description: description,
        Status: 'Request Received...',
        PercentComplete: 1
      });
    };

    var generateDocument = function (documentType, description, res) {
      var mime = res.headers('Content-Type');
      var file = new Blob([res.data], {
        type: mime
      });
      var fileName = '';
      if (documentType === 'Text') {
        fileName = (res.headers('x-filename') || description) + '.txt';
      }
      else {
        fileName = res.headers('x-filename');
      }
      saveAs(file, fileName);
    };

    function addFailedNotification(description) {
      longTaskManager.add({
        Description: description,
        Status: 'Failed.',
        PercentComplete: 100,
        IsError: true
      });
    }

    var processTask = function (notification, linkIndex) {
      /*jshint bitwise:false */
      var task = notification.task;
      var notificationBehavior = task.NotificationBehavior;
      var notificationLink = task.NotificationLink[linkIndex];
      if (notificationLink !== '' || notificationLink !== null) {
        // Only when PivotTable LRT NotificationLink do not have proper ClientKey and OrgKey,
        // We will apply current context ClientKey and OrgKey
        if (notificationLink.indexOf('/ClientKey/') >= 0) {
          var currentClientKey = userContextSvc.getClientKey();
          var currentOrgKey = userContextSvc.getOrgKey();
          notificationLink = notificationLink.replace(/ClientKey/g, currentClientKey);
          notificationLink = notificationLink.replace(/OrgKey/g, currentOrgKey);
        }
        var notificationMetadata = task.NotificationMetadata[linkIndex];
        return http({
          method: notificationMetadata.RequestType,
          url: app.api.root + notificationLink,
          data: notificationMetadata.RequestBody ? notificationMetadata.RequestBody : {},
          responseType: (notificationMetadata.ResponseType) ? 'arraybuffer' : '',
          timeout: notificationMetadata.ResponseTimeout ? notificationMetadata.ResponseTimeout : app.timeout
        }).then(
        function (res) {
          if ((notificationBehavior & notificationBehaviorEnum.AddNewLrt) === notificationBehaviorEnum.AddNewLrt) {
            createNewLrt(notificationMetadata.Description);
          }
          if ((notificationBehavior & notificationBehaviorEnum.Broadcast) === notificationBehaviorEnum.Broadcast) {
            rootScope.$broadcast(notificationMetadata.Broadcast);
          }
          if ((notificationBehavior & notificationBehaviorEnum.DeleteLrt) === notificationBehaviorEnum.DeleteLrt) {
            longTaskManager.remove(notification.task);
          }
          if ((notificationBehavior & notificationBehaviorEnum.AutoDeleteAfterLinkClick) === notificationBehaviorEnum.AutoDeleteAfterLinkClick) {
            notificationSvc.remove(notification);
          }
          if (notificationMetadata.ResponseType) {
            generateDocument(notificationMetadata.DocumentType, task.description, res);
          }
        },
        function () {
          if ((notificationBehavior & notificationBehaviorEnum.AddNewLrt) === notificationBehaviorEnum.AddNewLrt) {
            addFailedNotification(notificationMetadata.Description);
          }
        }
        );
      }
    };

    return {
      get: longTaskManager.get,
      add: longTaskManager.add,
      remove: longTaskManager.remove,
      update: longTaskManager.update,
      processTask: processTask
    };
  }
  ]);
})(window.app);
