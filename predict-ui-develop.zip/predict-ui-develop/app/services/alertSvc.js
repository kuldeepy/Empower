(function (app) {
  'use strict';

  var errorList = [
    { Code: 1000, Type: 'Fatal', Title: 'Internal Server Error', Message: 'Error occured while processing your request' },
    { Code: 1001, Type: 'Error', Title: 'ErrorTitle', Message: 'Error Message-NonBlocker' },
    { Code: 403, Type: 'Forbidden', Title: 'Access Restricted', Message: 'You are not allowed to access the requested information.  Please contact your System Administrator to request access.' }
  ];
  var alertContainer = [];

  app.factory('alertSvc', function () {
    var alertCarrier = {
      get: function () {
        return alertContainer;
      },
      add: function (value) {
        if (value.Code) {
          var alertItem =_.cloneDeep(_.where(errorList, { Code: value.Code })[0]);
          if (value.Message) {
            alertItem.Message = value.Message;
          }
          if (value.Title) {
            alertItem.Title = value.Title;
          }
          if (value.Type) {
            alertItem.Type = value.Type;
          }
          if (value.Source) {
            alertItem.Source = value.Source;
          }
          if (!_.any(alertContainer, {Message: alertItem.Message, Source: alertItem.Source, Type: alertItem.Type})) {
            alertContainer.push(alertItem);
          }
        }
        else {
          if (!_.any(alertContainer, { Message: value.Message, Source: value.Source, Type: value.Type, IncompleteSteps:value.IncompleteSteps })) {
            alertContainer.push(value);
          }
        }
      },
      removeAll: function () {
        alertContainer.splice(0, alertContainer.length);
      },
      remove: function (item) {
        alertContainer.splice(alertContainer.indexOf(item), 1);
      }
    };
    return {
      get: alertCarrier.get,
      add: alertCarrier.add,
      removeAll: alertCarrier.removeAll,
      remove: alertCarrier.remove
    };
  });

})(window.app);
