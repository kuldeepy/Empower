﻿(function (app) {
	'use strict';

	app.factory('accountRecoverySvc', ['$http', '$q', 'userContextSvc',
	function (http, q, userContextSvc) {
		var baseApiUrl = app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/';
		http.defaults.headers.post['Content-Type'] = 'application/json';

		var changePassword = function (message, id) {
			var deferred = q.defer();
			http({
				method: 'PUT',
				url: baseApiUrl + 'accountRecovery/' + id.toLowerCase(),
				data: JSON.stringify(message)
			}).success(function (data) {
				deferred.resolve(data);
			}).error(function (data) {
				deferred.reject(data);
			});
			return deferred.promise;
		};

		var verifyConfirmationCode = function (message) {
			var deferred = q.defer();
			http({
				method: 'POST',
				url: baseApiUrl + 'accountRecovery/verifyCode',
				data: JSON.stringify(message)
			}).success(function (data) {
				deferred.resolve(data);
			}).error(function (data) {
				deferred.reject(data);
			});
			return deferred.promise;
		};

		return {
			changePassword: changePassword,
			verifyConfirmationCode: verifyConfirmationCode
		};

	}]);

}(window.app));