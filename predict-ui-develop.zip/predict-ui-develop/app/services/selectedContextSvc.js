'use strict';
(function (app) {
  app.value('selectedContext', {
    client: '',
    organization: ''
  });
})(window.app);
