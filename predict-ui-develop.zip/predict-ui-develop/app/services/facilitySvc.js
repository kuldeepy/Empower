'use strict';
(function (app) {

  app.factory('facilitySvc', ['$http', 'baseApiUrl',
  function (http, baseApiUrl) {
			var logError  = function(error){
        console.log(error);
        if (error.data) {
          console.log(error.data.message);
        }
			};

      var getFacilities = function (message) {
        return http({
          method: 'GET',
          url: baseApiUrl() + 'locations/' + message.locationids + '/facilities',
          data: JSON.stringify(message),
          cache: true
        })
        .then(
          function (response) {
            return response.data.results;
          },
          function (error) {
            logError(error);
          }
        );
			};

			return {
        getFacilities : getFacilities
			};
		}
	]);
})(window.app);

