'use strict';
(function(app) {
	app.factory('distributionSvc', ['$http', 'baseApiUrl', 'alertSvc', '_',
		function(http, baseApiUrl, alertSvc, _) {
      var logError = function (error) {
        console.log(error.data.message);
        console.log(error);
      };

      var personTypeMap = [{k:5, v:'Patients'}, {k:10, v:'New Movers'}, {k:15, v:'Prospects'},{k:20, v:'Qualified Prospects'},{k:25, v:'Family Member'}, {k:30, v:'Orphaned Record'}];
      var scoreMap = [{k:0, v:'behavior'},{k:1, v:'best'},{k:2, v:'better'},{k:3, v:'good'},{k:4,v:'fair'},{k:5, v:'poor'}];

      var createDefaultDistribution = function (list) {
        var rv = {AvailableCount: 0, DesiredCount:0};
        rv.Segments = _.map(list.Segments, function(segment) {
          return {
            Name: segment.Name,
            PersonTypeDistributions: _.map(personTypeMap, function (personType) {
              return {
                AvailableCount: 0,
                DesiredCount: 0,
                PersonTypeId: personType.k,
                PersonTypeName: personType.v,
                ScoreDistributions: _.map(scoreMap, function (score) {
                  return {
                    Score: score.k,
                    ScoreName: score.v,
                    AvailableCount: 0,
                    DesiredCount: 0
                  };
                })
              };
            })
          };
        });
        return rv;
      };

      var createDistribution = function(list) {
        if (!list.Distribution) {
          list.Distribution = createDefaultDistribution(list);
        }
				var createDistributionMessage = {
					List: list
				};
				return http({
					method: 'POST',
					url: baseApiUrl() + 'distribution',
					data: createDistributionMessage
				}).then(
					function(response) {
						return response.data.results.Distribution;
					},
					function(error) {
						alertSvc.add({
							Code: 1000,
							Type: 'Error',
							Source: 'distributionSvc'
						});
						logError(error);
					});
			};
			return {
				createDistribution: createDistribution
			};
		}
	]);
})(window.app);