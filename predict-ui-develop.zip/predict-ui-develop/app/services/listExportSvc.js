'use strict';

(function (app) {

  app.factory('listExportSvc', ['$http', 'baseApiUrl', 'longTaskSvc',
  function (http, baseApiUrl, longTaskSvc) {

    var createListExportDocument = function (list, isTextExport) {
      if (list) {
        return http({
          method: 'post',
          url: baseApiUrl() + 'listexport',
          data: {
            Id: list.Id,
            IsTextExport: isTextExport
          }
        }).then(
          function () {
            longTaskSvc.add({
              Description: getDescription(list),
              Status: 'Request Received...',
              PercentComplete: 1
            });
          },
          function () {
            addFailedExportNotification(list);
          });
      } else {
        addFailedExportNotification(list);
      }
    };

    function addFailedExportNotification(list) {
      longTaskSvc.add({
        Description: getDescription(list ? list : {}),
        TaskType: 'ListExport',
        Status: 'Failed.',
        PercentComplete: 100,
        IsError: true
      });
    }

    function getDescription(list) {
      if (typeof (list) === undefined || typeof (list) === null || typeof (list.Name) === 'undefined' || list.Name === null || list.Name === '') {
        return 'List Export - Unnamed List';
      }
      return 'List Export - ' + list.Name;
    }

    var downloadExportDocument = function (taskId, description) {
      return http({
        headers: {
          'Pragma': 'no-cache',
          'Cache-Control': 'no-cache'
        },
        method: 'get',
        url: baseApiUrl() + 'listexport/' + taskId,
        responseType: 'arraybuffer',
        timeout: 2 * 60 * 1000 /* 2 minutes */
      }).then(function (res) {
        var mime = res.headers('Content-Type');
        var file = new Blob([res.data], {
          type: mime
        });
        var fileName = (res.headers('x-filename') || description) + '.txt';
        saveAs(file, fileName);
        return true;
      });
    };

    return {
      createListExportDocument: createListExportDocument,
      downloadExportDocument: downloadExportDocument
    };

  }
  ]);
})(window.app);