'use strict';

(function (app) {

  app.factory('pivotTableSvc', ['$http', 'baseApiUrl', 'longTaskSvc',
  function (http, baseApiUrl, longTaskSvc) {

    var getListCountDocument = function (list) {
      return http({
        method: 'post',
        url: baseApiUrl() + 'listcountdocument',
        data: { List: list }
      }).then(
        function () {
          longTaskSvc.add({
            Description: getDescription(list),
            Status: 'Request Received...',
            PercentComplete: 1
          });
        },
        function () {
          longTaskSvc.add({
            Description: getDescription(list),
            Status: 'Failed.',
            PercentComplete: 100,
            IsError: true
          });
        });
    };

    function getDescription(list) {
      if (typeof (list.Name) === 'undefined' || list.Name === null || list.Name === '') {
        return 'Pivot Table - Unnamed List';
      }
      return 'Pivot Table - ' + list.Name;
    }

    var downloadExcelDocument = function (taskId) {
      return http({
        headers: {
          'Pragma': 'no-cache',
          'Cache-Control': 'no-cache'
        },
        method: 'get',
        url: baseApiUrl() + 'pivotTable/' + taskId,
        responseType: 'arraybuffer',
        timeout: 5 * 60 * 1000 /* 5 minutes */
      }).then(function (res) {
        var mime = res.headers('Content-Type');
        var file = new Blob([res.data], {
          type: mime
        });
        //if (typeof(listName) === 'undefined') {
        //  listName = listName + '_FilterCount.xlsx';
        //}
        var fileName = /*listName ||*/ res.headers('x-filename');
        saveAs(file, fileName);
        return true;
      });
    };

    return {
      getListCountDocument: getListCountDocument,
      downloadExcelDocument: downloadExcelDocument
    };

  }
  ]);
})(window.app);