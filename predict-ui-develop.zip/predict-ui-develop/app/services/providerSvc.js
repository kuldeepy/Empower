'use strict';

(function (app) {

  app.factory('providerSvc', ['$http', 'userContextSvc', '$q',
  function (http, userContextSvc, q) {
    var providersChunk = 20;
    var specialtiesChunk = 20;

    var logError = function (error) {
      console.log(error.data.message);
      console.log(error);
    };

    var getProvidersById = function (message) {
      var url = app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/providers/';
      var providerArrays = [];
      var i;
      for (i = 0; i < message.Ids.length; i += providersChunk) {
        providerArrays.push(message.Ids.slice(i, i + providersChunk));
      }
      var promiseArray = providerArrays.map(function (ids) {
        return http({
          method: 'GET',
          url: url + ids.join(','),
          cache: true
        });
      });

      return q.all(promiseArray).then(
        function (responses) {
          var retVal = [];
          for (var i = 0; i < responses.length; i = i + 1) {
            retVal = retVal.concat(responses[i].data.results.Providers);
          }
          return retVal;
        },
        function (error) {
          logError(error);
        }
      );
    };

    var findProviders = function (message) {
      var url = app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/providers' + '?ProviderInfo=' + JSON.stringify(message.ProviderInfo);
      var specialtyIdArrays = [];
      var i;
      for (i = 0; i < message.SpecialtyIds.length; i += specialtiesChunk) {
        specialtyIdArrays.push(message.SpecialtyIds.slice(i, i + specialtiesChunk));
      }
      var providerIds = specialtyIdArrays.join(',');
      if (providerIds !== '') {
        url = url + '&SpecialtyIds=' + providerIds;
      }
      return http({
        cache: true,
        method: 'GET',
        url: url
      }).then(function (responses) {
        var retVal = [];
        for (var i = 0; i < responses.data.results.Providers.length; i = i + 1) {
          if (responses.data.results.Providers[i]) {
            retVal = retVal.concat(responses.data.results.Providers[i]);
          }
        }
        return retVal;
      },
      function (error) {
        logError(error);
      });
    };

    var getAllProviderSpecialties = function () {
      return http({
        method: 'GET',
        url: app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/providerSpecialties',
        cache: true
      }).then(
      function (response) {
        return response.data.results.ProviderSpecialties;
      },
      function (error) {
        logError(error);
      });
    };

    return {
      getProvidersById: getProvidersById,
      findProviders: findProviders,
      getAllProviderSpecialties: getAllProviderSpecialties
    };
  }
  ]);
})(window.app);