(function (app) {
  'use strict';

  app.factory('errorInterceptor', ['$rootScope', '$q', 'alertSvc', 'userContextSvc', '$location', function ($rootScope, $q, alertSvc, userContextSvc, location) {
    return {
      responseError: function (rejection) {
        if (rejection.status === 401) {
          location.path(userContextSvc.getUserLoginUrl());
        }
        else if (rejection.status === 403) {
          alertSvc.add({ Code: rejection.status, Source: 'errorInterceptor' });
        }
        return $q.reject(rejection);
      }
    };
  }]);

  app.ng.config(function ($httpProvider) {
    $httpProvider.interceptors.push('errorInterceptor');
  });

}(window.app));