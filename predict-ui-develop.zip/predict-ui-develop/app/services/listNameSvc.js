﻿(function (app) {
  'use strict';

  app.factory('listNameSvc', ['listSvc', 'util', '$q',
  function (listSvc, util, $q) {
    var listName;
    function rejectIfNameInUse() {
      var params = { 'IncludeFields': '', 'ExcludeFields': '' };
      params.IncludeFields = 'Id,Name';
      return listSvc.searchLists(params).then(function (data) {
        var retVal = util.isPropertyValueInCollection(data, listName, 'Name');
        if (!retVal) {
          return;
        }
        return $q.reject('Name in use');
      });
    }

    var checkListNameExist = function (currentlistState, currentlistName) {
      listName = currentlistName;
      var deffered = new $q.defer();
      if (!currentlistState.Name && listName) {
        return rejectIfNameInUse().then(function () {
          deffered.resolve();
        });
      }
      else {
        if (currentlistState.Name.toUpperCase() === listName.toUpperCase()) {
          deffered.resolve();
        } else {
          return rejectIfNameInUse().then(function () {
            deffered.resolve();
          });
        }
      }
      return deffered.promise;
    };

    return {
      checkListNameExist: checkListNameExist
    };
  }
  ]);

})(window.app);
