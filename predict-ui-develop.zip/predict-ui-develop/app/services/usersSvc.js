﻿(function (app) {
  'use strict';

  app.factory('usersSvc', ['$http', '$q', 'userContextSvc',
  function (http, q, userContextSvc) {
    var baseApiUrl = app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/';
    http.defaults.headers.post['Content-Type'] = 'application/json';

    var changeUserPassword = function (newPassword, id) {
      var deferred = q.defer();
      http({
        method: 'PUT',
        url: baseApiUrl + 'users/' + id,
        data: { 'newPassword': newPassword }
      }).success(function (data) {
        deferred.resolve(data);
      }).error(function (data, status) {
        if (status === 0) {
          if (data) {
            deferred.resolve(data);
          } else {
            deferred.reject(data);
          }
        }
      });
      return deferred.promise;
    };

    return {
      changeUserPassword: changeUserPassword
    };

  }]);

}(window.app));