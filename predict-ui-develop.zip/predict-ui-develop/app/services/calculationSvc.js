'use strict';

(function(app) {
  app.factory('calculationSvc', ['$http', '$q', 'baseApiUrl', '_', '$timeout', 'alertSvc',
    function(http, $q, baseApiUrl, _, $timeout, alertSvc) {
      var recoverError = function(err) {
        alertSvc.add({
          Title: 'Internal Server Error',
          Message: 'Calculation failed',
          Type: 'Error',
          Source: 'quickcount'
        });
        return $q.reject(err);
      };

      var transformCalculation = function(result) {

        var PATIENT_GROUP_ID = 'C',
          FAMILY_MEMBER_GROUP_ID = 'F',
          QUALIFIED_PROSPECT_GROUP_ID = 'Q',
          PROSPECT_COUNT_GROUP_ID = 'P',
          NEW_MOVERS_GROUP_ID = 'N';

        var getIndividualCount = function(id) {
          var res = _.find(result.individual, {
            personType: id
          });
          return res === undefined ? 0 : res.count;
        };

        var getHouseholdCount = function(id) {
          var res = _.find(result.household, {
            personType: id
          });
          return res === undefined ? 0 : res.count;
        };

        return {
          patientCountForIndividual: getIndividualCount(PATIENT_GROUP_ID),
          familyMemberCountForIndividual: getIndividualCount(FAMILY_MEMBER_GROUP_ID),
          qualifiedProspectCountForIndividual: getIndividualCount(QUALIFIED_PROSPECT_GROUP_ID),
          prospectCountForIndividual: getIndividualCount(PROSPECT_COUNT_GROUP_ID),
          newMoversCountForIndividual: getIndividualCount(NEW_MOVERS_GROUP_ID),
          totalCountForIndividual: _.chain(result.individual).pluck('count').reduce(function(a, b) {
            return a + b;
          }, 0).value(),
          patientCountForHousehold: getHouseholdCount(PATIENT_GROUP_ID),
          familyMemberCountForHousehold: getHouseholdCount(FAMILY_MEMBER_GROUP_ID),
          qualifiedProspectCountForHousehold: getHouseholdCount(QUALIFIED_PROSPECT_GROUP_ID),
          prospectCountForHousehold: getHouseholdCount(PROSPECT_COUNT_GROUP_ID),
          newMoversCountForHousehold: getHouseholdCount(NEW_MOVERS_GROUP_ID),
          totalCountForHousehold: _.chain(result.household).pluck('count').reduce(function(a, b) {
            return a + b;
          }, 0).value()
        };
      };


      var calculate = function(list) {

        return http({
          method: 'POST',
          url: baseApiUrl() + 'calculation',
          data: {
            List: list
          },
        }).then(
          function(response) {
            console.log('calculate response', response);

            var results = response.data.results;

            var calculation = {};
            calculation.seedListCount = results.seedListCount || 0;
            calculation.segments = [];

            _.map(results.segments, function(segment) {
              calculation.segments.push(
                _.extend(transformCalculation(segment), {
                  segmentName: segment.name
                }));
            });

            if (_.find(calculation.segments, {
              segmentName: 'Available Count'
            }) === undefined) {
              calculation.segments.push(calculateAvailableCount(calculation.segments));
            }

            function calculateAvailableCount(segments) {
              var available = {
                segmentName: 'Available Count'
              };
              _.reduce(segments, function(total, segment) {
                _.map(Object.keys(segment), function(key) {
                  if (key !== 'segmentName') {
                    if (typeof(total[key]) === 'undefined') {
                      total[key] = 0;
                    }
                    total[key] += segment[key];
                  }
                });
                return total;
              }, available);
              return available;
            }
            return calculation;
          },
          recoverError);
      };

      return {
        calculate: calculate
      };

    }
  ]);
})(window.app);