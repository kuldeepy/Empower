'use strict';

(function (app) {

  app.factory('tabAndStepDefinitions', ['listStateSvc', 'listSvc', function (listStateSvc, listSvc) {
    //Tab and Step Definitions

    return function () {

      function getStep(name) {
        return _.chain(definitions.steps)
        .map(function (tab) {
          return _.find(tab, { name: name });
        })
        .filter(function (x) {
          return x !== undefined && x !== null;
        })
        .first()
        .value();

      }

      var definitions = {
        tabs: [
          {
            name: 'listName',
            url: function () {
              return 'listName';
            },
            title: 'Define List',
            tabIndex: 1,
            completed: function () {
              return getStep('listName').completed() && getStep('recipe').completed();
            },
            available: function () {
              return true;
            }
          },
          {
            name: 'selectLocation',
            url: function () {
              return (getStep('geographiesSummary').completed()) ? 'geographiesSummary' : 'selectLocation';
            },
            title: 'Define Geographies',
            tabIndex: 2,
            completed: function () {
              return getStep('geographiesSummary').completed();
            },
            available: function () {
              return getStep('recipe').completed();
            }
          },
          {
            name: 'pastLists',
            url: function () {
              return 'pastLists';
            },
            title: 'Manage Lists',
            tabIndex: 3,
            completed: function () {
              return getStep('pastLists').completed() && getStep('manageSeedList').completed();
            },
            available: function () {
              return getStep('geographiesSummary').completed() || listStateSvc.get().CurrentUIState.hasVisited.geographiesSummary;
            }
          },
          {
            name: 'criteria',
            url: function () {
              return 'criteria';
            },
            title: 'Refine Criteria',
            tabIndex: 4,
            completed: function () {
              return getStep('criteria').completed();
            },
            available: function () {
              return getStep('pastLists').completed() && getStep('manageSeedList').completed();
            }
          },
          {
            name: 'manageSegments',
            url: function () {
              return 'manageSegments';
            },
            title: 'Manage Segments',
            tabIndex: 5,
            completed: function () {
              return getStep('manageSegments').completed();
            },
            available: function () {
              return getStep('criteria').completed();
            }
          },
          {
            name: 'prioritizeCountType',
            url: function () {
              return 'prioritizeCountType';
            },
            title: 'Targeting',
            tabIndex: 6,
            completed: function () {
              return getStep('prioritizeCountType').completed() && getStep('managePrioritize').completed();
            },
            available: function () {
              return getStep('manageSegments').completed();
            }
          },
          {
            name: 'summary',
            url: function () {
              return 'summary';
            },
            title: 'Summary',
            tabIndex: 7,
            completed: function () {
              return getStep('managePrioritize').completed();
            },
            available: function () {
              return true;
            }
          }
        ],
        steps: [
          //Define List
          [
            {
              name: 'listName',
              letter: 'a',
              title: 'List Name & Channel',
              selectionCss: 'active',
              completed: function () {
                if (listStateSvc.get().MarketingChannelId && listStateSvc.get().MarketingChannelId !== 0 && listSvc.currentListName.get()) {
                  return true;
                }
              },
              available: function () {
                return true;
              }
            },
            {
              name: 'recipe',
              letter: 'b',
              title: 'Select Ideal Target',
              selectionCss: 'inactive',
              completed: function () {
                if (listStateSvc.get().RecipeId) {
                  return true;
                }
              },
              available: function () {
                return getStep('listName').completed();
              }
            }
          ],

          //Define Geographies Tab
          [
            {
              name: 'selectLocation',
              letter: 'a',
              title: 'Base Location',
              selectionCss: 'active',
              completed: function () {
                if (typeof listStateSvc.get().LocationDescriptors !== 'undefined' && listStateSvc.get().LocationDescriptors.length !== 0) {
                  return listStateSvc.get().LocationDescriptors[listStateSvc.get().CurrentUIState.CurrentLocationIndex].LocationId;
                }
              },
              available: function () {
                return getStep('recipe').completed();
              }
            },
            {
              name: 'serviceAreaRadius',
              letter: 'b',
              title: 'Target Areas',
              selectionCss: 'inactive',
              completed: function () {
                if (typeof listStateSvc.get().LocationDescriptors !== 'undefined' && listStateSvc.get().LocationDescriptors.length !== 0) {
                  if (listStateSvc.get().LocationDescriptors[listStateSvc.get().CurrentUIState.CurrentLocationIndex].Type === 'Radius') {
                    return listStateSvc.get().CurrentUIState.hasVisited.radius && listStateSvc.get().CurrentUIState.radiusValid;
                  } else {
                    return listStateSvc.get().CurrentUIState.hasVisited.serviceArea && listStateSvc.get().CurrentUIState.zipsSelectedValid;
                  }
                }
              },
              available: function () {
                if (typeof listStateSvc.get().LocationDescriptors !== 'undefined' && listStateSvc.get().LocationDescriptors.length !== 0) {
                  if (listStateSvc.get().LocationDescriptors[listStateSvc.get().CurrentUIState.CurrentLocationIndex].Type === 'Radius') {
                    return getStep('selectLocation').completed() && listStateSvc.get().CurrentUIState.radiusValid;
                  } else {
                    return getStep('selectLocation').completed() && listStateSvc.get().CurrentUIState.zipsSelectedValid;
                  }
                }
              }
            },
            {
              name: 'geographiesSummary',
              letter: 'c',
              title: 'Summary',
              selectionCss: 'inactive',
              completed: function () {
                if (typeof listStateSvc.get().LocationDescriptors !== 'undefined' && listStateSvc.get().LocationDescriptors.length !== 0) {
                  if (listStateSvc.get().LocationDescriptors[listStateSvc.get().CurrentUIState.CurrentLocationIndex].Type === 'Radius') {
                    return listStateSvc.get().CurrentUIState.hasVisited.geographiesSummary && listStateSvc.get().CurrentUIState.radiusValid;
                  } else {
                    return listStateSvc.get().CurrentUIState.hasVisited.geographiesSummary && listStateSvc.get().CurrentUIState.zipsSelectedValid;
                  }
                }
              },
              available: function () {
                if (typeof listStateSvc.get().LocationDescriptors !== 'undefined' && listStateSvc.get().LocationDescriptors.length !== 0) {
                  if (listStateSvc.get().LocationDescriptors[listStateSvc.get().CurrentUIState.CurrentLocationIndex].Type === 'Radius') {
                    return getStep('serviceAreaRadius').completed() && listStateSvc.get().CurrentUIState.radiusValid;
                  } else {
                    return getStep('serviceAreaRadius').completed() && listStateSvc.get().CurrentUIState.zipsSelectedValid;
                  }
                }
              }
            }
          ],
          //Manage Previous Lists
          [
            {
              name: 'pastLists',
              letter: 'a',
              title: 'Past Lists',
              selectionCss: 'active',
              completed: function () {
                return listStateSvc.get().CurrentUIState.hasVisited.pastLists;

              },
              available: function () {
                return getStep('geographiesSummary').completed();
              }
            },
            {
              name: 'manageSeedList',
              letter: 'b',
              title: 'Seed Lists',
              selectionCss: 'active',
              completed: function () {
                return listStateSvc.get().CurrentUIState.hasVisited.manageSeedList;
              },
              available: function () {
                return getStep('pastLists').completed();
              }
            }
          ],
          [
            {
              name: 'criteria',
              letter: '',
              title: 'Refine Criteria',
              selectionCss: 'active',
              completed: function () {
                return listStateSvc.get().CurrentUIState.hasVisited.criteria;
              },
              available: function () {
                return getStep('manageSeedList').completed();
              }
            }
          ],
          //Define Manage Segments Tab
          [
            {
              name: 'manageSegments',
              letter: '',
              title: 'Manage Segments',
              selectionCss: 'active',
              completed: function () {
                var hasDuplicateSegmentNames = false;
                if (listStateSvc.get().Segments && listStateSvc.get().Segments.length > 1) {
                  var segmentNames = _.pluck(listStateSvc.get().Segments, 'Name');
                  if (segmentNames && segmentNames.length > 1) {
                    hasDuplicateSegmentNames = _.uniq(segmentNames).length !== segmentNames.length;
                  }
                }
                return (listStateSvc.get().CurrentUIState.hasVisited.manageSegments && !hasDuplicateSegmentNames);
              },
              available: function () {
                return getStep('criteria').completed();
              }
            },
            {
              name: 'manageSegmentsGeographies',
              letter: 'a',
              title: 'Geographies',
              selectionCss: 'inactive',
              miniWizardOnly: function () {
                return (listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsListInclusions' || listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsFilters' || listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsGeographies') ? false : true;
              },
              completed: function () {
                return listStateSvc.get().CurrentUIState.hasVisited.manageSegmentsGeographies;
              },
              available: function () {
                return getStep('manageSegments').completed();
              }
            },
            {
              name: 'manageSegmentsListInclusions',
              letter: 'b',
              title: 'List Inclusions',
              selectionCss: 'inactive',
              miniWizardOnly: function () {
                return (listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsListInclusions' || listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsFilters' || listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsGeographies') ? false : true;
              },
              completed: function () {
                return listStateSvc.get().CurrentUIState.hasVisited.manageSegmentsListInclusions;
              },
              available: function () {
                return getStep('manageSegmentsGeographies').completed();
              }
            },
            {
              name: 'manageSegmentsFilters',
              letter: 'c',
              title: 'Criteria',
              selectionCss: 'inactive',
              miniWizardOnly: function () {
                return (listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsListInclusions' || listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsFilters' || listStateSvc.get().CurrentUIState.currentSubStepName === 'manageSegmentsGeographies') ? false : true;
              },
              completed: function () {
                return listStateSvc.get().CurrentUIState.hasVisited.manageSegmentsFilters;
              },
              available: function () {
                return getStep('manageSegmentsGeographies').completed();
              }
            }
          ],
          //Manage Prioritize  Tab
          [
            {
              name: 'prioritizeCountType',
              letter: 'a',
              title: 'Target Type',
              selectionCss: 'active',
              completed: function () {
                return listStateSvc.get().CurrentUIState.hasVisited.prioritizeCountType;
              },
              available: function () {
                return getStep('manageSegments').completed();
              }
            },
            {
              name: 'managePrioritize',
              letter: 'b',
              title: 'Targeting',
              selectionCss: 'active',
              completed: function () {
                return listStateSvc.get().Distribution && listStateSvc.get().Distribution.DesiredCount > 0 && listStateSvc.get().CurrentUIState.distributionTablesValid && !listStateSvc.get().CurrentUIState.isControlGroupDirty;
              },
              available: function () {
                return getStep('prioritizeCountType').completed() && !listStateSvc.get().CurrentUIState.isControlGroupDirty;
              }
            }
          ],
          //Summary Tab
          [
            {
              name: 'summary',
              letter: '',
              title: 'Summary',
              selectionCss: 'active',
              completed: function () {
                return true;
              },
              available: function () {
                return true;
              }
            }
          ]
        ]
      };

      return definitions;
    }; // END RETURN

  }]);

})(window.app);
