/* jshint ignore:start */
'use strict';

(function (app) {

  app.factory('geographiesLookupSvc', ['$http', '$q', 'baseApiUrl', 'userContextSvc',
  function (http, q, baseApiUrl, userContextSvc) {
    var chunk = 40;

    var logError = function (error) {
      console.log(error);
      if (error.data)
        console.log(error.data.message);
    };

    //Below data needs to be moved to DB lookup svc
    var statesJson = [
      { 'Name': 'Alabama', 'Id': 'AL' },
      { 'Name': 'Alaska', 'Id': 'AK' },
      { 'Name': 'American Samoa', 'Id': 'AS' },
      { 'Name': 'Arizona', 'Id': 'AZ' },
      { 'Name': 'Arkansas', 'Id': 'AR' },
      { 'Name': 'California', 'Id': 'CA' },
      { 'Name': 'Colorado', 'Id': 'CO' },
      { 'Name': 'Connecticut', 'Id': 'CT' },
      { 'Name': 'Delaware', 'Id': 'DE' },
      { 'Name': 'District Of Columbia', 'Id': 'DC' },
      { 'Name': 'Federated States Of Micronesia', 'Id': 'FM' },
      { 'Name': 'FlorIda', 'Id': 'FL' },
      { 'Name': 'Georgia', 'Id': 'GA' },
      { 'Name': 'Guam', 'Id': 'GU' },
      { 'Name': 'Hawaii', 'Id': 'HI' },
      { 'Name': 'Idaho', 'Id': 'ID' },
      { 'Name': 'Illinois', 'Id': 'IL' },
      { 'Name': 'Indiana', 'Id': 'IN' },
      { 'Name': 'Iowa', 'Id': 'IA' },
      { 'Name': 'Kansas', 'Id': 'KS' },
      { 'Name': 'Kentucky', 'Id': 'KY' },
      { 'Name': 'Louisiana', 'Id': 'LA' },
      { 'Name': 'Maine', 'Id': 'ME' },
      { 'Name': 'Marshall Islands', 'Id': 'MH' },
      { 'Name': 'Maryland', 'Id': 'MD' },
      { 'Name': 'Massachusetts', 'Id': 'MA' },
      { 'Name': 'Michigan', 'Id': 'MI' },
      { 'Name': 'Minnesota', 'Id': 'MN' },
      { 'Name': 'Mississippi', 'Id': 'MS' },
      { 'Name': 'Missouri', 'Id': 'MO' },
      { 'Name': 'Montana', 'Id': 'MT' },
      { 'Name': 'Nebraska', 'Id': 'NE' },
      { 'Name': 'Nevada', 'Id': 'NV' },
      { 'Name': 'New Hampshire', 'Id': 'NH' },
      { 'Name': 'New Jersey', 'Id': 'NJ' },
      { 'Name': 'New Mexico', 'Id': 'NM' },
      { 'Name': 'New York', 'Id': 'NY' },
      { 'Name': 'North Carolina', 'Id': 'NC' },
      { 'Name': 'North Dakota', 'Id': 'ND' },
      { 'Name': 'Northern Mariana Islands', 'Id': 'MP' },
      { 'Name': 'Ohio', 'Id': 'OH' },
      { 'Name': 'Oklahoma', 'Id': 'OK' },
      { 'Name': 'Oregon', 'Id': 'OR' },
      { 'Name': 'Palau', 'Id': 'PW' },
      { 'Name': 'Pennsylvania', 'Id': 'PA' },
      { 'Name': 'Puerto Rico', 'Id': 'PR' },
      { 'Name': 'Rhode Island', 'Id': 'RI' },
      { 'Name': 'South Carolina', 'Id': 'SC' },
      { 'Name': 'South Dakota', 'Id': 'SD' },
      { 'Name': 'Tennessee', 'Id': 'TN' },
      { 'Name': 'Texas', 'Id': 'TX' },
      { 'Name': 'Utah', 'Id': 'UT' },
      { 'Name': 'Vermont', 'Id': 'VT' },
      { 'Name': 'Virgin Islands', 'Id': 'VI' },
      { 'Name': 'Virginia', 'Id': 'VA' },
      { 'Name': 'Washington', 'Id': 'WA' },
      { 'Name': 'West Virginia', 'Id': 'WV' },
      { 'Name': 'Wisconsin', 'Id': 'WI' },
      { 'Name': 'Wyoming', 'Id': 'WY' }
    ];

    var getCountiesById = function (message) {
      var url = app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/counties/';
      var countyArrays = [];
      var i;
      for (i = 0; i < message.CountyIds.length; i += chunk) {
        countyArrays.push(message.CountyIds.slice(i, i + chunk));
      }
      var promiseArray = countyArrays.map(function (counties) {
        return http({
          method: 'GET',
          url: url + counties.join(','),
          cache: true
        });
      });

      return q.all(promiseArray).then(
      function (responses) {
        var retVal = [];
        for (var i = 0; i < responses.length; i++) {
          retVal = retVal.concat(responses[i].data.results.Counties)
        }
        return retVal;
      },
      function (error) {
        logError(error);
      }
      );
    };

    var getZipCodesById = function (message) {
      var url = app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/zipCodes/';
      var zipArrays = [];
      var i;
      for (i = 0; i < message.ZipCodes.length; i += chunk) {
        zipArrays.push(message.ZipCodes.slice(i, i + chunk));
      }
      var promiseArray = zipArrays.map(function (zips) {
        return http({
          cache: true,
          method: 'GET',
          url: url + zips.join(',') + '?IncludeGeoJSON=' + message.IncludeGeoJSON
        });
      });

      return q.all(promiseArray).then(
      function (responses) {
        var retVal = [];
        for (var i = 0; i < responses.length; i++) {
          retVal = retVal.concat(responses[i].data.results.ZipCodes);
        }
        return retVal;
      },
      function (error) {
        logError(error);
      }
      );
    };

    var getZipCodesByLocation = function (message) {
      return http({
        method: 'GET',
        url: baseApiUrl() + 'locations/' + message.Id + '/zipCodes',
        data: JSON.stringify(message),
        cache: true
      })
      .then(
      function (response) {
        return response.data.results.ZipCodes;
      },
      function (error) {
        logError(error);
      }
      );
    };

    var getZipCodesByLocationRadius = function (message) {
      return http({
        cache: true,
        method: 'GET',
        url: baseApiUrl() + 'locations/' + message.Id + '/zipCodesByRadius' +
        '?RadiusDescriptor=' + JSON.stringify(message.RadiusDescriptor)
      })
      .then(
      function (response) {
        return response.data.results.ZipCodeIds;
      },
      function (error) {
        logError(error);
      }
      );
    };

    var getStatesById = function (message) {
      return _.filter(statesJson, function (state) {
        return _.contains(message.Ids, state.Id);
      });
    };

    return {
      getZipCodesByLocationRadius: getZipCodesByLocationRadius,
      getZipCodesByLocation: getZipCodesByLocation,
      getZipCodesById: getZipCodesById,
      getStatesById: getStatesById,
      getCountiesById: getCountiesById
    };
  }
  ]);
})(window.app);
/* jshint ignore:end */