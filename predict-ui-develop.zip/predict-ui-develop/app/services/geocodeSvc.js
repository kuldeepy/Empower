'use strict';
/* global google */
(function (app) {

  app.factory('geocodeSvc', [function () {
    var geocoder = new google.maps.Geocoder();

    var findAddressComponents = function (addressComponents, componentsName) {
      return _.result(_.find(addressComponents, function (components) {
        return components.types[0].toUpperCase() === componentsName.toUpperCase();
      }), 'short_name');
    };

    var validateAddressPart = function (addressPart) {
      return addressPart && addressPart.trim() !== '';
    };

    // This method makes an async call to the google api, therefore a callback 
    // must be provided which will be called when the google api provides a response.
    /*jshint camelcase: false */
    var geocodeAddress = function (address, callback) {
      var response = {
        resolvedAddress: '',
        success: false
      };
      geocoder.geocode({ 'address': address }, function (results, status) {
        var locationResult = '';
        var addressComponents = [];
        var street_number = '';
        var route = '';
        var address1 = '';
        var city = '';
        var postal_code = '';
        var state = '';

        if (results && results.length > 0 && status === google.maps.GeocoderStatus.OK) {
          addressComponents = results[0].address_components;
          locationResult = results[0].geometry.location;

          street_number = findAddressComponents(addressComponents, 'street_number');
          route = findAddressComponents(addressComponents, 'route');
          address1 = (street_number || '') + ' ' + (route || '');
          city = findAddressComponents(addressComponents, 'locality');
          state = findAddressComponents(addressComponents, 'administrative_area_level_1');
          postal_code = findAddressComponents(addressComponents, 'postal_code');
        }
        var isValidAddress = validateAddressPart(address1) && validateAddressPart(city) && validateAddressPart(state) && validateAddressPart(postal_code);
        if (isValidAddress) {
          response.resolvedAddress = {
            'Address1': address1,
            'City': city,
            'State': state,
            'Zip': postal_code,
            'GeoJson': {
              'Type': 'Point',
              'Coordinates': [ locationResult.lng(), locationResult.lat() ]
            }
          };
          response.success = true;
        }
        else {
          response.resolvedAddress = 'Error: ' + status;
          response.success = false;
        }
        callback(response);
      });
    };

    return {
      geocodeAddress: geocodeAddress
    };
  }
  ]);
})(window.app);