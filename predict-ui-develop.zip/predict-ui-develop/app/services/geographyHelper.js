'use strict';

(function (app) {

	app.factory('geographyHelper', ['_', 'sessionSvc', 'locationSvc',
		function (_, sessionSvc, locationSvc) {
			var locationData = JSON.parse(sessionSvc.get('selectLocation.locations'));

			var getFormattedAddress = function (address) {
				var formattedAddress = address.Address1;
				formattedAddress = formattedAddress + ', ' + address.City + ', ' + address.State + ' ' + address.Zip;
				return formattedAddress;
			};

			var getMultipleRadiusDescriptions = function (loc) {
				var radiiDescription = '<ul class="grid-list-tooltip">';
				_.forEach(loc.RadiusDescriptors, function (rad) {
          var distDesc = rad.RadiusInMiles > 1 ? 'miles' : 'mile';
          radiiDescription = radiiDescription + '<li style="list-style-type: none;">' + rad.RadiusInMiles + ' ' + distDesc + ' from ' + (rad.IsCustomAddress ? rad.FormattedAddress : rad.LocationName) + '</li>';
				});
				radiiDescription = radiiDescription + '</ul>';
				return radiiDescription;
			};

			var getLocationName = function (id) {
				var loc = _.find(locationData, {
					'Id': id
				});
				if (loc) {
					return loc.Name;
				}
				return id;
			};

			var addComma = function (text) {
				if (text === '') {
					return text;
				}
				text += ', ';
				return text;
			};

			var addServiceAreaText = function (loc, areaName) {
				loc.ServiceAreaText = addComma(loc.ServiceAreaText);
				loc.ServiceAreaText += areaName;
			};

			var getSelectedZips = function (loc) {
				var selectedZips = [];

				if (loc.PrimaryServiceAreaZipCodes) {
					selectedZips.push(loc.PrimaryServiceAreaZipCodes.toString());
				}
				if (loc.SecondaryServiceAreaZipCodes) {
					selectedZips.push(loc.SecondaryServiceAreaZipCodes.toString());
				}
				if (loc.TertiaryServiceAreaZipCodes) {
					selectedZips.push(loc.TertiaryServiceAreaZipCodes.toString());
				}
				return selectedZips;
			};

			var mapLocationDescriptorsForGrid = function (locationDescriptors) {
				//var locations = _.map(locationDescriptors, _.cloneDeep);
        // Making a unreferenced copy keeps the locationDescriptors from being bound to the listState
        var facilitiesData = JSON.parse(sessionSvc.get('selectedLocation.facilities'));
				var locations = locationDescriptors;
				_.forEach(locations, function (loc) {
					_.forEach(loc.RadiusDescriptors, function (rad) {
						var locName = '';
						if (!rad.LocationId || rad.LocationId === '') {
							locName = rad.Address.Address1;
						} else {
							var locData = _.find(locationData, {
								'Id': rad.LocationId
							});

							var facilityData;
							if (!locData) {
                facilityData = _.find(facilitiesData.Facilities,{
                  'Id': parseInt(rad.LocationId)
                });
                locName = facilityData.Name;
              }
              else {
                locName = locData.Name;
              }
            }
						_.extend(rad, {
							'LocationName': rad.Name || locName, // If rad.Name not available, use locName. Used for persisting the location name from pulled list summary.
							'FormattedAddress': getFormattedAddress(rad.Address),
							'FormattedTargetAreaText': parseInt(rad.RadiusInMiles) === 1 ? 'mile from' : 'miles from'
						});

						if (rad.AdditionalZipCodeIds.length > 0) {
              rad.IncludedZipCodesWithinRadius = _.difference(_.union(rad.AdditionalZipCodeIds, rad.RadiusZipCodeIds), rad.ExcludedZipCodeIds);
						} else {
              rad.IncludedZipCodesWithinRadius = _.difference(rad.RadiusZipCodeIds, rad.ExcludedZipCodeIds);
            }
					});
					if (loc.RadiusDescriptors && loc.RadiusDescriptors.length > 1) {
						_.extend(loc, {
							'RadiusDescriptions': getMultipleRadiusDescriptions(loc)
						});
					}
				});
				locationSvc.listLocations()
					.then(function (data) {
						_.forEach(locations, function (location) {
							if (!location.Name || !location.ServiceAreaText) {
								var selectedLocation = _.find(data, {
									'Id': parseInt(location.LocationId)
								});
								location.Name = selectedLocation.Name;
								location.ServiceAreaText = '';
								if (location.PrimaryServiceAreaZipCodes.length > 0 && location.UsePrimaryServiceArea === true) {
									addServiceAreaText(location, 'Primary');
								}
								if (location.SecondaryServiceAreaZipCodes.length > 0 && location.UseSecondaryServiceArea === true) {
									addServiceAreaText(location, 'Secondary');
								}
								if (location.TertiaryServiceAreaZipCodes.length > 0 && location.UseTertiaryServiceArea === true) {
									addServiceAreaText(location, 'Tertiary');
								}
								if (!location.SelectedZipCodes) {
									location.SelectedZipCodes = getSelectedZips(location);
								}

							}
						});
					});
				return locations;
			};

			return {
				getFormattedAddress: getFormattedAddress,
				getMultipleRadiusDescriptions: getMultipleRadiusDescriptions,
				getLocationName: getLocationName,
				mapLocationDescriptorsForGrid: mapLocationDescriptorsForGrid
			};

		}
	]);
})(window.app);
