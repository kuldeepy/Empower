﻿'use strict';

(function (app) {

  app.factory('seedListSvc', ['$http', 'baseApiUrl', 'alertSvc',
  function (http, baseApiUrl, alertSvc) {

    var logError = function (error) {
      console.log(error.data.message);
      console.log(error);
    };

    var getSeedListData = function (id) {
      var idString = '';
      if (id) {
        idString = '/' + id;
      }
      console.log('getting seedList', id);
      return http({
        method: 'GET',
        url: baseApiUrl() + 'seedLists' + idString
      }).then(
      function (response) {
        if (id) {
          return response.data.results.SeedList;
        }
        else {
          return response.data.results.SeedLists;
        }
      },
      function (error) {
        alertSvc.add({ Code: 1000, Type: 'Error', Source: 'seedlist' });
        logError(error);
      });
    };


    return {
      getSeedListData: getSeedListData
    };

  }
  ]);
})(window.app);