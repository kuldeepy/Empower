'use strict';

(function (app) {

  app.factory('recipeSvc', ['$http', 'baseApiUrl','alertSvc',
  function (http, baseApiUrl, alertSvc) {

    var logError = function (error) {
      console.log(error.data.message);
      console.log(error);
    };

    var getRecipesForOrganization = function () {
      return http({
        method: 'GET',
        url: baseApiUrl() + 'recipes',
        cache: true
      }).then(
      function (response) {
        if (typeof(response.data.results.Recipes) === 'undefined' || response.data.results.Recipes.length === 0)
        {
          alertSvc.add({ Type: 'Fatal', Title: 'No Data Found', Source: 'recipe', Message: 'No Recipe data found' });
        }
        return response.data.results.Recipes;
      },
      function (error) {
        alertSvc.add({ Code: 1000, Source: 'recipe' });
        logError(error);
      });
    };

    var getRecipe = function (recipeId) {
      return http({
        method: 'GET',
        url: baseApiUrl() + 'recipes/' + recipeId,
        cache: true
      }).then(
      function (response) {
        return response.data.results.Recipe;
      },
      function (error) {
        logError(error);
      });
    };


    return {
      getRecipesForOrganization: getRecipesForOrganization,
      getRecipe: getRecipe
    };

  }
  ]);
})(window.app);