(function (app) {
  'use strict';

  app.factory('targetAreasColumn', function () {
    return {
      field: '',
      displayName: 'Target Areas',
      cellTemplate: '<div ng-switch="row.getProperty(\'Type\')">' +
      '<div ng-switch-when="ServiceArea"><div class="ngCellText target-area service-area-summary-text">{{row.getProperty(\'ServiceAreaText\')}}</div>' +
      '<a style="padding-top: 7px;" class="pull-right service-area-info" popover-placement="left" popover-append-to-body="true" popover-trigger="mouseenter" popover-title="Included ZIP Codes" ' +
      'popover="{{row.getProperty(\'SelectedZipCodes\').toString().split(\',\').join(\', \')}}" ng-show="{{row.getProperty(\'ServiceAreaText\') !== \'No\'}}">' +
      '<span class="round-icon"><span class="border"></span><img src="/images/icons/icon_zipcode.png" class="icon" alt="Zip Codes"></span></a></div>' +
      '<div ng-switch-when="Radius"><div ng-if="row.getProperty(\'RadiusDescriptors.length\') === 1"><div class="ngCellText target-area service-area-summary-text">{{row.getProperty(\'RadiusDescriptors\')[0].RadiusInMiles}} {{row.getProperty(\'RadiusDescriptors\')[0].FormattedTargetAreaText}} ' +
      '<a popover-placement="left" popover-append-to-body="true" popover-trigger="mouseenter" popover="{{row.getProperty(\'RadiusDescriptors\')[0].FormattedAddress}}">' +
      '<span ng-if="row.getProperty(\'RadiusDescriptors[0].IsCustomAddress\')===true">{{row.getProperty(\'RadiusDescriptors\')[0].FormattedAddress}}</span><span ng-if="!row.getProperty(\'RadiusDescriptors[0].IsCustomAddress\') || row.getProperty(\'RadiusDescriptors[0].IsCustomAddress\')===false">{{row.getProperty(\'RadiusDescriptors\')[0].LocationName}}</span></a></div>' +
      '<a style="padding-top: 7px;" class="pull-right service-area-info" tooltip-placement="left" tooltip-append-to-body="true" tooltip-trigger="mouseenter"' +
      'tooltip-html-unsafe="<ul class=&quot;grid-list-tooltip&quot;><li>Included ZIP Codes: {{row.getProperty(\'RadiusDescriptors\')[0].IncludedZipCodesWithinRadius.toString().split(\',\').join(\', \')}}</li></ul>">' +
      '<span class="round-icon"><span class="border"></span><img src="/images/icons/icon_zipcode.png" class="icon" alt="Zip Codes"></span></a></div>' +
      '<div ng-if="row.getProperty(\'RadiusDescriptors.length\') > 1"><div class="ngCellText target-area service-area-summary-text">Multiple Radii</div>' +
      '<a style="padding-top: 7px;" class="pull-right service-area-info radius" tooltip-placement="top red" tooltip-append-to-body="true" tooltip-trigger="mouseenter" tooltip-html-unsafe="{{row.getProperty(\'RadiusDescriptions\')}}">' +
      '<span class="round-icon"><span class="border"></span><img src="/images/icons/icon_radius.png" class="icon" alt="Radii Descriptions" /></span></a></div></div>' +
      '<div ng-switch-default></div></div>'
    };
  });
})(window.app);
