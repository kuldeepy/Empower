﻿'use strict';

(function (app) {

  app.factory('pastListSvc', ['$http', 'baseApiUrl','alertSvc',
  function (http, baseApiUrl, alertSvc) {

    var logError = function (error) {
      console.log(error.data.message);
      console.log(error);
    };

    var pastListData = function (applyExclusionPeriod) {
      return http({
        method: 'GET',
        url: baseApiUrl() + 'pastList?ApplyExclusionPeriod=' + applyExclusionPeriod
      }).then(
      function (response) {
        return response.data.results.PastList;
      },
      function (error) {
        alertSvc.add({ Code: 1000, Type: 'Error', Source: 'pastlist' });
        logError(error);
      });
    };

    return {
      pastListData: pastListData
    };

  }
  ]);
})(window.app);