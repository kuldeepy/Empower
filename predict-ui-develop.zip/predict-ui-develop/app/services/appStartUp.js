
(function (app) {
  'use strict';

  app.ng.requires.push('ui.bootstrap');
  //app.ng.requires.push('ngGrid');
  app.ng.requires.push('ui.router');
  app.ng.requires.push('ngTouch');
  app.ng.requires.push('ngAnimate');
  app.ng.requires.push('ngIdle');
  app.ng.requires.push('ui.tree');
  app.ng.requires.push('reTree');
  app.ng.requires.push('ng.deviceDetector');
  
  app.ng.run(
  ['$rootScope', '$state', '$stateParams',
  function ($rootScope, $state, $stateParams) {
    $rootScope.$state = $state;
    $rootScope.$stateParams = $stateParams;
  }
  ]
  );
  app.ng.config(
  ['$stateProvider','KeepaliveProvider', 'IdleProvider',
  function ($stateProvider, KeepaliveProvider, IdleProvider) {
    var modulePath = 'modules/listBuild';
    var ctrlRoot = app.root + modulePath + '/Views/';
    var tokenRefreshInterval = (app.autoRefreshTokenInterval) ? app.autoRefreshTokenInterval : 60;
    $stateProvider
    .state('listName',
    {
      url: '#listName',
      templateUrl: ctrlRoot + 'listNameAndChannel.html'
    })
    .state('recipe',
    {
      url: '#recipe',
      templateUrl: ctrlRoot + 'selectRecipe.html'
    })
    .state('selectLocation',
    {
      url: '#selectLocation',
      templateUrl: ctrlRoot + 'selectLocation.html'
    })
    .state('serviceAreaRadius',
    {
      url: '#serviceAreaRadius',
      templateUrl: ctrlRoot + 'serviceAreaRadius.html'
    })
    .state('serviceArea',
    {
      url: '#serviceArea',
      templateUrl: ctrlRoot + 'serviceArea.html'
    })
    .state('radius',
    {
      url: '#radius',
      templateUrl: ctrlRoot + 'radius.html'
    })
    .state('geographiesSummary',
    {
      url: '#geographiesSummary',
      templateUrl: ctrlRoot + 'geographiesSummary.html'
    })
    .state('pastLists',
    {
      url: '#pastLists',
      templateUrl: ctrlRoot + 'pastLists.html'
    })
    .state('criteria',
    {
      url: '#criteria',
      templateUrl: ctrlRoot + 'criteria.html'
    })
    .state('manageSegments',
    {
      url: '#manageSegments',
      templateUrl: ctrlRoot + 'manageSegments.html'
    })
    .state('manageSegmentsListInclusions',
    {
      url: '#manageSegmentsListInclusions',
      templateUrl: ctrlRoot + 'manageSegmentsListInclusions.html'
    })
    .state('manageSegmentsGeographies',
    {
      url: '#manageSegmentsGeographies',
      templateUrl: ctrlRoot + 'manageSegmentsGeographies.html'
    })
    .state('manageSegmentsFilters',
    {
      url: '#manageSegmentsFilters',
      templateUrl: ctrlRoot + 'manageSegmentsFilters.html'
    })
    .state('manageSegmentsSave',
    {
      url: '#manageSegmentsSave',
      templateUrl: ctrlRoot + 'manageSegmentsSave.html'
    })
    .state('manageSeedList',
    {
      url: '#manageSeedList',
      templateUrl: ctrlRoot + 'manageSeedList.html'
    })
    .state('prioritizeCountType',
    {
      url: '#prioritizeCountType',
      templateUrl: ctrlRoot + 'prioritizeCountType.html'
    })
    .state('managePrioritize',
    {
      url: '#managePrioritize',
      templateUrl: ctrlRoot + 'prioritize.html'
    })
    .state('summary',
    {
      url: '#summary',
      templateUrl: ctrlRoot + 'summary.html'
    });
    KeepaliveProvider.interval(tokenRefreshInterval); // This will help to refresh the auth.token every 1 minute
    IdleProvider.autoResume('notIdle');
  }]);

}(window.app));
