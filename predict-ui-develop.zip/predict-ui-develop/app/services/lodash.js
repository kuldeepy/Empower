(function (app) {
  'use strict';
  
  app.ng.config(function ($provide) {
    $provide.value('_', _);
    $provide.value('lodash', _);
  });
})(window.app);
