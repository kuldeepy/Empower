﻿'use strict';

(function (app) {

  app.factory('etlDataUpdateSvc', ['clientSvc', 'listStateSvc', '$q',
  function (clientSvc, listStateSvc, q) {
      var etlDate;
      
      var handleETLUpdates = function (listState, clientKey) {
        var deferred = q.defer();
        if (!listState.PullDate) {
          clientSvc.loadClients(clientKey).then(function (client) {
            etlDate = client.ETLDate;
            if (listStateSvc.hasETLDataUpdated(etlDate) && listStateSvc.isLocationDefined() && !listStateSvc.hasMarketingChannel()) {
              deferred.resolve(true);
            }
            else {
              deferred.resolve(false);
            }
          });
        }
        else {
          deferred.resolve(false);
        }
        return deferred.promise;
      };

      return {
        handleETLUpdates: handleETLUpdates
      };

    }
  ]);
})(window.app);