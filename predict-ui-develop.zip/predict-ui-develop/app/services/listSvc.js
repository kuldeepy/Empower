'use strict';

(function (app) {

  app.factory('listSvc', ['$http', 'baseApiUrl', '$q', 'longTaskSvc', '_',
    function (http, baseApiUrl, q, longTaskSvc, _) {

      //TODO: put this in a more global location
      http.defaults.headers.post['Content-Type'] = 'application/json';
      var listName;
      var searchLists = function (params) {
        if (_.has(params, 'IncludeFields') && _.has(params, 'ExcludeFields') &&
          (params.IncludeFields.length > 0 || params.ExcludeFields.length > 0)) {
          return http({
            headers: {
              'Pragma': 'no-cache',
              'Cache-Control': 'no-cache'
            },
            method: 'GET',
            url: baseApiUrl() + 'lists',
            params: params
          }).then(
            function (response) {
              return response.data.results.Lists;
            });
        }
        else {
          throw new Error('Request for lists must filter the fields for performance');
        }
      };

      var getList = function (listId) {
        if (!listId) {
          return searchLists();
        }
        return http({
          headers: {
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache'
          },
          method: 'GET',
          url: baseApiUrl() + 'lists/' + listId
        }).then(
          function (response) {
            return response.data.results.List;
          });
      };

      var createList = function (list) {
        var createListMessage = {
          List: list
        };
        return http({
          method: 'POST',
          url: baseApiUrl() + 'lists',
          data: JSON.stringify(createListMessage)
        }).then(
          function (response) {
            return response.data.results.NewId;
          });
      };

      var updateList = function (list) {
        var updateListMessage = {
          List: list
        };
        return http({
          method: 'PUT',
          url: baseApiUrl() + 'lists/' + list.Id,
          data: JSON.stringify(updateListMessage)
        }).then(
          function (response) {
            return response.data.results !== null;
          });
      };

      var deleteList = function (listId) {
        return http({
          method: 'DELETE',
          url: baseApiUrl() + 'lists/' + listId
        }).then(
          function (response) {
            return response.data.results !== null;
          });
      };

      var createPersonMarkerCollection = function (list, batchSize, bounds) {
        var createPersonMarkerCollectionMessage = {
          List: list,
          BatchSize: batchSize,
          MapBounds: bounds
        };
        return http({
          method: 'POST',
          url: baseApiUrl() + 'lists/persons',
          data: angular.fromJson(createPersonMarkerCollectionMessage)
        }).then(
          function (response) {
            return response.data.results;
          });
      };

      var nextPersonMarkerBatch = function (scrollId) {
        return http({
          headers: {
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache'
          },
          method: 'GET',
          url: baseApiUrl() + 'lists/persons/' + scrollId
        })
        .then(function (response) {
          return JSON.parse(response.data.results);
        });
      };

      /** Fetches person markers in batches and passes the array of  markers to the callback.
        * This function parses directly from elastic's format.
        * @list            {obj}      List spec.
        * @batchSize       {int}      Number of markers to pass into each callback.
        * @markerCallback  {function} As markers stream in, pass to this function.
        * @returns         {Promise}  Promise resolves or rejects based on success of all markers together.
      **/
      var scrollPersonMarkersInBatches = function (list, batchSize, markerCallback) {
        var allDone = q.defer();

        createPersonMarkerCollection(list, batchSize)
        .then(function (personMarkerResults) {
          var scrollId = personMarkerResults.scrollId;

          var keepScrolling = true;

          scrollPage()
          .then(function () {
            return allDone.resolve();
          })
          .catch(function (err) {
            return allDone.reject(err);
          });

          function scrollPage() {
            if (!keepScrolling) { return allDone.resolve(true); }

            return nextPersonMarkerBatch(scrollId)
            .then(function (elasticResponse) {
              if (elasticResponse.hits.hits.length === 0) {
                keepScrolling = false;
              } else {
                /* jshint ignore:start */
                scrollId = elasticResponse._scroll_id;
                /* jshint ignore:end */
                markerCallback(elasticResponse.hits.hits);
              }
            })
            .then(scrollPage);
          }
        });

        return allDone.promise;
      };

      var pullList = function (listId, legacyUserId, listName) {
        var pullListMessage = {
          ListId: listId,
          LegacyUserId: legacyUserId
        };
        return http({
          method: 'POST',
          url: baseApiUrl() + 'listPulls',
          data: JSON.stringify(pullListMessage)
        }).then(
          function () {
            longTaskSvc.add({
              Description: getTaskDescription(listName),
              Status: 'Request Received...',
              PercentComplete: 1
            });
          },
          function () {
            longTaskSvc.add({
              Description: getTaskDescription(listName),
              Status: 'Failed.',
              PercentComplete: 100,
              IsError: true
            });
          });
      };

      function getTaskDescription(listName) {
        if (typeof (listName) === 'undefined' || listName === null || listName === '') {
          return 'List Pull - Unnamed List';
        }
        return 'List Pull - ' + listName;
      }

      var createNewId = function () {
        var createIdMessage = {};
        return http({
          method: 'POST',
          url: baseApiUrl() + 'lists/id',
          data: JSON.stringify(createIdMessage)
        }).then(
          function (response) {
            return response.data.results.ListId;
          });
      };


      var currentListName = {
        get: function () {
          return listName;
        },
        set: function (data) {
          listName = data;
        },
        clear: function () {
          listName = undefined;
        }
      };

      return {
        searchLists: searchLists,
        getList: getList,
        //getLRTList: getLRTList,
        //updateLRTList: updateLRTList,
        updateList: updateList,
        createList: createList,
        deleteList: deleteList,
        createPersonMarkerCollection: createPersonMarkerCollection,
        scrollPersonMarkersInBatches: scrollPersonMarkersInBatches,
        pullList: pullList,
        createNewId: createNewId,
        currentListName: currentListName
      };
    }
  ]);
})(window.app);