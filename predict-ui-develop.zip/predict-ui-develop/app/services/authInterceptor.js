(function (app) {
  'use strict';
  var lastAPICallTimeKey = 'lastAPICallTime';

  app.factory('authInterceptor', ['$rootScope', '$q', '$injector', function ($rootScope, $q, $injector) {
    return {
      request: function (config) {

        var authSvc = $injector.get('authSvc');
        var authToken = authSvc.getToken();

        if (authToken !== null) {
          config.headers = config.headers || {};
          config.headers.Authorization = 'Bearer ' + authToken;
        }
        return config;
      },
      response: function (response) {

        var authSvc = $injector.get('authSvc');
        var sessionSvc = $injector.get('sessionSvc');
        var lastAPICallTime = new Date();
        sessionSvc.set(lastAPICallTimeKey, lastAPICallTime);
        var newToken = response.headers().newtoken;
        if (newToken !== null && newToken !== undefined) {
          authSvc.storeAuthData(newToken);
        }

        return response;
      }
    };
  }]);

  app.ng.config(function ($httpProvider) {
    if (!$httpProvider.defaults.headers.get) {
      $httpProvider.defaults.headers.get = {};
    }
    $httpProvider.interceptors.push('authInterceptor');
  });

}(window.app));