'use strict';

(function (app) {

  app.factory('userContextSvc', ['sessionSvc', 'selectedContext', '$rootScope', '$location', '$timeout',
  function (sessionSvc, selectedContext, $rootScope, location, $timeout) {

    var selectedContextSvc = selectedContext;
    var clientDataAvailThroughDate = 'dataAvailThroughDate';

    var getClientKey = function () {
      if (app.routing !== undefined && app.routing.routeParams !== undefined) {
        return app.routing.routeParams.clientKey || '';
      }
      return '';
    };

    var getApiClientKey = function () {
      var clientKey = getClientKey();
      if (clientKey === '') {
        return app.superTenantClientKey;
      }
      return clientKey;
    };

    var getOrgKey = function () {
      if (app.routing !== undefined && app.routing.routeParams !== undefined) {
        if ((sessionSvc.get('auth.userOrgKey') && sessionSvc.get('auth.userOrgKey') !== null && sessionSvc.get('auth.userOrgKey').indexOf(app.routing.routeParams.orgKey) > -1) || sessionSvc.get('auth.userOrgKey') === '[]') {
          return app.routing.routeParams.orgKey || getUserPrimaryOrganization().OrgKey;
        }
      }
      return '';
    };

    var getAccountsPage = function () {
      //TODO: add logic here to check for only one client/org and forward to landing page.
      return '/accounts';
    };

    var getUserLandingUrl = function () {
      //TODO: add logic here to check for multiple clients/orgs and forward to Accounts page.
      return '/' + getClientKey();
    };

    var getUserLoginUrl = function () {
      var clientKey = getClientKey();
      if (clientKey === '' || clientKey === null || sessionSvc.get('auth.adminrole')) {
        return app.baseLoginUrl;
      }
      return '/' + clientKey + app.baseLoginUrl;
    };

    var getUserOrganizations = function () {
      var orgsList = sessionSvc.get('auth.userOrgKey');
      if (orgsList === null) {
        return [];
      }
      return JSON.parse(orgsList);
    };

    var getOrganizationName = function (orgKey) {
      var orgsList = sessionSvc.get('auth.userOrgKey');
      if (orgsList === null) {
        return [];
      }
      var organization = _.filter(JSON.parse(orgsList), function (org) { return org.OrgKey === orgKey; });
      sessionSvc.set('orgName', organization[0].Name);
      return organization[0].Name;
    };

    var getUserPrimaryOrganization = function () {
      var userOrgs = getUserOrganizations();
      if (userOrgs.length === 0) {
        return {
          Name: 'Unspecified',
          OrgKey: 'Unspecified'
        };
      }
      return userOrgs[0];
    };

    var setUserContext = function(client, organization) {
      var homeLink = '/' + client.Key;
      var contextLink = '/' + client.Key + '/' + organization.Key;
      var route = app.routing.data;
      var model = {};
      model.userOrgs = [];

      var pathArray = window.location.pathname.split('/');
      var newPathname = '';
      // jshint plusplus:false
      for (var i = 0; i < pathArray.length; i++) {
        if (pathArray[i].length > 0 && pathArray[i] !== getClientKey() && pathArray[i] !== getOrgKey() ) {
          newPathname += '/';
          newPathname += pathArray[i];
        }
      }
      // jshint plusplus:true
      this.clientNameValue = client.Name;
      sessionSvc.set('clientName', this.clientNameValue);
      $rootScope.$broadcast('getClientValue', this.clientNameValue);
      this.orgNameValue = organization.Name;
      sessionSvc.set('orgName', this.orgNameValue);
      $rootScope.$broadcast('getOrgValue', this.orgNameValue);
      sessionSvc.clear('selectLocation.locations');
      this.isSilverpopConfigured = client.IsSilverpopConfigured;

      this.dataAvailThroughDate = client.DATDate;
      sessionSvc.set(clientDataAvailThroughDate, this.dataAvailThroughDate);
      $rootScope.$broadcast('getdataAvailThroughDate', this.dataAvailThroughDate);

      selectedContextSvc.client = client.Key;
      selectedContextSvc.organization = organization.Key;

      angular.forEach(client.Organizations, function (org) {
        model.userOrgs.push({ 'OrgKey': org.Key, 'ListManagementLinkLabel': org.Name });
      });

      if (newPathname === '/accounts') {
        return location.path(homeLink);
      } else if (route.isWizardMode || newPathname === '/lists/listsummary') {
        return location.path(contextLink + '/lists');
      } else {
        return location.path(contextLink + newPathname);
      }
    };
    var expandOrCollapseNodes = function(clients) {
      var text = {};
      if (clients.length === 1) {
        $timeout(function() { // Have to set a $timeout due to init defect in angular-ui-tree
            angular.element('[ui-tree]').scope().expandAll();
          }, 400);
        text = {
          heading: 'Select Your Organization',
          description: 'To begin using Predict, you must specify which Organization context you wish to use. You will be able to change the context from within the app as well.',
          isSingleClient: true
        };
      } else {
        $timeout(function() {
            angular.element('[ui-tree]').scope().collapseAll();
          }, 400);
        text = {
          heading: 'Select Client & Organization',
          description: 'To begin using Predict, you must specify which Client and Organization context you wish to use. Select an Organization from the Client\'s dropdown menu. You will be able to change the context from within the app as well.',
          isSingleClient: false
        };
      }
      return text;
    };

    return {
      getClientKey: getClientKey,
      getApiClientKey: getApiClientKey,
      getOrgKey: getOrgKey,
      getUserLandingUrl: getUserLandingUrl,
      getUserLoginUrl: getUserLoginUrl,
      getUserOrganizations: getUserOrganizations,
      getUserPrimaryOrganization: getUserPrimaryOrganization,
      getOrganizationName: getOrganizationName,
      setUserContext: setUserContext,
      getAccountsPage: getAccountsPage,
      expandOrCollapseNodes: expandOrCollapseNodes
    };
  }
  ]);
})(window.app);
