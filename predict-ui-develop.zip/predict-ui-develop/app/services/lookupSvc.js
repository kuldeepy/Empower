'use strict';
(function (app) {

  app.factory('lookupSvc', ['baseApiUrl', '$http',
  function (baseApiUrl, http) {
    var logError = function (error) {
      console.log(error);
      if (error.data) {
        console.log(error.data.message);
      }
    };

    var getLookupDataById = function (id) {
      return http({
        method: 'GET',
        url: baseApiUrl(true) + 'lookupData/' + id,
        cache: true
      })
      .then(
      function (response) {
        return response.data.results;
      },
      function (error) {
        logError(error);
      }
      );
    };

    return {
      getLookupDataById: getLookupDataById
    };
  }
  ]);
})(window.app);
