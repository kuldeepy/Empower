'use strict';

(function(app) {

  app.factory('util', [ '_', function( _ ) {


    var isPropertyValueInCollection = function (arr, propValue, propName) {
      return (_.any(arr, function (item) { return item[propName].toUpperCase() === propValue.toUpperCase(); }));
    };

    var generateUniqueCopyOfName = function (arr, nameToCopy, namePropertyName){
      var copyOfRegEx = /Copy \d*\s?of /;
      if (copyOfRegEx.test(nameToCopy)){
        nameToCopy = nameToCopy.replace(copyOfRegEx, '');
      }
      var uniqueName = 'Copy of ' + nameToCopy;
      var i = 1;
      var namePropertyMatch = {};
      namePropertyMatch[namePropertyName] = uniqueName;
      while(_.any(arr, namePropertyMatch)){
        uniqueName = 'Copy ' + [i] + ' of ' + nameToCopy;
        namePropertyMatch[namePropertyName] = uniqueName;
        i+=1;
      }
      return uniqueName;
    };

    return {
      generateUniqueCopyOfName: generateUniqueCopyOfName,
      isPropertyValueInCollection: isPropertyValueInCollection
    };
  }
  ]);
})(window.app);
