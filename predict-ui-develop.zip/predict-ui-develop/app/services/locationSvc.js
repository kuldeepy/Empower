'use strict';

(function(app) {

	app.factory('locationSvc', ['$http', 'baseApiUrl',
		function(http, baseApiUrl) {
			var listLocations = function() {
				return http({
					method: 'GET',
					url: baseApiUrl() + 'locations',
					cache: true
				})
				.then(
					function(response) {
						return response.data.results.Locations;
					}
				);
			};

			return {
				listLocations : listLocations
			};

		}
	]);
})(window.app);