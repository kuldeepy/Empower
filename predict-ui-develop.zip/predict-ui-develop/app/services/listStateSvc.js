(function (app) {
  'use strict';

  app.factory('listStateSvc', ['listSvc',
  function (listSvc) {
    var model;
    var isMarketingChannelNotDefined;
    var createNewList = function () {
      return listSvc.createNewId().then(function (newId) {
        return {
          'Id': newId,
          'MarketingChannelId': 0,
          'LocationDescriptors': [],
          'FilterValueSelections': [{ FilterName: 'ValidAddress', ExcludeValues: ['False'], IncludeValues: [] }],
          'InExclusionPastListIds':[],
          'ExcludedPastListIds': [],
          'IncludedPastListIds': [],
          'SeedListIds': [],
          'Segments': [],
          'IsEditable': true,
          'IsTransient': true,
          'ExcludeHoldouts': true,
          'DistributeByHousehold': true,
          'IsActive': true,
          'LastCalculation': [],
          'CurrentUIState': {
            'CurrentLocationIndex': 0,
            'hasVisited': {},
            'isControlGroupDirty' : false
          }
        };
      });
    };

    var hasETLDataUpdated = function (etlDate) {
      var hasETLUpdated = (model.UpdatedOn ? new Date(model.UpdatedOn) : new Date(model.CreatedOn)) < new Date(etlDate);
      return (hasETLUpdated && ((model.CurrentUIState.countUpdateStatus !== 'Updated') ||
        (model.CurrentUIState.countUpdateStatus === 'Update')));
    };

    var hasMarketingChannel = function () {
      return (((model.CurrentUIState.isComplete === true && (!model.MarketingChannelId || model.MarketingChannelId === 0)) && model.PullDate === null));
    };

    var isLocationDefined = function () {
      return (model.LocationDescriptors && model.LocationDescriptors.length > 0);
    };

    var hasDistribution = function () {
      return (model.Distribution && model.Distribution.hasOwnProperty('DesiredCount') && model.Distribution.DesiredCount > 0);
    };

    var currentListState = {
      get: function () {
        return model;
      },
      set: function (data) {
        console.log('listStateSvc.set ' + data);
        model = data;
        isMarketingChannelNotDefined = undefined;
      },
      clear: function () {
        model = undefined;
        isMarketingChannelNotDefined = undefined;
      },
      createList: createNewList,
      hasETLDataUpdated: hasETLDataUpdated,
      hasMarketingChannel: hasMarketingChannel,
      isLocationDefined: isLocationDefined,
      hasDistribution: hasDistribution,
      isMarketingChannelNotDefined: isMarketingChannelNotDefined
    };
    return currentListState;
  }
  ]);

})(window.app);
