(function (app) {
  'use strict';

  var tokenKey = 'auth.token';
  var usernameKey = 'auth.username';
  var fullNameKey = 'auth.fullname';
  var rolesKey = 'auth.roles';
  var isAdminRole = 'auth.adminrole';
  var expiresAtKey = 'auth.expiresAt';
  var issuedAtKey = 'auth.issuedAt';
  var refreshingFlagKey = 'auth.isRefreshing';
  var expiresInKey = 'auth.expiresIn';
  var passwordExpiresBy = 'auth.passwordExpiresBy';
  var userOrgKey = 'auth.userOrgKey';
  var userClientKeys = 'auth.userClientKeys';
  var lastAPICallTimeKey = 'lastAPICallTime';
  var remainingAlertSecondsKey = 'remainingAlertSeconds';
  var selectLocationKey = 'selectLocation.locations';
  var selectedClientKey = 'clientName';
  var selectedOrgKey = 'orgName';
  var facilitiesKey = 'selectedLocation.facilities';
  var userLocationsKey = 'user.AllowedLocationIds';
  var pastListInclusions = 'pastLists.included';
  var externalTokens = 'auth.externalTokens';
  var clientDataAvailThroughDate = 'dataAvailThroughDate';

  app.factory('authSvc', ['$http', '$q', '$rootScope', 'userContextSvc', 'sessionSvc',
  function (http, q, rootScope, userContextSvc, sessionSvc) {

    var systemAdministratorRole = 'SysAdmin';
    var clientAdministratorRole = 'ClientAdministrator';
    var allListCriteriaRole = 'AllListCriteria';

    var baseApiUrl = app.api.root + 'clients/' + userContextSvc.getApiClientKey() + '/';
    http.defaults.headers.post['Content-Type'] = 'application/json';

    var logError = function (error) {
      if (error.data !== undefined && error.data.message !== undefined && error.data.message !== null) {
        console.log(error.data.message);
      }
      console.log(error);
    };

    var extractTokenPayload = function (token) {
      var payloadSegment = token.split('.')[1];
      var decoded = base64Decode(payloadSegment);
      return JSON.parse(decoded);
    };

    var base64Decode = function (str) {
      var output = str.replace('-', '+').replace('_', '/');
      switch (output.length % 4) {
        case 0:
          break;
        case 2:
          output += '==';
          break;
        case 3:
          output += '=';
          break;
        default:
          output = ''; // invalid base64 string
          break;
      }
      return window.atob(output);
    };

    var getTokenExpirationDate = function () {
      return getTokenDateFromSession(expiresAtKey);
    };

    var getTokenIssueDate = function () {
      return getTokenDateFromSession(issuedAtKey);
    };

    var getTokenDateFromSession = function (key) {
      var intDate = sessionSvc.get(key);
      if (intDate !== null) {
        return new Date(parseInt(intDate) * 1000);
      }
      return null;
    };

    var storeAuthData = function (token) {
      if (!token || token === null || token === 'null') {
        return;
      }

      sessionSvc.clear(refreshingFlagKey);
      var payload = extractTokenPayload(token);
      var profile = payload.profile;
      var idToken = {};
      /* jshint ignore:start */
      if (payload.oauthToken && payload.oauthToken.id_token) {
        idToken = extractTokenPayload(payload.oauthToken.id_token);
      }
      /* jshint ignore:end */
      sessionSvc.set(tokenKey, token);
      if (idToken.externalTokens){
        sessionSvc.set(externalTokens, JSON.stringify(idToken.externalTokens));
      }
      sessionSvc.set(usernameKey, profile.Username);
      sessionSvc.set(fullNameKey, profile.FirstName + ' ' + profile.LastName);
      sessionSvc.set(rolesKey, JSON.stringify(profile.Roles));
      if (isSystemAdministrator() || isClientAdministrator()) {
        sessionSvc.set(isAdminRole, true);
      }
      sessionSvc.set(issuedAtKey, payload.iat);
      sessionSvc.set(expiresAtKey, payload.exp);
      sessionSvc.set(userOrgKey, JSON.stringify(profile.Organizations));
      sessionSvc.set(userClientKeys, JSON.stringify(profile.UserClientKeys));
      sessionSvc.set(expiresInKey, payload.exp - payload.iat - app.sessionExpiryAlertSeconds);
      sessionSvc.set(passwordExpiresBy, profile.DaysLeftForPasswordExpiry);
      sessionSvc.set(userLocationsKey, JSON.stringify(profile.AllowedLocationIds));
      rootScope.$broadcast('Authenticated');
    };

    var clearAuthData = function () {
      sessionSvc.clear(tokenKey);
      sessionSvc.clear(rolesKey);
      sessionSvc.clear(isAdminRole);
      sessionSvc.clear(usernameKey);
      sessionSvc.clear(fullNameKey);
      sessionSvc.clear(expiresAtKey);
      sessionSvc.clear(refreshingFlagKey);
      sessionSvc.clear(passwordExpiresBy);
      sessionSvc.clear(userOrgKey);
      sessionSvc.clear(expiresInKey);
      sessionSvc.clear(issuedAtKey);
      sessionSvc.clear(lastAPICallTimeKey);
      sessionSvc.clear(remainingAlertSecondsKey);
      sessionSvc.clear(selectLocationKey);
      sessionSvc.clear(selectedClientKey);
      sessionSvc.clear(userClientKeys);
      sessionSvc.clear(selectedOrgKey);
      sessionSvc.clear(facilitiesKey);
      sessionSvc.clear(userLocationsKey);
      sessionSvc.clear(pastListInclusions);
      sessionSvc.clear(clientDataAvailThroughDate);
      rootScope.$broadcast('AuthRevoked');
    };

    var initiateTokenRefresh = function () {
      if (sessionSvc.get(refreshingFlagKey) === null) {
        console.log('Initiating Auth Token refresh...');
        sessionSvc.set(refreshingFlagKey, true);
        http({
          method: 'PUT',
          url: baseApiUrl + 'authToken'
        }).success(function (data) {
          if (data.results.IsAuthorized) {
            var token = data.results.Token;
            if (token) {
              storeAuthData(token);
              console.log('Auth Token refreshed...');
            }
          }

        }).error(function (data) {
          clearAuthData();
          logError(data);
        });
      }
    };

    var revokeToken = function () {
      console.log('revoking token');
      var deferred = q.defer();
      http({
        method: 'DELETE',
        url: baseApiUrl + 'authToken'
      }).success(function (data) {
        clearAuthData();
        deferred.resolve(data.results.IsRevoked);
      }).error(function (data) {
        logError(data);
        clearAuthData();
      });
      window.location.replace(userContextSvc.getUserLoginUrl());
      return deferred.promise;
    };

    var isTokenExpired = function (expDate) {
      return expDate !== null && new Date() >= expDate;
    };

    var getRoles = function () {
      var rolesString = sessionSvc.get(rolesKey);
      if (rolesString !== undefined && rolesString !== null && rolesString !== '') {
        return JSON.parse(rolesString);
      }
      return [];
    };

    var isSystemAdministrator = function () {
      return getRoles().indexOf(systemAdministratorRole) !== -1;
    };

    var isClientAdministrator = function () {
      return getRoles().indexOf(clientAdministratorRole) !== -1;
    };

    var showAllListCriteria = function () {
      return getRoles().indexOf(allListCriteriaRole) !== -1 || isSystemAdministrator();
    };

    var getAllowedUserLocationsIds = function () {
      var locationString = sessionSvc.get(userLocationsKey);
      if (locationString !== undefined && locationString !== null && locationString !== '') {
        return JSON.parse(locationString);
      }
      return [];
    };

    var getClientKeys = function () {
      return JSON.parse(sessionSvc.get(userClientKeys));
    };

    var getUserClientKey = function () {
      if (!isClientAdministrator() && !isSystemAdministrator()) {
        var clientKeys = getClientKeys();
        return clientKeys ? clientKeys[0].ClientKey : null;
      }
      return null;
    };

    var getAdminClientKeys = function () {
      if (isClientAdministrator() || isSystemAdministrator()) {
        return getClientKeys();
      }
    };

    var getLegacyUserId = function () {
      var clientKeys = getClientKeys();
      return _.result(_.find(clientKeys, function (clientKey) {
        return clientKey.ClientKey === userContextSvc.getApiClientKey();
      }), 'LegacyUserId');
    };

    return {
      getToken: function () {
        var token = sessionSvc.get(tokenKey);
        if (token !== null && sessionSvc.get(refreshingFlagKey) === null) {
          var expDate = getTokenExpirationDate();
          if (expDate !== null) {
            if (isTokenExpired(expDate)) {
              console.log('Auth Token is expired.  No longer authorized to make API calls.');
              clearAuthData();
              token = null;
            }
          }
        }
        return token;
      },

      setToken: function (token) {
        sessionSvc.set(tokenKey, token);
      },

      getAllowedUserLocationIds: getAllowedUserLocationsIds,

      logOut: function () {
        return revokeToken();
      },
      hasToken: function () {
        return !!this.getToken();
      },
      hasExternalTokens: function(){
        return !!sessionSvc.get(externalTokens);
      },
      getExternalTokens: function(){
        return JSON.parse(sessionSvc.get( externalTokens ));
      },
      getUsername: function () {
        return sessionSvc.get(usernameKey);
      },
      getFullName: function () {
        return sessionSvc.get(fullNameKey);
      },
      getRoles: getRoles,

      isSystemAdministrator: isSystemAdministrator,

      isClientAdministrator: isClientAdministrator,

      getClientKeys: getClientKeys,

      getUserClientKey: getUserClientKey,

      getAdminClientKeys: getAdminClientKeys,

      showAllListCriteria: showAllListCriteria,

      getTokenExpirationDate: getTokenExpirationDate,

      isLegacyUser: function () {
        return getLegacyUserId() !== null && getLegacyUserId() !== '';
      },

      getLegacyUserId: getLegacyUserId,

      getTokenIssueDate: getTokenIssueDate,

      createToken: function (message) {
        console.log('creating token');
        message.Username = message.Username.toLowerCase();
        var deferred = q.defer();
        http({
          method: 'POST',
          url: baseApiUrl + 'authToken',
          data: JSON.stringify(message)
        }).success(function (data) {
          if (data.results.IsAuthorized) {
            var token = data.results.Token;
            storeAuthData(token);
          }
          deferred.resolve(data.results);
        }).error(function (data, status) {
          if (status === 0) {
            if (data.results.IsAuthorized) {
              var token = data.results.Token;
              storeAuthData(token);
            }
            deferred.resolve(data.results);
          }
          logError(data);
        });
        return deferred.promise;
      },

      forgotPassword: function (userName) {
        var deferred = q.defer();
        http({
          method: 'POST',
          url: baseApiUrl + 'accountRecovery',
          data: { 'Username': userName.toLowerCase() }
        }).success(function (data) {
          deferred.resolve(data);
        }).error(function (data, status) {
          console.log('status:' + status);
          console.log('data:' + data);
          if (status === 0) {
            if (data) {
              deferred.resolve(data);
            } else {
              deferred.reject(data);
            }
          }
        });
        return deferred.promise;
      },

      refreshToken: initiateTokenRefresh,
      clearAuthSession: clearAuthData,
      storeAuthData: storeAuthData
    };
  }
  ]);
}(window.app));