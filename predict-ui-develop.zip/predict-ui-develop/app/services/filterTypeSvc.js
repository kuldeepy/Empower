'use strict';

(function (app) {

  app.factory('filterTypeSvc', ['$http', 'baseApiUrl',
  function (http, baseApiUrl) {

    var logError = function (error) {
      console.log(error.data.message);
      console.log(error);
    };

    var loadFilterTypeData = function (filterId) {
      return http({
        method: 'GET',
        url: baseApiUrl() + 'filterTypes/' + filterId,
        cache: true
      }).then(
      function (response) {
        return response.data.results.filterTypeData;
      },
      function (error) {
        logError(error);
      });
    };

    return {
      loadFilterTypeData: loadFilterTypeData
    };

  }
  ]);
})(window.app);