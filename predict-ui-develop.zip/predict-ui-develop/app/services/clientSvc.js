﻿'use strict';
(function (app) {
  app.factory('clientSvc', ['$http', 'userContextSvc', 'sessionSvc', 'baseApiUrl', 'authSvc',
  function (http, userContextSvc, sessionSvc, baseApiUrl, authSvc) {
    //TODO: put this in a more global location
    var logError = function (error) {
      if (error) {
        console.log(error);
        if (error.data) {
          console.log(error.data.message);
        }
      }
    };
    var loadClients = function (clientKey) {
      var routePath = baseApiUrl(true) + 'listclients';
      if (clientKey) {
        routePath = baseApiUrl(true, clientKey) + 'listclients?Id=' + clientKey;
      }
      return http({
        method: 'GET',
        url: routePath,
        cache: true
      }).then(
      function (response) {
        var clients = response.data.results.Clients;
        if (!clientKey) {
          return clients;
        }
        else if (clients.length > 0) {
          return clients[0];
        }
      },
      function (error) {
        logError(error);
      });
    };
    var getAllowedClientOrg = function() {
      var allowedClients = _.pluck(authSvc.getClientKeys(),  'ClientKey');
      var allowedOrgs = _.pluck(userContextSvc.getUserOrganizations(), 'OrgKey');
      return loadClients(allowedClients.length === 1 ? allowedClients[0] : undefined).then(function (clients) {
        if (!_.isArray(clients)){ clients = [clients]; }
        return _.filter(clients, function (client) {
          client.Organizations = _.filter(client.Organizations, function (org){
            return (authSvc.isClientAdministrator() || authSvc.isSystemAdministrator()) || _.contains(allowedOrgs, org.Key);
          });
          return authSvc.isSystemAdministrator() || _.contains(allowedClients, client.Key);
        });
      });
    };

    return {
      loadClients: loadClients,
      getAllowedClientOrg: getAllowedClientOrg
    };
  }
  ]);
})(window.app);
