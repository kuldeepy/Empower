'use strict';
//This allows our postinstall script to not fail when we don't install dev dependencies
// as in npm install --production
var fs = require('fs');
var sys = require('sys')
var exec = require('child_process').exec;

try {
  var stats = fs.lstatSync('./node_modules/grunt');
  if (stats.isDirectory()) {
    exec('grunt postinstall', puts);
  }
}
catch (e) {
  console.log('assuming production npm install, skipping grunt postinstall');
}

function puts(error, stdout, stderr) { sys.puts(stdout); } // jshint ignore:line