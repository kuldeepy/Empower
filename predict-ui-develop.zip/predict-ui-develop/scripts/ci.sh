mkdir jshint &&\
npm test &&\
npm run-script jshint > jshint/jshint_results.txt
