var fs = require('fs');
var packageJson = require('../package.json');

// the Team City current build number is exposed as the environment variable BUILD_NUMBER
if(process.env.BUILD_NUMBER != null) {
  version = packageJson.version;
  packageJson.version = version + '+' + process.env.BUILD_NUMBER;
  console.log('Updating version to: ' + packageJson.version);
  fs.writeFileSync('./package.json', JSON.stringify(packageJson, null, 2));
}
