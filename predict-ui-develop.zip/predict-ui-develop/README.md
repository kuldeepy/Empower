# predict-ui
This project contains the source code of the MEDSEEK Predict web user interface.

# build & run
## 1.) Get the source
```
$> git clone https://github.com/medseek-engineering/predict-ui.git
```
## 2.) Install 3rd party dependencies
### Ruby and Sass installation
Predict has been updated to using Sass for all CSS styling. Because Sass compilation is now a part of the build process, your local environment needs to have Ruby and Compass installed. Run the following steps in order. If you have any questions or issues, please contact Martin Castre at martin.castre@influencehealth.com.

#### Ruby Installation For Windows
1.) Run `npm install` to get the latest packages.  

2.) Go to  [RubyInstaller for Windows](http://rubyinstaller.org/) and click the download button. Choose Ruby 2.0.0p647 from the RubyInstallers list.  

3.) Run the installation wizard with all options set to default.  

4.) Open the ruby shell or set up in Powershell (your preference). Run the command `ruby -v` to ensure installation was successful.  

5.) `cd` to your app root and run the command `gem install bundler`. This will install the bundler gem, which will allow you to download a set of gem dependencies associated to the project.  

6.) After installing bundler, run `bundle install`. This will install the dependencies listed in the Gemfile.  

7.) Sometimes some dependencies may not fully install. In this case, run `gem install compass`, `gem install sass-globbing`, `gem install bootstrap-sass` and `gem install breakpoint`. Running `gem list` will print out a list of the gems installed, make sure you have all those gems.  

8.) All set! Now you should be able to run `grunt build` without any issues. Good hunting!  


#### Ruby Installation For Mac
Installing Ruby on Mac is a little different since Mac already comes with Ruby installed, but you don't want to use the native ruby set. Follow these instructions on installing [rvm](https://rvm.io/).  

1.) First make sure you have the latest Command Line Tools installed `xcode-select --install` and XCode version. You can also log in to [Apple developer](http://developer.apple.com/downloads) to download CLT.  

2.) From the rvm website, run the command `\curl -sSL https://get.rvm.io | bash -s stable`, or if you have homebrew installed, `curl -L get.rvm.io | bash`.  

3.) Run `ruby -v` to verify successful installation.  

4.) `cd` to your app root and run the command `gem install bundler`. This will install the bundler gem, which will allow you to download a set of gem dependencies associated to the project.  

5.) After installing bundler, run `bundle install`. This will install the dependencies listed in the Gemfile.  

6.) Sometimes some dependencies may not fully install. In this case, run `gem install compass`, `gem install sass-globbing`, `gem install bootstrap-sass` and `gem install breakpoint`. Running `gem list` will print out a list of the gems installed, make sure you have all those gems.  

7.) All set! Now you should be able to run `grunt build` without any issues. Good hunting!  

## 3.) Install node dependencies and compile sass
````
$> npm install
````

## 4.) Run the server
````
$> grunt run
````
You should see output similar to: **Predict UI, listening on port 4000**  
Visit **localhost:4000** to view the running website.

## testing
You may execute unit tests by running the command:
````
$> grunt build
````


