'use strict';

// require dependencies
var ui = require('ui-core')();

// apply UI extensions
ui.use(require('./extend'));
ui.use(require('ui-patterns'));
ui.use(require('iui-general'));
ui.use(require('iui-table'));

// apply additional modules
ui.use(require('./app/resources/additional-modules.js'));

// start the UI server
ui.start();
