module.exports = function (config) {
  'use strict';
  config.set({
    basePath: '',

    exclude: [],

    port: 8091,

    runnerPort: 9100,

    colors: true,

    autoWatch: true,

    logLevel: config.LOG_INFO,

    browsers: ['PhantomJS'],

    captureTimeout: 12000,

    browserNoActivityTimeout: 25000,

    singleRun: true,

    plugins: [
      'karma-jasmine',
      'karma-phantomjs-launcher',
      'karma-chrome-launcher',
      'karma-coverage',
      'karma-ng-html2js-preprocessor',
      'karma-spec-reporter',
      //This is incompatiable with karma dependencies as of Mar 11, 2014.
      //When this is updated for karma@>0.11.x then we can reenable this.
      //See this branch for more info: https://github.com/dtabuenc/karma-html-reporter/tree/karma-0.11
      //'karma-html-reporter'
    ],

    coverageReporter: {
      type: 'html',
      dir: 'coverage/'
    },

    htmlReporter: {
      outputDir: 'karma_html',
      templatePath: __dirname + '/node_modules/karma-html-reporter/jasmine_template.html'
    },

    ngHtml2JsPreprocessor: {
      stripPrefix: 'app/',
      prependPrefix: '/',
      moduleName: 'templates'
    },

    files: [
      // app core dependencies
      'test/test-helper.js',
      'node_modules/ui-core/lib/content/js/jquery.js',
      'node_modules/ui-core/lib/content/js/angular.js',
      'app/js/angular-animate.js',
      'node_modules/ui-core/lib/content/js/main.js',
      'test/angular-mocks.js',
      'app/js/angular-idle.min.js',
      'app/js/ui-bootstrap-tpls-0.11.0.min.js',
      'app/js/angular-ui-router.min.js',
      'app/js/angular-touch.min.js',
      'app/js/lodash.js',
      'app/js/ng-grid-flexible-height.js',
      'app/js/ui-tree/angular-ui-tree.min.js',
      // app module dependencies

      'node_modules/ng-device-detector/bower_components/re-tree/re-tree.min.js',
      'node_modules/ng-device-detector/ng-device-detector.min.js',
      'app/services/*.js',
      'app/modules/**/*.js',
      'app/modules/**/controllers/*.js',
      'app/modules/**/directives/*.js',
      'app/directives/*.js',
      'app/layouts/**/*.js',
      'app/services/*.js',

      // test scripts
      'test/**/*.test.js',

       //directive templates

      'app/**/*.html',
      'app/images/icons-svg/icon-search.svg'
    ],

    reporters: ['coverage', 'spec', 'html'],

    preprocessors: {
      'app/modules/**/controllers/*.js': ['coverage'],
      //'app/directives/**/*.js': ['coverage'],
      'app/directives/*.js': ['coverage'],
      'app/modules/**/directives/*.js': ['coverage'],
      'app/modules/session/*.js': ['coverage'],
      'app/layouts/**/*.js': ['coverage'],
      'app/lib/*.js': ['coverage'],
      'app/services/*.js': ['coverage'],
      'app/**/*.html': ['ng-html2js'],
      'app/images/icons-svg/icon-search.svg' : ['ng-html2js']
    },

    frameworks: ['jasmine']
  });
};
