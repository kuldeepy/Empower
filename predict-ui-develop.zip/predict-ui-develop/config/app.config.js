var appRoot = '/';
var apiRoot = 'http://localhost:3000/predict/v1/';

// export app config
module.exports = {
  client: {
    debug: true,
    head: {
      stylesheets: [
        '/css/ng-grid.min.css',
        '/css/jquery-ui.css',
        '/css/jslider.css',
        '/css/leaflet.css',
        '/css/L.Control.Pan.css',
        '/css/L.Control.Pan.ie.css',
        '/css/bootstrap-select.min.css',
        '/css/MarkerCluster.css',
        '/css/MarkerCluster.Default.css',
        '/css/datepicker.css',
        '/css/font-awesome.min.css',
        '/css/angular-ui-tree.min.css',
        '/themes/default/main.css',
        '/css/leaflet-PruneCluster.css'
      ],
      scripts: [
        '/js/bootstrap.min.js',
        '/js/common.js',
        '/js/jquery.capslockstate.js',
        '/js/capslock-helper.js',
        '/js/angular-ui-router.min.js',
        '/js/jquery-ui.min.js',
        '/js/ui-tree/angular-ui-tree.min.js',
        '/js/jSlider/jshashtable-2.1_src.js',
        '/js/jSlider/jquery.numberformatter-1.2.3.js',
        '/js/jSlider/tmpl.js',
        '/js/jSlider/jquery.dependClass-0.1.js',
        '/js/jSlider/draggable-0.1.js',
        '/js/jSlider/jquery.slider.js',
        '/js/angular-touch.min.js',
        '/js/leaflet.js',
        '/js/Google.js',
        '/js/L.Control.Pan.js',
        '/js/bootstrap-select.min.js',
        '/js/ng-grid-flexible-height.js',
        '/js/leaflet.markercluster.js',
        '/js/FileSaver.js',
        '/js/bootstrap-datepicker.js',
        '/js/leaflet-PruneCluster.js',
        '/js/circle-progress.js',
        'https://maps.googleapis.com/maps/api/js?v=3.16&key=AIzaSyBBiFjH-NQmKAqhfFj-IPcR7ULXBs0FkbA&sensor=false',
        'https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.2.13/angular-animate.min.js',
        'https://cdnjs.cloudflare.com/ajax/libs/lodash.js/2.4.1/lodash.js',
        'https://cdnjs.cloudflare.com/ajax/libs/angular-ui-bootstrap/0.12.1/ui-bootstrap-tpls.min.js',
        '/js/angular-idle.min.js'
      ]
    },
    app: {
      root: appRoot,
      api: {
        root: apiRoot
      },
      routes: {
        href: appRoot + 'routes.json'
      },
      superTenantClientKey: 'system',
      baseLoginUrl: '/session/login',
      sessionExpiryAlertSeconds: 120,
      autoRefreshTokenInterval: 60,
      defautLrtResponseTimeout: 60000
    }
  },
  server: {
    port: process.env.PORT || 4000
  }
};
