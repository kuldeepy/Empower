'use strict';

var fs = require('fs');

module.exports = {
  config: function(conf) {
    //'conf' unused now, but will be in the future.
    /* jshint unused: false*/

  },
  app: function (app, conf) {
    //'conf' unused now, but will be in the future.
    /* jshint unused: false*/
  }
  // resolve may be used to supply a custom module resolver
  //resolve:
};

function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) { return next(); }
  res.redirect('/login');
}
