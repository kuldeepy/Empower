#!/bin/bash

Command=$1
shift
CommandArguments=$@
ServicesDir=$PWD/services

echo Command = $Command, CommandArguments = $CommandArguments
#echo ServicesDir = $ServicesDir
echo

function Cmd_build()
{
    echo Building $1
    if [ -f package.json ]; then
        npm install
    elif [ -f build.xml ]; then
        ant
    fi
}

function Cmd_start()
{
    echo Starting $1
    Cmd="forever start -a -w --minUptime 1000 --spinSleepTime 10000 --uid $1 $2 $CommandArguments"
    echo $Cmd
    $Cmd
}

function Cmd_stop()
{
    echo Stopping $1
    forever stop $1
}

function Cmd_restart()
{
    echo Restarting $1
    Cmd_stop $1 $2
    Cmd_start $1 $2
}

cd $ServicesDir
for x in `ls -d */`; do
    Service=${x%%/}
    cd $ServicesDir/$Service
    Script=
    if [ -f $Service.js ]; then
        Script=$Service.js
    elif [ -f service.js ]; then
        Script=service.js
    elif [ -f app.js ]; then
        Script=app.js
    fi
    if [ $Script ]; then
        Cmd_$Command $Service $Script
    else
        echo WARNING: No script found for $Service
    fi
    echo
done
