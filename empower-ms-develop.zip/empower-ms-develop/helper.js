'use strict';

var userArgs = process.argv.slice(2);
var http = require('https');
var fs = require('fs'), serverDir = './application-server';
var nupkg = 'Medseek.Util.MicroServices.ApplicationServer.1.0.5365.35985.nupkg';
var nupkgPackageRepo = 'https://%s@vm-dev-01.medseek.com/nuget-octopus-packages/Medseek.Util.MicroServices.ApplicationServer/%s';
var util = require('util');
var spawn = require('child_process').spawn;
var nugetFile = './application-server/nuget.exe';
var stdin = process.openStdin();
var tty = require('tty');
var path = require('path');

process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

module.exports.install = function(args){
  console.log('installing application server');
  if(!fs.existsSync(serverDir)){
    fs.mkdir(serverDir);
  }
  var file = fs.createWriteStream('./application-server/' + nupkg);
  var uri = util.format(nupkgPackageRepo,args[0],nupkg);
  console.log('downloading ' + uri);
  var request = http.get(uri, function(response) {
    response.pipe(file);
    console.log('downloading nuget.exe');
    downloadNuget('https://www.nuget.org/nuget.exe',fs.createWriteStream(nugetFile),extractPackage);
  });
};

function downloadNuget(uri,file,callback){
  var body = '';
  var request = http.get(uri,function(res){
    console.log('status code: ' + res.statusCode);
    if(res.statusCode === 302)
      console.log('\n\nFollowing http redirect....\n');
    else {
      res.pipe(file);
      callback();
      return;
    }

    res.on('data',function(data){
      body += data;
    });

    res.on('end',function(){
      uri = /href="([^"]+)"/.exec(body)[1];
      console.log(util.format('new uri %s\n', uri));
      downloadNuget(uri,file,callback);
    });
  })
}


if(!userArgs || !userArgs.length){
  throw new Error('Please specify what you want to do: Start,Install, or Stop');
}

function extractPackage(){
  var packagePath = path.dirname('./application-server/' +  nupkg);
  spawn('./application-server/nuget.exe',['install', 'Medseek.Util.MicroServices.ApplicationServer', '-source',path.join(packagePath,nupkg),'-output','./application-server']);

}

function installFromSource(args){
  console.log('extracting file');
  var uri = util.format(nupkgPackageRepo,nupkg);
  var nuget = spawn('./application-server/nuget.exe', ['install','Medseek.Util.MicroServices.ApplicationServer','-Source', uri]);
  nuget.stdout.on('data',function(data){
    var request = data.toString('ascii');
    console.log(request);
    if(request.toLowerCase().indexOf('user') > -1){
      getInput(function(username){
        nuget.stdin.write(username);
      });
    } else if(request.toLowerCase().indexOf('pass') > -1){
      getPassword(function(password){
        nuget.stdin.write(password);
      })
    }
  })
}

module.exports[userArgs[0]](userArgs.splice(1));

function getInput(callback){
  process.stdin.resume();
  process.stdin.setEncoding('utf8');
  process.stdin.on('data', callback);
}

function getPassword(callback) {
  process.stdin.resume();
  process.stdin.setEncoding('utf8');
  process.stdin.setRawMode(true); 
  var password = ''
  process.stdin.on('data', function(password){
    process.stdin.setRawMode(false);
  });
}