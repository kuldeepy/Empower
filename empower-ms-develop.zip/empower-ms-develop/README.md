Empower Micro-Services
======================

The source for Empower micro-services can be found here in the empower-ms
repository, which is authoritatively located in [Medseek-Engineering at GitHub](https://github.com/medseek-engineering/empower-ms.git).

# Overview of this Repository

TODO: Describe repository layout, proper locations for projects, etc.
````
empower-ms
├─ README.md
├─ services
│   ├─ empower-authz
│   ├─ empower-users
│   ├─ example-nodejs
│   │   ├─ package.json
│   │   ├─ example-one.js
│   │   └─ ...
│   ├─ example-netcs
│   │   ├─ package.nuspec
│   │   ├─ Example.Two.csproj
│   │   ├─ ExampleTwo.cs
│   │   └─ ...
│   └─ ...
└─ ...
````

# Overview of Adding A Micro-Service

TODO: Describe the project structure, available tools, etc. as they apply in
      general to all new micro-services.
## Node.js Micro-Services

Node.js and the ih-microservice module are the preferred tool-set for
creating Empower micro-services, and new work should only deviate from this
guidance if a good technical reason exists to justify the choice.


### Patterns and Anti-Patterns for Node.js Micro-Services

TODO: Describe Node.js micro-service patterns and anti-patterns.

### Example Node.js Micro-Service

TODO: Provide an example Node.js micro-service.

### Using the Yeoman generator
You can use the included Yeoman generator to scaffold a new node.js micro-service.

##### One-time setup
1.  Ensure [Yeoman](http://yeoman.io) is installed on your system.
2.  Run `npm install` in the generator-empower-ms directory.
  ```
  cd generator-empower-ms
  npm install
  ```

3.  Install the empower micro-service generator by running `npm link` *from within the generator-empower-ms directory*.
  ```
  npm link
  ```

##### Creating a new micro-service
1. Create a directory for your micro-service within the services directory.

  ```
  cd services
  mkdir my-new-microservice
  ```
2. In the new directory, run `yo empower-ms`.

  ```
  cd my-new-microservice
  yo empower-ms
  ```
3. Follow prompts and allow Yeoman to create the micro-service files.  By default, the name of the micro-service will be the name of the directory.  This is our convention and should be followed.  When prompted, enter a more appropriate description. (The description will be used in the package that is created).
4. Run `npm test` to run your unit tests.
5. Run `node my-new-microservice.js` to start it up.

#### Common command line options

* **ll** log level
* **broker** rabbit mq broker URL

## .NET Micro-Services

Unless there is a good technical reason to do so, the use of .NET for creating
Empower micro-services is discouraged in favor of Node.js.

TODO: Briefly describe the expectations for creating .NET micro-services
      using Medseek.Util.MicroServices.Host and other related packages/tools.

### Patterns and Anti-Patterns for .NET Micro-Services

TODO: Describe .NET micro-service patterns and anti-patterns.

### Example .NET Micro-Service

TODO: Provide an example .NET micro-service.
