'use strict';
var micro = require('ih-microservice');
var xml2js = require('xml2js');

var defaults = {
  id: 'patient-user-relationships',
  debug: true,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'patient-user-relationships',
  defaultReturnBody: true
};

micro(defaults, function(app, logging, microservices, Promise, options, url, _, util) {

  var log = logging.getLogger('patient-user-relationships');
  var knownPgs = {};

  return Promise.all([microservices.bind('empower.patient-user-relationships', searchRelationships),
                      microservices.bind('empower.patient-user-relationships-update-lock-version', updateLockVersion),
                      microservices.bind('empower.patient-user-relationships-update-access-level', updateAccessLevelId),
                      microservices.bind('empower.patient-user-relationships.update-status', updateStatus),
                      microservices.bind('empower.patient-user-relationships-by-userid', getRelationshipsByUserId),
                      microservices.bind('empower.patient-user-relationships-by-patientid', getRelationshipsByPatientId)]);

  function updateAccessLevelId(req){
    log.trace('updateAccessLevelId| req',req);
    var patientId = qp(req.patientId);
    var userId = qp(parseUserId(req.userId));
    var pgId = parsePgId(req.userId);
    var qString = 'Update nModProfileAuthUserRelationship \n' +
    '              SET AccessLevelId = @accessLevelId \n' +
    '              WHERE AuthUserId = @userId \n' +
    '              AND PatientProfileId = @patientId \n' +
    '              SELECT @@ROWCOUNT as rowsUpdated';
    var queryObj = {
      q: qString,
      qp: {
        userId: userId,
        patientId: patientId,
        accessLevelId: qp(req.accessLevelId)
      }
    };

    log.trace('updateAccessLevelId| queryObj', queryObj);
    return query(queryObj,'pg-' + pgId)
      .catch(function(err){
        log.error(err);
        return err;
      });
  }

  function updateStatus(req){
    log.trace('updateAccessLevelId| req',req);
    var patientId = qp(req.patientId);
    var userId = qp(parseUserId(req.userId));
    var pgId = parsePgId(req.userId);
    var qString = 'Update nModProfileAuthUserRelationship \n' +
    '              SET [Status] = ( \n' +
    '                 Select Top 1 Id from nModProfileLookup \n' +
    '                 WHERE TYPE = \'ProfileRelationshipStatus\'  \n' +
    '                 AND Value = @status Order By Id Desc \n' +
    '              ) \n' +
    '              WHERE AuthUserId = @userId \n' +
    '              AND PatientProfileId = @patientId \n' +
    '              SELECT @@ROWCOUNT as rowsUpdated';
    var queryObj = {
      q: qString,
      qp: {
        userId: userId,
        patientId: patientId,
        status: qp(req.status)
      }
    };

    log.trace('updateAccessLevelId| queryObj', queryObj);
    return query(queryObj,'pg-' + pgId)
      .catch(function(err){
        log.error(err);
        return err;
      });
  }

  function updateLockVersion(req){
    log.trace('updateLockVersion| req', req);
    var patientId = qp(req.patientId);
    var userId = qp(parseUserId(req.userId));
    var pgId = parsePgId(req.userId);
    var qString = 'Update nModProfileAuthUserRelationship \n' +
    '              SET LockVersion = (@lockVersion + 1) \n' +
    '              WHERE AuthUserId = @userId \n' +
    '              AND PatientProfileId = @patientId \n' +
    '              AND LockVersion = @lockVersion \n' +
    '              SELECT @@ROWCOUNT as rowsUpdated';

    var queryObj = {
      q: qString,
      qp: {
        userId: userId,
        patientId: patientId,
        lockVersion: qp(req.lockVersion, 'Int')
      }
    };

    log.trace('updateLockVersion| queryObj', queryObj);
    return query(queryObj,'pg-' + pgId)
      .then(_.first)
      .catch(function(err){
        log.error(err);
        return err;
      });
  }

  function searchRelationships(req,mc) {
     log.trace('searchRelationships req', req);
     var pgId = parsePgId(req.userId);
     return querySource(req, pgId)
      .then(bindFirstAccessLevel)
      .catch(function(err){
        log.error(err);
        return err;
      });
  }

  function getRelationshipsByPatientId(req,mc){
    log.trace('getRelationshipsByPatientId req:', req);
    var pgId = parsePgId(req.userId);
    delete req.userId;
    return querySource(req, pgId)
      .tap(function(data){
        log.trace('result from query',data);
      })
      .then(bindAllAccessLevels)
      .catch(function(err){
        log.error(err);
        return err;
      });
  }

  function getRelationshipsByUserId(req,mc){
    var pgId = parsePgId(req.userId);
    return querySource(req,pgId)
      .tap(function(data){
        log.debug('result from query',data);
      })
      .then(bindAllAccessLevels)
      .catch(function(err){
        log.error(err);
        return err;
      });
  }

  function bindAllAccessLevels(relationships){
    var promises = [];
    relationships.forEach(function(relationship){
      promises.push(bindAccessLevel(relationship));
    });
    return Promise.all(promises).then(function(relations){
      log.trace('bindAllAccessLevels relations: ', relations);
      return relations;
    });
  }

  function filterForPatient(req){
    return function(db){
      req.userId = undefined;
      return db;
    };
  }

  function bindFirstAccessLevel(relationships){
    return bindAccessLevel(relationships[0]);
  }

  function bindAccessLevel(relationship){
    if (!relationship){
      return {};
    }

    return toJson(relationship.permissions).then(function(p){
      relationship.permissions = p;
      return relationship;
    });
  }

  function toJson(permissionsXml) {
    if (permissionsXml === null) {
      return Promise.resolve([]);
    }
    var parser = new xml2js.Parser({
      explicitArray: false
    });
    return Promise.promisify(parser.parseString)(permissionsXml).then(function(res) {
      return res.permissions.permission;
    }).catch(function() {
      return [];
    });
  }

  function querySource(req,pgId){
    var qString = 'SELECT \n' +
  '       [AuthUserId] as userId, \n' +
  '       [PatientProfileId] as patientId, \n' +
  '       [RelationshipClassification] as relationship, \n' +
  '       p.[FirstName] as patientFirstName, \n' +
  '       p.[LastName] as patientLastName, \n' +
  '       p.[uniqueId], \n' +
  '       p.[gender], \n' +
  '       p.[emailAddress] as patientEmail, \n' +
  '       l.[value] as status, \n' +
  '       r.[accessLevelId], \n' +
  '       a.[permissions], \n' +
  '       a.[portalId], \n' +
  '       a.[name] as accessLevel, \n' +
  '       pr.[Name] as portalName, \n' +
  '       r.[LockVersion] as lockVersion \n' +
  '       FROM [nModProfileAuthUserRelationship] r \n' +
  '       INNER JOIN nModProfilePatients p on p.id = r.PatientProfileId \n' +
  '       INNER JOIN nModProfileLookup l on ' + (req.all ? '' : 'l.[Type] IN (\'ProfileRelationshipStatus\',\'Age of Majority Override\') AND ') + ' l.Id = r.[Status] \n' +
  '       INNER JOIN nModProfileAccessLevels a on a.Id = r.AccessLevelId \n' +
  '       INNER JOIN CmsPortals pr on pr.Id = a.portalId \n' +
  '       WHERE ';

    var queryObject = {
      qp: {}
    };
    if(req.userId){
      var userId = parseUserId(req.userId);
      queryObject.qp.userId = qp(userId);
      qString += ' r.AuthUserId = @userId ';
    }
    if(req.patientId){
      queryObject.qp.patientId = qp(req.patientId);
      qString += ((req.userId ? ' AND ' : ' ') + 'r.PatientProfileId = @patientId');
    }
    if(req.medseekId){
      queryObject.qp.medseekId = qp(req.medseekId);
      qString += (((req.userId || req.patientId) ? ' AND ' : ' ') + ' p.uniqueId = @medseekId');
    }
    queryObject.q = qString;
    log.debug('querySource| qString', qString);
    return query(queryObject,pgId);
  }

  function parseUserId(userId){
    var match = /[\/^]users\/([^\/]+)/.exec(userId);
    return match ? match[1] : userId;
  }

  function parsePgId(userId){
    log.trace('parsing pgId from userId', userId);
    var match = /[\/^]?empower\/pg-([^\/]+)/.exec(userId);
    log.trace('parsePgId match',match);
    return parseInt(match[1],10);
  }

  function query(q,pgId){
    log.debug('query q',q);
    log.trace('query pgId:',pgId);
    return microservices.call('empower.v6.portal-groups.mssql.query.'+ pgId,q)
      .tap(function(results){
        log.trace('get| query results', util.inspect(results, { colors: true, depth: null }));
      })
      .then(function(results){
        if(typeof(results.error) !== 'undefined'){
          throw new Error('Error running query: ' + results.error);
        }
        return results;
      });
  }

  function qp(value, type) {
      var result = {
        type: type || 'NVarChar',
        value: value,
        length: value.length
      };
      log.trace('qp| result', result);
      return result;
  }
});
