'use strict';
var chai = require('chai');
chai.use(require('chai-as-promised'));
chai.use(require('sinon-chai'));
var expect = chai.expect;

var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var _ = require('lodash');

describe('empower-portal-groups.js',function(){
  var portalGroups,mockMs,mockLog,mockMicroservices,options,mockLogger,mockInject, getFunc, mockDb,queryFunc;
  beforeEach(function(){
    mockMs = sinon.stub();
    mockLog = sinon.stub({
      debug: function(){},
      error: function(){},
      trace: function(){}
    });
    mockLogger = {
      getLogger: function(){
        return mockLog;
      }
    };
    mockMicroservices = {
      bind: function(name,func){
        if(name === 'empower.v6.portal-groups.get.#'){
          getFunc = func;
        } else if(name === 'empower.v6.portal-groups.mssql.query.#'){
          queryFunc = func;
        }
      },
      call: function(){}
    };
    mockInject = {
      child: function(){
        return function(func){
          return func;
        };
      }
    };
    mockDb = sinon.stub({
      query: function(){}
    });
    options = { mssql: 'mssql://user:password@localhost/empower'};
    mockDb.query.returns(Promise.resolve([]));
    mockMs.yields(_,mockInject,mockLogger,mockMicroservices,options,Promise,require('url'));
    portalGroups = proxyquire.noCallThru()('../empower-portal-groups',{
      'ih-microservice': mockMs,
      './db.js': mockDb
    });

  });
  describe('get',function(){
    var request;
    beforeEach(function(){
      request = {
        id: '12345'
      };
    });
    it('should inject the proper where clause if the request contains an id',function(done){
      getFunc(request).then(function(){
        expect(mockDb.query.args[0][0].q).to.contain('WHERE siteId = @pgId OR directoryName = CAST(@pgId as NVarChar)');
        done();
      }).catch(done);
    });
    it('should not contain the where clause when request does not contain an id property',function(done){
      request.id = undefined;
      getFunc(request,{ routingKey:'a.' }).then(function(){
        expect(mockDb.query.args[0][0].q).to.not.contain('WHERE siteId = @pgId OR directoryName = CAST(@pgId as NVarChar)');
        done();
      }).catch(done);
    });
    it('should use the routingKey if request.id is undefined',function(done){
      request.id = undefined;
      getFunc(request,{ routingKey:'a.123' }).then(function(){
        expect(mockDb.query.args[0][0].qp.pgId.value).to.equal('123');
        done();
      }).catch(done);
    });
  });
});
