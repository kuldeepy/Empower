'use strict';

var crutch = require('ih-microservice');
var dbFactory = require('./db.js');

var defaults = {
    id: 'empower-portal-groups',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'empower-portal-groups',
    defaultReturnBody: true,
    mssql: 'mssql://empower:Password1@localhost/coldstoneent?encrypt=true',
};

module.exports = crutch(defaults, function(_, inject, logging, microservices, options, Promise, url, util) {
    var db, knownDbs = {};
    var log = logging.getLogger(options.id);

        return getDb(options.mssql).then(function(db) {
            return Promise.all([
                microservices.bind('empower.v6.portal-groups.get.#', get),
                microservices.bind('empower.v6.portal-groups.mssql.query.#', query)
        ]);

        function get(request, mc) {
            if(request.id && knownDbs[request.id]){
                log.trace('returning known database', knownDbs[request.id]);
                return Promise.resolve(knownDbs[request.id]);
            }
            log.trace('get| request:', request, ',\n mc:', mc);
            var qo = { q: 'SELECT * FROM esWebsite' };
            if (request.id === undefined) {
                var rkTail = _.last(mc.routingKey.split('.'));
                request.id = rkTail.toLowerCase() !== 'get' ? rkTail : undefined;
            }
            if (request.id) {
                qo.q += ' WHERE siteId = @pgId OR directoryName = CAST(@pgId as NVarChar)';
                qo.qp = { pgId: { value: _.last(request.id.toString().split('-')), type: 'NVarChar' } };
            }
            return db.query(qo)
                .map(function(x) {
                    var info = _({ id: 'pg-' + x.siteID })
                        .defaults(x)
                        .omit(['ref', 'databaseServer', 'databaseUser', 'databasePassword', 'DSN'])
                        .omit(_.isNull)
                        .extend({ mssql: toMssqlUri({
                            server: (x.databaseServer || db.config.server)
                                .replace('localhost', db.config.server.split('\\')[0]),
                            user: x.databaseUser || db.config.user,
                            password: x.databasePassword || db.config.password,
                            database: x.DSN || db.config.database,
                        }) })
                        .value();
                    knownDbs['pg-' + x.siteID] = info;
                    return info;
                })
                .then(function(results) {
                    
                    log.trace('get| results:', results);
                    return request.id ? _.first(results) : results;
                })
                .then(toReply('get'), toReply('get'));
        }

        function query(request, mc) {
            return get({ id: _.last(mc.routingKey.split('.')) })
                .then(function(pg) {
                    return getDb(pg.mssql, request.options);
                })
                .then(function(db) {
                    return db.query(request)
                        .finally(function() {
                            db.disconnect();
                        });
                })
                .then(toReply('query'), toReply('query'));
        }
    });

    function getDb(uri, options) {
        return Promise.try(function() {
            log.trace('getDb| uri:', uri);
            var config = toMssqlConfig(uri);
            if (options) {
                config = _.assign(config, options);
            }
            return inject.child({ config: config })(dbFactory);
        });
    }

    function toMssqlConfig(uri) {
        var parsed = url.parse(uri, true);
        if (parsed.protocol !== 'mssql:')
            throw new Error('Unsupported protocol: ' + parsed.protocol);
        var authParts = _.compact(parsed.auth.split(':'));
        var hostParts = _.compact(parsed.host.split(':'));
        var pathParts = _.compact(parsed.pathname.split('/'));
        var config = {
            server: parsed.hostname,
            user: parsed.auth.length > 0 ? authParts[0] : undefined,
            password: parsed.auth.length > 1 ? authParts[1] : undefined,
            database: _.first(pathParts),
            options: parsed.query,
        };
        if (hostParts.length > 1)
            config.port = hostParts[1];

        if (pathParts.length > 1 && pathParts[0].length > 0) {
            config.server += '\\' + pathParts[0];
            config.database = pathParts[1];
        }
        _.forEach(parsed.query, function(x, k, o) {
            var s = ('' + x).toLowerCase();
            if (s === 'true' || s === 'false') {
                o[k] = s === 'true';
            }
        });
        _.defaults(config, (db || {}).config);
        log.trace('toMssqlConfig| uri: %s, config:', uri, config);
        return config;
    }

    function toMssqlUri(config) {
        var serverParts = _.compact(config.server.split('\\'));
        var uriObj = {
            protocol: 'mssql',
            slashes: true,
            hostname: _.first(serverParts),
            port: config.port || undefined,
            auth: config.user || undefined,
            pathname: _.compact([_.first(_.drop(serverParts)), config.database]).join('/'),
            query: config.options,
        };
        if (config.password) {
            uriObj.auth = [uriObj.auth || '', config.password].join(':');
        }
        var uri = url.format(uriObj);
        log.trace('toMssqlUri| uri: %s, config:', uri, config);
        return uri;
    }

    function toReply(logLabel) {
        return function(value) {
            if (value instanceof Error) {
                log.debug('%s| error:', logLabel, value);
                value = { error: value.toString() };
            }
            else {
                log.trace('%s| result:', logLabel, value);
            }
            return value || {};
        };
    }
});
