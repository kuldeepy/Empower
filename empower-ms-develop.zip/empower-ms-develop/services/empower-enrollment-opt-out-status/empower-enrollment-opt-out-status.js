'use strict';

var crutch = require('ih-microservice');
var defaults = {
    id: 'empower-enrollment-opt-out-status',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'empower-enrollment-opt-out-status',
    defaultReturnBody: true,
    communicateDb: 'MedseekIntegration60',
    pageSize: '20'
};

module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise) {

  var log = logging.getLogger(options.id);
  var Promise = bluebird;
  var knownPgs = {};

  var promiseFor = Promise.method(function(condition, action, value) {
    if (!condition(value)) {
      return value;
    }
    return action(value).then(promiseFor.bind(null, condition, action));
  });

  return Promise.all([
    microservices.bind('empower.enrollment.opt.out.status', _.wrap(get, errorWrap)),
    microservices.bind('empower.enrollment.opt.out.status.create', _.wrap(create, errorWrap)),
    microservices.bind('empower.enrollment.opt.out.status.update', _.wrap(update, errorWrap)),
  ]);

  var promiseFor = Promise.method(function(condition, action, value) {
    if (!condition(value)) {
      return value;
    }
    return action(value).then(promiseFor.bind(null, condition, action));
  });

  function get(req)
  {
    return getEnrollmentOptOutStatusForPatient(req)
      .then(function(data){
        if(data.length > 0)
        return data[0];
      else 
        return {};
      }).catch(function(err){
        return err;
      });
  }

  function update(req){
      return updateOptOutEnrollmentStatusForPatient(req)
      .then(function (data){
        if (data.length > 0){
          return { result : 'success' }
        }  
        else{
          return { result :'failure' }
        }
      })
  }

  function create(req){
  		 return createOptOutEnrollmentStatusForPatient(req)
      .then(function(data){
        if(data.length > 0){
          if( data[0].StatusId > 0){
          	return { result:'success'}
          } 
          else{
          	return {result :'failure'}
            }
        }
        else{
          return {};
        }
        
      }).catch(function(err){
        return err;
      });
  }

  function updateOptOutEnrollmentStatusForPatient(req){
  	var qString =  '\n'+
		'	update nmodposenrollmentoptoutstatus \n'+
		'		set OptOutOfEnrollment = @optOutStatus \n'+
    '   ,   UpdatedDateTime= getdate() \n'+
		'	where UniquePatientId =  @uniquePatientId  \n'+
		'	select @@ROWCOUNT AS [RowCount];'; 
      var queryObject ={
      q: qString,
       qp: {
       	  optOutStatus: { 
       	  	value: req.optOutStatus
       	  
       	  },
          uniquePatientId: {
            value: req.medseekId,
            type: 'VarChar'
          }
        }
      }
   	return query( queryObject, req);
  }

  function createOptOutEnrollmentStatusForPatient(req){
 	var qString =  '\n'+
		'	insert into nmodposenrollmentoptoutstatus(OptOutOfEnrollment,UniquePatientId, CreatedDateTime) \n'+
		'	values(@optOutStatus,@uniquePatientId, getdate());   \n'+
		'	 SELECT SCOPE_IDENTITY() AS [StatusId];'; 
      var queryObject ={
      q: qString,
       qp: {
       	  optOutStatus: { 
       	  	value: req.optOutStatus
       	  
       	  },
          uniquePatientId: {
            value: req.medseekId,
            type: 'VarChar'
          }
        }
      }
   	return query( queryObject, req);
  }

  function getEnrollmentOptOutStatusForPatient(req){
    var qString = 'select Id, OptOutOfEnrollment,UniquePatientId, COALESCE (UpdatedDateTime,CreatedDateTime) as LastModified from nmodposenrollmentoptoutstatus (nolock) where UniquePatientId = @uniquePatientId';
      var queryObject ={
      q: qString,
       qp: {
          uniquePatientId: {
            value: req.medseekId,
            type: 'VarChar'
          }
        }
      }
   return query( queryObject, req);
  }

   function getPortalGroupId(req){
    return parseInt(req.portalGroupId,10); 
  }

  function query(q,req){
    return microservices.call('empower.v6.portal-groups.mssql.query.pg-'+getPortalGroupId(req),q)
    .tap(function(results){
    })
    .then(function(results){
      return results;
    });
	}	

   function errorWrap(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      return {
        error: err.message
      };
    });
  }

});
