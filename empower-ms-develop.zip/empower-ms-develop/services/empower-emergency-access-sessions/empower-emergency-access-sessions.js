'use strict';

var crutch = require('ih-microservice');

var defaults = {
  id: 'empower-emergency-access-sessions',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-emergency-access-sessions',
  defaultReturnBody: true
};

module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise) {

  var log = logging.getLogger(defaults.id);

  var INSERT_QUERY = 'INSERT INTO EmergencyAccessSessions' +
    ' (UserId, PatientId, AuthSessionId, StartUTCDateTime)' +
    ' VALUES(@UserId, @PatientId, @AuthSessionId, GETUTCDATE());';

  var END_QUERY = 'UPDATE EmergencyAccessSessions SET EndUTCDateTime = GETUTCDATE()' +
    ' WHERE AuthSessionId = @AuthSessionId AND EndUTCDateTime IS NULL;';

  var FIND_QUERY = 'SELECT TOP 1 patientId FROM EmergencyAccessSessions' +
    ' WHERE AuthSessionId = @AuthSessionId AND EndUTCDateTime IS NULL ' +
    ' ORDER BY StartUTCDateTime DESC;';

  return Promise.all([
    microservices.bind('empower.emergency-access-session.start.#', _.wrap(startSession, returnError)),
    microservices.bind('empower.emergency-access-session.end.#', _.wrap(endSession, returnError)),
    microservices.bind('empower.emergency-access-session.find-current.#', _.wrap(findCurrentSession, returnError))
  ]);

  /*
  Starts an EA session the specified patient for the current auth session.
  Ensures that any existing active sessions are ended.
  message params:
  {
    userId,
    patientId,
    authSessionId
  }
  */
  function startSession(message, messageContext) {
    log.debug('Creating EA session', message);
    return submitQuery({
      q: END_QUERY + INSERT_QUERY,
      qp: {
        UserId: {
          value: parseInt(message.userId, 10),
          type: 'Int'
        },
        PatientId: {
          value: parseInt(message.patientId, 10),
          type: 'Int'
        },
        AuthSessionId: {
          value: message.authSessionId,
          type: 'VarChar'
        }
      },
      multiple: true
    }, messageContext).then(function() {
      return {
        emergencyAccess: true
      };
    });
  }

  /*
   Ends all active EA sessions for the current auth session.
   message params:
   {
     authSessionId
   }
   */
  function endSession(message, messageContext) {
    log.debug('Ending EA session', message);
    return submitQuery({
      q: END_QUERY,
      qp: {
        AuthSessionId: {
          value: message.authSessionId,
          type: 'VarChar'
        }
      }
    }, messageContext).then(function() {
      return {
        emergencyAccess: false
      };
    });
  }

  /*
   Finds an active EA session for the current auth session.
   message params:
   {
     authSessionId
   }
   */
  function findCurrentSession(message, messageContext) {
    log.debug('Finding current EA session', message);
    return submitQuery({
      q: FIND_QUERY,
      qp: {
        AuthSessionId: {
          value: message.authSessionId,
          type: 'VarChar'
        }
      }
    }, messageContext).then(function(results) {
      log.trace('results', results);
      if (results.length > 0) {
        log.trace('patientId', results[0].patientId);
        return {
          patientId: results[0].patientId
        };
      }
      return {};
    });
  }

  function submitQuery(queryObj, messageContext) {
    log.debug('submitting query', queryObj.q);
    var portalGroupId = getPortalGroupId(messageContext);
    return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, queryObj)
      .then(function(results) {
        checkError(results);
        return results;
      });
  }

  function getPortalGroupId(messageContext) {
    return _.last(messageContext.routingKey.split('.'));
  }

  function checkError(results) {
    if (typeof(results.error) !== 'undefined') {
      throw new Error('Error running query: ' + results.error);
    }
  }

  function returnError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }

});