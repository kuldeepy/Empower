'use strict';
var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var _ = require('lodash');
var util = require('util');
var fs = require('fs');

describe('empower-language-import', function () {

  var service, mockMs, mockLog, mockMicroservices, options, mockLogging;
  beforeEach(function () {
    mockMs = sinon.stub();
    mockLog = sinon.stub({
      debug: console.log,
      error: console.error,
      trace: console.log
    });
    mockLogging = {
      getLogger: function () {
        return mockLog;
      }
    };
    mockMicroservices = sinon.stub({
      bind: function () {},
      call: function () {}
    });

    mockMicroservices.call.returns(Promise.resolve(1));
    options = {
      languageExcelFile: './test/templates/Templates.xlsx',
      supportedLanguages: JSON.stringify([{'key':'en-US','value':'English','defaultPortalCulture':true}]),
      staticFilesDirectories: './test/tmp/'
    };
    mockMs.yields(undefined, mockLogging, mockMicroservices, Promise, options, _, util);
    service = proxyquire.noCallThru()('../empower-language-import.js', {
      'ih-microservice': mockMs
    });

  });

  it('exists', function () {
    expect(service).to.be.an('object');
  });

  describe('translate', function() {
    it('should return the specified key and culture',function() {
      var val = service.translate({ key:'MyDt', cultureName: 'en-US'});
      expect(val.translation).to.equal('My dynamic Text');
    });
    it('should return an empty string when the key is not found.', function() {
      var val = service.translate({ key:'NotFound', cultureName: 'en-US'});
      expect(val.translation).to.equal('');
    });
    it('should return the key and type combo if type is included', function() {
      var val = service.translate({ key:'MyDt', cultureName: 'en-US', type: 'DT'});
      expect(val.translation).to.equal('My dynamic Text');
    });
    it('should not return the key and type if the type is not found when included', function() {
      var val = service.translate({ key:'MyDt', cultureName: 'en-US', type: 'UNKNOWN'});
      expect(val.translation).to.equal('');
    });
    it('should return an empty string if the culture inserted is not found.', function() {
      var val = service.translate({ key:'MyDt', cultureName: 'not-english', type: 'DT'});
      expect(val.translation).to.equal('');
    });
  });

  describe('staticResources', function () {
    var output;
    beforeEach(function (){
      options = {
        languageExcelFile: './test/templates/Static.xlsx',
        supportedLanguages: JSON.stringify([{'key':'en-US','value':'English','defaultPortalCulture':true},{'key':'es-MX','value':'Español'}]),
        staticFilesDirectories: './test/tmp/'
      };
      mockMs.yields(undefined, mockLogging, mockMicroservices, Promise, options, _, util);
      service = proxyquire.noCallThru()('../empower-language-import.js', {
        'ih-microservice': mockMs
      });
      output = service.staticResources();
    })
    it('should generate json for each supported language', function () {
      _.forEach(output, function (json){
        expect(json.json).to.be.an('object');
      });
    });
    it('should write the json files to disk.',function () {
      var files = fs.readdirSync('./test/tmp/');
      expect(files.length).to.equal(3);
    });
  });

  describe('dynamicResources', function () {
    beforeEach(function () {
    });

    it('should send the sql to the portalGroups microservice.', function (d) {
      service.dynamicResources({},{ routingKey: 'a.b'}).then(function() {
        expect(mockMicroservices.call.callCount).to.equal(50);
        d();
      }).catch(d);
    });
    
    it('should call the microservice with the portalGroup from the routingKey', function (d) {
      service.dynamicResources({},{ routingKey: 'a.b'}).then(function() {
        _.forEach(mockMicroservices.call.args, function(args,index) {
          expect(args[0]).to.equal('empower.v6.portal-groups.mssql.query.b');
        });
        d();
      }).catch(d);
    });

    it('should honor the request filter',function(d){
      mockMicroservices = sinon.stub({
        call:function () {},
        bind: function () {}
      });
      mockMicroservices.call.returns(Promise.resolve(1));
      options.staticFilesDirectories = '';
      options.supportedLanguages = JSON.stringify([{ key: 'en-US' }])
      mockMs.yields(undefined, mockLogging, mockMicroservices, Promise, options, _, util);
      service = proxyquire.noCallThru()('../empower-language-import.js', {
        'ih-microservice': mockMs
      });
      service.dynamicResources({ filter: 'notavalidkey'},{ routingKey: 'a.b'}).then(function() {
        expect(mockMicroservices.call.callCount).to.equal(0);
        d();
      }).catch(d);
    });

    describe('loadJson',function () {
      var values;
      beforeEach(function (){
        values = service.loadJson();
      });
      it('should return an array of objects',function(){
        expect(values).to.be.an('array');
      });
      it('should have a key',function () {
        expect(_.last(values).Key).to.equal('AccountHolderCloseAccount');
      });
      it('should have a Type',function(){
        expect(_.last(values).Type).to.equal('T.Body');
      });
    });

    describe('buildNameAndDescription', function () {
      var values, builtObject;
      beforeEach(function (){
        values = service.loadJson();
        builtObject = service.buildNameAndDescription('AddEmergencyContact', values);
      });
      it('should return an object',function () {
        expect(builtObject).to.be.an('object');
      });
      it('should have a name',function () {
        expect(builtObject.name).to.be.an('object');
      });
      it('should have a description',function () {
        expect(builtObject.description).to.be.an('object');
      });
    });

    describe('buildTemplate', function () {
      var values, builtObject;
      beforeEach(function (){
        values = service.loadJson();
        builtObject = service.buildTemplate('PatientPasswordChangeSettings', values);
      });
      it('should return an object',function () {
        expect(builtObject).to.be.an('object');
      });
      it('should have a body',function () {
        expect(builtObject.body).to.be.an('object');
      });
      it('should have a senderName',function () {
        expect(builtObject.senderName).to.be.an('object');
      });
      it('should have a senderAddress',function () {
        expect(builtObject.senderAddress).to.be.an('object');
      });
      it('should have a sms',function () {
        expect(builtObject.sms).to.be.an('object');
      });
    });

    describe('buildDynamicFormNameQuery',function () {
      var values, query;
      beforeEach(function () {
        values = service.loadJson();
        query = service.buildDynamicFormNameQuery('AddEmergencyContact', values, 'en-US');
      });

      it('should return an object',function () {
        expect(query).to.be.an('object');
      });

      it('should have a q property', function () {
        expect(query.q).to.be.a('string');
      });

      it('should have a qp property', function () {
        expect(query.qp).to.be.an('object');
      });

      it('should have a qp.key', function () {
        expect(query.qp.key).to.be.an('object');
      });

      it('should have a qp.formName', function () {
        expect(query.qp.formName).to.be.an('object');
      });

      it('should have a qp.formDescription', function () {
        expect(query.qp.formDescription).to.be.an('object');
      });
    });

    describe('buildFieldLabelQuery',function () {
      var values, query;
      beforeEach(function () {
        values = service.loadJson();
        query = service.buildFieldLabelQuery('AddEmergencyContact','FirstName', { Key: 'AddEmergencyContact$$FirstName', 'EN_US': 'First Name'}, 'EN_US');
      });

      it('should return an object',function () {
        expect(query).to.be.an('object');
      });

      it('should have a q property', function () {
        expect(query.q).to.be.a('string');
      });

      it('should have a qp property', function () {
        expect(query.qp).to.be.an('object');
      });

      it('should have a qp.formKey', function () {
        expect(query.qp.formKey).to.be.an('object');
      });
      
      it('should have a qp.fieldKey', function () {
        expect(query.qp.fieldKey).to.be.an('object');
      });

      it('should have a qp.fieldValue', function () {
        expect(query.qp.fieldValue).to.be.an('object');
      });

      it('should have a qp.cultureName', function () {
        expect(query.qp.cultureName).to.be.an('object');
      });
    });

    describe('buildTemplateQuery',function () {
      var values, query;
      beforeEach(function () {
        values = service.loadJson();
        query = service.buildTemplateQuery('PatientPasswordChangeSettings', values, 'EN_US');
      });

      it('should return an object',function () {
        expect(query).to.be.an('object');
      });

      it('should have a q property', function () {
        expect(query.q).to.be.a('string');
      });

      it('should have a qp property', function () {
        expect(query.qp).to.be.an('object');
      });

      it('should have a qp.body', function () {
        expect(query.qp.body).to.be.an('object');
      });

      it('should have a qp.subject', function () {
        expect(query.qp.subject).to.be.an('object');
      });

      it('should have a qp.senderName', function () {
        expect(query.qp.senderName).to.be.an('object');
      });

      it('should have a qp.senderAddress', function () {
        expect(query.qp.senderAddress).to.be.an('object');
      });

      it('should have a qp.smsBody', function () {
        expect(query.qp.smsBody).to.be.an('object');
      });

      it('should replace the line breaks in the body with <br>', function() {
        var q = service.buildTemplateQuery('LoginForgetUserName', values, 'es-MX');
        expect(q.qp.body.value).to.equal('Estimado/a$$UserFirstName$$   Su nombre de usuario es: $$UserName$$   $$Portal URL$$   SaludoEstimado/a$$UserFirstName$$   <br>Su nombre de usuario es: $$UserName$$   <br>$$Portal URL$$   <br><br>Saludos, <br>El administrador del sistema  s, El administrador del sistema  ');
      });
    });

  describe('buildDynamicTextQuery', function () {
      var query;
      beforeEach(function () {
        query = service.buildDynamicTextQuery({ Key: 'MyDt', EN_US: 'MyValue' }, 'EN_US');
      });

      it('should return an object', function () {
        expect(query).to.be.an('object');
      });

      it('should have a q property', function () {
        expect(query.q).to.be.a('string');
      });

      it('should have a qp property', function () {
        expect(query.qp).to.be.an('object');
      });

      it('should have a qp.key', function () {
        expect(query.qp.key).to.be.an('object');
      });

      it('should have a qp.value', function () {
        expect(query.qp.value).to.be.an('object');
      });

      it('should have a qp.cultureName', function () {
        expect(query.qp.cultureName).to.be.an('object');
      });
    });
  });

});