'use strict';

var micro = require('ih-microservice');
var fs = require('fs');
var defaults = {
  id: 'empower-language-import',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-language-import',
  defaultReturnBody: true,
  languageExcelFile:  './translations.xlsx',
  staticFilesDirectories: '../../../empower-ui/app/translations/',
  supportedLanguages: '[]',
  ignoreCulture: 'en-US'
};
var xlsx = require('node-xlsx');

micro(defaults, function (app, logging, microservices, Promise, options, _, util) {

  var languages = JSON.parse(options.supportedLanguages.replace(/'/g,'"'));
  options.supportedLanguages = _.clone(languages);
  var supportedCultures = _(languages)
    .remove(function (lan) {
      if(options.ignoreCulture){

        return lan.key !== options.ignoreCulture;
      }
      return true;
    })
    .pluck('key')
    .value(),json;
  var log = logging.getLogger(defaults.id);
  options.staticFilesDirectories = options.staticFilesDirectories.split('~');
  log.debug('files registered for write', options.staticFilesDirectories);
  log.debug('supportedCultures',supportedCultures);
  var sql = (function () {
    var s = {};
    fs.readdirSync('./sql').forEach(function(file){
      s[file.replace('.sql', '')] = fs.readFileSync('./sql/' + file).toString('utf-8');
    });
    log.trace(s);
    return s;
  })();

  module.exports = {
    staticResources: staticResources,
    dynamicResources: dynamicResources,
    loadJson: loadJson,
    buildNameAndDescription: buildNameAndDescription,
    buildDynamicFormNameQuery: buildDynamicFormNameQuery,
    buildTemplate: buildTemplate,
    buildTemplateQuery: buildTemplateQuery,
    buildDynamicTextQuery: buildDynamicTextQuery,
    buildFieldLabelQuery: buildFieldLabelQuery,
    translate: translate
  };

  return Promise.all([
    microservices.bind('empower.languages.import-static', staticResources),
    microservices.bind('empower.languages.import-dynamic.#', dynamicResources),
    microservices.bind('empower.language.translate', translate),
    microservices.bind('empower.language.verify.#', verify)
  ]);

  function verify (request, messageContext) {
    var q,pgId = _.last(messageContext.routingKey.split('.'));
    var files = options.staticFilesDirectories.map(function(dir) {
      return fs.readFileSync(dir + request.cultureName.split('-')[0] + '.json', 'utf8');
    });
    log.trace(files[0]);
    var promises = _.map(loadJson(), function(row) {
      switch(row.Type) {
        case 'DT':
          q = {
            q: sql.VerifyDynamicText,
            qp: {
              cultureName: qp(request.cultureName),
              key: qp(row.Key.trim())
            }
          };
          return query(q,pgId).bind(row).then(function(result) {
            if(!result[0][0].Exists){
              return row;
            }
          });
        case 'Static':
          var missing = _.compact(files.map(function(f) {
            if(f.indexOf(row.Key.trim()) !== - 1){
              log.trace('missing row', row.Key.trim());
              return row.Key.trim();
            }
          }));
          return missing.length ? missing : undefined;
        case 'DF.Description':
        case 'DF.Name':
          q = {
            q: sql.VerifyDynamicFormNameAndDescription,
            qp: {
              cultureName: qp(request.cultureName),
              formKey: qp(row.Key.trim())
            }
          };

          return query(q, pgId).then(function(result) {
            if (row.Type === 'DF.Description' && (!result[0] || !result[0][0] || !result[0][0].description)){
              return { row: row , result: result, Type: row.Type };
            }
            if (row.Type === 'DF.Name' && (!result[0] || !result[0][0] || !result[0][0].name)){
              return { row: row, result: result, Type: row.Type };
            }
          });
        case 'DF.Field.Label':
          var parts = row.Key.trim().split('$$');
          q = {
            q: sql.VerifyDynamicFormField,
            qp: {
              formKey: qp(parts[0]),
              dataKey: qp(parts[1]),
              cultureName: qp(request.cultureName)
            }
          };
          return query(q, pgId).then(function(result) {
            if (!result || !result[0] || !result[0][0] || !result[0][0].label){
              return { row: row, result: result, Type: row.Type };
            }
          });
        case 'T.Body':
        case 'T.SenderAddress':
        case 'T.SenderName':
        case 'T.SMS':
        case 'T.Subject':
          q = {
            q: sql.VerifyTemplate,
            qp: {
              templateType: qp(row.Key.trim()),
              cultureName: qp(request.cultureName)
            }
          };
          return query(q, pgId).then(function(results) {
            return results[0][0];
          }).bind(row).then(function(val){
            var key = this.Type === 'T.SMS' ? 'SmsBody' : this.Type.split('.')[1];
            if(!val || !val[key]) {
              return { Type: this.Type, row: this, result: val || 'No template row found. Probably means the Admin English Version was not inserted at the time of ingestions.  Save the Template in admin and then restart the business services.' };
            }
          });
      }
    });
    return Promise.all(_.compact(promises)).then(function(results) {
      return _(results).compact().groupBy('Type').value();
    });
  }

  function translate (request, messageContext) {
    var values = loadJson();
    var filter = { Key: request.key.trim() };
    if(request.type) {
      filter.Type = request.type;
    }
    return { translation: (_.find(values, filter) || {})[request.cultureName] || '' };
  }

  function loadJson () {
    if(json) {
      return json;
    }
    var obj = xlsx.parse(options.languageExcelFile);
    var data = obj.shift().data;
    var map = data.shift();
    json = _(data).map(function (rowData) {
      var row = {};
      _.forEach(map, function (column, index) {
        row[column.trim()] = rowData[index];
      });
      return row;
    })
    .sortBy(['Key'])
    .reverse()
    .value();
    return json;
  }

  function buildTemplate (key, json) {
    return {
      body: _.find(json, { Key: key, Type: 'T.Body' }),
      subject: _.find(json, { Key: key, Type: 'T.Subject' }),
      senderName: _.find(json, { Key: key, Type: 'T.SenderName' }),
      senderAddress: _.find(json, { Key: key, Type: 'T.SenderAddress' }),
      sms: _.find(json, { Key: key, Type: 'T.SMS' })
    };
  }

  function buildNameAndDescription (key, json) {
    return {
      name: _.find(json, { Key: key, Type: 'DF.Name' }),
      description: _.find(json, { Key: key, Type: 'DF.Description' })
    };
  }

  function buildTemplateQuery (key, json, culture) {
    var template = buildTemplate(key, json);
    var q = {
      q: sql.Template,
      qp: {
        body: qp(template.body && template.body[culture] && template.body[culture].replace(/(?:\r\n|\r|\n)/g, '<br>'), 'Text'),
        subject: qp(template.subject && template.subject[culture]),
        senderName: qp(template.senderName && template.senderName[culture]),
        senderAddress: qp(template.senderAddress && template.senderAddress[culture]),
        smsBody: qp(template.sms && template.sms[culture]),
        key: qp(key),
        cultureName: qp(culture)
      }
    };
    log.trace('buildTemplateQuery| q', q);
    return q;
  }

  function buildDynamicFormNameQuery (key, json, culture) {
    var nameAndDescription = buildNameAndDescription(key, json);
    var q = {
      q: sql.DynamicFormNameAndDescription,
      qp: {
        key: qp(key),
        cultureName: qp(culture),
        formName: qp(nameAndDescription.name[culture]),
        formDescription: qp(nameAndDescription.description[culture])
      }
    };
    log.trace('buildDynamicFormNameQuery| q', q);
    return q;
  }

  function buildDynamicTextQuery (value, culture) {
    var q = {
      q: sql.DynamicText,
      qp: {
        key: qp(value.Key.trim(), 'VarChar', 100),
        value: qp(value[culture]),
        cultureName: qp(culture)
      }
    };
    log.trace('buildDynamicTextQuery| q', q);
    return q;
  }

  function buildFieldLabelQuery (formKey, fieldKey, row, culture) {
    var q = {
      q: sql.DynamicFormLabel,
      qp: {
        formKey: qp(formKey),
        fieldKey: qp(fieldKey),
        fieldValue: qp(row[culture]),
        cultureName: qp(culture)
      }
    };
    log.trace('buildFieldLabelQuery| q', q);
    return q;
  }

  function qp (value, type, length) {
    value = value || '';
    try{
      return {
        type: type || 'NVarChar',
        value: value,
        length: length ? length : (!type ? value.length : undefined)
      };
    } catch (err) {
      log.error('val' , value, 'type',type);
      throw err;
    }

  }

  function parseDynamicText (row, culture, pg) {
    var q = buildDynamicTextQuery(row, culture);
    return query(q, pg);
  }

  function parseDynamicFormName (key, json, culture, pg) {
    try {
      var q = buildDynamicFormNameQuery(key, json, culture);
      return query(q, pg);
    }
    catch(err) {
      log.error(key, culture, pg, err);
    }
  }

  function parseTemplate (key, json, culture, pg) {
    var q = buildTemplateQuery(key, json, culture);
    return query(q, pg);
  }

  function query (q, pgId) {
    q.multiple = true;
    return microservices.call('empower.v6.portal-groups.mssql.query.' + pgId, q)
      .tap(function(results){
        log.trace('get| query results', util.inspect(results, { colors: true, depth: null }));
      })
      .then(function(results){
        return results;
      });
  }

  function parseDynamicFormLabel (key, row, culture, pg) {
    var keyParts = key.split('$$');
    log.debug('row', row);
    var q = buildFieldLabelQuery(keyParts[0], keyParts[1], row, culture);
    return query(q, pg);
  }

  function staticResources (request, messageContext) {
    var values = loadJson();
    var cultureFiles = [];
    _(options.supportedLanguages).forEach(function(culture) {
      var cultureJson = {};
      _(values).where({ Type: 'Static' }).forEach(function (value) {
        cultureJson[value.Key] = value[culture.key];
      });
      cultureFiles.push({
        culture: culture,
        json: cultureJson
      });
      _.forEach(options.staticFilesDirectories, function (dir) {
        var fileName = util.format('%s%s.json', dir, culture.key.split('-')[0]);
        log.debug('writing file:', fileName);
        fs.writeFileSync(fileName, JSON.stringify(cultureJson));
      });
    });
  }

  function dynamicResources (request, messageContext) {
    console.log('request',request);
    return Promise.try(function() {

      var pg = _.last(messageContext.routingKey.split('.'));
      var values = _.where(loadJson(),function(val){
        return val.Key !== undefined;
      });
      log.trace('values',values);
      if(request.filter) {
        log.debug('filtering values', request.filter);
        values = _.filter(values, function (value) {
          return value.Key && value.Key.indexOf(request.filter) !== -1;
        });
        log.trace('filtered values', values);
      }

      var promises = [];
      log.trace('supportedCultures',supportedCultures.length);
      supportedCultures.forEach(function (culture) {
        _.reject(values,{ Type: 'Static' }).forEach(function (value) {
          switch (value.Type) {
            case 'DT':
              promises.push(parseDynamicText(value, culture, pg));
              break;
            case 'DF.Name':
              promises.push(parseDynamicFormName(value.Key, values, culture, pg));
              break;
            case 'DF.Field.Label':
              promises.push(parseDynamicFormLabel(value.Key, value, culture, pg));
              break;
            case 'T.Body':
              log.trace('found T.Body',value);
              promises.push(parseTemplate(value.Key, values, culture, pg));
              break;
          }
        });
      });
      log.debug(util.format('sending %d sql queries',promises.length));
      return Promise.all(promises).then(function(results){
        log.debug('dynamicResources| results', results);
      }).catch(function(err) {
        log.error(err);
      });
    }).catch(function(err){
      log.error('dynamicResources| err',err);
      throw err;
    });
  }

});
