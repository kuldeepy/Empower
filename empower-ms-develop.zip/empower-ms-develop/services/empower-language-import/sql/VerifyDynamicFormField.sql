
--set @formKey = 'AddEmergencyContact'
--set @cultureName = 'es-mx'
--set @dataKey = 'DaytimePhone'

SELECT v.label, 
       v.textlabel 
FROM   dynamicformfieldtextvalues v 
       INNER JOIN dynamicformfields d 
               ON d.FORMID = v.FORMID 
                  AND d.DATAKEY = v.DATAKEY 
       INNER JOIN dynamicforms f 
               ON f.ID = d.FORMID 
WHERE  CULTURENAME = @cultureName 
       AND FORMKEY = @formKey 
       AND v.DATAKEY = @dataKey 