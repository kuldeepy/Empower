
BEGIN TRY
  DECLARE @dynamicTextId NVARCHAR(20)

  SELECT [Id]
  INTO #ControlTable
  FROM DynamicText
  WHERE [Key] like @key + '%' 

  WHILE EXISTS (
      SELECT *
      FROM #ControlTable
      )
  BEGIN
    SET @dynamicTextId = (
        SELECT TOP (1) [Id]
        FROM #ControlTable
        )

    IF EXISTS (
        SELECT *
        FROM [DynamicTextValues]
        WHERE [DynamicTextId] = @dynamicTextId
        )
    BEGIN
      IF NOT EXISTS (
          SELECT *
          FROM [DynamicTextValues]
          WHERE [DynamicTextId] = @dynamicTextId
            AND [CultureName] = @cultureName
          )
      BEGIN
        INSERT INTO [DynamicTextValues] ([DynamicTextId], [Value], [Description], [CultureName], [Version], [Updated])
        VALUES (
          @dynamicTextId, @value, '', @cultureName, (
            SELECT TOP (1) [Version]
            FROM [DynamicTextValues]
            WHERE [DynamicTextId] = @dynamicTextId
            ), GETDATE()
          )

        SELECT @@ROWCOUNT as rowsInserted
        
      END
    END
    DELETE
    FROM #ControlTable
    WHERE Id = @dynamicTextId
  END

  DROP TABLE #ControlTable
END TRY

BEGIN CATCH
  IF EXISTS (
      SELECT *
      FROM sys.objects
      WHERE object_id = OBJECT_ID(N'[dbo].[EmpowerLanguageException]')
        AND type IN (N'U')
      )
  BEGIN
    INSERT INTO [EmpowerLanguageException]
    VALUES (ERROR_NUMBER(), ERROR_MESSAGE(), @key, @value, @cultureName, GETDATE())

    DROP TABLE #ControlTable
  END
END CATCH