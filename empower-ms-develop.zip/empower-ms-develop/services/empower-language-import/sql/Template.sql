BEGIN TRY
  SELECT *
  INTO #ControlTable
  FROM [MessageTemplates]
  WHERE [TemplateType] = @key

  IF EXISTS (
      SELECT *
      FROM [MessageTemplates]
      WHERE [TemplateType] = @key
      )
  BEGIN
    IF NOT EXISTS (
        SELECT *
        FROM [MessageTemplates]
        WHERE [TemplateType] = @key
          AND [CultureName] = @cultureName
        )
    BEGIN
      INSERT INTO [dbo].[MessageTemplates] ([Name], [Description], [Subject], [Body], [IsEnabled], [LastUpdated], [TemplateType], [CategoryId], [DateTimesAreUtc], [SenderName], [SenderAddress], [Frequency], [FrequencyType], [CultureName], [SmsBody])
      VALUES (
        (
          SELECT TOP (1) [Name]
          FROM #ControlTable
          ), (
          SELECT TOP (1) [Description]
          FROM #ControlTable
          ), @subject, @body, (
          SELECT TOP (1) [IsEnabled]
          FROM #ControlTable
          ), getutcdate(), (
          SELECT TOP (1) [TemplateType]
          FROM #ControlTable
          ), (
          SELECT TOP (1) [CategoryId]
          FROM #ControlTable
          ), 1, @senderName, @senderAddress, (
          SELECT TOP (1) [Frequency]
          FROM #ControlTable
          ), (
          SELECT TOP (1) [FrequencyType]
          FROM #ControlTable
          ), @cultureName, @smsBody
        )
    END
  END
END TRY

BEGIN CATCH
  IF EXISTS (
      SELECT *
      FROM sys.objects
      WHERE object_id = OBJECT_ID(N'[dbo].[EmpowerLanguageException]')
        AND type IN (N'U')
      )
  BEGIN
    INSERT INTO [EmpowerLanguageException]
    VALUES (ERROR_NUMBER(), ERROR_MESSAGE(), @key, (cast(@subject as VARCHAR(MAX)) + cast('|' as VARCHAR(MAX)) + cast(@body as VARCHAR(MAX)) + cast('|' as VARCHAR(MAX)) + cast(@senderName as VARCHAR(MAX)) + cast('@senderName' as VARCHAR(MAX)) + cast('|' as VARCHAR(MAX)) + cast(@smsBody  as VARCHAR(MAX))+ cast('|' as VARCHAR(MAX)) + cast(@senderAddress as VARCHAR(MAX))), @cultureName, getdate())
  END
END CATCH