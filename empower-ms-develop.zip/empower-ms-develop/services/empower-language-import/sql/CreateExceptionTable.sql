 IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[EmpowerLanguageException]') AND type in (N'U')) 
    BEGIN 
        CREATE TABLE [EmpowerLanguageException](
            [Id] [int] IDENTITY(1,1) NOT NULL,
            [ErrorNumber] INT,
            [ErrorMessage] VARCHAR(200),
            [Key] VARCHAR(100),
            [Value] VARCHAR(max),
            [CultureName] VARCHAR(20),
            [LastUpdated] DATE ) 
    END 