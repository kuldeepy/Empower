BEGIN TRY
  DECLARE @dynamicFormId NVARCHAR(20)

  SELECT [Id]
  INTO #ControlTable
  FROM [DynamicForms]
  WHERE [FormKey] like @key + '%'

  WHILE EXISTS (
      SELECT *
      FROM #ControlTable
      )
  BEGIN
    SET @dynamicFormId = (
        SELECT TOP (1) [Id]
        FROM #ControlTable
        )

    IF EXISTS (
        SELECT *
        FROM [dbo].[DynamicFormTextValues]
        WHERE [FormId] = @dynamicFormId
        )
    BEGIN
      IF NOT EXISTS (
          SELECT *
          FROM [dbo].[DynamicFormTextValues]
          WHERE [FormId] = @dynamicFormId
            AND [CultureName] = @cultureName
          )
      BEGIN
        INSERT INTO [dbo].[DynamicFormTextValues] ([FormId], [CultureName], [Name], [Description])
        VALUES (@dynamicFormId, @cultureName, @formName, @formDescription)


      END
    END

    DELETE
    FROM #ControlTable
    WHERE Id = @dynamicFormId
  END

  DROP TABLE #ControlTable
END TRY

BEGIN CATCH
  IF EXISTS (
      SELECT *
      FROM sys.objects
      WHERE object_id = OBJECT_ID(N'[dbo].[EmpowerLanguageException]')
        AND type IN (N'U')
      )
  BEGIN
    INSERT INTO [EmpowerLanguageException]
    VALUES (ERROR_NUMBER(), ERROR_MESSAGE(), @key, ('Name: ' + @formName + ' Description: ' + @formDescription), @cultureName, getdate())

    DROP TABLE #ControlTable
  END
END CATCH
