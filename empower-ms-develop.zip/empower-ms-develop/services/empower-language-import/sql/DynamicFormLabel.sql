BEGIN TRY
  DECLARE @dynamicFormId NVARCHAR(20)

  SELECT distinct ([Id])
  INTO #ControlTable
  FROM DynamicForms WHERE [FormKey] like @formKey + '%'
  WHILE EXISTS (
      SELECT *
      FROM #ControlTable
      )
  BEGIN
    SET @dynamicFormId = (
        SELECT TOP (1) [Id]
        FROM #ControlTable
        )
      IF NOT EXISTS (
          SELECT *
          FROM [DynamicFormFieldTextValues]
          WHERE [FormId] = @dynamicFormId
            AND [CultureName] = @cultureName
            AND [DataKey] = @fieldKey
          )
      BEGIN
        INSERT INTO [dbo].[DynamicFormFieldTextValues] ([FormId], [DataKey], [CultureName], [Label], [Description], [TextLabel])
        VALUES (@dynamicFormId, @fieldKey, @cultureName, @fieldValue, '', '')


      END
      DELETE
      FROM #ControlTable
      WHERE [Id] = @dynamicFormId
  END

  DROP TABLE #ControlTable
END TRY

BEGIN CATCH
  IF EXISTS (
      SELECT *
      FROM sys.objects
      WHERE object_id = OBJECT_ID(N'[dbo].[EmpowerLanguageException]')
        AND type IN (N'U')
      )
  BEGIN
    INSERT INTO [EmpowerLanguageException]
    VALUES (ERROR_NUMBER(), ERROR_MESSAGE(), @formKey + '$$' + @fieldKey, @fieldValue, @cultureName, getdate())

    DROP TABLE #ControlTable
  END
END CATCH
