-- DECLARE @templateType NVARCHAR(29) 
-- DECLARE @cultureName NVARCHAR(5) 
-- SET @templateType = 'EmailVerification' 
-- SET @cultureName = 'es-MX' 

SELECT * 
FROM   messagetemplates 
WHERE  culturename = @cultureName 
       AND templatetype = @templateType 