SELECT [name], [description]
FROM DynamicFormTextValues v
INNER JOIN DynamicForms d
  ON d.Id = v.FormId
WHERE CultureName = @cultureName AND FormKey = @formKey