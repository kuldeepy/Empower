
IF EXISTS (
  SELECT * FROM DynamicTextValues v
    INNER JOIN DynamicText d
    ON d.Id = v.DynamicTextId
    WHERE CultureName = @cultureName AND [KEY] like @key  + '%')
SELECT
  1 AS [Exists]
ELSE
  SELECT
    0 AS [Exists]