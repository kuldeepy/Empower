'use strict';

var crutch = require('ih-microservice');

var defaults = {
    id: 'empower-enrollment-invitation-status',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'empower-enrollment-invitation-status',
    defaultReturnBody: true,
    communicateDb: 'MedseekIntegration60',
    pageSize: '20'
};

module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise) {

	var log = logging.getLogger(defaults.id);

	var log = logging.getLogger(options.id);
	var Promise = bluebird;
	var knownPgs = {};

	var promiseFor = Promise.method(function(condition, action, value) {
		if (!condition(value)) {
		  return value;
		}
		return action(value).then(promiseFor.bind(null, condition, action));
	});

	return Promise.all([
		microservices.bind('empower.enrollment.invitation.status', _.wrap(get, errorWrap)),
	]);

	var promiseFor = Promise.method(function(condition, action, value) {
		if (!condition(value)) {
		  return value;
		}
		return action(value).then(promiseFor.bind(null, condition, action));
	});

	function get(req){
	   return getInvitationStatus(req)
	  .then(function(data){
	    if(data.length > 0){
	    	return data[0];
	    }
	  	else {
	   	 return {};
	   	}
	  }).catch(function(err){
	    return err;
	  });
	}

	function getInvitationStatus(req){
    	var qString = 'select Id, MedseekPatientId, Status, Created, Modified from '+options.communicateDb+'.[dbo].[ps_EnrollmentInvitationStatus] where MedseekPatientId= @uniquePatientId';
      	var queryObject ={
      	q: qString,
       	qp: {
          		uniquePatientId: {
            		value: req.medseekId,
            		type: 'VarChar'
          		}
        	}
    	}
   		return query( queryObject, req);
  	}

   	function getPortalGroupId(req){
    	return parseInt(req.portalGroupId,10); 
  	}

	function query(q,req){
	    return microservices.call('empower.v6.portal-groups.mssql.query.pg-'+getPortalGroupId(req),q)
	    .tap(function(results){
	    })
	    .then(function(results){
	      return results;
	    });
	}	

	function errorWrap(fn, message, mc) {
	    return Promise.try(function() {
	      return fn(message, mc);
	    }).catch(function(err) {
	      return {
	        error: err.message
	      };
	    });
	}

});
