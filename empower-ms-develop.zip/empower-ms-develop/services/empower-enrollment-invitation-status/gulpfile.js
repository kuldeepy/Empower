'use strict';

var gulp = require('gulp');

gulp.task('start', function() {
    require('./empower-enrollment-invitation-status.js');
});

gulp.task('start-watch', function() {
    var gulpNodemon = require('gulp-nodemon');
    gulpNodemon(getOptions({
        script: 'empower-enrollment-invitation-status',
        ext: 'html js',
        ignore: [
        ]
    }));
});

gulp.task('test', function() {
    var gulpMocha = require('gulp-mocha');
    var gulpUtil = require('gulp-util');
    var options = getOptions({
        reporter: 'spec',
        timeout: undefined
    });
    return gulp.src(['test/**/*.test.js'], { read: false })
        .pipe(gulpMocha(options))
        .on('error', gulpUtil.log);
});

gulp.task('test-watch', function() {
    gulp.watch(['**/*'], ['test']);
});

gulp.task('test-coverage', function () {
  var mocha = require('gulp-mocha'),
      cover = require('gulp-coverage');;
  return gulp.src(['./test/*.tests.js'],{read: false})
    .pipe(cover.instrument({
        pattern: ['./empower-*.js']
    }))
    .pipe(mocha())
    .pipe(cover.gather())
    .pipe(cover.format())
    .pipe(gulp.dest('reports'));
});


function getOptions(defaults) {
    var args = process.argv[0] == 'node' ? process.argv.slice(3) : process.argv.slice(2);
    var minimist = require('minimist');
    return minimist(args, {
        default: defaults
    });
}
