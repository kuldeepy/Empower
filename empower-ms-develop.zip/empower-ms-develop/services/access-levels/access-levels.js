'use strict';
var micro = require('ih-microservice');
var xml2js = require('xml2js');
var definition = require('./models/all')();

var defaults = {
  id: 'influence.accesslevels',
  debug: false,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'influence.accesslevels',
  defaultReturnBody: true
};

micro(defaults, function(app, logging, options, microservices, Promise, _) {

  var log = logging.getLogger(defaults.id);

  var INSERT_QUERY = 'INSERT INTO nModProfileAccessLevels (name, portalId, permissions) VALUES (@name, @portalId, @permissions); SELECT SCOPE_IDENTITY() AS id;';
  var UPDATE_QUERY = 'UPDATE nModProfileAccessLevels SET name = @name,  permissions = @permissions WHERE Id = @id; SELECT @@ROWCOUNT AS updated';

  return Promise.all([
    microservices.bind('influence.accesslevels.definition.#', _.wrap(accessDefinition, errorWrap)),
    microservices.bind('influence.accesslevels.create.#', _.wrap(create, errorWrap)),
    microservices.bind('influence.accesslevels.create-defaults.#', _.wrap(createDefaults, errorWrap)),
    microservices.bind('influence.accesslevels.get-default-permissions.#', _.wrap(getDefaultPermissions, errorWrap)),
    microservices.bind('influence.accesslevels.find.#', _.wrap(find, errorWrap)),
    microservices.bind('influence.accesslevels.update.#', _.wrap(update, errorWrap))
  ]);

  function accessDefinition() {
    return Promise.resolve(definition);
  }

  function create(accessLevel, mc) {
    log.debug('creating access level', accessLevel);
    return submitQuery({
      q: INSERT_QUERY,
      qp: {
        name: {
          value: (accessLevel.name || null),
          type: 'VarChar'
        },
        portalId: {
          value: parseInt(accessLevel.portalId, 10),
          type: 'Int'
        },
        permissions: {
          value: toXml(accessLevel.permissions),
          type: 'XML'
        }
      }
    }, mc).then(function(results) {
      return {
        id: results[0].id
      };
    });
  }

  function update(accesslevel, mc) {
    log.debug('updating access level', accesslevel);
    return submitQuery({
      q: UPDATE_QUERY,
      qp: {
        id: {
          value: parseInt(accesslevel.id, 10),
          type: 'Int'
        },
        name: {
          value: (accesslevel.name || null),
          type: 'VarChar'
        },
        permissions: {
          value: toXml(accesslevel.permissions),
          type: 'XML'
        }
      }
    }, mc).then(function(result) {
      return {
        updated: result[0].updated,
      };
    });
  }

  function find(message, mc) {

    var params = {};
    var query = 'SELECT id, name, portalId, permissions FROM nModProfileAccessLevels';

    var startCondition = function() {
      if (Object.keys(params).length === 0) {
        query += ' WHERE ';
      } else {
        query += ' AND ';
      }
    };

    var addWhereEquals = function(field, type, value) {
      startCondition();
      query += (field + ' = @' + field);
      params[field] = {
        value: value,
        type: type
      };
    };

    if (message.portalId) {
      addWhereEquals('portalId', 'Int', message.portalId);
    }

    if (message.name) {
      addWhereEquals('name', 'VarChar', message.name);
    }

    if (message.id) {
      addWhereEquals('id', 'Int', message.id);
    }

    if (message.allNamed) {
      startCondition();
      query += "(name IS NOT NULL OR name != '')";
    }

    log.debug('find| query', query);
    return submitQuery({
      q: query,
      qp: params
    }, mc).then(function(results) {
      log.debug('got results', results);
      return mapResults(results);
    });
  }

  var permissions = [];
  function iterate(obj, stack) {
    for (var property in obj) {
      if (obj.hasOwnProperty(property)) {
        if (typeof obj[property] === 'object') {
          iterate(obj[property], stack + '.' + property);
        } else {
          if (property === 'permission') {
            permissions.push(obj[property]);
          }
        }
      }
    }
  };

  function getDefaultPermissions(message, mc) {
    permissions = [];
    iterate(definition, '');
    return permissions;
  }

  function createDefaults(message, mc) {
    permissions = [];
    iterate(definition, '');

    var fullAccess = {
      permissions: permissions,
      name: 'Full Access',
      portalId: message.portalId
    };

    var readOnly = {
      permissions: [
        'health-information',
        'health-information.allergies',
        'health-information.blood-glucoses',
        'health-information.blood-pressures',
        'health-information.body-mass-indexes',
        'health-information.cholesterols',
        'health-information.heights',
        'health-information.immunizations',
        'health-information.medications',
        'health-information.conditions',
        'health-information.procedures',
        'health-information.social-histories',
        'health-information.family-history',
        'health-information.test-results',
        'health-information.weights',
        'health-information.clinical-documents',
        'health-information.blue-button',
        'appointments',
        'appointments.future',
        'appointments.future.export',
        'appointments.past',
        'patient-management',
        'patient-management.demographics',
        'patient-management.profile-image',
        'patient-management.locations',
        'patient-management.pharmacies',
        'patient-management.emergency-contacts',
        'patient-management.insurances',
        'patient-management.physicians',
        'patient-management.guarantors',
        'patient-management.invitations',
        'request-center',
        'request-center.pending',
        'request-center.discussion',
        'request-center.discussion.create',
        'request-center.completed'
      ],
      name: 'Read Only Access',
      portalId: message.portalId
    };

    return Promise.all([create(fullAccess, mc), create(readOnly, mc)]).then(function(data) {
      fullAccess.id = data[0].id;
      readOnly.id = data[1].id;
      return [fullAccess, readOnly];
    });
  }

  function errorWrap(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      return {
        error: err.message
      };
    });
  }

  function submitQuery(queryObj, messageContext) {
    log.debug('submitting query', queryObj);
    var portalGroupId = getPortalGroupId(messageContext);
    var routeKey = 'empower.v6.portal-groups.mssql.query.' + portalGroupId;
    log.debug('querying routeKey', routeKey);
    return microservices.call(routeKey, queryObj)
      .then(function(results) {
        checkError(results);
        return results;
      });
  }

  function getPortalGroupId(messageContext) {
    return _.last(messageContext.routingKey.split('.'));
  }

  function checkError(results) {
    if (typeof(results.error) !== 'undefined') {
      throw new Error('Error running query: ' + results.error);
    }
  }

  function toXml(permissionsArray) {
    var builder = new xml2js.Builder({
      renderOpts: {
        pretty: false
      }
    });
    return builder.buildObject({
      permissions: {
        permission: permissionsArray
      }
    });
  }

  function toJson(permissionsXml) {
    if (!permissionsXml) {
      return Promise.resolve([]);
    }
    var parser = new xml2js.Parser({
      explicitArray: false
    });
    return Promise.promisify(parser.parseString)(permissionsXml).then(function(res) {
      var permissions = res.permissions.permission;
      if(_.isArray(permissions)){
        return permissions;
      }
      return [permissions];
    }).catch(function() {
      return [];
    });
  }

  function mapResults(results) {
    return Promise.all(results.map(function(result) {
      return toJson(result.permissions).then(function(permissions) {
        result.permissions = permissions;
        return result;
      });
    }));
  }

});
