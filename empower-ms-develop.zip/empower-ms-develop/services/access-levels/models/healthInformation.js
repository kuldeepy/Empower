'use strict';

module.exports = function() {
	return {
		id: 'health-information',
		accessTypes:[
			{
				permission: 'health-information.allergies.view',
				componentKey: 'allergies',
				label: 'View Allergies'
			},
			{
				permission: 'health-information.blood-glucoses.view',
				componentKey: 'blood-glucoses',
				label: 'View Blood Glucoses'
			},
			{
				permission: 'health-information.blood-pressures.view',
				componentKey: 'blood-pressures',
				label: 'View Blood Pressures'
			},
			{
				permission: 'health-information.cholesterols.view',
				componentKey: 'cholesterols',
				label: 'View Cholesterols'
			},
			{
				permission: 'health-information.immunizations.view',
				componentKey: 'immunizations',
				label: 'View Immunizations'
			},
			{
				permission: 'health-information.medications.view',
				componentKey: 'medications',
				label: 'View Medications'
			},
			{
				permission: 'health-information.conditions.view',
				componentKey: 'conditions',
				label: 'View Conditions'
			},
			{
				permission: 'health-information.procedures.view',
				componentKey: 'procedures',
				label: 'View Procedures'
			},
			{
				permission: 'health-information.social-histories.view',
				componentKey: 'social-histories',
				label: 'View Social History'
			},
			{
				permission: 'health-information.family-history.view',
				componentKey: 'family-history',
				label: 'View Family History'
			},
			{
				permission: 'health-information.test-results.view',
				componentKey: 'test-results',
				label: 'View Test Results'
			},
			{
				permission: 'health-information.height-weight-bmi.view',
				componentKey: 'height-weight-bmi',
				label: 'View Height/Weight/BMI'
			},
			{
				permission: 'health-information.clinical-documents.view',
				componentKey: 'clinical-documents',
				label: 'View Clinical Documents'
			},
			{
				permission: 'health-information.blue-button',
				label: 'Blue Button Download'
			}

		],
		components: [
			{
				id: 'allergies',
				accessTypes: [
					{
						permission: 'health-information.allergies.manage',
						label: 'Add/Edit/Delete Patient Entered Allergies'
					},
					{
						permission: 'health-information.allergies.external.dispute',
						label: 'Dispute External Allergies'
					},
					{
						permission: 'health-information.allergies.ask',
						label: 'Ask a Question for Allergies'
					},
					{
						permission: 'health-information.allergies.education.view',
						label: 'View Education Content for Allergies'
					},
					{
						permission: 'health-information.allergies.mark-private',
						label: 'Mark Allergies as Private'
					}
				]
			},
			{
				id: 'blood-glucoses',
				accessTypes: [
					{
						permission: 'health-information.blood-glucoses.manage',
						label: 'Add/Delete Patient Entered Blood Glucoses'
					},
					{
						permission: 'health-information.blood-glucoses.external.dispute',
						label: 'Dispute External Blood Glucoses'
					},
					{
						permission: 'health-information.blood-glucoses.ask',
						label: 'Ask a Question for Blood Glucoses'
					},
					{
						permission: 'health-information.blood-glucoses.education.view',
						label: 'View Education Content for Blood Glucoses'
					},
					{
						permission: 'health-information.blood-glucoses.mark-private',
						label: 'Mark Blood Glucoses as Private'
					}
				]
			},
			{
				id: 'blood-pressures',
				accessTypes: [
					{
						permission: 'health-information.blood-pressures.manage',
						label: 'Add/Delete Patient Entered Blood Pressures'
					},
					{
						permission: 'health-information.blood-pressures.external.dispute',
						label: 'Dispute External Blood Pressures'
					},
					{
						permission: 'health-information.blood-pressures.ask',
						label: 'Ask a Question for Blood Pressures'
					},
					{
						permission: 'health-information.blood-pressures.education.view',
						label: 'View Education Content for Blood Pressures'
					},
					{
						permission: 'health-information.blood-pressures.mark-private',
						label: 'Mark Blood Pressures as Private'
					}
				]
			},
			{
				id: 'cholesterols',
				accessTypes: [
					{
						permission: 'health-information.cholesterols.manage',
						label: 'Add/Delete Patient Entered Cholesterols'
					},
					{
						permission: 'health-information.cholesterols.external.dispute',
						label: 'Dispute External Cholesterols'
					},
					{
						permission: 'health-information.cholesterols.ask',
						label: 'Ask a Question for Cholesterols'
					},
					{
						permission: 'health-information.cholesterols.education.view',
						label: 'View Education Content for Cholesterols'
					},
					{
						permission: 'health-information.cholesterols.mark-private',
						label: 'Mark Cholesterols as Private'
					}
				]
			},
			{
				id: 'height-weight-bmi',
				accessTypes: [
					{
						permission: 'health-information.height-weight-bmi.manage',
						label: 'Add/Edit/Delete Patient Entered Height/Weight/BMI'
					},
					{
						permission: 'health-information.height-weight-bmi.external.dispute',
						label: 'Dispute External Height/Weight/BMI'
					},
					{
						permission: 'health-information.height-weight-bmi.ask',
						label: 'Ask a Question for Height/Weight/BMI'
					},
					{
						permission: 'health-information.height-weight-bmi.education.view',
						label: 'View Education Content for Height/Weight/BMI'
					},
					{
						permission: 'health-information.height-weight-bmi.mark-private',
						label: 'Mark Height/Weight/BMI as Private'
					}
				]
			},
			{
				id: 'immunizations',
				accessTypes: [
					{
						permission: 'health-information.immunizations.manage',
						label: 'Add/Edit/Delete Patient Entered Immunizations'
					},
					{
						permission: 'health-information.immunizations.external.dispute',
						label: 'Dispute External Immunizations'
					},
					{
						permission: 'health-information.immunizations.ask',
						label: 'Ask a Question for Immunizations'
					},
					{
						permission: 'health-information.immunizations.education.view',
						label: 'View Education Content for Immunizations'
					},
					{
						permission: 'health-information.immunizations.mark-private',
						label: 'Mark Immunizations as Private'
					}
				]
			},
			{
				id: 'medications',
				accessTypes: [
					{
						permission: 'health-information.medications.manage',
						label: 'Add/Edit/Delete Patient Entered Medications'
					},
					{
						permission: 'health-information.medications.external.dispute',
						label: 'Dispute External Medications'
					},
					{
						permission: 'health-information.medications.ask',
						label: 'Ask a Question for Medications'
					},
					{
						permission: 'health-information.medications.education.view',
						label: 'View Education Content for Medications'
					},
					{
						permission: 'health-information.medications.mark-private',
						label: 'Mark Medications as Private'
					},
					{
						permission: 'health-information.medications.renew-prescription',
						label: 'Renew Prescription'
					}
				]
			},
			{
				id: 'conditions',
				accessTypes: [
					{
						permission: 'health-information.conditions.manage',
						label: 'Add/Edit/Delete Patient Entered Conditions'
					},
					{
						permission: 'health-information.conditions.external.dispute',
						label: 'Dispute External Conditions'
					},
					{
						permission: 'health-information.conditions.ask',
						label: 'Ask a Question for Conditions'
					},
					{
						permission: 'health-information.conditions.education.view',
						label: 'View Education Content for Conditions'
					},
					{
						permission: 'health-information.conditions.mark-private',
						label: 'Mark Conditions as Private'
					}
				]
			},
			{
				id: 'procedures',
				accessTypes: [
					{
						permission: 'health-information.procedures.manage',
						label: 'Add/Edit/Delete Patient Entered Procedures'
					},
					{
						permission: 'health-information.procedures.external.dispute',
						label: 'Dispute External Procedures'
					},
					{
						permission: 'health-information.procedures.ask',
						label: 'Ask a Question for Procedures'
					},
					{
						permission: 'health-information.procedures.education.view',
						label: 'View Education Content for Procedures'
					},
					{
						permission: 'health-information.procedures.mark-private',
						label: 'Mark Procedures as Private'
					}
				]
			},
			{
				id: 'social-histories',
				accessTypes: [
					{
						permission: 'health-information.social-histories.manage',
						label: 'Add/Edit/Delete Patient Entered Social History'
					},
					{
						permission: 'health-information.social-histories.external.dispute',
						label: 'Dispute External Social History'
					},
					{
						permission: 'health-information.social-histories.ask',
						label: 'Ask a Question for Social History'
					},
					{
						permission: 'health-information.social-histories.education.view',
						label: 'View Education Content for Social History'
					},
					{
						permission: 'health-information.social-histories.mark-private',
						label: 'Mark Social History as Private'
					}
				]
			},
			{
				id: 'family-history',
				accessTypes: [
					{
						permission: 'health-information.family-history.manage',
						label: 'Add/Edit/Delete Patient Entered Family History'
					},
					{
						permission: 'health-information.family-history.external.dispute',
						label: 'Dispute External Family History'
					},
					{
						permission: 'health-information.family-history.ask',
						label: 'Ask a Question for Family History'
					},
					{
						permission: 'health-information.family-history.education.view',
						label: 'View Education Content for Family History'
					},
					{
						permission: 'health-information.family-history.mark-private',
						label: 'Mark Family History as Private'
					}
				]
			},
			{
				id: 'test-results',
				accessTypes: [
					{
						permission: 'health-information.test-results.external.dispute',
						label: 'Dispute External Test Results'
					},
					{
						permission: 'health-information.test-results.ask',
						label: 'Ask a Question for Test Results'
					},
					{
						permission: 'health-information.test-results.education.view',
						label: 'View Education Content for Test Results'
					},
					{
						permission: 'health-information.test-results.mark-private',
						label: 'Mark Test Results as Private'
					}
				]
			},
			{
				id: 'clinical-documents',
				accessTypes: [
					{
						permission: 'health-information.clinical-documents.open',
						label: 'Open Clinical Documents'
					},
					{
						permission: 'health-information.clinical-documents.transmit',
						label: 'Transmit Clinical Documents'
					},
					{
						permission: 'health-information.clinical-documents.download',
						label: 'Download Clinical Documents'
					},
					{
						permission: 'health-information.clinical-documents.dispute',
						label: 'Dispute Clinical Documents'
					},
					{
						permission: 'health-information.clinical-documents.mark-private',
						label: 'Mark Clinical Documents as Private'
					}
				]
			}
		]
	};
};
