'use strict';

module.exports = function() {
	var healthInfo = require('./healthInformation')();
	var appointments = require('./appointments')();
	var patientManagement = require('./patientManagement')();
	var requestCenter = require('./requestCenter')();

	var all = {
		id: 'all',
		components: [
			healthInfo,
			appointments,
			patientManagement,
			requestCenter
		],
		accessTypes: [
			{
				permission: 'health-information',
				componentKey: 'health-information',
				label: 'Health Information'
			},
			{
				permission: 'appointments',
				componentKey: 'appointments',
				label: 'Appointments'
			},
			{
				permission: 'evisits.view',
				componentKey: 'evisits',
				label: 'eVisit'
			},
			{
				permission: 'patient-management',
				componentKey: 'patient-management',
				label: 'Patient Management'
			},
			{
				permission: 'request-center',
				componentKey: 'request-center',
				label: 'Request Center'
			}
		]
	};

	return all;
};
