'use strict';

module.exports = function() {
	return {
		id: 'request-center',
		accessTypes: [
			{
				permission: 'request-center.requests.create',
				label: 'Submit New Requests'
			}
		]
	};
};
