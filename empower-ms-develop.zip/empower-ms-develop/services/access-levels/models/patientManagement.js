'use strict';

module.exports = function() {
	return {
		id: 'patient-management',
		accessTypes: [
			{
				permission: 'patient-management.demographics.view',
				componentKey: 'demographics',
				label: 'View Demographics'
			},
			{
				permission: 'patient-management.profileactivity.view',
				label: 'View Profile Activity'
			},
			{
				permission: 'patient-management.profile-image.view',
				componentKey: 'profile-image',
				label: 'View Profile Image'
			},
			{
				permission: 'patient-management.locations.view',
				componentKey: 'locations',
				label: 'View Locations'
			},
			{
				permission: 'patient-management.pharmacies.view',
				componentKey: 'pharmacies',
				label: 'View Pharmacies'
			},
			{
				permission: 'patient-management.emergency-contacts.view',
				componentKey: 'emergency-contacts',
				label: 'View Emergency Contacts'
			},
			{
				permission: 'patient-management.insurances.view',
				componentKey: 'insurances',
				label: 'View Insurances'
			},
			{
				permission: 'patient-management.physicians.view',
				componentKey: 'physicians',
				label: 'View Physicians'
			},
			{
				permission: 'patient-management.guarantors.view',
				componentKey: 'guarantors',
				label: 'View Guarantors'
			},
			{
				permission: 'patient-management.share-access',
				label: 'Share Access'
			},
			{
				permission: 'patient-management.invitations.view',
				componentKey: 'invitations',
				label: 'View Pending Invitations'
			}
		],
		components: [
			{
				id: 'demographics',
				accessTypes: [
					{
						permission: 'patient-management.demographics.manage',
						label: 'Edit/Copy Demographics'
					}
				]
			},
			{
				id: 'profile-image',
				accessTypes: [
					{
						permission: 'patient-management.profile-image.manage',
						label: 'Add/Change/Remove Image'
					}
				]
			},
			{
				id: 'locations',
				accessTypes: [
					{
						permission: 'patient-management.locations.manage',
						label: 'Add/Delete/Copy Locations'
					}
				]
			},
			{
				id: 'pharmacies',
				accessTypes: [
					{
						permission: 'patient-management.pharmacies.manage',
						label: 'Add/Delete/Copy Pharmacies'
					}
				]
			},
			{
				id: 'emergency-contacts',
				accessTypes: [
					{
						permission: 'patient-management.emergency-contacts.manage',
						label: 'Add/Edit/Delete/Copy Emergency Contacts'
					}
				]
			},
			{
				id: 'insurances',
				accessTypes: [
					{
						permission: 'patient-management.insurances.manage',
						label: 'Add/Edit/Delete/Copy Insurances'
					}
				]
			},
			{
				id: 'physicians',
				accessTypes: [
					{
						permission: 'patient-management.physicians.manage',
						label: 'Add/Delete/Copy Physicians'
					}
				]
			},
			{
				id: 'guarantors',
				accessTypes: [
					{
						permission: 'patient-management.guarantors.manage',
						label: 'Add/Edit/Delete/Copy Guarantors'
					}
				]
			},
			{
				id: 'invitations',
				accessTypes: [
					{
						permission: 'patient-management.invitations.edit',
						label: 'Edit Invitations'
					},
					{
						permission: 'patient-management.invitations.resend',
						label: 'Resend Invitations'
					},
					{
						permission: 'patient-management.invitations.expire',
						label: 'Expire Invitations'
					}
				]
			}
		]
	};
};
