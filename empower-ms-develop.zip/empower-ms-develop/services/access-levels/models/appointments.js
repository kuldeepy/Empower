'use strict';

module.exports = function() {
	return {
		id: 'appointments',
		accessTypes: [
			{
				permission: 'appointments.future.view',
				componentKey: 'future',
				label: 'View Appointments'
			},
			{
				permission: 'appointments.past.view',
				componentKey: 'past',
				label: 'View Past Appointments'
			}
		],
		components: [
			{
				id: 'future',
				accessTypes: [
					{
						permission: 'appointments.future.schedule',
						label: 'Schedule Appointment'
					},
					{
						permission: 'appointments.future.reschedule',
						label: 'Reschedule Appointment'
					},
					{
						permission: 'appointments.future.cancel',
						label: 'Cancel Appointment'
					},
					{
						permission: 'appointments.future.export',
						label: 'Export to Calendar'
					},
					{
						permission: 'appointments.future.preregister',
						label: 'Preregister for Appointment'
					}
				]
			},
			{
				id: 'past',
				accessTypes: [
					{
						permission: 'appointments.past.rebook',
						label: 'Re-book Appointment'
					},
					{
						permission: 'appointments.past.export',
						label: 'Export to Calendar'
					}
				]
			}
		]
	};
};
