'use strict';

var gulp = require('gulp');

gulp.task('start', function() {
    require('./empower-profile-search.js');
});

gulp.task('test', function() {
    
});

gulp.task('test-coverage', function () {
  var mocha = require('gulp-mocha'),
      cover = require('gulp-coverage');;
  return gulp.src(['./test/*.test*.js'],{read: false})
    .pipe(cover.instrument({
        pattern: ['empower*js']
    }))
    .pipe(mocha())
    .pipe(cover.gather())
    .pipe(cover.format())
    .pipe(gulp.dest('reports'));
});

function getOptions(defaults) {
    var args = process.argv[0] == 'node' ? process.argv.slice(3) : process.argv.slice(2);
    var minimist = require('minimist');
    return minimist(args, {
        default: defaults
    });
}
