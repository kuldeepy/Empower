'use strict';
var micro = require('ih-microservice');

var defaults = {
  id: 'empower-profiles',
  debug: true,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-profiles',
  defaultReturnBody: true,
  communicateDb: 'MedseekIntegration60',
  pageSize: '20'
};

micro(defaults, function(app, logging, microservices, bluebird, options, url, _, util) {
  options.pageSize = parseInt(options.pageSize,10);
  var Promise = bluebird, db;
  var log = logging.getLogger('empower-profiles');
  var knownPgs = {};

  return Promise.resolve(microservices.bind('empower.profiles.search.#', searchProfiles));
  
  function searchProfiles(req,mc) {
     req.searchType = (req.searchType || 'Both').toLowerCase();
     return getKnownDb(parseInt(_.last(mc.routingKey.split('.')),10))
      .then(function(db){
        return querySource(req,db)
          .then(function(data){
            return data;
          }).catch(function(err){
            return err;
          });
      })
      .catch(function(err){
        log.error(err);
        return err;
      });
  }

  function getKnownDb(id){
    return new Promise(function(resolve){
      log.trace('knownPgs for id %s: ',id, knownPgs[id]);
      resolve(knownPgs[id]);
    })
    .then(function(pg){
      return pg || microservices.call('empower.v6.portal-groups.get',{})
        .tap(function(pgs){
          log.trace(pgs);
        })
        .then(function(pgs){
          var pg = _.find(pgs,{siteID: id });
          knownPgs[id] = toMssqlConfig(pg.mssql).database;
          return knownPgs[id];
        });
    });
  }

  function querySource(req,pgDb){
    var qString = '\n' +
    '     SELECT * FROM ( \n' +
    '        SELECT ROW_NUMBER ( ) OVER (ORDER By firstName) AS row, userid, medseekPatientId, firstName, lastName, middleName, mrn, email, dateOfBirth, enrollmentStatus, preferredLanguage \n' +
    '            FROM ( \n' 

    if(req.searchType !== 'accountholder')
      qString +=  '            Select \n' +
      '              0 AS userid, \n' +
      '              p.medseekPatientId, \n' +
      '              p.PatientName_GivenName AS firstName,\n' +
      '              p.PatientName_FamilyName AS lastName, \n' +
      '              p.PatientName_FurtherGivenName AS middleName,\n' +
      '               (  \n' +
      '                SELECT TOP 1 Identifier FROM ' + options.communicateDb +'.[dbo].[ps_Patients] pi (NOLOCK)\n' +
      '                  WHERE pi.medseekPatientId = p.medseekPatientId \n' + getExternalIdWhere(req) +
      '              ) AS mrn, \n' +
      '              null as preferredLanguage, \n' +
      '              NULL as email, \n' +
      '              p.dateOfBirth, \n' +
      '             COALESCE(status.Status, \'NotInvited\') as enrollmentStatus \n'+
      '            FROM ' + options.communicateDb +'.[dbo].[ps_PatientDemographics] p (NOLOCK) \n' +
      '            LEFT JOIN '+options.communicateDb +'.[dbo].[ps_EnrollmentInvitationStatus] status (NOLOCK) on status.medseekPatientId = p.medseekPatientId \n ' +
      '          ' + getCommunicateWhere(req) + ' \n';
    if(req.searchType === 'both')
      qString += '          UNION \n';

    if(req.searchType !== 'patient')
      qString += '          SELECT  \n' +
      '            e.ref AS userid,  \n' +
      '            NULL AS medseekPatientId,  \n' +
      '            e.firstName,  \n' +    
      '            e.lastName,  \n' +
      '            e.middleName,  \n' +
      '            null as mrn, \n' +
      '            e.preferredLanguage, \n' + 
      '            e.email, \n' +
      '            e.dateOfBirth \n, ' +
      '            NULL as enrollmentStatus \n'+
      '            FROM [' + pgDb + '].[dbo].enAuthUsers e (NOLOCK) \n' +
      '            INNER JOIN [' + pgDb + '].[dbo].enAuthGroupMembers gm (NOLOCK) on gm.enAuthRef = e.ref \n ' +
      '            INNER JOIN [' + pgDb + '].[dbo].enAuthGroups g (NOLOCK) on gm.enAuthGroupRef = g.ref \n ' +
      '            INNER JOIN [' + pgDb + '].[dbo].CmsPortals p (NOLOCK) on p.PortalType = 2 AND p.Id = g.portalId \n ' +
      '          ' + getEmpowerWhere(req) + ' group by e.ref, e.firstname, e.lastname, e.middlename, e.email, e.dateofbirth, e.preferredLanguage';

    qString +=  '           ) AS U ) AS Profiles ' + rowNumberClause(req);
    return query({
                  q: qString,
                  qp: getWhereParameters(req)
                });
                
  }

  function query(q){
    return microservices.call('empower.v6.portal-groups.mssql.query.pg-1',q)
      .tap(function(results){
        log.trace('get| query results', util.inspect(results, { colors: true, depth: null }));
      })
      .then(function(results){
        return results;
      });
  }

  function getEmpowerWhere(req){
    var where = (req.firstName || req.lastName || req.email) ? 'WHERE ' : '';
    
    if(req.fullName){
      if(_.compact(req.fullName.split(' ')).length > 1){
        return 'WHERE (e.firstName like \'\' + @fullName1 + \'%\' AND e.lastName like \'\' + @fullName2 + \'%\') ' +
              ' OR (e.firstName like \'\' + @fullName2 + \'%\' AND e.lastName like \'\' + @fullName1 + \'%\') ';
      }
      return 'WHERE e.firstName like \'\' + @fullName1 + \'%\' OR e.lastName like \'\' + @fullName1 + \'%\' ' +
              ' OR e.firstName like \'\' + @fullName2 + \'%\' OR e.lastName like \'\' + @fullName2 + \'%\' ';
    }
    if(req.userId){
      return 'WHERE e.ref = @userId';
    }
    if(req.firstName){
      where += ' e.firstName like \'\' + @firstName  + \'%\'';
      if(req.lastName || req.email){
        where += ' AND ';
      }
    }
    if(req.lastName){
      where += ' e.lastName like \'\' + @lastName + \'%\'';
      if(req.email){
        where += ' AND ';
      }
    }

    if(req.email){
      where += ' e.email like \'%\' + @email + \'%\'';
    }
    return where;
  }
  function getCommunicateWhere(req){

    var where = (req.medseekId || req.firstName || req.lastName || req.email || req.externalId) ? 'WHERE ' : '';
    if(req.fullName){
      if(_.compact(req.fullName.split(' ')).length > 1){
        return 'WHERE (p.PatientName_GivenName like \'\' + @fullName1 + \'%\' AND p.PatientName_FamilyName like \'\' + @fullName2 + \'%\') ' +
              ' OR (p.PatientName_GivenName like \'\' + @fullName2 + \'%\' AND p.PatientName_FamilyName like \'\' + @fullName1 + \'%\') ';
      }
      return 'WHERE p.PatientName_GivenName like \'\' + @fullName1 + \'%\' OR p.PatientName_FamilyName like \'\' + @fullName1 + \'%\' ' +
              ' OR p.PatientName_GivenName like \'\' + @fullName2 + \'%\' OR p.PatientName_FamilyName like \'\' + @fullName2 + \'%\' ';
    }

    if(req.medseekId){
      where += ' p.medseekPatientId = @medseekId';
      if(req.firstName || req.lastName || req.email || req.externalId){
        where += ' AND ';
      }
    }

    if(req.firstName){
      where += ' p.PatientName_GivenName like \'\' + @firstName  + \'%\'';
      if(req.lastName || req.email || req.externalId){
        where += ' AND ';
      }
    }
    if(req.lastName){
      where += ' p.PatientName_FamilyName like \'\' + @lastName + \'%\'';
      if(req.email || req.externalId){
        where += ' AND ';
      }
    }
    if(req.email){
      where += ' 1 = 0';
      if(req.externalId)
        where += ' AND '
    }

    if(req.externalId)
      where += '(SELECT TOP 1 Identifier FROM ' + options.communicateDb +'.[dbo].[ps_Patients] pi \n' +
      '                  WHERE pi.medseekPatientId = p.medseekPatientId \n' + getExternalIdWhere(req) + ') IS NOT NULL';

    return where;
  }
  function getWhereParameters(req){
    var params = {};
    if(req.userId){
      params.userId = qp(req.userId);
    }
    if(req.medseekId){
      params.medseekId = qp(req.medseekId);
    }
    if(req.firstName){
      params.firstName = qp(req.firstName);
    }
    if(req.lastName){
      params.lastName = qp(req.lastName);
    }
    if(req.email){
      params.email = qp(req.email);
    }
    if(req.fullName){
      var parts = _.compact(req.fullName.split(' '))
      params.fullName1 = qp(parts[0]);
      params.fullName2 = qp(parts[1] || parts[0]);
    }
    if(req.externalId){
      params.externalId = qp(req.externalId);
    }
    return params;
  }
  
  function getExternalIdWhere(req){
    if(req.externalId){
      return ' AND Identifier like \'%\' + @externalId + \'%\' \n';
    }
    return '';
  }

  function rowNumberClause(req){
    return 'WHERE row > ' + 
      ((req.pageSize || options.pageSize) * ((req.pageNumber || 1) - 1 )) +
      ' AND row < ' + 
      (((req.pageSize || options.pageSize) + 1) * (req.pageNumber || 1));
  }

  function qp(value) {
      return {
        type: 'NVarChar',
        value: value,
        length: value.length
      };
  }

  function toMssqlConfig(uri) {
      var parsed = url.parse(uri, true);
      if (parsed.protocol !== 'mssql:')
          throw new Error('Unsupported protocol: ' + parsed.protocol);
      var authParts =  parsed.auth ? _.compact(parsed.auth.split(':')) : [];
      var hostParts = _.compact(parsed.host.split(':'));
      var pathParts = _.compact(parsed.pathname.split('/'));
      var config = {
          server: parsed.hostname,
          port: hostParts.length > 1 ? hostParts[1] : undefined,
          user: parsed.auth && parsed.auth.length > 0 ? authParts[0] : undefined,
          password: parsed.auth && parsed.auth.length > 1 ? authParts[1] : undefined,
          database: _.first(pathParts),
          options: parsed.query
      };
      if (pathParts.length > 1) {
          config.server += '\\' + pathParts[0];
          config.database = pathParts[1];
      }
      _.forEach(parsed.query, function(x, k, o) {
          var s = ('' + x).toLowerCase();
          if (s === 'true' || s === 'false') {
              o[k] = s === 'true';
          }
      });
      _.defaults(config, (db || {}).config);
      log.debug('toMssqlConfig| uri: %s, config:', uri, config);
      return config;
  }
});