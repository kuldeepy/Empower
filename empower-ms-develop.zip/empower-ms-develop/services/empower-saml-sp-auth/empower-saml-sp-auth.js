'use strict';

var _ = require('lodash');
var micro = require('ih-microservice');
var util = require('util');
var Promise = require('bluebird');
var appScope = require('./app-scope');
var findUserMatchingClaims = require('./find-user-matching-claims');
var userInPortal = require('./user-in-portal');
var signInAs = require('./sign-in-as');
var createUserFromClaims = require('./create-user-from-claims');
var getSsoConfig = require('./get-sso-config');

var defaults = {
  id: 'empower-saml-sp-auth',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-saml-sp-auth',
  defaultReturnBody: true
};

micro(defaults, function(logging, microservices) {
  appScope.logging = logging;
  appScope.microservices = microservices;

  var log = logging.getLogger(defaults.id);

  module.exports = {
    loginWithClaims: loginWithClaims
  };

  return Promise.all([microservices.bind('empower.saml.sp.session.start.#', loginWithClaims)]);

  function loginWithClaims(request, messageContext) {
    return Promise.try(
      function() {
        log.debug('loginWithClaims');
        log.trace('request', util.inspect(request, {
          depth: null
        }));
        var portalInfo = getPortalInfo();
        log.trace('portalInfo', portalInfo);
        return findUserMatchingClaims(request.claims, portalInfo).then(function(users) {
          log.trace('users', users);
          if (users.length === 1) {
            var user = users[0];
            return userInPortal(user, portalInfo).then(function(inPortal) {
              if (inPortal) {
                return signInAs(user, portalInfo);
              }
              return notAuthenticated('user not permitted to log into portal');
            });
          } else if (users.length === 0) {
            return getSsoConfig(request.ssoConfigId, portalInfo).then(function(ssoConfig) {
              return createUserFromClaims(request.claims, portalInfo, ssoConfig).then(function(user) {
                if (user) {
                  return signInAs(user, portalInfo);
                }
                return notAuthenticated('user not found');
              });
            });
          } else {
            return notAuthenticated('multiple users found matching claims');
          }
        });
      }
    ).catch(function(err) {
      log.error(err);
      return {
        error: err.message || err.toString()
      };
    });

    function getPortalInfo() {
      return {
        id: request.portalId,
        group: request.portalGroup,
        groupId: _.last(messageContext.routingKey.split('.'))
      };
    }

    function notAuthenticated(reason) {
      log.debug('User not authenticated:', reason);
      return {
        info: reason
      };
    }
  }
});