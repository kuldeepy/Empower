'use strict';
var util = require('util');
var Promise = require('bluebird');
var _ = require('lodash');
var appScope = require('./app-scope');

var log;
var microservices;

module.exports = function(claims, portalInfo, ssoConfig) {

  log = log || appScope.logging.getLogger('empower-saml-sp-auth.find-patient-matching-claims');
  microservices = microservices || appScope.microservices;
  
  return Promise.try(
    function() {

      /*
      These are the claims that could be received:
      ProfileCurrentPatient SourceId    // Required.  This must be specified by the IDP as the external patient identifier.
      ProfileCurrentPatient InternalId  // (not used in Service Provider scenario)
      ProfileCurrentPatient FirstName   // Optional. Search by first name also, if present.
      ProfileCurrentPatient LastName    // Optional. Search by last name also, if present.
      ProfileCurrentPatient DateOfBirth // Optional. Search by DOB also, if present.
      ProfileCurrentPatient Email       // (not used)
      ProfileCurrentPatient Ids         // (not used in Service Provider scenario)
      */

      if (!claims.ProfileCurrentPatient) {
        return Promise.reject('ProfileCurrentPatient claims required to find a patient');
      }
      if (!claims.ProfileCurrentPatient.SourceId) {
        return Promise.reject('ProfileCurrentPatient.SourceId claim required to find a patient');
      }
      log.trace('searching for patients matching claims', util.inspect(claims.ProfileCurrentPatient, {
        depth: null
      }));

      var search = {
        pageNumber: 1,
        pageSize: 2
      };

      addSearchTerm('externalId', claims.ProfileCurrentPatient.SourceId);
      addSearchTerm('firstName', claims.ProfileCurrentPatient.FirstName);
      addSearchTerm('lastName', claims.ProfileCurrentPatient.LastName);
      addSearchTerm('dateOfBirth', claims.ProfileCurrentPatient.DateOfBirth);

      return microservices.call('empower.platform.patients.search.' + portalInfo.groupId, search)
        .then(function(reply) {
          if (reply.error) {
            throw new Error(reply.error);
          }
          log.debug('found patients', util.inspect(reply, {
            depth: null
          }));
          return reply;
        })
        .then(filterDuplicates)
        .then(appendSourceId);

      function addSearchTerm(key, value) {
        if (value) {
          search[key] = value;
        }
      }

      function filterDuplicates(results) {
        if (results.length > 1) {
          return Promise.resolve(_.filter(results, matchOnSourceGroup));
        }
        return Promise.resolve(results);

        function matchOnSourceGroup(patient) {
          return _.some(patient.externalId, function(id) {
            return id.SourceAssigningFacility === ssoConfig.sourceGroup && id.SourceId == claims.ProfileCurrentPatient.SourceId;
          });
        }
      }

      function appendSourceId(results) {
        results.forEach(function(patient) {
          patient.sourceId = claims.ProfileCurrentPatient.SourceId;
        });
        return Promise.resolve(results);
      }
    });
};