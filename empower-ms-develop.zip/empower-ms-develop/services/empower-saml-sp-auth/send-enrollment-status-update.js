'use strict';
var Promise = require('bluebird');
var appScope = require('./app-scope');

var microservices;
var log;

var CALL_PROPERTIES = {
  Route: 'MedSeek.Portal.Module.EcoEnablementProvider.IEcoEnablementProvider.SendEnrollmentStatusUpdate',
  Contract: 'MedSeek.Portal.Module.EcoEnablementProvider.IEcoEnablementProvider, MedSeek.Portal.Module.EcoEnablementProvider',
  Method: 'SendEnrollmentStatusUpdate',
  ParameterTypes: [
    'System.String',
    'System.String',
    'System.Boolean'
  ],
  Service: 'IEcoEnablementProvider'
};

module.exports = function(medseekId, status, portalInfo) {

  log = log || appScope.logging.getLogger('empower-saml-sp-auth.send-enrollment-status-update');
  microservices = microservices || appScope.microservices;

  return Promise.try(
    function() {
      log.debug('sending enrollment status update', medseekId, status);
      var address = 'Empower.Api.Proxy.' + portalInfo.group;
      var body = {
        medseekId: medseekId,
        status: status,
        sendOutboundMessage: true
      };
      return microservices.call(address, body, CALL_PROPERTIES, {
          timeout: 60000
        })
        .then(function(result) {
          log.trace('result', result);
        });
    }
  );
};