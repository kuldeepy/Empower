'use strict';

var appScope = require('./app-scope');
var log;
var microservices;

module.exports = function(portalInfo, query) {
  microservices = microservices || appScope.microservices;
  log = log || appScope.logging.getLogger('empower-saml-sp-auth.submit-query');
  log.trace('submitting query', query.q);

  return microservices.call('empower.v6.portal-groups.mssql.query.' + portalInfo.groupId, query)
    .then(function(results) {
      checkError(results);
      return results;
    });

  function checkError(results) {
    if (results.error) {
      throw new Error('Error running query: ' + results.error);
    }
  }
};