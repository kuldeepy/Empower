'use strict';
var Promise = require('bluebird');
var submitQuery = require('./submit-query');
var appScope = require('./app-scope');
var log;

var QUERY = "IF EXISTS (SELECT m.ref FROM enAuthGroupMembers m " +
  " JOIN enAuthGroups g ON m.enAuthGroupRef = g.ref" +
  " WHERE g.portalId = @portalId AND m.enAuthRef = @userId" +
  " AND g.[permissions].value('(/permissions/permission/permissionId)[1]', 'varchar(50)')  = 'login'" +
  " AND ISNULL(g.IsDisabled, 0) = 0 AND m.IsUser = 1)" +
  " SELECT 1 ELSE SELECT 0;";

module.exports = function(user, portalInfo) {
  log = log || appScope.logging.getLogger('empower-saml-sp-auth.user-in-portal');
  
  return Promise.try(
    function() {
      log.debug('checking if user %s has login permission in portal %s', user.userId, portalInfo.id);
      var query = makeQuery();
      return submitQuery(portalInfo, query).then(function(results) {
        log.trace('results', results);
        var row = results[0];
        var val = row[Object.keys(row)[0]];
        return val === 1;
      });
    }
  );

  function makeQuery() {
    return {
      q: QUERY,
      qp: {
        portalId: {
          value: portalInfo.id,
          type: 'Int'
        },
        userId: {
          value: user.userId,
          type: 'Int'
        }
      }
    };
  }
};