'use strict';

var Promise = require('bluebird');
var submitQuery = require('./submit-query');
var appScope = require('./app-scope');

var log;

module.exports = function(claims, portalInfo) {

log = log || appScope.logging.getLogger('empower-saml-sp-auth.find-user-matching-claims');

  return Promise.try(
    function() {
      var query = makeQuery();
      if (Object.keys(query.qp).length === 0) {
        return Promise.resolve([]);
      }
      return submitQuery(portalInfo, query);
    }
  );

  function makeQuery() {
    var sql = 'SELECT TOP 2 ref as userId from enAuthUsers WHERE deleted = 0 AND IsDisabled = 0';
    var params = {};

    if (claims.UserProfileData) {
      addParam('username', claims.UserProfileData.Username);
      addParam('firstName', claims.UserProfileData.FirstName);
      addParam('lastName', claims.UserProfileData.LastName);
      addParam('email', claims.UserProfileData.Email);
    }

    return {
      q: sql,
      qp: params
    };

    function addParam(name, value) {
      if (value) {
        sql += ' AND ' + name + ' = @' + name;
        params[name] = {
          value: value,
          type: 'NVarChar',
          length: value.length
        };
      }
    }
  }
};