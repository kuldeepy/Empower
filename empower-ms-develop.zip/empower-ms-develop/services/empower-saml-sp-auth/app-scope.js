'use strict';
module.exports = {};