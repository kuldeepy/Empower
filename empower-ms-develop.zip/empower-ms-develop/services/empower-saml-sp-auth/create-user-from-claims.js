'use strict';
var uuid = require('node-uuid');
var util = require('util');
var submitQuery = require('./submit-query');
var findPatientMatchingClaims = require('./find-patient-matching-claims');
var createUserPatientRelationship = require('./create-user-patient-relationship');
var Promise = require('bluebird');
var appScope = require('./app-scope');
var log;

var PATIENT_PORTAL_TYPE = 2;

module.exports = function(claims, portalInfo, ssoConfig) {

  log = log || appScope.logging.getLogger('empower-saml-sp-auth.create-user-from-claims');

  return Promise.try(
    function() {
      return validateClaims()
        .bind({})
        .then(function() {
          return getPortal();
        })
        .then(function(portal) {
          this.portal = portal;
          return createUser(portal);
        })
        .then(function(user) {
          this.user = user;
          return assignDefaultRole(user, this.portal);
        })
        .then(function() {
          return this.user;
        });
    }
  );

  function validateClaims() {
    if (!claims.UserProfileData) {
      return Promise.reject('UserProfileData claims required to create user');
    }
    if (!claims.UserProfileData.Username && !claims.UserProfileData.Email) {
      return Promise.reject('UserProfileData claims must have a Username or Email to create a user');
    }
    return Promise.resolve();
  }

  function getPortal() {
    log.trace('getting portal', portalInfo.id);
    var query = {
      q: 'SELECT portalType, primaryRoleId FROM CmsPortals WHERE Id = @id;',
      qp: {
        id: {
          type: 'Int',
          value: portalInfo.id
        }
      }
    };
    return submitQuery(portalInfo, query)
      .then(function(result) {
        var portal = result[0];
        log.debug('got portal', portal);
        return portal;
      });
  }

  function createUser(portal) {
    if (portal.portalType === PATIENT_PORTAL_TYPE) {
      return createPatientUser();
    } else {
      return createUserAccount();
    }

    function createPatientUser() {
      return findPatientMatchingClaims(claims, portalInfo, ssoConfig)
        .bind({})
        .then(function(patients) {
          return validatePatients(patients);
        })
        .then(function(patient) {
          this.patient = patient;
          return createUserAccount(patient);
        })
        .then(function(user) {
          this.user = user;
          return createUserPatientRelationship(this.patient, user, portalInfo)
            .catch(function(err) {
              log.warn('rolling back', err);
              return rollBackCreatedUser(user)
                .then(function() {
                  return Promise.reject(err);
                });
            });
        })
        .then(function() {
          return this.user;
        });
    }

    function createUserAccount(optionalPatient) {
      log.trace('creating user account from claims', util.inspect(claims.UserProfileData, {
        depth: null
      }));
      var query = {
        q: 'INSERT INTO enAuthUsers (username, email, firstname, lastname, description,' +
          ' deleted, created, IsDisabled, title, suffix, lastAuthGroupId) VALUES (@username, @email,' +
          ' @firstName, @lastName, @description, 0, GETDATE(), 0, 0, 0, @lastAuthGroupId);' +
          ' SELECT SCOPE_IDENTITY() as userId;',
        qp: getParams()
      };
      return submitQuery(portalInfo, query, {
        multi: true
      }).then(function(res) {
        var user = res[0];
        log.debug('created user', user);
        return user;
      });

      function getParams() {
        var params = {};
        var userData = claims.UserProfileData;
        addParam('username', userData.Username || userData.Email);
        addParam('email', userData.Email || (optionalPatient || {}).emailAddress || uuid.v1());
        addParam('firstName', userData.FirstName || (optionalPatient || {}).firstName || 'unspecified');
        addParam('lastName', userData.LastName || (optionalPatient || {}).lastName || 'unspecified');
        addParam('description', 'Created from SAML claims');
        params.lastAuthGroupId = {
          type: 'Int',
          value: portal.primaryRoleId
        };
        return params;

        function addParam(name, value) {
          params[name] = {
            type: 'NVarChar',
            value: value,
            length: value.length
          };
        }
      }
    }
  }

  function rollBackCreatedUser(user) {
    log.trace('removing previously created user', user);
    var query = {
      q: 'DELETE FROM enAuthUsers WHERE ref = @userId;' +
        ' DELETE FROM nModProfileAuthUserRelationship WHERE AuthUserId = @userId' +
        " AND RelationshipClassification = 'Self';",
      qp: {
        userId: {
          type: 'Int',
          value: user.userId
        }
      }
    };
    return submitQuery(portalInfo, query, {
      multi: true
    }).then(function() {
      log.debug('removed previously created user', user);
    });
  }

  function validatePatients(patients) {
    if (patients.length === 0) {
      return Promise.reject('No patient was found matching the provided claims.');
    }
    if (patients.length !== 1) {
      return Promise.reject('Multiple patients were found matching the provided claims.');
    }
    return Promise.resolve(patients[0]);
  }

  function assignDefaultRole(user, portal) {
    log.trace('adding user %s to roleId %s', user.userId, portal.primaryRoleId);
    var query = {
      q: 'INSERT INTO enAuthGroupMembers (enAuthGroupRef, enAuthRef, IsUser)' +
        ' VALUES (@roleId, @userId, 1);',
      qp: {
        roleId: {
          type: 'Int',
          value: portal.primaryRoleId
        },
        userId: {
          type: 'Int',
          value: user.userId
        }
      }
    };
    return submitQuery(portalInfo, query)
      .then(function() {
        log.debug('added user to role');
      })
      .catch(function(err) {
        log.warn('rolling back', err);
        return rollBackCreatedUser(user)
          .then(function() {
            return Promise.reject(err);
          });
      });
  }
};