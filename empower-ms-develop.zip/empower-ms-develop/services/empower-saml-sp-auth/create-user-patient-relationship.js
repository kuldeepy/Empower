'use strict';
var uuid = require('node-uuid');
var util = require('util');
var Promise = require('bluebird');
var empowerStates = require('./empower-states-by-name.json');
var submitQuery = require('./submit-query');
var sendEnrollmentStatusUpdate = require('./send-enrollment-status-update');
var appScope = require('./app-scope');

var log;

module.exports = function(patient, user, portalInfo) {

  log = log || appScope.logging.getLogger('empower-saml-sp-auth.create-user-patient-relationship');
  
  return Promise.try(
    function() {
      return getEmpowerPatient()
        .bind({})
        .then(function(existingPatient) {
          if (existingPatient) {
            return Promise.resolve(existingPatient);
          } else {
            return createEmpowerPatient();
          }
        })
        .then(function(empowerPatient) {
          this.empowerPatient = empowerPatient;
          return checkForSelfRelationships(empowerPatient);
        })
        .then(function() {
          return createUserPatientAssociation(user, this.empowerPatient);
        })
        .then(function() {
          return sendEnrollmentStatusUpdate(patient.medseekId, 'Enrolled', portalInfo);
        });
    });

  function getEmpowerPatient() {
    log.trace('getting empower patient', patient.medseekId);
    var query = {
      q: 'SELECT TOP 1 Id as patientId FROM nModProfilePatients WHERE UniqueId = @medseekId;',
      qp: {
        medseekId: {
          type: 'UniqueIdentifier',
          value: patient.medseekId
        }
      }
    };
    return submitQuery(portalInfo, query).then(function(res) {
      var empowerPatient = res[0];
      log.debug('found empower patient', empowerPatient || '(none)');
      return empowerPatient;
    });
  }

  function createEmpowerPatient() {
    log.trace('creating patient record in empower', patient.medseekId);
    var query = {
      q: 'INSERT INTO nModProfilePatients' +
        ' (FirstName, MiddleName, LastName, Gender, DateOfBirth, EmailAddress, Address1, City, State,' +
        '  ZipCode, SocialSecurityNumber, MedicalRecordNumber, UniqueId, CreatedOn, LastUpdatedOn)' +
        ' VALUES ' +
        ' (@firstName, @middleName, @lastName, @gender, @dateOfBirth, @emailAddress, @address1, @city, @state,' +
        '  @zipCode, @ssn, @medicalRecordNumber, @uniqueId, GETDATE(), GETDATE());' +
        ' SELECT SCOPE_IDENTITY() as patientId;',
      qp: {
        firstName: nvParam(patient.firstName),
        middleName: nvParam(patient.middleName),
        lastName: nvParam(patient.lastName),
        gender: nvParam(patient.gender || '1'),
        dateOfBirth: nvParam(patient.dateOfBirth),
        emailAddress: nvParam(patient.emailAddress),
        address1: nvParam(patient.addressLine1),
        city: nvParam(patient.city),
        state: {
          type: 'Int',
          value: getStateId(patient.stateName),
        },
        zipCode: nvParam(patient.zipCode),
        ssn: nvParam(patient.ssn),
        medicalRecordNumber: nvParam(patient.sourceId),
        uniqueId: {
          type: 'UniqueIdentifier',
          value: patient.medseekId
        },
      }
    };
    return submitQuery(portalInfo, query).then(function(res) {
      var empowerPatient = res[0];
      log.debug('created patient', empowerPatient);
      return res[0];
    });

    function nvParam(value) {
      return {
        type: 'NVarChar',
        value: value || null,
        length: value ? value.length : 0
      };
    }

    function getStateId(stateName) {
      if (!stateName) {
        return null;
      }
      var stateId = empowerStates[stateName];
      if (!stateId) {
        return null;
      }
      return stateId;
    }
  }

  function checkForSelfRelationships(empowerPatient) {
    log.trace('checking for self-relationship for patient', empowerPatient.patientId);
    var query = {
      q: "IF EXISTS (SELECT * FROM nModProfileAuthUserRelationship WHERE PatientProfileId = @patientId" +
        " AND RelationshipClassification = 'Self') SELECT 1 AS 'relationshipExists' ELSE SELECT 0 AS 'relationshipExists';",
      qp: {
        patientId: {
          type: 'Int',
          value: empowerPatient.patientId
        }
      }
    };
    return submitQuery(portalInfo, query).then(function(results) {
      if (results[0].relationshipExists.toString() === '1') {
        return Promise.reject('Patient already has a self-relationship to another user.');
      }
      log.debug('passed existing self-relationship check');
    });
  }

  function createUserPatientAssociation(user, empowerPatient) {
    return getAccessLevel()
      .then(function(accessLevelId) {
        log.trace('creating user-patient relationship, userId %s, patientId %s', user.userId, patient.patientId);
        var query = {
          q: 'INSERT INTO nModProfileAuthUserRelationship (AuthUserId, PatientProfileId, RelationshipClassification, [Status], IsCurrentContext, AccessLevelId, LockVersion)' +
            " SELECT @userId, @patientId, 'Self', (SELECT TOP 1 Id FROM nModProfileLookup WHERE Value = 'Enabled' AND [Type] = 'ProfileRelationshipStatus')," +
            ' 1, @accessLevelId, 1;',
          qp: {
            userId: {
              type: 'Int',
              value: user.userId
            },
            patientId: {
              type: 'Int',
              value: empowerPatient.patientId
            },
            portalId: {
              type: 'Int',
              value: portalInfo.id
            },
            accessLevelId: {
              type: 'Int',
              value: accessLevelId
            }
          }
        };
        return submitQuery(portalInfo, query).then(function() {
          log.debug('created user-patient relationship');
        });
      });

    function getAccessLevel() {
      log.trace('getting default access level for new user-patient relationship');
      var query = {
        q: "SELECT TOP 1 textValue FROM NModuleSettings WHERE [Key] = 'DefaultHl7Properties' ORDER BY Id;",
        qp: {}
      };
      return submitQuery(portalInfo, query)
        .then(function(res) {
          var row = res[0];
          if (!row || !row.textValue) {
            return Promise.reject('Could not get default Access Level: Default Values for HL7 Invitations are not defined in User Management.');
          }
          var settings = JSON.parse(row.textValue);
          var accessLevelId = settings.AccessLevelId;
          if (!accessLevelId) {
            return Promise.reject('Could not get default Access Level: No Access Level specified in Default Values for HL7 Invitations in User Management.');
          }
          return accessLevelId;
        });
    }
  }
};