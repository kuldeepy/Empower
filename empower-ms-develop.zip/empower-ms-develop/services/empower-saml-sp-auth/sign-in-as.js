'use strict';
var Promise = require('bluebird');
var _ = require('lodash');
var appScope = require('./app-scope');

var log;
var microservices;

var CALL_PROPERTIES = {
  Route: 'MedSeek.Portal.Server.AuthProvider.IAuthManagementBusinessService.SignInAs',
  Contract: 'MedSeek.Portal.Server.AuthProvider.IAuthManagementBusinessService, MedSeek.Portal.Server.AuthProvider.Shared',
  Method: 'SignInAs',
  ParameterTypes: [
    'System.String'
  ],
  Service: 'IAuthManagementBusinessService'
};

module.exports = function(user, portalInfo) {

  log = log || appScope.logging.getLogger('empower-saml-sp-auth.sign-in-as');
  microservices = microservices || appScope.microservices;

  return Promise.try(
    function() {
      log.debug('sign in as', user.userId);
      var address = 'Empower.Api.Proxy.' + portalInfo.group;
      var body = {
        portalUserId: user.userId
      };
      var properties = _.extend(CALL_PROPERTIES, {
        portalId: portalInfo.id
      });
      return microservices.call(address, body, properties, {
          timeout: 60000
        })
        .then(function(result) {
          log.debug('result', result);
          if (result.Retval) {
            return {
              sessionId: result.Retval
            };
          }
          return {};
        });
    }
  );
};