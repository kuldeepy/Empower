'use strict';

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var mockLogging = require('./mock-logging');
var proxyquire = require('proxyquire');

describe('submit-query', function() {

  var appScope,
    microservices,
    submitQuery,
    portalInfo,
    query;

  beforeEach(function() {

    microservices = {
      call: sinon.stub().returns(Promise.resolve({}))
    };

    appScope = {
      logging: mockLogging,
      microservices: microservices
    };

    submitQuery = proxyquire('../submit-query.js', {
      './app-scope': appScope
    });

    portalInfo = {
      groupId: '42'
    };
    query = {
      q: 'SELECT *...',
      qp: {}
    };

    microservices.call.reset();

  });

  it('is a function', function() {
    expect(submitQuery).to.be.a('function');
  });

  describe('given a query object', function() {

    it('calls the microservice', function(done) {
      submitQuery(portalInfo, query).then(function() {
        expect(microservices.call.called).to.equal(true);
        done();
      }).catch(done);
    });

    it('passes the portalGroupId', function(done) {
      submitQuery(portalInfo, query).then(function() {
        expect(microservices.call.getCall(0).args[0]).to.equal('empower.v6.portal-groups.mssql.query.42');
        done();
      }).catch(done);
    });

    it('passes the query object', function(done) {
      submitQuery(portalInfo, query).then(function() {
        expect(microservices.call.getCall(0).args[1]).to.eql(query);
        done();
      }).catch(done);
    });

  });

});