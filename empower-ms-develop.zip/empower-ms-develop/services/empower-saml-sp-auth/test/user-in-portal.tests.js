'use strict';

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var mockLogging = require('./mock-logging');

describe('user-in-portal', function() {

  var appScope,
    submitQuery,
    userInPortal,
    user,
    portalInfo;

  beforeEach(function() {

    appScope = {
      logging: mockLogging
    };

    submitQuery = sinon.stub().returns(Promise.resolve([{
      x: 0
    }]));

    userInPortal = proxyquire('../user-in-portal.js', {
      './app-scope': appScope,
      './submit-query': submitQuery
    });

    user = {
      userId: 1
    };

    portalInfo = {
      groupId: '42',
      id: '2'
    };

    submitQuery.reset();

  });

  it('is a function', function() {
    expect(userInPortal).to.be.a('function');
  });


  describe('when called', function() {

    it('sends the portalInfo', function(done) {
      userInPortal(user, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[0]).to.eql(portalInfo);
        done();
      }).catch(done);
    });

    it('sends a sql query', function(done) {
      userInPortal(user, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[1].q.indexOf('SELECT')).to.not.equal(-1);
        done();
      }).catch(done);
    });

    it('sends the right query params', function(done) {
      userInPortal(user, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[1].qp).to.eql({
          portalId: {
            value: '2',
            type: 'Int'
          },
          userId: {
            value: user.userId,
            type: 'Int'
          }
        });
        done();
      }).catch(done);
    });

    describe('and the query returns 0', function() {
      beforeEach(function() {
        submitQuery.returns(Promise.resolve([{
          x: 0
        }]));
      });

      it('returns false', function(done) {
        userInPortal(user, portalInfo).then(function(result) {
          expect(result).to.equal(false);
          done();
        }).catch(done);
      });
    });

    describe('and the query returns 1', function() {
      beforeEach(function() {
        submitQuery.returns(Promise.resolve([{
          x: 1
        }]));
      });

      it('returns true', function(done) {
        userInPortal(user, portalInfo).then(function(result) {
          expect(result).to.equal(true);
          done();
        }).catch(done);
      });
    });

  });
});