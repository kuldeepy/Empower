'use strict';

var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var mockLogging = require('./mock-logging');
var _ = require('lodash');

describe('find-patient-matching-claims', function() {

  var appScope,
    findPatientMatchingClaims,
    microservices,
    portalInfo,
    ssoConfig,
    claims,
    patient,
    extendedPatient;

  beforeEach(function() {

    portalInfo = {
      groupId: '42'
    };
    ssoConfig = {
      sourceGroup: 'Test'
    };
    microservices = {
      call: sinon.stub().returns(Promise.resolve([]))
    };
    appScope = {
      logging: mockLogging,
      microservices: microservices
    };
    findPatientMatchingClaims = proxyquire('../find-patient-matching-claims', {
      './app-scope': appScope
    });
    microservices.call.reset();
  });


  it('is a function', function() {
    expect(findPatientMatchingClaims).to.be.a('function');
  });

  describe('when called', function() {

    beforeEach(function() {
      claims = {
        UserProfileData: {
          Username: 'user2',
        },
        ProfileCurrentPatient: {
          SourceId: '1234567890',
          FirstName: 'Bart',
          LastName: 'Bear',
          DateOfBirth: '1958-10-05T00:00:00.000Z'
        }
      };
      patient = {
        externalId: [{
          SourceId: '1234567890',
          SourceAssigningFacility: 'Test'
        }],
        medseekId: 'E2F7EA2C-5BB4-4FC8-96D5-4F352D46524C',
        firstName: 'Bart',
        middleName: 'B',
        lastName: 'Bear',
        gender: 2,
        dateOfBirth: '1958-10-05T00:00:00.000Z',
        emailAddress: 'bart@bear.com'
      };
      extendedPatient = _.extend(patient, {
        sourceId: '1234567890'
      });
      microservices.call.returns(Promise.resolve([patient]));
    });

    it('searches the right portal group', function(done) {
      findPatientMatchingClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(microservices.call.getCall(0).args[0]).to.eql('empower.platform.patients.search.42');
        done();
      }).catch(done);
    });

    it('searches by for up to 2 patients', function(done) {
      findPatientMatchingClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(microservices.call.getCall(0).args[1].pageSize).to.equal(2);
        done();
      }).catch(done);
    });

    it('searches by externalId', function(done) {
      findPatientMatchingClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(microservices.call.getCall(0).args[1].externalId).to.eql('1234567890');
        done();
      }).catch(done);
    });

    it('searches by firstName', function(done) {
      findPatientMatchingClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(microservices.call.getCall(0).args[1].firstName).to.eql('Bart');
        done();
      }).catch(done);
    });

    it('searches by lastName', function(done) {
      findPatientMatchingClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(microservices.call.getCall(0).args[1].lastName).to.eql('Bear');
        done();
      }).catch(done);
    });

    it('searches by dateOfBirth', function(done) {
      findPatientMatchingClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(microservices.call.getCall(0).args[1].dateOfBirth).to.eql('1958-10-05T00:00:00.000Z');
        done();
      }).catch(done);
    });

    it('returns the patient with sourceId added', function(done) {
      findPatientMatchingClaims(claims, portalInfo, ssoConfig).then(function(result) {
        expect(result).to.eql([extendedPatient]);
        done();
      }).catch(done);
    });

    describe('and multiple patients found', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Username: 'user2',
          },
          ProfileCurrentPatient: {
            SourceId: '1234567890'
          }
        };
        var otherPatient = {
          externalId: [{
            SourceId: '1234567890',
            SourceAssigningFacility: 'XX'
          }, {
            SourceId: 'A78544',
            SourceAssigningFacility: 'ZZZ'
          }],
          medseekId: '3EAAED49-C0A9-4B57-B46F-E0311667A4C1',
          firstName: 'Carl',
          middleName: 'C',
          lastName: 'Cat',
          gender: 2,
          dateOfBirth: '1970-01-01T00:00:00.000Z',
          emailAddress: 'carl@cat.com'
        };
        microservices.call.returns(Promise.resolve([otherPatient, patient]));
      });

      it('filters by the source group', function(done) {
        findPatientMatchingClaims(claims, portalInfo, ssoConfig).then(function(result) {
          expect(result).to.eql([extendedPatient]);
          done();
        }).catch(done);
      });

    });

    describe('and Patient claims missing', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Username: 'user2',
            FirstName: 'Bart',
            LastName: 'Bear'
          }
        };
      });

      it('rejects', function(done) {
        expect(findPatientMatchingClaims(claims, portalInfo, ssoConfig)).to.be.rejected.notify(done);
      });

    });

    describe('and Patient claims missing SourceId', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Username: 'user2',
            FirstName: 'Bart',
            LastName: 'Bear'
          },
          ProfileCurrentPatient: {
            FirstName: 'Bart',
            LastName: 'Bear'
          }
        };
      });

      it('rejects', function(done) {
        expect(findPatientMatchingClaims(claims, portalInfo, ssoConfig)).to.be.rejected.notify(done);
      });

    });

  });

});