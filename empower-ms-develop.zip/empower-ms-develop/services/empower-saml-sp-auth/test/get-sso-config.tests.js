'use strict';

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var mockLogging = require('./mock-logging');

describe('get-sso-config', function() {

  var appScope,
    getSsoConfig,
    configId,
    ssoConfig,
    portalInfo,
    submitQuery;

  beforeEach(function() {
    appScope = {
      logging: mockLogging
    };
    configId = '10';
    ssoConfig = {};
    portalInfo = {};
    submitQuery = sinon.stub().returns(Promise.resolve([ssoConfig]));
    getSsoConfig = proxyquire('../get-sso-config.js', {
      './app-scope': appScope,
      './submit-query': submitQuery
    });
  });

  it('is a function', function() {
    expect(getSsoConfig).to.be.a('function');
  });

  describe('when called', function() {

    it('sends the portalInfo', function(done) {
      getSsoConfig(configId, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[0]).to.eql(portalInfo);
        done();
      }).catch(done);
    });

    it('sends a sql query', function(done) {
      getSsoConfig(configId, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[1].q.indexOf('SELECT')).to.not.equal(-1);
        done();
      }).catch(done);
    });

    it('sends the right query params', function(done) {
      getSsoConfig(configId, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[1].qp).to.eql({
          configId: {
            value: '10',
            type: 'Int'
          }
        });
        done();
      }).catch(done);
    });

    it('returns the ssoConfig', function(done) {
      getSsoConfig(configId, portalInfo).then(function(result) {
        expect(result).to.eql(ssoConfig);
        done();
      }).catch(done);
    });
  });

});