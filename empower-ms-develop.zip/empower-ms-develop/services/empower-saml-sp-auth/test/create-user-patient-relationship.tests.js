'use strict';

var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var expect = chai.expect;
var sinon = require('sinon');
var Promise = require('bluebird');
var proxyquire = require('proxyquire');
var mockLogging = require('./mock-logging');

describe('create-user-patient-relationship', function() {

  var appScope,
    createUserPatientRelationship,
    submitQuery,
    sendEnrollmentStatusUpdate,
    portalInfo,
    patient,
    user;

  beforeEach(function() {
    appScope = {
      logging: mockLogging
    };
    portalInfo = {
      id: '1',
      groupId: '42'
    };
    submitQuery = sinon.stub().returns(Promise.resolve([]));
    sendEnrollmentStatusUpdate = sinon.stub().returns(Promise.resolve());
    createUserPatientRelationship = proxyquire('../create-user-patient-relationship', {
      './app-scope': appScope,
      './submit-query': submitQuery,
      './send-enrollment-status-update': sendEnrollmentStatusUpdate
    });
    submitQuery.reset();
  });

  it('is a function', function() {
    expect(createUserPatientRelationship).to.be.a('function');
  });

  describe('when called', function() {

    beforeEach(function() {
      patient = {
        sourceId: '1234567890',
        medseekId: 'E2F7EA2C-5BB4-4FC8-96D5-4F352D46524C',
        firstName: 'Bart',
        middleName: 'B',
        lastName: 'Bear',
        gender: 2,
        dateOfBirth: '1958-10-05T00:00:00.000Z',
        emailAddress: 'bart@bear.com',
        addressLine1: '123 Bruin Ct.',
        city: 'Ursa',
        stateName: 'AK',
        zipCode: '90210',
        ssn: '000000000'
      };
      user = {
        userId: 88
      };
      submitQuery.onCall(0).returns(Promise.resolve([{
        patientId: 5
      }]));
      submitQuery.onCall(1).returns(Promise.resolve([{
        relationshipExists: 0
      }]));
      submitQuery.onCall(2).returns(Promise.resolve([{
        textValue: '{"AccessLevelId":20,"ModuleInstanceId":"43","PortalId":null,"RelationShip":"Self","RoleId":"6"}'
      }]));
    });

    it('queries empower for an existing patient', function(done) {
      createUserPatientRelationship(patient, user, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[1].q.indexOf('SELECT TOP 1 Id as patientId FROM nModProfilePatients') === 0).to.equal(true);
        done();
      }).catch(done);
    });

    it('queries by the medseekId', function(done) {
      createUserPatientRelationship(patient, user, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[1].qp.medseekId.value).to.eql('E2F7EA2C-5BB4-4FC8-96D5-4F352D46524C');
        done();
      }).catch(done);
    });

    describe('and patient exists in Empower', function() {

      it('checks for a existing self-relationship with another user', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].q.indexOf('IF EXISTS (SELECT * FROM nModProfileAuthUserRelationship') === 0).to.equal(true);
          done();
        }).catch(done);
      });

      it('checks the patient id for a self-relationship', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.patientId.value).to.equal(5);
          done();
        }).catch(done);
      });

      describe('and a self-relationship already exists with another user', function() {

        beforeEach(function() {
          submitQuery.onCall(1).returns(Promise.resolve([{
            relationshipExists: 1
          }]));
        });

        it('rejects', function(done) {
          expect(createUserPatientRelationship(patient, user, portalInfo)).to.be.rejected.notify(done);
        });
      });

    });

    describe('and patient does not exist in Empower', function() {

      beforeEach(function() {
        submitQuery.onCall(0).returns(Promise.resolve([]));
        submitQuery.onCall(1).returns(Promise.resolve([{
          patientId: 89
        }]));
        submitQuery.onCall(2).returns(Promise.resolve([{
          relationshipExists: 0
        }]));
        submitQuery.onCall(3).returns(Promise.resolve([{
          textValue: '{"AccessLevelId":20,"ModuleInstanceId":"43","PortalId":null,"RelationShip":"Self","RoleId":"6"}'
        }]));
      });

      it('submits a query to create a patient in empower', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].q.indexOf('INSERT INTO nModProfilePatients ') === 0).to.equal(true);
          done();
        }).catch(done);
      });

      it('creates an empower patient with firstName', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.firstName.value).to.equal('Bart');
          done();
        }).catch(done);
      });

      it('creates an empower patient with middleName', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.middleName.value).to.equal('B');
          done();
        }).catch(done);
      });

      it('creates an empower patient with lastName', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.lastName.value).to.equal('Bear');
          done();
        }).catch(done);
      });

      it('creates an empower patient with dateOfBirth', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.dateOfBirth.value).to.eql('1958-10-05T00:00:00.000Z');
          done();
        }).catch(done);
      });

      it('creates an empower patient with gender', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.gender.value).to.equal(2);
          done();
        }).catch(done);
      });

      it('creates an empower patient with emailAddress', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.emailAddress.value).to.equal('bart@bear.com');
          done();
        }).catch(done);
      });

      it('creates an empower patient with address1', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.address1.value).to.equal('123 Bruin Ct.');
          done();
        }).catch(done);
      });

      it('creates an empower patient with city', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.city.value).to.equal('Ursa');
          done();
        }).catch(done);
      });

      it('creates an empower patient with state', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.state.value).to.equal('1002');
          done();
        }).catch(done);
      });

      it('creates an empower patient with zipCode', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.zipCode.value).to.equal('90210');
          done();
        }).catch(done);
      });

      it('creates an empower patient with medicalRecordNumber', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.medicalRecordNumber.value).to.equal('1234567890');
          done();
        }).catch(done);
      });

      it('creates an empower patient with ssn', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.ssn.value).to.equal('000000000');
          done();
        }).catch(done);
      });

      it('uses the new patient id to create the relationship', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(4).args[1].qp.patientId.value).to.equal(89);
          done();
        }).catch(done);
      });

    });

    describe('with a valid empower patient', function() {

      beforeEach(function() {
        submitQuery.onCall(0).returns(Promise.resolve([{
          patientId: 5
        }]));
        submitQuery.onCall(1).returns(Promise.resolve([{
          relationshipExists: 0
        }]));
        submitQuery.onCall(2).returns(Promise.resolve([{
          textValue: '{"AccessLevelId":20,"ModuleInstanceId":"43","PortalId":null,"RelationShip":"Self","RoleId":"6"}'
        }]));
      });

      it('submits a query to create an association', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(3).args[1].q.indexOf('INSERT INTO nModProfileAuthUserRelationship') === 0).to.equal(true);
          done();
        }).catch(done);
      });

      it('associates the user id', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(3).args[1].qp.userId.value).to.equal(88);
          done();
        }).catch(done);
      });

      it('associates the patient id', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(3).args[1].qp.patientId.value).to.equal(5);
          done();
        }).catch(done);
      });

      it('assigns a valid Access Level', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(submitQuery.getCall(3).args[1].qp.accessLevelId.value).to.equal(20);
          done();
        }).catch(done);
      });

      it('sends the enrollment status update', function(done) {
        createUserPatientRelationship(patient, user, portalInfo).then(function() {
          expect(sendEnrollmentStatusUpdate.calledWith(patient.medseekId, 'Enrolled', portalInfo)).to.equal(true);
          done();
        }).catch(done);
      });

      describe('when no default Access Level specified', function() {
        beforeEach(function() {
          submitQuery.onCall(2).returns(Promise.resolve([{
            textValue: '{"AccessLevelId":null,"ModuleInstanceId":"43","PortalId":null,"RelationShip":"Self","RoleId":"6"}'
          }]));
        });

        it('rejects', function(done) {
          expect(createUserPatientRelationship(patient, user, portalInfo)).to.be.rejected.notify(done);
        });
      });

      describe('when DefaultHl7Properties are not set', function() {
        beforeEach(function() {
          submitQuery.onCall(2).returns(Promise.resolve([]));
        });

        it('rejects', function(done) {
          expect(createUserPatientRelationship(patient, user, portalInfo)).to.be.rejected.notify(done);
        });
      });

    });
  });

});