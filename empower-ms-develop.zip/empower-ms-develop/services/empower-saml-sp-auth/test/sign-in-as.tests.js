'use strict';

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var Promise = require('bluebird');
var mockLogging = require('./mock-logging');
var proxyquire = require('proxyquire');

describe('sign-in-as', function() {

  var appScope,
    microservices,
    signInAs,
    portalInfo,
    user;

  beforeEach(function() {

    microservices = {
      call: sinon.stub().returns(Promise.resolve({
        Retval: ''
      }))
    };

    appScope = {
      logging: mockLogging,
      microservices: microservices
    };

    signInAs = proxyquire('../sign-in-as.js', {
      './app-scope': appScope
    });

    portalInfo = {
      id: '3',
      group: 'testPortalGroup42'
    };
    user = {
      userId: 1
    };

    microservices.call.reset();

  });

  it('is a function', function() {
    expect(signInAs).to.be.a('function');
  });

  describe('when called', function() {

    it('calls the microservice', function(done) {
      signInAs(user, portalInfo).then(function() {
        expect(microservices.call.called).to.equal(true);
        done();
      }).catch(done);
    });

    it('sends the userId in the body', function(done) {
      signInAs(user, portalInfo).then(function() {
        expect(microservices.call.getCall(0).args[1]).to.eql({
          portalUserId: 1
        });
        done();
      }).catch(done);
    });

    it('sends to the right portalGroup', function(done) {
      signInAs(user, portalInfo).then(function() {
        expect(microservices.call.getCall(0).args[0]).to.equal('Empower.Api.Proxy.testPortalGroup42');
        done();
      }).catch(done);
    });

    it('sends portalId in properties', function(done) {
      signInAs(user, portalInfo).then(function() {
        expect(microservices.call.getCall(0).args[2].portalId).to.equal('3');
        done();
      }).catch(done);
    });

    describe('and a sessionId is not returned', function() {

      it('returns and empty object', function(done) {
        signInAs(user, portalInfo).then(function(result) {
          expect(result).to.eql({});
          done();
        }).catch(done);
      });
    });

    describe('and a sessionId is returned', function() {

      var newSessionId = '1q2w3e4r5t6y';
      beforeEach(function() {
        microservices.call.returns(Promise.resolve({
          Retval: newSessionId
        }));
      });

      it('returns an object with the sessionId', function(done) {
        signInAs(user, portalInfo).then(function(result) {
          expect(result).to.eql({
            sessionId: newSessionId
          });
          done();
        }).catch(done);
      });
    });
  });
});