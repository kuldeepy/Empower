'use strict';

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var Promise = require('bluebird');
var mockLogging = require('./mock-logging');
var proxyquire = require('proxyquire');

describe('find-user-matching-claims', function() {

  var appScope,
    submitQuery,
    findUserMatchingClaims,
    claims,
    portalInfo;

  beforeEach(function() {
    appScope = {
      logging: mockLogging
    };
    submitQuery = sinon.stub().returns(Promise.resolve([]));
    findUserMatchingClaims = proxyquire('../find-user-matching-claims.js', {
      './app-scope': appScope,
      './submit-query': submitQuery
    });
    portalInfo = {
      groupId: '42'
    };
    claims = {};
    submitQuery.reset();
  });

  it('is a function', function() {
    expect(findUserMatchingClaims).to.be.a('function');
  });

  describe('when called with empty claims', function() {
    it('does not run a query', function(done) {
      findUserMatchingClaims(claims, portalInfo).then(function() {
        expect(submitQuery.called).to.equal(false);
        done();
      }).catch(done);
    });
  });

  describe('when called with claims and a portalInfo)', function() {

    beforeEach(function() {
      claims = {
        UserProfileData: {
          Username: 'john.doe'
        }
      };
    });

    it('runs a query', function(done) {
      findUserMatchingClaims(claims, portalInfo).then(function() {
        expect(submitQuery.called).to.equal(true);
        done();
      }).catch(done);
    });

    it('sends the portalInfo', function(done) {
      findUserMatchingClaims(claims, portalInfo).then(function() {
        expect(submitQuery.getCall(0).args[0]).to.eql(portalInfo);
        done();
      }).catch(done);
    });

    describe('and claims has username', function() {

      it('includes the username in the query', function(done) {
        findUserMatchingClaims(claims, portalInfo).then(function() {
          expect(submitQuery.getCall(0).args[1]).to.eql({
            q: 'SELECT TOP 2 ref as userId from enAuthUsers WHERE deleted = 0 AND IsDisabled = 0 AND username = @username',
            qp: {
              username: {
                value: 'john.doe',
                type: 'NVarChar',
                length: 8
              }
            }
          });
          done();
        }).catch(done);
      });

    });

    describe('and claims has FirstName', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            FirstName: 'John'
          }
        };
      });

      it('includes the FirstName in the query', function(done) {
        findUserMatchingClaims(claims, portalInfo).then(function() {
          expect(submitQuery.getCall(0).args[1]).to.eql({
            q: 'SELECT TOP 2 ref as userId from enAuthUsers WHERE deleted = 0 AND IsDisabled = 0 AND firstName = @firstName',
            qp: {
              firstName: {
                value: 'John',
                type: 'NVarChar',
                length: 4
              }
            }
          });
          done();
        }).catch(done);
      });
    });

    describe('and claims has lastName', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            LastName: 'Doe'
          }
        };
      });

      it('includes the lastName in the query', function(done) {
        findUserMatchingClaims(claims, portalInfo).then(function() {
          expect(submitQuery.getCall(0).args[1]).to.eql({
            q: 'SELECT TOP 2 ref as userId from enAuthUsers WHERE deleted = 0 AND IsDisabled = 0 AND lastName = @lastName',
            qp: {
              lastName: {
                value: 'Doe',
                type: 'NVarChar',
                length: 3
              }
            }
          });
          done();
        }).catch(done);
      });

    });

    describe('and claims has email', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Email: 'test@test.com'
          }
        };
      });

      it('includes the lastName in the query', function(done) {
        findUserMatchingClaims(claims, portalInfo).then(function() {
          expect(submitQuery.getCall(0).args[1]).to.eql({
            q: 'SELECT TOP 2 ref as userId from enAuthUsers WHERE deleted = 0 AND IsDisabled = 0 AND email = @email',
            qp: {
              email: {
                value: 'test@test.com',
                type: 'NVarChar',
                length: 13
              }
            }
          });
          done();
        }).catch(done);
      });

    });

    describe('and claims has username, firstName and lastName', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Username: 'john.doe',
            FirstName: 'John',
            LastName: 'Doe'
          }
        };
      });

      it('includes the each in the query', function(done) {
        findUserMatchingClaims(claims, portalInfo).then(function() {
          expect(submitQuery.getCall(0).args[1]).to.eql({
            q: 'SELECT TOP 2 ref as userId from enAuthUsers WHERE deleted = 0 AND IsDisabled = 0 AND username = @username AND firstName = @firstName AND lastName = @lastName',
            qp: {
              username: {
                value: 'john.doe',
                type: 'NVarChar',
                length: 8
              },
              firstName: {
                value: 'John',
                type: 'NVarChar',
                length: 4
              },
              lastName: {
                value: 'Doe',
                type: 'NVarChar',
                length: 3
              }
            }
          });
          done();
        }).catch(done);
      });

    });

    describe('and claims has email, firstName and lastName', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Email: 'test@test.com',
            FirstName: 'John',
            LastName: 'Doe'
          }
        };
      });

      it('includes the each in the query', function(done) {
        findUserMatchingClaims(claims, portalInfo).then(function() {
          expect(submitQuery.getCall(0).args[1]).to.eql({
            q: 'SELECT TOP 2 ref as userId from enAuthUsers WHERE deleted = 0 AND IsDisabled = 0 AND firstName = @firstName AND lastName = @lastName AND email = @email',
            qp: {
              email: {
                value: 'test@test.com',
                type: 'NVarChar',
                length: 13
              },
              firstName: {
                value: 'John',
                type: 'NVarChar',
                length: 4
              },
              lastName: {
                value: 'Doe',
                type: 'NVarChar',
                length: 3
              }
            }
          });
          done();
        }).catch(done);
      });

    });

    describe('and query returns users', function() {
      var users = [{
        userId: 1
      }, {
        userId: 2
      }];
      beforeEach(function() {
        submitQuery.returns(Promise.resolve(users));
      });

      it('returns the users', function() {
        findUserMatchingClaims(claims, portalInfo).then(function(results) {
          expect(results).to.eql(users);
        });
      });
    });

  });

});