'use strict';
var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var mockLogging = require('./mock-logging');

describe('empower-saml-sp-auth', function() {

  var service,
    mockMs,
    mockMicroservices,
    options,
    findUserMatchingClaims,
    userInPortal,
    signInAs,
    ssoConfig,
    getSsoConfig,
    createUserFromClaims,
    request,
    messageContext,
    expectedPortalInfo;

  beforeEach(function() {

    mockMs = sinon.stub();

    mockMicroservices = sinon.stub({
      bind: function() {},
      call: function() {}
    });

    ssoConfig = {};

    findUserMatchingClaims = sinon.stub();
    signInAs = sinon.stub();
    createUserFromClaims = sinon.stub();
    userInPortal = sinon.stub();
    getSsoConfig = sinon.stub().returns(Promise.resolve(ssoConfig));

    options = {};
    mockMs.yields(mockLogging, mockMicroservices);
    service = proxyquire.noCallThru()('../empower-saml-sp-auth.js', {
      'ih-microservice': mockMs,
      './find-user-matching-claims': findUserMatchingClaims,
      './user-in-portal': userInPortal,
      './sign-in-as': signInAs,
      './create-user-from-claims': createUserFromClaims,
      './get-sso-config': getSsoConfig
    });

    request = {
      claims: {
        userProfileData: {
          email: 'test@test.com',
          firstName: 'John',
          lastName: 'Doe'
        }
      },
      portalId: '1',
      portalGroup: 'testPortalGroup42',
      ssoConfigId: '10'
    };

    messageContext = {
      routingKey: 'empower.saml.sp.session.start.42'
    };

    expectedPortalInfo = {
      id: '1',
      groupId: '42',
      group: 'testPortalGroup42'
    };

    findUserMatchingClaims.reset();
    signInAs.reset();
    createUserFromClaims.reset();
    userInPortal.reset();

  });

  it('is an object', function() {
    expect(service).to.be.an('object');
  });

  describe('loginWithClaims', function() {

    it('is a function', function() {
      expect(service.loginWithClaims).to.be.a('function');
    });

    describe('when called', function() {

      it('tries to find a user matching the claims', function(done) {
        service.loginWithClaims(request, messageContext).then(function() {
          expect(findUserMatchingClaims.calledWith(request.claims, expectedPortalInfo)).to.equal(true);
          done();
        }).catch(done);
      });

    });

    describe('when claims match 1 user', function() {
      var user = {
        userId: 1
      };

      beforeEach(function() {
        findUserMatchingClaims.returns(Promise.resolve([user]));
      });

      describe('and user is not in portal', function() {

        beforeEach(function() {
          userInPortal.returns(Promise.resolve(false));
        });

        it('it does not authenticate', function(done) {
          service.loginWithClaims(request, messageContext).then(function(response) {
            expect(response.sessionId).to.be.undefined; /*jshint ignore: line*/
            done();
          }).catch(done);
        });

      });

      describe('and user is in portal', function() {

        beforeEach(function() {
          userInPortal.returns(Promise.resolve(true));
          signInAs.returns(Promise.resolve({
            sessionId: 'a-new-session-id'
          }));
        });

        it('signs in as the user', function(done) {
          service.loginWithClaims(request, messageContext).then(function(response) {
            expect(signInAs.getCall(0).args[0]).to.eql(user);
            done();
          }).catch(done);
        });

        it('uses the portalGroup from the request', function(done) {
          service.loginWithClaims(request, messageContext).then(function(response) {
            expect(signInAs.getCall(0).args[1]).to.eql(expectedPortalInfo);
            done();
          }).catch(done);
        });

        it('returns a new session id', function(done) {
          service.loginWithClaims(request, messageContext).then(function(response) {
            expect(response.sessionId).to.eql('a-new-session-id');
            done();
          }).catch(done);
        });
      });

    });

    describe('when claims do not match any user', function() {

      beforeEach(function() {
        findUserMatchingClaims.returns(Promise.resolve([]));
      });

      it('gets the ssoConfig', function(done) {
        service.loginWithClaims(request, messageContext).then(function(response) {
          expect(getSsoConfig.calledWith(request.ssoConfigId, expectedPortalInfo)).to.equal(true);
          done();
        }).catch(done);
      });

      it('tries to create a user', function(done) {
        service.loginWithClaims(request, messageContext).then(function(response) {
          expect(createUserFromClaims.calledWith(request.claims, expectedPortalInfo, ssoConfig)).to.equal(true);
          done();
        }).catch(done);
      });

      describe('and user cannot be created', function() {

        beforeEach(function() {
          createUserFromClaims.returns(Promise.resolve(null));
        });

        it('it does not authenticate', function(done) {
          service.loginWithClaims(request, messageContext).then(function(response) {
            expect(response.sessionId).to.be.undefined; /*jshint ignore: line*/
            done();
          }).catch(done);
        });
      });

      describe('and user is created', function() {

        var user = {
          userId: 3
        };

        beforeEach(function() {
          createUserFromClaims.returns(Promise.resolve(user));
          signInAs.returns(Promise.resolve({
            sessionId: 'a-new-session-id'
          }));
        });

        it('signs in as the user', function(done) {
          service.loginWithClaims(request, messageContext).then(function(response) {
            expect(signInAs.getCall(0).args[0]).to.eql(user);
            done();
          }).catch(done);
        });

        it('uses the portalGroup from the request', function(done) {
          service.loginWithClaims(request, messageContext).then(function(response) {
            expect(signInAs.getCall(0).args[1]).to.eql(expectedPortalInfo);
            done();
          }).catch(done);
        });

        it('returns a new session id', function(done) {
          service.loginWithClaims(request, messageContext).then(function(response) {
            expect(response.sessionId).to.eql('a-new-session-id');
            done();
          }).catch(done);
        });
      });

    });

    describe('when claims match more than one user', function() {

      beforeEach(function() {
        findUserMatchingClaims.returns(Promise.resolve([{
          userId: 1
        }, {
          userId: 2
        }]));
      });

      it('it does not authenticate', function(done) {
        service.loginWithClaims(request, messageContext).then(function(response) {
          expect(response.sessionId).to.be.undefined; /*jshint ignore: line*/
          done();
        }).catch(done);
      });

    });

  });
});