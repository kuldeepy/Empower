'use strict';

var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var Promise = require('bluebird');
var util = require('util');
var mockLogging = require('./mock-logging');
var proxyquire = require('proxyquire');

describe('send-enrollment-status-update', function() {

  var appScope,
    microservices,
    sendEnrollmentStatusUpdate,
    portalInfo,
    medseekId,
    status;

  beforeEach(function() {

    microservices = {
      call: sinon.stub().returns(Promise.resolve({
        Retval: ''
      }))
    };
    var appScope = {
      logging: mockLogging,
      microservices: microservices
    };

    sendEnrollmentStatusUpdate = proxyquire('../send-enrollment-status-update', {
      './app-scope': appScope
    });

    portalInfo = {
      group: 'testPortalGroup42'
    };
    medseekId = 'E2F7EA2C-5BB4-4FC8-96D5-4F352D46524C';
    status = 'Enrolled';

    microservices.call.reset();

  });

  it('is a function', function() {
    expect(sendEnrollmentStatusUpdate).to.be.a('function');
  });

  describe('when called', function() {

    it('calls the microservice', function(done) {
      sendEnrollmentStatusUpdate(medseekId, status, portalInfo).then(function() {
        expect(microservices.call.called).to.equal(true);
        done();
      }).catch(done);
    });

    it('sends to the correct address', function(done) {
      sendEnrollmentStatusUpdate(medseekId, status, portalInfo).then(function() {
        expect(microservices.call.getCall(0).args[0]).to.equal('Empower.Api.Proxy.testPortalGroup42');
        done();
      }).catch(done);
    });

    it('sends the medseekId in the body', function(done) {
      sendEnrollmentStatusUpdate(medseekId, status, portalInfo).then(function() {
        expect(microservices.call.getCall(0).args[1].medseekId).to.equal(medseekId);
        done();
      }).catch(done);
    });

    it('sends the status in the body', function(done) {
      sendEnrollmentStatusUpdate(medseekId, status, portalInfo).then(function() {
        expect(microservices.call.getCall(0).args[1].status).to.equal(status);
        done();
      }).catch(done);
    });

  });

});