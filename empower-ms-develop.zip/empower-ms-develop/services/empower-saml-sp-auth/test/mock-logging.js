'use strict';
var sinon = require('sinon');
var mockLog = sinon.stub({
  debug: function() {},
  error: function(e) {
    console.error(e);
  },
  trace: function() {},
  warn: function() {}
});
module.exports = {
  getLogger: function() {
    return mockLog;
  }
};