'use strict';

var chai = require('chai');
var chaiAsPromised = require('chai-as-promised');
chai.use(chaiAsPromised);
var expect = chai.expect;
var sinon = require('sinon');
var Promise = require('bluebird');
var mockLogging = require('./mock-logging');
var proxyquire = require('proxyquire');

describe('create-user-from-claims', function() {

  var appScope,
    createUserFromClaims,
    findPatientMatchingClaims,
    createUserPatientRelationship,
    submitQuery,
    portalInfo,
    ssoConfig,
    claims,
    user,
    patient;

  beforeEach(function() {
    appScope = {
      logging: mockLogging
    };
    portalInfo = {
      id: '1',
      groupId: '42'
    };
    ssoConfig = {};
    submitQuery = sinon.stub().returns(Promise.resolve([]));
    findPatientMatchingClaims = sinon.stub().returns(Promise.resolve([]));
    createUserPatientRelationship = sinon.stub().returns(Promise.resolve());
    createUserFromClaims = proxyquire('../create-user-from-claims', {
      './app-scope': appScope,
      './submit-query': submitQuery,
      './find-patient-matching-claims': findPatientMatchingClaims,
      './create-user-patient-relationship': createUserPatientRelationship
    });
    submitQuery.reset();
    findPatientMatchingClaims.reset();
    createUserPatientRelationship.reset();
  });

  it('is a function', function() {
    expect(createUserFromClaims).to.be.a('function');
  });

  describe('when called with missing UserProfileData claims', function() {

    beforeEach(function() {
      claims = {};
    });

    it('rejects', function(done) {
      expect(createUserFromClaims(claims, portalInfo, ssoConfig)).to.be.rejected.notify(done);
    });

  });

  describe('when called with missing Username and Email claims', function() {

    beforeEach(function() {
      claims = {
        UserProfileData: {}
      };
    });

    it('rejects', function(done) {
      expect(createUserFromClaims(claims, portalInfo, ssoConfig)).to.be.rejected.notify(done);
    });

  });

  describe('when portalType is not Patient', function() {

    beforeEach(function() {
      claims = {
        UserProfileData: {
          Username: 'user1',
          FirstName: 'Adam',
          LastName: 'Ant'
        }
      };
      user = {
        userId: 99
      };
      submitQuery.onCall(0).returns(Promise.resolve([{
        portalType: 3,
        primaryRoleId: 10
      }]));
      submitQuery.onCall(1).returns(Promise.resolve([user]));
    });

    it('returns the new user', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function(result) {
        expect(result).to.eql(user);
        done();
      }).catch(done);
    });

    it('creates a new user', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(1).args[1].q.indexOf('INSERT INTO enAuthUsers')).to.equal(0);
        done();
      }).catch(done);
    });

    it('creates a user with the Username', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(1).args[1].qp.username).to.eql({
          type: 'NVarChar',
          length: 5,
          value: 'user1'
        });
        done();
      }).catch(done);
    });

    it('creates a user with the FirstName', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(1).args[1].qp.firstName).to.eql({
          type: 'NVarChar',
          length: 4,
          value: 'Adam'
        });
        done();
      }).catch(done);
    });

    it('creates a user with the LastName', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(1).args[1].qp.lastName).to.eql({
          type: 'NVarChar',
          length: 3,
          value: 'Ant'
        });
        done();
      }).catch(done);
    });

    it('creates a user with the LastAuthGroupId', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(1).args[1].qp.lastAuthGroupId).to.eql({
          type: 'Int',
          value: 10
        });
        done();
      }).catch(done);
    });

    it('creates a user with a Description', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(1).args[1].qp.description).to.eql({
          type: 'NVarChar',
          length: 24,
          value: 'Created from SAML claims'
        });
        done();
      }).catch(done);
    });

    it('adds the user to a role', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(2).args[1].q.indexOf('INSERT INTO enAuthGroupMembers')).to.equal(0);
        done();
      }).catch(done);
    });

    it('uses the userId when adding to a role', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(2).args[1].qp.userId).to.eql({
          type: 'Int',
          value: 99
        });
        done();
      }).catch(done);
    });

    it('uses the default role of the portal when adding to a role', function(done) {
      createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
        expect(submitQuery.getCall(2).args[1].qp.roleId).to.eql({
          type: 'Int',
          value: 10
        });
        done();
      }).catch(done);
    });

    describe('and the Email claim is not present', function() {

      it('creates a user with a random email', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.email.value).to.be.defined; /* jshint ignore: line */
          done();
        }).catch(done);
      });

    });

    describe('and the Email claim is present', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Username: 'user1',
            Email: 'user1@test.com',
            FirstName: 'Adam',
            LastName: 'Ant'
          }
        };
      });

      it('creates a user with the email', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.email).to.eql({
            type: 'NVarChar',
            length: 14,
            value: 'user1@test.com'
          });
          done();
        }).catch(done);
      });

    });

    describe('and the Username claim is not present', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Email: 'user1@test.com',
            FirstName: 'Adam',
            LastName: 'Ant'
          }
        };
      });

      it('creates a user with the Email as the username', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.username).to.eql({
            type: 'NVarChar',
            length: 14,
            value: 'user1@test.com'
          });
          done();
        }).catch(done);
      });

    });

    describe('and the FirstName claim is not present', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Email: 'user1@test.com',
            LastName: 'Ant'
          }
        };
      });

      it('creates a user with a firstName of "unspecified"', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.firstName).to.eql({
            type: 'NVarChar',
            length: 11,
            value: 'unspecified'
          });
          done();
        }).catch(done);
      });

    });

    describe('and the LastName claim is not present', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Email: 'user1@test.com',
            FirstName: 'Adam'
          }
        };
      });

      it('creates a user with a lastName of "unspecified"', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
          expect(submitQuery.getCall(1).args[1].qp.lastName).to.eql({
            type: 'NVarChar',
            length: 11,
            value: 'unspecified'
          });
          done();
        }).catch(done);
      });

    });

    describe('if an error occurs setting the auth group', function() {

      beforeEach(function() {
        submitQuery.onCall(2).returns(Promise.reject());
      });

      it('submits a roll-back query', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig)
          .catch(function() {})
          .then(function() {
            expect(submitQuery.getCall(3).args[1].q.indexOf('DELETE FROM enAuthUsers')).to.equal(0);
            done();
          }).catch(done);
      });

      it('deletes the user', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig)
          .catch(function() {})
          .then(function() {
            expect(submitQuery.getCall(3).args[1].qp.userId.value).to.equal(99);
            done();
          }).catch(done);
      });

      it('rejects', function(done) {
        expect(createUserFromClaims(claims, portalInfo, ssoConfig)).to.be.rejected.notify(done);
      });

    });

  });

  describe('when portalType is Patient', function() {

    beforeEach(function() {
      submitQuery.onCall(0).returns(Promise.resolve([{
        portalType: 2,
        primaryRoleId: 11
      }]));
    });

    describe('when searching for patients', function() {

      beforeEach(function() {
        claims = {
          UserProfileData: {
            Username: 'user2',
          }
        };
        user = {
          userId: 88
        };
        patient = {
          medseekId: 'E2F7EA2C-5BB4-4FC8-96D5-4F352D46524C',
          firstName: 'Bart',
          middleName: 'B',
          lastName: 'Bear',
          gender: 2,
          dateOfBirth: '1958-10-05T00:00:00.000Z',
          emailAddress: 'bart@bear.com'
        };
        findPatientMatchingClaims.returns(Promise.resolve([patient]));
        submitQuery.onCall(1).returns(Promise.resolve([user]));
      });

      it('searches by the claims', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
          expect(findPatientMatchingClaims.getCall(0).args[0]).to.eql(claims);
          done();
        }).catch(done);
      });

      it('searches the right portal group', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
          expect(findPatientMatchingClaims.getCall(0).args[1]).to.eql(portalInfo);
          done();
        }).catch(done);
      });

      it('passes in the ssoConfig the right portal group', function(done) {
        createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
          expect(findPatientMatchingClaims.getCall(0).args[2]).to.eql(ssoConfig);
          done();
        }).catch(done);
      });

      describe('and Patient claims match 1 patient', function() {

        it('creates a new user', function(done) {
          createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
            expect(submitQuery.getCall(1).args[1].q.indexOf('INSERT INTO enAuthUsers')).to.equal(0);
            done();
          }).catch(done);
        });

        it('adds the user to a role', function(done) {
          createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
            expect(submitQuery.getCall(2).args[1].q.indexOf('INSERT INTO enAuthGroupMembers')).to.equal(0);
            done();
          }).catch(done);
        });

        it('uses the userId when adding to a role', function(done) {
          createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
            expect(submitQuery.getCall(2).args[1].qp.userId).to.eql({
              type: 'Int',
              value: 88
            });
            done();
          }).catch(done);
        });

        it('uses the default role of the portal when adding to a role', function(done) {
          createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
            expect(submitQuery.getCall(2).args[1].qp.roleId).to.eql({
              type: 'Int',
              value: 11
            });
            done();
          }).catch(done);
        });

        it('creates the user-patient relationship', function(done) {
          createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
            expect(createUserPatientRelationship.calledWith(patient, user, portalInfo)).to.equal(true);
            done();
          }).catch(done);
        });

        it('returns the new user', function(done) {
          createUserFromClaims(claims, portalInfo, ssoConfig).then(function(result) {
            expect(result).to.eql(user);
            done();
          }).catch(done);
        });

        describe('when user claims do not have firstName, lastName or email', function() {

          it('uses the patient first name for the user account', function(done) {
            createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
              expect(submitQuery.getCall(1).args[1].qp.firstName.value).to.equal('Bart');
              done();
            }).catch(done);
          });

          it('uses the patient last name for the user account', function(done) {
            createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
              expect(submitQuery.getCall(1).args[1].qp.lastName.value).to.equal('Bear');
              done();
            }).catch(done);
          });

          it('uses the patient email for the user account', function(done) {
            createUserFromClaims(claims, portalInfo, ssoConfig).then(function() {
              expect(submitQuery.getCall(1).args[1].qp.email.value).to.equal('bart@bear.com');
              done();
            }).catch(done);
          });

        });

        describe('if an error occurs creating the user-patient relationship', function() {

          beforeEach(function() {
            createUserPatientRelationship.returns(Promise.reject());
          });

          it('submits a roll-back query', function(done) {
            createUserFromClaims(claims, portalInfo, ssoConfig)
              .catch(function() {})
              .then(function() {
                expect(submitQuery.getCall(2).args[1].q.indexOf('DELETE FROM enAuthUsers')).to.equal(0);
                done();
              }).catch(done);
          });

          it('deletes the user', function(done) {
            createUserFromClaims(claims, portalInfo, ssoConfig)
              .catch(function() {})
              .then(function() {
                expect(submitQuery.getCall(2).args[1].qp.userId.value).to.equal(88);
                done();
              }).catch(done);
          });

          it('rejects', function(done) {
            expect(createUserFromClaims(claims, portalInfo, ssoConfig)).to.be.rejected.notify(done);
          });

        });

      });

      describe('and Patient claims do not match any Patients', function() {

        beforeEach(function() {
          createUserPatientRelationship.reset();
          findPatientMatchingClaims.reset();
          findPatientMatchingClaims.returns(Promise.resolve([]));
        });

        it('rejects', function(done) {
          expect(createUserFromClaims(claims, portalInfo, ssoConfig)).to.be.rejected.notify(done);
        });

      });

      describe('and Patient claims match multiple Patients', function() {

        beforeEach(function() {
          createUserPatientRelationship.reset();
          findPatientMatchingClaims.reset();
          findPatientMatchingClaims.returns(Promise.resolve([{
            medseekId: 'E2F7EA2C-5BB4-4FC8-96D5-4F352D46524C'
          }, {
            medseekId: '551A84EB-CD02-4428-81CB-77CB39042E09'
          }]));
        });

        it('rejects', function(done) {
          expect(createUserFromClaims(claims, portalInfo, ssoConfig)).to.be.rejected.notify(done);
        });

      });
    });
  });
});