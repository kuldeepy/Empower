'use strict';
var Promise = require('bluebird');
var submitQuery = require('./submit-query');
var appScope = require('./app-scope');
var log;

module.exports = function(configId, portalInfo) {
  log = log || appScope.logging.getLogger('empower-saml-sp-auth.get-sso-config');

  return Promise.try(
    function() {
      log.trace('getting sso config', configId);
      
      var query = {
        q: 'SELECT Source as sourceGroup FROM enAuthSsoConfig WHERE Id = @configId;',
        qp: {
          configId: {
            type: 'Int',
            value: configId
          }
        }
      };

      return submitQuery(portalInfo, query).then(function(res) {
        log.debug('got ssoConfig', res[0]);
        return res[0];
      });
    }
  );

};