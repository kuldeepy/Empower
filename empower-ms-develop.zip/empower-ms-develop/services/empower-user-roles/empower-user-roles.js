'use strict';
var micro = require('ih-microservice');

var defaults = {
  id: 'empower-user-roles',
  debug: false,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-user-roles',
  defaultReturnBody: true,
  defaultTimeout: 10000,
  channelPrefetch: 0,
  bulkBatchSize: 50
};

micro(defaults, function(app, logging, options, microservices, Promise, _) {

  var log = logging.getLogger(options.id);

  var GET_QUERY = 'SELECT g.name as roleName, g.ref as roleId, p.id as portalId, p.name as portalName  FROM enAuthGroups (NOLOCK) g INNER JOIN enAuthGroupMembers (NOLOCK) m on m.enAuthGroupRef = g.ref AND m.IsUser = 1 INNER JOIN enAuthUsers (NOLOCK) u on u.ref = m.enAuthRef INNER JOIN CmsPortals (NOLOCK) p on p.Id = portalId where u.ref = @userId';
  var DELETE_QUERY = 'DELETE FROM enAuthGroupMembers WHERE enAuthGroupRef = @groupId AND enAuthRef = @userId AND IsUser = 1;';
  var INSERT_QUERY = 'IF NOT EXISTS(SELECT 1 FROM enAuthGroupMembers WHERE enAuthGroupRef = @groupId AND enAuthRef = @userId AND IsUser = 1)' +
    ' BEGIN' +
    '  INSERT INTO enAuthGroupMembers (enAuthGroupRef, enAuthRef, IsUser) VALUES(@groupId, @userId, 1);' +
    '  UPDATE enAuthUsers SET LastAuthGroupId = @groupId WHERE ref = @userId;' +
    ' END;';

  var promiseFor = Promise.method(function(condition, action, value) {
    if (!condition(value)) {
      return value;
    }
    return action(value).then(promiseFor.bind(null, condition, action));
  });

  return Promise.all([
    microservices.bind('empower.user-roles.bulk-action.#', _.wrap(bulkAction, returnError)),
    microservices.bind('empower.user-roles.bulk-action-async.#', _.wrap(bulkActionAsync, logError)),
    microservices.bind('empower.user-roles.get.#', _.wrap(get, logError))
  ]);

  function get(message,mc){
    log.debug('get| received message',message);
    var cmd = {
      q: GET_QUERY,
      qp: {
        userId: {
          type: 'Int',
          value: message.userId
        }
      }
    };
    return submitQuery(cmd,mc);
  }
  function bulkAction(actions, mc) {
    log.info('processing %s bulk actions', actions.length);
    var actionGroups = chunked(actions, defaults.bulkBatchSize);
    var commands = actionGroups.map(function(group) {

      var cmd = {
        q: '',
        qp: {},
        multiple: true
      };

      for (var i = 0; i < group.length; i++) {
        var action = group[i];

        var groupParam = 'groupId_' + i.toString();

        cmd.qp[groupParam] = {
          value: parseInt(action.roleId, 10),
          type: 'Int'
        };

        var userParam = 'userId_' + i.toString();

        cmd.qp[userParam] = {
          value: parseInt(action.userId, 10),
          type: 'Int'
        };

        var query = '';

        if (action.command === 'add') {
          query = INSERT_QUERY;
        } else if (action.command === 'remove') {
          query = DELETE_QUERY;
        } else {
          throw new Error('unknown action command' + action.command);
        }
        cmd.q += query.split('@userId').join('@' + userParam).split('@groupId').join('@' + groupParam) + ' ';

      }
      return cmd;
    });

    log.debug('executing %s commands', commands.length);

    return promiseFor(function(cmdIndex) {
      return cmdIndex <= commands.length - 1;
    }, function(cmdIndex) {
      return submitQuery(commands[cmdIndex], mc).then(function() {
        cmdIndex += 1;
        return cmdIndex;
      });
    }, 0).then(function() {
      log.info('completed %s bulk actions', actions.length);
      return {
        status: 'ok'
      };
    });
  }

  function bulkActionAsync(message, mc) {
    var actions = message.actions;
    log.debug('processing %s bulk user-roles actions', actions.length);
    if (actions.length === 0) {
      return Promise.resolve();
    }
    return bulkAction(message.actions, mc).then(function(res) {
      log.info('performed bulk role assignment', res);
      return notifyBulkActionComplete(message.notifyAddress, res).then(function() {
        log.info('job complete');
      });
    });
  }

  function notifyBulkActionComplete(notifyAddress, status) {
    return microservices.send(notifyAddress, status);
  }

  function returnError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }

  function logError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
    });
  }

  function chunked(arr, len) {
    var chunks = [],
      i = 0,
      n = arr.length;
    while (i < n) {
      chunks.push(arr.slice(i, i += len));
    }
    return chunks;
  }

  function submitQuery(queryObj, messageContext) {
    var portalGroupId = getPortalGroupId(messageContext);
    return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, queryObj, {}, {
      timeout: 60000
    }).then(function(results) {
      checkError(results);
      return results;
    });
  }

  function getPortalGroupId(messageContext) {
    return _.last(messageContext.routingKey.split('.'));
  }

  function checkError(results) {
    if (typeof(results.error) !== 'undefined') {
      throw new Error('Error running query: ' + results.error);
    }
  }

});