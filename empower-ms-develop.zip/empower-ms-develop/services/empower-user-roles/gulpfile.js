'use strict';

var gulp = require('gulp');
var gulpUtil = require('gulp-util');

gulp.task('start', function() {
  require('./lib');
});

gulp.task('start-watch', function() {
  var gulpNodemon = require('gulp-nodemon');
  gulpNodemon(getOptions({
    script: 'index',
    ext: 'html js',
    ignore: []
  }));
});

gulp.task('test', function() {

  gulp.start('jshint');

  var gulpMocha = require('gulp-mocha');
  var options = getOptions({
    reporter: 'spec',
    timeout: undefined
  });
  return gulp.src(['test/.testStart/*.js', 'test/**/*.test.js'], {
      read: false
    })
    .pipe(gulpMocha(options))
    .on('error', gulpUtil.log);
});

gulp.task('test-watch', function() {
  gulp.watch(['**/*'], ['test']);
});

gulp.task('jshint', function() {
  var jshint = require('gulp-jshint');
  return gulp.src(['./lib/**/*.js', 'test/**/*.test.js', 'services/**/*.js'])
    .pipe(jshint())
    .pipe(jshint.reporter('default'));
});

var files = require('fs').readdirSync('./').filter(function (item) { return /^((?!gulp).)*.js$/.test(item); });

gulp.task('test-coverage', function () {
  var mocha = require('gulp-mocha'),
      cover = require('gulp-coverage');;
  return gulp.src(['./test/*.test*.js'],{read: false})
    .pipe(cover.instrument({
        pattern: files
    }))
    .pipe(mocha())
    .pipe(cover.gather())
    .pipe(cover.format())
    .pipe(gulp.dest('reports'));
});

function getOptions(defaults) {
  var args = process.argv[0] == 'node' ? process.argv.slice(3) : process.argv.slice(2);
  var minimist = require('minimist');
  return minimist(args, {
    default: defaults
  });
}