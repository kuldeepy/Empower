'use strict';

var crutch = require('ih-microservice');

var defaults = {
    id: 'empower-css-content',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'empower-css-content',
    defaultReturnBody: true,
    communicateDb: 'MedseekIntegration60',
    pageSize: '20'
};

module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise) {


    var log = logging.getLogger(options.id);
    var Promise = bluebird;
    var knownPgs = {};

    return Promise.all([
        microservices.bind('css.content.getAllCSS', _.wrap(getAllCSS, errorWrap)),
        microservices.bind('css.content.createCSS', _.wrap(createCSS, errorWrap)),
        microservices.bind('css.content.updateCSS', _.wrap(updateCSS, errorWrap))
    ]);

    function getAllCSS(req) {
      
        return getAllCssContent(req)
            .then(function(data) {
                return data;
            });
    };

    function createCSS(req) {
        return createCssContent(req).then(function(data) {
            return data;
        });

    };

    function updateCSS(req) {
        return updateCssContent(req).then(function(data) {
            return data;
        });

    }

    function buildappCssModel(appCssResults) {
        var appCssFormattedResults = [];

        appCssResults.forEach(function(result) {

            var model = {

                _id: result.id,
                source: {
                    style: result.value,
                    ecoApp: result.ecoApp,
                    portalId: result.portalId,
                    portalGroup: result.portalGroup
                }
            };
            appCssFormattedResults.push(model);

        });

        return appCssFormattedResults;
    };

    function buildglobalCssModel(globalCssResults) {
        var globalCssFormattedResults = [];

        globalCssResults.forEach(function(result) {

            var model = {
                _id: result.id,
                source: {
                    style: result.value,
                    portalId: result.portalId,
                    portalGroup: result.portalGroup
                }
            };
            globalCssFormattedResults.push(model);
        });
        return globalCssFormattedResults;
    };

    function buildAppScriptingModel(scriptingResults) {
        var appScriptingResults = [];

        scriptingResults.forEach(function(result) {

            var model = {
                _id: result.id,
                source: {
                    script: result.value,
                    ecoApp: result.ecoApp,
                    portalId: result.portalId,
                    portalGroup: result.portalGroup
                }
            };
            appScriptingResults.push(model);
        });
        return appScriptingResults;
    };

    function buildGlobalScriptingModel(scriptingResults) {
        var globalScriptingResults = [];

        scriptingResults.forEach(function(result) {

            var model = {
                _id: result.id,
                source: {
                    script: result.value,
                    portalId: result.portalId,
                    portalGroup: result.portalGroup
                }
            };
            globalScriptingResults.push(model);
        });
        return globalScriptingResults;
    };

    function buildTargetedContentModel(contentResults) {
        var formattedContentResults = [];

        contentResults.forEach(function(result) {

            var model = {
                _id: result.id,
                source: {
                    campaign: JSON.parse(result.value),
                    portalId: result.portalId,
                    portalGroup: result.portalGroup,
                }
            };
            formattedContentResults.push(model);
        });
        return formattedContentResults;
    }

    function getglobalScriptingFromQueryResult(queryResult, sourceTypes) {
        return buildGlobalScriptingModel(_.where(queryResult, {
            sourceTypeId: sourceTypes.globalScripting
        }));
    };

    function getAppScriptingFromQueryResult(queryResult, sourceTypes) {
        return buildAppScriptingModel(_.where(queryResult, {
            sourceTypeId: sourceTypes.appScripting
        }));
    };

    function getglobalCssFromQueryResult(queryResult, sourceTypes) {
        return buildglobalCssModel(_.where(queryResult, {
            sourceTypeId: sourceTypes.globalCss
        }));
    };

    function getappCssFromQueryResult(queryResult, sourceTypes) {
        return buildappCssModel(_.where(queryResult, {
            sourceTypeId: sourceTypes.appCss
        }));
    };

    function getTargetedContentFromQueryResult(queryResult, sourceTypes) {
        return buildTargetedContentModel(_.where(queryResult, {
            sourceTypeId: sourceTypes.targetedContent
        }));
    }


    function createCssContent(req) {

        var sourceTypes = {
            appCss: 1,
            globalCss: 2,
            appScripting: 3,
            globalScripting: 4,
            targetedContent: 5
        };

        var sourceValueTypes = {
            style: 1,
            script: 2,
            campaign: 3
        };

        var sourceValue = '';
        var sourceTypeId;
        var sourceValueTypeId;
        var moduleInstanceId = null;

        var portalId = req.content.source.portalId;


        switch (req.type.trim().toUpperCase()) {

            case 'APPCSS':
                sourceValue = req.content.source.style;
                sourceTypeId = sourceTypes.appCss;
                sourceValueTypeId = sourceValueTypes.style;
                moduleInstanceId = req.content.source.moduleInstanceId;
                break;

            case 'GLOBALCSS':
                sourceValue = req.content.source.style
                sourceTypeId = sourceTypes.globalCss;
                sourceValueTypeId = sourceValueTypes.style;
                break;

            case 'APPSCRIPTING':
                sourceValue = req.content.source.script
                sourceTypeId = sourceTypes.appScripting;
                sourceValueTypeId = sourceValueTypes.script;
                moduleInstanceId = req.content.source.moduleInstanceId;
                break;

            case 'GLOBALSCRIPTING':
                sourceValue = req.content.source.script
                sourceTypeId = sourceTypes.globalScripting;
                sourceValueTypeId = sourceValueTypes.script;
                break;

            case 'TARGETEDCONTENT':
                sourceValue = JSON.stringify(req.content.source.campaign)
                sourceTypeId = sourceTypes.targetedContent;
                sourceValueTypeId = sourceValueTypes.campaign;
                moduleInstanceId = typeof(req.content.source.moduleInstanceId) !== 'undefined' ? req.content.source.moduleInstanceId : null;
                break;

            default:
                console.log('in default case');
        }

        var insertQuery = ' insert CssContent(sourceTypeId, sourcevaluetypeid, sourceValue, moduleInstanceId, portalId) \n' 
        + ' values( @sourceTypeIdParam, @sourceValueTypeIdParam, @sourceValueParam, @moduleInstanceIdParam, @portalIdParam ); \n'
         + ' select SCOPE_IDENTITY() as _id;';

        var queryObject = {
            q: insertQuery,
            qp: {
                sourceTypeIdParam: {
                    value: sourceTypeId,
                    type: 'Int'
                },
                sourceValueTypeIdParam: {
                    value: sourceValueTypeId,
                    type: 'Int'
                },
                sourceValueParam: {
                    value: sourceValue
                },
                moduleInstanceIdParam: {
                    value: moduleInstanceId,
                    type: 'Int'
                },
                portalIdParam: {
                    value: portalId,
                    type: 'Int'
                }
            }
        }

        return query(queryObject, req)
            .then(function(insertResult) {

                return insertResult[0]._id;

            });

    };

    function updateCssContent(req) {

        var sourceValue = '';
        switch (req.type.trim().toUpperCase()) {

            case 'APPCSS':
                sourceValue = req.content.source.style;
                break;

            case 'GLOBALCSS':
                sourceValue = req.content.source.style
                break;

            case 'APPSCRIPTING':
                sourceValue = req.content.source.script
                break;

            case 'GLOBALSCRIPTING':
                sourceValue = req.content.source.script
                break;

            case 'TARGETEDCONTENT':
                sourceValue = JSON.stringify(req.content.source.campaign)
                break;

            default:
                console.log('in default case');
        }

        var updateString = 'update CssContent set SourceValue = @sourceParamValue where Id = @id'

        var queryObject = {
            q: updateString,
            qp: {
                id: {
                    value: req.content._id,
                    type: 'Int'
                },
                sourceParamValue: {
                    value: sourceValue
                }
            }
        }

        return query(queryObject, req)
            .then(function(updateResults) {

                return req.content._id;

            });
    };

    function getAllCssContent(req) {

        var qString = 'select CssContent.Id as id,CssSourceTypes.SourceTypeName as source, CssContent.SourceTypeId as sourceTypeId, SourceValue as value, coalesce(esWebpage.sectionname,ModuleInstances.Name) as ecoApp, CssContent.PortalId as portalId, '+ getPortalGroupId(req)+' as portalGroup from CssContent (nolock) \n' + ' inner join CssSourceTypes (nolock)  on CssContent.SourceTypeId = CssSourceTypes.Id \n' 
        + ' inner join CssSourceValueTypes (nolock) on CssContent.SourceValueTypeId = CssSourceValueTypes.Id \n' 
        + ' left join ModuleInstances (nolock) on CssContent.ModuleInstanceId = ModuleInstances.Id \n' 
        + '    left join esWebpageProperties (nolock)on esWebpageProperties.KeyValue = ModuleInstances.Id and KeyName = \'MODULEREF\' \n' 
        + '         left join esWebpage (nolock) on esWebpageProperties.esWebPageRef = esWebpage.ref       \n' 
        + ' where CssContent.portalId = @portalId';
        
        var portalId = req.portalId;
        
        var queryObject = {
            q: qString,
            qp: {
                portalId: {
                    value: portalId,
                    type: 'Int'
                }
            }
        };

        return query(queryObject, req).then(function(queryResult) {

            var result = {
                appCSS: {},
                globalCSS: {},
                appScripting: {},
                globalScripting: {},
                targetedContent: {}
            };

            var sourceTypes = {
                appCss: 1,
                globalCss: 2,
                appScripting: 3,
                globalScripting: 4,
                targetedContent: 5
            };


            result.appCSS = getappCssFromQueryResult(queryResult, sourceTypes);
            result.globalCSS = getglobalCssFromQueryResult(queryResult, sourceTypes);
            result.appScripting = getAppScriptingFromQueryResult(queryResult, sourceTypes);
            result.globalScripting = getglobalScriptingFromQueryResult(queryResult, sourceTypes);
            result.targetedContent = getTargetedContentFromQueryResult(queryResult, sourceTypes);
            return result;

        });
    };


    function getPortalGroupId(req) {
        return parseInt(req.portalGroupId, 10);
    };

    function query(q, req) {
        return microservices.call('empower.v6.portal-groups.mssql.query.pg-' + getPortalGroupId(req), q)
            .tap(function(results) {
                log.trace('get| query results', util.inspect(results, {
                    colors: true,
                    depth: null
                }));
            })
            .then(function(results) {
                return results;
            });
    };

    function errorWrap(fn, message, mc) {
        return Promise.try(function() {
            return fn(message, mc);
        }).catch(function(err) {
            return {
                error: err.message
            };
        });
    };


});
