'use strict';
var micro = require('ih-microservice');
var xml2js = require('xml2js');

var defaults = {
  id: 'empower-roles',
  debug: false,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-roles',
  defaultReturnBody: true
};

micro(defaults, function(app, logging, options, microservices, Promise, _) {

  var log = logging.getLogger(defaults.id);

  var INSERT_QUERY = 'INSERT INTO enAuthGroups (name, description, candelete, passwordexpires, portalId, permissions) VALUES (@name, @name, 1, 0, @portalId, @permissions); SELECT SCOPE_IDENTITY() AS id;';
  var UPDATE_QUERY = 'UPDATE enAuthGroups SET name = @name, description = @name, permissions = @permissions WHERE ref = @ref; SELECT @@ROWCOUNT AS updated';
  var FIND_BY_IDS_QUERY = 'SELECT ref as id, g.name, portalId, p.portalType, permissions FROM enAuthGroups g INNER JOIN CmsPortals p on p.Id = portalId WHERE ref IN (1,2,3,4,5) ORDER BY g.name';
  var FIND_BY_PORTAL_QUERY = 'SELECT ref as id, name, portalId, permissions FROM enAuthGroups WHERE portalId = @portalId ORDER BY name';

  return Promise.all([
    microservices.bind('empower.roles.create.#', _.wrap(create, errorWrap)),
    microservices.bind('empower.roles.find.by-ids.#', _.wrap(findByIds, errorWrap)),
    microservices.bind('empower.roles.find.by-target.#', _.wrap(findByTarget, errorWrap)),
    microservices.bind('empower.roles.update.#', _.wrap(update, errorWrap))
  ]);

  function create(role, mc) {
    log.debug('creating role', role);
    return submitQuery({
      q: INSERT_QUERY,
      qp: {
        name: {
          value: role.name,
          type: 'VarChar'
        },
        portalId: {
          value: parseInt(role.portalId, 10),
          type: 'Int'
        },
        permissions: {
          value: toXml(role.permissions),
          type: 'XML'
        }
      }
    }, mc).then(function(results) {
      return {
        id: results[0].id
      };
    });
  }

  function submitQuery(queryObj, messageContext) {
    log.debug('submitting query', queryObj.q);
    var portalGroupId = getPortalGroupId(messageContext);
    return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, queryObj)
      .then(function(results) {
        checkError(results);
        return results;
      });
  }

  function getPortalGroupId(messageContext) {
    return _.last(messageContext.routingKey.split('.'));
  }

  function checkError(results) {
    if (typeof(results.error) !== 'undefined') {
      throw new Error('Error running query: ' + results.error);
    }
  }

  function toXml(permissionsArray) {
    var builder = new xml2js.Builder({
      renderOpts: {
        pretty: false
      }
    });
    return builder.buildObject({
      permissions: {
        permission: permissionsArray
      }
    });
  }

  function toJson(permissionsXml) {
    if (!permissionsXml) {
      return Promise.resolve([]);
    }
    var parser = new xml2js.Parser({
      explicitArray: false
    });
    return Promise.promisify(parser.parseString)(permissionsXml).then(function(res) {
      var permissions = res.permissions.permission;
      if (_.isArray(permissions)) {
        return permissions;
      }
      return [permissions];
    }).catch(function() {
      return [];
    });
  }

  function mapResults(results) {
    return Promise.all(results.map(function(result) {
      return toJson(result.permissions).then(function(permissions) {
        result.permissions = permissions;
        return result;
      });
    }));
  }

  function findByIds(findMessage, mc) {
    log.debug('received findMessage', findMessage);
    var params = {};
    var paramString = '';
    for (var i = 0; i < findMessage.roleIds.length; i++) {
      if (paramString !== '') {
        paramString += ',';
      }
      var param = 'ref' + i.toString();
      paramString += '@' + param;
      params[param] = {
        value: findMessage.roleIds[i],
        type: 'Int'
      };
    }
    var query = FIND_BY_IDS_QUERY.split('{0}').join(paramString);
    return submitQuery({
      q: query,
      qp: params
    }, mc).then(function(results) {
      return mapResults(results);
    });
  }

  function findByTarget(findMessage, mc) {
    log.debug('received findMessage', findMessage);
    return submitQuery({
      q: FIND_BY_PORTAL_QUERY,
      qp: {
        portalId: {
          value: parseInt(findMessage.target, 10),
          type: 'Int'
        }
      }
    }, mc).then(function(results) {
      return mapResults(results);
    });
  }

  function update(role, mc) {
    log.debug('updating role', role);
    return submitQuery({
      q: UPDATE_QUERY,
      qp: {
        ref: {
          value: parseInt(role.id, 10),
          type: 'Int'
        },
        name: {
          value: role.name,
          type: 'VarChar'
        },
        permissions: {
          value: toXml(role.permissions),
          type: 'XML'
        }
      }
    }, mc).then(function(result) {
      return {
        updated: result[0].updated,
      };
    });
  }

  function errorWrap(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      return {
        error: err.message
      };
    });
  }

});