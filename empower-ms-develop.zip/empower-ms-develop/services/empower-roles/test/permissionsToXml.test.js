var chai = require('chai');
var expect = chai.expect;
var xml2js = require('xml2js');
var util = require('util');

describe('permissions to xml', function() {

  var permissionsArray = [{
    id: 'test.1234'
  }, {
    id: 'test.abcd'
  }];

  var xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><permissions><permission><id>test.1234</id></permission><permission><id>test.abcd</id></permission></permissions>';

  it('converts to xml', function() {

    var builder = new xml2js.Builder({
      renderOpts: {
        pretty: false
      }
    });

    var result = builder.buildObject({
      permissions: {
        permission: permissionsArray
      }
    });

    expect(result).to.eql(xml);

  });

  it('converts to json', function() {

    var parser = new xml2js.Parser({
      explicitArray: false
    });
    parser.parseString(xml, function(err, res) {
      console.log(util.inspect(res, {
        depth: null
      }));
      expect(res.permissions.permission).to.eql(permissionsArray);
    });

  });

});