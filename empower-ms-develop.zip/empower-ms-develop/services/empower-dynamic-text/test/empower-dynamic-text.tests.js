'use strict';
var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var _ = require('lodash');
var util = require('util');

describe('empower-dynamic-text', function() {

  var service, mockMs, mockLog, mockMicroservices, options, mockLogging, request, messageContext, expectedResult;
  beforeEach(function() {
    mockMs = sinon.stub();
    mockLog = sinon.stub({
      debug: function() {},
      error: function(e) {
        console.error(e)
      },
      trace: function() {}
    });
    mockLogging = {
      getLogger: function() {
        return mockLog;
      }
    };
    mockMicroservices = sinon.stub({
      bind: function() {},
      call: function() {}
    });
    options = {};
    mockMs.yields(undefined, mockLogging, mockMicroservices, Promise, options, _, util);
    service = proxyquire.noCallThru()('../empower-dynamic-text', {
      'ih-microservice': mockMs
    });

    request = {
      lang: 'es',
      portalId: 2
    };

    messageContext = {
      routingKey: 'empower.dynamic-text.for-lang.42'
    };

  });

  it('exists', function() {
    expect(service).to.be.an('object');
  });

  describe('getDynamicTextValues', function() {

    it('is a function', function() {
      expect(service.getDynamicTextValues).to.be.a('function');
    });

    describe('when called', function() {

      beforeEach(function() {

        mockMicroservices.call.onCall(0).returns(Promise.resolve([{
          moduleId: null,
          key: 'key1',
          value: 'val1'
        }, {
          moduleId: 'MyModule',
          key: 'key2.subkey',
          value: 'Added info to $$PatientName$$'
        }]));

        expectedResult = {
          'key1': 'val1',
          'MyModule_key2_subkey': 'Added info to {{patientName}}'
        };

      });

      it('queries for dynamic text entries in the correct portal group', function(done) {
        service.getDynamicTextValues(request, messageContext).then(function() {
          expect(mockMicroservices.call.getCall(0).args[0]).to.equal('empower.v6.portal-groups.mssql.query.42');
          done();
        }).catch(done);
      });

      it('queries for dynamic text entries', function(done) {
        service.getDynamicTextValues(request, messageContext).then(function() {
          expect(mockMicroservices.call.getCall(0).args[1].q.indexOf('SELECT')).to.equal(0);
          done();
        }).catch(done);
      });

      it('queries for dynamic text entries for the correct language', function(done) {
        service.getDynamicTextValues(request, messageContext).then(function() {
          expect(mockMicroservices.call.getCall(0).args[1].qp.lang.value).to.equal('es');
          done();
        }).catch(done);
      });

      it('queries for dynamic text entries from the correct portal group', function(done) {
        service.getDynamicTextValues(request, messageContext).then(function() {
          expect(mockMicroservices.call.getCall(0).args[1].qp.portalId.value).to.equal(2);
          done();
        }).catch(done);
      });

      it('returns a hash of the keys and values', function(done) {
        service.getDynamicTextValues(request, messageContext).then(function(result) {
          expect(Object.getOwnPropertyNames(result).length).to.equal(2);
          done();
        }).catch(done);
      });

      it('converts keys and values', function(done) {
        service.getDynamicTextValues(request, messageContext).then(function(result) {
          expect(result).to.eql(expectedResult);
          done();
        }).catch(done);
      });

    });

  });

  describe('convertTokens', function() {

    it('is a function', function() {
      expect(service.convertTokens).to.be.a('function');
    });

    describe('when called', function() {

      var input = 'The quick brown $$Animal$$ jumped over the lazy $$OtherAnimal$$.';
      var expected = 'The quick brown {{animal}} jumped over the lazy {{otherAnimal}}.'
      var result;

      beforeEach(function() {
        result = service.convertTokens(input);
      });

      it('converts the $$ tokens to {{}} tokens', function() {
        expect(result).to.equal(expected);
        console.log(result);
      });
    });
  });

  describe('makeKey', function() {
    it('is a function', function() {
      expect(service.makeKey).to.be.a('function');
    });

    var item, result;

    describe('when item has no moduleId', function() {

      beforeEach(function() {
        item = {
          moduleId: null,
          key: 'aKey'
        };
        result = service.makeKey(item);
      });

      it('uses the key', function() {
        expect(result).to.equal('aKey');
      });

    });

    describe('when item has a moduleId', function() {

      beforeEach(function() {
        item = {
          moduleId: 'MyModule',
          key: 'aKey'
        };
        result = service.makeKey(item);
      });

      it('prepends the moduleId to the key ', function() {
        expect(result).to.equal('MyModule_aKey');
      });

    });

    describe('when key has dots', function() {
      beforeEach(function() {
        item = {
          moduleId: 'MyModule',
          key: 'aKey.subkey.xyz'
        };
        result = service.makeKey(item);
      });

      it('replaces the dots with underscores', function() {
        expect(result).to.equal('MyModule_aKey_subkey_xyz');
      });
    });

    describe('when entry key already has the module id', function() {
      beforeEach(function() {
        item = {
          moduleId: 'MyModule',
          key: 'MyModule.key'
        };
        result = service.makeKey(item);
      });

      it('does not prepend the module id', function() {
        expect(result).to.equal('MyModule_key');
      });

      describe('if different case', function() {
        beforeEach(function() {
          item = {
            moduleId: 'mhr',
            key: 'MHR.key'
          };
          result = service.makeKey(item);
        });

        it('does not prepend the module id', function() {
          expect(result).to.equal('MHR_key');
        });

      });

      describe('if coincidental', function() {
        beforeEach(function() {
          item = {
            moduleId: 'MyModule',
            key: 'MyModuleKey'
          };
          result = service.makeKey(item);
        });

        it('prepends the module id', function() {
          expect(result).to.equal('MyModule_MyModuleKey');
        });

      });

    });
  });

});