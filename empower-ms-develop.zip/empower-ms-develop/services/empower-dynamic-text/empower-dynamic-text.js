'use strict';

var micro = require('ih-microservice');
var _ = require('lodash');

var defaults = {
  id: 'empower-dynamic-text',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-dynamic-text',
  defaultReturnBody: true
};

micro(defaults, function(app, logging, microservices, Promise, options, util) {
  var log = logging.getLogger(defaults.id);

  var QUERY = 'SELECT DISTINCT i.moduleId, d.[key], v.[value]' +
    ' FROM [DynamicText] d' +
    ' JOIN [DynamicTextValues] v ON d.Id = v.DynamicTextId' +
    ' LEFT JOIN ModuleInstances i ON i.Id = d.ModuleInstanceId' +
    ' LEFT JOIN esWebPageProperties pp ON pp.KeyName = \'MODULEREF\' AND pp.KeyValue = i.Id' +
    ' LEFT JOIN esWebpage p ON p.ref = pp.esWebPageRef' +
    ' LEFT JOIN CmsPortals pr ON pr.Id = p.portalId' +
    ' WHERE' +
    ' (d.ModuleInstanceId IS NULL OR d.ModuleInstanceId IN (SELECT Id FROM ModuleInstances)) AND' +
    ' (ISNULL(p.portalId, @portalId) = @portalId OR pr.PortalType = 3) AND' +
    ' v.CultureName LIKE @lang + \'%\'' +
    ' ORDER BY i.ModuleId, d.[Key]';

  var TOKEN_EXP = /\$\$(\w+)\$\$/g;

  module.exports = {
    getDynamicTextValues: getDynamicTextValues,
    convertTokens: convertTokens,
    makeKey: makeKey
  };

  return Promise.resolve(microservices.bind('empower.dynamic-text.for-lang.#', getDynamicTextValues));

  function getDynamicTextValues(request, messageContext) {
    log.debug('getting dynamic text for language %s in portal %s', request.lang, request.portalId);
    return Promise.try(
      function() {
        return getDynamicTextEntries()
          .then(convertEntriesToResult);
      }
    ).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });

    function getDynamicTextEntries() {
      log.debug('getting dynamic text entries');
      var query = {
        q: QUERY,
        qp: {
          portalId: {
            type: 'Int',
            value: request.portalId
          },
          lang: {
            type: 'NVarChar',
            value: request.lang,
            length: request.lang.length
          }
        }
      };
      return submitQuery(query)
        .tap(function(entries) {
          log.debug('got %s dynamic text entries', entries.length);
        });
    }

    function convertEntriesToResult(entries) {
      var result = {};
      entries.forEach(function(entry) {
        var key = makeKey(entry);
        var value = convertTokens(entry.value);
        result[key] = value;
      });
      log.trace('result', result);
      return result;
    }

    function submitQuery(queryObj) {
      log.trace('submitting query', queryObj.q, queryObj.qp);
      var portalGroupId = getPortalGroupId();
      return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, queryObj)
        .then(function(results) {
          if (results.error) {
            throw new Error('Error running query: ' + results.error);
          }
          return results;
        });

      function getPortalGroupId() {
        return _.last(messageContext.routingKey.split('.'));
      }
    }
  }

  function convertTokens(text) {
    return text.replace(TOKEN_EXP, function(captured) {
      return '{{' + _.camelCase(captured) + '}}';
    });
  }

  function makeKey(entry) {
    var moduleKey = '';
    if (entry.moduleId) {
      if (entry.key.toLowerCase().indexOf(entry.moduleId.toLowerCase() + '.') !== 0) {
        moduleKey = entry.moduleId + '_';
      }
    }
    return (moduleKey + entry.key)
      .replace(/\./g, '_');
  }

});