var chai = require('chai');
var expect = chai.expect;
var resolveRule = require('../resolve-rule.js');

describe('resolve-rule', function() {

  var ruleCollections = [{
    StateId: null,
    Rules: [{
      Name: 'Default Full Access',
      FromTheAgeOf: 0,
      UntilTheAgeOf: 11,
      Permissions: ['1', '2', '3', '4'],
      IsEnabled: true
    }, {
      Name: 'Default Limited Access',
      FromTheAgeOf: 11,
      UntilTheAgeOf: 18,
      Permissions: ['1', '6'],
      IsEnabled: true
    }, {
      Name: 'Default No Access',
      FromTheAgeOf: 18,
      UntilTheAgeOf: null,
      Permissions: [],
      IsEnabled: true
    }]
  }, {
    StateId: 1001,
    Rules: [{
      Name: 'Alabama 0-11',
      FromTheAgeOf: 0,
      UntilTheAgeOf: 11,
      Permissions: ['1', '2', '3'],
      IsEnabled: true
    }, {
      Name: 'Alabama 11-18',
      FromTheAgeOf: 11,
      UntilTheAgeOf: 18,
      Permissions: ['1'],
      IsEnabled: true
    }]
  }, {
    StateId: 1005,
    Rules: [{
      Name: 'CA 0-11',
      FromTheAgeOf: 0,
      UntilTheAgeOf: 11,
      Permissions: ['1', '2', '3'],
      IsEnabled: true
    }, {
      Name: 'CA Disabled',
      FromTheAgeOf: 18,
      UntilTheAgeOf: null,
      Permissions: [],
      IsEnabled: false
    }]
  }];

  it('finds state rule by age', function() {
    var patient = {
      age: 10,
      state: 1001
    };
    var rule = resolveRule(ruleCollections, patient);
    expect(rule.Name).to.eql('Alabama 0-11');
  });

  it('finds state rule by edge age', function() {
    var patient = {
      age: 11,
      state: 1001
    };
    var rule = resolveRule(ruleCollections, patient);
    expect(rule.Name).to.eql('Alabama 11-18');
  });

  it('finds default rule by age when no state rule collection', function() {
    var patient = {
      age: 10,
      state: 1002
    };
    var rule = resolveRule(ruleCollections, patient);
    expect(rule.Name).to.eql('Default Full Access');
  });

  it('finds default rule when no state rule by age', function() {
    var patient = {
      age: 18,
      state: 1005
    };
    var rule = resolveRule(ruleCollections, patient);
    expect(rule.Name).to.eql('Default No Access');
  });

  it('finds default rule when matching state rule is disabled', function() {
    ruleCollections[1].Rules[1].IsEnabled = false;

    var patient = {
      age: 18,
      state: 1001
    };
    var rule = resolveRule(ruleCollections, patient);
    expect(rule.Name).to.eql('Default No Access');

    ruleCollections[1].Rules[1].IsEnabled = true;
  });

  it('finds no rule when no state rule and default rule is disabled', function() {
    ruleCollections[0].Rules[2].IsEnabled = false;

    var patient = {
      age: 19,
      state: 1001
    };
    var rule = resolveRule(ruleCollections, patient);
    expect(rule).to.eql({});

    ruleCollections[0].Rules[2].IsEnabled = true;
  });


});