'use strict';
var _ = require('lodash');
var util = require('util');
var log = require('log4js').getLogger('age-of-majority.resolve-rule');

module.exports = function(ruleCollections, patient) {

  var effectiveRule;

  //find a rule collection for the patient's state
  var stateCollection = _.find(ruleCollections, function(rc) {
    return rc.StateId === patient.state;
  });
  log.trace('rule collection found for state:', stateCollection || '(none)');
  if (stateCollection) {
    effectiveRule = findEffectiveRule(stateCollection, patient);
  }

  if (!effectiveRule) {
    //if no rule found, default to rule collection with null state 
    var defaultCollection = _.find(ruleCollections, function(rc) {
      return rc.StateId === null || rc.State === 'AOMDefaultRule';
    });
    log.trace('default rule collection found:', defaultCollection || '(none)');
    if (defaultCollection) {
      effectiveRule = findEffectiveRule(defaultCollection, patient);
    }
  }

  if (effectiveRule) {
    log.trace('effectiveRule found:', util.inspect(effectiveRule));
  }

  return effectiveRule || {};

};

function findEffectiveRule(ruleCollection, patient) {
  return _(ruleCollection.Rules)
    .find(function(rule) {
      var from = rule.FromTheAgeOf;
      var to = rule.UntilTheAgeOf;
      return rule.IsEnabled && (na(from) || from <= patient.age) && (patient.age < to || na(to));

      function na(x) {
        return x === undefined || x === null;
      }
    });
}