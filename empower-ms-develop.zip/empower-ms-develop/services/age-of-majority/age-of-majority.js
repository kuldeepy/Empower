'use strict';

var crutch = require('ih-microservice');
var resolveRule = require('./resolve-rule.js');

var defaults = {
  id: 'age-of-majority',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'age-of-majority',
  defaultReturnBody: true,
  defaultTimeout: 10000,
  channelPrefetch: 0,
};

module.exports = crutch(defaults, function(_, app, inject, logging, microservices, options, Promise, util, moment) {
  var log = logging.getLogger(options.id);

  var RULES_QUERY = "SELECT TOP 1 s.TextValue FROM NModuleSettings s JOIN ModuleInstances m ON m.Id = s.ModuleInstanceId WHERE s.[Key] = 'UserManagementModuleSettings' ORDER BY m.Priority;";
  var PATIENT_QUERY = 'SELECT dateOfBirth, [state] FROM nModProfilePatients WHERE Id = @patientId';

  return Promise.all([
    microservices.bind('empower.age-of-majority.rule-collections.all.#', _.wrap(getRuleCollections, returnError)),
    microservices.bind('empower.age-of-majority.rule.for-patient.#', _.wrap(getRuleForPatient, returnError))
  ]);

  function getRuleForPatient(request, mc) {
    return getRuleCollections({}, mc).then(function(ruleCollections) {
      if (!ruleCollections || ruleCollections.length === 0) {
        log.warn('No AOM rule collections found');
        return {};
      }
      return getPatient(request.patientId, mc).then(function(patient) {
        if (!patient) {
          log.warn('No patient found by id', request.patientId);
          return {};
        }
        patient.age = moment().diff(patient.dateOfBirth, 'years');
        log.trace('patient.age', patient.age);
        log.trace('patient.state', patient.state);
        log.trace('ruleCollections', util.inspect(ruleCollections, {
          depth: 2
        }));

       return resolveRule(ruleCollections, patient);
      });
    });
  }

  function getRuleCollections(options, mc) {
    return submitQuery({
        q: RULES_QUERY
      }, mc)
      .then(function(results) {
        return _(results)
          .pluck('TextValue')
          .map(JSON.parse)
          .pluck('AgeOfMajorityRuleCollections')
          .first();
      })
      .tap(function(result) {
        log.trace('getRuleCollections| result:', result);
      })
      .then(function(rules) {
        return rules;
      });
  }

  function getPatient(patientId, mc) {
    return submitQuery({
        q: PATIENT_QUERY,
        qp: {
          patientId: {
            type: 'INT',
            value: patientId
          }
        }
      }, mc)
      .then(function(results) {
        return _(results).first();
      });
  }

  function submitQuery(queryObj, messageContext) {
    log.debug('submitting query', queryObj.q);
    var portalGroupId = getPortalGroupId(messageContext);
    return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, queryObj)
      .then(function(results) {
        checkError(results);
        return results;
      });
  }

  function getPortalGroupId(messageContext) {
    return _.last(messageContext.routingKey.split('.'));
  }

  function checkError(results) {
    if (typeof(results.error) !== 'undefined') {
      throw new Error('Error running query: ' + results.error);
    }
  }

  function returnError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }
});