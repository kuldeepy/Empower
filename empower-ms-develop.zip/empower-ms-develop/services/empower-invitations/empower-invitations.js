'use strict';
var micro = require('ih-microservice'),enterprise;


var defaults = {
  id: 'patient-user-invitations',
  debug: false,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-enrollment-invitations',
  communicateDb: '[MedseekIntegration60]',
  defaultReturnBody: true,
  injectables: {
    moment: require('moment')
  }
};


micro(defaults, function(app, logging, microservices, Promise, options, url, _, moment, util) {

  var log = logging.getLogger(defaults.id);
  log.trace('getInvitations req:', url);
    var knownPgs = {};
    var db;
  var services = Promise.all([
    microservices.bind('empower.enrollment-invitations.update-version.#',updateVersion),
    microservices.bind('empower.enrollment-invitations.search.#', getInvitations),
    microservices.bind('empower.enrollment-invitations-by-guid.#', getInvitations),
    microservices.bind('empower.enrollment-invitations-by-userid.#', getInvitations),
    microservices.bind('empower.enrollment-search-invitations.#', getInvitations),
    microservices.bind('empower.enrollment-invitations.update.#', updateInvitation)
  ]);

  function updateVersion(req,mc){

    log.debug(req);

    var q = {
      q: 'UPDATE nModPosEnrollmentInvitation set version = version + 1 where version = @version and pin = @pin; SELECT @@ROWCOUNT as rowsUpdated;',
      qp: {
        pin: {
          type: 'NVarChar',
          value: req.pin
        },
        version: {
          type: 'Int',
          value: req.version
        }
      }
    };

    return submitSql(q,_.last(mc.routingKey.split('.')))
    .tap(function(d){
      log.debug('response from update',d);
    })
    .then(_.first);
  }

  function updateInvitation(req, mc){
    var pgId = _.last(mc.routingKey.split('.'));
    log.debug('updateInvitation| req', req);
    var sql = 'UPDATE [nModPosEnrollmentInvitation] \n' +
          '    SET    [Pin] = @pin, \n' +
          '       [RelationshipClassification] = @relationshipClassification, \n' +
          '       [AccessLevelId] = @accessLevelId, \n' +
          '       [Status] = @status, \n' +
          '       [IsEmancipatedMinor] = @emancipated \n' +
          '    WHERE   [Pin] = @pin;  SELECT @@Identity as rowsUpdated ';

    var cleanSql = 'DELETE from [nModProfilePreloadedEntities] WHERE pendingPatientId = @medseekId';
    var preloadedInsertSql = 'INSERT INTO nModProfilePreloadedEntities (PendingPatientTypeId,PendingPatientId,PreloadedEntityTypeId, PreloadedEntityId) Values (\'PosEnrollment\',@medseekId,@typeId, @entityId)';

    var q = {
      q: sql,
      qp: {
        pin: {
          type: 'NVarChar',
          value: req.pin
        },
        relationshipClassification: {
          type: 'NVarChar',
          value: req.relationshipClassification
        },
        accessLevelId: {
          type: 'Int',
          value: req.accessLevelId
        },
        medseekId: {
          type: 'NVarChar',
          value: req.medseekId
        },
        emancipated: {
          type: 'Bit',
          value: req.emancipatedMinor ? 1 : 0
        },
        status: {
          type: 'Int',
          value: req.excludeFromAgeOfMajority ? 103 : 100
        }
      }
    };
    log.debug('query params',q);
    var totalPreload = 0;
    function preload(id,typeId){
      var obj = {
        q:preloadedInsertSql,
        qp: {
          typeId: {
            type: 'NVarChar',
            value: typeId
          },
          medseekId: {
            type: 'NVarChar',
            value: req.medseekId
          },
          entityId: {
            type: 'Int',
            value: id
          }
        }
      };

      return submitSql(obj,pgId);
    }
    return submitSql(q,pgId)
      .then(function(d){
        log.debug('Rows Updated',d);
        q.q = cleanSql;
        return submitSql(q,pgId);
      })
      .then(function(){
          log.debug('Updating Preloaded Physicians');
          if (req.preloadedPhysicianIdentifiers) {
              return Promise.map(req.preloadedPhysicianIdentifiers, function (id) {
                  totalPreload++;
                  log.debug('Inserting Physician Id:', id);
                  return preload(id, 'Physician');
              });
          }
      })
      .then(function(){
          log.debug('Updating Preloaded Locations');
          if (req.preloadedLocationIdentifiers) {
              return Promise.map(req.preloadedLocationIdentifiers, function (id) {
                  totalPreload++;
                  log.debug('Inserting Location Id:', id);
                  return preload(id, 'Location');
              });
          }
      })
      .tap(function(){
        log.debug('Completed Update', totalPreload);
      })
      .then(function(){
        return { success: true };
      })
      .catch(function(err){
        log.error(err);
        return { error: 'Error from Empower-Invitations Microservice: ' + err };
      });
    }

    function getKnownDb(id){
    return new Promise(function(resolve){
      log.trace('knownPgs for id %s: ',id, knownPgs[id]);
      resolve(knownPgs[id]);
    })
    .then(function(pg){
      return pg || microservices.call('empower.v6.portal-groups.get',{})
        .tap(function(pgs){
          log.trace(pgs);
        })
        .then(function(pgs){
          enterprise = _.find(pgs,{isEnterprise:true});
          var pg = _.find(pgs,{siteID: id });
          knownPgs[id] = toMssqlConfig(pg.mssql).database;
          return knownPgs[id];
        });
      });
    }

    function getInvitations(req,mc) {
      log.trace('getInvitations| req:', req);
      req.searchType = (req.searchType || 'Both').toLowerCase();
      return getKnownDb(parseInt(_.last(mc.routingKey.split('.')),10))
      .then(function(db){
        var query = buildQuery(req,db);
        log.debug('enterprise',enterprise);
        return submitQuery(query,mc,enterprise.siteID)
          .then(function(data){
            return computeStatus(data);
          }).catch(function(err){
            return err;
          });
      })
      .catch(function(err){
        log.error(err);
        return { error: 'Error from Empower-Invitations Microservice: ' + err };
      });
    }

  function buildQuery(req, pgDb) {
      var orderBy = 'i.[InvitationDate] DESC';

      switch (req.orderBy) {
        case 'status':
          orderBy = 'case when status is null then 1 else 0 end, status';
          break;
        case 'firstName':
          orderBy = 'case when pd.PatientName_GivenName is null then 1 else 0 end, pd.PatientName_GivenName';
          break;
        case 'lastName':
          orderBy = 'case when pd.PatientName_FamilyName is null then 1 else 0 end, pd.PatientName_FamilyName';
          break;
        case 'userFirstName':
          orderBy = 'case when i.userFirstName is null then 1 else 0 end, i.userFirstName';
          break;
        case 'userLastName':
          orderBy = 'case when i.userLastName is null then 1 else 0 end, i.userLastName';
          break;
        default:
          orderBy = 'i.[InvitationDate] DESC';
          break;
      }

      var query = {
        q:'SELECT ROW_NUMBER() OVER (ORDER BY ' + orderBy + ') as rowNum, i.[id], \n' +
        '      i.[pin], \n' +
        '      i.[userId], \n' +
        '      i.[medseekId], \n' +
        '      i.[expirationDate], \n' +
        '      i.[relationshipClassification] as relationship, \n' +
        '      [status] = \n' +
        '        CASE [STATUS]\n' +
        '          WHEN 100 THEN \'Pending\' \n' +
        '          WHEN 101 THEN \'Expired\' \n' +
        '          WHEN 102 THEN \'Enrolled\' \n' +
        '          WHEN 103 THEN \'PendingExcludedFromAgeOfMajority\'\n' +
        '          WHEN 105 THEN \'ResendByStaff\'\n' +
        '        END, \n' +
        '      i.[statusUpdatedDateTime], \n' +
        '      i.[email], \n' +
        '      i.[remainingAttempts], \n' +
        '      i.[lastName], \n' +
        '      i.[firstName], \n' +
        '      i.[invitationDate], \n' +
        '      i.[middleName], \n' +
        '      i.[isEmancipatedMinor], \n' +
        '      i.[portalId], \n' +
        '      i.[portalRole], \n' +
        '      i.[accessLevelId], \n' +
        '      i.[userFirstName], \n' +
        '      i.[userLastName], \n' +
        '      i.[statusUpdatedBy], \n' +
        '      i.[version], \n' +
        '      i.[language], \n' +
        '      u.[gender] as userGender, \n' +
        '      a.[name] as accessLevel, \n' +
        '      p.[name] as portalName, \n' +
        '      r.[name] as roleName, \n' +
        '        STUFF( \n' +
        '        (SELECT \', \' + source_group + \':\' +  identifier \n' +
        '          FROM ' + options.communicateDb + '.[dbo].[ps_Patients] C \n' +
        '          WHERE C.medseekPatientId = i.MedseekId '  + (req.mrn ? ' AND C.identifier = @mrn ' : '') + '\n' +
        '          FOR XML PATH (\'\')) \n' +
        '         , 1, 1, \'\') as identifiers, \n' +
        '      pd.sex AS patientGender, \n' +
        '        (SELECT \'[\' + STUFF( \n' +
        '        (SELECT \',\' +  PreloadedEntityId \n' +
        '          FROM ['+ pgDb +'].[dbo].nModProfilePreloadedEntities e \n' +
        '          WHERE e.PreloadedEntityTypeId = \'Physician\' \n' +
        '          AND e.PendingPatientId = i.medseekId \n' +
        '          FOR XML PATH (\'\')) \n' +
        '         , 1, 1, \'\') + \']\' ) as preloadedPhysicians, \n' +
        '        (SELECT \'[\' + STUFF( \n' +
        '        (SELECT \',\' +  PreloadedEntityId \n' +
        '          FROM ['+ pgDb +'].[dbo].nModProfilePreloadedEntities e \n' +
        '          WHERE e.PreloadedEntityTypeId = \'Location\' \n' +
        '          AND e.PendingPatientId = i.medseekId \n' +
        '          FOR XML PATH (\'\')) \n' +
        '         , 1, 1, \'\') + \']\' ) as preloadedLocations \n' +
        '  FROM ['+ pgDb +'].[dbo].nModPosEnrollmentInvitation i \n' +
        '  LEFT JOIN ['+ pgDb +'].[dbo].nModProfileAccessLevels a on a.id = i.accessLevelId  \n' +
        '  LEFT JOIN ['+ pgDb +'].[dbo].CmsPortals p ON p.Id = i.PortalId \n' +
        '  LEFT JOIN ['+ pgDb +'].[dbo].enAuthGroups r ON r.ref = i.PortalRole \n' +
        '  LEFT JOIN ['+ pgDb +'].[dbo].enAuthUsers u ON u.ref = i.userId \n' +
        '  Left join ' + options.communicateDb + '.[dbo].[ps_PatientDemographics] pd On pd.medseekPatientId = i.MedseekId  \n',

        qp: {}
      };

      if(req.mrn){
        query.q += ' INNER JOIN ' + options.communicateDb + '.[dbo].[ps_Patients] c on c.identifier = @mrn AND c.medseekPatientId = i.MedseekId ';
      }

      query.q += ' WHERE i.Deleted IS NULL AND (u.Deleted = 0 OR u.Deleted IS NULL) ';

      if (req.userId) {
        query.q += ' AND u.ref = @userId';
        query.qp.userId = {
          type: 'Int',
          value: req.userId
        };
      }

      if (req.userName) {
        query.q += ' AND u.username = @userName';
        query.qp.userName = {
          type: 'NVarChar',
          value: req.userName
        };
      }

      if (req.medseekId) {
        query.q += ' AND i.medseekId = @medseekId';
        query.qp.medseekId = {
          type: 'NVarChar',
          value: req.medseekId,
          length: req.medseekId.length
        };
      }

      if (req.mrn) {
        query.qp.mrn = {
          type: 'NVarChar',
          value: req.mrn,
          length: req.mrn.length
        };
      }

      if (req.ssn) {
        query.q += ' AND pd.SocialSecurityNumber like (\'%\' +  @ssn)';
        query.qp.ssn = {
          type: 'NVarChar',
          value: req.ssn,
          length: req.ssn.length
        };
      }

      if (req.dateOfBirth) {
        query.q += ' AND pd.DateOfBirth = @dateOfBirth';
        query.qp.dateOfBirth = {
          type: 'NVarChar',
          value: req.dateOfBirth,
          length: req.dateOfBirth.length
        };
      }

      if (req.pin) {
        query.q += ' AND i.pin like \'\' + @pin + \'%\'';
        query.qp.pin = {
          type: 'NVarChar',
          value: req.pin,
          length: req.pin.length
        };
      }

      if (req.emailAddress) {
        query.q += ' AND i.email like \'%\' + @emailAddress +  \'%\'';
        query.qp.emailAddress = {
          type: 'NVarChar',
          value: req.emailAddress,
          length: req.emailAddress.length
        };
      }

      if (req.invitationStatus) {
        if( req.invitationStatus === '100'){
          query.q += ' AND (i.status = 100  OR i.status = 103)';
        }
        else if(req.invitationStatus === '108'){ //GetLocked invitation
          query.q += ' AND i.remainingAttempts < 1';
        }
        else{
          query.q += ' AND i.status = @invitationStatus';
        }
         query.qp.invitationStatus = {
            type: 'Int',
            value: req.invitationStatus,
            length: req.invitationStatus.length
          };

      }

      if (req.gender) {
        var genderName;
        switch (req.gender) {
          case '1':
            genderName = 'Unknown';
            break;
          case '2':
            genderName = 'Male';
            break;
          case '3':
            genderName = 'Female';
            break;
        }

        query.q += ' AND pd.sex = @gender';
        query.qp.gender = {
          type: 'NVarChar',
          value: genderName,
          length: genderName.length
        };
      }

      if (req.portalId) {
        query.q += ' AND i.portalId = @portalId';
        query.qp.portalId = {
          type: 'Int',
          value: req.portalId,
          length: req.portalId.length
        };
      }

      if (req.portalRole) {
        query.q += ' AND i.PortalRole = @portalRole';
        query.qp.portalRole = {
          type: 'NVarChar',
          value: req.portalRole,
          length: req.portalRole.length
        };
      }

      if (req.accessLevel) {
        query.q +=  ' AND i.AccessLevelId = @accessLevel';
        query.qp.accessLevel = {
          type: 'Int',
          value: req.accessLevel,
        };
      }

      if (req.isInvitedByStaff) {
        query.q += ' AND i.IsInvitedByStaff = @isInvitedByStaff';
        query.qp.isInvitedByStaff = {
          type: 'Int',
          value: req.isInvitedByStaff
        };
      }

      if (req.excludeFromMinimumAge) {
        query.q += ' AND i.IsEmancipatedMinor = 1';
      }

      if (req.excludeFromAOM) {
        query.q += ' AND i.status = 103';
      }

      if (req.lastUpdatedFrom && req.lastUpdatedTo) {
        var updatedTo = moment(req.lastUpdatedTo).add(1,'days').format('YYYY-MM-DD');
        query.q += ' AND i.StatusUpdatedDateTime between @lastUpdatedFrom AND @lastUpdatedTo';
        query.qp.lastUpdatedFrom = {
          type: 'NVarChar',
          value: req.lastUpdatedFrom,
          length: req.lastUpdatedFrom.length
        };
        query.qp.lastUpdatedTo = {
          type: 'NVarChar',
          value: updatedTo,
          length: updatedTo.length
        };
      } else if (req.lastUpdatedFrom) {
        query.q += ' AND i.StatusUpdatedDateTime >= @lastUpdatedFrom';
        query.qp.lastUpdatedFrom = {
          type: 'NVarChar',
          value: req.lastUpdatedFrom,
          length: req.lastUpdatedFrom.length
        };
      }
      else if (req.lastUpdatedTo) {
        var updatedToOnly = moment(req.lastUpdatedTo).add(1,'days').format('YYYY-MM-DD');
        query.q += ' AND i.StatusUpdatedDateTime <= @lastUpdatedTo';
        query.qp.lastUpdatedTo = {
          type: 'NVarChar',
          value: updatedToOnly,
          length: updatedToOnly.length
        };
      }

      if (req.dateCreatedFrom && req.dateCreatedTo) {
        var toDate = moment(req.dateCreatedTo).add(1,'days').format('YYYY-MM-DD');
        query.q += ' AND i.InvitationDate between @dateCreatedFrom AND @dateCreatedTo';
        query.qp.dateCreatedFrom = {
          type: 'NVarChar',
          value: req.dateCreatedFrom,
          length: req.dateCreatedFrom.length
        };
        query.qp.dateCreatedTo = {
          type: 'NVarChar',
          value: toDate,
          length: toDate.length
        };
      }
      else if (req.dateCreatedFrom) {
        query.q += ' AND i.InvitationDate >= @dateCreatedFrom';
        query.qp.dateCreatedFrom = {
          type: 'NVarChar',
          value: req.dateCreatedFrom,
          length: req.dateCreatedFrom.length
        };
      }
      else if (req.dateCreatedTo) {
        var createdToOnly = moment(req.dateCreatedTo).add(1,'days').format('YYYY-MM-DD');
        query.q += ' AND i.InvitationDate <= @dateCreatedTo';
        query.qp.dateCreatedTo = {
          type: 'NVarChar',
          value: createdToOnly,
          length: createdToOnly.length
        };
      }

      //Patient First name
       if (req.firstName) {
        query.q += ' AND i.FirstName like \'\' + @FirstName + \'%\'';
        query.qp.firstName = {
          type: 'NVarChar',
          value: req.firstName,
          length: req.firstName.length
        };
      }


      //Patient last name
       if (req.lastName) {
        query.q += ' AND i.LastName like \'\' + @LastName + \'%\'';
        query.qp.lastName = {
          type: 'NVarChar',
          value: req.lastName,
          length: req.lastName.length
        };
      }

      //User First name
       if (req.userfirstName) {
        query.q += ' AND i.UserFirstName like \'\' + @userfirstName + \'%\'';
        query.qp.userfirstName = {
          type: 'NVarChar',
          value: req.userfirstName,
          length: req.userfirstName.length
        };
      }

      //User Last Name
       if (req.userlastName) {
        query.q += ' AND i.UserLastName like \'\' + @userlastName + \'%\'';
        query.qp.userlastName = {
          type: 'NVarChar',
          value: req.userlastName,
          length: req.userlastName.length
        };
      }

     //Paging
      if (req.pageSize) {
        query.q = 'WITH Results AS (' + getUnique(query.q) + ') SELECT * FROM Results WHERE rowNum BETWEEN (@pageNumber - 1) * @pageSize AND @pageNumber * @pageSize';
        query.qp.pageSize = {
          type: 'Int',
          value: req.pageSize
        };

        query.qp.pageNumber = {
          type: 'Int',
          value: req.pageNumber || 1
        };
      }

      log.debug('buildQuery', query);
      return query;
  }
  module.exports.buildQuery = buildQuery;

  function getUnique(q){
    return q + '          group by \n' +
    '          i.[InvitationDate], \n' +
    '          i.[userId],  \n' +
    '          i.[id],  \n' +
    '          i.[pin], \n' +
    '          i.[medseekId], \n' +
    '          i.[expirationDate],  \n' +
    '          i.[relationshipClassification] , \n' +
    '          i.status, \n' +
    '          i.[statusUpdatedDateTime],  \n' +
    '          i.[email],  \n' +
    '          i.[remainingAttempts],  \n' +
    '          i.[lastName],  \n' +
    '          i.[firstName],  \n' +
    '          i.[invitationDate],  \n' +
    '          i.[portalRole],  \n' +
    '          i.[middleName],  \n' +
    '          i.[isEmancipatedMinor],  \n' +
    '          i.[portalId],  \n' +
    '          i.[accessLevelId],  \n' +
    '          i.[userFirstName],  \n' +
    '          i.[userLastName],  \n' +
    '          pd.PatientName_GivenName,  \n' +
    '          pd.PatientName_FamilyName,  \n' +
    '          i.[language],   \n' +
    '          i.[statusUpdatedBy],   \n' +
    '          i.[version],  \n' +
    '          u.[gender] , \n' +
    '          a.[name] , \n' +
    '          p.[name], \n' +
    '          r.[name], \n' +
    '          pd.sex';
  }

  function submitSql(q,pgId){
    log.trace('query q.q', q.q);
    return microservices.call('empower.v6.portal-groups.mssql.query.pg-' + pgId, q)
      .tap(function(results) {
        log.trace('get| query results', util.inspect(results, {
          colors: true,
          depth: null
        }));
      });
  }

  function submitQuery(q, mc, pgId) {
    return submitSql(q,pgId)
    .tap(function(results){
      log.debug('submitQuery| results',results);
    })
    .then(parseForError)
    .then(function(results) {
      return _.map(results,function(result){
        result.preloadedPhysicians = result.preloadedPhysicians ? JSON.parse(result.preloadedPhysicians) : [];
        result.preloadedLocations = result.preloadedLocations ? JSON.parse(result.preloadedLocations) : [];
        return result;
      });
    });
  }

  function parseForError(results){
    if(results.error){
      log.error(results.error);
      return { error: 'Error from Empower-Invitations Microservice: ' + results.error };
    }
    return results;
  }

  function toMssqlConfig(uri) {
    var parsed = url.parse(uri, true);
    if (parsed.protocol !== 'mssql:')
        throw new Error('Unsupported protocol: ' + parsed.protocol);
    var authParts =  parsed.auth ? _.compact(parsed.auth.split(':')) : [];
    var hostParts = _.compact(parsed.host.split(':'));
    var pathParts = _.compact(parsed.pathname.split('/'));
    var config = {
        server: parsed.hostname,
        port: hostParts.length > 1 ? hostParts[1] : undefined,
        user: parsed.auth && parsed.auth.length > 0 ? authParts[0] : undefined,
        password: parsed.auth && parsed.auth.length > 1 ? authParts[1] : undefined,
        database: _.first(pathParts),
        options: parsed.query
    };
    if (pathParts.length > 1) {
        config.server += '\\' + pathParts[0];
        config.database = pathParts[1];
    }
    _.forEach(parsed.query, function(x, k, o) {
        var s = ('' + x).toLowerCase();
        if (s === 'true' || s === 'false') {
            o[k] = s === 'true';
        }
    });
    _.defaults(config, (db || {}).config);
    log.debug('toMssqlConfig| uri: %s, config:', uri, config);
    return config;
  }

  function computeStatus(records) {

    records.forEach(function(record) {
      record.statusCode = record.status;
      switch (record.status) {
        case 'Expired':
          record.status = util.format('Expired (%s)', (record.statusUpdatedBy || 'Auto'));
          break;
        case 'PendingExcludedFromAgeOfMajority':
          record.status = 'Pending';
          break;
        case 'ResendByStaff': 
          record.status = util.format('Expired (%s)', (record.statusUpdatedBy || 'Staff'));
          record.statusCode = 'Expired';
      }

      if (record.remainingAttempts < 1) {
        record.status = 'Locked';
      }
    });
    return records;
  }
  return services;
});
