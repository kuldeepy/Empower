'use strict';
var path = require('path');
var chai = require('chai');
chai.use(require('chai-as-promised'));
chai.use(require('sinon-chai'));
var expect = chai.expect;

var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var _ = require('lodash');
var util = require('util');
var moment = require('moment');

describe('empower-invitations.js',function(){
  var invitations,mockMs,mockLog,mockMicroservices,options,mockLogger;
  beforeEach(function(){
    mockMs = sinon.stub();
    mockLog = sinon.stub({
      debug: function(){},
      error: function(){},
      trace: function(){}
    });
    mockLogger = {
      getLogger: function(){
        return mockLog;
      }
    };
    mockMicroservices = sinon.stub({
      bind: function(){},
      call: function(){}
    });
    options = {};
    mockMs.yields(undefined,mockLogger,mockMicroservices,Promise,options,require('url'),_,moment,util);
    invitations = proxyquire.noCallThru()('../empower-invitations',{
      'ih-microservice': mockMs
    });

  });
  describe('buildQuery',function(){
    var request;
    beforeEach(function(){
      request = {
        ssn: '1010'
      };
    });
    it('should add a query of ssn like if request contains a ssn property',function(){
      var q = invitations.buildQuery(request,'abc');
      expect(q.q).to.contain('AND pd.SocialSecurityNumber like (\'%\' +  @ssn)');
    });
    it('should not contain SocialSecurityNumber when request does not contain a ssn property',function(){
      delete request.ssn;
      var q = invitations.buildQuery(request,'abc');
      expect(q.q).to.not.contain('AND pd.SocialSecurityNumber like (\'%\' +  @ssn)');
    });
    it('should add a query of ssn like if request contains a ssn property',function(){
      var q = invitations.buildQuery(request,'abc');
      expect(q.q).to.contain('WHEN 105 THEN \'ResendByStaff');
    });
  });
});
