'use strict';


var crutch = require('ih-microservice');

var defaults = {
    id: 'medseek.empower.rules-engine',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'medseek.empower.rules-engine',
    defaultReturnBody: true,
    communicateDb: 'MedseekIntegration60',
    pageSize: '20'
};

var util = require('./app/util/nools-utility');
var dataStore = require('./app/util/dataStore');
var engine = require('./app/engine');



module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, Promise) {
	engine.setLogger(logging);
	util.setLogger(logging);

var log = logging.getLogger('empower-rules-engine');
return Promise.all([microservices.bind('medseek.platform.engine.rules.get.#',get),
					microservices.bind('medseek.platform.engine.rules.set.#',set),
					microservices.bind('medseek.platform.engine.rules.evaluate.#',evaluate)]);


function get(req,mc) {
	var id = (req.id || (typeof req === 'string' ? req : '')).replace(/\"/g,'');
	return dataStore.find(id,microservices,mc,log).then(function(rule){
		if(!rule.source){
			rule = _.map(rule, function(rl){
				rl.source._id = rl._id;
				return rl.source;
			});
			log.debug('get| returning rule',rule);
			return rule;
		} else {
			rule.source._id = rule._id;
			rule = rule.source;
			var results = [rule];
			log.debug('get| returning rule results',results);
			return results;
		}
	
	});
}

function set(req,mc){
	
	return Promise.try(function(){

		log.debug('set| rule req',req);
		var rule = util.generateNool(req);

		if(req._id){
			
			var ruleId = req._id;
			delete req._id;				
			return dataStore.update(rule, ruleId,microservices,mc,log).then(returnId);
		
		} else {
			
			rule = util.generateNool(req);
			return dataStore.save(rule,microservices,mc,log).then().then(returnId);
		
		}
	});
}

function returnId(id){
	return { ruleId: id };
}

function evaluate(req,mc) {
	var user = req.user;
	var ids = req.rules;
	
	log.info(' evaluating req: ',req);
	
	if(!ids || !user){
		log.info('returning empty array');
		return Promise.resolve([]);
	}
	
	log.info(' ids: ',ids);
	log.info(' user: ',user);
	
	return Promise.map(ids,function(id){
		var info = {
			user: user,
			ruleId: id
		};
		return engine.evalUser(info,microservices,mc);
	})
	.then(function(result) {
		log.info('evaluation result:', result);
		return result;
	}).catch(function(e) {
		log.info('rule evaluation error:',e.message);
		log.info('error stack:',e.stack);
		throw e;
	});

}

});