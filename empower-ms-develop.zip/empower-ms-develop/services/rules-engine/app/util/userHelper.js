'use strict';
/* jshint ignore:start */
var redisClient;
var q = require('q');
/* jshint ignore:end */
var _ = require('lodash');
var models = {};
var modelK = {};
var log = require('log4js').getLogger('user mapper');
var keys = [];

_.transform(require('./helpers').getModels(),function(result,model){
	keys.push(model.key);
	modelK[model.key] = model.model;
	models[model.name] = model.model;
});

module.exports.buildUser = function(usr){
	var user = new models.User(usr);
	user.patients = _.map(usr.patients, function(patient){
		var p = new models.Patient(patient);
		p.clinical = new models.Clinical(patient);
		keys.forEach(function(k){
			if(patient[k]){
				if(k === 'testResults') {
					var mapped = _.map(patient[k], function(test){
						if(test.id){
							var componentChildren = _.filter(patient[k],{testResultId: test.id});
							var m = new modelK[k](test);
							componentChildren.forEach(function(child){
								m[child.component] = child.value;
							});
							return m;
						}
					});
					p.clinical[k] = _.compact(mapped);
				} else
					p.clinical[k] = _.map(patient[k], function(component){
						return new modelK[k](component);
					});
			}
		});
		// p.physicians = _.map(patient.physicians, function(doc){
		// 	return new models.Physician(doc);
		// });
		// p.locations = _.map(patient.locations, function(location){
		// 	return new models.Location(location);
		// });
		log.trace('patient mapped',p);
		return p;
	});
	log.debug('user patients',user.patients);
	user.addresses = _.map(usr.addresses, function(address){
		return new models.Address(address);
	});
	user.hasBeenBuilt = true;
	return user;
};

module.exports.setLogger = function(l){
	log = l.getLogger('user-helper');
};