'use strict';
var _ = require('lodash');
var util = require('./helpers');
var u = require('util');
var models;
var log;
var groupIndex;

var generateResultPipeline = module.exports.generateResultPipeline = function(grp, targets, index,loc){
	targets = targets || [];
	index = index || 0;
	loc = loc || [0];
	var pipeline = [];
	var groupLength = grp.rules.length;
	grp.rules.forEach(function(rule,idx){
		if(!rule.enabled && rule.rules){
			pipeline.push((groupLength === 1) ? true : false);
			return;
		}
		if(rule.rules){
			log.debug('recursion',rule, targets, idx, index)
			pipeline.push(generateResultPipeline(rule, targets, idx, index));
		}
		else if (rule.type === 'RuleGroup'){
			pipeline.push({ruleGroup: rule.value});
			loc.push(idx);
			targets.push(loc);
		}
		else{
			pipeline.push(rule.operatorType ? rule.operatorType : false);
		}
	});
	log.trace('pipeline',pipeline);
	return pipeline;
};

var parseTypePrefix = function(type){
	switch(type){
		case 'Number':
			return { prefix: 'float(', suffix:')' };
		case 'Date':
			return { prefix: 'date(', suffix: ')' };
		case 'Patient':
			return { prefix: 'log(', suffics: ')' };
		default:
			return { prefix:'', suffix:'' };
	}
};

var parseOperator = function(operator){
	switch (operator){
		case 'equals':
			return '===';
		case 'is not equal to':
			return '!==';
		case 'is greater than':
			return '>';
		case 'is less than':
			return '<';
		case 'is greater than/equal to':
			return '>=';
		case 'is less than/equal to':
			return '<=';
		case 'contains':
			return '=~';
		default:
			return '!=~';
	}
	return operator;
};

var parseValue = function(value, type, operator){
	var rsp = '';
	switch (type){
		case 'String':
			var isRegex = (parseOperator(operator).indexOf('~') > -1);
			var wrapper = (isRegex) ? '/' : '\'';
			var flag = (isRegex) ? 'i' : '';
			value = (typeof value === 'string') ? value.toLowerCase() : value;
			rsp =  wrapper + value + wrapper + flag;
			break;
		case 'Date':
			rsp = 'date(\'' + value + '\')';
			break;
		default:
			rsp = value;
			break;
	}
	return rsp;
};

var getTypeMethod = function(type){
	var val = '';
	switch (type){
		case 'String':
			val =  '.toLowerCase() ';
			break;
		default:
			val = ' ';
			break;
	}
	return val;
};

var parseGenericLine = function(prop, previousProperty, nextProperty, rule){
	var rsp, op, targetType;
	if(!nextProperty){
		log.debug('rule Type',rule.type)
		op = parseTypePrefix(rule.type);		
		if(rule.target.indexOf('testResults') > 0) {
			rsp = prop + ' : ' + rule.type + ' ' + prop + ' ' + parseOperator(rule.operator) + ' ' + parseValue(rule.value, rule.type, rule.operator) + ' from ' + op.prefix + 'testResultsItem.' + prop + op.suffix + ';\n';
			return rsp;
		}
		if(isTargetAnArray(rule.target)) {
			targetType = getTargetType(rule.target);
			if (rule.operator === 'is not equal to')
				rsp = 'not(' + prop + ' : ' + rule.type + ' ' + prop + ' ' + parseOperator('equals') + ' ' + parseValue(rule.value, rule.type, rule.operator) + ' from ' + targetType + ');\n';
			else
				rsp = prop + ' : ' + rule.type + ' ' + prop + ' ' + parseOperator(rule.operator) + ' ' + parseValue(rule.value, rule.type, rule.operator) + ' from ' + targetType + ';\n';
			return rsp;
		}
		rsp = prop + ' : ' + rule.type + ' ' + prop + getTypeMethod(rule.type) + parseOperator(rule.operator) + ' ' + parseValue(rule.value, rule.type, rule.operator) + ' from ' + op.prefix + previousProperty + 'Item.' + prop + op.suffix + ';\n';
	} else {
		if(isTargetAnArray(rule.target)) {
			rsp = prop + 'Item: Number from ' + previousProperty + 'Item.' + prop + ';';
		}
		else
			rsp = 'name : String name  == \'' + prop + '\'  from ' + previousProperty + 'Item.name;';
	}
	return rsp;
};


var parseLine = function(prop, previousProperty, nextProperty, rule){
	prop = prop.replace(/ /g,' ');
	if(previousProperty){
		previousProperty = previousProperty.replace(/ /g,' ');
	}
	var rsp = '\t\t';
	
	var found = _.find(models, {key: prop});
	
	if(previousProperty === 'clinical' && !found){
		throw new Error(u.format('Invalid clinical component [%s]',prop));
	}

	if(found){
		rsp = rsp + prop + 'Item: ' + found.name + ' ' + prop + 'Item';
		if(previousProperty)
			rsp = rsp + ' from ' + previousProperty + 'Item.' + found.key;

		return rsp + ';';
	}

	return rsp + parseGenericLine(prop, previousProperty, nextProperty, rule);
};

var parseRules = function (group,groupIndex){
	group.index =  [groupIndex];
	var nulRul = '';
	group.rules.forEach(function(rule, index){
		var idx = _.clone(group.index);
		if(rule.operatorType){
		} else if(rule.rules && rule.enabled){
			log.debug('group.index',group.index)
			idx.push(index);
			nulRul = nulRul + parseRules(rule, [idx]);
		} else if(rule.type !== 'RuleGroup' && rule.type !== undefined) {
			log.trace('rule',rule);
			var id = [group.index , index];
			nulRul = nulRul + 'rule \'' + id + '\' {\n\twhen{\n';
			var parts = rule.target.split('.');
			var prop = parts.shift(), previousProperty;
			while(prop){
				var line = parseLine(prop, previousProperty, parts[0], rule);
				nulRul = nulRul + line;
				previousProperty = prop;
				prop = parts.shift();
				if(prop){
					nulRul = nulRul + '\n';
				}
			}
			var identifier = '';
			_.flatten(id).forEach(function(i) {
				identifier += '[' + i + ']';
			});
			nulRul = nulRul + '\t}\n\tthen{';
			nulRul = nulRul + '\n\t\treporter' + identifier + ' = true;\n\t}\n}\n\n';
			log.debug('identifier',identifier)
		}
	});
	log.debug('nulRul',nulRul);
	return nulRul;
};

module.exports.generateNool = function(ruleGroup){
	models = util.getModels();
	var nule = '';
	ruleGroup.rules.forEach(function(g,v){
		groupIndex = [v];
		if(g.enabled)
			nule = nule + parseRules(g, v);
	});
	log.debug('generated nools',nule);
	var targets = [];
	var pipeLine = generateResultPipeline(ruleGroup,targets);
	var meta = {
		nools: nule,
		source: ruleGroup,
		pipeLine: pipeLine,
		targets: targets
	};
	return meta;
};

function isTargetAnArray(target) {
	return (target.indexOf('roles') > 0 || target.indexOf('locations.id') > 0 || target.indexOf('physicians.id') > 0);
}

function getTargetType(target) {
	var targetType;
	if (target.indexOf('roles') > 0)
		targetType = 'userItem.roles';
	else if (target.indexOf('locations.id') > 0)
		targetType = 'patientsItem.locations';
	else
		targetType = 'patientsItem.physicians';
	return targetType;
}
module.exports.setLogger = function(l){
	log = l.getLogger('nools-utility');
}