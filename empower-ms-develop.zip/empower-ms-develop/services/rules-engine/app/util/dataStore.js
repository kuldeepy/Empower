'use strict';

var config = require('medseek-config'), db, Rule;
var q = require('q');
var redisClient;
var _ = require('lodash');
var noolsUtility = require('./../engine');
var redisConfig = config.get('redis') || {};

function getRedisClient(){
    if(redisClient){
        return redisClient;
    }
    redisClient = require('redis').createClient(redisConfig.port, config.get('redis:host'), redisConfig);
    return redisClient 
}

function setCacheEntity(key, value, timeout) {
    var transaction = getRedisClient().multi();
    transaction.set(key, JSON.stringify(value));
    transaction.expire(key, timeout || (5 * 60));
    q.ninvoke(transaction, 'exec')
        .catch(function(errors) {
            throw errors[0];
        })
        .done();
}

function getPortalGroupId(messageContext) {
	return _.last(messageContext.routingKey.split('.'));
}

function query(q,microService,messageContext) {

	return microService.call('empower.v6.portal-groups.mssql.query.pg-' + getPortalGroupId(messageContext), q)
	    .then(function(results) {
	        return results;
	    });
};

function createRule(req,microService,messageContext) {
    var qString = ' insert Rules(ruleValue) \n'+
    			  ' values(@ruleValue); \n'+
    			  ' select SCOPE_IDENTITY() as _id;';
    
    var queryObject = {
        q: qString,
        qp: {
            ruleValue: {
                value: JSON.stringify(req)
            }
        }
    };

    return query(queryObject,microService,messageContext).then(function(queryResult) {
        return queryResult[0]._id;
    });
};

module.exports.save = function(rule,microService,messageContext,log){
	log.debug('saving rule',rule);
    return createRule(rule,microService,messageContext)
    .then(
        function(resultId)
        {
            var portalGroup = getPortalGroupId(messageContext);
            setCacheEntity(portalGroup + '.medseek.microservices.rules.cache.' + resultId, rule, 86400);
            return resultId
        });
};

function findRule(id,microService,messageContext){
  	var qString = ' select id as _id, ruleValue from Rules \n'

  	if(id){
  		qString += ' where id = @ruleId';
  	}

    var queryObject = {
        q: qString,
        qp: {
            ruleId: {
                value: id
            }
        }
    };

    return query(queryObject,microService,messageContext).then(function(queryResult) {
        return queryResult;
    });
}

module.exports.find = function(id,microService,messageContext) {
    var redisClientInstance = getRedisClient();
    var key = getPortalGroupId(messageContext) + '.medseek.microservices.rules.cache.';
	return q.ninvoke(redisClientInstance, 'get', key + id)
    .then(function(cacheResult){

        if(cacheResult){
            return JSON.parse(cacheResult);
        }

        return findRule(id,microService,messageContext).then(function(queryResult){

    		if(queryResult.length === 1){
    			var actualValue = queryResult;
    			var returnValue = JSON.parse(actualValue[0].ruleValue);
    			returnValue._id = actualValue[0]._id;
                setCacheEntity(key + returnValue._id, returnValue, 86400);

    			return returnValue;
    		}else{
    			var resultArray = [];
    			queryResult.forEach(function(result){
    				var actualValue = result;
    				var returnValue = JSON.parse(actualValue.ruleValue);
    				returnValue._id = actualValue._id;
    				resultArray.push(returnValue);
    			});
    			return resultArray;
    		}

	    });

    });
};

function updateRule(rule, id, microService,messageContext){
    var redisClientInstance = getRedisClient();
    var key = getPortalGroupId(messageContext) + '.medseek.microservices.rules.cache.';
    q.ninvoke(redisClientInstance, 'del', key + id);

	var qString = ' update Rules \n'
				+' set ruleValue = @ruleValue \n'
   				+ ' where id = @ruleId; \n'
   				+ ' select @ruleId as _id;';

    var queryObject = {
        q: qString,
        qp: {
            ruleId: {
                value: id
            },
            ruleValue :{
            	value: JSON.stringify(rule)
            }
        }
    };
    noolsUtility.flowStore.deleteFlow(id);
    return query(queryObject,microService,messageContext).then(function(queryResult) {
        return queryResult[0]._id;
    });
}

module.exports.update = function(rule, id,microService,messageContext) {
	return updateRule(rule,id,microService,messageContext);
};


