'use strict';

var helper = require('../util/helpers');
var _ = require('lodash');
var log;
/* Patient */
module.exports = {
	model: function Patient(patient){
		log.debug('Patient',patient);
		this.dateOfBirth = patient.DateOfBirth;
		this.gender = patient.Gender === 3 ? 'Female' : 'Male';
		this.age = patient.DateOfBirth ? helper.getAge(patient.DateOfBirth) : 0;
		this.city = patient.City;
		this.state = patient.State;
		this.postalCode = patient.ZipCode;
		this.locations = patient.locations && patient.locations.length ? _.pluck(patient.locations, 'id') : [];
		this.physicians = patient.physicians && patient.physicians.length ? _.pluck(patient.physicians, 'id') : [];		
	},
	name: 'Patient',
	key: 'patients',
  setLogger: function(l){
    log = l.getLogger('patient');
  }
};