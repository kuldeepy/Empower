'use strict';
var log;

/* Clinical */
module.exports = {
	model: function Clinical(patient){
		this.allergies = patient.allergies || [];
		this.bloodGlucoses = patient.bloodGlucoses || [];
		this.bloodPressures = patient.bloodPressures || [];
		this.cholesterols = patient.cholesterols || [];
		this.growthCharts = patient.growthCharts || [];
		this.immunizations = patient.immunizations || [];
		this.medications = patient.medications || [];
		this.problems = patient.problems || [];
		this.procedures = patient.procedures || [];
		this.socialHistories = patient.socialHistories || [];
		this.testResults = patient.testResults || [];
		this.weights = patient.weights || [];
	},
	name: 'Clinical',
	key: 'clinical',
  setLogger: function(l){
    log = l.getLogger('clinical');
  }
};