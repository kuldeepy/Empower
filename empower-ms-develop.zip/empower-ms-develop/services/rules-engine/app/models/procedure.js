'use strict';
var log;

/* Procedure */
module.exports = {
	model: function Procedure(procedure){
		this.name = procedure.name;
		this.date = procedure.date;
		this.clinician = procedure.clinician;
		this.location = procedure.location;
	},
	name: 'Procedure',
	key: 'procedures',
  setLogger: function(l){
    log = l.getLogger('procedure');
  }
};