'use strict';
var log;

/* Allergy */
module.exports = {
	model: function Allergy(allergy){
		this.name = allergy.name;
		this.type = allergy.type;
		this.allergyReactions = allergy.allergyReactions;
	},
	name: 'Allergy',
	key: 'allergies',
  setLogger: function(l){
    log = l.getLogger('allergy');
  }
};