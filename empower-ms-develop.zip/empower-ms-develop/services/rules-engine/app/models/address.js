'use strict';
var log;

/* Address */
module.exports = {
	model: function Address(address){
		this.city = address.City;
		this.state = address.State;
		this.postalCode = address.ZipCode;
	},
	name: 'Address',
	key: 'addresses',
  setLogger: function(l){
    log = l.getLogger('address');
  }
};