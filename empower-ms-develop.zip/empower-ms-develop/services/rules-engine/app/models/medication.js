'use strict';
var log;

/* Medication */
module.exports = {
	model: function Medication(med){
		this.name = med.name;
		this.reaction = med.reaction;
		this.dateStarted = med.dateStarted;
		this.dosage = med.dosage;
		this.prescribedBy = med.prescribedBy;
		this.quantity = med.quantity;
		this.frequency = med.frequency;
		this.route = med.route;
		this.strength = med.strength;
	},
	name: 'Medication',
	key: 'medications',
  setLogger: function(l){
    log = l.getLogger('medication');
  }
};