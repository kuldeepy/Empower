'use strict';
var log;

/* Immunization */
module.exports = {
	model: function Immunization(med){
		this.name = med.name;
		this.reaction = med.reaction;
	},
	name: 'Immunization',
	key: 'immunizations',
  setLogger: function(l){
    log = l.getLogger('immunizations');
  }
};