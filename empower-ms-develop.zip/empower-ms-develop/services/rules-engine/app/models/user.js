'use strict';
var log;

var _ = require('lodash');
var helper = require('../util/helpers');
/* User */
module.exports = {
	model: function User(user){
		this.firstName = user.firstName;
		this.lastName = user.lastName;
		this.dateOfBirth = user.dateOfBirth;
		this.gender = user.gender === 3 ? 'Female' : 'Male';
		this.age = user.dateOfBirth ? helper.getAge(user.dateOfBirth) : 0;
		this.roles = user.roles && user.roles.length ? _.pluck(user.roles, 'id') : [];
		this.patients = [];
	},
	name: 'User',
	key: 'user',
  setLogger: function(l){
    log = l.getLogger('user');
  }
};
