'use strict';
var log;

/* Family History */
module.exports = {
	model: function FamilyHistory(history){
		this.condition = history.condition;
		this.relationship = history.relationship;
		this.onsetdate = history.onsetdate;
	},
	name: 'FamilyHistory',
	key: 'familyHistories',
  setLogger: function(l){
    log = l.getLogger('family-history');
  }
};