'use strict';
var log;

/* Medication */
module.exports = {
  model: function Weights(w){
    this.height = w.heightvalue;
    this.weight = w.weightvalue;
  },
  name: 'Weights',
  key: 'weights',
  setLogger: function(l){
    log = l.getLogger('weights');
  }
};