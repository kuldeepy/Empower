'use strict';
var log;

/* Cholesterol */
module.exports = {
  model: function Cholesterols(c){
    this.ldl = c.ldl;
    this.hdl = c.hdl;
    this.level = c.level;
    this.tryglicerides = c.tryglicerides;
  },
  name: 'Cholesterols',
  key: 'cholesterols',
  setLogger: function(l){
    log = l.getLogger('cholesterol');
  }
};