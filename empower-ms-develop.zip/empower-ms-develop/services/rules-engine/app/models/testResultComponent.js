'use strict';
var log;

/* Test Result Subrecords */
module.exports = {
	model: function TestResultComponent(subRecord){
		this.component = subRecord.component;
		this.value = subRecord.value;
	},
	name: 'TestResultComponent',
	key: 'subRecords',
  setLogger: function(l){
    log = l.getLogger('test-results');
  }
};

