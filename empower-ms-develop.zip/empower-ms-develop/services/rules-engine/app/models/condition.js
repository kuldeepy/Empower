'use strict';
var log;

/* Condition */
module.exports = {
	model: function Condition(problem){
		this.name = problem.name;
		this.date = problem.date;
	},
	name: 'Condition',
	key: 'problems',
  setLogger: function(l){
    log = l.getLogger('condition');
  }
};