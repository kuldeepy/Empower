'use strict';
var log;

/* Blood Pressure */
module.exports = {
	model: function BloodPressure(bp){
		log.debug(bp);
    this.systolic = bp.systolic;
		this.diastolic = bp.diastolic;
		this.pulse = bp.pulse;
	},
	name: 'BloodPressure',
	key: 'bloodPressures',
  setLogger: function(l){
    log = l.getLogger('blood-pressure');
  }
};