'use strict';
var log;

/* Blood Glucose */
module.exports = {
	model: function BloodGlucose(bg){
		this.glucose = bg.glucose;
	},
	name: 'BloodGlucose',
	key: 'bloodGlucoses',
  setLogger: function(l){
    log = l.getLogger('blood-glucose');
  }
};