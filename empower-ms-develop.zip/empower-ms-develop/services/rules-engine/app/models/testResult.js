'use strict';
var log;

/* Test Result */
module.exports = {
	model: function TestResult(test){
		this.name = test.name;
		this.components = [];
	},
	name: 'TestResult',
	key: 'testResults',
  setLogger: function(l){
    log = l.getLogger('test-result');
  }
};

