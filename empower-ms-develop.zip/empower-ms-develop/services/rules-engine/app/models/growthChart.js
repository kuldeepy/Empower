'use strict';
var log;

/* Growth Chart */
module.exports = {
	model: function GrowthChart(chart){
		this.heightvalue = chart.heightvalue;
		this.height = chart.height;
	},
	name: 'GrowthChart',
	key: 'growthCharts',
  setLogger: function(l){
    log = l.getLogger('growth-chart');
  }
};