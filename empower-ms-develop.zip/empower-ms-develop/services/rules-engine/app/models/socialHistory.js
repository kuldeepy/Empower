'use strict';
var log;

/* Social History */
module.exports = {
	model: function SocialHistory(his){
		this.type = his.type;
		this.yearStarted = his.yearStarted;
		this.yearStopped = his.yearStopped;
		this.frequency = his.frequency;
		this.amount = his.amount;
	},
	name: 'SocialHistory',
	key: 'socialHistories',
  setLogger: function(l){
    log = l.getLogger('social-history');
  }
};