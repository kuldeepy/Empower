'use strict';

var nools = require('nools');
var dataStore = require('./util/dataStore');
var fs = require('fs');
var defined;
var userHelper = require('./util/userHelper');
var log;
var Promise = require('bluebird');
var _ = require('lodash');
var EventEmitter = require('events').EventEmitter;
var ee = new EventEmitter();


function getDefined(l) {
	if (defined) {
		return defined;
	}

	defined = {};
	var files = fs.readdirSync(__dirname + '/models');
	files.forEach(function(f) {
		var model = require('./models/' + f);
		model.setLogger(l);
		defined[model.name] = model.model;
	});
	return defined;
}

exports.replaceNullWithEmpty = function(user){
	_.each(user, function(value, key){
			if (value === null) {
				user[key] = '';
			}

			else if (Object.prototype.toString.call(value) === '[object Object]') {
				exports.replaceNullWithEmpty(value);
			}
			else if (_.isArray(value)) {
				_.each(value, function (v,k) { exports.replaceNullWithEmpty(v); });
			}
		});
	return user;

};

var flowStore = module.exports.flowStore = (function(){
	var store = [];
	
	function deleteFlow(name){
		log.debug('deleting flow',name);
		if(nools.getFlow(name)){
			nools.deleteFlow(name);
		}
	}
	function getFlow(name,meta){
		var flow = nools.getFlow(name);
		if(flow){
			return flow;
		}
		return nools.compile(meta.nools, {
			name: name,
			define: defined,
			scope: {
				reporter: meta.pipeLine,
				date: function(str) {
					return new Date(str);
				},
				float: function(num) {
					log.debug('num', num);
					return parseFloat(num);
				},
				log: function(str) {
					log.error('logging', str);
					return str;
				}
			}
		});
	}
	return {
		getFlow: getFlow,
		deleteFlow: deleteFlow
	};
})();

var evalUser = module.exports.evalUser = function(obj, ms, mc) {
	getDefined();
	log.trace('defined classes', defined);
	return dataStore.find(obj.ruleId, ms, mc, log).then(function(doc) {
		log.trace('found doc', doc);
		var meta = {};
		if (Object.prototype.toString.call(doc) === '[object Array]')
			meta = doc[0];
		else
			meta = doc;

		log.debug('meta', meta);
		var flowName = obj.ruleId;
		var flow = flowStore.getFlow(flowName,meta);
		if(!meta.nools){
			return true;
		}
		/*
			Define a nools flow based on the nools property of the meta object.
			Define the scope functions available to the nools engine: [date,float,log]
		*/
		var noolsStr = meta.nools + ' ';
		log.debug('noolsStr', noolsStr);

		var handleRules = function(user) {
			/*replace the null value with empty*/
			var userData = exports.replaceNullWithEmpty(user);
			
			user = userData;
			
			var session = flow.getSession(user);

			var children = Promise.map(meta.targets, function(target) {
				var item = meta.pipeLine;
				target.forEach(function(t) {
					item = item[t];
				});
				/* Run child tests */
				var childTarget = {
					user: user,
					ruleId: item.ruleGroup
				};
				return evalUser(childTarget).then(function(result) {
					var prop = JSON.stringify(target);
					eval('meta.pipeLine' + prop.replace(',', '][', 'i') + ' = result;'); // jshint ignore:line
					return result;
				});
			});

			session.on('fire', function(name, rule) {
				log.trace('assert| fire:name, fire:rule', name, rule);
			});

			/* Wait for all child tests to return results and report. */
			return Promise.all([session.match(), children]).then(function() {
				log.debug('meta.pipeLine', meta.pipeLine);
				var pipe = JSON.stringify(meta.pipeLine)
					.replace(/,/g, ' ')
					.replace(/"and"/gi, '&&')
					.replace(/"or"/gi, '||')
					.replace(/\[/g, '(')
					.replace(/\]/g, ')');
				var result = eval(pipe);

				log.info(' Rule evaluation result:', meta.pipeLine);
				if (!result) {
					// exports.reportFailures(noolsStr,meta.pipeLine);
					log.info(' Rule evaluated to false for target:', obj.user);
				}

				// clean up to resolve inconsistent behavior
				session.dispose();
				flowStore.deleteFlow(flowName);

				return result;
			}).catch(function(err) {
				log.debug('Rule Exception:', err);
				log.debug('Stack Trace', err.stack);
				return false;
			});
		};

		return obj.user.hasBeenBuilt ?
			handleRules(obj.user) :
			handleRules(userHelper.buildUser(obj.user));
	});

};

exports.matchRule = function(nools, i, j, n) {
	log.debug(i, j,n);
	var idx = i + ',' + j;
	if(typeof n === 'number'){
		idx += ',' + n;
	}
	var exp = 'rule \'' + idx + '\'[\\s\\S]+?(?=rule)';
	var endExp = 'rule \'' + idx + '\'[\\s\\S]+';
	return (new RegExp(exp).exec(nools) || new RegExp(endExp).exec(nools))[0];
};

exports.setLogger = function(l) {
	log = l.getLogger('engine.js');
	userHelper.setLogger(l);
	getDefined(l);
};

exports.reportFailures = function(noolsStr,pipeLine,idx,deepIdx){
	try{
		_.forEach(pipeLine,function(item,i){
			if(typeof item === 'object'){
				exports.reportFailures.call(this,noolsStr,item,i,idx !== undefined ? 0 : idx,deepIdx);
			}
			else if (item === false) {
				var report = [i];
				if(typeof idx === 'number'){
					report.unshift(idx);
				}
				if(typeof deepIdx === 'number'){
					report.unshift(deepIdx);
				}
				log.debug('emiting report-failure',report);
				setTimeout(function(){
					ee.emit('report-failure',noolsStr,report);
				});
			}
		});
	}
	catch(err){
		log.error(err);
	}
};

ee.on('report-failure',function(nools,idx){
	var rule = exports.matchRule(nools,idx[0],idx[1],idx[2]);
	log.debug('report-failure| failed rule:',rule);
});
