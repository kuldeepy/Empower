'use strict';

module.exports = {
	mongo: 'mongodb://localhost',
    mongoPath: '/rules-engine',
	amqp: {
        host: 'localhost',
        vhost: '/',
        'medseek-topic-exchange': 'medseek-api',
        queue: 'medseek.platform.rules.engine',
        broker: 'amqp://guest:guest@localhost'
    },
    redis: {
        host: 'localhost',
        port: 6379,
        cache_times_minutes: {
            patientAttribution: 30
        }
    }
}