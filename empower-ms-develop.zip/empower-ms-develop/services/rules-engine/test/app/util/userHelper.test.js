'use strict';
var patient = require('../../../app/models/patient.js');
var bp = require('../../../app/models/bloodPressure.js');

describe('userHelper', function(){
	var helper, user, mockq, mockRedis;
	
	beforeEach(function(){
		mockq = sinon.stub({
			ninvoke:function(){},
		});
		mockRedis = sinon.stub({
			createClient: function(){}
		});
		mockq.ninvoke.returns(mockPromises.buildImmediatelyResolvedPromise(undefined));
		helper = proxyquire('../../app/util/userHelper', {
			'q': mockq,
			'redis':mockRedis
		});
		var mockLogger = {
			getLogger: function() {
				return {
					debug: function() {},
					error: function() {},
					trace: function() {}
				};
			}
		}
		helper.setLogger(mockLogger);
		patient.setLogger(mockLogger);
		bp.setLogger(mockLogger);
		user = {
			dateOfBirth: '10/12/1977',
			patients: [
				{
					dateOfBirth: '10/12/1977',
					bloodPressures: [
						{
							systolic: '200'
						}
					],
					allergies: [
						{
							name:'Penicillin',
							type: 'Medication',
							allergyReactions: 'Swelling'
						}
					],
					bloodGlucoses: [
						{
							glucose: '220'
						}
					],
					conditions: [
						{
							name: 'Heart palpitations.'
						}
					],
					testResults: [
						{
							'id': '157',
							'documentId': '171',
							'active': 'true',
							'exported': 'false',
							'medseekRecordId': '1b13571e-3d2e-4a54-96c0-b98bac3fe250',
							'name': 'CBC WO DIFFERENTIAL',
							'date': '07/27/2008 02:30 PM',
							'clinician': '',
							'type': '',
							'comments': '',
							'source': 'ExternalDomain:ExternalSystem:ExternalGroup'
						},
						{
							'component': 'HGB',
							'value': '13.2',
							'testResultId': '157'
						},
						{
							'component': 'WBC',
							'value': '6.7',
							'testResultId': '157'
						}
					],
					Id: '22'
				}
			],
			_id: '23'
		};
	});

	describe('buildUser', function(){
		it('should return a built up user.', function(){
			var usr = helper.buildUser(user);
			expect(usr).to.be.an('object');
		});

		it('should return the patients', function(){
			var usr = helper.buildUser(user);
			expect(usr.patients).to.be.an('array');
		});
		it('should return the patients allergies', function(){
			var usr = helper.buildUser(user);
			expect(usr.patients[0].clinical.allergies).to.be.an('array');
			expect(usr.patients[0].clinical.allergies.length).to.equal(1);
		});
		it('should return the patients bloodPressures', function(){
			var usr = helper.buildUser(user);
			expect(usr.patients[0].clinical.bloodPressures).to.be.an('array');
			expect(usr.patients[0].clinical.bloodPressures.length).to.equal(1);
		});
		it('should return the patients bloodGlucoses', function(){
			var usr = helper.buildUser(user);
			expect(usr.patients[0].clinical.bloodGlucoses).to.be.an('array');
			expect(usr.patients[0].clinical.bloodGlucoses.length).to.equal(1);
		});
		it('should return the patients testResults', function(){
			var usr = helper.buildUser(user);
			expect(usr.patients[0].clinical.testResults).to.be.an('array');
			expect(usr.patients[0].clinical.testResults.length).to.equal(1);
		});
	});
});