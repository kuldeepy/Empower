'use strict';
var fs = require('fs');
var nools = require('nools');
var helper = require('../../../app/util/helpers');
var logger = require('log4js'), log = logger.getLogger('utility-test');

function getDefined(){
	var defined = {};
	helper.getModels().forEach(function(model){
		defined[model.name] = model.model;
	});
	return defined;
}

describe('nools-utility', function() {
	var engine, sample, flowName, invalidSample, disabledRule, disabledRuleSingle, multipleClinicalRule;

	beforeEach(function(){
		
		engine = proxyquire('../../app/util/nools-utility',{});
		sample = JSON.parse(fs.readFileSync('./test/samples/rulesSample.json'));
		disabledRule = JSON.parse(fs.readFileSync('./test/samples/disabledRule.json'));
		disabledRuleSingle = JSON.parse(fs.readFileSync('./test/samples/disabledRuleSingle.json'));
		invalidSample = JSON.parse(fs.readFileSync('./test/samples/invalidSample.json'));
		multipleClinicalRule = JSON.parse(fs.readFileSync('./test/samples/multipleNestedRule.json'));
		engine.setLogger(logger);
	});
	afterEach(function(){
		if(flowName){
			nools.deleteFlow(flowName);
		}
		flowName = undefined;
	});
	describe('generateNool', function(){
		it('should generate nools file from ruleGroup', function(){
			var meta = engine.generateNool(sample);
			expect(meta.nools).to.be.a('string');
		});

		it('should throw an error for invalid clinical key',function(){
			function invalidRule(){
				engine.generateNool(invalidSample);
			}
			expect(invalidRule).to.throw()
		})
		it('generated nools rules should compile', function(){
			var meta = engine.generateNool(sample);
			flowName = meta.source.name;
			nools.compile(meta.nools, {
				name: flowName,
				define: getDefined(),
				scope: {
					reporter: meta.pipeLine,
					date: function(str){
						return new Date(str);
					},
					float: function(num){
						return parseFloat(num);
					}
				}
			}); 

		});

		describe('naming rules',function(){
			afterEach(function(){
				if(flowName){
					nools.deleteFlow(flowName);
				}
				flowName = undefined;
			});
			it('should generate a unique name mapped to the pipeLine',function(){
				var meta = engine.generateNool(multipleClinicalRule);
				flowName = meta.source.name;
				nools.compile(meta.nools,{
					name: 'comp2dsssssls2',
					define: getDefined(),
					scope: {
					reporter: meta.pipeLine,
					date: function(str){
						return new Date(str);
					},
					float: function(num){
						return parseFloat(num);
					}
				}
				})
			});
		});

	});

	describe('generateResultPipeline', function(){
		it('should create an array', function(){
			var result = engine.generateResultPipeline(sample);
			expect(result).to.be.an('array');
		});
		it('should should contain rule keys, operators and arrays', function(){
			var result = engine.generateResultPipeline(sample);
			expect(result.indexOf('or')).to.be.greaterThan(0);
		});

		it('should generate a false pipeline for a disabled rule with multiple ruleGroups',function(){
			var result = engine.generateResultPipeline(disabledRule);
			expect(result).to.deep.equal([false,"OR",[false]]);
		});

		it('should generate a true pipeline for a disabled rule with single ruleGroup',function(){
			var result = engine.generateResultPipeline(disabledRuleSingle);
			expect(result).to.deep.equal([true]);
		});
	});
});