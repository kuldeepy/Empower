'use strict';

var fs = require('fs');
var simplesample = JSON.parse(fs.readFileSync('./test/samples/simpleRule.json'));
var systolicRule = JSON.parse(fs.readFileSync('./test/samples/highSystolicRule.json'));
var disabledRule = JSON.parse(fs.readFileSync('./test/samples/disabledRule.json'));
var reportJson = JSON.parse(fs.readFileSync('./test/samples/reportJson.json'));
var complexAllergy = JSON.parse(fs.readFileSync('./test/samples/allergyResult.json'));
var bloodPressuresRule = JSON.parse(fs.readFileSync('./test/samples/bloodPressuresRule.json'));
var bloodPressureUser = JSON.parse(fs.readFileSync('./test/samples/bloodPressureUser.json'));
var testResult = JSON.parse(fs.readFileSync('./test/samples/testResult.json'));
var allergiesResult = JSON.parse(fs.readFileSync('./test/samples/allergyResult.json'));
var noolsUtil = require('../../app/util/nools-utility');
var logger = require('log4js');
var log = logger.getLogger('test-logging');
log.setLevel('FATAL');
var engine, mockStore;
var bluebird = require('bluebird');

describe('engine', function(){
	
	var user = { 
		ruleId: 1,
		patients: [
			{
				allergies: [
					{
						name: 'honey'
					}
				],
				firstName: 'bob',
				gender: 1,
				testResults: [
						{
							'id': '157',
							'documentId': '171',
							'active': 'true',
							'exported': 'false',
							'medseekRecordId': '1b13571e-3d2e-4a54-96c0-b98bac3fe250',
							'name': 'CBC WO DIFFERENTIAL',
							'date': '07/27/2008 02:30 PM',
							'clinician': '',
							'type': '',
							'comments': '',
							'source': 'ExternalDomain:ExternalSystem:ExternalGroup'
						},
						{
							'component': 'HGB',
							'value': '32.2',
							'testResultId': '157'
						},
						{
							'component': 'WBC',
							'value': '6.7',
							'testResultId': '157'
						}
					]
				}
			]};
	beforeEach(function(){
		mockStore = sinon.stub({
			find: function(){}
		});
		mockStore.find.onCall(0).returns(mockPromises.buildImmediatelyResolvedPromise(simplesample));
		mockStore.find.onCall(1).returns(mockPromises.buildImmediatelyResolvedPromise(simplesample));
		engine = proxyquire.noCallThru()('../../app/engine', {
			'./util/dataStore': mockStore,
			'bluebird': bluebird
		});
		engine.setLogger(logger);
		noolsUtil.setLogger(logger);
	});
	it('fails', function(done){
		engine.evalUser({user:user,ruleId:1},log).done(function(){
			done();
		});
	});

	describe('bloodPressures', function(){
		beforeEach(function(){
			
			var clinicalNools = noolsUtil.generateNool(bloodPressuresRule);
			mockStore.find.onCall(0).returns(mockPromises.buildImmediatelyResolvedPromise(clinicalNools));
			user.patients[0].bloodPressures = [
					{
						systolic: '200'
					}
				];
		});

		it('should resolve to true for the matched bloodPressure and role rule.', function(done){
			engine.evalUser(bloodPressureUser,log).done(function(result){
				try{
					log.debug(result);
					expect(result).to.be.true; // jshint ignore:line
					done();
				} catch(err){
					done(err);
				}
			});
		});
	});

	describe('clinical condition', function(){
		var clinicalNools;
		
		beforeEach(function(){
			
			clinicalNools = noolsUtil.generateNool(systolicRule);
			mockStore.find.onCall(0).returns(mockPromises.buildImmediatelyResolvedPromise(clinicalNools));
			user.patients[0].bloodPressures = [
					{
						systolic: '200'
					}
				];
		});

		it('should pass a clinical condition test if the user has the condition specified', function(done){
			engine.evalUser({user:user, ruleId: 'systolicRule'},log).done(function(result){
				try{
					expect(result).to.be.true; // jshint ignore:line
					done();
				} catch(err){
					done(err);
				}
			});
		});

	});

	describe('test result', function(){
		var clinicalNools;
		
		beforeEach(function(){
			clinicalNools = noolsUtil.generateNool(testResult,log);
			mockStore.find.onCall(0).returns(mockPromises.buildImmediatelyResolvedPromise(clinicalNools));
		});

		it('should pass a test result if the user has the specified test', function(done){
			engine.evalUser({user:user, ruleId: 4},log).done(function(result){
				try{
					expect(result).to.be.true;// jshint ignore:line
					done();
				} catch(err){
					done(err);
				}
			});
		});
	});

	describe('allergy condition', function(){
		var clinicalNools;
		
		beforeEach(function(){
			clinicalNools = noolsUtil.generateNool(allergiesResult,log);
			mockStore.find.onCall(0).returns(mockPromises.buildImmediatelyResolvedPromise(clinicalNools));
			user._id = require('node-uuid').v1();
		});

		it('should pass a test result if the user has the specified test', function(done){
			user._id = require('node-uuid').v1();
			engine.evalUser({user:user, ruleId: 5},log).done(function(result){
				try{
					expect(result).to.be.true;// jshint ignore:line
					done();
				} catch(err){
					done(err);
				}
			});
		});
	});

	describe('matchRule',function(){
		var ruleObj, mockLog;
		beforeEach(function(){
			ruleObj = reportJson;
			mockLog = sinon.stub({
				debug:function(){}
			});
		});

		it('should return the matched rule',function(){
			var rule = engine.matchRule(ruleObj.nools,0,0,log);
			expect(rule).to.be.a('string');
		});

		it('should return the matched rule with deep index',function(){
			var rule = engine.matchRule(ruleObj.nools,0,0,log);
			expect(rule).to.be.a('string');
		});

	});
	
	describe('reportFailures',function(){
		var pipeLine;
		beforeEach(function(){
			pipeLine =  [
				[true, 'AND', [false, 'OR', true, 'OR', false]]
			];
		});

		it('should report the deep index',function(){
			var idx = engine.reportFailures(complexAllergy.nools,complexAllergy.pipeLine);
		})
	});

	describe('replaceNullWithEmpty',function(){
		var ruleObj;
		beforeEach(function(){
			ruleObj = {UserName : 'UserName', City : null};
		});

		it('should return the object',function(){
			var rule = engine.replaceNullWithEmpty(ruleObj);
			expect(rule).to.be.a('object');
		});

		it('should return the object with replace the null value',function(){
			var rule = engine.replaceNullWithEmpty(ruleObj);
			expect(rule.City).to.be.equal('');
		});

	});
});