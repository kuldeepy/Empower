Rules Engine
============


The **rules-engine** is a node.js microservice.  The application is a wrapper of [nools](https://github.com/C2FO/nools), a [rete](http://en.wikipedia.org/wiki/Rete_algorithm) based rules engine.  The **rules-engine** has three public methods available for consumption with the following route key bindings:
- medseek.platform.engine.rules.set
- medseek.platform.engine.rules.get
- medseek.platform.engine.rules.evaluate

### set

The **Set** Queue is used to save or update a **rule definition** object.
This object has the following format:

<pre>
{
    /*display name of rule for editing*/
	"name": "Simple Rule",
	
	/*description of rule set*/
	"description": "This is a simple Rule", 
	
	/*whether or not to evaluate this rule at run time*/
	"enabled": true,  
	
	/*array of rules and operators in between rules*/
	"rules": [
		{
			"enabled": true,
			"rules": [
				{
					"operator": "equals",
					"value": "bob",
					"type": "String",
					"target": "user.firstName"
				}
			]
		},
		{
		    "operatorType": "and" /*and|or*/
		},
		{
			"enabled": true,
			"rules": [
				{
					"operator": "equals",
					"value": "smith",
					"type": "String",
					"target": "user.lastName"
				}
			]
		}
	]
}
</pre>

This Rule will get converted to nools dsl in the following format.
<pre>
rule '0,2' {
	when{
		user : User user;
		firstName : String firstName == 'bob' from user.firstName;
	}
	then{
		reporter[0][2] = true;
	}
}

rule '0,4' {
		when{
		user : User user;
		firstName : String lastName == 'smith' from user.lastName;
	}
	then{
		reporter[0][4] = true;
	}
}
</pre>

The resulting generated nools code as well as the original JSON will get stored in a mongodb available for retrieval at runtime. The result of the **set** method is the string `_id` value of the mongodb Rules document which gets saved.  This value will be used to run a rule at application runtime.

### get

In order to edit a rule definition the developer will need to retrieve the rule from the rules engine microservice based on the `_id` set in the **set** method. To retrieve all the rules stored don't pass an **id** to this method and the entire collection will be returned.

### evaluate

To evaluate a rule group the developer will need to pass a user as well as an array of **id's**.  For example a request would look like so: 
<pre>
{ 
    user : ...
    rules: ['19284182asb8','12948182193basd']    
}
</pre>

Once rules have evaluated the **reporter object** will be analyzed. For example given the following evaluation target user,
<pre>
    {
        firstName: 'bob',
        lastName: 'smith'
    }
</pre>
being run against the previous nools rule group, a javascript line like <code>(true && true)</code> would be generated and evaluated. So, if you pass two rules in the rules array and the first evaluated to `true` and the second evaluated to `false` the response from the **evaluate** method would look like:
<pre>
[true,false]
</pre>

## Running the Application

To run the **rules-engine** run `npm install` and then `node app`.