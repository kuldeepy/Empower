'use strict';

var micro = require('ih-microservice');


var defaults = {
  id: 'empower-analytics-reporting',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-analytics-reporting',
  defaultReturnBody: true,
  defaultTableauAdminUserName:'admin',
  defaultTableauAdminPassword:'Test123',
  defaultTableauUserName: 'admin',
  defaultTableauPassword: 'Test123',
  defaultTableauServer:'http://vm-stage-01.cloudapp.net:8000'
};

var requestLib = require('request-promise');

micro(defaults, function(app, logging, microservices, Promise, options, _, util) {
  var log = logging.getLogger(defaults.id);
  var moduleXML = Promise.promisifyAll( require('xml2js'));

  module.exports = {
    getAnalyticReportAuthenticationToken: getAnalyticReportAuthenticationToken,
    getAnalyticReportWorkbooks: getAnalyticReportWorkbooks,
    getAnalyticReportViews:getAnalyticReportViews,
    makeAuthenticationRequest: makeAuthenticationRequest,
    getAnalyticsProjects:getAnalyticsProjects,
    makeAnalyticsProjectRequest:makeAnalyticsProjectRequest,
    getUserAuthentication:getUserAuthentication,
    getAnalyticReportServerUrl:getAnalyticReportServerUrl,
    getAnalyticReportWorkbooksByProjectId:getAnalyticReportWorkbooksByProjectId,
    updateAnalyticReportWorkbook:updateAnalyticReportWorkbook,
    deleteAnalyticProject:deleteAnalyticProject,
    createAnalyticReportProject:createAnalyticReportProject,
    updateAnalyticReportProject:updateAnalyticReportProject,
    deleteAnalyticWorkBook:deleteAnalyticWorkBook,
    defaults: defaults
  };


  return Promise.resolve(
    microservices.bind('empower.analyticreportservice.getAnalyticReportWorkbooks', getAnalyticReportWorkbooks),
    microservices.bind('empower.analyticreportservice.getAnalyticReportAuthenticationToken', getAnalyticReportAuthenticationToken),
    microservices.bind('empower.analyticreportservice.getAnalyticReportViews',getAnalyticReportViews),
    microservices.bind('empower.analyticreportservice.getAnalyticProjects',getAnalyticsProjects),
    microservices.bind('empower.analyticreportservice.getAnalyticReportWorkbooksByProjectId',getAnalyticReportWorkbooksByProjectId),
    microservices.bind('empower.analyticreportservice.getAnalyticReportServerUrl',getAnalyticReportServerUrl),
    microservices.bind('empower.analyticreportservice.deleteAnalyticWorkBook',deleteAnalyticWorkBook),
    microservices.bind('empower.analyticreportservice.updateAnalyticReportWorkbook',updateAnalyticReportWorkbook),
    microservices.bind('empower.analyticreportservice.deleteAnalyticProject',deleteAnalyticProject),
    microservices.bind('empower.analyticreportservice.createAnalyticReportProject',createAnalyticReportProject),
    microservices.bind('empower.analyticreportservice.updateAnalyticReportProject',updateAnalyticReportProject)
  );

  function deleteAnalyticWorkBook(request,messageContext){
    return Promise.try(
      function() {
          return getUserAuthentication(true).then(function(authResponse){

            var workBookId = request.WorkBookId;

            var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid +  '/workbooks/'+ workBookId;

            var optionRequest = {
              uri: urlformat, //URL 
              method: 'DELETE', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
            };
            return requestLib(optionRequest).then(function(body){
              return { result: true};
           }).catch(function(err){return {result:false, error:err};});

          });
        })
      .catch(defaultError);
  }

  function updateAnalyticReportWorkbook(request,messageContext){
    return Promise.try(
      function() {
          return getUserAuthentication(true).then(function(authResponse){

            var workBookId = request.WorkbookId;

            var projectId = request.ProjectId;

            var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid +  '/workbooks/'+ workBookId;

            var optionRequest = {
              uri: urlformat, //URL 
              body: "<tsRequest> <workbook showTabs=" + '"' + false + '"' + " > <project id=" + '"' + projectId + '"' + " /> </workbook> </tsRequest>",
              method: 'PUT', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
            };
            return requestLib(optionRequest).then(function(body){
              return { result: true};
           }).catch(function(err){return {result:false, error:err};});

          });
        })
      .catch(defaultError);
  }

  function deleteAnalyticProject(request,messageContext){
     return Promise.try(
      function() {
          return getUserAuthentication(true).then(function(authResponse){

            var projectId = request.ProjectId;

            var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid +  '/projects/' + projectId;

            var optionRequest = {
              uri: urlformat, //URL 
              method: 'DELETE', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
            };
            return requestLib(optionRequest).then(function(body){
              return { result: true};
           }).catch(function(err){return {result:false, error:err};});

          });
        })
      .catch(defaultError);
  }

  function createAnalyticReportProject(request,messageContext){
    return Promise.try(
      function() {
          return getUserAuthentication(false).then(function(authResponse){

            var name = request.name;

            var description= request.description;

            var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid +  '/projects/';

            var optionRequest = {
              uri: urlformat, //URL 
              body: "<tsRequest><project name=" + '"' +name+ '"' + "   description=" + '"' + description + '"' + "/></tsRequest>",
              method: 'POST', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
            };

            return requestLib(optionRequest).then(function(body){

            return moduleXML.parseStringAsync(body).then(function(result) {

              if(result.hasOwnProperty("tsResponse") && result.tsResponse.hasOwnProperty("project")){
                  return { result: true};
                }else{
                  return {result:false};
                }
             });

           }).catch(function(err){return {result:false, error:err};});

          });
        })
      .catch(defaultError); 
  }

  function updateAnalyticReportProject(request,messageContext){
    return Promise.try(
      function() {
          return getUserAuthentication(false).then(function(authResponse){
            var name = request.name;

            var description= request.description;

            var projectId = request.ProjectId;

            var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid +  '/projects/'+ projectId;

            var optionRequest = {
              uri: urlformat, //URL 
              body: "<tsRequest><project name=" + '"' +name+ '"' + "   description=" + '"' + description + '"' + "/></tsRequest>",
              method: 'PUT', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
            };
            return requestLib(optionRequest).then(function(body){
              return { result: true};
           }).catch(function(err){return {result:false, error:err};});

          });
        }
    )
    .catch(defaultError); 
  }

  function getAnalyticReportServerUrl(request,messageContext){
      return Promise.try(
      function() {
          return getUserAuthentication(true).then(function(authResponse){
              return [{TableauServerUrl:options.defaultTableauServer }];
            });
        })
      .catch(defaultError);
  }

  function getAnalyticReportAuthenticationToken(request, messageContext) {

    return Promise.try(
      function() {

        var urlformat = options.defaultTableauServer+'/trusted';

        var optionRequest = {
            uri: urlformat, //URL 
            form: {username: getUserName(request.UseAdminMode), target_site:''}, 
            method: 'POST', 
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        };

        return makeAuthenticationRequest(optionRequest).then(function(result){
          if(result.Key === '-1'){
            return {error: 'Could not retrieve valid token from Tableau server.'};
          }
          else{
            return result;
          }

        });
              
      }
    ).catch(defaultError);
  }

  function makeRequestAnalyticReportWorkbooksByProjectId(authResponse){
      var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid + '/users/' + authResponse.Userid + '/workbooks';

          var optionRequest = {
              uri: urlformat, //URL 
              method: 'GET', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
          };
           return requestLib(optionRequest);
  }

  function getAnalyticReportWorkbooksByProjectId(request,messageContext){
    return Promise.try(
      function() {

        var projectId= request.ProjectId;

        return getUserAuthentication(false).then(function(authResponse){

         return makeRequestAnalyticReportWorkbooksByProjectId(authResponse).then(function(body){

            var viewResults = [];

             return moduleXML.parseStringAsync(body).then(function(result) {
              var workBookResults =[]; 

              for(var i = 0;i < result.tsResponse.workbooks[0].workbook.length;i++){

                var localProjectId = result.tsResponse.workbooks[0].workbook[i].project[0].$.id;

                var workBook = result.tsResponse.workbooks[0].workbook[i];
                if(projectId === localProjectId)
                {
                  workBookResults.push({ Workbookname: workBook.$.name, WorkbookId: workBook.$.id, Token :authResponse.AuthToken, TableauUrl: workBook.$.contentUrl});
                }
            }
              return workBookResults;
            });

          });

        });


      }
     )
     .catch(defaultError);
  }


  function getAnalyticReportViews(request,messageContext){
     return Promise.try(
      function() {

        var workBookId = request.WorkbookId;
        return getUserAuthentication(false).then(function(authResponse){

          var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid +  '/workbooks/'+ workBookId;

          var optionRequest = {
              uri: urlformat, //URL 
              method: 'GET', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
          };
           return requestLib(optionRequest).then(function(body){

            var viewResults = [];

            return moduleXML.parseStringAsync(body).then(function(result) {

              for(var i = 0;i < result.tsResponse.workbook[0].views[0].view.length;i++){
                var view = result.tsResponse.workbook[0].views[0].view[i];
                viewResults.push({ ViewName: view.$.name, ViewId: view.$.id});
              }

              return viewResults;
            });

          });

        });


      }
     )
     .catch(defaultError);
  }

  function getAnalyticReportWorkbooks(request,messageContext){
     return Promise.try(

      function() {
        return getUserAuthentication(false).then(function(authResponse){

          var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid + '/users/' + authResponse.Userid + '/workbooks';

          var optionRequest = {
              uri: urlformat, //URL 
              method: 'GET', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
          };

          return requestLib(optionRequest).then(function(body){

             return moduleXML.parseStringAsync(body).then(function(result) {
              var workBookResults =[]; 

              for(var i = 0;i < result.tsResponse.workbooks[0].workbook.length;i++){
                  var workBook = result.tsResponse.workbooks[0].workbook[i];
                  workBookResults.push({ Workbookname: workBook.$.name, WorkbookId: workBook.$.id, Token :authResponse.AuthToken, TableauUrl: workBook.$.contentUrl});
              }
              return workBookResults;

             });

          });

        });

      }
     )
     .catch(defaultError);
  }


  function makeAnalyticsProjectRequest(authResponse){

          var urlformat = options.defaultTableauServer+ '/api/2.0/sites/' + authResponse.Siteid+"/projects";

          var optionRequest = {
              uri: urlformat, //URL 
              method: 'GET', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': authResponse.AuthToken
              }
          };

          return requestLib(optionRequest);
  }


  function getAnalyticsProjects(request,messageContext){
     return Promise.try(

      function() {

        return getUserAuthentication(false).then(function(authResponse){

         return makeAnalyticsProjectRequest(authResponse).then(function(body){

              return moduleXML.parseStringAsync(body).then(function(result) {
              var projectResults =[]; 

              for(var i = 0;i < result.tsResponse.projects[0].project.length;i++){
                  var project = result.tsResponse.projects[0].project[i].$;
                  projectResults.push({ ProjectName: project.name, Projectid: project.id, Token :authResponse.AuthToken});
              }
              return projectResults;
             });

          });

        });

      }
     )
     .catch(defaultError);
  }


  function getUserAuthentication(isAdminUser){

        var urlformat = options.defaultTableauServer+'/api/2.0/auth/signin';

        var optionRequest = {
            uri: urlformat, //URL 
            body: "<tsRequest> <credentials name=" + '"' + getUserName(isAdminUser)+ '"' + " password=" + '"' + getPassword(isAdminUser)+ '"' + " > <site contentUrl=" + '"' + '"' + " /> </credentials> </tsRequest>",
            method: 'POST', 
            headers: { 
                "content-type": "text/xml"
            }
        };
        return requestLib(optionRequest).then(function(body){

          return moduleXML.parseStringAsync(body).then(function(result) {

            var token = result.tsResponse.credentials[0].$.token;
            var siteid = result.tsResponse.credentials[0].site[0].$.id;
            var userid = result.tsResponse.credentials[0].user[0].$.id;

            var resultObj = {AuthToken : token, Userid : userid, Siteid: siteid};

            return resultObj;

          });

        }).
        catch(defaultError);
  }

  function getUserName(isAdminUser){
    if(isAdminUser===true){
      return options.defaultTableauAdminUserName;
    }
    else{
      return options.defaultTableauUserName;
    }
  }

  function getPassword(isAdminUser){
    if(isAdminUser===true){
      return options.defaultTableauAdminPassword;
    }
    else{
      return options.defaultTableauPassword;
    }
  }

  function makeAuthenticationRequest(requestOptions){
    
    return requestLib(requestOptions).then(function(body){
          return { TableauUrl: options.defaultTableauServer, Key: body };
        }).
    catch(function(err){
          return {};
        });
  }

  function defaultError (err) {
    log.error(err);
    return {
      error: err.message
    };
  }


});