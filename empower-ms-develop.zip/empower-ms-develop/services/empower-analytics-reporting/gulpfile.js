'use strict';

var gulp = require('gulp');

gulp.task('start', function() {
  require('./empower-analytics-reporting.js');
});

gulp.task('test', function() {
  var gulpMocha = require('gulp-mocha');
  var gulpUtil = require('gulp-util');
  var options = getOptions({
    reporter: 'spec',
    timeout: undefined
  });
  return gulp.src('./test/*.tests.js')
    .pipe(gulpMocha(options))
    .on('error', gulpUtil.log);
});

gulp.task('start-watch', function() {
  var gulpNodemon = require('gulp-nodemon');
  gulpNodemon(getOptions({
    script: 'empower-analytics-reporting',
    ext: 'html js',
    ignore: []
  }));
});

function getOptions(defaults) {
  var args = process.argv[0] == 'node' ? process.argv.slice(3) : process.argv.slice(2);
  var minimist = require('minimist');
  return minimist(args, {
    default: defaults
  });
}