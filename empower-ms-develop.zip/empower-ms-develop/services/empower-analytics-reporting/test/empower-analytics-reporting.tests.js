'use strict';
var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var _ = require('lodash');
var util = require('util');

require('sinon-as-promised')(Promise);


var defaults = {
  id: 'empower-analytics-reporting',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-analytics-reporting',
  defaultReturnBody: true,
   defaultTableauAdminUserName:'admin',
  defaultTableauAdminPassword:'Test123',
  defaultTableauUserName: 'admin',
  defaultTableauPassword: 'Test123',
  defaultTableauServer:'http://vm-stage-01.cloudapp.net:8000'
};

describe('empower-analytics-reporting', function() {

  var service, mockMs, mockLog, mockMicroservices, options, mockLogging, mockRequest;
  beforeEach(function() {
    mockMs = sinon.stub();
    mockRequest = sinon.stub();
    mockLog = sinon.stub({

      debug: function() {},
      error: function(e) {
        console.error(e);
      },
      trace: function() {}
    });
    mockLogging = {
      getLogger: function() {
        return mockLog;
      }
    };
    mockMicroservices = sinon.stub({
      bind: function() {},
      call: function() {}
    });
    options ={id: 'empower-analytics-reporting',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-analytics-reporting',
  defaultReturnBody: true,
  defaultTableauAdminUserName:'admin',
  defaultTableauAdminPassword:'Test123',
  defaultTableauUserName: 'admin',
  defaultTableauPassword: 'Test123',
  defaultTableauServer:'http://vm-stage-01.cloudapp.net:8000'};


  mockMs.yields(undefined, mockLogging, mockMicroservices, Promise, options, _, util,defaults);
    service = proxyquire.noCallThru()('../empower-analytics-reporting.js', {
      'ih-microservice': mockMs,
      'request-promise': mockRequest
    });

  });

  it('exists', function() {
    expect(service).to.be.an('object');
  });


  describe("Delete project",function(){

     /*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';

      beforeEach(function (){

        mockRequest.returns(Promise.resolve('success'));
        service.defaults = defaults;

        var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

        var options = {
              uri: urlformat, //URL 
              method: 'DELETE', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': 'something'
              }
        };
      
        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));
      });

      it('should delete project', function(){
        service.deleteAnalyticProject({ProjectId:'986a3bdc-34b5-11e5-b396-679c09e2812e'}).then(function(result){
          expect(result.result).to.equal(true);
        });
      });

  });

  describe("Create duplicate project",function(){

     /*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';

      beforeEach(function (){

        mockRequest.rejects(new Error('Duplicate'));
        service.defaults = defaults;

        var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

        var options = {
            uri: urlformat, //URL 
            body: "<tsRequest> <credentials name=" + '"' + 'admin'+ '"' + " password=" + '"'+'Test123'+ '"' + " > <site contentUrl=" + '"' + '"' + " /> </credentials> </tsRequest>",
            method: 'POST', 
            headers: { 
                "content-type": "text/xml"
            }
        };
      
        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));
      });

      it('should handle exception', function(){
        service.createAnalyticReportProject({Name:'new project', Description:'description a'}).then(function(result){
          var expectedResult = [ {ProjectName: 'default', Projectid: '986a3bdc-34b5-11e5-b396-679c09e2812e', Token:'something'},{ProjectName: 'Tableau Samples', Projectid: '1b4ae6a8-8a1e-4f93-bb50-f9221a9be079', Token:'something'} ];

          expect(result.result).to.equal(false);
        });
      });
  });
   
  describe('Retrieve projects', function(){

    /*jshint multistr: true */
    var responseXML = '<tsResponse xmlns="http://tableausoftware.com/api" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api http://tableausoftware.com/api/ts-api-2.0.xsd"> \
      <pagination pageNumber="1" pageSize="100" totalAvailable="2"/> \
      <projects> \
        <project id="986a3bdc-34b5-11e5-b396-679c09e2812e" name="default" description="The default project that was automatically created by Tableau."/> \
        <project id="1b4ae6a8-8a1e-4f93-bb50-f9221a9be079" name="Tableau Samples" description="Sample workbooks provided by Tableau Software."/> \
      </projects> \
    </tsResponse>';

    /*jshint multistr: true */
    var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';

      
      beforeEach(function (){

        mockRequest.returns(Promise.resolve(responseXML));
        service.defaults = defaults;

        var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

        var options = {
            uri: urlformat, //URL 
            body: "<tsRequest> <credentials name=" + '"' + 'admin'+ '"' + " password=" + '"'+'Test123'+ '"' + " > <site contentUrl=" + '"' + '"' + " /> </credentials> </tsRequest>",
            method: 'POST', 
            headers: { 
                "content-type": "text/xml"
            }
        };
      
        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));

      });

      it('should return 2 projects', function(){
        service.getAnalyticsProjects().then(function(result){
          var expectedResult = [ {ProjectName: 'default', Projectid: '986a3bdc-34b5-11e5-b396-679c09e2812e', Token:'something'},{ProjectName: 'Tableau Samples', Projectid: '1b4ae6a8-8a1e-4f93-bb50-f9221a9be079', Token:'something'} ];

          var compareResult = JSON.stringify(result) === JSON.stringify(expectedResult); 

          expect(compareResult).to.equal(true);
        });
      });

  });

  describe("Retrieve workbooks",function(){

      var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

      var requestOptionMock = {
            uri: urlformat, //URL 
            form: {username: defaults.defaultTableauUserName, target_site:''}, 
            method: 'POST', 
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded'
            }
      };


      var projectsUrlFormat = defaults.defaultTableauServer+ '/api/2.0/sites/' +'67b26d53-b6cd-4fed-b395-9eb56c4c8510'+ '/users/' + 'e60ba778-f447-46d7-bb6e-e76adc3f27e9' + '/workbooks';

      /*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';
        
      /*jshint multistr: true */
      var workbooksResponse='<?xml version="1.0" encoding="UTF-8"?> \
      <tsResponse \
          xmlns="http://tableausoftware.com/api" \
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api http://tableausoftware.com/api/ts-api-2.0.xsd">\
          <pagination pageNumber="1" pageSize="100" totalAvailable="3"/> \
          <workbooks> \
              <workbook id="c8c80ed0-cfa9-4865-b2e8-8a31b29c14d0" name="Regional" contentUrl="Regional" showTabs="false"> \
                  <project id="1b4ae6a8-8a1e-4f93-bb50-f9221a9be079" name="Tableau Samples"/> \
                  <owner id="e60ba778-f447-46d7-bb6e-e76adc3f27e9"/> \
                  <tags></tags> \
              </workbook> \
              <workbook id="7d0d578a-aee5-40da-a90a-9bb58d670db3" name="Superstore" contentUrl="Superstore" showTabs="false"> \
                  <project id="986a3bdc-34b5-11e5-b396-679c09e2812e" name="default"/> \
                  <owner id="e60ba778-f447-46d7-bb6e-e76adc3f27e9"/> \
                  <tags></tags> \
              </workbook> \
              <workbook id="8bdaf961-8df3-4dd7-b893-76860d138ebb" name="copy" contentUrl="copy" showTabs="false"> \
                  <project id="986a3bdc-34b5-11e5-b396-679c09e2812e" name="default"/> \
                  <owner id="e60ba778-f447-46d7-bb6e-e76adc3f27e9"/> \
                  <tags></tags> \
              </workbook> \
          </workbooks> \
      </tsResponse>';

      beforeEach(function (){
        service.defaults = defaults;

        var options = {
            uri: urlformat, //URL 
            body: "<tsRequest> <credentials name=" + '"' + 'admin'+ '"' + " password=" + '"'+'Test123'+ '"' + " > <site contentUrl=" + '"' + '"' + " /> </credentials> </tsRequest>",
            method: 'POST', 
            headers: { 
                "content-type": "text/xml"
            }
        };

        var optionsForProjectsRequest = {
              uri: projectsUrlFormat, //URL 
              method: 'GET', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': 'something'
              }
          };

        mockRequest.withArgs(optionsForProjectsRequest).returns(Promise.resolve(workbooksResponse));

        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));
      });

      it('should return 3 workbook over all projects',function(){
        service.getAnalyticReportWorkbooks().then(function(result){
            expect(result.length).to.equal(3);
        });
      });
  });

  describe("Retrieve workbooks by project id",function(){

      var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

      var requestOptionMock = {
            uri: urlformat, //URL 
            form: {username: defaults.defaultTableauUserName, target_site:''}, 
            method: 'POST', 
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded'
            }
      };


      var projectsUrlFormat = defaults.defaultTableauServer+ '/api/2.0/sites/' +'67b26d53-b6cd-4fed-b395-9eb56c4c8510'+ '/users/' + 'e60ba778-f447-46d7-bb6e-e76adc3f27e9' + '/workbooks';

      /*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';
        
      /*jshint multistr: true */
      var workbooksResponse='<?xml version="1.0" encoding="UTF-8"?> \
      <tsResponse \
          xmlns="http://tableausoftware.com/api" \
          xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api http://tableausoftware.com/api/ts-api-2.0.xsd">\
          <pagination pageNumber="1" pageSize="100" totalAvailable="3"/> \
          <workbooks> \
              <workbook id="c8c80ed0-cfa9-4865-b2e8-8a31b29c14d0" name="Regional" contentUrl="Regional" showTabs="false"> \
                  <project id="1b4ae6a8-8a1e-4f93-bb50-f9221a9be079" name="Tableau Samples"/> \
                  <owner id="e60ba778-f447-46d7-bb6e-e76adc3f27e9"/> \
                  <tags></tags> \
              </workbook> \
              <workbook id="7d0d578a-aee5-40da-a90a-9bb58d670db3" name="Superstore" contentUrl="Superstore" showTabs="false"> \
                  <project id="986a3bdc-34b5-11e5-b396-679c09e2812e" name="default"/> \
                  <owner id="e60ba778-f447-46d7-bb6e-e76adc3f27e9"/> \
                  <tags></tags> \
              </workbook> \
              <workbook id="8bdaf961-8df3-4dd7-b893-76860d138ebb" name="copy" contentUrl="copy" showTabs="false"> \
                  <project id="986a3bdc-34b5-11e5-b396-679c09e2812e" name="default"/> \
                  <owner id="e60ba778-f447-46d7-bb6e-e76adc3f27e9"/> \
                  <tags></tags> \
              </workbook> \
          </workbooks> \
      </tsResponse>';

      beforeEach(function (){
        service.defaults = defaults;

        var options = {
            uri: urlformat, //URL 
            body: "<tsRequest> <credentials name=" + '"' + 'admin'+ '"' + " password=" + '"'+'Test123'+ '"' + " > <site contentUrl=" + '"' + '"' + " /> </credentials> </tsRequest>",
            method: 'POST', 
            headers: { 
                "content-type": "text/xml"
            }
        };

        var optionsForProjectsRequest = {
              uri: projectsUrlFormat, //URL 
              method: 'GET', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': 'something'
              }
          };

        mockRequest.withArgs(optionsForProjectsRequest).returns(Promise.resolve(workbooksResponse));

        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));
      });

      it('should return 1 workbook for project 1b4ae6a8-8a1e-4f93-bb50-f9221a9be079',function(){
        service.getAnalyticReportWorkbooksByProjectId({ProjectId:'1b4ae6a8-8a1e-4f93-bb50-f9221a9be079'}).then(function(result){
            expect(result.length).to.equal(1);
        });
      });

      it('workbook should have workbook name',function(){
        service.getAnalyticReportWorkbooksByProjectId({ProjectId:'1b4ae6a8-8a1e-4f93-bb50-f9221a9be079'}).then(function(result){
            expect(result[0].Workbookname).to.equal('Regional');
        });
      });

      it('should return 2 workbook for project 986a3bdc-34b5-11e5-b396-679c09e2812e',function(){
        service.getAnalyticReportWorkbooksByProjectId({ProjectId:'986a3bdc-34b5-11e5-b396-679c09e2812e'}).then(function(result){
            expect(result.length).to.equal(2);
        });
      });
  });

  describe('Make authentication request', function(){
      var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

      var requestOptionMock = {
            uri: urlformat, //URL 
            form: {username: defaults.defaultTableauUserName, target_site:''}, 
            method: 'POST', 
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded'
            }
      };

      /*jshint multistr: true *//*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';

      beforeEach(function (){
        service.defaults = defaults;

        var options = {
            uri: urlformat, //URL 
            body: "<tsRequest> <credentials name=" + '"' + 'admin'+ '"' + " password=" + '"'+'Test123'+ '"' + " > <site contentUrl=" + '"' + '"' + " /> </credentials> </tsRequest>",
            method: 'POST', 
            headers: { 
                "content-type": "text/xml"
            }
        };
      
         mockRequest.withArgs(options).returns(Promise.resolve(authResponse));
      });

      it('should return valid auth token ',function(){
        service.getUserAuthentication(true).then(function(result){
            expect(result.AuthToken).to.equal('something');
        });
      });

      it('should return valid siteid ',function(){
        service.getUserAuthentication(true).then(function(result){
            expect(result.Siteid).to.equal('67b26d53-b6cd-4fed-b395-9eb56c4c8510');
        });
      });

      it('should return valid userid ',function(){
        service.getUserAuthentication(true).then(function(result){
            expect(result.Userid).to.equal('e60ba778-f447-46d7-bb6e-e76adc3f27e9');
        });
      });

  });

  describe('Retrieve AnalyticReportServerUrl', function(){
      var urlformat = defaults.defaultTableauServer+'/trusted';

      var requestOptionMock = {
            uri: urlformat, //URL 
            form: {username: defaults.defaultTableauUserName, target_site:''}, 
            method: 'POST', 
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded'
            }
      };

      /*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';

      beforeEach(function (){
        service.defaults = defaults;

        var options = {
            uri: urlformat, //URL 
            body: "<tsRequest> <credentials name=" + '"' + 'admin'+ '"' + " password=" + '"'+'Test123'+ '"' + " > <site contentUrl=" + '"' + '"' + " /> </credentials> </tsRequest>",
            method: 'POST', 
            headers: { 
                "content-type": "text/xml"
            }
        };
      
        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));
      });

      it('should return valid url',function(){
        service.getAnalyticReportServerUrl().then(function(result){
            expect(result.length).to.not.equal(0);
        });
      });

  });

  describe('make valid AuthenticationTokenRequest', function () {
      var urlformat = defaults.defaultTableauServer+'/trusted';

      var authResponse='NWbijHaECQjaQKTa8qBvWpDv';


      var requestOptionMock = {
            uri: urlformat, //URL 
            form: {username: defaults.defaultTableauUserName, target_site:''}, 
            method: 'POST', 
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded'
            }
      };

      beforeEach(function (){
        service.defaults = defaults;

        mockRequest.withArgs(requestOptionMock).returns(Promise.resolve(authResponse));
      });

      it('should return key',function () {
        service.getAnalyticReportAuthenticationToken({UseAdmin:true}).then(function(result){
          expect(result.Key).to.equal('NWbijHaECQjaQKTa8qBvWpDv');
        });
      });

    });

  describe('make AuthenticationTokenRequest with incorrect username', function () {
      var requestOptionMock;
      var urlformat = defaults.defaultTableauServer+'/trusted';

      var authResponse='-1';

      beforeEach(function (){
        mockRequest.returns(Promise.resolve(authResponse));
      });

      it('should throw exception for invalid token',function(){
        service.getAnalyticReportAuthenticationToken({UseAdmin:true}).then(function(result){
          expect(result.error).to.equal('Could not retrieve valid token from Tableau server.');
        });
      });
  }); 

  describe("Update projects",function(){

      /*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';

      beforeEach(function (){

        mockRequest.returns(Promise.resolve('success'));
        service.defaults = defaults;

        var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

        var options = {
              uri: urlformat, //URL 
              method: 'DELETE', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': 'something'
              }
        };
      
        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));
      });

      it('should update workbook', function(){
        service.updateAnalyticReportProject({ProjectId:'986a3bdc-34b5-11e5-b396-679c09e2812e', Name:'new project name', Description:'new descirption'}).then(function(result){
          expect(result.result).to.equal(true);
        });
      });

  });

  describe("Delete workbook",function(){

     /*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';

      beforeEach(function (){

        mockRequest.returns(Promise.resolve('success'));
        service.defaults = defaults;

        var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

        var options = {
              uri: urlformat, //URL 
              method: 'DELETE', 
              headers: { 
                  'content-type': 'text/xml',
                  'X-Tableau-Auth': 'something'
              }
        };
      
        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));
      });

      it('should delete workbook', function(){
        service.deleteAnalyticWorkBook({WorkBookId:'986a3bdc-34b5-11e5-b396-679c09e2812e'}).then(function(result){
          expect(result.result).to.equal(true);
        });
      });

  });

  describe("Create project",function(){

     /*jshint multistr: true */
      var authResponse='<tsResponse xmlns="http://tableausoftware.com/api" \
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api \
      http://tableausoftware.com/api/ts-api-2.0.xsd"><credentials token="something"> \
      <site id="67b26d53-b6cd-4fed-b395-9eb56c4c8510" contentUrl="" /><user id="e60ba778-f447-46d7-bb6e-e76adc3f27e9" /></credentials></tsResponse>';

      /*jshint multistr: true */
      var createProjectResponse='<?xml version="1.0" encoding="UTF-8"?> \
      <tsResponse xmlns="http://tableausoftware.com/api" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://tableausoftware.com/api http://tableausoftware.com/api/ts-api-2.0.xsd"> \
        <project id="f1ebd0c9-25d1-41b4-9f2a-8a442813d69f" name="new project" description="description a"/> \
      </tsResponse> ';
      
      beforeEach(function (){

        mockRequest.returns(Promise.resolve(createProjectResponse));
        service.defaults = defaults;

        var urlformat = defaults.defaultTableauServer+'/api/2.0/auth/signin';

        var options = {
            uri: urlformat, //URL 
            body: "<tsRequest> <credentials name=" + '"' + 'admin'+ '"' + " password=" + '"'+'Test123'+ '"' + " > <site contentUrl=" + '"' + '"' + " /> </credentials> </tsRequest>",
            method: 'POST', 
            headers: { 
                "content-type": "text/xml"
            }
        };
      
        mockRequest.withArgs(options).returns(Promise.resolve(authResponse));

      });

      it('should create project', function(){
        service.createAnalyticReportProject({Name:'new project', Description:'description a'}).then(function(result){
          var expectedResult = [ {ProjectName: 'default', Projectid: '986a3bdc-34b5-11e5-b396-679c09e2812e', Token:'something'},{ProjectName: 'Tableau Samples', Projectid: '1b4ae6a8-8a1e-4f93-bb50-f9221a9be079', Token:'something'} ];

          expect(result.result).to.equal(true);
        });
      });

  });
   
  

});