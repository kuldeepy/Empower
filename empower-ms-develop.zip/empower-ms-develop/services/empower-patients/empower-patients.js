'use strict';
var micro = require('ih-microservice');
var availableQueryParameters = ['id', 'firstName', 'lastName', 'uniqueId'];
var defaults = {
  id: 'empower-patients',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-patients',
  defaultReturnBody: true
};

micro(defaults, function(app, logging, microservices, bluebird, options, url, _, util) {
  var Promise = bluebird, db;
  var log = logging.getLogger('empower-patients');
  var knownPgs = {};
  var countries;
  var states;
  return Promise.resolve(microservices.bind('empower.patients.search.#', searchPatients));

  function searchPatients(req, mc) {
    req.searchType = (req.searchType || 'Both').toLowerCase();
    var pgId = parseInt(_.last(mc.routingKey.split('.')), 10);
    return getKnownPortalGroup(pgId)
      .then(function(pg) {
        log.trace(pg);
        return querySource(req, pg.database, pgId)
          .tap(function(data){
            log.trace('tapped data',data);
          })
          .then(getCountryFilter(pg.directoryName))
          .then(getStateFilter(pg.directoryName))
          .catch(function(err) {
            return err;
          });
      })
      .catch(function(err) {
        log.error(err);
        return err;
      });
  }

  function getKnownPortalGroup(id) {
    return new Promise(function(resolve) {
        log.trace('knownPgs for id %s: ', id, knownPgs[id]);
        resolve(knownPgs[id]);
      })
      .then(function(pg) {
        return pg || microservices.call('empower.v6.portal-groups.get', {})
          .tap(function(pgs) {
            log.trace(pgs);
          })
          .then(function(pgs) {
            log.debug('pgs',pgs);
            var pg = _.find(pgs, {
              siteID: id
            });
            pg.database = toMssqlConfig(pg.mssql);
            knownPgs[id] = pg;
            return knownPgs[id];
          });
      });
  }

  function querySource(req, pgDb, pgId) {
    var qString = 'SELECT [id],\n' +
      '      [firstName],\n' +
      '      [middleName],\n' +
      '      [lastName],\n' +
      '      [title],\n' +
      '      [suffix],\n' +
      '      [nickname],\n' +
      '      [dateOfBirth],\n' +
      '      [gender],\n' +
      '      [emailAddress],\n' +
      '      [address1],\n' +
      '      [address2],\n' +
      '      [city],\n' +
      '      [state],\n' +
      '      [zipCode],\n' +
      '      [country],\n' +
      '      [socialSecurityNumber],\n' +
      '      [medicalRecordNumber],\n' +
      '      [daytimePhone],\n' +
      '      [daytimePhoneExt],\n' +
      '      [eveningPhone],\n' +
      '      [eveningPhoneExt],\n' +
      '      [uniqueId],\n' +
      '      [maritalStatus],\n' +
      '      [externalId],\n' +
      '      [ethnicity]\n' +
      '  FROM [nModProfilePatients] ' + getWhere(req);
    return query({
      q: qString,
      qp: getWhereParameters(req)
    }, pgId);

  }

  function query(q, pgId) {
    return microservices.call('empower.v6.portal-groups.mssql.query.pg-' + pgId, q)
      .tap(function(results) {
        log.trace('get| query results', util.inspect(results, {
          colors: true,
          depth: null
        }));
      })
      .then(function(results) {
        return results;
      });
  }

  function getCountryFilter(pgId) {
    return function populateCountries(rows) {

      if (countries) {
        return bindPatientLookup(rows, 'country', countries);
      }

      var headers = {
        Route: "MedSeek.Portal.Module.SharedLookupProvider.ISharedLookupBusinessService.GetCountries",
        Contract: "MedSeek.Portal.Module.SharedLookupProvider.ISharedLookupBusinessService, MedSeek.Portal.Module.SharedLookupProvider",
        Method: "GetCountries",
        ParameterTypes: [],
        Service: "ISharedLookupBusinessService"
      };
      return microservices.call('Empower.Api.Proxy.' + pgId, {}, headers)
        .then(function(data) {
          countries = data.Retval;
          return bindPatientLookup(rows, 'country', countries);
        });
    };
  }

  function getStateFilter(pgId) {
    return function populateStates(rows) {
      if (states) {
        return bindPatientLookup(rows, 'state', states);
      }
      var headers = {
        Route: "MedSeek.Portal.Module.SharedLookupProvider.ISharedLookupBusinessService.GetStates",
        Contract: "MedSeek.Portal.Module.SharedLookupProvider.ISharedLookupBusinessService, MedSeek.Portal.Module.SharedLookupProvider",
        Method: "GetStates",
        ParameterTypes: ["System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"],
        Service: "ISharedLookupBusinessService"
      };
      return microservices.call('Empower.Api.Proxy.' + pgId, {}, headers)
        .then(function(data) {
          states = data.Retval;
          return bindPatientLookup(rows, 'state', states);
        });
    };
  }

  function bindPatientLookup(rows, property, source) {
    log.trace('binding patient lookup property', property);
    log.trace('bindPatientLookup| source', source);
    rows.forEach(function(dr, idx) {
      if (dr[property])
        dr[property] = _.find(source, {
          UniqueId: dr[property].toString()
        }).Name;
    });
    log.trace('rows',rows);
    return rows;
  }

  function getWhere(req) {
    var where = '';

    if (req.id) {
      where += ' WHERE id = @id';
    }

    if (req.uniqueId) {
      where += (req.id ? ' AND' : ' WHERE') + ' uniqueId = @uniqueId';
    }
    return where;
  }

  function getWhereParameters(req) {
    var params = {};
    Object.keys(req).forEach(function(k, i) {
      if (availableQueryParameters.indexOf(k) > -1) {
        params[k] = qp(req[k]);
      }
    });
    return params;
  }



  function qp(value) {
    return {
      type: 'NVarChar',
      value: value,
      length: value.length
    };
  }

  function toMssqlConfig(uri) {
    var parsed = url.parse(uri, true);
    if (parsed.protocol !== 'mssql:')
      throw new Error('Unsupported protocol: ' + parsed.protocol);
    var authParts = parsed.auth ? _.compact(parsed.auth.split(':')) : [];
    var hostParts = _.compact(parsed.host.split(':'));
    var pathParts = _.compact(parsed.pathname.split('/'));
    var config = {
      server: parsed.hostname,
      port: hostParts.length > 1 ? hostParts[1] : undefined,
      user: parsed.auth && parsed.auth.length > 0 ? authParts[0] : undefined,
      password: parsed.auth && parsed.auth.length > 1 ? authParts[1] : undefined,
      database: _.first(pathParts),
      options: parsed.query
    };
    if (pathParts.length > 1) {
      config.server += '\\' + pathParts[0];
      config.database = pathParts[1];
    }
    _.forEach(parsed.query, function(x, k, o) {
      var s = ('' + x).toLowerCase();
      if (s === 'true' || s === 'false') {
        o[k] = s === 'true';
      }
    });
    _.defaults(config, (db || {}).config);
    log.debug('toMssqlConfig| uri: %s, config:', uri, config);
    return config;
  }
});
