'use strict';
var chai = require('chai');
chai.use(require('chai-as-promised'));
chai.use(require('sinon-chai'));
var expect = chai.expect;
var Promise = require('bluebird');
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var _ = require('lodash');
var util = require('util');
var moment = require('moment');
var fs = require('fs');
var profile;
var cl = JSON.parse(fs.readFileSync(__dirname + '/mocks/claims.json').toString()).Claims;
var titles = JSON.parse(fs.readFileSync(__dirname + '/mocks/titles.json').toString());
var suffixes = JSON.parse(fs.readFileSync(__dirname + '/mocks/suffix.json').toString());
var countries = JSON.parse(fs.readFileSync(__dirname + '/mocks/countries.json').toString());
var states = JSON.parse(fs.readFileSync(__dirname + '/mocks/states.json').toString());
var genders = JSON.parse(fs.readFileSync(__dirname + '/mocks/genders.json').toString());
var linkedProfiles = JSON.parse(fs.readFileSync(__dirname + '/mocks/linkedProfiles.json').toString());
var userProfile = JSON.parse(fs.readFileSync(__dirname + '/mocks/userProfile.json').toString());
describe('empower-ip-claims.js',function(){
  var claims,mockMs,mockLog,mockMicroservices,options,mockLogger;
  beforeEach(function(){
    linkedProfiles = JSON.parse(fs.readFileSync(__dirname + '/mocks/linkedProfiles.json').toString());
    profile = JSON.parse(fs.readFileSync(__dirname + '/mocks/profile.json').toString()).Retval;
    mockMs = sinon.stub();
    mockLog = sinon.stub({
      debug: function(){},
      error: function(){},
      trace: function(){}
    });
    mockLogger = {
      getLogger: function(){
        return mockLog;
      }
    };
    mockMicroservices = sinon.stub({
      bind: function(){},
      call: function(){}
    });
    options = {};
    mockMs.yields(undefined,mockLogger,mockMicroservices,Promise,options,require('url'),_,moment,util);
    claims = proxyquire.noCallThru()('../empower-ip-claims.js',{
      'ih-microservice': mockMs
    });

  });
  describe('getClaims',function(){
    describe('getLinkedProfilesClaimsData',function(){
    
    });

    describe('getProfileClaimsData',function(){
    
    });
    
    describe('getCurrentPatientClaimsData',function(){
      
      describe('getSourceId',function(){
        it('should get the sourceId',function(){
          
          var sourceId = claims.getSourceId(profile,'Test',cl);
          expect(sourceId.value).to.equal('123456');
        });
        it('should not get the sourceId if not found',function(){
          var sourceId = claims.getSourceId(profile,'Test1',cl);
          expect(sourceId).to.be.undefined;
        });
      });
      
      describe('getInternalId',function(){
        it('should populate the internal Id for a claim',function(){
          var internalId = claims.getInternalId(profile,cl);
          expect(internalId.value).to.equal('bbf45203-d9a3-4199-8e6f-5b2b64c41a9f');
        });
      });
      
      describe('getFirstName',function(){
        it('should populate the firstName',function(){
          var fn = claims.getFirstName(profile,cl);
          expect(fn.value).to.equal('Rajesh');
        });
        it('should have the correct claim name',function(){
          var fn = claims.getFirstName(profile,cl);
          expect(fn.name).to.equal('http://schemas.medseek.com/ws/2012/06/profile/currentpatient/claims/CurrentPatientFirstName');
        });
      });

      describe('getLasttName',function(){
        it('should populate the lastName',function(){
          var fn = claims.getLastName(profile,cl);
          expect(fn.value).to.equal('Sajda');
        });
      });

      describe('getDateOfBirth',function(){
        it('should populate the DateOfBirth',function(){
          var fn = claims.getDOB(profile,cl);
          expect(fn.value).to.equal('1947-08-07T00:00:00');
        });
      });

      describe('getIds',function(){
        it('should populate the ids',function(){
          var fn = claims.getIds(profile,cl);
          var ids = [
            { AssigningFacility: 'Test', Id: '123456'},
            { AssigningFacility: 'ADT', Id: 'E849'},
            { AssigningFacility: 'ExternalGroup', Id: '123456'}
          ];
          expect(JSON.parse(fn.value)).to.deep.equal(ids);
        });
      });

      describe('getProfile',function(done){
        var req;
        beforeEach(function(){
          req = {
            portalGroup: '123'
          };
          var looks = Promise.resolve({Retval:[{
            UniqueId: '1009',
            Name: 'Colorado'
          },{
            UniqueId: '2',
            Name: 'Male'
          },{
            UniqueId: '102',
            Name: 'United States'
          }

          ]});
          mockMicroservices.call.returns(looks);
          mockMicroservices.call.onCall(3).returns(Promise.resolve(titles));
          mockMicroservices.call.onCall(4).returns(Promise.resolve(suffixes));
        });
        it('should populate the profile',function(done){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value)).to.deep.be.an('object');
            done();
          }).catch(done);
        });
        
        it('should have a valid gender value',function(done){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).Gender).to.equal('Male');
            done();         
          }).catch(done);
        });
        it('should have a valid state value',function(done){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).State).to.equal('Colorado');
            done();         
          }).catch(done);
        });
        it('should have a valid country value',function(done){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).Country).to.equal('United States');
            done();         
          }).catch(done);
        });
        it('should have a valid country value',function(done){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).Country).to.equal('United States');
            done();         
          }).catch(done);
        });
        it('should format the DateOfBirth to the c# ShortDateString equiv',function(d){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).DateOfBirth).to.equal('8/7/1947');
            d();         
          }).catch(d);
        });
        it('should populate the title',function(d){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).Title).to.equal('Mr.');
            d();         
          }).catch(d);
        });
        it('should populate the suffixes',function(d){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).Suffix).to.equal('Ph.D.');
            d();         
          }).catch(d);
        });
        it('should populate the race',function(d){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).Race).to.equal('Indian');
            d();         
          }).catch(d);
        });
        it('should set the lastUpdated on to c# ShortDateString',function(d){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).LastUpdatedOn).to.equal('7/16/2015');
            d();         
          }).catch(d);
        });
        it('should set the createdOn on to c# ShortDateString',function(d){
          claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).CreatedOn).to.equal('7/16/2015');
            d();         
          }).catch(d);
        });
        it('should set the Id to string',function(d){
           claims.getProfile(profile,cl,req).then(function(fn){
            expect(JSON.parse(fn.value).Id).to.equal('1');
            d();         
          }).catch(d);
        });
      });

      describe('getEmail',function(){
        it('should populate the Email',function(){
          var fn = claims.getEmail(profile,cl);
          expect(fn.value).to.equal('registered@email.com');
        });
      });

    });

    describe('buildClaim',function(){
      it('should return an object with name',function(){
        var c = {
          ClaimName: 'firstName'
        };
        var claim = claims.buildClaim(c,'greg','string');
        expect(claim.name).to.equal('firstName');
      });
      it('should return an object with value',function(){
        var obj = {
          ClaimName: 'firstNadme'
        };
        var claim = claims.buildClaim(obj,'greg','string');
        expect(claim.value).to.equal('greg');
      });
    });
    describe('getPatientClaims',function(){
      var req;
      beforeEach(function(){
        req = {claims: cl, userId: 1, sourceAssigningFacility: 'Test'};
        mockMicroservices.call.onCall(0).returns(Promise.resolve({Retval:profile}));
        mockMicroservices.call.onCall(1).returns(Promise.resolve(countries));
        mockMicroservices.call.onCall(2).returns(Promise.resolve(states));
        mockMicroservices.call.onCall(3).returns(Promise.resolve(genders));
        mockMicroservices.call.onCall(4).returns(Promise.resolve(titles));
        mockMicroservices.call.onCall(5).returns(Promise.resolve(suffixes));
        mockMicroservices.call.onCall(6).returns(Promise.resolve(states));
      });
      it('should return 8 claims',function(d){
        claims.getPatientClaims(req).then(function(data){
          expect(data.length).to.equal(8);
          d();
        }).catch(d);
      });
      it('should populate the sourceId',function(d){
        claims.getPatientClaims(req).then(function(data){
          var claim = _.find(data,{ key: 'SourceId'});
          expect(claim).to.be.an('object');
          d();
        }).catch(d);
      });
      it('should populate the internalId',function(d){
        claims.getPatientClaims(req).then(function(data){
          var claim = _.find(data,{ key: 'InternalId'});
          expect(claim).to.be.an('object');
          d();
        }).catch(d);
      });
      it('should populate the firstName',function(d){
        claims.getPatientClaims(req).then(function(data){
          var claim = _.find(data,{ key: 'FirstName'});
          expect(claim).to.be.an('object');
          d();
        }).catch(d);
      });
      it('should populate the lastName',function(d){
        claims.getPatientClaims(req).then(function(data){
          var claim = _.find(data,{ key: 'LastName'});
          expect(claim).to.be.an('object');
          d();
        }).catch(d);
      });
      it('should populate the dateOfBirth',function(d){
        claims.getPatientClaims(req).then(function(data){
          var claim = _.find(data,{ key: 'DateOfBirth'});
          expect(claim).to.be.an('object');
          d();
        }).catch(d);
      });
      it('should populate the email',function(d){
        claims.getPatientClaims(req).then(function(data){
          var claim = _.find(data,{ key: 'Email'});
          expect(claim).to.be.an('object');
          d();
        }).catch(d);
      });
      it('should populate the ids',function(d){
        claims.getPatientClaims(req).then(function(data){
          var claim = _.find(data,{ key: 'Ids'});
          expect(claim).to.be.an('object');
          d();
        }).catch(d);
      });
      it('should populate the profile',function(d){
        claims.getPatientClaims(req).then(function(data){
          var claim = _.find(data,{ key: 'Profile'});
          expect(claim).to.be.an('object');
          d();
        }).catch(d);
      });
    });
    describe('getCurrentPatient',function(){
      var req;
      beforeEach(function(){
        req = {
          userId: 1
        }
        mockMicroservices.call.returns(Promise.resolve({Retval:profile}));
      });
      it('should get the empower current patient',function(d){
        claims.getCurrentPatient(req).then(function(p){
          expect(p).to.equal(profile);
          d();
        }).catch(d);
      })
    });
    describe('getUserClaimData',function(){
      var req;
      beforeEach(function(){
        req = {
          userId: 5,
          portalGroup: '12345',
          claims: cl
        };
        mockMicroservices.call.returns(Promise.resolve(userProfile));
        claims.countries = toLookup(countries.Retval);
        claims.states = toLookup(states.Retval);
        claims.genders = toLookup(genders.Retval);
        claims.suffixes = toLookup(suffixes.Retval);
        claims.titles = toLookup(titles.Retval);
      });
      it('should return a collection of claims',function(d){
        claims.getUserClaims(req).then(function(c){
          expect(c.length).to.equal(5);
          d();
        }).catch(d);
      });
    });
    describe('getLinkedProfilesClaims',function(){
      var req;
      beforeEach(function(){
        
        req = {
          userId: 5,
          portalGroup: '12345',
          claims: cl
        };
        mockMicroservices.call.returns(Promise.resolve(linkedProfiles));
        claims.countries = toLookup(countries.Retval);
        claims.states = toLookup(states.Retval);
        claims.genders = toLookup(genders.Retval);
        claims.suffixes = toLookup(suffixes.Retval);
        claims.titles = toLookup(titles.Retval);
      });
      it('should return the json linked profiles claim as the value',function(d){
        claims.getLinkedProfileClaims(req).then(function(claim){
          expect(JSON.parse(claim.value)).to.be.an('array');
          d();
        }).catch(d);
      });
      it('should return profiles when ProfileCurrentPatient claim is not present',function(d){
        _.remove(req.claims,{ ProviderKey: 'ProfileCurrentPatient', ClaimKey: 'Profile'});
        claims.getLinkedProfileClaims(req).then(function(claim){
          expect(JSON.parse(claim.value)).to.be.an('array');
          d();
        }).catch(d);
      });
    });
  });
});

function toLookup (arr){
  var arr = _.map(arr,function(val){
    return {
      value: val.Name,
      key: val.UniqueId
    }
  });
  return arr;
}