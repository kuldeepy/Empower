'use strict';

var crutch = require('ih-microservice');

var defaults = {
    id: 'empower-ip-claims',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'empower-ip-claims',
    defaultReturnBody: true,
    pageSize: '20'
};

crutch(defaults, function(app, logging, microservices, Promise, options, url, _, moment) {


  Array.prototype.findClaim = function(name,providerKey){
    var selector = { ClaimKey: name};
    if(providerKey){
      selector.ProviderKey = providerKey;
    }
    var claim = _.find(this, selector);
    return claim;
  };

  var log = logging.getLogger(defaults.id),countries, states,genders,titles,suffixes,mod;

  function getCountries(req){
    return countries ? Promise.resolve(countries) :  (getLookup(req,'GetCountries').then(function(r){
      log.trace('countries',r);      
      countries = r;
      return countries;
    }));
  }

  function getStates(req){
    return states ? Promise.resolve(states) : (Promise.reduce(['GetUSStates','GetCAProvinces'], function(total,method){
      return getLookup(req,method).then(function(states){
        log.trace('states',states);
        return states.concat(total);
      });
    },[]).then(function(r){
      states = r;
      return states;
    }));
  }

  function getGenders(req){
    return genders ? Promise.resolve(genders) : (getLookup(req,'GetGenders').then(function(r){
      log.trace('genders',r);
      genders = r;
      return genders;
    }));
  }

  function getProfileLookup(req,key){
    return microservices.call('Empower.Api.Proxy.' + req.portalGroup,{
      profileLookupType: key
    },{
      Route: 'MedSeek.Portal.Module.ProfileProvider.IProfileProviderManager.GetProfileLookupList',
      Contract: 'MedSeek.Portal.Module.ProfileProvider.IProfileProviderManager, MedSeek.Portal.Module.ProfileProvider',
      Method: 'GetProfileLookupList',
      ParameterTypes: [
        'System.String'
      ],
      Service: 'IProfileProviderManager'
    });
  }
  
  function getTitles(req){
    return titles ? Promise.resolve(titles) : (getProfileLookup(req,'ProfileTitle')
    .then(function(r){
      log.trace('titles',r);
      
      titles = r.Retval;
      return titles;
    }));
  }

  function getSuffix(req){
    return suffixes ? Promise.resolve(suffixes) : (getProfileLookup(req,'ProfileTitle')
    .then(function(r){
      log.trace('suffixes',r);
      suffixes = r.Retval;
      return suffixes;
    }));
  }

  function getLookup(req,key){
    if(!key){
      throw new Error('all arguments are required');
    }
    return microservices.call('Empower.Api.Proxy.' + req.portalGroup,{},{
      Route: 'MedSeek.Portal.Module.SharedLookupProvider.ISharedLookupBusinessService.' + key,
      Contract: 'MedSeek.Portal.Module.SharedLookupProvider.ISharedLookupBusinessService, MedSeek.Portal.Module.SharedLookupProvider',
      Method: key,
      ParameterTypes: [],
      Service: 'ISharedLookupBusinessService'
    }).then(function(r){
      return _.map(r.Retval,function(g){
        return {
          key: g.UniqueId,
          value: g.Name
        };
      });
    });
  }
  
  function getPatientClaims(req){
    log.debug('enter: getPatientClaims');
    return getCurrentPatient(req).then(function(p){
      log.debug('getCurrentPatient: p');
      if(!p){
        return Promise.resolve();
      }
      return Promise.all([
          getSourceId(p,req.sourceAssigningFacility,req.claims),
          mod.getInternalId(p,req.claims),
          mod.getFirstName(p,req.claims),
          mod.getLastName(p,req.claims),
          mod.getDOB(p,req.claims),
          mod.getEmail(p,req.claims),
          mod.getIds(p,req.claims),
          mod.getProfile(p,req.claims,req)
                          ]).then(function(claims){
        log.debug('getPatientClaims',claims);
        return _.flatten(claims);
      }).catch(function(err){
        log.error(err);
        throw err;
      });
    });
  }

  function getUserClaims(req){
    var profileClaims = _.find(req.claims,{ProviderKey:'UserProfileData'});
    return !profileClaims ? Promise.resolve() : (microservices.call('Empower.Api.Proxy.' + req.portalGroup,{portalUserId: req.userId},
      {
        'Route': 'MedSeek.Portal.Module.Profile.Shared.IProfileManager.GetPortalUser',
        'Contract': 'MedSeek.Portal.Module.Profile.Shared.IProfileManager, MedSeek.Portal.Module.Profile.Shared',
        'Method': 'GetPortalUser',
        'ParameterTypes': [
          'System.String'
        ],
        'Service': 'IProfileManager'
      }
      ).then(function(r){
        return r.Retval;
      })
      .then(function(profile){
        return Promise.all([
          mod.getUserFirstName(profile,req.claims),
          mod.getUserLastName(profile,req.claims),
          mod.getUserEmail(profile,req.claims),
          mod.getUsername(profile,req.claims),
          getUserProfile(profile,req.claims,req)]);
      }));
  }

  function getUserProfile(profile,claims,req){
    return Promise.all([getCountries(req),getStates(req),getGenders(req),getTitles(req),getSuffix(req)]).then(function(){
      var address = _.first(profile.Addresses) || { State: '', Country: ''};
      var p = {};
      p.FirstName = profile.FirstName;
      p.MiddleName = profile.MiddleName;
      p.LastName = profile.LastName;
      p.EmailAddress = profile.EmailAddress;
      p.Address1 = address.Address1;
      p.Address2 = address.Address2;
      p.City = address.City;
      p.ZipCode = address.ZipCode;
      p.State = (_.find(states,{ key: address.State.toString()}) || {}).value;
      p.Country = (_.find(countries,{ key: address.Country.toString()}) || {}).value;
      p.Gender = (_.find(genders,{ key: profile.Gender }) || {}).value;
      p.DateOfBirth = moment(profile.DateOfBirth).format('M/D/YYYY');
      p.LastUpdatedOn = moment(profile.LastUpdatedOn).format('M/D/YYYY');
      p.CreatedOn = moment(profile.CreatedOn).format('M/D/YYYY');
      p.Title = (_.find(titles,{ UniqueId: profile.Title.toString()}) || {}).Name;
      p.Suffix = (_.find(suffixes,{ UniqueId: profile.Suffix.toString()}) || {}).Name;
      p.Race = profile.RaceDisplay;
      p.Id = profile._id.toString();
      p.EveningPhone = (_.find(profile.PhoneNumbers,{PhoneType:4001}) || {}).PhoneNumber;
      p.DaytimePhone = (_.find(profile.PhoneNumbers,{PhoneType:4002}) || {}).PhoneNumber;
      p.MobilePhone = (_.find(profile.PhoneNumbers,{PhoneType:4003}) || {}).PhoneNumber;
      return buildClaim(claims.findClaim('UserProfile','UserProfileData'),JSON.stringify(p));
    });
  }

  function getProfile(profile,claims,req,skipBuildClaim){
    return Promise.all([getCountries(req),getStates(req),getGenders(req),getTitles(req),getSuffix(req)]).then(function(){
      profile.Gender = (_.find(genders,{ key: profile.Gender.toString() }) || {}).value;
      profile.State = (_.find(states,{ key: profile.State.toString()}) || {}).value;
      profile.Country = (_.find(countries,{ key: profile.Country.toString()}) || {}).value;
      profile.DateOfBirth = moment(profile.DateOfBirth).format('M/D/YYYY');
      profile.LastUpdatedOn = moment(profile.LastUpdatedOn).format('M/D/YYYY');
      profile.CreatedOn = moment(profile.CreatedOn).format('M/D/YYYY');
      profile.Title = (_.find(titles,{ UniqueId: profile.Title.toString()}) || {}).Name;
      profile.Suffix = (_.find(suffixes,{ UniqueId: profile.Suffix.toString()}) || {}).Name;
      profile.Race = profile.RaceDisplay;
      profile.Id = profile.Id.toString();
      delete profile.Image;
      delete profile.PatientsXmlData;
      return !skipBuildClaim ? buildClaim(claims.findClaim('Profile','ProfileCurrentPatient'),JSON.stringify(profile),'string') : profile;
    });
  }
  function getClaims(req){
    return Promise.all([getPatientClaims(req),getUserClaims(req),getLinkedProfileClaims(req)]).then(function(collection){
      log.debug('getClaims| collection',collection);
      return _.chain(collection).flatten().compact().value();
    }).catch(function(err){
      log.error(err);
      return err;
    });
  }

  function getLinkedProfileClaims(req){
    var linkedClaim = req.claims.findClaim('Profiles','LinkedProfiles');
    return !linkedClaim ? Promise.resolve() : (microservices.call('Empower.Api.Proxy.' + req.portalGroup,{portalUserId: req.userId},
      {
        'Route': 'MedSeek.Portal.Module.ProfileProvider.IProfileProviderManager.GetPatients',
        'Contract': 'MedSeek.Portal.Module.ProfileProvider.IProfileProviderManager, MedSeek.Portal.Module.ProfileProvider',
        'Method': 'GetPatients',
        'ParameterTypes': [
          'System.String'
        ],
        'Service': 'IProfileProviderManager'
      })
    .then(function(response){
        log.trace('getLinkedProfileClaims| linkedClaim',response);
        
        return Promise.map(response.Retval,function(profile){
          return getProfile(profile,req.claims,req,true);
        });
    })
    .then(function(mappedProfiles){
      return buildClaim(linkedClaim,JSON.stringify(mappedProfiles));
    }));
  }

  function buildClaim(claim,data){
    if(claim && (!(claim instanceof Object) || (claim instanceof Array))){
      throw Error('claim must be an object');
    }
    if(!claim){
      return;
    }
    var c = {
      providerKey: claim.ProviderKey,
      name: claim.ClaimName,
      value: data,
      key: claim.ClaimKey
    };
    log.trace('buildClaim| claim',c);
    return c;
  }
  
  function getCurrentPatient(req){
    log.trace('getCurrentPatient| enter');
    return microservices.call('Empower.Api.Proxy.' + req.portalGroup, { portalUserId: req.userId},
    {
      'Route': 'MedSeek.Portal.Module.ProfileProvider.IProfileProviderManager.GetCurrentPatientContext',
      'Contract': 'MedSeek.Portal.Module.ProfileProvider.IProfileProviderManager, MedSeek.Portal.Module.ProfileProvider',
      'Method': 'GetCurrentPatientContext',
      'ParameterTypes': [
        'System.String, mscorlib'
      ],
      'Service': 'IProfileProviderManager'
    }).then(function(r){
      log.trace('getCurrentPatient| exit');
      return r.Retval;
    });
  }

  function getSourceId(profile,sourceAssigningFacility,claims){
    var id = _.find(profile.ExternalIdentifiers,{SourceAssigningFacility:sourceAssigningFacility});
    var sourceId = (id || {}).SourceId;
    if(sourceId){
      return buildClaim(claims.findClaim('SourceId'),sourceId);
    }
  }

  function getIds(profile,claims){
    var ids = _.map(profile.ExternalIdentifiers,function(id){
      return {
        AssigningFacility: id.SourceAssigningFacility,
        Id: id.SourceId
      };
    });
    return buildClaim(claims.findClaim('Ids'),JSON.stringify(ids));
  }

  function buildSimpleExtractor(name,selector,patient){
    return function(profile,claims){
      if(profile[selector || name]){
        log.trace('claim',claims.findClaim(name,patient));
        return buildClaim(claims.findClaim(name,patient),profile[selector || name]);
      }
    };
  }

  function getUsername(profile,claims){
    return buildClaim(claims.findClaim('Username'),profile.UserName);
  }

  mod = module.exports = {
    getSourceId: getSourceId,
    getClaims: getClaims,
    getLinkedProfileClaims: getLinkedProfileClaims,
    buildClaim: buildClaim,
    getUsername: getUsername,
    getInternalId: buildSimpleExtractor('InternalId','MedseekId','ProfileCurrentPatient'),
    getFirstName: buildSimpleExtractor('FirstName',undefined,'ProfileCurrentPatient'),
    getLastName: buildSimpleExtractor('LastName',undefined,'ProfileCurrentPatient'),
    getDOB: buildSimpleExtractor('DateOfBirth',undefined,'ProfileCurrentPatient'),
    getEmail: buildSimpleExtractor('Email','EmailAddress','ProfileCurrentPatient'),
    getUserFirstName: buildSimpleExtractor('FirstName',undefined,'UserProfileData'),
    getUserLastName: buildSimpleExtractor('LastName',undefined,'UserProfileData'),
    getUserDOB: buildSimpleExtractor('DateOfBirth',undefined,'UserProfileData'),
    getUserEmail: buildSimpleExtractor('Email','EmailAddress','UserProfileData'),
    getIds: getIds,
    getProfile: getProfile,
    getPatientClaims: getPatientClaims,
    getCurrentPatient: getCurrentPatient,
    getUserClaims: getUserClaims,
    getUserProfile: getUserProfile,
    set states (val){
      states = val;
    },
    set genders (val){
      genders = val;
    },
    set titles (val){
      titles = val;
    },
    set suffixes (val){
      suffixes = val;
    },
    set countries (val){
      countries = val;
    },
  };
  return Promise.all([microservices.bind('empower.ip.claims.getClaims',getClaims)]);
});
