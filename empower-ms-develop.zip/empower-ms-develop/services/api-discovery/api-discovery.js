'use strict';

var crutch = require('ih-microservice');
var fs = require('fs');

var defaults = {
   id: 'api-discovery',
   defaultExchange: 'topic://medseek-api',
   defaultQueue: 'api-discovery',
   defaultReturnBody: true,
   address: 'http://localhost:3000'
};

module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise) {

 var log = logging.getLogger(defaults.id);

 return Promise.all([microservices.bind('service.discovery.api.endpoint.query',returnEndpoint)]);

 function returnEndpoint(req,mc){
   var service = { address: options.address, id: 'influence-api-endpoint' };
   log.debug('service',service);
   return service;
 }

});