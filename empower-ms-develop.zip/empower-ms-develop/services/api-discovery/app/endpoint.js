'use strict';

var microservices = require('ih-util-microservices');
var util = require('util');


module.exports = function(ops){
    var service = { address: ops.address, id: 'influence-api-endpoint' };
    
    console.log('Registering Microservice for api discovery:', service);
    microservices.useTransport(microservices.AmqpTransport, {
        defaultExchange: 'topic://' + ops.exchange,
        broker: ops.broker,
        debug: ops.debug
    });
    microservices.bind(ops.exchange + '/service.discovery.api.endpoint.query/api-discovery',function(mc) {
            console.log('[service.discovery.api.endpoint.query]', mc.deserialize());
            mc.reply(service);
        }).then(function(){
            microservices.send(ops.exchange + '/service.discovery.api.endpoint.announce.up', service);
        });

    ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK'].forEach(function(event) {
        process.once(event, function() {
            if (!service.isDown) {
                service.isDown = true;
                microservices.send(ops.exchange + '/service.discovery.api.endpoint.announce.down', service);
            }
        });
    });
}

