'use strict';
var micro = require('ih-microservice');
var xml2js = require('xml2js');

var defaults = {
  id: 'empower-user-permissions',
  debug: false,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-user-permissions',
  defaultReturnBody: true
};

micro(defaults, function(app, logging, options, microservices, Promise, _) {
  var log = logging.getLogger(options.id);

  var ROLE_PERMISSIONS_QUERY = 'SELECT g.[permissions], g.name FROM enAuthGroups g JOIN enAuthGroupMembers m ON m.enAuthGroupRef = g.ref WHERE m.enAuthRef = @userId AND g.portalId = @portalId;';
  var RELATIONSHIP_PERMISSIONS_QUERY = 'SELECT r.patientProfileId, a.[permissions], a.name as accessLevel, LOWER(s.Value) as [status], LOWER(r.relationshipClassification) as classification FROM nModProfileAuthUserRelationship r JOIN nModProfileAccessLevels a ON r.AccessLevelId = a.Id JOIN nModProfileLookup s ON r.[Status] = s.Id WHERE r.AuthUserId = @userId AND a.PortalId = @portalId;';
  var AOM_OVERRIDE_STATUS = 'age of majority override';
  var NO_PERMISSIONS_STATUSES = ['pending approval', 'suspended', 'suspended - age of majority override', 'inactive'];
  var SELF_RELATIONSHIP_CLASSIFICATION = 'self';

  return Promise.all([
    microservices.bind('empower.user-permissions.by-portal.#', _.wrap(permissionsByPortal, returnError))
  ]);

  /*
  Gets all permission ids that a user has in a portal, based on the assigned roles and access-levels.
  message params:
  {
    userId,
    portalId,
    authSessionId,
    iFrameHost (optional)
  }
  */
  function permissionsByPortal(message, mc) {
    log.info('findPermissions', message);
    var query = {
      q: ROLE_PERMISSIONS_QUERY + RELATIONSHIP_PERMISSIONS_QUERY,
      qp: {
        userId: {
          value: parseInt(message.userId, 10),
          type: 'Int'
        },
        portalId: {
          value: parseInt(message.portalId, 10),
          type: 'Int'
        }
      },
      multiple: true
    };
    return submitQuery(query, mc).then(function(results) {
      log.trace('results', results);
      return Promise.all([parseRolePermissions(results[0]), parseRelationshipPermissions(results[1], mc)]).then(function(parsedResults) {
        return getEmergencyAccessPermissions(message.authSessionId, mc).then(function(eaPermissions) {
          var fullPermissionSet = _.compact(parsedResults[0].concat(parsedResults[1]).concat(eaPermissions));
          return redact(fullPermissionSet, message, mc).then(function(finalSet) {
            return finalSet;
          });
        });
      });
    });
  }

  function parseRolePermissions(rows) {
    return Promise.all(rows.map(function(row) {
      var roleNameEntry = {
        permissionId: '_role.' + row.name
      };
      return toJson(row.permissions).then(function(permissions) {
        return [roleNameEntry].concat(permissions);
      });
    })).then(function(permissions) {
      return _.uniq(_.pluck(_.union.apply(_, permissions), 'permissionId'));
    });
  }

  function parseRelationshipPermissions(relationships, mc) {
    return Promise.all(relationships.map(function(rel) {
      var accessLevelName = (rel.accessLevel && rel.accessLevel.length > 0) ? rel.accessLevel : 'Custom';
      var info = '_' + rel.patientProfileId + '.relationship-access-level.' + accessLevelName + '.' + rel.status + '.' + rel.classification;
      if (_.contains(NO_PERMISSIONS_STATUSES, rel.status)) {
        return [info];
      }
      return getAomRule(rel, mc).then(function(rule) {
        if (rule.Permissions) {
          info = '_' + rel.patientProfileId + '.aom-rule.' + (rule.State || 'Default') + '.' + rule.Name;
          return [info].concat(mapPatientIdPermissions(rule.Permissions, rel.patientProfileId));
        } else {
          return toJson(rel.permissions).then(function(permissions) {
            return [info].concat(mapPatientIdPermissions(permissions, rel.patientProfileId));
          });
        }
      });
    })).then(function(permissionsArrays) {
      return _.flatten(permissionsArrays);
    });
  }

  function mapPatientIdPermissions(permissions, patientId) {
    return permissions.map(function(permissionId) {
      return patientId + '.' + permissionId;
    });
  }

  function getAomRule(relationship, mc) {
    log.debug('checking for an AOM rule for patientId %s, status %s, classification %s', relationship.patientProfileId, relationship.status, relationship.classification);
    if (relationship.status === AOM_OVERRIDE_STATUS) {
      log.debug('AOM override status detected', AOM_OVERRIDE_STATUS);
      return Promise.resolve({});
    }
    if (relationship.classification === SELF_RELATIONSHIP_CLASSIFICATION) {
      log.debug('Self relationship detected', relationship.classification);
      return Promise.resolve({});
    }
    return microservices.call('empower.age-of-majority.rule.for-patient.' + getPortalGroupId(mc), {
      patientId: relationship.patientProfileId
    }).then(function(rule) {
      checkError(rule);
      if (rule.Permissions) {
        log.debug('got AOM rule %s for patientId %s', rule.Name, relationship.patientProfileId);
      }
      return rule;
    });
  }

  function toJson(permissionsXml) {
    if (!permissionsXml) {
      return Promise.resolve([]);
    }
    var parser = new xml2js.Parser({
      explicitArray: false
    });
    return Promise.promisify(parser.parseString)(permissionsXml).then(function(res) {
      var permissions = res.permissions.permission;
      if (_.isArray(permissions)) {
        return permissions;
      }
      return [permissions];
    }).catch(function() {
      return [];
    });
  }

  function getEmergencyAccessPermissions(authSessionId, mc) {
    if (!authSessionId) {
      return Promise.resolve([]);
    }
    return getEmergencyAccessPatientId(authSessionId, mc).then(function(patientId) {
      if (!patientId) {
        return Promise.resolve([]);
      }
      return getPatientEmergencyAccessPermissions(patientId);
    });
  }

  function getEmergencyAccessPatientId(authSessionId, mc) {
    log.debug('checking for an Emergency Access Session for authSessionId:', authSessionId);
    return microservices.call('empower.emergency-access-session.find-current.' + getPortalGroupId(mc), {
      authSessionId: authSessionId
    }).then(function(session) {
      checkError(session);
      if (session.patientId) {
        log.info('Got emergency access session for patientId %s', session.patientId);
        return session.patientId;
      }
      return null;
    });
  }

  function getPatientEmergencyAccessPermissions(patientId) {
    log.debug('getting emergency access permissions for patientId:', patientId);
    return microservices.call('empower.permissions.by-portal-type', {
      portalType: 'staff',
      flatten: true,
      emergencyAccess: true
    }).then(function(permissions) {
      checkError(permissions);
      if (permissions.length > 0) {
        var info = '_' + patientId + '.EMERGENCY_ACCESS';
        return [info].concat(mapPatientIdPermissions(permissions, patientId));
      }
      return [];
    });
  }

  function redact(initialPermissionSet, message, mc) {
    if (!message.iFrameHost) {
      return Promise.resolve(initialPermissionSet);
    }
    return redactPermissionsByIFrameHost(initialPermissionSet, message, mc);
  }

  function redactPermissionsByIFrameHost(initialPermissionSet, message, mc) {
    log.info('redacting permissions by iFrameHost', message.iFrameHost);
    log.debug('initial set', initialPermissionSet.length);
    var redactedSet = ['_Permissions redacted for IFrame Host: ' + message.iFrameHost];
    return microservices.call('empower.iframe.portal-white-lists.get.' + getPortalGroupId(mc), {
      portalId: message.portalId
    }).then(function(whiteList) {
      checkError(whiteList);
      var allowedHost = _.find(whiteList, function(e) {
        return e.iFrameHost.toLowerCase() === message.iFrameHost.toLowerCase();
      });
      if (allowedHost) {
        log.debug('allowedHost', allowedHost.iFrameHost);
        return getPermissionsByModules(allowedHost.availableModules).then(function(modulePermissions) {
          log.debug('got permissions based on modules', modulePermissions.length);
          redactedSet = redactedSet.concat(_.filter(initialPermissionSet, function(initialPermission) {
            var permissionId = getNonPatientScopedPermissionId(initialPermission);
            return initialPermission.charAt(0) === '_' || _.contains(modulePermissions, permissionId);
          }));
          log.debug('redactedSet', redactedSet.length);
          return redactedSet;
        });
      }
      log.debug('unknown host', message.iFrameHost)
      return redactedSet;
    });
  }

  function getPermissionsByModules(modules) {
    return microservices.call('empower.permissions.get-unioned-flattened-components', {})
      .then(function(components) {
        log.debug('got components', components.length);
        checkError(components);
        var permissions = [];
        modules.forEach(function(module) {
          log.debug('checking module', module.key, module.permissionComponent);
          var component = _.find(components, {
            id: module.permissionComponent
          });
          if (component) {
            permissions.push(component.id);
            permissions = permissions.concat(component.permissions);
          }
        });
        return permissions;
      });
  }

  function getNonPatientScopedPermissionId(permission) {
    if (permission.indexOf('.') === -1) {
      return permission;
    }
    var parts = permission.split('.');
    if (!isNaN(parts[0])) {
      return parts.slice(1).join('.');
    }
    return permission;
  }

  function submitQuery(queryObj, messageContext) {
    log.debug('submitting query', queryObj.q);
    var portalGroupId = getPortalGroupId(messageContext);
    return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, queryObj)
      .then(function(results) {
        checkError(results);
        return results;
      });
  }

  function getPortalGroupId(messageContext) {
    return _.last(messageContext.routingKey.split('.'));
  }

  function checkError(results) {
    if (typeof(results.error) !== 'undefined') {
      throw new Error('Error from call: ' + results.error);
    }
  }

  function returnError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }

});