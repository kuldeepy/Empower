'use strict';

var micro = require('ih-microservice');

var defaults = {
  id: 'empower-sms-inbound',
  debug: false,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-sms-inbound',
  defaultReturnBody: true
};

micro(defaults, function (app, logging, microservices, bluebird, _) {
  var Promise = bluebird;
  var log = logging.getLogger(defaults.id);

  return Promise.all([
		microservices.bind('empower.sms.inbound', _.wrap(inboundmessageinsert, errorWrap)),
    microservices.bind('empower.sms.status', _.wrap(inboundstatusupdate, errorWrap))
  ]);

  function inboundstatusupdate(message) {
    log.trace('inbound update call');
    var updateQuery = 'UPDATE nModInboundMessage' +
                      ' SET ' +
                      ' Status = @status, ' +
                      ' ExceptionMessage = @exceptionMessage' +
                      ' WHERE MessageId = @messageId';

    log.trace('update inbound message', message);

    var queryObject = {
      q: updateQuery,
      qp: {
        messageId: {
          value: message.MessageId,
          type: 'VarChar'
        },
        status: {
          value: (message.Status || null),
          type: 'VarChar'
        },
        exceptionMessage: {
          value: (message.ExceptionMessage || null),
          type: 'VarChar'
        }
      }
    };

    return submitQuery(queryObject, message)
    .then(function (updateResult) {
      return updateResult;
    });
  };

  function inboundmessageinsert(message) {
    log.trace('inbound call');
    var insertQuery = 'INSERT INTO nModInboundMessage' +
                      ' (Id, TenantId, MessageId, [From], [To], Status, ApiBaseUrl, PortalGroupId, Body, ExceptionMessage)' +
                      ' VALUES(NEWID(), @tenantId, @messageId, @from, @to, @status, @apiBaseUrl, @portalGroupId, @body, @exceptionMessage);';

    log.trace('create inbound message', message);

    var queryObject = {
      q: insertQuery,
      qp: {
        tenantId: {
          value: (message.TenantId || null),
          type: 'VarChar'
        },
        messageId: {
          value: (message.MessageId || null),
          type: 'VarChar'
        },
        from: {
          value: (message.From || null),
          type: 'VarChar'
        },
        to: {
          value: (message.To || null),
          type: 'VarChar'
        },
        status: {
          value: (message.Status || null),
          type: 'VarChar'
        },
        apiBaseUrl: {
          value: (message.ApiBaseUrl || null),
          type: 'VarChar'
        },
        portalGroupId: {
          value: (message.PortalGroupId || null),
          type: 'VarChar'
        },
        body: {
          value: (message.Body || null),
          type: 'VarChar'
        },
        exceptionMessage: {
          value: (message.ExceptionMessage || null),
          type: 'VarChar'
        }
      }
    };

    return submitQuery(queryObject, message)
    .then(function (insertResult) {
      return insertResult;
    });

  };

  function submitQuery(queryObj, messageContext) {
    log.trace('submitting query', queryObj);
    var routeKey = 'empower.v6.portal-groups.mssql.query.' + messageContext.PortalGroupId;
    log.trace('querying routeKey', routeKey);

    return microservices.call(routeKey, queryObj)
      .then(function (results) {
        checkError(results);
        return results;
      });
  };

  function checkError(results) {
    if (typeof (results.error) !== 'undefined') {
      throw new Error('Error running query: ' + results.error);
    }
  };

  function errorWrap(fn, message, mc) {
    return Promise.try(function () {
      return fn(message, mc);
    }).catch(function (err) {
      return {
        error: err.message
      };
    });
  };

});