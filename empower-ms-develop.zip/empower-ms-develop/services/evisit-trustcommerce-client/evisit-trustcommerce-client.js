'use strict';

var crutch = require('ih-microservice');
var https = require('https');

var defaults = {
    id: 'evisit-trustcommerce-client',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'evisit-trustcommerce-client',
    defaultReturnBody: true,
    pageSize: '20'
};

module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise) {

 	var log = logging.getLogger(defaults.id);
  return Promise.all([microservices.bind('empower.evisit.trustcommerce.client.post', postData)]);
  
  function postData(request) {
    
    return new Promise(function(resolve,reject){
      Promise.try(function(){
        var parsedUrl = url.parse(request.url);
        log.trace('parsedUrl',parsedUrl);
        var options = {
          hostname: parsedUrl.hostname,
          port: parseInt(parsedUrl.port,10),
          path: parsedUrl.pathname,
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Content-Length': request.data.length
          }
        };
        var responseStr = '';
        var req = https.request(options, function(res) {
          log.trace('STATUS: ' + res.statusCode);
          log.trace('HEADERS: ' + JSON.stringify(res.headers));
          res.setEncoding('utf8');
          res.on('data', function(d) {
            responseStr += d;
          });
          res.on('end', function(){
            var r = { response: responseStr};
            log.debug('resolving trustcommerce response',r);
            resolve(r);
          });
        });

        req.on('error', function(e) {
          log.error('problem with request: ' + e);
          reject(e);
        });
        req.write(request.data);
        req.end();
      })
      .catch(function(err){
        log.error('error processing request', err);
        reject(err);
      });
    });
    

  } 

});
