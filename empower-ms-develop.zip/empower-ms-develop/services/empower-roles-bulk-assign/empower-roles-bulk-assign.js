'use strict';
var micro = require('ih-microservice');
var util = require('util');

var defaults = {
  id: 'empower-roles-bulk-assign',
  debug: false,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-roles-bulk-assign',
  defaultReturnBody: true,
  defaultTimeout: 90000
};

micro(defaults, function(app, logging, options, microservices, Promise, _) {

  var log = logging.getLogger(options.id);

  var promiseFor = Promise.method(function(condition, action, value) {
    if (!condition(value)) {
      return value;
    }
    return action(value).then(promiseFor.bind(null, condition, action));
  });

  var QUERY_PAGE_SIZE = 100;
  var CALL_QUERY_TIMEOUT = 60000;
  var REQUEST_TIMEOUT = 59000;

  var ASSIGN_ALL_COMMAND =
    'BEGIN TRANSACTION;' +
    ' UPDATE u SET u.LastAuthGroupId = @roleId FROM enAuthUsers u' +
    '   JOIN enAuthGroups g ON g.ref= u.LastAuthGroupId' +
    '   JOIN CmsPortals p ON p.Id = g.portalId' +
    '     WHERE p.PortalType = @portalType AND u.deleted = 0 AND u.ref NOT IN' +
    '       (SELECT enAuthRef from enAuthGroupMembers WHERE enAuthGroupRef = @roleId);' +
    ' IF @@ERROR != 0 BEGIN ROLLBACK TRANSACTION RETURN END;' +
    '   INSERT INTO enAuthGroupMembers (enAuthGroupRef, enAuthRef, IsUser)' +
    '     SELECT @roleId, u.ref, 1 FROM enAuthUsers u ' +
    '       JOIN enAuthGroups g ON g.ref= u.LastAuthGroupId' +
    '       JOIN CmsPortals p ON p.Id = g.portalId' +
    '     WHERE p.PortalType = @portalType AND u.deleted = 0 AND u.ref NOT IN' +
    '       (SELECT enAuthRef from enAuthGroupMembers WHERE enAuthGroupRef = @roleId);' +
    ' IF @@ERROR != 0 BEGIN ROLLBACK TRANSACTION RETURN END; ' +
    'COMMIT TRANSACTION;';

  var UNASSIGN_ALL_COMMAND =
    'DELETE m FROM dbo.enAuthGroupMembers m JOIN dbo.enAuthUsers u ON m.enAuthRef = u.ref WHERE u.deleted = 0 AND m.enAuthGroupRef = @roleId AND m.IsUser = 1;';

  var ASSIGNABLE_COUNT_QUERY =
    'SELECT COUNT(*) as count FROM dbo.enAuthUsers u WITH (NOLOCK) JOIN dbo.enAuthGroups g WITH (NOLOCK) ON g.ref = u.LastAuthGroupId' +
    ' JOIN dbo.CmsPortals p WITH (NOLOCK) ON p.Id = g.portalId WHERE p.PortalType = @portalType AND u.deleted = 0 AND u.ref NOT IN' +
    ' (SELECT enAuthRef FROM dbo.enAuthGroupMembers WITH (NOLOCK) WHERE enAuthGroupRef = @roleId)';

  var UNASSIGNABLE_COUNT_QUERY =
    'SELECT COUNT(*) as count FROM dbo.enAuthGroupMembers m WITH (NOLOCK) JOIN dbo.enAuthUsers u WITH (NOLOCK) ON m.enAuthRef = u.ref WHERE u.deleted = 0 AND enAuthGroupRef = @roleId;';

  var PORTAL_TYPES = [{
    id: 1,
    name: 'portalgroupadmin'
  }, {
    id: 2,
    name: 'public'
  }, {
    id: 3,
    name: 'staff'
  }];

  return Promise.all([
    microservices.bind('empower.roles-bulk-assign.assignable-count.#', _.wrap(getAssignableCount, returnError)),
    microservices.bind('empower.roles-bulk-assign.unassignable-count.#', _.wrap(getUnassignableCount, returnError)),
    microservices.bind('empower.roles-bulk-assign.assign-all.#', _.wrap(assignAll, returnError)),
    microservices.bind('empower.roles-bulk-assign.assign-all-async.#', _.wrap(assignAllAsync, logError)),
    microservices.bind('empower.roles-bulk-assign.unassign-all.#', _.wrap(unassignAll, returnError)),
    microservices.bind('empower.roles-bulk-assign.unassign-all-async.#', _.wrap(unassignAllAsync, logError))
  ]);

  /*
    Gets a count of all available users that could be assigned to the role.
     expected message fields:
     {
      portalType,
      roleId (optional, can be undefined to return count of all users mapped to portal type)
     }
   */
  function getAssignableCount(message, mc) {
    log.debug('getAssignableCount', message);
    return submitQuery({
      q: ASSIGNABLE_COUNT_QUERY,
      qp: {
        portalType: {
          type: 'Int',
          value: mapPortalTypeId(message.portalType)
        },
        roleId: {
          type: 'Int',
          value: parseInt(message.roleId, 10)
        },
      }
    }, mc).then(function(results) {
      return {
        availableUsers: results[0].count
      };
    });
  }

  /*
    Gets a count of all available users that can be unassigned from the role.
     expected message fields:
     {
      roleId
     }
   */
  function getUnassignableCount(message, mc) {
    log.debug('getUnassignableCount', message);
    return submitQuery({
      q: UNASSIGNABLE_COUNT_QUERY,
      qp: {
        roleId: {
          type: 'Int',
          value: parseInt(message.roleId, 10)
        },
      }
    }, mc).then(function(results) {
      return {
        availableUsers: results[0].count
      };
    });
  }

  /*
    Assigns all matching users to the role, and replies.
     expected message fields:
     {
      portalId,
      portalType,
      roleId
     }
  */
  function assignAll(message, mc) {
    log.debug('assignAll', message);

    return submitQuery({
      q: ASSIGN_ALL_COMMAND,
      qp: {
        portalId: {
          type: 'Int',
          value: parseInt(message.portalId, 10)
        },
        portalType: {
          type: 'Int',
          value: mapPortalTypeId(message.portalType)
        },
        roleId: {
          type: 'Int',
          value: parseInt(message.roleId, 10)
        },
      },
      options: {
        requestTimeout: REQUEST_TIMEOUT
      }
    }, mc).then(function() {
      return {
        status: 'ok'
      };
    });
  }

  /*
    Assigns all matching users to the role, and notifies.
     expected message fields:
     {
      portalId,
      portalType,
      roleId,
      expectedCount,
      notifyAddress
     }
  */
  function assignAllAsync(message, mc) {
    log.info('assignAllAsync', message);

    var getUsersToAssign = function() {
      var totalPages = Math.ceil(message.expectedCount / QUERY_PAGE_SIZE);
      log.debug('querying for %s users in %s pages of %s', message.expectedCount, totalPages, QUERY_PAGE_SIZE);
      var users = [];
      return promiseFor(function(pageNumber) {
        return pageNumber <= totalPages;
      }, function(pageNumber) {
        log.debug('querying page ', pageNumber);
        return microservices.call('empower.v6.users.find.' + getPortalGroupId(mc), {
          portalTypeFilter: message.portalType,
          roleIdFilter: message.roleId,
          excludeRoleIdFilter: true,
          pageNumber: pageNumber,
          pageSize: QUERY_PAGE_SIZE
        }, {}, {
          timeout: defaults.defaultTimeout
        }).then(function(result) {
          checkError(result);
          log.debug('got %s results from page %s', result.users.length, pageNumber);
          result.users.forEach(function(user) {
            users.push(user);
          });
          pageNumber += 1;
          return pageNumber;
        });
      }, 1).then(function() {
        return users;
      });
    };

    return getUsersToAssign().then(function(allUsers) {
      log.debug('retrieved %s users', allUsers.length);
      log.debug('getting roles by portal', message.portalId);
      return microservices.call('empower.roles.find.by-target.' + getPortalGroupId(mc), {
        target: message.portalId.toString()
      }).then(function(rolesOfPortal) {
        checkError(rolesOfPortal);
        var roleIdsOfPortal = _.pluck(rolesOfPortal, 'id');
        log.debug('retrieved %s roles', rolesOfPortal.length);
        var actions = [];
        allUsers.forEach(function(user) {
          actions.push({
            command: 'add',
            userId: user.userId,
            roleId: message.roleId
          });
        });
        log.debug('sending bulk role actions', actions.length);
        return microservices.send('empower.user-roles.bulk-action-async.' + getPortalGroupId(mc), {
          actions: actions,
          notifyAddress: message.notifyAddress
        }).then(function() {
          log.info('sent bulk role actions', actions.length);
        });
      });
    });
  }

  /*
   UnAssigns all matching users from the role and replies.
     expected message fields:
     {
      roleId
     }
   */
  function unassignAll(message, mc) {
    log.debug('unassignAll', message);
    return submitQuery({
      q: UNASSIGN_ALL_COMMAND,
      qp: {
        roleId: {
          type: 'Int',
          value: parseInt(message.roleId, 10)
        },
      },
      options: {
        requestTimeout: REQUEST_TIMEOUT
      }
    }, mc).then(function() {
      return {
        status: 'ok'
      };
    });
  }

  /*
   UnAssigns all matching users from the role and notifies.
     expected message fields:
     {
      roleId,
      expectedCount,
      notifyAddress
     }
   */
  function unassignAllAsync(message, mc) {
   log.debug('unassignAllAsync', message);

    var getUsersToUnassign = function() {
      var totalPages = Math.ceil(message.expectedCount / QUERY_PAGE_SIZE);
      log.debug('querying for %s users in %s pages of %s', message.expectedCount, totalPages, QUERY_PAGE_SIZE);
      var users = [];
      return promiseFor(function(pageNumber) {
        return pageNumber <= totalPages;
      }, function(pageNumber) {
        log.debug('querying page ', pageNumber);
        return microservices.call('empower.v6.users.find.' + getPortalGroupId(mc), {
          roleIdFilter: message.roleId,
          pageNumber: pageNumber,
          pageSize: QUERY_PAGE_SIZE
        }, {}, {
          timeout: defaults.defaultTimeout
        }).then(function(result) {
          checkError(result);
          log.debug('got %s results from page %s', result.users.length, pageNumber);
          result.users.forEach(function(user) {
            users.push(user);
          });
          pageNumber += 1;
          return pageNumber;
        });
      }, 1).then(function() {
        return users;
      });
    };

    return getUsersToUnassign().then(function(allUsers) {
      log.debug('retrieved %s users', allUsers.length);

      var actions = allUsers.map(function(user) {
        return {
          command: 'remove',
          userId: user.userId,
          roleId: message.roleId
        };
      });
      log.debug('sending bulk role actions', actions.length);
      return microservices.send('empower.user-roles.bulk-action-async.' + getPortalGroupId(mc), {
        actions: actions,
        notifyAddress: message.notifyAddress
      }).then(function() {
        log.info('sent bulk role actions', actions.length);
      });
    });
  }

  function returnError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }

  function logError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
    });
  }

  function submitQuery(queryObj, messageContext) {
    var portalGroupId = getPortalGroupId(messageContext);
    return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, queryObj, {}, {
      timeout: CALL_QUERY_TIMEOUT
    }).then(function(results) {
      checkError(results);
      return results;
    });
  }

  function getPortalGroupId(messageContext) {
    return _.last(messageContext.routingKey.split('.'));
  }

  function checkError(results) {
    if (typeof(results.error) !== 'undefined') {
      throw new Error('Error running query: ' + results.error);
    }
  }

  function mapPortalTypeId(portalTypeName) {
    var portalType = _.find(PORTAL_TYPES, function(pt) {
      return pt.name === portalTypeName.toLowerCase();
    });
    if (portalType === undefined) {
      throw new Error('unknown portal type ' + portalTypeName);
    }
    return portalType.id;
  }

});
