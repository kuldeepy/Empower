'use strict';

var crutch = require('ih-microservice');
var defaults = {
  id: 'empower-users',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-users',
  defaultReturnBody: true,
  defaultTimeout: 10000,
  channelPrefetch: 0,
  pageSize: 20
};

module.exports = crutch(defaults, function(_, app, inject, logging, microservices, options, Promise, util) {
  var log = logging.getLogger(options.id);
  var roleIdMap = {};
  var PORTAL_TYPES = [{
    id: 1,
    name: 'portalgroupadmin'
  }, {
    id: 2,
    name: 'public'
  }, {
    id: 3,
    name: 'staff'
  }];

  return Promise
    .all([
      microservices.bind('empower.v6.users.create.#', create),
      microservices.bind('empower.v6.users.get.#', get),
      microservices.bind('empower.v6.users.retrieve.#', get),
      microservices.bind('empower.v6.users.update.#', update),
      microservices.bind('empower.v6.users.delete.#', delete_),
      microservices.bind('empower.v6.users.find.#', find)
    ])
    .then(function(result) {
      return options.send ? send() : result;
    });

  function create(request) {
    return {
      error: 'Not Implemented'
    };
  }

  function get(request, mc) {
    return microservices.call('empower.v6.portal-groups.get', {})
      .map(function(pg) {
        log.trace('get| portal-group:', pg);
        throw new Error('pain');
        return microservices // jshint ignore:line
          .call('empower.v6.portal-groups.mssql.query.' + pg.id, {
            q: 'SELECT ref, userName, email, gender, firstName, middleName, lastName, ldapDomain, ldapGuid, dateOfBirth, title, suffix, maritalStatus FROM enAuthUsers; ' +
              'SELECT u.ref as uid, g.*' +
              ' FROM enAuthUsers u, enAuthGroups g, enAuthGroupMembers m' +
              ' WHERE u.ref = m.enAuthRef AND g.ref = m.enAuthGroupRef',
            multiple: true,
          })
          .tap(function(results) {
            log.trace('get| query results:', util.inspect(results, {
              colors: true,
              depth: null
            }));
          })
          .then(function(results) {
            return _.map(results[0], function(u) {
              var groups = _.where(results[1], {
                uid: u.ref
              });
              var principal = toPrincipal(pg.id, 'user', u.ref);
              return _({
                  id: principal.id
                })
                .extend(u)
                .omit('ref')
                .omit(_.isNull)
                .omit(_.isUndefined)
                .extend({
                  principals: [principal].concat(_(groups)
                    .pluck('ref')
                    .map(_.partial(toPrincipal, pg.id, 'group'))
                    .value())
                })
                .value();
            });
          });
      })
      .reduce(function(r, results) {
        return r.concat(results);
      }, [])
      .then(function(result) {
        return result;
      })
      .then(toReply(get), toReply(get));
  }

  function find(request, mc) {
    log.debug('find', request);

    var portalGroupId = _.last(mc.routingKey.split('.'));

    function mapResults(res) {
      var grouped = _.groupBy(res, function(r) {
        return r.rowNumber;
      });
      var wound = Object.keys(grouped).map(function(key) {
        return _.extend(_.omit(grouped[key][0], 'groupId'), {
          roleIds: _.without(_.pluck(grouped[key], 'groupId'), null)
        });
      });
      return wound;
    }

    function makeQueryFilter(request) {
      var filter = '';
      if (request.portalTypeFilter && request.portalTypeFilter !== '') {
        var portalType = _.find(PORTAL_TYPES, function(pt) {
          return pt.name === request.portalTypeFilter.toLowerCase();
        });
        if (portalType === undefined) {
          throw new Error('unknown portal type ' + request.portalTypeFilter);
        }
        filter = ' JOIN enAuthGroups g ON g.ref = u.LastAuthGroupId JOIN CmsPortals p  ON p.Id = g.portalId WHERE p.PortalType = ' + portalType.id;
      }
      filter += (filter === '') ? ' WHERE' : ' AND';
      filter += ' u.deleted = 0';
      if (request.nameFilter && request.nameFilter !== '') {
        filter += ' AND';
        filter += " (u.username like '%" + request.nameFilter + "%' OR u.firstname LIKE '%" + request.nameFilter + "%' OR u.lastname LIKE '%" + request.nameFilter + "%')";
      }
      if (request.idFilter) {
        filter += ' AND';
        filter += ' u.ref = ' + request.idFilter + ' ';
      }
      if (request.roleIdFilter && request.roleIdFilter !== '') {
        filter += ' AND';
        var not = (request.excludeRoleIdFilter) ? 'NOT' : '';
        filter += ' u.ref ' + not + ' IN (SELECT enAuthRef FROM enAuthGroupMembers WHERE enAuthGroupRef = ' + request.roleIdFilter + ')';
      }
      return filter;
    }

    function rowNumberClause(request) {
      var pageSize = defaults.pageSize;
      if (request.pageSize) {
        pageSize = parseInt(request.pageSize, 10);
      }
      var pageNumber = 1;
      if (request.pageNumber) {
        pageNumber = parseInt(request.pageNumber, 10);
      }
      return ' WHERE p.rowNumber > ' +
        (pageSize * (pageNumber - 1)) +
        ' AND p.rowNumber < ' +
        ((pageSize * pageNumber) + 1);
    }

    return Promise.try(function() {
      var filter = makeQueryFilter(request);
      var query =
        'WITH pagedUsers AS (SELECT u.ref as userId, ROW_NUMBER() OVER(ORDER BY u.lastname, u.firstname, u.MiddleName) AS rowNumber' +
        ' FROM enAuthUsers u' + filter +
        ') SELECT p.rowNumber, u.ref as userId, u.userName, u.firstName, u.lastName, u.middleName, u.email, gm.enAuthGroupRef as groupId, gender, maritalStatus' +
        ' FROM enAuthUsers u' +
        ' LEFT JOIN enAuthGroupMembers gm ON gm.enAuthRef = u.ref' +
        ' INNER JOIN pagedUsers p ON p.userId = u.ref' + rowNumberClause(request) +
        ' ORDER BY p.rowNumber;' +
        ' SELECT COUNT(*) FROM enAuthUsers u' + filter;
      log.debug('query', query);
      return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, {
        q: query,
        multiple: true
      }).then(function(results) {
        if (results.error === undefined) {
          var users = mapResults(results[0]);
          return {
            users: users,
            totalUsers: _.first(_.values(results[1][0]))
          };
        } else {
          throw new Error(results.error);
        }
      });
    }).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }

  function update(request) {
    return {
      error: 'Not Implemented'
    };
  }

  function delete_(request) {
    return {
      error: 'Not Implemented'
    };
  }

  function toPrincipal(tenant, type, subid) {
    return {
      id: ['empower', tenant, type + 's', subid].join('/'),
      type: type
    };
  }

  function toReply(logLabel) {
    logLabel = logLabel instanceof Function ? logLabel.name : logLabel;
    return function(value) {
      if (value instanceof Error) {
        log.warn('%s| error:', logLabel, value);
        value = {
          error: value.toString()
        };
      } else {
        log.trace('%s| result:', logLabel, value);
      }
      return value;
    };
  }

  function send() {
    var to = 'empower.v6.users.' + options.send;
    var request = {};
    log.debug('Sending %s; to: %s, request:', options.send, to, request);
    microservices.call(to, request)
      .then(function(result) {
        var logLevel = log.level;
        log.setLevel('INFO');
        log.info('result:', util.inspect(result, {
          colors: true,
          depth: null
        }));
        log.setLevel(logLevel);
      })
      .finally(function() {
        setTimeout(function() {
          app.shutdown()
            .done();
        }, 1);
      })
      .done();
  }
});