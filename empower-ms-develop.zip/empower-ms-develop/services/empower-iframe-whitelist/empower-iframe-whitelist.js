'use strict';

var crutch = require('ih-microservice');

var defaults = {
    id: 'empower-iframe-whitelist',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'empower-iframe-whitelist',
    defaultReturnBody: true,
    communicateDb: 'MedseekIntegration60',
    pageSize: '20'
};

module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise) {

 	var log = logging.getLogger(defaults.id),
  GET_QUERY = 'SELECT id, portalId, iFrameHost, availableModules FROM [nModIframeWhitelists] WHERE PortalId = @portalId AND deleted = 0;',
  SAVE_OR_UPDATE = 'MERGE nModIframeWhitelists AS wl \n' +
  '      USING (values (@availableModules,@iFrameHost,@deleted))\n' +
  '          AS source (availableModules,iFrameHost,deleted)\n' +
  '          ON wl.portalId = @portalId AND wl.id = @id\n' +
  '      WHEN MATCHED THEN\n' +
  '          UPDATE\n' +
  '          SET availableModules = source.availableModules,\n' +
  '           iFrameHost = source.iFrameHost,\n' +
  '           deleted = source.deleted\n' +
  '      WHEN NOT MATCHED THEN\n' +
  '          INSERT ( portalId, iFrameHost, availableModules, deleted)\n' +
  '          VALUES ( @portalId,  @iFrameHost, source.availableModules,0);\n' +
  ' SELECT @@ROWCOuNT as rowsUpdated';

  return Promise.all([
    microservices.bind('empower.iframe.portal-white-lists.get.#', _.wrap(get, returnError)),
    microservices.bind('empower.iframe.portal-white-lists.save-or-update.#', _.wrap(saveOrUpdate, returnError))
  ]); 

  /*
  Saves or Updates the portal white list entity.
  message params:
  {
    portalId,
    iFrameHost,
    availableModules
  }
  */
  function saveOrUpdate(message, messageContext){
    log.debug('Saving iFrame whiteList', message);
    return submitQuery({
      q: SAVE_OR_UPDATE,
      qp: {
        portalId: {
          value: parseInt(message.portalId,10),
          type: 'Int'
        },
        iFrameHost: {
          value: message.iFrameHost,
          type: 'NVarChar'
        },
        availableModules: {
          value: JSON.stringify(message.availableModules),
          type: 'NVarChar'
        },
        id: {
          value: parseInt(message.id,10),
          type: 'Int'
        },
        deleted: {
          type: 'Bit',
          value: message.deleted ? 1 : 0
        }
      }
    }, messageContext).then(_.first);
  }

  /*
  Queries iframe whitelist table by portalId
  message params:
  {
    portalId
  }
  */
  function get(message, messageContext) {
    log.debug('Querying iFrame whiteList', message);
    return submitQuery({
      q: GET_QUERY,
      qp: {
        portalId: {
          value: parseInt(message.portalId, 10),
          type: 'Int'
        }
      }
    }, messageContext).then(function(response) {
      _.map(response,function(entity){
        entity.availableModules = JSON.parse(entity.availableModules);
      });
      return response;
    });
  }

  function submitQuery(queryObj, messageContext) {
    log.debug('submitting query', queryObj.q,queryObj.qp);
    var portalGroupId = getPortalGroupId(messageContext);
    return microservices.call('empower.v6.portal-groups.mssql.query.' + portalGroupId, queryObj)
      .then(function(results) {
        checkError(results);
        return results;
      });
  }

  function getPortalGroupId(messageContext) {
    return _.last(messageContext.routingKey.split('.'));
  }

  function checkError(results) {
    if (typeof(results.error) !== 'undefined') {
      throw new Error('Error running query: ' + results.error);
    }
  }

  function returnError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }
});
