'use strict';

var crutch = require('ih-microservice');
var dbFactory = require('./db.js');

var defaults = {
    id: 'empower-portal-aliases',
    defaultExchange: 'topic://medseek-api',
    defaultQueue: 'empower-portals-aliases',
    defaultReturnBody: true,
    communicateDb: 'MedseekIntegration60',
    pageSize: '20'
};

module.exports = crutch(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise) {

  var log = logging.getLogger(options.id);
  var Promise = bluebird, db;
  var knownPgs = {};

  var promiseFor = Promise.method(function(condition, action, value) {
    if (!condition(value)) {
      return value;
    }
    return action(value).then(promiseFor.bind(null, condition, action));
  });

  return Promise.all([
    microservices.bind('empower.portal.aliases', _.wrap(get, errorWrap)),
    microservices.bind('empower.portal.aliases.update', _.wrap(update, errorWrap))
  ]);

  var promiseFor = Promise.method(function(condition, action, value) {
    if (!condition(value)) {
      return value;
    }
    return action(value).then(promiseFor.bind(null, condition, action));
  });

  function get(req)
  {
    return getAliasesQuery(req)
      .then(function(data){
        return data;
      }).catch(function(err){
        return err;
      });
  }

  function update(req){

    var aliases = req.aliases;

    return performDeleteQuery(req,aliases).
      then(function(db){
      return performUpdate(req,aliases);
      }).then(function(records){
        return records;

      });
    
    }

    function performUpdate(req,aliases){
      var aliasRecords = [];
       return promiseFor(function(actionIndex) {
      return actionIndex <= aliases.length - 1;
    }, function(actionIndex) {

      var alias = aliases[actionIndex];

      if(alias.Id > 0 )
      {
        aliasRecords.push({"Id": alias.Id});
        return performUpdateAliasesQuery(req,alias).then(function(data) {
          actionIndex += 1;
          return actionIndex;
        });
       }
       else {
        return performInsertAliasQuery(req,alias).then(function(data) {
          aliasRecords.push({"Id": data[0].newAliasId});
          actionIndex += 1;
          return actionIndex;
        });
      }

    }, 0).then(function() {
          return aliasRecords;
        });
    }



    function performUpdateAliasesQuery(req, alias){

    var qString = 'update CmsPortalAliases set Alias =  @alias where Id = @id; select @@ROWCOUNT as AliasesUpdated' 
 
    var queryObject ={
      q: qString,
       qp: {
          Id: {
            value: parseInt(alias.Id, 10),
            type: 'Int'
          },
          alias: {
            type: 'NVarChar',
            value: alias.Alias,
            length: alias.Alias.length
          }
        }
      }

    return query(queryObject, req);
  }

   function performInsertAliasQuery(req, alias){

    var qString = 'insert CmsPortalAliases (portalId,alias) values ( @portalId,@alias); select SCOPE_IDENTITY() as newAliasId;'
 
    var queryObject ={
      q: qString,
       qp: {
          portalId: {
            value: parseInt(req.portalId, 10),
            type: 'Int'
          },
          alias: {
            type: 'NVarChar',
            value: alias.Alias,
            length: alias.Alias.length
          }

        }
      }

    return query(queryObject, req);
  }

  function performDeleteQuery(req, aliases){

    var qString = 'delete CmsPortalAliases where portalId = @portalId ';

    aliases.forEach(function(alias){
      
      if(alias.Id > 0)
      {
        qString += ' and id <> ' + parseInt(alias.Id, 10);
      }

    });

    var queryObject ={
      q: qString,
       qp: {
          portalId: {
            value: parseInt(req.portalId, 10),
            type: 'Int'
          }
        }
      }

    return query(queryObject, req);
  }


  function query(q,req){
    return microservices.call('empower.v6.portal-groups.mssql.query.pg-'+getSiteId(req),q)
    .tap(function(results){
      log.trace('get| query results', util.inspect(results, { colors: true, depth: null }));
    })
    .then(function(results){
      return results;
    });
}

  function getSiteId(req){
    return parseInt(req.siteId,10); 
  }

  function getPortalId(req){
    return parseInt(req.portalId,10); 
  }

  function getAliasesQuery(req){
    if( getPortalId(req) > 0 ){
      return getSpecificPortalAliasesQuery(req);
    }
    else
    {
      return getAllAliasesQuery(req);
    }
  }

  function getSpecificPortalAliasesQuery(req){
    var qString = 'select CmsPortalAliases.Id, CmsPortalAliases.PortalId, CmsPortalAliases.Alias from CmsPortalAliases inner join CmsPortals on CmsPortalAliases.portalid = CmsPortals.Id where CmsPortals.Id = @portalId';
      var queryObject ={
      q: qString,
       qp: {
          portalId: {
            value: parseInt(req.portalId, 10),
            type: 'Int'
          }
        }
      }
   return query( queryObject, req);
  }

  function getAllAliasesQuery(req){
    var qString = 'select CmsPortalAliases.Id, CmsPortalAliases.PortalId, CmsPortalAliases.Alias from CmsPortalAliases inner join CmsPortals on CmsPortalAliases.portalid = CmsPortals.Id';
    var queryObject ={
      q: qString,
      qp: {}
      }
      
    return query( queryObject, req);
  }


  function qp(value) {
    return {
      type: 'NVarChar',
      value: value,
      length: value.length
    };
  }


  function toMssqlConfig(uri) {
    var parsed = url.parse(uri, true);
    if (parsed.protocol !== 'mssql:')
        throw new Error('Unsupported protocol: ' + parsed.protocol);
    var authParts =  parsed.auth ? _.compact(parsed.auth.split(':')) : [];
    var hostParts = _.compact(parsed.host.split(':'));
    var pathParts = _.compact(parsed.pathname.split('/'));
    var config = {
        server: parsed.hostname,
        port: hostParts.length > 1 ? hostParts[1] : undefined,
        user: parsed.auth && parsed.auth.length > 0 ? authParts[0] : undefined,
        password: parsed.auth && parsed.auth.length > 1 ? authParts[1] : undefined,
        database: _.first(pathParts),
        options: parsed.query
    };
    if (pathParts.length > 1) {
        config.server += '\\' + pathParts[0];
        config.database = pathParts[1];
    }
    _.forEach(parsed.query, function(x, k, o) {
        var s = ('' + x).toLowerCase();
        if (s === 'true' || s === 'false') {
            o[k] = s === 'true';
        }
    });
    _.defaults(config, (db || {}).config);
    log.debug('toMssqlConfig| uri: %s, config:', uri, config);
    return config;
  }


  function errorWrap(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      return {
        error: err.message
      };
    });
  }

});
