'use strict';

module.exports = function(config, _, app, logging, mssql, Promise) {
    var log = logging.getLogger('empower-portal-aliases.db');
    log.trace('Connecting to SQL Server; config:', _.omit(config, 'password'));

    var connection;
    return new Promise(function(resolve, reject) {
        connection = mssql.connect(config, function(e) {
            return e ? reject(e) : resolve();
        });
    }).then(function() {
        log.trace('Connected to SQL Server: %s/%s', config.server, config.database);
        app.on('shutdown', onShutdown);
    }).return({
        config: config,
        disconnect: disconnect,
        query: query,
        qp: qp,
    });

    function disconnect() {
        return Promise.try(function() {
            if (connection) {
                app.removeListener('shutdown', onShutdown);
                connection.close();
                connection = undefined;
                log.debug('Disconnected from SQL Server: %s/%s', config.server, config.database);
            }
        });
    }

    function query(info) {
        log.trace('db| query info:', info);
        return Promise
            .try(function() {
                var request = connection.request();
                request.multiple = info.multiple;
                log.trace('db| query info.qp:', info.qp);
                _.forOwn(info.qp, function(p, k) {
                    log.trace('db| query info.qp loop: [p, %s],[k, %s]', JSON.stringify(p),k);
                    if(p.type){
                        p.type = qp(p.value, p.type, p.length);
                    }
                    return p.type ? request.input(k, p.type, p.value) : request.input(k, p.value);
                });
                return Promise.promisify(request.query.bind(request))(info.q);
            })
            .tap(function(result) {
                log.trace('result:', result);
            })
            .catch(function(error) {
                log.trace('error:', error);
                throw error;
            });
    }

    function qp(value, type, length) {
        var type = { type: type ? mssql[type] : undefined, value: value };
        log.trace('db| qp type:',type);
        return type;
    }

    function onShutdown() {
        disconnect().done();
    }
};
