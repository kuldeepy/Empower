'use strict';

var micro = require('ih-microservice');
var buildQuery = require('./build-query');
var formatResults = require('./format-results');

var defaults = {
  id: 'empower-platform-patient-search',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-platform-patient-search',
  defaultReturnBody: true,
  communicateDb: 'MedseekIntegration',
  pageSize: 100
};

module.exports = micro(defaults, function(app, logging, microservices, bluebird, options, url, _, util, Promise, fs) {
  var log = logging.getLogger(defaults.id);
  var Promise = bluebird;
  var empowerDbs = {};
  
  return Promise.resolve(microservices.bind('empower.platform.patients.search.#', _.wrap(search, returnError)));

  function search(request, messageContext) {

    var portalGroupId = getPortalGroupId();

    return getEmpowerDb()
      .then(buildQuery(request, options))
      .then(submitQuery)
      .then(formatResults);

    function getPortalGroupId() {
      return _.last(messageContext.routingKey.split('.'));
    }

    function getEmpowerDb() {
      return new Promise(function(resolve, reject) {
        if (empowerDbs[portalGroupId]) {
          return resolve(empowerDbs[portalGroupId]);
        }
        log.trace('querying for empower database for portal group', portalGroupId);
        return submitQuery({
          q: 'SELECT dsn FROM esWebsite WHERE CAST(siteID AS NVARCHAR) = @portalGroupId OR directoryName = @portalGroupId',
          qp: {
            portalGroupId: {
              value: portalGroupId,
              type: 'NVarChar',
              length: portalGroupId.length
            }
          }
        }).then(function(result) {
          var databaseName;
          if (result.length > 0 && result[0].dsn) {
            databaseName = result[0].dsn;
            empowerDbs[portalGroupId] = databaseName;
          }
          log.trace('empowerDb', databaseName);
          return resolve(databaseName);
        }).catch(function(err) {
          return reject(err);
        });
      });
    }

    function submitQuery(queryObj) {
      log.trace('submitting query', queryObj.q);
      log.trace('parameters', queryObj.qp);
      return microservices.call('empower.v6.portal-groups.mssql.query.pg-1', queryObj)
        .then(function(results) {
          checkError(results);
          return results;
        });
    }

    function checkError(results) {
      if (typeof(results.error) !== 'undefined') {
        throw new Error('Error running query: ' + results.error);
      }
    }
  }

  function returnError(fn, message, mc) {
    return Promise.try(function() {
      return fn(message, mc);
    }).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }

});