 medseekId IN (
      SELECT pp.UniqueId FROM [empowerDb].dbo.nModProfilePatients pp (NOLOCK) 
        JOIN [empowerDb].dbo.nModProfileLocations pl (NOLOCK) ON pl.PatientId = pp.Id
        JOIN [empowerDb].dbo.nModLocations l (NOLOCK) ON l.Id = pl.LocationId
      WHERE pl.LocationId = @location AND pl.IsApproved = 1 AND l.IsEnabled = 1
    )
