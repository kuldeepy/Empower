'use strict';
var chai = require('chai');
chai.use(require('chai-as-promised'));
chai.use(require('sinon-chai'));
var expect = chai.expect;

var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var _ = require('lodash');
var uuid = require('node-uuid');

var COMMUNICATE_DB = 'MedseekIntegration';
var EMPOWERDB = '12345';
var LOCATION_CLAUSE_TEST = 'WHERE pl.LocationId = @location';
var PHYSICIAN_CLAUSE_TEST = 'FindADoctorId';
var STRING_PARAMETER_NAMES =
  ['externalId', 'ssn', 'enrollmentStatus', 'firstName',
    'lastName', 'address1', 'city', 'stateName', 'postalCode',
    'phone', 'physician', 'location'
  ];

var buildQuery = require('../build-query');

describe('build-query', function() {
  var options;
  var request;
  var empowerDb;
  var buildQueryFn;

  beforeEach(function() {
    options = {
      communicateDb: COMMUNICATE_DB
    };
    request = {};
    empowerDb = EMPOWERDB;
    buildQueryFn = buildQuery(request, options);
  });

  describe('always', function() {

    it('should return an object with query and parameters', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query).to.exist;
        expect(query.q).to.be.a('string');
        expect(query.qp).to.be.a('object');
        done();
      });
    });

    it('should replace name of communicate db', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.contain(COMMUNICATE_DB);
        expect(query.q).to.not.contain('communicateDb');
        done();
      });
    });

    it('should replace identifierClause token', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.not.contain('identifierClause');
        done();
      });
    });

    it('should replace locationClause token', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.not.contain('locationClause');
        done();
      });
    });

    it('should replace physicianClause token', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.not.contain('physicianClause');
        done();
      });
    });

    it('should replace sortClause token', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.not.contain('sortClause');
        done();
      });
    });

    it('should include the minRow parameter', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.minRow).to.exist;
        expect(query.qp.minRow).to.be.a('object');
        done();
      });
    });

    it('should include the maxRow parameter', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.maxRow).to.exist;
        expect(query.qp.maxRow).to.be.a('object');
        done();
      });
    });

  });

  describe('when not querying by location', function() {

    it('should not include the location clause', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.not.contain(LOCATION_CLAUSE_TEST);
        done();
      });
    });

    it('should not include the location parameter', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.location).to.not.be.defined;
        done();
      });
    });

  });

  describe('when not querying by physician', function() {

    it('should not include the physician clause', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.not.contain(PHYSICIAN_CLAUSE_TEST);
        done();
      });
    });

    it('should set the physician parameter to null', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.physician).to.not.be.defined;
        done();
      });
    });

  });

  describe('when querying by location', function() {

    beforeEach(function() {
      request = {
        'location': 'someLocationId'
      };
      buildQueryFn = buildQuery(request, options);
    });

    it('should include the locationClause in the query', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.contain(LOCATION_CLAUSE_TEST);
        done();
      });
    });

    it('should replace the empowerDb token', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.contain(EMPOWERDB);
        expect(query.q).to.not.contain('empowerDb');
        done();
      });
    });

    it('should set the location parameter', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.location).to.exist;
        expect(query.qp.location).to.eql({
          type: 'NVarChar',
          value: 'someLocationId',
          length: 14
        });
        done();
      });
    });

  });

  describe('when querying by physician', function() {

    beforeEach(function() {
      request = {
        'physician': 'somePhysician'
      };
      buildQueryFn = buildQuery(request, options);
    });

    it('should include the physicianClause in the query', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.contain(PHYSICIAN_CLAUSE_TEST);
        done();
      });
    });

    it('should replace the empowerDb token', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.contain(EMPOWERDB);
        expect(query.q).to.not.contain('empowerDb');
        done();
      });
    });

    it('should set the physician parameter', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.physician).to.exist;
        expect(query.qp.physician).to.eql({
          type: 'NVarChar',
          value: 'somePhysician',
          length: 13
        });
        done();
      });
    });

  });

  describe('when querying by externalId', function() {
    beforeEach(function() {
      request = {
        'externalId': '12345'
      };
      buildQueryFn = buildQuery(request, options);
    });

    it('should include the identifier clause in the joined subquery', function(done){
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.q).to.contain("AND Identifier LIKE '%' + @externalId + '%'");
        done();
      });
    });

  });

  describe('when parameter values not specified', function() {

    STRING_PARAMETER_NAMES.concat(['gender', 'dateOfBirth']).forEach(function(parameterName) {
      it('does not include ' + parameterName + ' parameter', function(done) {
        buildQuery(request, options)(empowerDb).then(function(query) {
          expect(query.qp[parameterName]).to.not.be.defined;
          done();
        });
      });
    });

  });

  describe('when parameter values specified', function() {

    STRING_PARAMETER_NAMES.forEach(function(parameterName) {
      it('sets ' + parameterName + ' parameter', function(done) {
        var val = uuid.v4();
        request[parameterName] = val;
        buildQuery(request, options)(empowerDb).then(function(query) {
          expect(query.qp[parameterName]).to.eql({
            type: 'NVarChar',
            value: val,
            length: val.length
          });
          request = {};
          done();
        });
      });
    });

    it('sets gender parameter', function(done) {
      request.gender = 3;
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.gender).to.eql({
          type: 'Int',
          value: 3
        });
        done();
      });
    });

    it('sets dateOfBirth parameter', function(done) {
      request.dateOfBirth = '1/1/1970';
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.dateOfBirth).to.eql({
          type: 'DATE',
          value: '1/1/1970'
        });
        done();
      });
    });

    describe('when only enrollmentStatus parameter specified', function() {
      it('includes only enrollmentStatus clause', function(done) {
        request.enrollmentStatus = 'Enrolled';
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('enrollmentStatus = @enrollmentStatus');
          done();
        });
      });
    });

    describe('when enrollmentStatus and gender parameters specified', function() {
      it('includes only enrollmentStatus and gender clause', function(done) {
        request.enrollmentStatus = 'Enrolled';
        request.gender = 2;
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('enrollmentStatus = @enrollmentStatus AND gender = @gender');
          done();
        });
      });
    });

    describe('when externalId, enrollmentStatus, and gender parameters specified', function() {
      it('includes only externalId, enrollmentStatus and gender clause', function(done) {
        request.externalId = 'abc';
        request.enrollmentStatus = 'Enrolled';
        request.gender = 2;
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('externalId LIKE \'%\' + @externalId + \'%\' AND enrollmentStatus = @enrollmentStatus AND gender = @gender');
          done();
        });
      });
    });

    describe('when enrollmentStatus and physician parameters specified', function() {
      it('includes enrollmentStatus and physicianClause', function(done) {
        request.externalId = 'abc';
        request.physician = '123';
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('externalId LIKE \'%\' + @externalId + \'%\'');
          expect(query.q).to.contain(PHYSICIAN_CLAUSE_TEST);
          done();
        });
      });
    });

    describe('when only ssn parameters specified', function() {
      it('includes only ssn clause', function(done) {
        request.ssn = '9999';
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain(' ssn LIKE \'%\' + @ssn');
          done();
        });
      });
    });

    describe('when enrollmentStatus and ssn parameters specified', function() {
      it('includes only enrollmentStatus and ssn clause', function(done) {
        request.enrollmentStatus = 'Enrolled';
        request.ssn = '9999';
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('enrollmentStatus = @enrollmentStatus AND ssn LIKE \'%\' + @ssn');
          done();
        });
      });
    });

  });

  describe('sorting', function() {

    beforeEach(function() {
      request = {};
    });

    describe('when not specified', function() {

      it('should sort by lastName ascending', function(done) {
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('ORDER BY lastName asc');
          done();
        });
      });

    });

    describe('by last name descending', function() {

      beforeEach(function() {
        request = {
          orderBy: 'lastName',
          sortOrder: 'desc'
        };
        buildQueryFn = buildQuery(request, options);
      });

      it('sorts by lastName desc', function(done) {
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('ORDER BY lastName desc');
          done();
        });
      });

    });

    describe('by last name with no order specified', function() {

      beforeEach(function() {
        request = {
          orderBy: 'lastName',
        };
        buildQueryFn = buildQuery(request, options);
      });

      it('sorts by lastName asc', function(done) {
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('ORDER BY lastName asc');
          done();
        });
      });

    });

    describe('by gender default', function() {

      beforeEach(function() {
        request = {
          orderBy: 'gender',
        };
        buildQueryFn = buildQuery(request, options);
      });

      it('sorts by gender desc', function(done) {
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('ORDER BY gender desc');
          done();
        });
      });

    });

    describe('by gender ascending', function() {

      beforeEach(function() {
        request = {
          orderBy: 'gender',
          sortOrder: 'asc'
        };
        buildQueryFn = buildQuery(request, options);
      });

      it('sorts by gender desc', function(done) {
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('ORDER BY gender desc');
          done();
        });
      });

    });

    describe('by gender descending', function() {

      beforeEach(function() {
        request = {
          orderBy: 'gender',
          sortOrder: 'desc'
        };
        buildQueryFn = buildQuery(request, options);
      });

      it('sorts by gender asc', function(done) {
        buildQueryFn(empowerDb).then(function(query) {
          expect(query.q).to.contain('ORDER BY gender asc');
          done();
        });
      });

    });

  });

  describe('pagination', function() {

    beforeEach(function() {
      options.pageSize = 100;
      request = {};
      buildQueryFn = buildQuery(request, options);
    });

    it('should use default page size', function(done) {
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.minRow.value).to.eql(0);
        expect(query.qp.maxRow.value).to.eql(101);
        done();
      });
    });

    it('should use sepecified page size', function(done) {
      request.pageSize = 10;
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.minRow.value).to.eql(0);
        expect(query.qp.maxRow.value).to.eql(11);
        done();
      });
    });

    it('should use sepecified page number', function(done) {
      request.pageNumber = 1;
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.minRow.value).to.eql(0);
        expect(query.qp.maxRow.value).to.eql(101);
        done();
      });
    });

    it('should use sepecified page number and size', function(done) {
      request.pageNumber = 2;
      request.pageSize = 100;
      buildQueryFn(empowerDb).then(function(query) {
        expect(query.qp.minRow.value).to.eql(100);
        expect(query.qp.maxRow.value).to.eql(202);
        done();
      });
    });

  });

});
