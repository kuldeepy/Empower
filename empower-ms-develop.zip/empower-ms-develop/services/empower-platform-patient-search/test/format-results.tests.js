'use strict';
var chai = require('chai');
var expect = chai.expect;
var formatResults = require('../format-results');

describe('format-results', function() {

  var patients = [];

  describe('when called', function() {
    beforeEach(function() {
      patients = [{
        firstName: 'x'
      }, {
        firstName: 'y'
      }];
    });

    it('returns the formatted patients', function() {
      var formatted = formatResults(patients);
      expect(formatted).to.eql(patients);
    });
  });

  describe('formats external identifiers', function() {

    describe('when patient has externalId with id and source', function() {

      beforeEach(function() {
        patients = [{
          externalId: 'ABC:123'
        }];
      });

      it('creates an array of identifiers', function() {
        var formatted = formatResults(patients);
        expect(formatted[0].externalId).to.be.a('array');
      });

      it('sets the SourceId', function() {
        var formatted = formatResults(patients);
        expect(formatted[0].externalId[0].SourceId).to.eql('123');
      });

      it('sets the SourceAssigningFacility', function() {
        var formatted = formatResults(patients);
        expect(formatted[0].externalId[0].SourceAssigningFacility).to.eql('ABC');
      });

    });

    describe('when patient has multiple externalIds', function() {

      beforeEach(function() {
        patients = [{
          externalId: 'ABC:123, DEF:456'
        }];
      });

      it('creates multiple identifier objects', function() {
        var formatted = formatResults(patients);
        expect(formatted[0].externalId.length).to.equal(2);
      });

      it('formats each identifier object', function() {
        var formatted = formatResults(patients);
        var patient = formatted[0];
        var externalIds = patient.externalId;

        expect(externalIds[0]).to.eql({
          SourceId: '123',
          SourceAssigningFacility: 'ABC'
        });

        expect(externalIds[1]).to.eql({
          SourceId: '456',
          SourceAssigningFacility: 'DEF'
        });

      });


    });

    describe('when patient has no externalId', function() {

      beforeEach(function() {
        patients = [{
          externalId: ''
        }];
      });

      it('sets externalId to empty array', function() {
        var formatted = formatResults(patients);
        expect(formatted[0].externalId).to.be.a('array');
        expect(formatted[0].externalId.length).to.equal(0);
      });
    });

    describe('when externalId has no SourceAssigningFacility', function() {

      beforeEach(function() {
        patients = [{
          externalId: '12345'
        }];
      });

      it('still sets externalId', function() {
        var formatted = formatResults(patients);
        expect(formatted[0].externalId[0].SourceId).to.eql('12345');
      });
    });



  });
});