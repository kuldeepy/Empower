 medseekId IN (
      SELECT pp.UniqueId FROM [empowerDb].dbo.nModProfilePatients pp (NOLOCK)  
        JOIN [empowerDb].dbo.nModPatientsPhysicians ph (NOLOCK) ON ph.PatientId = pp.Id
        JOIN [empowerDb].dbo.nModFindADoctorDoctor d (NOLOCK) ON d.Id = ph.FindADoctorId
      WHERE (
          ph.FindADoctorId = CASE ISNUMERIC(@physician) WHEN 1 THEN @physician ELSE -1 END 
          OR (d.FirstName LIKE '%' + CAST(@physician AS VARCHAR(20)) + '%' OR d.LastName LIKE '%' + CAST(@physician AS VARCHAR(20)) + '%')
        ) AND ph.IsApproved = 1 AND d.IsEnabled = 1
    )
