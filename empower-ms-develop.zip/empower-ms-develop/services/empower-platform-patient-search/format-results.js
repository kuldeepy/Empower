'use strict';

module.exports = function(results) {

  results.forEach(function(patient) {
    patient.externalId = formatExternalIdentifiers(patient);
  });

  return results;

  function formatExternalIdentifiers(patient) {
    var externalId = patient.externalId;
    if (externalId) {
      return externalId.split(',').map(function(id) {
        var formatted = {};
        var parts = id.split(':');
        if (parts.length === 2) {
          formatted.SourceId = parts[1].trim();
          formatted.SourceAssigningFacility = parts[0].trim();
        } else {
          formatted.SourceId = parts[0].trim();
        }
        return formatted;
      });
    } else {
      return [];
    }
  }
};