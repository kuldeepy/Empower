SELECT * FROM (         
  SELECT ROW_NUMBER() OVER (ORDER BY sortClause) AS row, * 
  FROM ( SELECT
    p.medseekPatientId as medseekId,
    p.medseekPatientId as uniqueId,
    p.medseekPatientId as medicalRecordNumber,
    p.PatientName_GivenName AS firstName,              
    p.PatientName_FamilyName AS lastName,               
    p.PatientName_FurtherGivenName AS middleName,
    gender = CASE LOWER(p.Sex) WHEN 'male' THEN 2 WHEN 'female' THEN 3 ELSE 1 END,
    p.SocialSecurityNumber AS ssn,
    g.PatientEmailAddress AS emailAddress,
    (SELECT TOP 1 x.StreetAddress FROM communicateDb.[dbo].[ps_PatientAddresses] x (NOLOCK) WHERE x.PatientDemographicsId = p.Id ORDER BY x.Created DESC) AS addressLine1,
    (SELECT TOP 1 x.City FROM communicateDb.[dbo].[ps_PatientAddresses] x (NOLOCK) WHERE x.PatientDemographicsId = p.Id ORDER BY x.Created DESC) AS city,
    (SELECT TOP 1 x.StateOrProvince FROM communicateDb.[dbo].[ps_PatientAddresses] x (NOLOCK) WHERE x.PatientDemographicsId = p.Id ORDER BY x.Created DESC) AS stateName,
    (SELECT TOP 1 ISNULL(x.AreaCode, '') + ISNULL(x.LocalNumber, '') FROM communicateDb.[dbo].[ps_PatientHomePhoneNumbers] x (NOLOCK) WHERE x.PatientDemographicsId = p.Id ORDER BY x.Created DESC) AS phoneNumber,
    (SELECT TOP 1 ISNULL(x.AreaCode, '') + ISNULL(x.LocalNumber, '') FROM communicateDb.[dbo].[ps_PatientBusinessPhoneNumbers] x (NOLOCK) WHERE x.PatientDemographicsId = p.Id ORDER BY x.Created DESC) AS workPhoneNumber,
    (SELECT TOP 1 x.ZipOrPostalCode FROM communicateDb.[dbo].[ps_PatientAddresses] x (NOLOCK) WHERE x.PatientDemographicsId = p.Id ORDER BY x.Created DESC) AS zipCode,
    i.externalId,
    p.dateOfBirth,             
    ISNULL([status].[Status], 'NotInvited') AS enrollmentStatus 
  FROM 
    communicateDb.[dbo].[ps_PatientDemographics] p (NOLOCK)
    LEFT JOIN communicateDb.[dbo].[ps_EnrollmentInvitationStatus] [status] (NOLOCK) on [status].medseekPatientId = p.medseekPatientId
    LEFT JOIN communicateDb.[dbo].[ps_CustomDemographics] g (NOLOCK) ON g.Id = p.Id
    LEFT JOIN (
        SELECT
            medseekPatientId,
            STUFF((SELECT N', ' + Source_Group + ':' + Identifier
                FROM communicateDb.[dbo].[ps_Patients] WITH (NOLOCK)
                WHERE MedseekPatientId = pii.MedseekPatientId
                identifierClause
                FOR XML PATH('')), 1, 1, N'') AS externalId
        FROM communicateDb.[dbo].[ps_Patients] pii (NOLOCK)
        GROUP BY MedseekPatientId
    ) i ON i.medseekPatientId = p.medseekPatientId
  ) Data  
  WHERE 
    patientClause
	physicianClause
    locationClause
    
) AS Pages WHERE row > @minRow AND row < @maxRow
