'use strict';

var Promise = require('bluebird');
var fs = require('fs');

var QUERY_TEMPLATE = fs.readFileSync('./query-template.sql', {
  encoding: 'utf8'
});

var LOCATION_CLAUSE_TEMPLATE = fs.readFileSync('./location-clause-template.sql', {
  encoding: 'utf8'
});

var PHYSICIAN_CLAUSE_TEMPLATE = fs.readFileSync('./physician-clause-template.sql', {
  encoding: 'utf8'
});

module.exports = function (request, options) {

  return function buildQuery(empowerDb) {

    return Promise.resolve({
      q: getQueryText(),
      qp: getQueryParams()
    });

    function getQueryText() {

      var needAnd = false;

      var and = function() {
        var val = needAnd ? ' AND' : ' ';
        needAnd = true;
        return val;
      };

      var query = QUERY_TEMPLATE.split('communicateDb').join(options.communicateDb);

      query = query.replace('identifierClause', getIdentifierClause());
      query = query.replace('patientClause', getPatientClause());
      query = query.replace('physicianClause', getPhysicianClause());
      query = query.replace('locationClause', getLocationClause());
      query = query.split('empowerDb').join(empowerDb);
      query = query.replace('sortClause', getSortClause());

      function getSortClause() {
        var orderBy = request.orderBy || 'lastName';
        var sortOrder = (request.sortOrder || 'asc').toLowerCase();
        if (orderBy == 'gender') {
          sortOrder = sortOrder === 'desc' ? 'asc' : 'desc';
        }
        return orderBy + ' ' + sortOrder;
      }

      function getPatientClause() {
        var clause = '';
        if (request.externalId) {
          clause += and() + " externalId LIKE '%' + @externalId + '%'";
        }
        if (request.enrollmentStatus) {
          clause += and() + " enrollmentStatus = @enrollmentStatus";
        }
        if (request.ssn) {
          clause += and() + " ssn LIKE '%' + @ssn";
        }
        if (request.firstName) {
          clause += and() + " firstName LIKE @firstName + '%'";
        }
        if (request.lastName) {
          clause += and() + " lastName LIKE @lastName + '%'";
        }
        if (request.gender) {
          clause += and() + " gender = @gender";
        }
        if (request.dateOfBirth) {
          clause += and() + " DateOfBirth = @dateOfBirth";
        }
        if (request.address1) {
          clause += and() + " addressLine1 = @address1";
        }
        if (request.city) {
          clause += and() + " city = @city";
        }
        if (request.stateName) {
          clause += and() + " stateName = @stateName";
        }
        if (request.postalCode) {
          clause += and() + " zipCode = @postalCode";
        }
        if (request.phone) {
          clause += and() + " (phoneNumber = @phone OR workPhoneNumber = @phone)";
        }
        return clause;
      }

      function getIdentifierClause() {
        return request.externalId ? " AND Identifier LIKE '%' + @externalId + '%'" : '';
      }

      function getPhysicianClause() {
        return request.physician ? and() + PHYSICIAN_CLAUSE_TEMPLATE : '';
      }

      function getLocationClause() {
        return request.location ? and() + LOCATION_CLAUSE_TEMPLATE : '';
      }

      return query;
    }

    function getQueryParams() {
      return {
        externalId: nvParam(request.externalId),
        enrollmentStatus: nvParam(request.enrollmentStatus),
        ssn: nvParam(request.ssn),
        firstName: nvParam(request.firstName),
        lastName: nvParam(request.lastName),
        address1: nvParam(request.address1),
        city: nvParam(request.city),
        stateName: nvParam(request.stateName),
        postalCode: nvParam(request.postalCode),
        phone: nvParam(request.phone),
        physician: nvParam(request.physician),
        location: nvParam(request.location),
        gender: (function () {
          if (!request.gender) {
            return undefined;
          }
          return {
            type: 'Int',
            value: request.gender
          };
        })(),
        dateOfBirth: (function () {
          if (!request.dateOfBirth) {
            return undefined;
          }
          return {
            type: 'DATE',
            value: request.dateOfBirth
          };
        })(),
        minRow: {
          type: 'Int',
          value: ((request.pageSize || options.pageSize) * ((request.pageNumber || 1) - 1))
        },
        maxRow: {
          type: 'Int',
          value: (((request.pageSize || options.pageSize) + 1) * (request.pageNumber || 1))
        }
      };

      function nvParam(input) {
        if (input) {
          return {
            type: 'NVarChar',
            value: input,
            length: input.length
          };
        }
        return undefined;
      }
    }
  };

};
