'use strict';
var micro = require('ih-microservice');
var patientPortalPermissions = require('./permissions/patient_portal/all');
var staffPortalPermissions = require('./permissions/staff_portal/all');
var adminPortalPermissions = require('./permissions/admin/all');
var flatten = require('./flatten');

var defaults = {
  id: 'empower-permissions',
  debug: true,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-permissions',
  defaultReturnBody: true
};

micro(defaults, function(app, logging, microservices, bluebird, _) {
  var Promise = bluebird;
  var log = logging.getLogger('empower-permissions');

  return Promise.all([
    microservices.bind('empower.permissions.by-portal-type', get),
    microservices.bind('empower.permissions.get-flattened-components', getFlattenedComponents),
    microservices.bind('empower.permissions.get-unioned-flattened-components', getUnionedFlattenedComponents)
  ]);

  function get(message) {
    return Promise.try(function() {
      log.debug(message);
      return getPermissionSet(message.portalType).then(function(permissionSet) {
        if (message.flatten) {
          var flattend = flatten(permissionSet);
          if (message.readOnly) {
            flattend = _.filter(flattend, function(accessType) {
              return accessType.readOnly;
            });
          } else if (message.emergencyAccess) {
            flattend = _.filter(flattend, function(accessType) {
              return accessType.emergencyAccess;
            });
          }
          return _.pluck(flattend, 'permission').sort();
        }
        return permissionSet;
      });
    }).catch(function(err) {
      return {
        error: err.message
      };
    });
  }

  function getPermissionSet(portalType) {
    log.debug('getting permissions for portal type', portalType);
    return new Promise(function(resolve, reject) {
      var type = portalType.toLowerCase();
      var permissions;
      if (type === 'public') {
        permissions = patientPortalPermissions;
      } else if (type === 'staff') {
        permissions = staffPortalPermissions;
      } else if (type === 'portalgroupadmin') {
        permissions = adminPortalPermissions;
      } else {
        return reject(new Error('Unknown portal type: ' + portalType));
      }
      return resolve(permissions);
    });
  }

  function getFlattenedComponents(message) {
    return Promise.try(function() {
      return getPermissionSet(message.portalType).then(function(permissionSet) {
        var topLevelComponents = permissionSet.components[0].components;
        return flattenComponents(topLevelComponents);
      });
    }).catch(function(err) {
      return {
        error: err.message
      };
    });
  }

  function getUnionedFlattenedComponents(message) {
    return Promise.try(function() {
      var topLevelPatientComponents = patientPortalPermissions.components[0].components;
      var flattendPatient = flattenComponents(topLevelPatientComponents);
      var topLevelStaffComponents = staffPortalPermissions.components[0].components;
      var flattenedStaff = flattenComponents(topLevelStaffComponents);
      var all = [];
      unionComponents(flattenedStaff, all);
      unionComponents(flattendPatient, all);
      return all;
    }).catch(function(err) {
      return {
        error: err.message
      };
    });
  }

  function flattenComponents(components) {
    return components.map(function(component) {
      return {
        id: component.id,
        permissions: _.pluck(flatten(component), 'permission').sort()
      };
    });
  }

  function unionComponents(components, all) {
    components.forEach(function(component) {
      if (!_.contains(_.pluck(all, 'id'), component.id)) {
        all.push(component);
      } else {
        var existing = _.find(all, {
          id: component.id
        });
        existing.permissions = _.union(existing.permissions, component.permissions);
      }
    });
  }

});