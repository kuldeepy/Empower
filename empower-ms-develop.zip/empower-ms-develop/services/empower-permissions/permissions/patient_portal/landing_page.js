'use strict';

module.exports = {
  id: 'landing-page',
  accessTypes: [{
    permission: 'landing-page.tile.move',
    label: 'Change Tile Position'
  },{
    permission: 'landing-page.tile.add',
    label: 'Add Tile'
  },{
    permission: 'landing-page.tile.remove',
    label: 'Remove Tile'
  }]
};