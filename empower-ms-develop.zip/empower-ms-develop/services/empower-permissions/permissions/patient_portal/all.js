'use strict';
var userSettings = require('./user_settings');
var messageCenter = require('./message_center');
var landingPage = require('./landing_page');
var requestCenter = require('./request_center')();

module.exports = {
  id: 'Public',
  components: [{
    id: 'login',
    accessTypes: [{
      permission: 'user-settings',
      componentKey: 'user-settings',
      readOnly: true,
      label: 'User Settings'	  
    }, {
      permission: 'message-center',
      componentKey: 'message-center',
      readOnly: true,
      label: 'Message Center'
    }, {
      permission: 'landing-page',
      componentKey: 'landing-page',
      readOnly: true,
      label: 'Landing Page'
    }, {
      permission: 'request-center',
      componentKey: 'request-center',
      label: 'Request Center'
    }],
    components: [
      userSettings,
      messageCenter,
      landingPage,
      requestCenter
    ]
  }],
  accessTypes: [{
    permission: 'login',
    componentKey: 'login',
    readOnly: true,
    label: 'Login'
  }]
};