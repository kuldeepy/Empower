'use strict';

module.exports = {
  id: 'message-center',
  accessTypes: [{
    permission: 'message-center.messages.view',
    componentKey: 'view',
    readOnly: true,
    label: 'View Messages'
  }],
  components: [{
    id: 'view',
    accessTypes: [{
      permission: 'message-center.messages.create',
      componentKey: 'create',
      label: 'Create Message'
    }, {
      permission: 'message-center.folders.create',
      componentKey: 'create-folder',
      label: 'Create Folder'
    }, {
      permission: 'message-center.messages.attachment.add',
      componentKey: 'attach',
      label: 'Attach File'
    }],
    components: [{
      id: 'create-folder',
      accessTypes: [{
        permission: 'message-center.folders.rename',
        label: 'Rename Folder'
      }, {
        permission: 'message-center.folders.delete',
        label: 'Delete Folder'
      }]
    }]
  }]
};