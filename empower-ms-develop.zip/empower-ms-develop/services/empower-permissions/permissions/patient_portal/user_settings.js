'use strict';

module.exports = {
  id: 'user-settings',
  accessTypes: [{
    permission: 'user-settings.user-info.view',
    readOnly: true,
    componentKey: 'view-user-info',
    label: 'View User Information'
  }, {
    permission: 'user-settings.profile-image.view',
    readOnly: true,
    componentKey: 'view-profile-image',
    label: 'View Profile Image'
  }, {
    permission: 'user-settings.notification-types.view',
    readOnly: true,
    componentKey: 'view-notification-types',
    label: 'View Notification Types'
  }, {
    permission: 'user-settings.time-zone.view',
    readOnly: true,
    componentKey: 'view-time-zone',
    label: 'View Time Zone'
  }, {
    permission: 'user-settings.preferred-language.view',
    readOnly: true,
    componentKey: 'view-preferred-language',
    label: 'View Preferred Language'
  }, {
    permission: 'user-settings.security-questions.view',
    readOnly: true,
    componentKey: 'view-security-questions',
    label: 'View Security Questions and Answers'
  }, {
    permission: 'user-settings.password.update',
    label: 'Update Password'
  }, {
    permission: 'user-settings.account.close',
    label: 'Close Account'
  }],
  components: [{
    id: 'view-user-info',
    accessTypes: [{
      permission: 'user-settings.user-info.edit',
      label: 'Edit User Information'
    }]
  }, {
    id: 'view-profile-image',
    accessTypes: [{
      permission: 'user-settings.profile-image.edit',
      label: 'Add/Change/Remove Image'
    }]
  }, {
    id: 'view-notification-types',
    accessTypes: [{
      permission: 'user-settings.notification-types.manage',
      label: 'Enable/Disable Notifications'
    }]
  }, {
    id: 'view-time-zone',
    accessTypes: [{
      permission: 'user-settings.time-zone.edit',
      label: 'Edit Time Zone'
    }]
  }, {
    id: 'view-preferred-language',
    accessTypes: [{
      permission: 'user-settings.preferred-language.edit',
      label: 'Edit Preferred Language'
    }]
  }, {
    id: 'view-security-questions',
    accessTypes: [{
      permission: 'user-settings.security-questions.edit',
      label: 'Edit Answers to Security Questions'
    }]
  }]
};