'use strict';

module.exports = function() {
  return {
    id: 'request-center',
    accessTypes: [
      {
        permission: 'request-center.requests.pending.view',
        label: 'View Pending Requests'
      },
      {
        permission: 'request-center.requests.completed.view',
        label: 'View Completed Requests'
      },
      {
        permission: 'request-center.requests.discussions.view',
        componentKey: 'discussion',
        label: 'View Discussion'
      }
    ],
    components: [
      {
        id: 'discussion',
        accessTypes: [
          {
            permission: 'request-center.discussions.create',
            label: 'Add a Comment to Discussion'
          },
          {
            permission: 'request-center.discussions.edit',
            label: 'Edit a Comment - Self Entered'
          },
          {
            permission: 'request-center.discussions.delete',
            label: 'Delete a Comment - Self Entered'
          }
        ]
      }
    ]
  };
};
