'use strict';

module.exports = {
  id: 'PortalGroupAdmin',
  accessTypes: [{
    permission: 'login',
    label: 'Login'
  }]
};