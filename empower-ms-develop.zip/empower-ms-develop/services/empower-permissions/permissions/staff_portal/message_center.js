'use strict';

module.exports = {
  id: 'message-center',
  accessTypes: [{
    permission: 'message-center.messages.view',
    componentKey: 'view-messages',
    readOnly: true,
    label: 'View Messages'
  }],
  components: [{
    id: 'view-messages',
    accessTypes: [{
      permission: 'message-center.messages.create',
      componentKey: 'create-message',
      readOnly: true,
      label: 'Create Message'
    }, {
      permission: 'message-center.folders.create',
      componentKey: 'create-folder',
      readOnly: true,
      label: 'Create Folder'
    }, {
      permission: 'message-center.messages.attachment.add',
      readOnly: true,
      label: 'Attach File'
    }],
    components: [{
      id: 'create-message',
      accessTypes: [{
        permission: 'message-center.messages.recipients.users.add',
        readOnly: true,
        label: 'Address to Patient Users'
      }, {
        permission: 'message-center.messages.recipients.staff.add',
        readOnly: true,
        label: 'Address to Staff Users'
      }]
    }, {
      id: 'create-folder',
      accessTypes: [{
        permission: 'message-center.folders.rename',
        readOnly: true,
        label: 'Rename Folder'
      }, {
        permission: 'message-center.folders.delete',
        readOnly: true,
        label: 'Delete Folder'
      }]
    }]
  }]
};