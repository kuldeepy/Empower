'use strict';

module.exports = {
  id: 'user-management',
  accessTypes: [{
    permission: 'user-management.users.search.view',
    componentKey: 'search-user',
    readOnly: true,
    label: 'Search User'
  }, {
    permission: 'user-management.patients.search.view',
    componentKey: 'search-patient',
    readOnly: true,
    label: 'Search Patient'
  }, {
    permission: 'user-management.invitations.create',
    componentKey: 'create-invitation',
    label: 'Create Portal Invitation'
  }, {
    permission: 'user-management.community.view',
    componentKey: 'view-community',
    readOnly: true,
    label: 'View User and Patient Community'
  }, {
    permission: 'user-management.invitations.view',
    componentKey: 'manage-invitation',
    label: 'Manage All Invitation'
  }, {
    permission: 'user-management.batch-enrollments.view',
    componentKey: 'batch-enrollment',
    label: 'Batch Enrollment'
  }],
  components: [{
      id: 'search-user',
      accessTypes: [{
        permission: 'user-management.users.details.view',
        readOnly: true,
        label: 'View User Details'
      }, {
        permission: 'user-management.users.activity.view',
        readOnly: true,
        label: 'View User Account Activity'
      }, {
        permission: 'user-management.users.activate',
        label: 'Activate Account'
      }, {
        permission: 'user-management.users.deactivate',
        label: 'Deactivate Account'
      }, {
        permission: 'user-management.users.password',
        label: 'Reset User Password'
      }, {
        permission: 'user-management.users.security-answers.reset',
        label: 'Reset Security Answers'
      }]
    }, {
      id: 'search-patient',
      accessTypes: [{
        permission: 'user-management.patients.activity.view',
        readOnly: true,
        label: 'View Patient Profile Activity'
      }, {
        permission: 'user-management.patients.enrollment.update',
        readOnly: true,
        label: 'Mark Opt Out/In of Enrollment'
      }]
    }, {
      id: 'create-invitation',
      accessTypes: [{
        permission: 'user-management.invitations.access-level.customize',
        label: 'Customize Access Level'
      }]
    },

    {
      id: 'view-community',
      accessTypes: [{
        permission: 'user-management.community.access-level.edit',
        label: 'Change Access Level on an existing connection'
      }, {
        permission: 'user-management.community.access-level.customize',
        label: 'Customize Access Level'
      }, {
        permission: 'user-management.community.relationship.sever',
        label: 'Sever Connection'
      }, {
        permission: 'user-management.community.relationship.restore',
        label: 'Restore Connection'
      }, {
        permission: 'user-management.view-community.relationship.override-aom',
        label: 'Override Age of Majority'
      }]
    }, {
      id: 'manage-invitation',
      accessTypes: [{
        permission: 'user-management.invitations.edit',
        label: 'Edit Pending Invitation'
      }, {
        permission: 'user-management.invitations.expire',
        label: 'Expire Invitation'
      }, {
        permission: 'user-management.invitations.resend',
        label: 'Resend Invitation'
      }, {
        permission: 'user-management.invitations.aom.override',
        label: 'Override Age of Majority'
      }]
    }, {
      id: 'batch-enrollment',
      accessTypes: [{
        permission: 'user-management.batch-enrollments.all.view',
        label: 'View Batch Uploaded by All Users'
      }, {
        permission: 'user-management.batch-enrollments.self.view',
        label: 'View Batch Uploaded by Self'
      }, {
        permission: 'user-management.batch-enrollments.create',
        label: 'Upload New Batch'
      }]
    }
  ]
};