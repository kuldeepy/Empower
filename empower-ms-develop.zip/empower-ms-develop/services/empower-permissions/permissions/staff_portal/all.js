'use strict';
var healthInformation = require('./health_information');
var taskCenter = require('./task_center');
var userSettings = require('./user_settings');
var patientManagement = require('./patient_management');
var broadcastMessaging = require('./broadcast_messaging');
var userManagememnt = require('./user_management');
var appointments = require('./appointments');
var messageCenter = require('./message_center');
var landingPage = require('./landing_page');

module.exports = {
  id: 'Staff',
  components: [{
    id: 'login',
    accessTypes: [{
      permission: 'health-information',
      componentKey: 'health-information',
      label: 'Health Information'
    }, {
      permission: 'task-center',
      componentKey: 'task-center',
      label: 'Task Center'
    }, {
      permission: 'user-settings',
      componentKey: 'user-settings',
      label: 'User Settings'
    }, {
      permission: 'patient-management',
      componentKey: 'patient-management',
      label: 'Patient Management'
    }, {
      permission: 'broadcast-messaging',
      componentKey: 'broadcast-messaging',
      label: 'Broadcast Messaging'
    }, {
      permission: 'landing-page',
      componentKey: 'landing-page',
      label: 'Landing Page'
    }, {
      permission: 'user-management',
      componentKey: 'user-management',
      label: 'User Management'
    }, {
      permission: 'appointments',
      componentKey: 'appointments',
      label: 'Appointments'
    }, {
      permission: 'message-center',
      componentKey: 'message-center',
      label: 'Message Center'
    },{
      permission: 'reports.analytic-reports.full-access',
      readOnly: true,
      label: 'Reports'
    }],
    components: [
      healthInformation,
      taskCenter,
      userSettings,
      patientManagement,
      broadcastMessaging,
      landingPage,
      userManagememnt,
      appointments,
      messageCenter
    ]
  }],
  accessTypes: [{
    permission: 'login',
    componentKey: 'login',
    readOnly: true,
    label: 'Login',
  }]
};