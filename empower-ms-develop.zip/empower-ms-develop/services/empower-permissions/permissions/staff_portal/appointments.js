'use strict';

module.exports = {
  id: 'appointments',
  accessTypes: [{
    permission: 'appointments.future.view',
    readOnly: true,
    label: 'View Upcoming Appointments'
  }, {
    permission: 'appointments.past.view',
    readOnly: true,
    label: 'View Past Appointments'
  }]
};