'use strict';

module.exports = {
  id: 'health-information',
  accessTypes: [{
    permission: 'health-information.recommended-articles.find',
    componentKey: 'find-recommended-articles',
    readOnly: true,
    emergencyAccess: true,
    label: 'Find Recommended Articles'
  }, {
    permission: 'health-information.allergies.view',
    componentKey: 'view-allergies',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Allergies'
  }, {
    permission: 'health-information.blood-glucoses.view',
    componentKey: 'view-blood-glucoses',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Blood Glucoses'
  }, {
    permission: 'health-information.blood-pressures.view',
    componentKey: 'view-blood-pressures',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Blood Pressures'
  }, {
    permission: 'health-information.cholesterols.view',
    componentKey: 'view-cholesterols',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Cholesterols'
  }, {
    permission: 'health-information.immunizations.view',
    componentKey: 'view-immunizations',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Immunizations'
  }, {
    permission: 'health-information.height-weight-bmi.view',
    componentKey: 'view-height-weight-bmi',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Height/Weight/BMI'
  }, {
    permission: 'health-information.medications.view',
    componentKey: 'view-medications',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Medications'
  }, {
    permission: 'health-information.conditions.view',
    componentKey: 'view-conditions',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Conditions'
  }, {
    permission: 'health-information.procedures.view',
    componentKey: 'view-procedures',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Procedures'
  }, {
    permission: 'health-information.social-history.view',
    componentKey: 'view-social-history',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Social History'
  }, {
    permission: 'health-information.family-history.view',
    componentKey: 'view-family-history',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Family History'
  }, {
    permission: 'health-information.test-results.view',
    componentKey: 'view-test-results',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Test Results'
  }, {
    permission: 'health-information.clinical-documents.view',
    componentKey: 'view-clinical-documents',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Clinical Documents'
  }, {
    permission: 'health-information.emergency-access.enable',
    readOnly: true,
    emergencyAccess: true,
    label: 'Enable Emergency Access'
  }],
  components: [{
    id: 'find-recommended-articles',
    accessTypes: [{
      permission: 'health-information.recommended-articles.search',
      emergencyAccess: true,
      label: 'Search Health Information'
    }]
  }, {
    id: 'view-allergies',
    accessTypes: [{
      permission: 'health-information.allergies.external.delete',
      emergencyAccess: true,
      label: 'Delete External Allergies'
    }, {
      permission: 'health-information.allergies.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-blood-glucoses',
    accessTypes: [{
      permission: 'health-information.blood-glucoses.external.delete',
      emergencyAccess: true,
      label: 'Delete External Blood Glucoses'
    }, {
      permission: 'health-information.blood-glucoses.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-blood-pressures',
    accessTypes: [{
      permission: 'health-information.blood-pressures.external.delete',
      emergencyAccess: true,
      label: 'Delete External Blood Pressures'
    }, {
      permission: 'health-information.blood-pressures.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-cholesterols',
    accessTypes: [{
      permission: 'health-information.cholesterols.external.delete',
      emergencyAccess: true,
      label: 'Delete External Cholesterols'
    }, {
      permission: 'health-information.cholesterols.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-height-weight-bmi',
    accessTypes: [{
      permission: 'health-information.height-weight-bmi.external.delete',
      emergencyAccess: true,
      label: 'Delete External Height/Weight/BMI'
    }, {
      permission: 'health-information.height-weight-bmi.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-immunizations',
    accessTypes: [{
      permission: 'health-information.immunizations.external.delete',
      emergencyAccess: true,
      label: 'Delete External Immunizations'
    }, {
      permission: 'health-information.immunizations.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-medications',
    accessTypes: [{
      permission: 'health-information.medications.external.delete',
      emergencyAccess: true,
      label: 'Delete External Medications'
    }, {
      permission: 'health-information.medications.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-conditions',
    accessTypes: [{
      permission: 'health-information.conditions.external.delete',
      emergencyAccess: true,
      label: 'Delete External Conditions'
    }, {
      permission: 'health-information.conditions.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-procedures',
    accessTypes: [{
      permission: 'health-information.procedures.external.delete',
      emergencyAccess: true,
      label: 'Delete External Procedures'
    }, {
      permission: 'health-information.procedures.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-social-history',
    accessTypes: [{
      permission: 'health-information.social-history.external.delete',
      emergencyAccess: true,
      label: 'Delete External Social History'
    }, {
      permission: 'health-information.social-history.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-family-history',
    accessTypes: [{
      permission: 'health-information.family-history.external.delete',
      emergencyAccess: true,
      label: 'Delete External Family History'
    }, {
      permission: 'health-information.family-history.health-articles.send',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-test-results',
    accessTypes: [{
      permission: 'health-information.test-results.external.delete',
      emergencyAccess: true,
      label: 'Delete External Test Results'
    }, {
      permission: 'health-information.test-results.send-health-articles',
      emergencyAccess: true,
      label: 'Send Health Articles'
    }]
  }, {
    id: 'view-clinical-documents',
    accessTypes: [{
      permission: 'health-information.clinical-documents.individual.delete',
      emergencyAccess: true,
      label: 'Delete Individual Clinical Documents'
    }, {
      permission: 'health-information.clinical-documents.all.delete',
      emergencyAccess: true,
      label: 'Delete All Clinical Documents'
    }]
  }]
};