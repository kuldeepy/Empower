'use strict';

module.exports = {
  id: 'patient-management',
  accessTypes: [{
    permission: 'patient-management.demographics.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Demographics'
  }, {
    permission: 'patient-management.profileactivity.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Profile Activity'
  }, {
    permission: 'patient-management.profile-images.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Profile Images'
  }, {
    permission: 'patient-management.physicians.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Physicians'
  }, {
    permission: 'patient-management.locations.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Locations'
  }, {
    permission: 'patient-management.pharmacies.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Pharmacies'
  }, {
    permission: 'patient-management.emergency-contacts.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Emergency Contacts'
  }, {
    permission: 'patient-management.insurances.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Insurances'
  }, {
    permission: 'patient-management.guarantors.view',
    readOnly: true,
    emergencyAccess: true,
    label: 'View Guarantors'
  }]
};