'use strict';

module.exports = {
  id: 'user-settings',
  accessTypes: [{
    permission: 'user-settings.user-info.view',
    componentKey: 'view-user-info',
    readOnly: true,
    label: 'View User Information'
  }, {
    permission: 'user-settings.profile-image.view',
    componentKey: 'view-profile-image',
    readOnly: true,
    label: 'View Profile Image'
  }, {
    permission: 'user-settings.notification-types.view',
    componentKey: 'view-notification-types',
    readOnly: true,
    label: 'View Notification Types'
  }, {
    permission: 'user-settings.time-zone.view',
    componentKey: 'view-time-zone',
    readOnly: true,
    label: 'View Time Zone'
  }, {
    permission: 'user-settings.security-questions.view',
    componentKey: 'view-security-questions',
    readOnly: true,
    label: 'View Security Questions and Answers'
  }, {
    permission: 'user-settings.password.update',
    readOnly: true,
    label: 'Update Password'
  }],
  components: [{
    id: 'view-user-info',
    accessTypes: [{
      permission: 'user-settings.user-info.edit',
      readOnly: true,
      label: 'Edit User Information'
    }]
  }, {
    id: 'view-profile-image',
    accessTypes: [{
      permission: 'user-settings.profile-image.edit',
      readOnly: true,
      label: 'Add/Change/Remove Image'
    }]
  }, {
    id: 'view-notification-types',
    accessTypes: [{
      permission: 'user-settings.notification-types.manage',
      readOnly: true,
      label: 'Enable/Disable Notifications'
    }]
  }, 
  {
    id: 'view-time-zone',
    accessTypes: [{
      permission: 'user-settings.time-zone.edit',
      readOnly: true,
      label: 'Edit Time Zone'
    }]
  },{
    id: 'view-security-questions',
    accessTypes: [{
      permission: 'user-settings.security-questions.edit',
      readOnly: true,
      label: 'Edit Answers to Security Questions'
    }]
  }]
};