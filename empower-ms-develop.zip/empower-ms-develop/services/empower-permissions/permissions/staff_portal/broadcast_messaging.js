'use strict';

module.exports = {
  id: 'broadcast-messaging',
  accessTypes: [{
    permission: 'broadcast-messaging.messages.view',
    componentKey: 'view-broadcast-messages',
    readOnly: true,
    label: 'View Broadcast Messages'
  }, {
    permission: 'broadcast-messaging.target-groups.view',
    componentKey: 'view-target-groups',
    readOnly: true,
    label: 'View Target Groups'
  }, {
    permission: 'broadcast-messaging.imports.view',
    componentKey: 'view-imports',
    readOnly: true,
    label: 'View Imports'
  }, {
    permission: 'broadcast-messaging.templates.view',
    componentKey: 'view-templates',
    readOnly: true,
    label: 'View Templates'
  }],
  components: [{
    id: 'view-target-groups',
    accessTypes: [{
      permission: 'broadcast-messaging.target-groups.manage',
      label: 'Add/Edit/Delete Target Groups'
    }]
  }, {
    id: 'view-imports',
    accessTypes: [{
      permission: 'broadcast-messaging.imports.manage',
      label: 'Add/Edit/Delete Imports'
    }]
  }, {
    id: 'view-templates',
    accessTypes: [{
      permission: 'broadcast-messaging.templates.manage',
      label: 'Add/Edit/Delete Templates'
    }]
  }, {
    id: 'view-broadcast-messages',
    accessTypes: [{
      permission: 'broadcast-messaging.messages.create',
      label: 'Create New Broadcast Message'
    }, {
      permission: 'broadcast-messaging.read-status.view',
      label: 'View Read Status'
    }]
  }]
};