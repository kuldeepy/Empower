'use strict';

module.exports = {
  id: 'task-center',
  accessTypes: [{
    permission: 'task-center.tasks.mine.view',
    readOnly: true,
    label: 'View My Tasks'
  }, {
    permission: 'task-center.tasks.unassigned.view',
    readOnly: true,
    label: 'View Unassigned Tasks'
  }, {
    permission: 'task-center.tasks.all.view',
    readOnly: true,
    label: 'View All Tasks'
  }, {
    permission: 'task-center.tasks.aom-approaching.view',
    readOnly: true,
    label: 'View Tasks - AOM Approaching'
  }, {
    permission: 'task-center.tasks.connection-severed.view',
    readOnly: true,
    label: 'View Tasks - Connection Severed'
  }, {
    permission: 'task-center.tasks.search',
    readOnly: true,
    label: 'Search Tasks'
  }, {
    permission: 'task-center.tasks.activity-log.view',
    readOnly: true,
    label: 'View Task Activity Log'
  }, {
    permission: 'task-center.tasks.threads.view',
    readOnly: true,
    componentKey: 'view-threads',
    label: 'View Discussion Threads'
  }, {
    permission: 'task-center.tasks.notes.view',
    readOnly: true,
    label: 'View Notes'
  }, {
    permission: 'task-center.searches.manage',
    readOnly: true,
    label: 'Add/Manage Saved Searches'
  }],
  components: [{
    id: 'view-threads',
    accessTypes: [{
      permission: 'task-center.tasks.threads.members.add',
      readOnly: true,
      label: 'Add Members to Discussion Thread'
    }, {
      permission: 'task-center.tasks.threads.comments.self-entered.edit',
      readOnly: true,
      label: 'Edit Comment - Self Entered'
    }, {
      permission: 'task-center.tasks.threads.comments.self-entered.delete',
      readOnly: true,
      label: 'Delete Comment - Self Entered'
    }, {
      permission: 'task-center.tasks.threads.comments.others.edit',
      readOnly: true,
      label: 'Edit Comment - Entered By Others'
    }]
  }]
};