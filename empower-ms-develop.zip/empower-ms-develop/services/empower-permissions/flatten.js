'use strict';
var _ = require('lodash');

module.exports = function(permissionSet) {
  var accessTypes = [];
  acccumulateAccessTypes(permissionSet, accessTypes);
  return accessTypes;
};

function acccumulateAccessTypes(component, accessTypes) {
  if (component.accessTypes) {
    component.accessTypes.map(function(accessType) {
      accessTypes.push(accessType);
    });
  }
  if (component.components) {
    component.components.map(function(comp) {
      acccumulateAccessTypes(comp, accessTypes);
    });
  }
}