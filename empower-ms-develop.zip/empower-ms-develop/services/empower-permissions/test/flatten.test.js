var chai = require('chai');
var expect = chai.expect;
var flatten = require('../flatten');

describe('flatten', function() {

  it('gets all access types recursively', function() {

    var permissionSet = {
      accessTypes: [{
        permission: 'a'
      }, {
        permission: 'b'
      }],
      components: [{
        accessTypes: [{
          permission: 'c'
        }],
        components: [{
          accessTypes: [{
            permission: 'd'
          }, {
            permission: 'e'
          }]
        }]
      }]
    };

    var result = flatten(permissionSet);

    expect(result).to.eql([{
      permission: 'a'
    }, {
      permission: 'b'
    }, {
      permission: 'c'
    }, {
      permission: 'd'
    }, {
      permission: 'e'
    }]);
  });

});