'use strict';
var micro = require('ih-microservice');

var defaults = {
  id: 'empower-physicians',
  debug: true,
  defaultExchange: 'topic://medseek-api',
  defaultQueue: 'empower-physicians',
  defaultReturnBody: true,
  communicateDb: 'MedseekIntegration60',
  pageSize: '20'
};

micro(defaults, function(app, logging, microservices, bluebird, options, url, _, util) {
  options.pageSize = parseInt(options.pageSize,10);
  var Promise = bluebird;
  var log = logging.getLogger('empower-physicians');
  var knownPgs = {};

  return Promise.resolve(microservices.bind('empower.physicians.search.#', searchPhysicians));
  
  function searchPhysicians(req,mc) {
     return getKnownDb(parseInt(_.last(mc.routingKey.split('.')),10))
      .then(function(db){
        return querySource(req,db)
          .then(function(data){
            return data;
          }).catch(function(err){
            return err;
          });
      })
      .catch(function(err){
        log.error(err);
        return err;
      });
  }

  function getKnownDb(id){
    return new Promise(function(resolve){
      log.trace('knownPgs for id %s: ',id, knownPgs[id]);
      resolve(knownPgs[id]);
    })
    .then(function(pg){
      return pg || microservices.call('empower.v6.portal-groups.get',{})
        .tap(function(pgs){
          log.trace(pgs);
        })
        .then(function(pgs){
          var pg = _.find(pgs,{siteID: id });
          knownPgs[id] = pg.id;
          return knownPgs[id];
        });
    });
  }

  function querySource(req,pgId){
    var qString = 'SELECT [id] \n' +
'                  ,[firstName]\n' +
'                  ,[middleInitial]\n' +
'                  ,[lastName]\n' +
'                  ,[email]\n' +
'                  ,[degree]\n' +
'                  ,[hospitalAffiliation]\n' +
'                  ,[genderId]\n' +
'                  ,[image]\n' +
'                 ,[isEnabled]\n' +
'                  ,[certification]\n' +
'                  ,[isParticipating]\n' +
'                  ,[externalId]\n' +
'                  ,[dateOfBirth]\n' +
'                  ,[websiteUrl]\n' +
'              FROM [nModFindADoctorDoctor] d WHERE isEnabled = 1 \n' + getWhere(req);
    return query({
                  q: qString,
                  qp: getWhereParameters(req)
                },pgId);
                
  }

  function query(q,pgId){
    return microservices.call('empower.v6.portal-groups.mssql.query.'+ pgId,q)
      .tap(function(results){
        log.trace('get| query results', util.inspect(results, { colors: true, depth: null }));
      })
      .then(function(results){
        return results;
      });
  }

  function getWhere(req){
    var where = '';
    if(req.fullName){
      where += ' AND ((FirstName like  @fullName1 + \'%\' OR FirstName like  @fullName2 + \'%\') OR (LastName like  @fullName1 + \'%\' OR LastName like  @fullName2 + \'%\'))';
    }
    if(req.firstName){
      where += ' AND FirstName like  @firstName + \'%\' ';
    }

    if(req.lastName){
      where += ' AND LastName like  @lastName + \'%\' ';
    }
    return where;
  }

  function getWhereParameters(req){
    var params = {};
    if(req.firstName){
      params.firstName = qp(req.firstName);
    }
    if(req.lastName){
      params.lastName = qp(req.lastName);
    }
    if(req.fullName){
      var parts = req.fullName.split(' ');
      params.fullName1 = qp(parts[0]);
      params.fullName2 = qp(parts[1] || parts[0]);
    }
    return params;
  }
  
 

  function qp(value) {
      return {
        type: 'NVarChar',
        value: value,
        length: value.length
      };
  }
});