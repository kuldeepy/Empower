'use strict';
var chai = require('chai');
var expect = chai.expect;
var sinon = require('sinon');
var proxyquire = require('proxyquire');
var Promise = require('bluebird');
var _ = require('lodash');
var util = require('util');

describe('<%= name %>', function() {

  var service, mockMs, mockLog, mockMicroservices, options, mockLogging;
  beforeEach(function() {
    mockMs = sinon.stub();
    mockLog = sinon.stub({
      debug: function() {},
      error: function(e) {
        console.error(e)
      },
      trace: function() {}
    });
    mockLogging = {
      getLogger: function() {
        return mockLog;
      }
    };
    mockMicroservices = sinon.stub({
      bind: function() {},
      call: function() {}
    });
    options = {};
    mockMs.yields(undefined, mockLogging, mockMicroservices, Promise, options, _, util);
    service = proxyquire.noCallThru()('../<%= name %>.js', {
      'ih-microservice': mockMs
    });

  });

  it('exists', function() {
    expect(service).to.be.an('object');
  });

});