'use strict';

var micro = require('ih-microservice');

var defaults = {
  id: '<%= name %>',
  defaultExchange: 'topic://medseek-api',
  defaultQueue: '<%= name %>',
  defaultReturnBody: true
};

micro(defaults, function(app, logging, microservices, Promise, options, _, util) {
  var log = logging.getLogger(defaults.id);

  module.exports = {
    main: main
  };

  return Promise.resolve(microservices.bind('my.routing.key.#', main));

  function main(request, messageContext) {
    return Promise.try(
      function() {
        return {};
      }
    ).catch(function(err) {
      log.error(err);
      return {
        error: err.message
      };
    });
  }

});