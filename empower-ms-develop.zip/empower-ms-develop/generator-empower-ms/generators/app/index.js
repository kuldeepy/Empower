'use strict';
var yeoman = require('yeoman-generator');
var chalk = require('chalk');
var yosay = require('yosay');
var path = require('path');

var defaultName;

module.exports = yeoman.generators.Base.extend({

  initializing: function() {
    defaultName = path.basename(this.destinationRoot());
  },

  prompting: function() {
    var done = this.async();

    this.log(yosay(
      'Welcome to the ' + chalk.red('empower-microservice') + ' generator!'
    ));

    var prompts = [{
      type: 'input',
      name: 'name',
      message: 'Name (hit Enter to use default)',
      default: defaultName
    },{
      type: 'input',
      name: 'description',
      message: 'Enter a description for this microservice',
      default: 'The ' + defaultName + ' microservice.'
    }];

    this.prompt(prompts, function(props) {
      this.props = props;
      done();
    }.bind(this));
  },

  writing: {
    app: function() {
      this.fs.copyTpl(
        this.templatePath('_package.json'),
        this.destinationPath('package.json'),
        this.props
      );
      this.fs.copyTpl(
        this.templatePath('_package.nuspec'),
        this.destinationPath('package.nuspec'),
        this.props
      );
      this.fs.copyTpl(
        this.templatePath('_services.xml'),
        this.destinationPath('services.xml'),
        this.props
      );
      this.fs.copyTpl(
        this.templatePath('_gulpfile.js'),
        this.destinationPath('gulpfile.js'),
        this.props
      );
      this.fs.copyTpl(
        this.templatePath('_gulpfile.js'),
        this.destinationPath('gulpfile.js'),
        this.props
      );
      this.fs.copyTpl(
        this.templatePath('_index.js'),
        this.destinationPath(this.props.name + '.js'),
        this.props
      );
      this.fs.copyTpl(
        this.templatePath('test/_index.tests.js'),
        this.destinationPath('test/' + this.props.name + '.tests.js'),
        this.props
      );
    },

    projectfiles: function() {}
  },

  install: function() {
    this.installDependencies({
      bower: false
    });
  }
});