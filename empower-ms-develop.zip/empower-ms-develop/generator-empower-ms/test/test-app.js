'use strict';

var path = require('path');
var assert = require('yeoman-generator').assert;
var helpers = require('yeoman-generator').test;
var os = require('os');

describe('empower-ms:app', function() {
  before(function(done) {
    helpers.run(path.join(__dirname, '../generators/app'))
      .withOptions({
        skipInstall: true
      })
      .withPrompts({
        description: 'test',
        name: 'a-test-microservice'
      })
      .on('end', done);
  });

  it('creates files', function() {
    assert.file([
      'package.json',
      'package.nuspec',
      'gulpfile.js',
      'services.xml',
      'a-test-microservice.js',
      'test/a-test-microservice.tests.js'
    ]);
  });
});